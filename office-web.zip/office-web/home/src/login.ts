import '@soffice/ui/tokens.css'
import './login.css'
import logo from './logo.svg'

type Mode = 'login' | 'signup' | 'setup'

const KO = (navigator.language || '').toLowerCase().startsWith('ko')
const S = KO
  ? {
      title: 'S-Office Web',
      tagline: 'Word·Excel·PowerPoint·PDF 파일을 브라우저에서 AI와 함께 편집하세요.',
      setup: '관리자 계정 만들기',
      setupHint: '이 서버의 첫 계정이 관리자가 됩니다.',
      login: '로그인',
      signup: '계정 만들기',
      username: '사용자 이름',
      displayName: '표시 이름 (선택)',
      password: '비밀번호',
      password2: '비밀번호 확인',
      mismatch: '비밀번호가 일치하지 않습니다.',
      toSignup: '계정이 없으신가요? 만들기',
      toLogin: '이미 계정이 있으신가요? 로그인',
    }
  : {
      title: 'S-Office Web',
      tagline: 'Edit Word, Excel, PowerPoint and PDF files in your browser, with AI.',
      setup: 'Create the administrator account',
      setupHint: 'The first account on this server becomes its administrator.',
      login: 'Sign in',
      signup: 'Create account',
      username: 'Username',
      displayName: 'Display name (optional)',
      password: 'Password',
      password2: 'Confirm password',
      mismatch: 'The passwords do not match.',
      toSignup: 'No account yet? Create one',
      toLogin: 'Already have an account? Sign in',
    }

document.documentElement.lang = KO ? 'ko' : 'en'

function nextUrl(): string {
  const next = new URLSearchParams(location.search).get('next') ?? '/'
  // only same-site relative targets
  return next.startsWith('/') && !next.startsWith('//') ? next : '/'
}

async function post(url: string, body: unknown): Promise<{ ok: boolean; error?: string }> {
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    credentials: 'same-origin',
    body: JSON.stringify(body),
  })
  const data = (await res.json().catch(() => ({}))) as { error?: string }
  return res.ok ? { ok: true } : { ok: false, error: data.error ?? `HTTP ${res.status}` }
}

function render(mode: Mode, allowSignup: boolean): void {
  const root = document.getElementById('root')!
  const heading = mode === 'setup' ? S.setup : mode === 'signup' ? S.signup : S.login
  root.innerHTML = `
    <div class="card">
      <img class="logo" alt="" src="${logo}" />
      <h1>${S.title}</h1>
      <p class="tagline">${S.tagline}</p>
      <h2>${heading}</h2>
      ${mode === 'setup' ? `<p class="hint">${S.setupHint}</p>` : ''}
      <form novalidate>
        <label>${S.username}<input name="username" autocomplete="username" required autofocus /></label>
        ${mode !== 'login' ? `<label>${S.displayName}<input name="displayName" autocomplete="name" /></label>` : ''}
        <label>${S.password}<input name="password" type="password" autocomplete="${mode === 'login' ? 'current-password' : 'new-password'}" required /></label>
        ${mode !== 'login' ? `<label>${S.password2}<input name="password2" type="password" autocomplete="new-password" required /></label>` : ''}
        <p class="error" role="alert" hidden></p>
        <button type="submit" class="primary">${heading}</button>
      </form>
      ${
        mode === 'setup' || !allowSignup
          ? ''
          : `<button class="link" data-switch>${mode === 'login' ? S.toSignup : S.toLogin}</button>`
      }
    </div>`
  const form = root.querySelector('form')!
  const error = root.querySelector<HTMLElement>('.error')!
  root.querySelector('[data-switch]')?.addEventListener('click', () =>
    render(mode === 'login' ? 'signup' : 'login', allowSignup),
  )
  form.addEventListener('submit', async (ev) => {
    ev.preventDefault()
    const data = Object.fromEntries(new FormData(form)) as Record<string, string>
    error.hidden = true
    if (mode !== 'login' && data.password !== data.password2) {
      error.textContent = S.mismatch
      error.hidden = false
      return
    }
    const button = form.querySelector('button')!
    button.disabled = true
    const res =
      mode === 'login'
        ? await post('/api/auth/login', { username: data.username, password: data.password })
        : await post('/api/auth/signup', {
            username: data.username,
            password: data.password,
            displayName: data.displayName,
          })
    button.disabled = false
    if (res.ok) {
      location.replace(nextUrl())
      return
    }
    error.textContent = res.error ?? 'Error'
    error.hidden = false
  })
}

void (async () => {
  const status = (await fetch('/api/auth/status').then((r) => r.json())) as {
    needsSetup: boolean
    allowSignup: boolean
  }
  const me = await fetch('/api/me', { credentials: 'same-origin' })
  if (me.ok) {
    location.replace(nextUrl())
    return
  }
  render(status.needsSetup ? 'setup' : 'login', status.allowSignup)
})()
