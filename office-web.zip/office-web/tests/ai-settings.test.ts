import { readFileSync } from 'node:fs'
import { join } from 'node:path'
import { afterAll, beforeAll, describe, expect, it, vi } from 'vitest'
import { adminClient, startHarness, userClient, type Client, type Harness } from './helpers'

vi.mock('../server/src/apps/all', () => ({}))

const SERVER_KEY = 'sk-ant-server-secret-0001'
const MASK = '••••••••'

let h: Harness
let admin: Client
let user: Client
beforeAll(async () => {
  h = await startHarness({
    ANTHROPIC_API_KEY: SERVER_KEY,
    AI_PROVIDER: undefined,
    AI_API_KEY: undefined,
    ALLOW_PRIVATE_AI_ENDPOINTS: undefined,
  })
  admin = await adminClient(h)
  user = await userClient(admin, h, 'alice')
})
afterAll(() => h.cleanup())

function userSettingsFile(userId: string): string {
  return join(h.dataDir, 'users', userId, 'appdata', 'ai-settings.json')
}

describe('AI settings', () => {
  it('inherits the server key without ever returning it', async () => {
    const res = await user.json('GET', '/api/ai/settings')
    expect(res.status).toBe(200)
    expect(res.body.provider).toBe('anthropic')
    expect(res.body.providers.anthropic.apiKey).toBe(MASK)
    expect(JSON.stringify(res.body)).not.toContain(SERVER_KEY)
  })

  it('stores a user key, masks it, and keeps it when the mask comes back', async () => {
    const settings = (await user.json('GET', '/api/ai/settings')).body
    settings.provider = 'openai'
    settings.providers.openai = { ...settings.providers.openai, apiKey: 'sk-user-openai-0002', model: 'gpt-test' }
    const saved = await user.json('PUT', '/api/ai/settings', settings)
    expect(saved.status).toBe(200)
    expect(saved.body.providers.openai.apiKey).toBe(MASK)
    expect(JSON.stringify(saved.body)).not.toContain('sk-user-openai-0002')

    // a round trip of the masked copy must not wipe the stored key
    const again = await user.json('PUT', '/api/ai/settings', saved.body)
    expect(again.status).toBe(200)
    const me = (await user.json('GET', '/api/me')).body
    const stored = JSON.parse(readFileSync(userSettingsFile(me.id), 'utf8'))
    expect(stored.providers.openai.apiKey).toBe('sk-user-openai-0002')
    // the server's key is inherited at request time, never written into a user file
    expect(JSON.stringify(stored)).not.toContain(SERVER_KEY)
  })

  it('rejects invalid settings payloads', async () => {
    expect((await user.req('PUT', '/api/ai/settings', { provider: 'nope', providers: {} })).status).toBe(400)
    expect((await user.req('PUT', '/api/ai/settings', [])).status).toBe(400)
  })

  it('refuses the codex provider (it would spawn a local binary)', async () => {
    const settings = (await user.json('GET', '/api/ai/settings')).body
    settings.provider = 'codex'
    expect((await user.req('PUT', '/api/ai/settings', settings)).status).toBe(400)
  })

  it('does not let a user point a key at a private address (SSRF)', async () => {
    const settings = (await user.json('GET', '/api/ai/settings')).body
    settings.provider = 'openai'
    settings.providers.openai = {
      ...settings.providers.openai,
      apiKey: 'sk-user',
      baseUrl: 'http://127.0.0.1:9/v1',
      model: 'gpt-test',
    }
    const put = await user.json('PUT', '/api/ai/settings', settings)
    expect(put.status).toBe(400)
    expect(put.body.error).toMatch(/private or local address/)
    // nothing was stored
    const after = (await user.json('GET', '/api/ai/settings')).body
    expect(after.providers.openai.baseUrl ?? '').not.toContain('127.0.0.1')
  })

  it('takes credentials and base URLs from the server copy, not the request', async () => {
    // the request names an attacker URL and key; this user's server copy has neither
    const fresh = await userClient(admin, h, 'dave')
    const settings = (await fresh.json('GET', '/api/ai/settings')).body
    settings.provider = 'openai'
    settings.providers.openai = {
      ...settings.providers.openai,
      baseUrl: 'https://attacker.example/v1',
      apiKey: 'sk-attacker',
      model: 'gpt-test',
    }
    const chat = await fresh.json('POST', '/api/ai/chat', { settings, system: 's', user: 'u' })
    expect(chat.body.ok).toBe(false)
    expect(chat.body.error).toMatch(/No AI provider is configured/)
  })

  it('reports no configured provider instead of calling out', async () => {
    const fresh = await userClient(admin, h, 'carol')
    const settings = (await fresh.json('GET', '/api/ai/settings')).body
    settings.provider = 'gemini'
    settings.providers.gemini.apiKey = ''
    await fresh.json('PUT', '/api/ai/settings', settings)
    const got = (await fresh.json('GET', '/api/ai/settings')).body
    // a half-configured provider falls back (activeProvider), never to a keyless call
    expect(got.provider).not.toBe('gemini')
  })
})
