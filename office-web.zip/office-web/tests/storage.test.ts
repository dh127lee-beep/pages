import { existsSync, mkdtempSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { beforeAll, describe, expect, it } from 'vitest'

process.env.DATA_DIR = mkdtempSync(join(tmpdir(), 'office-web-storage-'))

const { normalizeVirtualPath, validateName, UserStorage, StorageError } = await import('../server/src/storage')

describe('normalizeVirtualPath', () => {
  it('normalizes separators and leading slash', () => {
    expect(normalizeVirtualPath('a/b.docx')).toBe('/a/b.docx')
    expect(normalizeVirtualPath('/a//b.docx')).toBe('/a/b.docx')
    expect(normalizeVirtualPath('\\a\\b.docx')).toBe('/a/b.docx')
    expect(normalizeVirtualPath('/')).toBe('/')
  })

  it.each(['/../etc/passwd', '/a/../../b', '..', '/a/./b', '', '/a\u0000b', '/a/b:c', '/a/<b>', 'x'.repeat(2000)])(
    'rejects %j',
    (p) => {
      expect(() => normalizeVirtualPath(p)).toThrow(StorageError)
    },
  )

  it('rejects non-strings', () => {
    expect(() => normalizeVirtualPath(undefined)).toThrow(StorageError)
    expect(() => normalizeVirtualPath(42)).toThrow(StorageError)
  })
})

describe('validateName', () => {
  it.each(['', '.', '..', 'a/b', 'a\\b', 'con?', 'x'.repeat(300)])('rejects %j', (n) => {
    expect(() => validateName(n)).toThrow(StorageError)
  })
  it('trims and accepts ordinary names', () => {
    expect(validateName('  보고서 2026.docx ')).toBe('보고서 2026.docx')
  })
})

describe('UserStorage', () => {
  const id = '11111111-2222-3333-4444-555555555555'
  let s: InstanceType<typeof UserStorage>
  beforeAll(() => {
    s = new UserStorage(id)
  })

  it('refuses malformed user ids', () => {
    expect(() => new UserStorage('../../etc')).toThrow()
  })

  it('keeps every resolved path inside its root', () => {
    expect(s.resolve('/a/b.txt').startsWith(s.root)).toBe(true)
    expect(() => s.resolve('/../x')).toThrow(StorageError)
  })

  it('writes atomically, detects conflicts and lists', async () => {
    const data = new TextEncoder().encode('hello')
    const st = await s.write('/doc.txt', data)
    expect(st.size).toBe(5)
    await expect(s.write('/doc.txt', data, { overwrite: false })).rejects.toMatchObject({ status: 409 })
    await expect(s.write('/doc.txt', data, { expectHash: 'nope' })).rejects.toMatchObject({ status: 409 })
    await expect(s.write('/missing/x.txt', data)).rejects.toMatchObject({ status: 404 })
    const names = (await s.list('/')).map((e) => e.name)
    expect(names).toContain('doc.txt')
    expect(names.some((n) => n.startsWith('.~'))).toBe(false)
  })

  it('finds a free name', async () => {
    await s.write('/Document.docx', new Uint8Array([1]))
    expect(await s.uniquePath('/', 'Document.docx')).toBe('/Document 2.docx')
  })

  it('moves deleted items to the trash and restores them', async () => {
    await s.write('/gone.txt', new Uint8Array([1, 2]))
    await s.remove('/gone.txt')
    expect(existsSync(s.resolve('/gone.txt'))).toBe(false)
    const [item] = await s.listTrash()
    expect(item.path).toBe('/gone.txt')
    const restored = await s.restoreTrash(item.id)
    expect(restored.path).toBe('/gone.txt')
    await expect(s.restoreTrash('../../x')).rejects.toMatchObject({ status: 400 })
  })

  it('refuses to move a folder into itself or delete the root', async () => {
    await s.mkdir('/f')
    await expect(s.move('/f', '/f/g')).rejects.toMatchObject({ status: 400 })
    await expect(s.remove('/')).rejects.toMatchObject({ status: 400 })
  })
})
