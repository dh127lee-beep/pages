import { existsSync } from 'node:fs'
import { afterAll, beforeAll, describe, expect, it, vi } from 'vitest'
import { adminClient, startHarness, type Client, type Harness } from './helpers'

vi.mock('../server/src/apps/all', () => ({}))

const CHROME =
  Boolean(process.env.CHROME_PATH && existsSync(process.env.CHROME_PATH)) ||
  existsSync('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome') ||
  existsSync('/usr/bin/chromium') ||
  existsSync('/usr/bin/google-chrome')

let h: Harness
let c: Client
beforeAll(async () => {
  h = await startHarness({ DISABLE_CHROME: undefined })
  c = await adminClient(h)
})
afterAll(async () => {
  const { closeChrome } = await import('../server/src/lib/chrome')
  await closeChrome()
  h.cleanup()
})

const request = (extra: Record<string, unknown> = {}) => ({
  fileName: 'Book.pdf',
  html:
    '<!doctype html><html><head><style>@page{size:A4}</style></head><body>' +
    '<p>page one</p><p style="break-before:page">page two</p>' +
    // never fetched: the print context refuses every non-data: request
    '<img src="http://169.254.169.254/latest/meta-data">' +
    '</body></html>',
  landscape: false,
  pageSize: 'A4',
  margins: { top: 0.5, bottom: 0.5, left: 0.5, right: 0.5 },
  scale: 1,
  ...extra,
})

describe('PDF export through the editors', () => {
  it('routes xlsx, xlsm, csv and pptx to PDF through their editors', async () => {
    const res = await c.json('GET', '/api/convert/formats')
    for (const from of ['docx', 'xlsx', 'xlsm', 'csv', 'pptx']) {
      const pdf = (res.body[from] as Array<{ to: string; available: boolean; reason?: string }>).find(
        (r) => r.to === 'pdf',
      )
      expect(pdf, from).toBeDefined()
      // whatever keeps a route off here is a missing tool, never "not implemented"
      expect(pdf?.reason ?? '').not.toMatch(/not available yet/)
    }
  })

  it('schema-checks the print request the browser sends', async () => {
    const { parseWorkbookPdfRequest } = await import('../server/src/lib/sheets-pdf')
    expect(() => parseWorkbookPdfRequest(request())).not.toThrow()
    expect(() => parseWorkbookPdfRequest(request({ scale: 50 }))).toThrow()
    expect(() => parseWorkbookPdfRequest({ ...request(), extra: 1 })).toThrow()
  })

  it.skipIf(!CHROME)('prints a workbook layout with first-page and even-page variants', async () => {
    const { parseWorkbookPdfRequest, renderWorkbookPdf } = await import('../server/src/lib/sheets-pdf')
    const { PDFDocument } = await import('pdf-lib')
    const plain = await renderWorkbookPdf(parseWorkbookPdfRequest(request()))
    expect((await PDFDocument.load(plain)).getPageCount()).toBe(2)
    const variants = await renderWorkbookPdf(
      parseWorkbookPdfRequest(
        request({
          footerTemplate: '<span class="pageNumber"></span>',
          firstPage: { footerTemplate: '<span>first</span>' },
          evenPages: {},
        }),
      ),
    )
    expect((await PDFDocument.load(variants)).getPageCount()).toBe(2)
  }, 60_000)
})
