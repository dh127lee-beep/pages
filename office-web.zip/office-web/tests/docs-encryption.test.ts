import { readFileSync } from 'node:fs'
import { createRequire } from 'node:module'
import { join } from 'node:path'
import { afterAll, beforeAll, describe, expect, it, vi } from 'vitest'
import { adminClient, startHarness, userClient, type Client, type Harness } from './helpers'

// only the docs module: no sidecars or Electron stand-ins
vi.mock('../server/src/apps/all', async () => {
  await import('../server/src/apps/docs')
  return {}
})

const upstream = join(__dirname, '..', 'upstream', 'soffice')
const req = createRequire(join(upstream, 'package.json'))
const officeCrypto = req('officecrypto-tool') as {
  decrypt(b: Buffer, o: { password: string }): Promise<Buffer>
}
const fixture = (name: string) =>
  new Uint8Array(readFileSync(join(upstream, 'apps', 'docs', 'tests', 'encrypted-fixtures', name)))
const PASSWORD = 'Password1234_'
const TAB = 'a'.repeat(32)
const isCfb = (b: Uint8Array) => Buffer.from(b.subarray(0, 4)).toString('hex') === 'd0cf11e0'

let h: Harness
let c: Client
beforeAll(async () => {
  h = await startHarness()
  c = await adminClient(h)
  await c.req('PUT', '/api/fs/raw?path=%2Fsecret.docx', fixture('office-agile-password.docx'))
  await c.req('PUT', '/api/fs/raw?path=%2Fplain.docx', fixture('office-agile-plain.docx'))
})
afterAll(() => h.cleanup())

async function rawBytes(client: Client, path: string): Promise<Buffer> {
  const res = await client.req('GET', `/api/fs/raw?path=${encodeURIComponent(path)}`)
  return Buffer.from(await res.arrayBuffer())
}

describe('docs: password-protected documents', () => {
  it('asks for a password instead of returning bytes', async () => {
    const open = await c.json('POST', '/api/apps/docs/open', { tab: TAB, path: '/secret.docx' })
    expect(open.body).toEqual({ needsPassword: true, path: '/secret.docx', name: 'secret.docx' })
  })

  it('reports plain documents as such', async () => {
    const open = await c.json('POST', '/api/apps/docs/open', { tab: TAB, path: '/plain.docx' })
    expect(open.body.plain).toBe(true)
    expect(open.body.hash).toMatch(/^[0-9a-f]{64}$/)
  })

  it('rejects a wrong password with reason wrong-password', async () => {
    const res = await c.json('POST', '/api/apps/docs/decrypt', { tab: TAB, path: '/secret.docx', password: 'nope' })
    expect(res.body.ok).toBe(false)
    expect(res.body.reason).toBe('wrong-password')
  })

  it('decrypts into a one-shot, user-bound URL and never echoes the password', async () => {
    const res = await c.json('POST', '/api/apps/docs/decrypt', { tab: TAB, path: '/secret.docx', password: PASSWORD })
    expect(res.body.ok).toBe(true)
    expect(JSON.stringify(res.body)).not.toContain(PASSWORD)
    const url = res.body.result.dataUrl as string
    expect(url).toMatch(/^\/api\/apps\/docs\/blob\//)
    // another user cannot take it
    const other = await userClient(c, h, 'mallory')
    expect((await other.req('GET', url)).status).toBe(404)
    const first = await c.req('GET', url)
    expect(first.status).toBe(200)
    const plain = Buffer.from(await first.arrayBuffer())
    expect(Buffer.compare(plain, Buffer.from(fixture('office-agile-plain.docx')))).toBe(0)
    // one shot
    expect((await c.req('GET', url)).status).toBe(404)
  })

  it('re-encrypts on save with the remembered password', async () => {
    const plain = fixture('office-agile-plain.docx')
    const save = await c.json('POST', `/api/apps/docs/save?tab=${TAB}&path=%2Fsecret.docx&source=%2Fsecret.docx`, plain)
    expect(save.body.ok).toBe(true)
    expect(save.body.encrypted).toBe(true)
    const onDisk = await rawBytes(c, '/secret.docx')
    expect(isCfb(onDisk)).toBe(true)
    const back = await officeCrypto.decrypt(onDisk, { password: PASSWORD })
    expect(Buffer.compare(back, Buffer.from(plain))).toBe(0)
  })

  it('keeps passwords per tab: a fresh tab must ask again', async () => {
    const open = await c.json('POST', '/api/apps/docs/open', { tab: 'b'.repeat(32), path: '/secret.docx' })
    expect(open.body.needsPassword).toBe(true)
  })

  it('protects a plain document on its next save (Review › Protect)', async () => {
    const tab = 'c'.repeat(32)
    await c.json('POST', '/api/apps/docs/open', { tab, path: '/plain.docx' })
    const rev = (await c.json('POST', '/api/apps/docs/password-intent-revision', { tab })).body.revision
    expect(Number.isSafeInteger(rev)).toBe(true)
    expect((await c.json('POST', '/api/apps/docs/set-password', { tab, path: '/plain.docx', password: 'New#1' })).body.ok).toBe(true)
    const save = await c.json('POST', `/api/apps/docs/save?tab=${tab}&path=%2Fplain.docx&source=%2Fplain.docx`, fixture('office-agile-plain.docx'))
    expect(save.body.encrypted).toBe(true)
    expect(save.body.passwordIntentPending).toBe(false)
    const onDisk = await rawBytes(c, '/plain.docx')
    expect(isCfb(onDisk)).toBe(true)
    await expect(officeCrypto.decrypt(onDisk, { password: 'New#1' })).resolves.toBeInstanceOf(Buffer)

    // clearing the password writes plain bytes again
    await c.json('POST', '/api/apps/docs/set-password', { tab, path: '/plain.docx', password: null })
    await c.json('POST', `/api/apps/docs/save?tab=${tab}&path=%2Fplain.docx&source=%2Fplain.docx`, fixture('office-agile-plain.docx'))
    expect(isCfb(await rawBytes(c, '/plain.docx'))).toBe(false)
  })

  it('refuses a stale save with 409', async () => {
    const save = await c.req('POST', `/api/apps/docs/save?tab=${TAB}&path=%2Fplain.docx&expectHash=${'0'.repeat(64)}`, fixture('office-agile-plain.docx'))
    expect(save.status).toBe(409)
  })

  it('validates tab ids', async () => {
    const res = await c.json('POST', '/api/apps/docs/open', { tab: '../x', path: '/plain.docx' })
    expect(res.status).toBe(400)
  })
})
