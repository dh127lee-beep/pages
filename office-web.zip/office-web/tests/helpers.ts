/**
 * Test harness: a fresh server (temp DATA_DIR) driven in-process through
 * Hono's app.request, with a tiny cookie jar per client.
 *
 * Test files must `vi.mock('../server/src/apps/all', () => ({}))` so the
 * editor modules (sidecars, Electron stand-ins) stay out of these tests.
 */

import { mkdtempSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

export interface Harness {
  dataDir: string
  app: { request: (input: string, init?: RequestInit) => Response | Promise<Response> }
  client: () => Client
  cleanup: () => void
}

export interface Client {
  cookie: string
  req: (method: string, path: string, body?: unknown, headers?: Record<string, string>) => Promise<Response>
  json: <T = any>(method: string, path: string, body?: unknown) => Promise<{ status: number; body: T }>
  login: (username: string, password: string) => Promise<Response>
}

/** env must be in place before the server modules load (config reads it at import) */
export async function startHarness(env: Record<string, string | undefined> = {}): Promise<Harness> {
  const dataDir = mkdtempSync(join(tmpdir(), 'office-web-test-'))
  process.env.DATA_DIR = dataDir
  process.env.OFFICE_WEB_ROOT = join(__dirname, '..')
  for (const [k, v] of Object.entries(env)) {
    if (v === undefined) delete process.env[k]
    else process.env[k] = v
  }
  const { createApp } = await import('../server/src/app')
  const { getDb, closeDb } = await import('../server/src/db')
  getDb()
  const app = createApp()

  const client = (): Client => {
    const c: Client = {
      cookie: '',
      async req(method, path, body, headers = {}) {
        const init: RequestInit = { method, headers: { ...headers } }
        const h = init.headers as Record<string, string>
        if (c.cookie) h.cookie = c.cookie
        if (body instanceof Uint8Array || typeof body === 'string') {
          init.body = body as BodyInit
        } else if (body !== undefined) {
          init.body = JSON.stringify(body)
          h['content-type'] = 'application/json'
        }
        const res = await app.request(`http://localhost${path}`, init)
        const set = res.headers.get('set-cookie')
        if (set) {
          const m = /office_session=([^;]*)/.exec(set)
          if (m) c.cookie = m[1] ? `office_session=${m[1]}` : ''
        }
        return res
      },
      async json(method, path, body) {
        const res = await c.req(method, path, body)
        const text = await res.text()
        return { status: res.status, body: text ? JSON.parse(text) : null }
      },
      login: (username, password) => c.req('POST', '/api/auth/login', { username, password }),
    }
    return c
  }

  return {
    dataDir,
    app,
    client,
    cleanup: () => {
      closeDb()
      rmSync(dataDir, { recursive: true, force: true })
    },
  }
}

/** first account (becomes admin) and a signed-in client for it */
export async function adminClient(h: Harness, username = 'admin', password = 'password123'): Promise<Client> {
  const c = h.client()
  const res = await c.req('POST', '/api/auth/signup', { username, password })
  if (res.status !== 200) throw new Error(`signup failed: ${res.status} ${await res.text()}`)
  return c
}

export async function userClient(admin: Client, h: Harness, username: string, password = 'password123'): Promise<Client> {
  const created = await admin.req('POST', '/api/admin/users', { username, password })
  if (created.status !== 200) throw new Error(`create user failed: ${created.status}`)
  const c = h.client()
  const res = await c.login(username, password)
  if (res.status !== 200) throw new Error('login failed')
  return c
}
