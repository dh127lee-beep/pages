import { afterAll, beforeAll, describe, expect, it, vi } from 'vitest'
import { adminClient, startHarness, userClient, type Client, type Harness } from './helpers'

vi.mock('../server/src/apps/all', () => ({}))

let h: Harness
let c: Client
beforeAll(async () => {
  h = await startHarness()
  c = await adminClient(h)
})
afterAll(() => h.cleanup())

const q = (path: string) => encodeURIComponent(path)
const bytes = (s: string) => new TextEncoder().encode(s)

describe('file API', () => {
  it('writes, reads and stats a file', async () => {
    const put = await c.json('PUT', `/api/fs/raw?path=${q('/hello.md')}`, bytes('# hi'))
    expect(put.status).toBe(200)
    expect(put.body.hash).toMatch(/^[0-9a-f]{64}$/)
    const raw = await c.req('GET', `/api/fs/raw?path=${q('/hello.md')}`)
    expect(await raw.text()).toBe('# hi')
    // user content never runs on our origin
    expect(raw.headers.get('content-security-policy')).toMatch(/sandbox/)
    expect(raw.headers.get('x-content-type-options')).toBe('nosniff')
    const stat = await c.json('GET', `/api/fs/stat?path=${q('/hello.md')}&hash=1`)
    expect(stat.body.hash).toBe(put.body.hash)
  })

  it('serves downloads as attachments', async () => {
    const res = await c.req('GET', `/api/fs/raw?path=${q('/hello.md')}&download=1`)
    expect(res.headers.get('content-disposition')).toMatch(/^attachment/)
  })

  it('refuses a stale save with 409 (expectHash)', async () => {
    const first = await c.json('GET', `/api/fs/stat?path=${q('/hello.md')}&hash=1`)
    await c.req('PUT', `/api/fs/raw?path=${q('/hello.md')}`, bytes('# changed elsewhere'))
    const stale = await c.req('PUT', `/api/fs/raw?path=${q('/hello.md')}&expectHash=${first.body.hash}`, bytes('# mine'))
    expect(stale.status).toBe(409)
    const noOverwrite = await c.req('PUT', `/api/fs/raw?path=${q('/hello.md')}&overwrite=0`, bytes('x'))
    expect(noOverwrite.status).toBe(409)
  })

  it('rejects traversal in every path parameter', async () => {
    expect((await c.req('GET', `/api/fs/raw?path=${q('/../../etc/passwd')}`)).status).toBe(400)
    expect((await c.req('PUT', `/api/fs/raw?path=${q('/a/../../x')}`, bytes('x'))).status).toBe(400)
    expect((await c.req('POST', '/api/fs/move', { from: '/hello.md', to: '/../x.md' })).status).toBe(400)
    expect((await c.req('POST', '/api/fs/rename', { path: '/hello.md', name: '../x.md' })).status).toBe(400)
  })

  it('creates folders, lists, renames and moves', async () => {
    expect((await c.json('POST', '/api/fs/mkdir', { path: '/Reports' })).status).toBe(200)
    const renamed = await c.json('POST', '/api/fs/rename', { path: '/hello.md', name: 'notes.md' })
    expect(renamed.body.path).toBe('/notes.md')
    const moved = await c.json('POST', '/api/fs/move', { from: '/notes.md', to: '/Reports/notes.md' })
    expect(moved.body.path).toBe('/Reports/notes.md')
    const list = await c.json('GET', `/api/fs/list?path=${q('/Reports')}`)
    expect(list.body.map((e: { name: string }) => e.name)).toEqual(['notes.md'])
    const dirs = await c.json('GET', '/api/fs/dirs')
    expect(dirs.body).toContain('/Reports')
  })

  it('copies under a free name', async () => {
    const copy = await c.json('POST', '/api/fs/copy', { from: '/Reports/notes.md' })
    expect(copy.body.path).toBe('/Reports/notes 2.md')
  })

  it('deletes into the trash and restores', async () => {
    await c.json('POST', '/api/fs/star', { path: '/Reports/notes 2.md', starred: true })
    expect((await c.json('POST', '/api/fs/delete', { paths: ['/Reports/notes 2.md'] })).status).toBe(200)
    expect((await c.req('GET', `/api/fs/stat?path=${q('/Reports/notes 2.md')}`)).status).toBe(404)
    // the star went with it
    expect((await c.json('GET', '/api/fs/starred')).body).toEqual([])
    const trash = await c.json('GET', '/api/fs/trash')
    expect(trash.body[0].path).toBe('/Reports/notes 2.md')
    const restored = await c.json('POST', '/api/fs/trash/restore', { id: trash.body[0].id })
    expect(restored.body.path).toBe('/Reports/notes 2.md')
  })

  it('tracks recent files', async () => {
    await c.json('POST', '/api/fs/recent', { path: '/Reports/notes.md' })
    const recent = await c.json('GET', '/api/fs/recent')
    expect(recent.body[0].path).toBe('/Reports/notes.md')
  })

  it('keeps users apart', async () => {
    const other = await userClient(c, h, 'eve')
    expect((await other.req('GET', `/api/fs/stat?path=${q('/Reports/notes.md')}`)).status).toBe(404)
    expect((await other.json('GET', '/api/fs/list?path=%2F')).body).toEqual([])
  })
})
