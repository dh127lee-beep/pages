import { existsSync } from 'node:fs'
import { join } from 'node:path'
import { afterAll, beforeAll, describe, expect, it, vi } from 'vitest'
import { adminClient, startHarness, type Client, type Harness } from './helpers'

vi.mock('../server/src/apps/all', () => ({}))

const ROOT = join(__dirname, '..')
const CLI_BUILT = existsSync(join(ROOT, 'dist', 'tools', 'cli', 'soffice.cjs'))

let h: Harness
let c: Client
beforeAll(async () => {
  h = await startHarness({ TOOLS_DIR: join(ROOT, 'dist', 'tools'), DISABLE_CHROME: '1' })
  c = await adminClient(h)
  await c.req('PUT', `/api/fs/raw?path=${encodeURIComponent('/notes.md')}`, new TextEncoder().encode('# Title\n\nBody **bold**\n'))
})
afterAll(() => h.cleanup())

describe('conversion API', () => {
  it('lists routes with availability', async () => {
    const res = await c.json('GET', '/api/convert/formats')
    expect(res.status).toBe(200)
    const md = res.body.md as Array<{ to: string; available: boolean; reason?: string }>
    expect(md.map((r) => r.to)).toEqual(expect.arrayContaining(['docx', 'html', 'pdf']))
    // Chrome is disabled in this run: the browser routes say why
    expect(md.find((r) => r.to === 'pdf')).toMatchObject({ available: false })
  })

  it('refuses unknown routes and bad paths', async () => {
    expect((await c.req('POST', '/api/convert', { path: '/notes.md', to: 'exe' })).status).toBe(400)
    expect((await c.req('POST', '/api/convert', { path: '/../x.md', to: 'docx' })).status).toBe(400)
  })

  it('answers 501 for a route whose engine is unavailable', async () => {
    const res = await c.json('POST', '/api/convert', { path: '/notes.md', to: 'pdf' })
    expect(res.status).toBe(501)
  })

  it.skipIf(!CLI_BUILT)('converts Markdown to Word next to the source', async () => {
    const res = await c.json('POST', '/api/convert', { path: '/notes.md', to: 'docx' })
    expect(res.status).toBe(200)
    expect(res.body.path).toBe('/notes.docx')
    const raw = await c.req('GET', `/api/fs/raw?path=${encodeURIComponent('/notes.docx')}`)
    const head = new Uint8Array(await raw.arrayBuffer()).slice(0, 2)
    expect(String.fromCharCode(...head)).toBe('PK')
    // a second conversion never overwrites the first
    const again = await c.json('POST', '/api/convert', { path: '/notes.md', to: 'docx' })
    expect(again.body.path).toBe('/notes 2.docx')
  })

  it.skipIf(!CLI_BUILT)('reports document structure without leaking disk paths', async () => {
    const res = await c.json('POST', '/api/convert/info', { path: '/notes.docx' })
    expect(res.status).toBe(200)
    expect(JSON.stringify(res.body)).not.toContain(h.dataDir)
  })
})
