import { afterAll, beforeAll, describe, expect, it, vi } from 'vitest'
import { adminClient, startHarness, type Harness } from './helpers'

vi.mock('../server/src/apps/all', () => ({}))

let h: Harness
beforeAll(async () => {
  h = await startHarness({ ALLOW_SIGNUP: undefined, ADMIN_USER: undefined, ADMIN_PASSWORD: undefined })
})
afterAll(() => h.cleanup())

describe('accounts and sessions', () => {
  it('reports first-run setup', async () => {
    const res = await h.client().json('GET', '/api/auth/status')
    expect(res.body).toEqual({ needsSetup: true, allowSignup: true })
  })

  it('makes the first account an administrator and signs it in', async () => {
    const admin = await adminClient(h)
    expect(admin.cookie).toMatch(/^office_session=/)
    const me = await admin.json('GET', '/api/me')
    expect(me.status).toBe(200)
    expect(me.body.isAdmin).toBe(true)
    expect(me.body.username).toBe('admin')
  })

  it('closes sign-up after the first account', async () => {
    const res = await h.client().req('POST', '/api/auth/signup', { username: 'second', password: 'password123' })
    expect(res.status).toBe(403)
  })

  it('rejects a wrong password with 401 and no cookie', async () => {
    const c = h.client()
    const res = await c.login('admin', 'wrong-password')
    expect(res.status).toBe(401)
    expect(c.cookie).toBe('')
  })

  it('sets an HttpOnly, SameSite=Lax session cookie on login', async () => {
    const c = h.client()
    const res = await c.login('admin', 'password123')
    expect(res.status).toBe(200)
    const cookie = res.headers.get('set-cookie') ?? ''
    expect(cookie).toMatch(/HttpOnly/i)
    expect(cookie).toMatch(/SameSite=Lax/i)
    // the password hash never reaches the browser
    expect(await res.text()).not.toMatch(/scrypt/)
  })

  it('requires a session for the API', async () => {
    const res = await h.client().req('GET', '/api/fs/list?path=%2F')
    expect(res.status).toBe(401)
  })

  it('ends the session on logout', async () => {
    const c = h.client()
    await c.login('admin', 'password123')
    const before = c.cookie
    await c.req('POST', '/api/auth/logout')
    const reuse = h.client()
    reuse.cookie = before
    expect((await reuse.req('GET', '/api/me')).status).toBe(401)
  })

  it('refuses cross-origin state changes (CSRF)', async () => {
    const c = h.client()
    await c.login('admin', 'password123')
    const evil = await c.req('POST', '/api/fs/mkdir', { path: '/x' }, { origin: 'https://evil.example', host: 'office.example' })
    expect(evil.status).toBe(403)
    const same = await c.req('POST', '/api/fs/mkdir', { path: '/x' }, { origin: 'https://office.example', host: 'office.example' })
    expect(same.status).toBe(200)
  })

  it('lets only administrators manage accounts', async () => {
    const admin = h.client()
    await admin.login('admin', 'password123')
    const created = await admin.json('POST', '/api/admin/users', { username: 'bob', password: 'password123' })
    expect(created.status).toBe(200)
    const bob = h.client()
    await bob.login('bob', 'password123')
    expect((await bob.req('GET', '/api/admin/users')).status).toBe(403)
  })
})
