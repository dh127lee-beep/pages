/**
 * Small DOM popup menus standing in for the native ones the shell's main
 * process pops up (tab list, "+" new-file menu, per-tab menu, app menu).
 */

export type MenuItem =
  | { label: string; onClick: () => void; checked?: boolean; disabled?: boolean }
  | { separator: true }

const CSS = `
.ow-menu{position:fixed;z-index:2147482000;min-width:200px;max-width:min(360px,calc(100vw - 16px));max-height:calc(100vh - 60px);overflow:auto;padding:4px;background:var(--surface,#fff);color:var(--text,#222);border:1px solid var(--border,#ddd);border-radius:8px;box-shadow:var(--shadow-menu,0 8px 24px rgba(0,0,0,.18));font:13px/1.3 system-ui,-apple-system,"Segoe UI","Apple SD Gothic Neo","Malgun Gothic",sans-serif}
.ow-menu button{display:flex;align-items:center;gap:8px;width:100%;padding:7px 10px;border:0;border-radius:5px;background:none;color:inherit;font:inherit;text-align:left;cursor:pointer;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.ow-menu button:hover:not(:disabled){background:var(--hover,#f2f2f2)}
.ow-menu button:disabled{opacity:.45;cursor:default}
.ow-menu .ow-check{width:14px;flex:none;text-align:center}
.ow-menu hr{border:0;border-top:1px solid var(--border-subtle,#eee);margin:4px 2px}
`

let open: { el: HTMLElement; close: () => void } | null = null

function ensureStyles(): void {
  if (document.getElementById('ow-menu-css')) return
  const style = document.createElement('style')
  style.id = 'ow-menu-css'
  style.textContent = CSS
  document.head.appendChild(style)
}

export function closeMenu(): void {
  open?.close()
}

/** pop up `items` with its top-left corner at (x, y), kept inside the viewport */
export function showMenu(x: number, y: number, items: MenuItem[]): void {
  closeMenu()
  ensureStyles()
  const el = document.createElement('div')
  el.className = 'ow-menu'
  el.setAttribute('role', 'menu')
  const hasChecks = items.some((i) => 'label' in i && i.checked !== undefined)
  for (const item of items) {
    if ('separator' in item) {
      el.appendChild(document.createElement('hr'))
      continue
    }
    const b = document.createElement('button')
    b.setAttribute('role', 'menuitem')
    b.disabled = item.disabled === true
    if (hasChecks) {
      const mark = document.createElement('span')
      mark.className = 'ow-check'
      mark.textContent = item.checked ? '✓' : ''
      b.appendChild(mark)
    }
    b.appendChild(document.createTextNode(item.label))
    b.addEventListener('click', () => {
      closeMenu()
      item.onClick()
    })
    el.appendChild(b)
  }
  document.body.appendChild(el)
  const rect = el.getBoundingClientRect()
  el.style.left = `${Math.max(8, Math.min(x, window.innerWidth - rect.width - 8))}px`
  el.style.top = `${Math.max(8, Math.min(y, window.innerHeight - rect.height - 8))}px`

  const onDown = (ev: Event) => {
    if (!el.contains(ev.target as Node)) close()
  }
  const onKey = (ev: KeyboardEvent) => {
    if (ev.key === 'Escape') close()
  }
  const close = () => {
    el.remove()
    window.removeEventListener('pointerdown', onDown, true)
    window.removeEventListener('keydown', onKey, true)
    window.removeEventListener('blur', close)
    open = null
  }
  // the opening click is still dispatching; listen from the next tick
  setTimeout(() => {
    window.addEventListener('pointerdown', onDown, true)
    window.addEventListener('keydown', onKey, true)
    // a press inside a tab iframe blurs this window
    window.addEventListener('blur', close)
  }, 0)
  open = { el, close }
  el.querySelector<HTMLButtonElement>('button:not(:disabled)')?.focus()
}
