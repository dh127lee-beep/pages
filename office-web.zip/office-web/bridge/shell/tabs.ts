/**
 * The shell's document tabs, web edition. Electron stacks one
 * WebContentsView per tab under the tab strip; here every document tab is an
 * iframe of its editor (/app/<id>/?path=…) laid over the shell's content
 * area, and only the active one is shown. Home is the shell page itself.
 */

import { basename, bus, confirmDialog, editorUrl, type AppId } from '../core'

export type TabKind = 'home' | AppId | 'help'

export interface TabSummary {
  id: string
  kind: TabKind
  title: string
  closable: boolean
  active: boolean
  filePath?: string
}

interface DocTab {
  id: string
  kind: Exclude<TabKind, 'home'>
  frame: HTMLIFrameElement
  title: string
  filePath?: string
}

const STORE_KEY = 'office-web:shell-tabs'
const ko = () => document.documentElement.lang.startsWith('ko')

const UNTITLED: Record<string, { en: string; ko: string }> = {
  docs: { en: 'Untitled document', ko: '제목 없는 문서' },
  sheets: { en: 'Untitled spreadsheet', ko: '제목 없는 스프레드시트' },
  slides: { en: 'Untitled presentation', ko: '제목 없는 프레젠테이션' },
  pdf: { en: 'PDF', ko: 'PDF' },
  markdown: { en: 'Untitled Markdown', ko: '제목 없는 마크다운' },
  html: { en: 'Untitled page', ko: '제목 없는 페이지' },
  help: { en: 'Help', ko: '도움말' },
}

/** titles the editors' index.html ship with — not a document name */
const GENERIC_TITLE = /^(S-Office|AI ?Docs|AI ?Sheets)(\s.*)?$/i

class TabHost {
  private tabs: DocTab[] = []
  private activeId = 'home'
  private seq = 0
  private container: HTMLDivElement | null = null
  private readonly listeners = new Set<(tabs: TabSummary[]) => void>()

  /** called once the shell DOM exists */
  mount(): void {
    if (this.container) return
    const el = document.createElement('div')
    el.id = 'ow-tab-views'
    el.style.cssText = 'position:fixed;left:0;right:0;bottom:0;top:40px;z-index:5;display:none;background:var(--surface,#fff)'
    document.body.appendChild(el)
    this.container = el
    const layout = () => {
      const bar = document.querySelector('.tab-bar')
      const top = bar ? Math.round(bar.getBoundingClientRect().bottom) : 40
      el.style.top = `${top}px`
    }
    window.addEventListener('resize', layout)
    new MutationObserver(layout).observe(document.body, { childList: true })
    layout()
    for (const t of this.tabs) el.appendChild(t.frame)
    this.apply()
    setInterval(() => this.poll(), 1200)
  }

  list(): TabSummary[] {
    const home: TabSummary = {
      id: 'home',
      kind: 'home',
      title: ko() ? '홈' : 'Home',
      closable: false,
      active: this.activeId === 'home',
    }
    return [
      home,
      ...this.tabs.map((t) => ({
        id: t.id,
        kind: t.kind,
        title: t.title,
        closable: true,
        active: t.id === this.activeId,
        ...(t.filePath ? { filePath: t.filePath } : {}),
      })),
    ]
  }

  onChanged(handler: (tabs: TabSummary[]) => void): () => void {
    this.listeners.add(handler)
    return () => this.listeners.delete(handler)
  }

  /** open (or focus, when that file is already open) an editor tab */
  open(kind: Exclude<TabKind, 'home'>, params: Record<string, string>): string {
    const path = params.path
    if (path) {
      const existing = this.tabs.find((t) => t.filePath === path)
      if (existing) {
        this.activate(existing.id)
        return existing.id
      }
    }
    const id = `t${Date.now().toString(36)}${(this.seq++).toString(36)}`
    const frame = document.createElement('iframe')
    frame.src = kind === 'help' ? '/?mode=help' : editorUrl(kind, params)
    frame.title = path ? basename(path) : ''
    frame.setAttribute('allow', 'clipboard-read; clipboard-write; fullscreen')
    frame.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;border:0;display:none;background:var(--surface,#fff)'
    const tab: DocTab = {
      id,
      kind,
      frame,
      title: path ? basename(path) : (ko() ? UNTITLED[kind]?.ko : UNTITLED[kind]?.en) ?? kind,
      ...(path ? { filePath: path } : {}),
    }
    frame.addEventListener('load', () => this.poll())
    this.tabs.push(tab)
    this.container?.appendChild(frame)
    this.activeId = id
    this.apply()
    return id
  }

  activate(id: string): void {
    if (id !== 'home' && !this.tabs.some((t) => t.id === id)) return
    this.activeId = id
    this.apply()
  }

  /** asks a dirty editor first, like the desktop close guard */
  async close(id: string): Promise<void> {
    const tab = this.tabs.find((t) => t.id === id)
    if (!tab) return
    let state: { dirty: boolean; autoSave?: boolean } | undefined
    try {
      const w = tab.frame.contentWindow as (Window & { __owCloseState?: () => typeof state }) | null
      state = w?.__owCloseState?.()
    } catch {
      state = undefined
    }
    if (state?.dirty && !state.autoSave) {
      this.activate(id)
      const ok = await confirmDialog(
        ko()
          ? `"${tab.title}"에 저장하지 않은 변경 내용이 있습니다. 닫으시겠습니까?`
          : `"${tab.title}" has unsaved changes. Close it anyway?`,
        ko() ? '닫기' : 'Close',
      )
      if (!ok) return
    }
    const index = this.tabs.indexOf(tab)
    this.tabs.splice(index, 1)
    tab.frame.remove()
    if (this.activeId === id) {
      const next = this.tabs[index] ?? this.tabs[index - 1]
      this.activeId = next?.id ?? 'home'
    }
    this.apply()
  }

  async closeMany(ids: string[]): Promise<void> {
    for (const id of ids) await this.close(id)
  }

  reorder(id: string, toIndex: number): void {
    const from = this.tabs.findIndex((t) => t.id === id)
    if (from < 0) return
    const [tab] = this.tabs.splice(from, 1)
    // index counts Home, pinned at 0
    const target = Math.max(0, Math.min(this.tabs.length, toIndex - 1))
    this.tabs.splice(target, 0, tab!)
    this.apply()
  }

  /** "Open in New Window": the editor moves to its own browser tab */
  detach(id: string): void {
    const tab = this.tabs.find((t) => t.id === id)
    if (!tab) return
    let url = tab.frame.src
    try {
      url = tab.frame.contentWindow?.location.href ?? url
    } catch {
      // keep the original src
    }
    window.open(url, '_blank')
    void this.close(id)
  }

  /** a file was renamed/moved from Home: open tabs follow it */
  pathMoved(from: string, to: string): void {
    let changed = false
    for (const t of this.tabs) {
      if (!t.filePath) continue
      if (t.filePath === from || t.filePath.startsWith(`${from}/`)) {
        const oldPath = t.filePath
        t.filePath = to + t.filePath.slice(from.length)
        t.title = basename(t.filePath)
        changed = true
        try {
          const w = t.frame.contentWindow as
            | (Window & { __owFileMoved?: (a: string, b: string) => void })
            | null
          w?.__owFileMoved?.(oldPath, t.filePath)
        } catch {
          // frame not loaded yet: it reads the new path when it does
        }
      }
    }
    if (changed) this.apply()
  }

  docTabs(): Array<{ id: string; title: string; kind: string }> {
    return this.tabs.map((t) => ({ id: t.id, title: t.title, kind: t.kind }))
  }

  /** restore the previous session's file tabs (sessionStorage survives reloads) */
  restore(): void {
    let saved: { tabs: Array<{ kind: Exclude<TabKind, 'home'>; path: string }>; active: number } | null = null
    try {
      saved = JSON.parse(sessionStorage.getItem(STORE_KEY) ?? 'null')
    } catch {
      saved = null
    }
    if (!saved?.tabs?.length) return
    for (const t of saved.tabs) this.open(t.kind, { path: t.path })
    const active = saved.active >= 0 ? this.tabs[saved.active] : undefined
    this.activeId = active?.id ?? 'home'
    this.apply()
  }

  /** follow each editor's file path and title (Save As, first save, renames) */
  private poll(): void {
    let changed = false
    for (const t of this.tabs) {
      try {
        const w = t.frame.contentWindow
        if (!w) continue
        const path = new URLSearchParams(w.location.search).get('path') ?? undefined
        if (path && path !== t.filePath) {
          t.filePath = path
          changed = true
        }
        const docTitle = w.document.title.trim()
        const title = t.filePath
          ? basename(t.filePath)
          : docTitle && !GENERIC_TITLE.test(docTitle)
            ? docTitle
            : t.title
        if (title !== t.title) {
          t.title = title
          changed = true
        }
      } catch {
        // not loaded yet
      }
    }
    if (changed) this.apply()
  }

  private apply(): void {
    const active = this.tabs.find((t) => t.id === this.activeId)
    if (this.container) this.container.style.display = active ? 'block' : 'none'
    for (const t of this.tabs) t.frame.style.display = t === active ? 'block' : 'none'
    if (active) {
      try {
        active.frame.contentWindow?.focus()
      } catch {
        // cross-origin never happens here, but a detached frame can throw
      }
    }
    document.title = active ? `${active.title} — S-Office` : 'S-Office'
    try {
      sessionStorage.setItem(
        STORE_KEY,
        JSON.stringify({
          tabs: this.tabs.filter((t) => t.filePath).map((t) => ({ kind: t.kind, path: t.filePath })),
          active: this.tabs.filter((t) => t.filePath).findIndex((t) => t.id === this.activeId),
        }),
      )
    } catch {
      // storage unavailable
    }
    const snapshot = this.list()
    for (const l of [...this.listeners]) l(snapshot)
    bus.emit('tabs:changed', snapshot)
  }
}

export const tabHost = new TabHost()
