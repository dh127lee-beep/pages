/**
 * Browser-side replacement for the Electron preload bridges.
 *
 * Every S-Office renderer talks to its main process through objects the
 * preload exposes on `window` (`window.desktop`, `window.projectApi`, ...).
 * In the web build those objects are installed by this bridge before the
 * renderer's own entry module runs, and every call is served by the office
 * server over HTTP instead of Electron IPC.
 */

export type Lang = 'zh' | 'en' | 'ja' | 'ko' | 'fr' | 'de' | 'es' | 'th' | 'id' | 'ru' | 'ar'
export type UiTheme = 'light' | 'dark' | 'system'
export type AppId = 'docs' | 'sheets' | 'slides' | 'pdf' | 'markdown' | 'html'

export const SUPPORTED_LANGS: readonly Lang[] = [
  'zh',
  'en',
  'ja',
  'ko',
  'fr',
  'de',
  'es',
  'th',
  'id',
  'ru',
  'ar',
]

// ---------------------------------------------------------------------------
// HTTP

export class HttpError extends Error {
  constructor(
    readonly status: number,
    message: string,
  ) {
    super(message)
  }
}

async function request<T>(method: string, url: string, body?: unknown): Promise<T> {
  const init: RequestInit = { method, credentials: 'same-origin', headers: {} }
  if (body instanceof ArrayBuffer || ArrayBuffer.isView(body) || body instanceof Blob) {
    init.body = body as BodyInit
    ;(init.headers as Record<string, string>)['content-type'] = 'application/octet-stream'
  } else if (body !== undefined) {
    init.body = JSON.stringify(body)
    ;(init.headers as Record<string, string>)['content-type'] = 'application/json'
  }
  const res = await fetch(url, init)
  if (res.status === 401) {
    redirectToLogin()
    throw new HttpError(401, 'Not signed in')
  }
  const text = await res.text()
  let data: unknown = null
  if (text) {
    try {
      data = JSON.parse(text)
    } catch {
      data = text
    }
  }
  if (!res.ok) {
    const message =
      data && typeof data === 'object' && 'error' in data
        ? String((data as { error: unknown }).error)
        : `${res.status} ${res.statusText}`
    throw new HttpError(res.status, message)
  }
  return data as T
}

export const http = {
  get: <T>(url: string) => request<T>('GET', url),
  post: <T>(url: string, body?: unknown) => request<T>('POST', url, body ?? {}),
  put: <T>(url: string, body?: unknown) => request<T>('PUT', url, body),
  del: <T>(url: string) => request<T>('DELETE', url),
}

export function redirectToLogin(): void {
  const next = encodeURIComponent(location.pathname + location.search)
  if (!location.pathname.startsWith('/login')) location.href = `/login?next=${next}`
}

// ---------------------------------------------------------------------------
// Files: the server exposes one virtual tree per user; paths are POSIX-style
// and rooted at "/" (e.g. "/Reports/q3.docx").

export interface FileStat {
  path: string
  name: string
  size: number
  mtimeMs: number
  isDir: boolean
  hash?: string
}

export const files = {
  rawUrl(path: string, opts?: { download?: boolean }): string {
    const q = new URLSearchParams({ path })
    if (opts?.download) q.set('download', '1')
    return `/api/fs/raw?${q}`
  },
  stat: (path: string) => http.get<FileStat>(`/api/fs/stat?${new URLSearchParams({ path })}`),
  exists: async (path: string) => {
    try {
      await files.stat(path)
      return true
    } catch (err) {
      if (err instanceof HttpError && err.status === 404) return false
      throw err
    }
  },
  async read(path: string): Promise<ArrayBuffer> {
    const res = await fetch(files.rawUrl(path), { credentials: 'same-origin' })
    if (!res.ok) throw new HttpError(res.status, `Cannot read ${path}`)
    return res.arrayBuffer()
  },
  async readText(path: string): Promise<string> {
    return new TextDecoder().decode(await files.read(path))
  },
  /** writes bytes; `expectHash` turns a concurrent outside change into a 409 */
  write(
    path: string,
    data: ArrayBuffer | ArrayBufferView | Blob | string,
    opts?: { overwrite?: boolean; expectHash?: string },
  ): Promise<FileStat> {
    const q = new URLSearchParams({ path })
    if (opts?.overwrite === false) q.set('overwrite', '0')
    if (opts?.expectHash) q.set('expectHash', opts.expectHash)
    const body = typeof data === 'string' ? new TextEncoder().encode(data) : data
    return http.put<FileStat>(`/api/fs/raw?${q}`, body)
  },
  /** a free name next to `dir` such as "Document 2.docx" */
  uniquePath: (dir: string, name: string) =>
    http.get<{ path: string }>(`/api/fs/unique?${new URLSearchParams({ dir, name })}`),
  defaultDir: () => '/',
}

export function basename(path: string): string {
  const i = Math.max(path.lastIndexOf('/'), path.lastIndexOf('\\'))
  return i >= 0 ? path.slice(i + 1) : path
}

export function dirname(path: string): string {
  const i = path.lastIndexOf('/')
  return i <= 0 ? '/' : path.slice(0, i)
}

export function extname(path: string): string {
  const name = basename(path)
  const i = name.lastIndexOf('.')
  return i > 0 ? name.slice(i).toLowerCase() : ''
}

export function stripExt(name: string): string {
  const i = name.lastIndexOf('.')
  return i > 0 ? name.slice(0, i) : name
}

export function joinPath(dir: string, name: string): string {
  return dir.endsWith('/') ? `${dir}${name}` : `${dir}/${name}`
}

export function toArrayBuffer(data: ArrayBuffer | ArrayBufferView): ArrayBuffer {
  if (data instanceof ArrayBuffer) return data
  return data.buffer.slice(data.byteOffset, data.byteOffset + data.byteLength) as ArrayBuffer
}

export function base64ToBytes(b64: string): Uint8Array {
  const bin = atob(b64)
  const out = new Uint8Array(bin.length)
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i)
  return out
}

export function bytesToBase64(bytes: Uint8Array): string {
  let bin = ''
  const step = 0x8000
  for (let i = 0; i < bytes.length; i += step) {
    bin += String.fromCharCode(...bytes.subarray(i, i + step))
  }
  return btoa(bin)
}

// ---------------------------------------------------------------------------
// Which app owns which extension (mirrors the shell's routing table)

const APP_BY_EXT: Record<string, AppId> = {
  '.docx': 'docs',
  '.doc': 'docs',
  '.dotx': 'docs',
  '.odt': 'docs',
  '.rtf': 'docs',
  '.xlsx': 'sheets',
  '.xlsm': 'sheets',
  '.xls': 'sheets',
  '.csv': 'sheets',
  '.ods': 'sheets',
  '.pptx': 'slides',
  '.ppt': 'slides',
  '.odp': 'slides',
  '.pdf': 'pdf',
  '.md': 'markdown',
  '.markdown': 'markdown',
  '.html': 'html',
  '.htm': 'html',
}

export function appForPath(path: string): AppId | null {
  return APP_BY_EXT[extname(path)] ?? null
}

export function editorUrl(app: AppId, params: Record<string, string>): string {
  return `/app/${app}/?${new URLSearchParams(params)}`
}

/** open a document in its editor, in a new browser tab (the web's "shell tab") */
/** the web shell (home page with tabs) when this editor runs inside one of its tab iframes */
export interface ShellHost {
  openTab(app: AppId, params: Record<string, string>): void
  openSettings(section: string): void
}

export function shellHost(): ShellHost | null {
  try {
    if (window.parent === window) return null
    return ((window.parent as unknown as { __owShell?: ShellHost }).__owShell ?? null)
  } catch {
    return null
  }
}

export function openInNewTab(path: string | null, app?: AppId): void {
  const target = app ?? (path ? appForPath(path) : null)
  const host = shellHost()
  if (host && target) {
    host.openTab(target, path ? { path } : { new: '1' })
    return
  }
  if (!target) {
    if (path) window.open(files.rawUrl(path, { download: true }), '_blank')
    return
  }
  window.open(editorUrl(target, path ? { path } : { new: '1' }), '_blank')
}

// ---------------------------------------------------------------------------
// Launch parameters: /app/<id>/?path=/x.docx | ?new=1 | ?template=...

export const launch = (() => {
  const q = new URLSearchParams(location.search)
  return {
    path: q.get('path'),
    isNew: q.get('new') === '1',
    params: q,
  }
})()

/** rewrite the address bar after Save As / first save so a reload reopens the file */
export function setLaunchPath(path: string): void {
  const url = new URL(location.href)
  url.searchParams.delete('new')
  url.searchParams.set('path', path)
  history.replaceState(history.state, '', url)
}

// ---------------------------------------------------------------------------
// Event bus (main → renderer pushes become local events)

type Handler = (...args: never[]) => void

export class EventBus {
  private readonly handlers = new Map<string, Set<Handler>>()

  on<A extends unknown[]>(name: string, handler: (...args: A) => void): () => void {
    let set = this.handlers.get(name)
    if (!set) {
      set = new Set()
      this.handlers.set(name, set)
    }
    set.add(handler as unknown as Handler)
    return () => set.delete(handler as unknown as Handler)
  }

  emit(name: string, ...args: unknown[]): void {
    for (const h of [...(this.handlers.get(name) ?? [])]) {
      try {
        ;(h as (...a: unknown[]) => void)(...args)
      } catch (err) {
        console.error(`[bridge] ${name} handler failed`, err)
      }
    }
  }

  count(name: string): number {
    return this.handlers.get(name)?.size ?? 0
  }
}

export const bus = new EventBus()

/**
 * The web shell tells an editor in one of its tab iframes that its file was
 * renamed or moved from Home: the address bar follows, and the bridge emits
 * 'file:moved' ({ oldPath, newPath }) for app bridges to forward.
 */
;(window as unknown as { __owFileMoved?: (oldPath: string, newPath: string) => void }).__owFileMoved = (
  oldPath,
  newPath,
) => {
  const url = new URL(location.href)
  if (url.searchParams.get('path') === oldPath) {
    url.searchParams.set('path', newPath)
    history.replaceState(history.state, '', url)
  }
  bus.emit('file:moved', { oldPath, newPath })
}

/** preferences changed in another tab (home page settings) reach every open editor */
const channel = typeof BroadcastChannel !== 'undefined' ? new BroadcastChannel('office-web') : null
channel?.addEventListener('message', (ev: MessageEvent) => {
  const msg = ev.data as { type?: string; payload?: unknown }
  if (!msg?.type) return
  if (msg.type === 'prefs') applyPrefs(msg.payload as Partial<Prefs>, false)
  if (msg.type === 'ai-settings') bus.emit('ai:settings-changed')
})

export function broadcast(type: string, payload?: unknown): void {
  channel?.postMessage({ type, payload })
}

// ---------------------------------------------------------------------------
// User preferences (the shell's app-settings.json, kept per user on the server)

export interface Prefs {
  language: Lang
  theme: UiTheme
  documentTheme: 'follow' | 'light' | 'dark'
  /** the shell's AutoSave default; updatedAt 0 = never set */
  autoSaveDefault: { on: boolean; updatedAt: number }
  authorName: string
  aiPanelPrefs: Record<string, unknown> | null
}

export interface Me {
  id: string
  username: string
  displayName: string
  isAdmin: boolean
  prefs: Prefs
}

function browserLang(): Lang {
  const tag = (navigator.language || 'en').toLowerCase()
  const base = tag.split('-')[0] as Lang
  return SUPPORTED_LANGS.includes(base) ? base : 'en'
}

const fallbackPrefs: Prefs = {
  language: browserLang(),
  theme: 'system',
  documentTheme: 'follow',
  autoSaveDefault: { on: false, updatedAt: 0 },
  authorName: '',
  aiPanelPrefs: null,
}

let prefs: Prefs = { ...fallbackPrefs }

export const me: Promise<Me | null> = http
  .get<Me>('/api/me')
  .then((user) => {
    prefs = { ...fallbackPrefs, ...user.prefs }
    if (!prefs.authorName) prefs.authorName = user.displayName || user.username
    return user
  })
  .catch(() => null)

export async function getPrefs(): Promise<Prefs> {
  await me
  return prefs
}

function applyPrefs(patch: Partial<Prefs>, persist: boolean): void {
  const before = prefs
  prefs = { ...prefs, ...patch }
  if (patch.language && patch.language !== before.language) {
    bus.emit('app:language-changed', prefs.language)
  }
  if (patch.theme && patch.theme !== before.theme) bus.emit('app:theme-changed', prefs.theme)
  if (patch.documentTheme && patch.documentTheme !== before.documentTheme) {
    bus.emit('app:document-theme-changed', prefs.documentTheme)
  }
  if (patch.autoSaveDefault && patch.autoSaveDefault.updatedAt !== before.autoSaveDefault.updatedAt) {
    bus.emit('app:auto-save-default-changed', prefs.autoSaveDefault)
  }
  if (patch.authorName !== undefined && patch.authorName !== before.authorName) {
    bus.emit('app:author-name-changed', prefs.authorName)
  }
  if (patch.aiPanelPrefs) bus.emit('app:ai-panel-prefs-changed', prefs.aiPanelPrefs)
  if (persist) {
    broadcast('prefs', patch)
    void http.put('/api/me/prefs', patch).catch((err) => console.warn('[bridge] prefs', err))
  }
}

export function setPrefs(patch: Partial<Prefs>): void {
  applyPrefs(patch, true)
}

// ---------------------------------------------------------------------------
// Methods every app's DesktopApi shares (language, theme, AI, attachments...)

/** AiStreamChunk, structurally (the canonical type lives in @soffice/ai-provider) */
export interface StreamChunk {
  requestId: string
  type: string
  [key: string]: unknown
}

const activeStreams = new Map<string, AbortController>()

async function aiStream(request: { requestId: string } & Record<string, unknown>): Promise<void> {
  const controller = new AbortController()
  activeStreams.set(request.requestId, controller)
  const emit = (chunk: StreamChunk) => bus.emit('ai:stream-chunk', chunk)
  try {
    const res = await fetch('/api/ai/stream', {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(request),
      signal: controller.signal,
    })
    if (!res.ok || !res.body) {
      const text = await res.text().catch(() => '')
      emit({ requestId: request.requestId, type: 'error', error: text || `HTTP ${res.status}` })
      return
    }
    const reader = res.body.pipeThrough(new TextDecoderStream()).getReader()
    let buffer = ''
    for (;;) {
      const { value, done } = await reader.read()
      if (done) break
      buffer += value
      let nl: number
      while ((nl = buffer.indexOf('\n')) >= 0) {
        const line = buffer.slice(0, nl).trim()
        buffer = buffer.slice(nl + 1)
        if (line) emit(JSON.parse(line) as StreamChunk)
      }
    }
    if (buffer.trim()) emit(JSON.parse(buffer) as StreamChunk)
  } catch (err) {
    if (controller.signal.aborted) {
      emit({ requestId: request.requestId, type: 'done' })
    } else {
      emit({
        requestId: request.requestId,
        type: 'error',
        error: err instanceof Error ? err.message : String(err),
        errorCode: 'network',
      })
    }
  } finally {
    activeStreams.delete(request.requestId)
  }
}

export interface AttachmentMeta {
  path: string
  name: string
  ext: string
  sizeBytes: number
  kind?: string
  [key: string]: unknown
}

export interface AttachmentAddResult {
  accepted: AttachmentMeta[]
  rejected: string[]
}

function randomId(): string {
  const bytes = crypto.getRandomValues(new Uint8Array(8))
  return [...bytes].map((b) => b.toString(16).padStart(2, '0')).join('')
}

/** File objects dropped/picked in the page → the server path of their uploaded copy */
const droppedFiles = new WeakMap<File, string>()
/** uploads still in flight, by the path getPathForFile already handed out */
const pendingUploads = new Map<string, Promise<AttachmentAddResult>>()

function startUpload(file: File): { path: string; done: Promise<AttachmentAddResult> } {
  const id = randomId()
  const name = file.name.replace(/[/\\]/g, '_') || 'file'
  const path = `/.attachments/${id}/${name}`
  const q = new URLSearchParams({ id, name })
  const done = http
    .put<AttachmentAddResult>(`/api/attachments?${q}`, file)
    .catch((err): AttachmentAddResult => ({
      accepted: [],
      rejected: [`${file.name}: ${err instanceof Error ? err.message : String(err)}`],
    }))
    .finally(() => pendingUploads.delete(path))
  droppedFiles.set(file, path)
  pendingUploads.set(path, done)
  return { path, done }
}

/** chat attachments are uploaded into the user's private scratch area on the server */
async function uploadAttachments(list: File[]): Promise<AttachmentAddResult> {
  const results = await Promise.all(list.map((f) => startUpload(f).done))
  return {
    accepted: results.flatMap((r) => r.accepted),
    rejected: results.flatMap((r) => r.rejected),
  }
}

/** a dropped File's path: its upload starts now, addAttachmentPaths waits for it */
export function pathForFile(file: File): string {
  return droppedFiles.get(file) ?? startUpload(file).path
}

async function addAttachmentPaths(paths: string[]): Promise<AttachmentAddResult> {
  await Promise.all(paths.map((p) => pendingUploads.get(p)))
  return http.post<AttachmentAddResult>('/api/attachments/add', { paths })
}

export function pickLocalFiles(opts: { accept?: string; multiple?: boolean } = {}): Promise<File[]> {
  return new Promise((resolve) => {
    const input = document.createElement('input')
    input.type = 'file'
    if (opts.accept) input.accept = opts.accept
    input.multiple = opts.multiple ?? false
    input.style.display = 'none'
    let settled = false
    const finish = (list: File[]) => {
      if (settled) return
      settled = true
      input.remove()
      resolve(list)
    }
    input.addEventListener('change', () => finish([...(input.files ?? [])]))
    input.addEventListener('cancel', () => finish([]))
    document.body.appendChild(input)
    input.click()
  })
}

export function commonApi() {
  return {
    getLanguage: async () => (await getPrefs()).language,
    getSystemLocale: async () => navigator.language || 'en-US',
    onLanguageChanged: (h: (lang: Lang) => void) => bus.on('app:language-changed', h),
    getTheme: async () => (await getPrefs()).theme,
    onThemeChanged: (h: (t: UiTheme) => void) => bus.on('app:theme-changed', h),
    getDocumentTheme: async () => (await getPrefs()).documentTheme,
    onDocumentThemeChanged: (h: (t: string) => void) => bus.on('app:document-theme-changed', h),
    getAutoSaveDefault: async () => (await getPrefs()).autoSaveDefault,
    onAutoSaveDefaultChanged: (h: (v: Prefs['autoSaveDefault']) => void) => bus.on('app:auto-save-default-changed', h),
    getAuthorName: async () => (await getPrefs()).authorName,
    onAuthorNameChanged: (h: (n: string) => void) => bus.on('app:author-name-changed', h),
    getAiPanelPrefs: async () => (await getPrefs()).aiPanelPrefs ?? undefined,
    setAiPanelPrefs: async (patch: Record<string, unknown>) => {
      const next = { ...((await getPrefs()).aiPanelPrefs ?? {}), ...patch }
      setPrefs({ aiPanelPrefs: next })
      return next
    },
    onAiPanelPrefsChanged: (h: (p: unknown) => void) => bus.on('app:ai-panel-prefs-changed', h),
    onChromePressed: (h: () => void) => bus.on('app:chrome-pressed', h),

    // AI
    getAiSettings: () => http.get<unknown>('/api/ai/settings'),
    setAiSettings: async (settings: unknown) => {
      await http.put('/api/ai/settings', settings)
      broadcast('ai-settings')
      bus.emit('ai:settings-changed')
    },
    onAiSettingsChanged: (h: () => void) => bus.on('ai:settings-changed', h),
    openAiModelSettings: async () => {
      const host = shellHost()
      if (host) host.openSettings('aiModel')
      else window.open('/?settings=aiModel', '_blank')
    },
    aiChat: (req: unknown) => http.post<unknown>('/api/ai/chat', req),
    aiStream,
    aiStreamCancel: async (requestId: string) => {
      activeStreams.get(requestId)?.abort()
      void http.post('/api/ai/stream-cancel', { requestId }).catch(() => undefined)
    },
    onAiStream: (h: (c: StreamChunk) => void) => bus.on('ai:stream-chunk', h),
    aiGskStatus: async () => ({ loggedIn: false }),
    aiGskLogin: async () => {
      const host = shellHost()
      if (host) host.openSettings('aiModel')
      else window.open('/?settings=aiModel', '_blank')
    },
    webSearch: (query: string, maxResults?: number) =>
      http.post<unknown>('/api/ai/web-search', { query, maxResults }),
    imageSearch: (query: string, maxResults?: number) =>
      http.post<unknown>('/api/ai/image-search', { query, maxResults }),
    fetchImage: (url: string) => http.post<unknown>('/api/ai/fetch-image', { url }),
    analyzeMedia: (op: unknown) => http.post<unknown>('/api/ai/analyze-media', op),
    aiGenerateImage: (op: unknown) => http.post<unknown>('/api/ai/generate-image', op),

    // chat attachments
    pickAttachments: async () => {
      const list = await pickLocalFiles({ multiple: true })
      if (list.length === 0) return null
      return uploadAttachments(list)
    },
    addAttachmentPaths,
    addPastedImage: async (data: ArrayBuffer, ext: string) => {
      const name = `pasted-${Date.now()}.${ext.replace(/^\./, '') || 'png'}`
      return uploadAttachments([new File([data], name)])
    },
    readAttachment: (path: string, offset: number, maxChars: number) =>
      http.post<unknown>('/api/attachments/read', { path, offset, maxChars }),
    readAttachmentImage: (path: string) => http.post<unknown>('/api/attachments/read-image', { path }),

    // starred-files knowledge base (the home page's stars)
    kbList: () => http.get<unknown>('/api/kb/list'),
    kbSearch: (query: { q: string; limit?: number }) => http.post<unknown>('/api/kb/search', query),
    kbRead: (path: string, offset: number) => http.post<unknown>('/api/kb/read', { path, offset }),

    // drag & drop: the uploaded copy of a dropped File
    getPathForFile: pathForFile,
    openSourcePath: async (path: string) => openInNewTab(path),
    openExternal: async (url: string) => {
      window.open(url, '_blank', 'noopener')
    },
    getRecentFiles: async () => {
      const list = await http.get<Array<{ path: string }>>('/api/fs/recent').catch(() => [])
      return list.map((r) => r.path)
    },
  }
}

export function projectApi() {
  return {
    resolveChat: (args: unknown) => http.post<unknown>('/api/project/resolve-chat', args),
    appendChat: (args: unknown) => http.post<void>('/api/project/append-chat', args),
    loadChat: (args: unknown) => http.post<unknown>('/api/project/load-chat', args),
    rebindChat: (args: unknown) => http.post<unknown>('/api/project/rebind-chat', args),
  }
}

// ---------------------------------------------------------------------------
// Fallback for the long tail of desktop-only calls (printers, spellcheck
// plumbing, Zotero, OS clipboard bitmaps...). Unknown `onX` subscriptions
// return an unsubscribe; unknown invokes resolve to null, which every preload
// caller already treats as "canceled / unavailable".

export function withFallback<T extends object>(name: string, impl: Partial<T> & object): T {
  const warned = new Set<string>()
  return new Proxy(impl as T, {
    get(target, prop, receiver) {
      if (typeof prop === 'symbol' || prop in target) return Reflect.get(target, prop, receiver)
      if (prop === 'then') return undefined
      if (/^on[A-Z]/.test(prop)) return () => () => undefined
      return (..._args: unknown[]) => {
        if (!warned.has(prop)) {
          warned.add(prop)
          console.info(`[bridge] ${name}.${prop} is not available in the web edition`)
        }
        return Promise.resolve(null)
      }
    },
  })
}

export function expose(name: string, value: unknown): void {
  Object.defineProperty(window, name, { value, configurable: true, writable: false })
}

// ---------------------------------------------------------------------------
// Keyboard shortcuts → menu commands. In Electron the native menu turns
// accelerators into `menu:command` pushes; on the web the bridge does it.

export interface Shortcut {
  /** e.g. "mod+s", "mod+shift+s", "mod+p" */
  keys: string
  command: string
  payload?: string
}

function matches(ev: KeyboardEvent, keys: string): boolean {
  const parts = keys.toLowerCase().split('+')
  const key = parts.pop()!
  const mod = parts.includes('mod')
  const isMac = /mac|iphone|ipad/i.test(navigator.platform)
  const modPressed = isMac ? ev.metaKey : ev.ctrlKey
  if (mod !== modPressed) return false
  if (parts.includes('shift') !== ev.shiftKey) return false
  if (parts.includes('alt') !== ev.altKey) return false
  return ev.key.toLowerCase() === key
}

export function installShortcuts(shortcuts: Shortcut[], event = 'menu:command'): void {
  window.addEventListener(
    'keydown',
    (ev) => {
      for (const s of shortcuts) {
        if (!matches(ev, s.keys)) continue
        if (bus.count(event) === 0) return
        ev.preventDefault()
        ev.stopPropagation()
        bus.emit(event, s.command, s.payload)
        return
      }
    },
    { capture: true },
  )
}

// ---------------------------------------------------------------------------
// Close guard: `beforeunload` asks the renderer whether it is dirty through
// the same close-check handshake the Electron main process uses.

export function installCloseGuard(opts: {
  /** emitted to the renderer; its handler answers through `report` */
  checkEvent: string
}): { report: (state: { dirty: boolean; autoSave?: boolean }) => void } {
  let last: { dirty: boolean; autoSave?: boolean } = { dirty: false }
  // the web shell asks a tab iframe the same question before closing it
  ;(window as unknown as { __owCloseState?: () => typeof last }).__owCloseState = () => {
    bus.emit(opts.checkEvent)
    return last
  }
  window.addEventListener('beforeunload', (ev) => {
    bus.emit(opts.checkEvent)
    if (last.dirty && !last.autoSave) {
      ev.preventDefault()
      ev.returnValue = ''
    }
  })
  return {
    report: (state) => {
      last = state
    },
  }
}

// ---------------------------------------------------------------------------
// Downloads and small dialogs

export function downloadBlob(data: BlobPart, name: string, type = 'application/octet-stream'): void {
  const url = URL.createObjectURL(new Blob([data], { type }))
  const a = document.createElement('a')
  a.href = url
  a.download = name
  document.body.appendChild(a)
  a.click()
  a.remove()
  setTimeout(() => URL.revokeObjectURL(url), 60_000)
}

export { promptSaveAs, confirmDialog, toast, pickServerFile } from './dialogs'

// ---------------------------------------------------------------------------
// Document I/O shared by every editor: open results, conflict-aware saves,
// Save As and the silent first save of a new document.

import { confirmDialog as confirm_, promptSaveAs as promptSaveAs_ } from './dialogs'

/** content hash each open document had when it was last read or written */
const knownHash = new Map<string, string>()

export interface OpenInfo {
  path: string
  name: string
  dataUrl: string
  hash: string
}

export async function openInfo(path: string): Promise<OpenInfo> {
  const st = await http.get<FileStat>(`/api/fs/stat?${new URLSearchParams({ path, hash: '1' })}`)
  if (st.isDir) throw new HttpError(400, 'Is a folder')
  if (st.hash) knownHash.set(st.path, st.hash)
  void http.post('/api/fs/recent', { path: st.path }).catch(() => undefined)
  return { path: st.path, name: st.name, dataUrl: files.rawUrl(st.path), hash: st.hash ?? '' }
}

export type SaveOutcome =
  | { ok: true; path: string; hash: string }
  | { ok: false; error?: string; reason?: 'external-modified' | 'canceled' }

const SAVE_STRINGS = {
  en: 'This file was changed elsewhere since you opened it. Overwrite it with your version?',
  ko: '파일을 연 뒤에 다른 곳에서 변경되었습니다. 현재 내용으로 덮어쓰시겠습니까?',
}

/**
 * Write a document. A file changed by someone else since we last saw it is
 * refused: autosaves report `external-modified`, manual saves ask first.
 */
export async function saveDocument(
  path: string,
  data: ArrayBuffer | ArrayBufferView | Blob | string,
  opts: { auto?: boolean; force?: boolean } = {},
): Promise<SaveOutcome> {
  const expectHash = opts.force ? undefined : knownHash.get(path)
  try {
    const st = await files.write(path, data, { expectHash })
    if (st.hash) knownHash.set(st.path, st.hash)
    return { ok: true, path: st.path, hash: st.hash ?? '' }
  } catch (err) {
    if (err instanceof HttpError && err.status === 409 && expectHash) {
      if (opts.auto) return { ok: false, reason: 'external-modified' }
      const lang = (document.documentElement.lang || navigator.language).startsWith('ko') ? 'ko' : 'en'
      if (!(await confirm_(SAVE_STRINGS[lang]))) return { ok: false, reason: 'canceled' }
      return saveDocument(path, data, { force: true })
    }
    return { ok: false, error: err instanceof Error ? err.message : String(err) }
  }
}

/** Save As through the in-page dialog; the address bar follows the new path */
export async function saveDocumentAs(
  defaultName: string,
  ext: string,
  data: ArrayBuffer | ArrayBufferView | Blob | string,
  opts: { defaultDir?: string; updateLaunch?: boolean } = {},
): Promise<SaveOutcome> {
  const path = await promptSaveAs_({ defaultName, ext, defaultDir: opts.defaultDir ?? launchDir() })
  if (!path) return { ok: false, reason: 'canceled' }
  const out = await saveDocument(path, data, { force: true })
  if (out.ok && opts.updateLaunch !== false) setLaunchPath(out.path)
  return out
}

/** first save of a new document: no dialog, a free name in the folder it was created from */
export async function saveNewDocument(
  defaultName: string,
  ext: string,
  data: ArrayBuffer | ArrayBufferView | Blob | string,
): Promise<SaveOutcome> {
  const dotExt = ext.startsWith('.') ? ext : `.${ext}`
  let name = (defaultName || 'Untitled').replace(/[/\\]/g, '_')
  if (!name.toLowerCase().endsWith(dotExt)) name = stripExt(name) + dotExt
  const { path } = await files.uniquePath(launchDir(), name)
  const out = await saveDocument(path, data, { force: true })
  if (out.ok) setLaunchPath(out.path)
  return out
}

/** folder a new document was created from (?dir=), else the parent of the open file */
export function launchDir(): string {
  const dir = new URLSearchParams(location.search).get('dir')
  if (dir) return dir
  const path = new URLSearchParams(location.search).get('path')
  return path ? dirname(path) : '/'
}

export function forgetHash(path: string): void {
  knownHash.delete(path)
}

// ---------------------------------------------------------------------------
// macOS: the upstream ribbons drop their File tab (the native menu bar owns
// File commands) and keep a gap for the window's traffic lights. A browser has
// neither, so the web edition puts a small File menu into that gap.

export interface MacFileMenuItem {
  label: { en: string; ko: string }
  command: string
}

export async function installMacFileMenu(opts: {
  items: MacFileMenuItem[]
  run: (command: string) => void
  /** hide the button while any of these elements exist (slideshow, full screen...) */
  hideWhen?: string
  top?: number
}): Promise<void> {
  if (!/mac/i.test(navigator.platform)) return
  if (document.readyState === 'loading') {
    await new Promise((r) => document.addEventListener('DOMContentLoaded', r, { once: true }))
  }
  const ko = (await getPrefs()).language === 'ko'
  const wrap = document.createElement('div')
  wrap.className = 'ow-mac-file-menu'
  wrap.style.cssText = `position:fixed;left:8px;top:${opts.top ?? 6}px;z-index:1000;font:13px system-ui,sans-serif`
  const btn = document.createElement('button')
  btn.textContent = ko ? '파일' : 'File'
  btn.style.cssText =
    'border:0;background:transparent;color:var(--text);padding:4px 10px;border-radius:5px;cursor:pointer;font:inherit'
  btn.onmouseenter = () => (btn.style.background = 'var(--hover)')
  btn.onmouseleave = () => (btn.style.background = 'transparent')
  const menu = document.createElement('div')
  menu.style.cssText =
    'display:none;position:absolute;top:28px;left:0;min-width:200px;background:var(--surface);color:var(--text);border:1px solid var(--border);border-radius:8px;box-shadow:var(--shadow-menu);padding:4px'
  for (const { label, command } of opts.items) {
    const item = document.createElement('button')
    item.textContent = ko ? label.ko : label.en
    item.style.cssText =
      'display:block;width:100%;text-align:left;border:0;background:transparent;color:inherit;padding:6px 10px;border-radius:5px;cursor:pointer;font:inherit'
    item.onmouseenter = () => (item.style.background = 'var(--hover)')
    item.onmouseleave = () => (item.style.background = 'transparent')
    item.onclick = () => {
      menu.style.display = 'none'
      opts.run(command)
    }
    menu.append(item)
  }
  btn.onclick = (ev) => {
    ev.stopPropagation()
    menu.style.display = menu.style.display === 'none' ? 'block' : 'none'
  }
  document.addEventListener('mousedown', (ev) => {
    if (!wrap.contains(ev.target as Node)) menu.style.display = 'none'
  })
  wrap.append(btn, menu)
  document.body.append(wrap)
  // web-edition chrome, never part of a printed or exported page
  const printCss = document.createElement('style')
  printCss.textContent = '@media print { .ow-mac-file-menu { display: none !important; } }'
  document.head.append(printCss)
  if (opts.hideWhen) {
    const selector = opts.hideWhen
    new MutationObserver(() => {
      wrap.style.display = document.querySelector(selector) ? 'none' : ''
    }).observe(document.body, { childList: true, subtree: true })
  }
}
