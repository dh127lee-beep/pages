/**
 * Docs "Export PDF" / "Export as images" for the web edition.
 *
 * The desktop prints the live editor window (webContents.printToPDF). A web
 * page cannot print itself to bytes, so the PDF is made on the server by the
 * same Docs editor running headless (POST /api/convert → lib/chrome.ts
 * exportViaEditor): identical layout code, but it reads the *saved* file. A
 * document with unsaved edits is therefore saved first — with the user's
 * consent — and the export then reflects exactly what is on screen.
 */

import { basename, bus, bytesToBase64, confirmDialog, files, http, joinPath, launchDir, stripExt, toast } from '../core'

interface CloseState {
  dirty: boolean
  filePath?: string | null
}

const KO = () => (document.documentElement.lang || navigator.language).startsWith('ko')

/** the renderer's own dirty flag and path (answers the close-check handshake synchronously) */
function closeState(): CloseState {
  const probe = (window as unknown as { __owCloseState?: () => CloseState }).__owCloseState
  return probe?.() ?? { dirty: false, filePath: null }
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms))

/** the saved document's path, saving first when there are unsaved edits; null = canceled */
async function savedPathForExport(): Promise<string | null> {
  const state = closeState()
  if (!state.dirty && state.filePath) return state.filePath
  const ok = await confirmDialog(
    KO()
      ? '저장하지 않은 변경 내용이 있습니다. PDF는 저장된 문서로 만들어지므로 먼저 저장합니다.'
      : 'This document has unsaved changes. The PDF is made from the saved document, so it will be saved first.',
    KO() ? '저장 후 내보내기' : 'Save and export',
  )
  if (!ok) return null
  bus.emit('menu:command', 'save')
  const deadline = Date.now() + 120_000
  while (Date.now() < deadline) {
    await sleep(300)
    const now = closeState()
    if (!now.dirty && now.filePath) return now.filePath
  }
  toast(KO() ? '문서를 저장하지 못해 PDF를 내보낼 수 없습니다.' : 'The document could not be saved, so no PDF was exported.')
  return null
}

function errorText(err: unknown): string {
  return err instanceof Error ? err.message : String(err)
}

function downloadFromTree(path: string): void {
  const a = document.createElement('a')
  a.href = files.rawUrl(path, { download: true })
  a.download = basename(path)
  document.body.append(a)
  a.click()
  a.remove()
}

/** PDF next to the document (free name), also downloaded */
async function exportToTree(): Promise<{ ok: boolean; path?: string; error?: string }> {
  const source = await savedPathForExport()
  if (!source) return { ok: false }
  try {
    const st = await http.post<{ path: string }>('/api/convert', { path: source, to: 'pdf' })
    downloadFromTree(st.path)
    return { ok: true, path: st.path }
  } catch (err) {
    return { ok: false, error: errorText(err) }
  }
}

/** export-as-images: the PDF stays in memory for the renderer to rasterize */
const IMAGES_PDF = 'office-web:export-images.pdf'
const pendingPdfs = new Map<string, Uint8Array>()

async function exportToMemory(key: string): Promise<{ ok: boolean; path?: string; error?: string }> {
  const source = await savedPathForExport()
  if (!source) return { ok: false }
  const res = await fetch(`/api/convert/download?${new URLSearchParams({ path: source, to: 'pdf' })}`, {
    credentials: 'same-origin',
  })
  if (!res.ok) {
    const body = (await res.json().catch(() => ({}))) as { error?: string }
    return { ok: false, error: body.error ?? `HTTP ${res.status}` }
  }
  pendingPdfs.set(key, new Uint8Array(await res.arrayBuffer()))
  return { ok: true, path: key }
}

function exportPdfTo(outPath?: string) {
  return outPath === IMAGES_PDF ? exportToMemory(IMAGES_PDF) : exportToTree()
}

export const docsExportApi = {
  exportPdf: (_defaultName: string, _w: number, _h: number, outPath?: string) => exportPdfTo(outPath),
  // mixed paper sizes: the renderer prints group by group, then merges. The
  // server-side editor does that grouping itself, so the parts are placeholders
  // and the merge step performs the one real export.
  printPdfBuffer: async () => ({ ok: true, base64: 'JVBERi0=' }),
  saveMergedPdf: (_defaultName: string, _parts: string[], outPath?: string) => exportPdfTo(outPath),

  pickExportImagesTarget: async () => {
    const source = closeState().filePath
    const stem = stripExt(basename(source || 'document'))
    const { path } = await files.uniquePath(source ? source.slice(0, source.lastIndexOf('/')) || '/' : launchDir(), `${stem} ${KO() ? '이미지' : 'images'}`)
    return { dir: path, pdfPath: IMAGES_PDF }
  },
  takeExportPdf: async (pdfPath: string) => {
    const bytes = pendingPdfs.get(pdfPath)
    pendingPdfs.delete(pdfPath)
    return bytes ? { ok: true, base64: bytesToBase64(bytes) } : { ok: false, error: 'No exported PDF' }
  },
  writeExportImage: async (dir: string, fileName: string, pngBase64: string) => {
    try {
      const path = joinPath(dir, basename(fileName))
      const bytes = Uint8Array.from(atob(pngBase64), (ch) => ch.charCodeAt(0))
      await http.put(`/api/fs/raw?${new URLSearchParams({ path, mkdirs: '1' })}`, bytes)
      return { ok: true, path }
    } catch (err) {
      return { ok: false, error: errorText(err) }
    }
  },
}
