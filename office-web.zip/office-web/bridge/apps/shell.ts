/**
 * Shell (home page + tab strip + settings) — web implementation of
 * apps/shell/src/preload. Interfaces: HomeApi (shared/home-api.ts),
 * TabsApi (shared/tabs-api.ts), IntegrationsApi (shared/integrations-api.ts).
 *
 * The page at "/" is the upstream shell renderer. Document tabs are iframes
 * of the editors (see ../shell/tabs.ts); editors inside them reach back here
 * through window.__owShell (bridge/core.ts shellHost()).
 */

import {
  AI_MEDIA_PROVIDERS,
  AI_PROVIDERS,
  AI_SEARCH_PROVIDERS,
  getProviderAdapter,
} from '@soffice/ai-provider/browser'
import { normalizeAiPanelPrefs } from '@soffice/ui/ai-panel-prefs'
import {
  appForPath,
  basename,
  bus,
  commonApi,
  confirmDialog,
  dirname,
  expose,
  files,
  getPrefs,
  http,
  joinPath,
  me,
  pickLocalFiles,
  projectApi,
  setPrefs,
  toast,
  withFallback,
  type AppId,
  type Prefs,
} from '../core'
import { showMenu, type MenuItem } from '../shell/menu'
import { tabHost } from '../shell/tabs'

const isHelpTab = new URLSearchParams(location.search).get('mode') === 'help'
const ko = () => (document.documentElement.lang || navigator.language).startsWith('ko')
const L = (en: string, kr: string) => (ko() ? kr : en)

const common = commonApi()

// ---------------------------------------------------------------------------
// Web-only chrome adjustments: no macOS traffic lights or vibrancy in a browser

const style = document.createElement('style')
style.textContent = `
.tab-bar-drag-spacer{width:8px!important}
body.vib{background:var(--surface)!important}
`
document.head.appendChild(style)

// ---------------------------------------------------------------------------
// helpers

interface ListEntry {
  path: string
  name: string
  isDir: boolean
}

const SUPPORTED_ACCEPT =
  '.docx,.doc,.dotx,.odt,.rtf,.xlsx,.xlsm,.xls,.csv,.ods,.pptx,.ppt,.odp,.pdf,.md,.markdown,.html,.htm'

/** folder Home last listed — where dropped/browsed files land */
let currentDir = '/'

function folderChanged(...dirs: string[]): void {
  bus.emit('home:folder-changed', [...new Set(dirs)])
}

function openDocumentTab(path: string): void {
  const app = appForPath(path)
  if (!app) {
    window.open(files.rawUrl(path, { download: true }), '_blank')
    return
  }
  tabHost.open(app, { path })
}

async function uploadInto(dir: string, list: File[]): Promise<string[]> {
  const out: string[] = []
  for (const file of list) {
    try {
      const { path } = await files.uniquePath(dir, file.name)
      await files.write(path, file, { overwrite: false })
      out.push(path)
    } catch (err) {
      toast(`${file.name}: ${err instanceof Error ? err.message : String(err)}`)
    }
  }
  if (out.length) {
    folderChanged(dir)
    bus.emit('home:files-uploaded', out)
  }
  return out
}

/** a valid blank one-page A4 PDF, built by hand so no PDF library is needed */
function blankPdf(): Uint8Array {
  const objects = [
    '<< /Type /Catalog /Pages 2 0 R >>',
    '<< /Type /Pages /Kids [3 0 R] /Count 1 >>',
    '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595.28 841.89] /Resources << >> >>',
  ]
  let body = '%PDF-1.4\n'
  const offsets: number[] = []
  objects.forEach((obj, i) => {
    offsets.push(body.length)
    body += `${i + 1} 0 obj\n${obj}\nendobj\n`
  })
  const xref = body.length
  body += `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n`
  for (const off of offsets) body += `${String(off).padStart(10, '0')} 00000 n \n`
  body += `trailer\n<< /Size ${objects.length + 1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF\n`
  return new TextEncoder().encode(body)
}

let flagsCache: Record<string, unknown> | null = null
async function flags(): Promise<Record<string, unknown>> {
  flagsCache ??= await http.get<Record<string, unknown>>('/api/home/flags').catch(() => ({}))
  return flagsCache
}
async function setFlags(patch: Record<string, unknown>): Promise<Record<string, unknown>> {
  flagsCache = await http.put<Record<string, unknown>>('/api/home/flags', patch)
  return flagsCache
}

const DEFAULT_FILE_SEARCH = {
  rerank: false,
  endpoint: 'openrouter',
  keys: { openrouter: '', direct: '', perplexity: '', liquid: '', cloudflare: '', kev: '', rizzo: '', custom: '' },
  customBaseUrl: '',
  customModel: '',
  cloudflareAccountId: '',
  cloudflareModel: '',
}

async function rawPrefs(): Promise<{ prefs: Partial<Prefs>; displayName: string }> {
  const user = await http.get<{ displayName: string; username: string; prefs: Partial<Prefs> }>('/api/me')
  return { prefs: user.prefs ?? {}, displayName: user.displayName || user.username }
}

async function moveOne(
  from: string,
  targetDir: string,
  policy: string,
): Promise<{ to?: string; conflict?: boolean; error?: string }> {
  let to = joinPath(targetDir, basename(from))
  if (to === from) return { to }
  try {
    if (await files.exists(to)) {
      if (policy === 'replace') {
        // fall through with overwrite
      } else if (policy === 'keepBoth') {
        to = (await files.uniquePath(targetDir, basename(from))).path
      } else {
        return { conflict: true }
      }
    }
    const st = await http.post<{ path: string }>('/api/fs/move', { from, to, overwrite: policy === 'replace' })
    tabHost.pathMoved(from, st.path)
    return { to: st.path }
  } catch (err) {
    return { error: err instanceof Error ? err.message : String(err) }
  }
}

// ---------------------------------------------------------------------------
// trash (the desktop app opens the OS trash; here a small in-page list)

async function showTrash(): Promise<void> {
  const list = await http.get<Array<{ id: string; path: string; deletedAt: number }>>('/api/fs/trash')
  const backdrop = document.createElement('div')
  backdrop.className = 'ow-backdrop'
  const box = document.createElement('div')
  box.className = 'ow-dialog'
  box.style.width = 'min(560px, calc(100vw - 32px))'
  const h = document.createElement('h2')
  h.textContent = L('Trash', '휴지통')
  box.append(h)
  const rows = document.createElement('div')
  rows.style.cssText = 'max-height:360px;overflow:auto'
  if (list.length === 0) rows.textContent = L('The trash is empty.', '휴지통이 비어 있습니다.')
  for (const item of list) {
    const row = document.createElement('div')
    row.style.cssText = 'display:flex;align-items:center;gap:10px;padding:6px 0;border-bottom:1px solid var(--border-subtle,#eee)'
    const label = document.createElement('div')
    label.style.cssText = 'flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap'
    label.textContent = item.path
    label.title = `${item.path} — ${new Date(item.deletedAt).toLocaleString()}`
    const restore = document.createElement('button')
    restore.textContent = L('Restore', '복원')
    restore.onclick = async () => {
      const st = await http.post<{ path: string }>('/api/fs/trash/restore', { id: item.id })
      folderChanged(dirname(st.path))
      row.remove()
    }
    row.append(label, restore)
    rows.append(row)
  }
  const actions = document.createElement('div')
  actions.className = 'ow-actions'
  const empty = document.createElement('button')
  empty.textContent = L('Empty trash', '휴지통 비우기')
  empty.disabled = list.length === 0
  empty.onclick = async () => {
    if (!(await confirmDialog(L('Permanently delete everything in the trash?', '휴지통의 모든 항목을 영구 삭제할까요?')))) return
    await http.post('/api/fs/trash/empty')
    backdrop.remove()
  }
  const close = document.createElement('button')
  close.className = 'ow-primary'
  close.textContent = L('Close', '닫기')
  close.onclick = () => backdrop.remove()
  actions.append(empty, close)
  box.append(rows, actions)
  backdrop.append(box)
  backdrop.addEventListener('mousedown', (ev) => {
    if (ev.target === backdrop) backdrop.remove()
  })
  document.body.append(backdrop)
}

// ---------------------------------------------------------------------------
// HomeApi

function newDocTab(kind: AppId, opts?: { dir?: string }): void {
  tabHost.open(kind, { new: '1', dir: opts?.dir ?? currentDir })
}

const homeApi = {
  // lists
  recents: (query?: object) => http.post('/api/home/recents', query ?? {}),
  starred: (query?: object) => http.post('/api/home/starred', query ?? {}),
  starredGroups: () => http.get<string[]>('/api/home/starred-groups'),
  setStarredGroup: async (paths: string[], group: string | null) => {
    await http.post('/api/home/starred-group', { paths, group })
  },
  statPaths: (paths: string[]) => http.post('/api/home/stat-paths', { paths }),
  toggleStar: async (path: string) => {
    const starred = await http.get<Array<{ path: string }>>('/api/fs/starred')
    await http.post('/api/fs/star', { path, starred: !starred.some((s) => s.path === path) })
  },
  unstarPaths: async (paths: string[]) => {
    for (const path of paths) await http.post('/api/fs/star', { path, starred: false })
  },
  removeRecent: async (paths: string[]) => {
    await http.post('/api/home/remove-recent', { paths })
  },

  // search
  searchFiles: (query: object) => http.post('/api/home/search', query),
  rerankSearch: async () => null,
  getFileSearchSettings: async () => ({ ...DEFAULT_FILE_SEARCH, ...((await flags()).fileSearch as object) }),
  setFileSearchSettings: async (patch: object) => {
    const next = { ...DEFAULT_FILE_SEARCH, ...((await flags()).fileSearch as object), ...patch }
    await setFlags({ fileSearch: next })
    return next
  },
  testFileSearchRerank: async () => ({
    ok: false,
    error: L('Search reranking is not available in the web edition', '웹 버전에서는 검색 재정렬을 사용할 수 없습니다'),
  }),

  // knowledge base
  kbList: common.kbList,
  kbSearch: common.kbSearch,
  kbRead: common.kbRead,
  kbCreateDocument: async (request: { title: string; format: 'md' | 'docx'; content: string }) => {
    const title = (request.title || 'Untitled').replace(/[/\\:*?"<>|]/g, '_').slice(0, 120)
    // the web edition writes Markdown; the docs editor converts on Save As
    const { path } = await files.uniquePath('/', `${title}.md`)
    await files.write(path, request.content, { overwrite: false })
    folderChanged('/')
    return { path }
  },

  // AI (shared with every editor)
  aiGetSettings: common.getAiSettings,
  aiStream: common.aiStream,
  aiStreamCancel: common.aiStreamCancel,
  onAiStream: common.onAiStream,
  aiGskStatus: async () => ({ loggedIn: false }),
  getAiSettings: common.getAiSettings,
  setAiSettings: common.setAiSettings,
  onAiSettingsChanged: common.onAiSettingsChanged,
  getAiProviders() {
    return AI_PROVIDERS.filter((meta) => meta.id !== 'codex').map((meta) => {
      let defaultBaseUrl = ''
      if (meta.id !== 'scloud' && !meta.needsBaseUrl && !meta.needsCliPath) {
        try {
          defaultBaseUrl = getProviderAdapter(meta.id).resolveEndpoint({
            apiKey: '',
            model: meta.defaultModel,
          }).baseUrl
        } catch {
          defaultBaseUrl = ''
        }
      }
      return { ...meta, defaultBaseUrl }
    })
  },
  getCodexModels: async () => ({ models: [], defaultModel: '' }),
  getCustomModels: (baseUrl: string, apiKey?: string, api?: string) =>
    http.post('/api/home/custom-models', { baseUrl, apiKey, ...(api ? { api } : {}) }),
  testAiSettings: (settings: unknown) => http.post('/api/home/ai-test', settings),
  getAiMediaProviders: () => AI_MEDIA_PROVIDERS,
  getAiSearchProviders: () => AI_SEARCH_PROVIDERS,
  testAiSearchSettings: (input: unknown) => http.post('/api/home/search-test', input),
  testAiMediaSettings: (input: unknown) => http.post('/api/home/media-test', input),

  // opening and creating
  openHelp: async () => {
    tabHost.open('help', {})
  },
  openPath: async (path: string) => openDocumentTab(path),
  browse: async () => {
    const picked = await pickLocalFiles({ accept: SUPPORTED_ACCEPT, multiple: true })
    const uploaded = await uploadInto(currentDir, picked)
    for (const path of uploaded) openDocumentTab(path)
  },
  newDoc: async (opts?: { dir?: string }) => newDocTab('docs', opts),
  newSheet: async (opts?: { dir?: string }) => newDocTab('sheets', opts),
  newSlide: async (opts?: { dir?: string }) => newDocTab('slides', opts),
  newMarkdown: async (opts?: { dir?: string }) => newDocTab('markdown', opts),
  newHtml: async (opts?: { dir?: string }) => newDocTab('html', opts),
  newPdf: async (opts?: { dir?: string }) => {
    const dir = opts?.dir ?? currentDir
    const { path } = await files.uniquePath(dir, `${L('Untitled', '제목 없음')}.pdf`)
    await files.write(path, blankPdf(), { overwrite: false })
    folderChanged(dir)
    openDocumentTab(path)
  },

  // file operations
  revealPath: async (path: string) => {
    // no file manager to reveal into: hand the file to the browser instead
    window.open(files.rawUrl(path, { download: true }), '_blank')
  },
  renameFile: async (path: string, newName: string) => {
    try {
      const st = await http.post<{ path: string }>('/api/fs/rename', { path, name: newName })
      tabHost.pathMoved(path, st.path)
      folderChanged(dirname(path))
      return { ok: true, path: st.path }
    } catch (err) {
      return { ok: false, error: err instanceof Error ? err.message : String(err) }
    }
  },
  duplicateFile: async (path: string) => {
    const st = await http.post<{ path: string }>('/api/fs/copy', { from: path })
    await http.post('/api/fs/recent', { path: st.path }).catch(() => undefined)
    folderChanged(dirname(path))
  },
  deleteFiles: async (paths: string[]) => {
    await http.post('/api/fs/delete', { paths })
    folderChanged(...paths.map(dirname))
  },
  openTrash: async () => {
    await showTrash()
  },

  // folder tree: one root, the user's own space
  folderRoots: async () => [
    { path: '/', name: L('My files', '내 파일'), usable: true, readable: true, removable: false },
  ],
  addFolderRoot: async () => null,
  dropFolderRoots: async () => [],
  removeFolderRoot: async () => undefined,
  // drops are uploaded by the window-level handler below; Home's own drop paths stay empty
  pathForFile: () => '',
  listFolder: async (dir: string) => {
    currentDir = dir || '/'
    return http.get(`/api/home/folder?${new URLSearchParams({ dir: currentDir })}`)
  },
  createFolder: async (parent: string, name: string) => {
    try {
      const st = await http.post<{ path: string }>('/api/fs/mkdir', { path: joinPath(parent, name.trim()) })
      folderChanged(parent)
      return { ok: true, path: st.path }
    } catch (err) {
      return { ok: false, error: err instanceof Error ? err.message : String(err) }
    }
  },
  renameFolder: async (dir: string, newName: string) => {
    try {
      const st = await http.post<{ path: string }>('/api/fs/rename', { path: dir, name: newName })
      tabHost.pathMoved(dir, st.path)
      folderChanged(dirname(dir), st.path)
      return { ok: true, path: st.path }
    } catch (err) {
      return { ok: false, error: err instanceof Error ? err.message : String(err) }
    }
  },
  movePaths: async (paths: string[], targetDir: string, onConflict: string) => {
    const result = {
      moved: [] as Array<{ from: string; to: string }>,
      conflicts: [] as string[],
      failed: [] as Array<{ path: string; error: string }>,
    }
    for (const from of paths) {
      const r = await moveOne(from, targetDir, onConflict)
      if (r.to) result.moved.push({ from, to: r.to })
      else if (r.conflict) result.conflicts.push(from)
      else result.failed.push({ path: from, error: r.error ?? 'failed' })
    }
    folderChanged(targetDir, ...paths.map(dirname))
    return result
  },
  deleteFolder: async (dir: string) => {
    await http.post('/api/fs/delete', { paths: [dir] })
    folderChanged(dirname(dir))
  },
  onFolderChanged: (h: (dirs: string[]) => void) => bus.on('home:folder-changed', h),

  // preferences
  getLanguage: async () => (await getPrefs()).language,
  setLanguage: async (lang: string) => setPrefs({ language: lang as Prefs['language'] }),
  getTheme: common.getTheme,
  setTheme: async (theme: Prefs['theme']) => setPrefs({ theme }),
  onThemeChanged: common.onThemeChanged,
  getDocumentTheme: common.getDocumentTheme,
  setDocumentTheme: async (theme: Prefs['documentTheme']) => setPrefs({ documentTheme: theme }),
  onDocumentThemeChanged: common.onDocumentThemeChanged,
  getAutoSaveDefault: common.getAutoSaveDefault,
  setAutoSaveDefault: async (on: boolean) => setPrefs({ autoSaveDefault: { on, updatedAt: Date.now() } }),
  getAuthorName: async () => {
    const { prefs, displayName } = await rawPrefs()
    const value = prefs.authorName && prefs.authorName !== displayName ? prefs.authorName : ''
    return { value, fallback: displayName }
  },
  setAuthorName: async (value: string) => {
    const { displayName } = await rawPrefs()
    const v = value.trim().slice(0, 120)
    setPrefs({ authorName: v || displayName })
    return { value: v, fallback: displayName }
  },
  getAiPanelPrefs: async () => normalizeAiPanelPrefs((await getPrefs()).aiPanelPrefs ?? {}),
  setAiPanelPrefs: async (patch: object) =>
    normalizeAiPanelPrefs(await common.setAiPanelPrefs(patch as Record<string, unknown>)),
  getDefaultSaveDir: async () => '/',
  pickDefaultSaveDir: async () => null,
  getDefaultAppStatus: async () => ({ state: 'unsupported', others: [], manualOnly: false }),
  setDefaultApp: async () => ({ state: 'unsupported', others: [], manualOnly: false }),
  getUpdateChannel: async () => 'stable',
  setUpdateChannel: async () => undefined,
  getAnalyticsEnabled: async () => false,
  setAnalyticsEnabled: async () => false,

  // first run
  onboardingSeen: async () => (await flags()).onboardingSeen === true,
  setOnboardingSeen: async () => {
    await setFlags({ onboardingSeen: true })
    return true
  },

  // account: the server's own sign-in, not a hosted AI account
  accountStatus: async () => {
    const user = await me
    return user ? { loggedIn: true, email: user.displayName || user.username } : { loggedIn: false }
  },
  accountLogin: async () => {
    location.href = '/login'
    return true
  },
  onAccountLogin: () => () => undefined,
  openLoginUrl: async () => undefined,
  accountLogout: async () => {
    await http.post('/api/auth/logout').catch(() => undefined)
    location.href = '/login'
  },
  onOpenSettings: (h: (target: { section: string }) => void) => bus.on('home:open-settings', h),

  // about / updates / promos
  getAppVersion: async () => 'Web',
  getUpdateState: async () => null,
  openUpdateDialog: async () => false,
  onUpdateStateChanged: () => () => undefined,
  // the desktop build links to the vendor's community pages; the web edition has none
  openGenTeam: async () => undefined,
  openCreditUsage: async () => undefined,
  openGitHubRepo: async () => undefined,
  githubStars: async () => null,
  starPromptShouldShow: async () => ({ show: false, docOpens: 0 }),
  starPromptAction: async () => undefined,
  cloudProjectsCached: async () => null,
  cloudProjectsSync: async () => null,
  openCloudProject: async () => undefined,

  // local MCP server: a desktop feature
  getMcpStatus: async () => ({
    running: false,
    enabled: false,
    port: 0,
    background: false,
    logging: false,
    url: null,
    capabilities: [],
  }),
  setMcpSettings: async () => ({
    running: false,
    enabled: false,
    port: 0,
    background: false,
    logging: false,
    url: null,
    capabilities: [],
    error: L('Not available in the web edition', '웹 버전에서는 사용할 수 없습니다'),
  }),
  getMcpLogs: async () => [],
  clearMcpLogs: async () => undefined,
  openMcpLogFile: async () => undefined,
}

// ---------------------------------------------------------------------------
// Tabs API

function newMenuItems(): MenuItem[] {
  return [
    { label: L('New document', '새 문서'), onClick: () => newDocTab('docs') },
    { label: L('New spreadsheet', '새 스프레드시트'), onClick: () => newDocTab('sheets') },
    { label: L('New presentation', '새 프레젠테이션'), onClick: () => newDocTab('slides') },
    { label: L('New Markdown', '새 마크다운'), onClick: () => newDocTab('markdown') },
    { label: L('New HTML page', '새 HTML 페이지'), onClick: () => newDocTab('html') },
    { label: L('New PDF', '새 PDF'), onClick: () => void homeApi.newPdf() },
    { separator: true },
    { label: L('Upload and open…', '업로드하여 열기…'), onClick: () => void homeApi.browse() },
  ]
}

function openSettings(section: string): void {
  tabHost.activate('home')
  bus.emit('home:open-settings', { section })
}

const tabsApi = {
  list: async () => tabHost.list(),
  activate: async (id: string) => tabHost.activate(id),
  close: (id: string) => tabHost.close(id),
  reorder: async (id: string, toIndex: number) => tabHost.reorder(id, toIndex),
  onChanged: (h: (tabs: unknown) => void) => tabHost.onChanged(h),
  showMenu: async (x: number, y: number) => {
    showMenu(
      x,
      y,
      tabHost.list().map((t) => ({ label: t.title, checked: t.active, onClick: () => tabHost.activate(t.id) })),
    )
  },
  showNewMenu: async (x: number, y: number) => showMenu(x, y, newMenuItems()),
  showTabMenu: async (id: string, x: number, y: number) => {
    if (id === 'home') return
    const docs = tabHost.docTabs()
    const index = docs.findIndex((t) => t.id === id)
    showMenu(x, y, [
      { label: L('Open in new browser tab', '새 브라우저 탭에서 열기'), onClick: () => tabHost.detach(id) },
      { separator: true },
      { label: L('Close', '닫기'), onClick: () => void tabHost.close(id) },
      {
        label: L('Close other tabs', '다른 탭 닫기'),
        disabled: docs.length < 2,
        onClick: () => void tabHost.closeMany(docs.filter((t) => t.id !== id).map((t) => t.id)),
      },
      {
        label: L('Close tabs to the right', '오른쪽 탭 닫기'),
        disabled: index === docs.length - 1,
        onClick: () => void tabHost.closeMany(docs.slice(index + 1).map((t) => t.id)),
      },
    ])
  },
  showAppMenu: async (x: number, y: number) => {
    showMenu(x, y, [
      ...newMenuItems(),
      { separator: true },
      { label: L('Trash', '휴지통'), onClick: () => void showTrash() },
      { label: L('Settings', '설정'), onClick: () => openSettings('general') },
      { label: L('Help', '도움말'), onClick: () => void homeApi.openHelp() },
      { separator: true },
      { label: L('Sign out', '로그아웃'), onClick: () => void homeApi.accountLogout() },
    ])
  },
  detach: async (id: string) => tabHost.detach(id),
  // tear-off / docking between OS windows has no browser counterpart
  tearOff: async () => false,
  dragTornWindow: () => undefined,
  dockTornWindow: async () => undefined,
  endTornDrag: async () => undefined,
  onDockPreview: () => () => undefined,
  reportDockIndex: () => undefined,
  // our popup menus close on their own outside-press; this one fires for presses inside them too
  notifyChromePressed: () => bus.emit('tabs:chrome-pressed'),
  onChromePressed: (h: () => void) => bus.on('tabs:chrome-pressed', h),
  onStartRename: () => () => undefined,
}

const integrationsApi = {
  // the CLI/agent-skill installer is a desktop feature; Home's probe just never answers
  status: () => new Promise(() => undefined),
  installSkill: async () => ({ status: 'error' }),
  uninstallSkill: async () => ({ status: 'error' }),
  pickSkillDir: async () => null,
  saveSkillZip: async () => null,
  copyText: async (text: string) => {
    await navigator.clipboard.writeText(text)
  },
}

expose('aiOffice', withFallback('aiOffice', homeApi))
expose('aiOfficeTabs', withFallback('aiOfficeTabs', tabsApi))
expose('aiOfficeIntegrations', withFallback('aiOfficeIntegrations', integrationsApi))
expose('projectApi', projectApi())

// ---------------------------------------------------------------------------
// Host side of bridge/core.ts shellHost(): editors in tab iframes open tabs here

if (!isHelpTab) {
  expose('__owShell', {
    openTab: (app: AppId, params: Record<string, string>) => tabHost.open(app, params),
    openSettings,
  })

  // dropping files from the computer anywhere on Home uploads them into the
  // folder being viewed and opens them (the desktop shell's drop-to-open)
  window.addEventListener(
    'dragover',
    (ev) => {
      if (ev.dataTransfer?.types.includes('Files')) {
        ev.preventDefault()
        ev.dataTransfer.dropEffect = 'copy'
      }
    },
    true,
  )
  window.addEventListener(
    'drop',
    (ev) => {
      const list = [...(ev.dataTransfer?.files ?? [])]
      if (list.length === 0) return
      ev.preventDefault()
      const dir = currentDir
      void uploadInto(dir, list).then((paths) => {
        toast(L(`Uploaded ${paths.length} file(s)`, `${paths.length}개 파일을 업로드했습니다`))
        if (paths.length === 1 && appForPath(paths[0]!)) openDocumentTab(paths[0]!)
      })
    },
    true,
  )

  const start = () => {
    // restore first: mounting persists the (still empty) tab list
    tabHost.restore()
    tabHost.mount()
    const q = new URLSearchParams(location.search)
    const open = q.get('open')
    if (open) openDocumentTab(open)
    const settings = q.get('settings')
    if (settings) {
      // Home subscribes after its first render
      const tryOpen = (n: number) => {
        if (bus.count('home:open-settings') > 0) openSettings(settings)
        else if (n > 0) setTimeout(() => tryOpen(n - 1), 100)
      }
      tryOpen(50)
    }
    if (open || settings) history.replaceState(null, '', '/')
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start)
  else start()
}
