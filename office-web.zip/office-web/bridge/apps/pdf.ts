/**
 * PDF — web implementation of apps/pdf/src/preload (window.pdfApi).
 * Interface: PdfApi in upstream/soffice/apps/pdf/src/shared/ipc.ts.
 *
 * Desktop dialogs the main process opened (Save As, "pick a PDF to insert",
 * certificate file) are asked in the page; the work itself runs on the
 * server with the upstream PDF modules.
 */

import {
  basename,
  bus,
  commonApi,
  dirname,
  editorUrl,
  expose,
  files,
  http,
  launch,
  launchDir,
  me,
  openInNewTab,
  pickLocalFiles,
  pickServerFile,
  projectApi,
  promptSaveAs,
  stripExt,
  toast,
  withFallback,
} from '../core'
import { isKo } from './pmh-common'

const API = '/api/apps/pdf'

let current: string | null = launch.path
let pendingConsumed = false
/** documents this tab created through "New PDF" and that still carry their placeholder name */
const untitled = new Set<string>()
let dirty = false

window.addEventListener('beforeunload', (ev) => {
  if (!dirty) return
  ev.preventDefault()
  ev.returnValue = ''
})

function opened(path: string): void {
  current = path
  document.title = basename(path)
  void http.post('/api/fs/recent', { path }).catch(() => undefined)
}

/** after a Save As / redaction copy / signed copy the tab follows the new file */
function reopen(path: string): void {
  location.replace(editorUrl('pdf', { path }))
}

// Home renamed/moved the open file: the editor keeps working on the new path
bus.on('file:moved', (m: { oldPath: string; newPath: string }) => {
  if (current !== m.oldPath) return
  current = m.newPath
  document.title = basename(m.newPath)
  if (untitled.delete(m.oldPath)) untitled.add(m.newPath)
  bus.emit('pdf:file-renamed', m.newPath)
})

let saveAsInFlight = false

async function runSaveAs(defaultName: string): Promise<boolean> {
  if (!current || saveAsInFlight) return false
  const target = await promptSaveAs({ defaultName, ext: '.pdf', defaultDir: dirname(current) })
  if (!target || target === current) return false
  saveAsInFlight = true
  bus.emit('pdf:save-as-flow', true)
  try {
    const ok = await new Promise<boolean>((resolve) => {
      const off = bus.on('pdf:save-as-result', (result: boolean) => {
        off()
        resolve(result)
      })
      if (bus.count('pdf:save-as-request') === 0) {
        off()
        resolve(false)
        return
      }
      bus.emit('pdf:save-as-request', target)
    })
    if (ok) reopen(target)
    return ok
  } finally {
    saveAsInFlight = false
    bus.emit('pdf:save-as-flow', false)
  }
}

window.addEventListener(
  'keydown',
  (ev) => {
    const mod = /mac|iphone|ipad/i.test(navigator.platform) ? ev.metaKey : ev.ctrlKey
    if (!mod || !ev.shiftKey || ev.key.toLowerCase() !== 's') return
    ev.preventDefault()
    ev.stopPropagation()
    if (current) void runSaveAs(basename(current))
  },
  { capture: true },
)

async function openResult(path: string | undefined): Promise<void> {
  if (path) openInNewTab(path, 'pdf')
}

const api = {
  ...commonApi(),
  gskStatus: async () => ({ loggedIn: false }),

  consumePending: async () => {
    if (pendingConsumed) return current
    pendingConsumed = true
    if (launch.path) {
      opened(launch.path)
      return launch.path
    }
    if (launch.isNew) {
      // the PDF editor has no in-memory blank: create the file, like the desktop shell does
      try {
        const { path } = await http.post<{ path: string }>(`${API}/new`, {
          dir: launchDir(),
          name: isKo() ? '제목 없음.pdf' : 'Untitled.pdf',
        })
        untitled.add(path)
        opened(path)
        history.replaceState(history.state, '', editorUrl('pdf', { path }))
        return path
      } catch (err) {
        toast(err instanceof Error ? err.message : String(err))
      }
    }
    return null
  },
  openSourcePath: async (path: string) => openInNewTab(path),
  readFile: (path: string) => files.read(path),

  save: async (request: { path: string; targetPath?: string }) => {
    try {
      const res = await http.post<{ ok: boolean; error?: string }>(`${API}/save`, request)
      if (res.ok && (!request.targetPath || request.targetPath === request.path)) dirty = false
      return res
    } catch (err) {
      return { ok: false, error: err instanceof Error ? err.message : String(err) }
    }
  },
  requestRedactionCopy: async (path: string) => {
    if (path !== current) return false
    const base = stripExt(basename(path))
    return runSaveAs(`${base}-redacted.pdf`)
  },
  autoRename: async (path: string, baseName: string) => {
    if (!untitled.has(path) || typeof baseName !== 'string') return { renamed: false }
    const base = baseName.replace(/[/\\:*?"<>|\u0000-\u001f]/g, '_').trim().slice(0, 80)
    if (!base || `${base}.pdf` === basename(path)) return { renamed: false }
    try {
      const { path: target } = await files.uniquePath(dirname(path), `${base}.pdf`)
      const st = await http.post<{ path: string; name: string }>('/api/fs/rename', {
        path,
        name: basename(target),
      })
      untitled.delete(path)
      current = st.path
      document.title = st.name
      history.replaceState(history.state, '', editorUrl('pdf', { path: st.path }))
      return { renamed: true, path: st.path, name: st.name }
    } catch {
      return { renamed: false }
    }
  },
  isUntitled: async (path: string) => untitled.has(path),

  // ---- pdfium-backed editing ----
  validateTextEdits: (request: { path: string; edits: unknown[] }) =>
    http.post<unknown>(`${API}/validate-text-edits`, request),
  listEditFonts: () => http.get<string[]>(`${API}/edit-fonts`),
  canDrawText: (text: string, font?: string, bold?: boolean, italic?: boolean) =>
    http.post<boolean>(`${API}/can-draw-text`, { text, font, bold, italic }),
  listPageImages: (path: string) => http.post<unknown>(`${API}/page-images`, { path }),
  listStaticFormFills: (path: string) => http.post<unknown>(`${API}/static-form-fills`, { path }),
  // OCR helpers are platform binaries (Vision / Windows OCR) the server does not ship
  ocrPage: async () => null,
  pageImagePng: (request: unknown) => http.post<string | null>(`${API}/page-image-png`, request),
  pagePreviewPng: (request: unknown) => http.post<unknown>(`${API}/page-preview-png`, request),

  // ---- page operations ----
  extractPages: async (request: { path: string; pages: number[]; suggestedName?: string }) => {
    const res = await http.post<{ ok: boolean; savedPath?: string }>(`${API}/extract-pages`, request)
    if (res.ok) await openResult(res.savedPath)
    return res
  },
  insertPdf: async (request: { path: string; afterPageIndex?: number }) => {
    const other = await pickServerFile({ exts: ['.pdf'] })
    if (!other) return { ok: true, canceled: true }
    return http.post<unknown>(`${API}/insert-pdf`, { ...request, otherPath: other })
  },
  insertBlankPage: (request: unknown) => http.post<unknown>(`${API}/insert-blank-page`, request),
  splitPdf: async (request: unknown) => {
    const res = await http.post<{ ok: boolean; savedDir?: string; count?: number }>(`${API}/split-pdf`, request)
    if (res.ok && res.savedDir) toast(isKo() ? `${res.count}개 파일을 "${res.savedDir}"에 저장했습니다` : `Saved ${res.count} files to "${res.savedDir}"`)
    return res
  },
  mergePdf: async (request: { path: string; suggestedName?: string }) => {
    const picked: string[] = []
    for (;;) {
      const p = await pickServerFile({
        exts: ['.pdf'],
        title: isKo()
          ? picked.length
            ? `병합할 PDF 추가 선택 (${picked.length}개 선택됨, 취소하면 병합)`
            : '병합할 PDF 선택'
          : picked.length
            ? `Add another PDF (${picked.length} chosen — cancel to merge)`
            : 'Choose a PDF to merge',
      })
      if (!p) break
      picked.push(p)
    }
    if (picked.length === 0) return { ok: true, canceled: true }
    const res = await http.post<{ ok: boolean; savedPath?: string }>(`${API}/merge-pdf`, { ...request, otherPaths: picked })
    if (res.ok) await openResult(res.savedPath)
    return res
  },
  mergePages: async (request: unknown) => {
    const res = await http.post<{ ok: boolean; savedPath?: string }>(`${API}/merge-pages`, request)
    if (res.ok) await openResult(res.savedPath)
    return res
  },
  replacePages: async (request: { path: string; pages: number[] }) => {
    const other = await pickServerFile({ exts: ['.pdf'] })
    if (!other) return { ok: true, canceled: true }
    return http.post<unknown>(`${API}/replace-pages`, { ...request, otherPath: other })
  },
  setPageSize: (request: unknown) => http.post<unknown>(`${API}/set-page-size`, request),
  splitPages: async (request: unknown) => {
    const res = await http.post<{ ok: boolean; savedPath?: string }>(`${API}/split-pages`, request)
    if (res.ok) await openResult(res.savedPath)
    return res
  },
  cropPages: (request: unknown) => http.post<unknown>(`${API}/crop-pages`, request),
  exportImages: async (request: { images: string[]; pageNumbers: number[]; baseName?: string }) => {
    const res = await http.post<{ ok: boolean; savedDir?: string; count?: number }>(`${API}/export-images`, {
      ...request,
      path: current,
    })
    if (res.ok && res.savedDir) toast(isKo() ? `이미지 ${res.count}장을 "${res.savedDir}"에 저장했습니다` : `Saved ${res.count} images to "${res.savedDir}"`)
    return res
  },
  convertOffice: async (format: string) => {
    if (!current) return
    try {
      const st = await http.post<{ path: string }>('/api/convert', { path: current, to: format })
      toast(isKo() ? `"${basename(st.path)}"(으)로 변환했습니다` : `Converted to "${basename(st.path)}"`)
      openInNewTab(st.path)
    } catch (err) {
      toast(err instanceof Error ? err.message : String(err), 5000)
    }
  },
  createDocument: async (request: { type: string; title: string; content: string }) => {
    const title = (request.title || 'Untitled').replace(/[/\\:*?"<>|]/g, '_').slice(0, 120)
    if (request.type === 'md' || request.type === 'html') {
      const { path } = await files.uniquePath(current ? dirname(current) : launchDir(), `${title}.${request.type}`)
      await files.write(path, request.content, { overwrite: false })
      openInNewTab(path)
      return { ok: true, path }
    }
    return { ok: false, error: `Creating ${request.type} files from the PDF editor is not available in the web edition` }
  },
  generateImage: (op: unknown) => http.post<unknown>('/api/ai/generate-image', op),

  // ---- signatures ----
  listSavedSignatures: () => http.get<unknown>(`${API}/signatures`),
  addSavedSignature: (data: unknown) => http.post<unknown>(`${API}/signatures`, data),
  removeSavedSignature: (id: string) => http.del<unknown>(`${API}/signatures/${encodeURIComponent(id)}`),
  getUsername: async () => (await me)?.displayName ?? '',
  listDigitalSignatures: (path: string) => http.post<unknown>(`${API}/digital-signatures`, { path }),
  pickCertificate: async () => {
    const [file] = await pickLocalFiles({ accept: '.p12,.pfx,application/x-pkcs12' })
    if (!file) return null
    const { certId } = await http.put<{ certId: string }>(`${API}/certificates`, file)
    return { certId, fileName: file.name }
  },
  // there is no OS certificate store in the browser; certificate files only
  listSystemCertificates: async () => ({ certs: [], issues: [] }),
  releaseCertificate: (certId: string) => {
    void http.del(`${API}/certificates/${encodeURIComponent(certId)}`).catch(() => undefined)
  },
  inspectCertificate: (certId: string, password: string) =>
    http.post<unknown>(`${API}/certificates/inspect`, { certId, password }),
  signWithCertificate: async (request: { path: string }) => {
    if (dirty) return { ok: false, error: 'sign-failed', message: 'pdf: save pending edits before signing' }
    const target = await promptSaveAs({
      defaultName: `${stripExt(basename(request.path))}-signed.pdf`,
      ext: '.pdf',
      defaultDir: dirname(request.path),
    })
    if (!target || target === request.path) return { ok: false, cancelled: true }
    const res = await http.post<{ ok: boolean; path?: string }>(`${API}/sign`, { ...request, targetPath: target })
    if (res.ok && res.path) setTimeout(() => reopen(res.path!), 50)
    return res
  },

  // ---- lifecycle ----
  setDirty: (value: boolean) => {
    dirty = value === true
  },
  onCloseSaveRequest: (h: (opts: { flushAll: boolean }) => void) => bus.on('pdf:close-save-request', h),
  sendCloseSaveResult: () => undefined,
  onSaveAsRequest: (h: (target: string) => void) => bus.on('pdf:save-as-request', h),
  sendSaveAsResult: (ok: boolean) => bus.emit('pdf:save-as-result', ok === true),
  onSaveAsFlow: (h: (inFlight: boolean) => void) => bus.on('pdf:save-as-flow', h),
  onPrintRequest: (h: () => void) => bus.on('pdf:print-request', h),
  // the renderer's print stylesheet lays one rasterized page per sheet; the browser dialog prints it
  print: async () => {
    window.print()
    return { ok: true }
  },
  listPrinters: async () => [],
  onFileRenamed: (h: (p: string) => void) => bus.on('pdf:file-renamed', h),
}

expose('pdfApi', withFallback('pdfApi', api))
expose('projectApi', projectApi())
