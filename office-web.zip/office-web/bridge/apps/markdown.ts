/**
 * Markdown — web implementation of apps/markdown/src/preload (window.markdownApi).
 * Interface: MarkdownApi in upstream/soffice/apps/markdown/src/shared/ipc.ts.
 */

import {
  basename,
  bus,
  commonApi,
  downloadBlob,
  expose,
  files,
  http,
  launch,
  openInNewTab,
  pickLocalFiles,
  projectApi,
  stripExt,
  toast,
  withFallback,
} from '../core'
import {
  blobToBase64,
  DocState,
  installExportMenu,
  installSaveShortcuts,
  isKo,
  postForBytes,
  printHtmlString,
  readFileAsBase64,
  storeExport,
} from './pmh-common'

const API = '/api/apps/markdown'
const doc = new DocState('.md')
let pendingConsumed = false

// ---------------------------------------------------------------------------
// md-asset:// — the renderer displays local pictures through the desktop
// app's custom scheme. In the browser the bytes come from /api/fs/raw; every
// script-visible read still sees the md-asset:// form, so the editor's
// bookkeeping (unresolveImageSrc, copy/paste) is unchanged.

const MD = 'md-asset://'
const RAW = '/api/fs/raw?path='

function mdToWeb(url: string): string {
  let path = url.slice(MD.length)
  try {
    path = decodeURIComponent(path)
  } catch {
    // keep as is
  }
  if (!path.startsWith('/')) path = `/${path}`
  return `${RAW}${encodeURIComponent(path)}`
}

function webToMd(url: string): string | null {
  const at = url.indexOf(RAW)
  if (at < 0) return null
  const prefix = url.slice(0, at)
  if (prefix && prefix !== location.origin) return null
  let path: string
  try {
    path = decodeURIComponent(url.slice(at + RAW.length).split('&')[0]!)
  } catch {
    return null
  }
  const enc = (seg: string) => encodeURIComponent(seg).replace(/%3A/gi, ':')
  return `${MD}${path.split('/').map(enc).join('/')}`
}

function installAssetScheme(): void {
  const elProto = Element.prototype
  const origSet = elProto.setAttribute
  const origGet = elProto.getAttribute
  const isSrc = (el: Element, name: string) =>
    name.toLowerCase() === 'src' && (el instanceof HTMLImageElement || el instanceof HTMLSourceElement)
  elProto.setAttribute = function (name: string, value: string) {
    if (typeof value === 'string' && value.startsWith(MD) && isSrc(this, name)) value = mdToWeb(value)
    return origSet.call(this, name, value)
  }
  elProto.getAttribute = function (name: string) {
    const value = origGet.call(this, name)
    if (value && isSrc(this, name)) return webToMd(value) ?? value
    return value
  }
  const desc = Object.getOwnPropertyDescriptor(HTMLImageElement.prototype, 'src')
  if (desc?.get && desc.set) {
    Object.defineProperty(HTMLImageElement.prototype, 'src', {
      configurable: true,
      enumerable: desc.enumerable,
      get() {
        const v = desc.get!.call(this) as string
        return webToMd(v) ?? v
      },
      set(value: string) {
        desc.set!.call(this, typeof value === 'string' && value.startsWith(MD) ? mdToWeb(value) : value)
      },
    })
  }
  // markup parsed from strings (innerHTML) bypasses the setters above
  const fix = (root: ParentNode) => {
    for (const img of root.querySelectorAll?.('img[src^="md-asset:"]') ?? []) {
      origSet.call(img, 'src', mdToWeb(origGet.call(img, 'src')!))
    }
  }
  new MutationObserver((records) => {
    for (const r of records) {
      for (const n of r.addedNodes) {
        if (n instanceof HTMLImageElement && origGet.call(n, 'src')?.startsWith(MD)) {
          origSet.call(n, 'src', mdToWeb(origGet.call(n, 'src')!))
        } else if (n instanceof Element) fix(n)
      }
    }
  }).observe(document.documentElement, { childList: true, subtree: true })
  const origFetch = window.fetch
  window.fetch = (input: RequestInfo | URL, init?: RequestInit) =>
    origFetch(typeof input === 'string' && input.startsWith(MD) ? mdToWeb(input) : input, init)
}

installAssetScheme()

// Home renamed/moved the open file: later saves and the editor's title follow it
bus.on('file:moved', (m: { oldPath: string; newPath: string }) => {
  if (doc.path !== m.oldPath) return
  doc.path = m.newPath
  document.title = basename(m.newPath)
  bus.emit('markdown:file-renamed', m.newPath)
})

// ---------------------------------------------------------------------------

installSaveShortcuts({
  save: () => bus.emit('markdown:save-request', 'save'),
  saveAs: () => bus.emit('markdown:save-request', 'saveAs'),
  print: () => bus.emit('markdown:print-request'),
})

installExportMenu(() =>
  isKo()
    ? [
        { label: 'PDF로 내보내기', run: () => bus.emit('markdown:export-request', 'pdf') },
        { label: 'Word(.docx)로 내보내기', run: () => bus.emit('markdown:export-request', 'docx') },
        { label: 'Docs에서 열기', run: () => bus.emit('markdown:export-request', 'docs') },
        { label: '이미지(PNG)로 내보내기', run: () => bus.emit('markdown:export-request', 'png') },
        { label: '인쇄…', run: () => bus.emit('markdown:print-request') },
      ]
    : [
        { label: 'Export as PDF', run: () => bus.emit('markdown:export-request', 'pdf') },
        { label: 'Export as Word (.docx)', run: () => bus.emit('markdown:export-request', 'docx') },
        { label: 'Open in Docs', run: () => bus.emit('markdown:export-request', 'docs') },
        { label: 'Export as image (PNG)', run: () => bus.emit('markdown:export-request', 'png') },
        { label: 'Print…', run: () => bus.emit('markdown:print-request') },
      ],
)

const THEME_KEY = 'office-web:markdown-theme'
const FRAGMENT_KEY = 'office-web:wiki-fragment:'

async function saveImageBytes(base64: string, ext: string, name?: string): Promise<string | null> {
  if (!doc.path) {
    toast(isKo() ? '이미지를 넣으려면 먼저 문서를 저장하세요.' : 'Save the document first to add pictures.')
    return null
  }
  const { path } = await http.post<{ path: string | null }>(`${API}/save-image`, {
    docPath: doc.path,
    base64,
    ext,
    name,
  })
  return path
}

const api = {
  ...commonApi(),

  consumePending: async () => {
    if (pendingConsumed) return doc.path
    pendingConsumed = true
    if (launch.path) {
      doc.path = launch.path
      document.title = basename(launch.path)
      void http.post('/api/fs/recent', { path: launch.path }).catch(() => undefined)
    }
    return doc.path
  },
  readFile: (path: string) => files.readText(path),

  save: async (request: {
    text: string
    imageSources?: string[]
    mode: 'save' | 'saveAs'
    suggestedName?: string
  }) => {
    try {
      const target = await doc.resolveTarget(request.mode === 'saveAs' ? 'saveAs' : 'save', {
        suggestedName: request.suggestedName,
      })
      if (target === 'canceled') return { ok: true, canceled: true }
      const res = await http.post<
        { ok: true; path: string; imageRewrites?: unknown[]; writtenText?: string } | { ok: false; error: string }
      >(`${API}/save`, {
        text: request.text,
        imageSources: request.imageSources ?? [],
        currentPath: doc.path,
        target,
        mode: request.mode,
      })
      if (res.ok) {
        if (res.path !== doc.path) doc.setPath(res.path)
        doc.dirty = false
      }
      return res
    } catch (err) {
      return { ok: false, error: err instanceof Error ? err.message : String(err) }
    }
  },
  setDirty: (dirty: boolean) => {
    doc.dirty = dirty === true
  },
  onSaveRequest: (h: (mode: string) => void) => bus.on('markdown:save-request', h),
  sendSaveRequestAck: () => undefined,
  onCloseSaveRequest: (h: () => void) => bus.on('markdown:close-save-request', h),
  sendCloseSaveResult: () => undefined,
  onReadTextRequest: () => () => undefined,
  sendReadTextResult: () => undefined,
  onFileRenamed: (h: (p: string) => void) => bus.on('markdown:file-renamed', h),
  consumeHeadlessExport: async () => null,
  headlessExportDone: () => undefined,
  openSourcePath: async (path: string) => openInNewTab(path),

  // ---- wiki links ----
  resolveWikiLinks: (request: { fromPath: string; targets: string[] }) =>
    http.post<unknown>(`${API}/wiki/resolve`, request),
  rememberWikiFragment: async (path: string, fragment: string) => {
    try {
      if (fragment) localStorage.setItem(FRAGMENT_KEY + path, fragment)
      else localStorage.removeItem(FRAGMENT_KEY + path)
    } catch {
      // storage unavailable
    }
  },
  takeWikiFragment: async (path: string) => {
    try {
      const v = localStorage.getItem(FRAGMENT_KEY + path) ?? ''
      localStorage.removeItem(FRAGMENT_KEY + path)
      return v
    } catch {
      return ''
    }
  },
  wikiBacklinks: (path: string) => (path ? http.post<unknown>(`${API}/wiki/backlinks`, { path }) : Promise.resolve([])),
  wikiGraph: () => http.get<unknown>(`${API}/wiki/graph`),

  // ---- pictures ----
  pickImage: async () => {
    if (!doc.path) {
      toast(isKo() ? '이미지를 넣으려면 먼저 문서를 저장하세요.' : 'Save the document first to add pictures.')
      return null
    }
    const [file] = await pickLocalFiles({ accept: 'image/*' })
    if (!file) return null
    const ext = (file.name.split('.').pop() ?? 'png').toLowerCase()
    return saveImageBytes(await readFileAsBase64(file), ext, file.name)
  },
  saveImage: (data: { base64: string; ext: string }) => saveImageBytes(data.base64, data.ext),
  readImage: (src: string) => http.post<unknown>(`${API}/read-image`, { docPath: doc.path, src }),
  saveImageAs: async (src: string) => {
    try {
      const url = src.startsWith('md-asset://') ? mdToWeb(src) : src
      const blob = await (await fetch(url)).blob()
      const name = src.startsWith('data:') ? `image.${blob.type.split('/')[1] ?? 'png'}` : basename(decodeURIComponent(src.split('?')[0]!))
      downloadBlob(blob, name || 'image.png', blob.type)
      return { ok: true }
    } catch (err) {
      return { ok: false, error: String(err) }
    }
  },
  onViewImage: (h: (src: string) => void) => bus.on('markdown:view-image', h),
  getMarkdownTheme: async () => {
    try {
      return localStorage.getItem(THEME_KEY) ?? 'default'
    } catch {
      return 'default'
    }
  },
  setMarkdownTheme: async (theme: string) => {
    try {
      localStorage.setItem(THEME_KEY, theme)
    } catch {
      // storage unavailable
    }
    return theme
  },
  // bring-your-own image hosts would hold third-party credentials in the browser; not offered
  getImageHost: async () => null,
  setImageHost: async () => null,
  uploadImage: async () => ({ ok: false, error: 'Image hosts are not available in the web edition' }),

  // ---- export & print ----
  onExportRequest: (h: (format: string) => void) => bus.on('markdown:export-request', h),
  onPrintRequest: (h: () => void) => bus.on('markdown:print-request', h),
  exportDocx: async (request: { base64: string; suggestedName: string; mode: 'dialog' | 'openInDocs' }) => {
    try {
      const bin = atob(request.base64)
      const bytes = new Uint8Array(bin.length)
      for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i)
      const blob = new Blob([bytes], {
        type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      })
      const name = `${stripExt(request.suggestedName || 'document')}.docx`
      const path = await storeExport(blob, name, {
        besidePath: doc.path,
        download: request.mode !== 'openInDocs',
      })
      if (request.mode === 'openInDocs') openInNewTab(path, 'docs')
      return { ok: true, path }
    } catch (err) {
      return { ok: false, error: err instanceof Error ? err.message : String(err) }
    }
  },
  exportPdf: async (request: { html: string; suggestedName: string }) => {
    try {
      const pdf = await postForBytes(`${API}/print-pdf`, { html: request.html })
      const path = await storeExport(pdf, `${stripExt(request.suggestedName || 'document')}.pdf`, {
        besidePath: doc.path,
        mime: 'application/pdf',
      })
      return { ok: true, path }
    } catch {
      // no headless browser on the server: the print dialog's "Save as PDF" does the same job
      await printHtmlString(request.html)
      return { ok: true, canceled: true }
    }
  },
  prepareImageExport: async (request: { html: string; suggestedName: string }) => {
    try {
      const pdf = await postForBytes(`${API}/print-pdf`, { html: request.html })
      const id = `${stripExt(request.suggestedName || 'document')}`
      imageExports.set(id, { name: id, pages: [] })
      return { ok: true, id, pdfBase64: await blobToBase64(pdf) }
    } catch (err) {
      return { ok: false, error: err instanceof Error ? err.message : String(err) }
    }
  },
  writeExportImage: async (id: string, page: number, pngBase64: string) => {
    const session = imageExports.get(id)
    if (!session) return { ok: false, error: 'unknown export' }
    session.pages[page] = pngBase64
    return { ok: true }
  },
  finishImageExport: async (id: string, success: boolean) => {
    const session = imageExports.get(id)
    imageExports.delete(id)
    if (!session || !success) return { ok: true, canceled: true }
    try {
      const pages = session.pages.filter(Boolean)
      let first = ''
      for (const [i, b64] of pages.entries()) {
        const bin = atob(b64)
        const bytes = new Uint8Array(bin.length)
        for (let j = 0; j < bin.length; j++) bytes[j] = bin.charCodeAt(j)
        const name = pages.length > 1 ? `${session.name}-${i + 1}.png` : `${session.name}.png`
        const p = await storeExport(new Blob([bytes], { type: 'image/png' }), name, {
          besidePath: doc.path,
          mime: 'image/png',
        })
        first ||= p
      }
      return { ok: true, path: first }
    } catch (err) {
      return { ok: false, error: err instanceof Error ? err.message : String(err) }
    }
  },

  aiGenerateImage: (op: unknown) => http.post<unknown>('/api/ai/generate-image', op),
}

const imageExports = new Map<string, { name: string; pages: string[] }>()

expose('markdownApi', withFallback('markdownApi', api))
expose('projectApi', projectApi())
