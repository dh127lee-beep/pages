/**
 * Docs (docx editor) — web implementation of apps/docs/src/preload.
 * Interface: DesktopApi in upstream/soffice/apps/docs/src/shared/ipc.ts.
 */

import {
  basename,
  bus,
  bytesToBase64,
  commonApi,
  confirmDialog,
  downloadBlob,
  expose,
  files,
  installCloseGuard,
  installMacFileMenu,
  installShortcuts,
  launch,
  launchDir,
  openInNewTab,
  pickLocalFiles,
  pickServerFile,
  projectApi,
  shellHost,
  stripExt,
  toast,
  withFallback,
} from '../core'
import {
  decryptDocPath,
  discardDocPasswordIntents,
  docPasswordIntentRevision,
  openDocPath,
  saveDocAs,
  saveDocNew,
  saveDocPath,
  saveDocTo,
  setDocPassword,
} from './docs-protect'
import { docsExportApi } from './docs-export'

const DOCX_EXTS = ['.docx', '.dotx', '.docm']

let pendingConsumed = false
let newConsumed = false

async function openPath(path: string) {
  try {
    return await openDocPath(path)
  } catch (err) {
    toast(err instanceof Error ? err.message : String(err))
    return null
  }
}

// Home renamed or moved this document: the editor follows it (save path, title)
bus.on('file:moved', (paths: { oldPath: string; newPath: string }) => bus.emit('docs:renamed', paths))

const closeGuard = installCloseGuard({ checkEvent: 'docs:close-check' })

installShortcuts([
  { keys: 'mod+s', command: 'save' },
  { keys: 'mod+shift+s', command: 'save-as' },
  { keys: 'mod+o', command: 'open' },
  { keys: 'mod+p', command: 'print' },
  { keys: 'mod+f', command: 'find' },
  { keys: 'mod+h', command: 'replace' },
  { keys: 'mod+=', command: 'zoom-in' },
  { keys: 'mod++', command: 'zoom-in' },
  { keys: 'mod+-', command: 'zoom-out' },
  { keys: 'mod+0', command: 'zoom-100' },
])

void installMacFileMenu({
  items: [
    { label: { en: 'New', ko: '새로 만들기' }, command: 'new' },
    { label: { en: 'Open…', ko: '열기…' }, command: 'open' },
    { label: { en: 'Save', ko: '저장' }, command: 'save' },
    { label: { en: 'Save As…', ko: '다른 이름으로 저장…' }, command: 'save-as' },
    { label: { en: 'Export PDF…', ko: 'PDF로 내보내기…' }, command: 'export-pdf' },
    { label: { en: 'Export HTML…', ko: 'HTML로 내보내기…' }, command: 'export-html' },
    { label: { en: 'Export Markdown…', ko: 'Markdown으로 내보내기…' }, command: 'export-markdown' },
    { label: { en: 'Print…', ko: '인쇄…' }, command: 'print' },
    { label: { en: 'Page Setup…', ko: '페이지 설정…' }, command: 'page-setup' },
  ],
  run: (command) => bus.emit('menu:command', command),
  top: 10,
})

/** AI create_document hands the new tab its content through localStorage */
const AI_DOC_KEY = 'office-web:ai-doc:'

const api = {
  ...commonApi(),

  // ---- open ----
  openDocx: async () => {
    const path = await pickServerFile({ exts: DOCX_EXTS })
    return path ? openPath(path) : null
  },
  openDocxPath: (path: string) => openPath(path),
  // like the desktop's close check: only a document with unsaved changes asks first
  confirmDocumentReplace: async () => {
    const state = (window as unknown as { __owCloseState?: () => { dirty: boolean } }).__owCloseState
    state?.()
    await new Promise((r) => setTimeout(r, 30))
    if (!state?.().dirty) return true
    return confirmDialog(
      document.documentElement.lang.startsWith('ko')
        ? '현재 문서를 닫고 다른 문서를 여시겠습니까? 저장하지 않은 변경 내용은 사라집니다.'
        : 'Replace the current document? Unsaved changes will be lost.',
    )
  },
  consumePendingOpenDocx: async () => {
    if (pendingConsumed || !launch.path) return null
    pendingConsumed = true
    return openPath(launch.path)
  },
  consumeNewBlankDoc: async () => {
    if (newConsumed) return false
    newConsumed = true
    return launch.isNew && !launch.params.get('aiDoc')
  },
  consumeAiDocContent: async () => {
    const id = launch.params.get('aiDoc')
    if (!id) return null
    try {
      const raw = localStorage.getItem(AI_DOC_KEY + id)
      localStorage.removeItem(AI_DOC_KEY + id)
      return raw ? (JSON.parse(raw) as { title: string; html: string }) : null
    } catch {
      return null
    }
  },
  consumeHeadlessExport: async () => null,
  headlessExportDone: () => undefined,
  onOpenDocx: (h: (r: unknown) => void) => bus.on('docs:opened', h),
  onRenamedDocx: (h: (p: unknown) => void) => bus.on('docs:renamed', h),
  openDocxDecrypt: (path: string, password: string) => decryptDocPath(path, password),
  convertAltChunkHtml: async () => null,

  // Review › Protect: the server keeps the password and encrypts on the next save
  setDocPassword,
  docPasswordIntentRevision,
  discardDocPasswordIntents,

  // ---- save: through the server, which re-encrypts protected documents ----
  saveDocx: (path: string, data: ArrayBuffer, auto?: boolean) => saveDocPath(path, data, auto === true),
  saveDocxAs: (defaultName: string, data: ArrayBuffer, sourcePath?: string | null) =>
    saveDocAs(defaultName, data, sourcePath),
  saveDocxNew: (defaultName: string, data: ArrayBuffer) => saveDocNew(defaultName, data),
  saveDocxTo: (path: string, data: ArrayBuffer, overwrite: boolean) => saveDocTo(path, data, overwrite === true),
  writeRecoveryCopy: async () => ({ ok: true }),

  createDocument: async (request: { type: string; title: string; content: string }) => {
    const title = (request.title || 'Untitled').replace(/[/\\:*?"<>|]/g, '_').slice(0, 120)
    if (request.type === 'md' || request.type === 'html') {
      const { path } = await files.uniquePath(launchDir(), `${title}.${request.type}`)
      await files.write(path, request.content, { overwrite: false })
      openInNewTab(path)
      return { ok: true, path }
    }
    if (request.type === 'docx') {
      const id = Math.random().toString(36).slice(2)
      try {
        localStorage.setItem(AI_DOC_KEY + id, JSON.stringify({ title, html: request.content }))
      } catch {
        return { ok: false, error: 'Browser storage is unavailable' }
      }
      const params = { new: '1', aiDoc: id, dir: launchDir() }
      const host = shellHost()
      if (host) host.openTab('docs', params)
      else window.open(`/app/docs/?${new URLSearchParams(params)}`, '_blank')
      return { ok: true }
    }
    return { ok: false, error: `Creating ${request.type} files is not available in the web edition` }
  },

  // ---- pictures ----
  pickImage: async () => {
    const [file] = await pickLocalFiles({ accept: 'image/png,image/jpeg,image/gif' })
    if (!file) return null
    const mime = file.type === 'image/png' || file.type === 'image/gif' ? file.type : 'image/jpeg'
    return { base64: bytesToBase64(new Uint8Array(await file.arrayBuffer())), mime, name: file.name }
  },
  saveImageAs: async (src: string) => {
    try {
      const blob = await (await fetch(src)).blob()
      const extension = blob.type.split('/')[1]?.replace('jpeg', 'jpg') || 'png'
      downloadBlob(blob, `image.${extension}`, blob.type)
      return { ok: true }
    } catch (err) {
      return { ok: false, error: String(err) }
    }
  },
  copyImageToClipboard: async (dataUrl: string) => {
    try {
      const blob = await (await fetch(dataUrl)).blob()
      const png = blob.type === 'image/png' ? blob : await toPng(blob)
      await navigator.clipboard.write([new ClipboardItem({ 'image/png': png })])
      return true
    } catch {
      return false
    }
  },
  onViewImage: (h: (src: string) => void) => bus.on('docs:view-image', h),
  fontMetrics: async () => null,

  // ---- print & export ----
  print: async () => {
    window.print()
    return { ok: true }
  },
  listPrinters: async () => [],
  // PDF / image export: made server-side by the same editor (./docs-export.ts)
  ...docsExportApi,
  exportHtml: async (defaultName: string, html: string) => {
    const name = `${stripExt(basename(defaultName || 'document'))}.html`
    downloadBlob(html, name, 'text/html;charset=utf-8')
    return { ok: true, path: name }
  },
  exportMarkdown: async (defaultName: string, markdown: string, images: Array<{ name: string; src: string }>) => {
    // pictures travel inline so the download is a single self-contained file
    let text = markdown
    let dropped = 0
    for (const img of images ?? []) {
      const src = img.src.startsWith('data:') ? img.src : await toDataUrl(img.src).catch(() => null)
      if (!src) {
        dropped++
        continue
      }
      text = text.split(`__soffice_media__/${img.name}`).join(src)
    }
    const name = `${stripExt(basename(defaultName || 'document'))}.md`
    downloadBlob(text, name, 'text/markdown;charset=utf-8')
    return { ok: true, path: name, imagesDropped: dropped }
  },

  // ---- spellcheck & context menu: the browser's own checker and menu are used ----
  respellKick: async () => undefined,
  spellDiag: () => undefined,
  armContextMenu: () => undefined,
  claimContextMenu: () => undefined,
  onContextMenuRequest: () => () => undefined,
  spellAddWord: async () => false,
  spellIgnoreWord: async () => false,
  spellReplace: async () => undefined,
  spellLanguages: async () => ({ active: [], available: [] }),
  spellSetLanguages: async () => ({ active: [], available: [] }),

  // ---- tabs, menus, close guard ----
  openNewTab: async (openPath?: string | null) => openInNewTab(openPath ?? null, 'docs'),
  listDocsTabs: async () => [],
  focusDocsTab: async () => undefined,
  onMenuCommand: (h: (command: string, payload?: string) => void) => bus.on('menu:command', h),
  onCloseCheck: (h: () => void) => bus.on('docs:close-check', h),
  reportCloseCheck: (state: { dirty: boolean; autoSave: boolean }) => closeGuard.report(state),
  onCloseSaveRequest: (h: () => void) => bus.on('docs:close-save-request', h),
  reportCloseSaveResult: () => undefined,
  reportViewMenuState: () => undefined,
  onTeardown: () => () => undefined,

  // ---- integrations without a web counterpart ----
  onZoteroRequest: () => () => undefined,
  zoteroCommand: async () => ({ ok: false, errorCode: 'unsupported-command', error: 'Zotero is not available in the web edition' }),
  respondToZotero: () => undefined,
  onMcpCommand: () => () => undefined,
  reportMcpResult: () => undefined,
  signalMcpReady: () => undefined,
}

async function toDataUrl(src: string): Promise<string> {
  const blob = await (await fetch(src)).blob()
  return `data:${blob.type || 'image/png'};base64,${bytesToBase64(new Uint8Array(await blob.arrayBuffer()))}`
}

async function toPng(blob: Blob): Promise<Blob> {
  const bitmap = await createImageBitmap(blob)
  const canvas = document.createElement('canvas')
  canvas.width = bitmap.width
  canvas.height = bitmap.height
  canvas.getContext('2d')!.drawImage(bitmap, 0, 0)
  return new Promise((resolve, reject) =>
    canvas.toBlob((b) => (b ? resolve(b) : reject(new Error('encode failed'))), 'image/png'),
  )
}

expose('desktop', withFallback('desktop', api))
expose('projectApi', projectApi())
