/**
 * HTML — web implementation of apps/html/src/preload (window.htmlApi).
 * Interface: HtmlApi in upstream/soffice/apps/html/src/shared/ipc.ts.
 *
 * The live preview runs in the renderer's sandboxed iframe, served by the
 * server under an unguessable per-view token (see server/src/apps/html.ts).
 */

import {
  basename,
  bus,
  commonApi,
  expose,
  files,
  http,
  launch,
  openInNewTab,
  pickLocalFiles,
  projectApi,
  stripExt,
  toast,
  withFallback,
} from '../core'
import {
  DocState,
  installExportMenu,
  installSaveShortcuts,
  isKo,
  postForBytes,
  printHtmlString,
  readFileAsBase64,
  storeExport,
} from './pmh-common'

const API = '/api/apps/html'
const doc = new DocState('.html')
let pendingConsumed = false

// ---------------------------------------------------------------------------
// preview buffer: pushes are serialized; the frame only navigates once the
// text it should show has reached the server

let token = ''
let previewUrl = ''
let chain: Promise<unknown> = Promise.resolve()
let inflight = 0

function pushPreview(body: { text?: string; docPath?: string | null }): Promise<unknown> {
  inflight++
  chain = chain
    .then(() => http.post<{ token: string; url: string }>(`${API}/preview`, { token, ...body }))
    .then((res) => {
      token = res.token
      previewUrl = res.url
    })
    .catch((err) => console.warn('[html] preview update failed', err))
    .finally(() => {
      inflight--
    })
  return chain
}

const ready = pushPreview({ docPath: launch.path ?? null })

function installFrameGate(): void {
  const origSet = Element.prototype.setAttribute
  const latest = new WeakMap<Element, string>()
  const isPreview = (el: Element, name: string, value: unknown) =>
    el instanceof HTMLIFrameElement && name.toLowerCase() === 'src' && typeof value === 'string' && value.startsWith('/pub/html/p/')
  Element.prototype.setAttribute = function (name: string, value: string) {
    if (isPreview(this, name, value) && inflight > 0) {
      latest.set(this, value)
      void chain.then(() => {
        if (latest.get(this) === value) origSet.call(this, name, value)
      })
      return
    }
    return origSet.call(this, name, value)
  }
  const desc = Object.getOwnPropertyDescriptor(HTMLIFrameElement.prototype, 'src')
  if (desc?.set && desc.get) {
    Object.defineProperty(HTMLIFrameElement.prototype, 'src', {
      configurable: true,
      enumerable: desc.enumerable,
      get() {
        return desc.get!.call(this)
      },
      set(value: string) {
        if (isPreview(this, 'src', value)) (this as Element).setAttribute('src', value)
        else desc.set!.call(this, value)
      },
    })
  }
}

installFrameGate()

// Home renamed/moved the open file: later saves, the preview's asset base and the title follow it
bus.on('file:moved', (m: { oldPath: string; newPath: string }) => {
  if (doc.path !== m.oldPath) return
  doc.path = m.newPath
  document.title = basename(m.newPath)
  void pushPreview({ docPath: m.newPath })
  bus.emit('html:file-renamed', m.newPath)
})

installSaveShortcuts({
  save: () => bus.emit('html:save-request', 'save'),
  saveAs: () => bus.emit('html:save-request', 'saveAs'),
  print: () => bus.emit('html:print-request'),
})

installExportMenu(() =>
  isKo()
    ? [
        { label: 'PDF로 내보내기', run: () => bus.emit('html:export-request', 'pdf') },
        { label: 'Word(.docx)로 내보내기', run: () => bus.emit('html:export-request', 'docx') },
        { label: '단일 HTML 파일로 내보내기', run: () => bus.emit('html:export-request', 'html') },
        { label: '인쇄…', run: () => bus.emit('html:print-request') },
      ]
    : [
        { label: 'Export as PDF', run: () => bus.emit('html:export-request', 'pdf') },
        { label: 'Export as Word (.docx)', run: () => bus.emit('html:export-request', 'docx') },
        { label: 'Export as single-file HTML', run: () => bus.emit('html:export-request', 'html') },
        { label: 'Print…', run: () => bus.emit('html:print-request') },
      ],
)

async function saveImageBytes(base64: string, ext: string, name?: string): Promise<string | null> {
  if (!doc.path) {
    toast(isKo() ? '이미지를 넣으려면 먼저 문서를 저장하세요.' : 'Save the document first to add pictures.')
    return null
  }
  const { path } = await http.post<{ path: string | null }>(`${API}/save-image`, {
    docPath: doc.path,
    base64,
    ext,
    name,
  })
  return path
}

function assetBase(): string | null {
  return token && doc.path ? `${location.origin}/pub/html/p/${token}/a/` : null
}

const api = {
  ...commonApi(),

  consumePending: async () => {
    if (pendingConsumed) return doc.path
    pendingConsumed = true
    if (launch.path) {
      doc.path = launch.path
      document.title = basename(launch.path)
      void http.post('/api/fs/recent', { path: launch.path }).catch(() => undefined)
    }
    return doc.path
  },
  readFile: (path: string) => files.readText(path),
  consumeHeadlessExport: async () => null,
  headlessExportDone: () => undefined,
  openSourcePath: async (path: string) => openInNewTab(path),

  // ---- preview ----
  updatePreview: (text: string) => {
    if (typeof text === 'string') void pushPreview({ text })
  },
  getPreviewInfo: async () => {
    await ready
    return { url: previewUrl }
  },
  setPresentFullScreen: async (on: boolean) => {
    try {
      if (on && !document.fullscreenElement) await document.documentElement.requestFullscreen()
      if (!on && document.fullscreenElement) await document.exitFullscreen()
    } catch {
      // fullscreen refused (no user gesture)
    }
  },
  presentInNewTab: async () => {
    await chain
    return Boolean(previewUrl && window.open(previewUrl, '_blank'))
  },

  // ---- save ----
  save: async (request: {
    text: string
    imageSources?: string[]
    mode: 'save' | 'saveAs'
    suggestedName?: string
    defaultName?: string
  }) => {
    try {
      const target = await doc.resolveTarget(request.mode === 'saveAs' ? 'saveAs' : 'save', {
        suggestedName: request.suggestedName,
        defaultName: request.defaultName,
      })
      if (target === 'canceled') return { ok: true, canceled: true }
      const res = await http.post<
        { ok: true; path: string; imageRewrites?: unknown[] } | { ok: false; error: string }
      >(`${API}/save`, {
        text: request.text,
        imageSources: request.imageSources ?? [],
        currentPath: doc.path,
        target,
        mode: request.mode,
      })
      if (res.ok) {
        if (res.path !== doc.path) {
          doc.setPath(res.path)
          void pushPreview({ docPath: res.path })
        }
        doc.dirty = false
      }
      return res
    } catch (err) {
      return { ok: false, error: err instanceof Error ? err.message : String(err) }
    }
  },
  setDirty: (dirty: boolean) => {
    doc.dirty = dirty === true
  },
  onSaveRequest: (h: (mode: string) => void) => bus.on('html:save-request', h),
  sendSaveRequestAck: () => undefined,
  onReadTextRequest: () => () => undefined,
  sendReadTextResult: () => undefined,
  onCloseSaveRequest: (h: () => void) => bus.on('html:close-save-request', h),
  sendCloseSaveResult: () => undefined,
  onFileRenamed: (h: (p: string) => void) => bus.on('html:file-renamed', h),
  setProvisionalTitle: (title: string) => {
    if (!doc.path && typeof title === 'string' && title.trim()) document.title = title.trim().slice(0, 80)
  },

  // ---- pictures ----
  pickImage: async () => {
    if (!doc.path) {
      toast(isKo() ? '이미지를 넣으려면 먼저 문서를 저장하세요.' : 'Save the document first to add pictures.')
      return null
    }
    const [file] = await pickLocalFiles({ accept: 'image/png,image/jpeg,image/gif' })
    if (!file) return null
    const ext = (file.name.split('.').pop() ?? 'png').toLowerCase()
    return saveImageBytes(await readFileAsBase64(file), ext, file.name)
  },
  saveImage: (data: { base64: string; ext: string }) => saveImageBytes(data.base64, data.ext),
  readImage: (src: string) => http.post<unknown>(`${API}/read-image`, { docPath: doc.path, src }),

  // ---- export & print ----
  onExportRequest: (h: (format: string) => void) => bus.on('html:export-request', h),
  onPrintRequest: (h: () => void) => bus.on('html:print-request', h),
  exportDocx: async (request: { html: string; suggestedName: string }) => {
    try {
      const docx = await postForBytes(`${API}/export-docx`, { html: request.html, docPath: doc.path })
      const path = await storeExport(docx, `${stripExt(request.suggestedName || 'page')}.docx`, {
        besidePath: doc.path,
        download: false,
      })
      openInNewTab(path, 'docs')
      return { ok: true, path }
    } catch (err) {
      return { ok: false, error: err instanceof Error ? err.message : String(err) }
    }
  },
  exportPdf: async (request: { html: string; suggestedName: string }) => {
    try {
      const pdf = await postForBytes(`${API}/export-pdf`, { html: request.html, docPath: doc.path })
      const path = await storeExport(pdf, `${stripExt(request.suggestedName || 'page')}.pdf`, {
        besidePath: doc.path,
        mime: 'application/pdf',
      })
      return { ok: true, path }
    } catch {
      await chain
      await printHtmlString(request.html, assetBase())
      return { ok: true, canceled: true }
    }
  },
  exportHtml: async (request: { html: string; suggestedName: string }) => {
    try {
      const res = await http.post<{ html: string; skipped: string[] }>(`${API}/export-html`, {
        html: request.html,
        docPath: doc.path,
      })
      const path = await storeExport(res.html, `${stripExt(request.suggestedName || 'page')}-single.html`, {
        besidePath: doc.path,
        mime: 'text/html;charset=utf-8',
      })
      return res.skipped.length ? { ok: true, path, skipped: res.skipped } : { ok: true, path }
    } catch (err) {
      return { ok: false, error: err instanceof Error ? err.message : String(err) }
    }
  },
  printHtml: async (request: { html: string }) => {
    await chain
    await printHtmlString(request.html, assetBase())
    return { ok: true }
  },

  aiGenerateImage: (op: unknown) => http.post<unknown>('/api/ai/generate-image', op),
}

expose('htmlApi', withFallback('htmlApi', api))
expose('projectApi', projectApi())
