/**
 * Slides (pptx editor) — web implementation of apps/slides/src/preload.
 *
 * The desktop main process (deck model, edits, save) runs unmodified on the
 * server (server/src/apps/slides.ts), so `window.slidesApi` is a thin
 * IPC-over-HTTP client: invokes become ordered POSTs, main→renderer pushes
 * arrive over a per-tab event stream, and native dialogs the main process
 * opens are shown here as in-page dialogs.
 */

import { buildPrintDocumentHtml } from '../../upstream/soffice/apps/slides/src/shared/print-html'
import {
  basename,
  bus,
  commonApi,
  confirmDialog,
  dirname,
  expose,
  files,
  getPrefs,
  http,
  HttpError,
  installCloseGuard,
  installShortcuts,
  launch,
  pickLocalFiles,
  pickServerFile,
  projectApi,
  promptSaveAs,
  redirectToLogin,
  setLaunchPath,
  toast,
  withFallback,
} from '../core'

const BASE = '/api/apps/slides'

/** presenter view's audience popup: bound to the presenter's server-side deck by its channel id */
const AUDIENCE = launch.params.get('mode') === 'audience'

// ---- wire format (mirrors server/src/apps/slides/wire.ts) ----------------------------

function b64encode(bytes: Uint8Array): string {
  let bin = ''
  for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode(...bytes.subarray(i, i + 0x8000))
  return btoa(bin)
}

function encode(value: unknown): unknown {
  if (value === null || typeof value !== 'object') return value
  if (value instanceof ArrayBuffer) return { __ow_bin: b64encode(new Uint8Array(value)), t: 'ab' }
  if (ArrayBuffer.isView(value)) {
    return { __ow_bin: b64encode(new Uint8Array(value.buffer, value.byteOffset, value.byteLength)), t: 'u8' }
  }
  if (Array.isArray(value)) return value.map(encode)
  if (value instanceof Map) return encode(Object.fromEntries(value))
  if (value instanceof Set) return encode([...value])
  if (value instanceof Date) return value.toISOString()
  const out: Record<string, unknown> = {}
  for (const [k, v] of Object.entries(value)) {
    if (typeof v !== 'function' && v !== undefined) out[k] = encode(v)
  }
  return out
}

function decode(value: unknown): unknown {
  if (value === null || typeof value !== 'object') return value
  if (Array.isArray(value)) return value.map(decode)
  const rec = value as Record<string, unknown>
  if (typeof rec.__ow_bin === 'string') {
    const bin = atob(rec.__ow_bin)
    const out = new Uint8Array(bin.length)
    for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i)
    return rec.t === 'ab' ? out.buffer : out
  }
  const out: Record<string, unknown> = {}
  for (const [k, v] of Object.entries(rec)) out[k] = decode(v)
  return out
}

// ---- IPC client --------------------------------------------------------------------

let wcId: number | null = AUDIENCE && /^\d+$/.test(launch.params.get('wc') ?? '') ? Number(launch.params.get('wc')) : null
let seq = 0
let resolveReady: () => void
const ready = new Promise<void>((r) => (resolveReady = r))

function connect(): void {
  const url = wcId === null ? `${BASE}/events` : `${BASE}/events?wc=${wcId}`
  const es = new EventSource(url)
  es.addEventListener('hello', (ev) => {
    const { wc } = JSON.parse((ev as MessageEvent).data) as { wc: number }
    if (AUDIENCE && wc !== wcId) {
      // the show this window belonged to is over
      window.close()
      return
    }
    if (wcId !== null && wc !== wcId) {
      // the server lost this tab (restart or long disconnect): its deck is gone
      toast('The editing session expired on the server — reloading')
      setTimeout(() => location.reload(), 1500)
    }
    wcId = wc
    resolveReady()
  })
  es.onmessage = (ev) => {
    const msg = decode(JSON.parse(ev.data)) as
      | { type: 'ipc'; channel: string; args: unknown[] }
      | { type: 'dialog'; id: number; kind: string; options: Record<string, unknown> }
    if (msg.type === 'ipc') bus.emit(`ipc:${msg.channel}`, ...msg.args)
    else if (msg.type === 'dialog') void answerDialog(msg.id, msg.kind, msg.options)
  }
  es.onerror = () => {
    es.close()
    void fetch('/api/me', { credentials: 'same-origin' }).then((r) => {
      if (r.status === 401) redirectToLogin()
      else setTimeout(connect, 1500)
    }, () => setTimeout(connect, 3000))
  }
}
connect()

async function post(kind: 'invoke' | 'send', channel: string, args: unknown[]): Promise<unknown> {
  await ready
  const body = { wc: wcId, seq: seq++, kind, channel, args: args.map(encode), lang: document.documentElement.lang || navigator.language }
  const res = await fetch(`${BASE}/ipc`, {
    method: 'POST',
    credentials: 'same-origin',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
  })
  if (res.status === 401) {
    redirectToLogin()
    throw new HttpError(401, 'Not signed in')
  }
  const data = (await res.json().catch(() => ({}))) as { result?: unknown; error?: string }
  if (!res.ok) throw new Error(data.error ?? `HTTP ${res.status}`)
  return decode(data.result)
}

const invoke = (channel: string, ...args: unknown[]) => post('invoke', channel, args)
const send = (channel: string, ...args: unknown[]) => {
  void post('send', channel, args).catch((err) => console.warn(`[slides] ${channel}`, err))
}
const on = (channel: string, handler: (...args: never[]) => void) => bus.on(`ipc:${channel}`, handler)

// Home renamed/moved this file: the server-side session follows (it answers with slides:renamed)
bus.on('file:moved', (p: { oldPath: string; newPath: string }) => {
  void ready.then(() => http.post(`${BASE}/renamed`, { wc: wcId, ...p }).catch(() => undefined))
})

window.addEventListener('pagehide', () => {
  if (wcId !== null) navigator.sendBeacon?.(`${BASE}/close`, new Blob([JSON.stringify({ wc: wcId })], { type: 'application/json' }))
})

// ---- native dialogs opened by the main process ----------------------------------------

interface DialogFilter {
  name?: string
  extensions?: string[]
}

const DOC_EXTS = new Set(['pptx', 'ppt', 'potx', 'pptm', 'odp', 'pdf'])

async function answerDialog(id: number, kind: string, options: Record<string, unknown>): Promise<void> {
  let result: unknown = null
  try {
    if (kind === 'open') result = await openDialog(options)
    else if (kind === 'save') result = await saveDialog(options)
    else if (kind === 'message') result = await messageBox(options)
    else if (kind === 'error') toast(`${options.title ?? ''} ${options.content ?? ''}`.trim(), 5000)
  } catch (err) {
    console.warn('[slides] dialog failed', err)
  }
  await http.post(`${BASE}/dialog-reply`, { wc: wcId, id, result }).catch(() => undefined)
}

async function openDialog(options: Record<string, unknown>): Promise<unknown[]> {
  const props = (options.properties as string[] | undefined) ?? []
  const filters = (options.filters as DialogFilter[] | undefined) ?? []
  const exts = filters.flatMap((f) => f.extensions ?? []).map((e) => e.toLowerCase())
  if (props.includes('openDirectory')) {
    const dir = await pickFolder(String(options.title ?? ''))
    return dir ? [{ path: dir }] : []
  }
  // documents come from the user's files; pictures, media and fonts from the computer
  if (exts.length > 0 && exts.some((e) => DOC_EXTS.has(e))) {
    const path = await pickServerFile({ exts: exts.filter((e) => e !== '*') })
    return path ? [{ path }] : []
  }
  const accept = exts.length && !exts.includes('*') ? exts.map((e) => `.${e}`).join(',') : ''
  const picked = await pickLocalFiles({ accept, multiple: props.includes('multiSelections') })
  const out: unknown[] = []
  for (const file of picked) {
    const q = new URLSearchParams({ name: file.name.replace(/[/\\]/g, '_') || 'file' })
    out.push(await http.put<{ upload: string }>(`${BASE}/upload?${q}`, file))
  }
  return out
}

async function saveDialog(options: Record<string, unknown>): Promise<string | null> {
  const filters = (options.filters as DialogFilter[] | undefined) ?? []
  const ext = filters[0]?.extensions?.[0] ?? 'pptx'
  const def = String(options.defaultPath ?? '')
  const dir = def.includes('/') ? dirname(def) : undefined
  return promptSaveAs({ defaultName: basename(def) || `Presentation.${ext}`, ext, defaultDir: dir })
}

async function messageBox(options: Record<string, unknown>): Promise<{ response: number }> {
  const buttons = (options.buttons as string[] | undefined) ?? ['OK']
  const cancelId = typeof options.cancelId === 'number' ? options.cancelId : buttons.length - 1
  const defaultId = typeof options.defaultId === 'number' ? options.defaultId : 0
  if (buttons.length <= 2) {
    const text = [options.message, options.detail].filter(Boolean).join('\n\n')
    if (buttons.length === 1) {
      await confirmDialog(text, buttons[0])
      return { response: 0 }
    }
    const okIndex = cancelId === 0 ? 1 : 0
    const ok = await confirmDialog(text, buttons[okIndex])
    return { response: ok ? okIndex : cancelId }
  }
  return { response: await choiceModal(options, buttons, cancelId, defaultId) }
}

function modalShell(): { box: HTMLDivElement; close: () => void } {
  const backdrop = document.createElement('div')
  backdrop.style.cssText =
    'position:fixed;inset:0;z-index:2147483000;display:flex;align-items:center;justify-content:center;background:var(--color-bg-overlay,rgba(0,0,0,.35));font:14px/1.45 system-ui,sans-serif'
  const box = document.createElement('div')
  box.style.cssText =
    'min-width:min(420px,calc(100vw - 32px));max-width:calc(100vw - 32px);background:var(--surface);color:var(--text);border:1px solid var(--border);border-radius:10px;box-shadow:var(--shadow-menu);padding:18px 20px'
  backdrop.append(box)
  document.body.append(backdrop)
  return { box, close: () => backdrop.remove() }
}

function button(label: string, primary: boolean, onClick: () => void): HTMLButtonElement {
  const b = document.createElement('button')
  b.textContent = label
  b.style.cssText = `padding:7px 14px;border-radius:6px;font:inherit;cursor:pointer;border:1px solid ${primary ? 'var(--accent)' : 'var(--border-strong)'};background:${primary ? 'var(--accent)' : 'var(--surface)'};color:${primary ? 'var(--surface)' : 'var(--text)'}`
  b.onclick = onClick
  return b
}

function choiceModal(
  options: Record<string, unknown>,
  buttons: string[],
  cancelId: number,
  defaultId: number,
): Promise<number> {
  return new Promise((resolve) => {
    const { box, close } = modalShell()
    const msg = document.createElement('div')
    msg.style.cssText = 'font-weight:600;margin-bottom:6px'
    msg.textContent = String(options.message ?? '')
    const detail = document.createElement('div')
    detail.style.cssText = 'color:var(--text-secondary);white-space:pre-wrap'
    detail.textContent = String(options.detail ?? '')
    const row = document.createElement('div')
    row.style.cssText = 'display:flex;justify-content:flex-end;gap:8px;margin-top:16px;flex-wrap:wrap'
    buttons.forEach((label, i) =>
      row.append(
        button(label, i === defaultId, () => {
          close()
          resolve(i)
        }),
      ),
    )
    box.append(msg, detail, row)
    const onKey = (ev: KeyboardEvent) => {
      if (ev.key !== 'Escape') return
      window.removeEventListener('keydown', onKey, true)
      close()
      resolve(cancelId)
    }
    window.addEventListener('keydown', onKey, true)
  })
}

async function pickFolder(title: string): Promise<string | null> {
  const dirs = ['/', ...(await http.get<string[]>('/api/fs/dirs').catch(() => [] as string[]))]
  return new Promise((resolve) => {
    const { box, close } = modalShell()
    const h = document.createElement('div')
    h.style.cssText = 'font-weight:600;margin-bottom:10px'
    h.textContent = title || (document.documentElement.lang.startsWith('ko') ? '폴더 선택' : 'Choose a folder')
    const select = document.createElement('select')
    select.style.cssText =
      'width:100%;padding:7px;border:1px solid var(--border-strong);border-radius:6px;background:var(--surface);color:var(--text);font:inherit'
    for (const d of new Set(dirs)) {
      const o = document.createElement('option')
      o.value = d
      o.textContent = d
      select.append(o)
    }
    const row = document.createElement('div')
    row.style.cssText = 'display:flex;justify-content:flex-end;gap:8px;margin-top:16px'
    row.append(
      button('Cancel', false, () => {
        close()
        resolve(null)
      }),
      button('OK', true, () => {
        close()
        resolve(select.value)
      }),
    )
    box.append(h, select, row)
  })
}

// ---- printing & PDF ------------------------------------------------------------------

function printHtml(html: string): Promise<{ ok: boolean; error?: string }> {
  return new Promise((resolve) => {
    const frame = document.createElement('iframe')
    frame.style.cssText = 'position:fixed;width:0;height:0;border:0;left:-10000px'
    // deck content is untrusted: no scripts in the print frame (the parent drives print())
    frame.setAttribute('sandbox', 'allow-same-origin allow-modals')
    frame.srcdoc = html
    frame.onload = async () => {
      try {
        const doc = frame.contentDocument!
        await doc.fonts?.ready
        await Promise.all([...doc.images].map((i) => i.decode().catch(() => undefined)))
        frame.contentWindow!.focus()
        frame.contentWindow!.print()
        resolve({ ok: true })
      } catch (err) {
        resolve({ ok: false, error: String(err) })
      } finally {
        setTimeout(() => frame.remove(), 60_000)
      }
    }
    document.body.append(frame)
  })
}

function downloadFromTree(path: string): void {
  const a = document.createElement('a')
  a.href = files.rawUrl(path, { download: true })
  a.download = basename(path)
  document.body.append(a)
  a.click()
  a.remove()
}

// ---- dirty tracking for the close guard (beforeunload is synchronous) -----------------

let dirty = false
let autoSave = false
const closeGuard = installCloseGuard({ checkEvent: 'slides:close-check' })
bus.on('slides:close-check', () => closeGuard.report({ dirty, autoSave }))
let dirtyProbe: ReturnType<typeof setTimeout> | undefined
on('slides:history-changed', () => {
  clearTimeout(dirtyProbe)
  dirtyProbe = setTimeout(() => {
    void invoke('slides:is-dirty').then((d) => (dirty = d === true), () => undefined)
  }, 200)
})

installShortcuts(
  [
    { keys: 'mod+s', command: 'save' },
    { keys: 'mod+shift+s', command: 'save-as' },
    { keys: 'mod+o', command: 'open' },
    { keys: 'mod+p', command: 'print' },
    { keys: 'mod+=', command: 'zoom-in' },
    { keys: 'mod++', command: 'zoom-in' },
    { keys: 'mod+-', command: 'zoom-out' },
    { keys: 'mod+0', command: 'zoom-reset' },
  ],
  'ipc:slides:menu',
)

// ---- macOS: the ribbon leaves File commands to the native menu bar ---------------------
// (and keeps the window's traffic-light gap free), so the web edition puts a
// File menu into that gap; it sends the same commands the menu bar would.

const FILE_MENU = {
  en: { file: 'File', open: 'Open…', save: 'Save', saveAs: 'Save As…', pdf: 'Export PDF…', images: 'Export Images…', print: 'Print…' },
  ko: { file: '파일', open: '열기…', save: '저장', saveAs: '다른 이름으로 저장…', pdf: 'PDF로 내보내기…', images: '이미지로 내보내기…', print: '인쇄…' },
}

async function installMacFileMenu(): Promise<void> {
  if (!/mac/i.test(navigator.platform)) return
  const s = (await getPrefs()).language === 'ko' ? FILE_MENU.ko : FILE_MENU.en
  const wrap = document.createElement('div')
  wrap.style.cssText = 'position:fixed;left:8px;top:6px;z-index:1000;font:13px system-ui,sans-serif'
  const btn = document.createElement('button')
  btn.textContent = s.file
  btn.style.cssText =
    'border:0;background:transparent;color:var(--text);padding:4px 10px;border-radius:5px;cursor:pointer;font:inherit'
  btn.onmouseenter = () => (btn.style.background = 'var(--hover)')
  btn.onmouseleave = () => (btn.style.background = 'transparent')
  const menu = document.createElement('div')
  menu.style.cssText =
    'display:none;position:absolute;top:28px;left:0;min-width:200px;background:var(--surface);color:var(--text);border:1px solid var(--border);border-radius:8px;box-shadow:var(--shadow-menu);padding:4px'
  const items: Array<[string, string]> = [
    [s.open, 'open'],
    [s.save, 'save'],
    [s.saveAs, 'save-as'],
    [s.pdf, 'export-pdf'],
    [s.images, 'export-images'],
    [s.print, 'print'],
  ]
  for (const [label, command] of items) {
    const item = document.createElement('button')
    item.textContent = label
    item.style.cssText =
      'display:block;width:100%;text-align:left;border:0;background:transparent;color:inherit;padding:6px 10px;border-radius:5px;cursor:pointer;font:inherit'
    item.onmouseenter = () => (item.style.background = 'var(--hover)')
    item.onmouseleave = () => (item.style.background = 'transparent')
    item.onclick = () => {
      menu.style.display = 'none'
      bus.emit('ipc:slides:menu', command)
    }
    menu.append(item)
  }
  btn.onclick = (ev) => {
    ev.stopPropagation()
    menu.style.display = menu.style.display === 'none' ? 'block' : 'none'
  }
  document.addEventListener('mousedown', (ev) => {
    if (!wrap.contains(ev.target as Node)) menu.style.display = 'none'
  })
  wrap.append(btn, menu)
  document.body.append(wrap)
  // out of the way during a slideshow / presenter view
  new MutationObserver(() => {
    wrap.style.display = document.querySelector('.slideshow, .pv-top') ? 'none' : ''
  }).observe(document.body, { childList: true, subtree: true })
}

if (!AUDIENCE) {
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => void installMacFileMenu())
  else void installMacFileMenu()
}

// ---- slidesApi: method → channel tables (extracted from the upstream preload) --------

const INVOKE: Record<string, string> = {
  getLanguage: 'app:get-language',
  getTheme: 'app:get-theme',
  getAutoSaveDefault: 'app:get-auto-save-default',
  getAiPanelPrefs: 'app:get-ai-panel-prefs',
  setAiPanelPrefs: 'app:set-ai-panel-prefs',
  setShowFullScreen: 'slides:show-fullscreen',
  privateFontFaces: 'slides:private-font-faces',
  privateFontData: 'slides:private-font-data',
  fontCatalog: 'slides:font-catalog',
  fontDownload: 'slides:font-download',
  fontInstallLocal: 'slides:font-install-local',
  fontMissing: 'slides:font-missing',
  openPptx: 'slides:open',
  openPptxPath: 'slides:open-path',
  consumePendingOpen: 'slides:consume-pending-open',
  consumeHeadlessExport: 'slides:consume-headless-export',
  newBlank: 'slides:new-blank',
  landGeneratedPages: 'slides:land-generated-pages',
  cloudGenStatus: 'slides:cloud-gen-status',
  cloudPageCancel: 'slides:cloud-page-cancel',
  cloudGeneratePage: 'slides:cloud-page-generate',
  localGeneratePage: 'slides:local-page-generate',
  editText: 'slides:edit-text',
  setElementFont: 'slides:set-element-font',
  setElementParagraphFormat: 'slides:set-element-paragraph-format',
  findReplace: 'slides:find-replace',
  setSlideLayout: 'slides:set-slide-layout',
  setSlideSize: 'slides:set-slide-size',
  getSlideSize: 'slides:get-slide-size',
  editTransform: 'slides:edit-transform',
  cancelTransformPreview: 'slides:cancel-transform-preview',
  editTransformMulti: 'slides:edit-transform-multi',
  editConnectorEndpoints: 'slides:edit-connector-endpoints',
  editPictureSrcRect: 'slides:edit-picture-src-rect',
  editPictureOpacity: 'slides:edit-picture-opacity',
  editImageFill: 'slides:edit-image-fill',
  changeShape: 'slides:change-shape',
  setShapeAdjust: 'slides:set-shape-adjust',
  setShapeGeometry: 'slides:set-shape-geometry',
  setTextAnchor: 'slides:set-text-anchor',
  setTextBodyProps: 'slides:set-text-body-props',
  setEffects: 'slides:set-effects',
  clipboardExternal: 'slides:clipboard-external',
  groupElements: 'slides:group-elements',
  ungroupElement: 'slides:ungroup-element',
  batchEditTransform: 'slides:batch-edit-transform',
  getRenderSlides: 'slides:get-render-slides',
  addElement: 'slides:add-element',
  deleteElement: 'slides:delete-element',
  deleteElements: 'slides:delete-elements',
  addSlide: 'slides:add-slide',
  addBlankSlide: 'slides:add-blank-slide',
  addSlideWithLayout: 'slides:add-slide-with-layout',
  getLayouts: 'slides:get-layouts',
  masterEnter: 'slides:master-enter',
  masterOpen: 'slides:master-open',
  masterClose: 'slides:master-close',
  masterEditText: 'slides:master-edit-text',
  masterEditTransform: 'slides:master-edit-transform',
  masterEditFill: 'slides:master-edit-fill',
  masterEditStroke: 'slides:master-edit-stroke',
  masterDeleteElement: 'slides:master-delete-element',
  editFill: 'slides:edit-fill',
  editStroke: 'slides:edit-stroke',
  flipElements: 'slides:flip-elements',
  editBackground: 'slides:edit-background',
  pickPictureFile: 'slides:pick-picture-file',
  insertImage: 'slides:insert-image',
  copySlides: 'slides:copy-slides',
  pasteSlide: 'slides:paste-slide',
  repasteSlide: 'slides:repaste-slide',
  hasSlideClipboard: 'slides:has-slide-clipboard',
  clipboardProbe: 'slides:clipboard-probe',
  deleteSlide: 'slides:delete-slide',
  deleteSlides: 'slides:delete-slides',
  duplicateSlides: 'slides:duplicate-slides',
  reorderElement: 'slides:reorder-element',
  editTableCell: 'slides:edit-table-cell',
  tableStructure: 'slides:table-structure',
  tableMerge: 'slides:table-merge',
  setTableColWidth: 'slides:set-table-col-width',
  setTableRowHeight: 'slides:set-table-row-height',
  setTableCellAnchor: 'slides:set-table-cell-anchor',
  editTableStyle: 'slides:edit-table-style',
  editChart: 'slides:edit-chart',
  getChartColorSchemes: 'slides:chart-color-schemes',
  getChartData: 'slides:get-chart-data',
  copyElements: 'slides:copy-elements',
  copyElementsImage: 'slides:copy-elements-image',
  pasteElements: 'slides:paste-elements',
  duplicateElements: 'slides:duplicate-elements',
  addTable: 'slides:add-table',
  addInk: 'slides:add-ink',
  addChart: 'slides:add-chart',
  addSmartArt: 'slides:add-smartart',
  addImageBytes: 'slides:add-image-bytes',
  replacePictureBytes: 'slides:replace-picture-bytes',
  insertMedia: 'slides:insert-media',
  addMediaBytes: 'slides:add-media-bytes',
  getMediaData: 'slides:media-data',
  insertModel3d: 'slides:insert-model3d',
  setLink: 'slides:set-link',
  getLink: 'slides:get-link',
  getSlideLinks: 'slides:get-slide-links',
  getRunLinks: 'slides:get-run-links',
  applyHeaderFooter: 'slides:apply-header-footer',
  getHeaderFooter: 'slides:get-header-footer',
  applyTheme: 'slides:apply-theme',
  setTransition: 'slides:set-transition',
  getTransition: 'slides:get-transition',
  getShowTiming: 'slides:get-show-timing',
  setAdvanceTimes: 'slides:set-advance-times',
  saveRecording: 'slides:save-recording',
  clearNarration: 'slides:clear-narration',
  microphoneAccess: 'slides:microphone-access',
  getAnimations: 'slides:get-animations',
  getShapeKeys: 'slides:get-shape-keys',
  setAnimations: 'slides:set-animations',
  setSlideHidden: 'slides:set-hidden',
  setSlidesHidden: 'slides:set-slides-hidden',
  getSections: 'slides:get-sections',
  setSections: 'slides:set-sections',
  addSection: 'slides:add-section',
  renameSection: 'slides:rename-section',
  removeSection: 'slides:remove-section',
  removeSectionSlides: 'slides:remove-section-slides',
  moveSection: 'slides:move-section',
  moveSlide: 'slides:move-slide',
  moveSlides: 'slides:move-slides',
  getNotes: 'slides:get-notes',
  setNotes: 'slides:set-notes',
  getComments: 'slides:get-comments',
  addComment: 'slides:add-comment',
  deleteComment: 'slides:delete-comment',
  nativeClipboard: 'slides:native-clipboard',
  beginHistoryBatch: 'slides:history-batch-begin',
  endHistoryBatch: 'slides:history-batch-end',
  applyEditScript: 'slides:apply-edit-script',
  applyTxn: 'slides:apply-txn',
  aiSnapshotRestore: 'slides:ai-snapshot-restore',
  undo: 'slides:undo',
  redo: 'slides:redo',
  pickExportDir: 'slides:pick-export-dir',
  exportImages: 'slides:export-images',
  pickExportPdfPath: 'slides:pick-export-pdf-path',
  savePicture: 'slides:save-picture',
  exportPdf: 'slides:export-pdf',
  printSlides: 'slides:print',
  save: 'slides:save',
  saveAs: 'slides:save-as',
  isDirty: 'slides:is-dirty',
  getRecentFiles: 'slides:recent',
  getAiSettings: 'ai:get-settings',
  setAiSettings: 'ai:set-settings',
  openAiModelSettings: 'ai:open-model-settings',
  aiStream: 'ai:stream',
  aiStreamCancel: 'ai:stream-cancel',
  aiGskStatus: 'ai:gsk-status',
  aiGskLogin: 'ai:gsk-login',
  aiLogRunFailure: 'ai:log-run-failure',
  webSearch: 'ai:web-search',
  imageSearch: 'ai:image-search',
  insertImageUrl: 'ai:insert-image-url',
  replacePictureUrl: 'ai:replace-picture-url',
  generateImage: 'ai:generate-image',
  analyzeMedia: 'ai:analyze-media',
  gskStatus: 'ai:gsk-status',
  saveStyleSidecar: 'ai:save-sidecar',
  saveStyleTemplate: 'ai:save-style-template',
  listStyleTemplates: 'ai:list-style-templates',
  loadStyleTemplate: 'ai:load-style-template',
  presenterStart: 'slides:presenter-start',
  presenterSwap: 'slides:presenter-swap',
  presenterEnd: 'slides:presenter-end',
  audienceReady: 'slides:audience-ready',
}

const SEND: Record<string, string> = {
  headlessExportDone: 'slides:headless-export-done',
  reportCloseSaveResult: 'slides:close-save-result',
  setAutoSavePref: 'slides:autosave-pref',
  presenterSync: 'slides:presenter-sync',
  presenterInk: 'slides:presenter-ink',
  audienceNav: 'slides:audience-nav',
}

const EVENTS: Record<string, string> = {
  onLanguageChanged: 'app:language-changed',
  onThemeChanged: 'app:theme-changed',
  onAutoSaveDefaultChanged: 'app:auto-save-default-changed',
  onAiPanelPrefsChanged: 'app:ai-panel-prefs-changed',
  onChromePressed: 'app:chrome-pressed',
  onFontsChanged: 'slides:fonts-changed',
  onCloseSaveRequest: 'slides:close-save-request',
  onHistoryChanged: 'slides:history-changed',
  onDeckChanged: 'slides:deck-changed',
  onMenuCommand: 'slides:menu',
  onOpened: 'slides:opened',
  onRenamed: 'slides:renamed',
  onAiSettingsChanged: 'ai:settings-changed',
  onAiStream: 'ai:stream-chunk',
  onShowSync: 'slides:show-sync',
  onShowInk: 'slides:show-ink',
  onAudienceNav: 'slides:audience-nav',
}

const api: Record<string, unknown> = {}
for (const [name, channel] of Object.entries(INVOKE)) api[name] = (...args: unknown[]) => invoke(channel, ...args)
for (const [name, channel] of Object.entries(SEND)) api[name] = (...args: unknown[]) => send(channel, ...args)
for (const [name, channel] of Object.entries(EVENTS)) api[name] = (h: (...a: never[]) => void) => on(channel, h)

// settings, AI and recents are served by the web server's shared endpoints
const common = commonApi()
let pendingConsumed = false

/** record a saved/opened path in the address bar so a reload reopens it */
function trackPath<T>(result: T): T {
  const path = (result as { path?: unknown } | null)?.path
  if (typeof path === 'string' && path.startsWith('/')) setLaunchPath(path)
  return result
}

Object.assign(api, {
  getLanguage: common.getLanguage,
  onLanguageChanged: common.onLanguageChanged,
  getTheme: common.getTheme,
  onThemeChanged: common.onThemeChanged,
  getAutoSaveDefault: common.getAutoSaveDefault,
  onAutoSaveDefaultChanged: common.onAutoSaveDefaultChanged,
  getAiPanelPrefs: common.getAiPanelPrefs,
  setAiPanelPrefs: common.setAiPanelPrefs,
  onAiPanelPrefsChanged: common.onAiPanelPrefsChanged,
  onChromePressed: common.onChromePressed,
  getAiSettings: common.getAiSettings,
  setAiSettings: common.setAiSettings,
  onAiSettingsChanged: common.onAiSettingsChanged,
  openAiModelSettings: common.openAiModelSettings,
  aiStream: common.aiStream,
  aiStreamCancel: common.aiStreamCancel,
  onAiStream: common.onAiStream,
  aiGskStatus: common.aiGskStatus,
  gskStatus: common.aiGskStatus,
  aiGskLogin: common.aiGskLogin,
  aiLogRunFailure: async () => undefined,
  webSearch: common.webSearch,
  imageSearch: common.imageSearch,
  getRecentFiles: common.getRecentFiles,

  consumeHeadlessExport: async () => null,
  headlessExportDone: () => undefined,

  consumePendingOpen: async (fitWidthPx: number) => {
    if (!pendingConsumed && launch.path) {
      pendingConsumed = true
      return invoke('slides:open-path', launch.path, fitWidthPx)
    }
    pendingConsumed = true
    // a remount (or reconnect) restores the deck the server still holds
    return invoke('slides:consume-pending-open', fitWidthPx)
  },
  openPptx: async (fitWidthPx: number) => trackPath(await invoke('slides:open', fitWidthPx)),
  openPptxPath: async (path: string, fitWidthPx: number) =>
    trackPath(await invoke('slides:open-path', path, fitWidthPx)),
  save: async () => trackPath(await invoke('slides:save')),
  saveAs: async (defaultName: string) => trackPath(await invoke('slides:save-as', defaultName)),
  setAutoSavePref: (on: boolean) => {
    autoSave = on === true
    send('slides:autosave-pref', autoSave)
  },

  // exports are written into the user's files, then handed to the browser as downloads
  exportPdf: async (op: unknown) => {
    const r = (await invoke('slides:export-pdf', op)) as { ok: boolean; path?: string }
    if (r?.ok && r.path) downloadFromTree(r.path)
    return r
  },
  savePicture: async (op: unknown) => {
    const r = (await invoke('slides:save-picture', op)) as { ok: boolean; path?: string }
    if (r?.ok && r.path) downloadFromTree(r.path)
    return r
  },
  printSlides: async (op: {
    pngsBase64: string[]
    widthPx: number
    heightPx: number
    layout?: 'full' | 'handout2' | 'handout3' | 'handout6' | 'notes'
    notes?: string[]
    orientation?: 'portrait' | 'landscape'
    frame?: boolean
  }) =>
    printHtml(
      buildPrintDocumentHtml({
        srcs: op.pngsBase64.map((b64) => `data:image/png;base64,${b64}`),
        ratio: op.widthPx / op.heightPx,
        layout: op.layout ?? 'full',
        ...(op.notes ? { notes: op.notes } : {}),
        ...(op.orientation ? { orientation: op.orientation } : {}),
        ...(op.frame ? { frame: true } : {}),
      }),
    ),

  // slideshow: the browser's own fullscreen instead of a borderless window
  setShowFullScreen: async (on: boolean) => {
    try {
      if (on && !document.fullscreenElement) await document.documentElement.requestFullscreen()
      if (!on && document.fullscreenElement) await document.exitFullscreen()
    } catch {
      // fullscreen needs a user gesture; the show still runs in the page
    }
  },
  // presenter view: the audience goes to a popup window the user drags to the projector
  presenterStart: async () => {
    // opened before any await, while the click that started the show still counts as a gesture
    const popup = window.open('about:blank', 'ow-slides-audience', 'popup=yes,width=1280,height=720')
    const r = (await invoke('slides:presenter-start', { popup: popup !== null })) as {
      audience: boolean
      audienceWc?: number
    }
    if (popup && r.audienceWc) {
      popup.location.href = `/app/slides/?${new URLSearchParams({ mode: 'audience', wc: String(r.audienceWc) })}`
      audiencePopup = popup
      return { audience: true }
    }
    popup?.close()
    return { audience: r.audience }
  },
  presenterEnd: async () => {
    await invoke('slides:presenter-end').catch(() => undefined)
    audiencePopup?.close()
    audiencePopup = null
  },
  microphoneAccess: async () => true,
})

expose('slidesApi', withFallback('slidesApi', api))

let audiencePopup: Window | null = null

if (AUDIENCE) {
  // the presenter ended the show (or closed its tab)
  on('office-web:close-window', () => window.close())
  // a page may only enter fullscreen from a gesture: offer it until it is taken
  const offerFullscreen = () => {
    if (document.fullscreenElement || document.getElementById('ow-audience-fs')) return
    const btn = document.createElement('button')
    btn.id = 'ow-audience-fs'
    btn.textContent = 'Full screen'
    void getPrefs().then((p) => {
      if (p.language === 'ko') btn.textContent = '전체 화면'
    })
    btn.style.cssText =
      'position:fixed;top:12px;right:12px;z-index:2147483000;padding:8px 14px;border-radius:8px;border:1px solid rgba(255,255,255,.35);background:rgba(0,0,0,.55);color:#fff;font:13px system-ui,sans-serif;cursor:pointer'
    btn.onclick = (ev) => {
      ev.stopPropagation()
      void document.documentElement.requestFullscreen().catch(() => undefined)
    }
    document.body.append(btn)
  }
  document.addEventListener('fullscreenchange', () => {
    if (document.fullscreenElement) document.getElementById('ow-audience-fs')?.remove()
    else offerFullscreen()
  })
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', offerFullscreen)
  else offerFullscreen()
}

// chat attachments (same subset docs exposes on window.desktop)
expose('desktop', {
  pickAttachments: common.pickAttachments,
  addAttachmentPaths: common.addAttachmentPaths,
  addPastedImage: common.addPastedImage,
  readAttachment: common.readAttachment,
  readAttachmentImage: common.readAttachmentImage,
  getPathForFile: common.getPathForFile,
})
expose('projectApi', projectApi())
