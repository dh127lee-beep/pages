/**
 * Docs open/save through /api/apps/docs so password-protected documents work:
 * the server decrypts on open (the plaintext comes back through a one-shot
 * URL), re-encrypts on save, and keeps every password to itself. Each browser
 * tab has its own id, the counterpart of the desktop's per-window state.
 */

import {
  bus,
  confirmDialog,
  files,
  HttpError,
  http,
  launchDir,
  promptSaveAs,
  setLaunchPath,
  stripExt,
} from '../core'

const API = '/api/apps/docs'

export const tabId = (() => {
  const bytes = crypto.getRandomValues(new Uint8Array(16))
  return [...bytes].map((b) => b.toString(16).padStart(2, '0')).join('')
})()

// the tab's passwords are dropped server-side when it goes away (also on an idle TTL)
window.addEventListener('pagehide', () => {
  try {
    navigator.sendBeacon(`${API}/forget`, new Blob([JSON.stringify({ tab: tabId })], { type: 'application/json' }))
  } catch {
    // best effort
  }
})

/** content hash of what each path held when this tab last read or wrote it */
const knownHash = new Map<string, string>()

export interface OpenFileResult {
  path: string
  name: string
  dataUrl: string
  hash: string
  encrypted?: boolean
}

export type OpenResult = OpenFileResult | { needsPassword: true; path: string; name: string } | null

export async function openDocPath(path: string): Promise<OpenResult> {
  const res = await http.post<
    | { plain: true; path: string; name: string; hash: string }
    | { needsPassword: true; path: string; name: string }
    | OpenFileResult
  >(`${API}/open`, { tab: tabId, path })
  if ('needsPassword' in res) return res
  knownHash.set(res.path, res.hash)
  if ('plain' in res) {
    void http.post('/api/fs/recent', { path: res.path }).catch(() => undefined)
    return { path: res.path, name: res.name, dataUrl: files.rawUrl(res.path), hash: res.hash }
  }
  return res
}

export async function decryptDocPath(
  path: string,
  password: string,
): Promise<
  | { ok: true; result: OpenFileResult }
  | { ok: false; reason: 'wrong-password' | 'unsupported' | 'error'; error?: string }
> {
  const res = await http.post<
    | { ok: true; result: OpenFileResult }
    | { ok: false; reason: 'wrong-password' | 'unsupported' | 'error'; error?: string }
  >(`${API}/decrypt`, { tab: tabId, path, password })
  if (res.ok) knownHash.set(res.result.path, res.result.hash)
  return res
}

export interface DocSaveResult {
  ok: boolean
  path?: string
  error?: string
  reason?: 'external-modified'
  passwordIntentPending?: boolean
}

const CONFLICT = {
  en: 'This file was changed elsewhere since you opened it. Overwrite it with your version?',
  ko: '파일을 연 뒤에 다른 곳에서 변경되었습니다. 현재 내용으로 덮어쓰시겠습니까?',
}

async function post(
  target: string,
  source: string | null,
  data: ArrayBuffer,
  opts: { expectHash?: string; overwrite?: boolean },
): Promise<{ ok: true; path: string; hash: string; passwordIntentPending: boolean } | { ok: false; conflict: true }> {
  const q = new URLSearchParams({ tab: tabId, path: target })
  if (source) q.set('source', source)
  if (opts.expectHash) q.set('expectHash', opts.expectHash)
  if (opts.overwrite === false) q.set('overwrite', '0')
  try {
    return await http.post<{ ok: true; path: string; hash: string; passwordIntentPending: boolean }>(
      `${API}/save?${q}`,
      data,
    )
  } catch (err) {
    if (err instanceof HttpError && err.status === 409) return { ok: false, conflict: true }
    throw err
  }
}

/**
 * Save over `path`. Someone else's change since we last saw the file is
 * refused: autosaves report `external-modified`, manual saves ask first.
 */
export async function saveDocPath(path: string, data: ArrayBuffer, auto: boolean): Promise<DocSaveResult> {
  try {
    let out = await post(path, path, data, { expectHash: knownHash.get(path) })
    if (!out.ok) {
      if (auto) return { ok: false, reason: 'external-modified' }
      const lang = document.documentElement.lang.startsWith('ko') ? 'ko' : 'en'
      if (!(await confirmDialog(CONFLICT[lang]))) return { ok: false, reason: 'external-modified' }
      out = await post(path, path, data, {})
      if (!out.ok) return { ok: false, error: 'File was modified elsewhere' }
    }
    knownHash.set(out.path, out.hash)
    return { ok: true, passwordIntentPending: out.passwordIntentPending }
  } catch (err) {
    return { ok: false, error: err instanceof Error ? err.message : String(err) }
  }
}

async function saveTo(target: string, source: string | null, data: ArrayBuffer, overwrite = true): Promise<DocSaveResult> {
  try {
    const out = await post(target, source, data, { overwrite })
    if (!out.ok) return { ok: false, error: 'File already exists' }
    knownHash.set(out.path, out.hash)
    return { ok: true, path: out.path, passwordIntentPending: out.passwordIntentPending }
  } catch (err) {
    return { ok: false, error: err instanceof Error ? err.message : String(err) }
  }
}

function docxName(defaultName: string): { name: string; ext: string } {
  const ext = defaultName.toLowerCase().endsWith('.dotx') ? '.dotx' : '.docx'
  let name = (defaultName || 'Untitled').replace(/[/\\]/g, '_')
  if (!name.toLowerCase().endsWith(ext)) name = stripExt(name) + ext
  return { name, ext }
}

/** Save As: the desired password of the source document follows it to the new path */
export async function saveDocAs(defaultName: string, data: ArrayBuffer, sourcePath?: string | null): Promise<DocSaveResult> {
  const { name, ext } = docxName(defaultName)
  const target = await promptSaveAs({ defaultName: name, ext, defaultDir: launchDir() })
  if (!target) return { ok: false }
  const out = await saveTo(target, sourcePath ?? null, data)
  if (out.ok && out.path) setLaunchPath(out.path)
  return out
}

/** first save of a new document: a free name in the folder it was created from, no dialog */
export async function saveDocNew(defaultName: string, data: ArrayBuffer): Promise<DocSaveResult> {
  const { name } = docxName(defaultName)
  const { path } = await files.uniquePath(launchDir(), name)
  const out = await saveTo(path, null, data, false)
  if (out.ok && out.path) setLaunchPath(out.path)
  return out
}

export function saveDocTo(path: string, data: ArrayBuffer, overwrite: boolean): Promise<DocSaveResult> {
  return saveTo(path, path, data, overwrite)
}

export async function setDocPassword(filePath: string | null, password: string | null): Promise<{ ok: boolean }> {
  try {
    return await http.post<{ ok: boolean }>(`${API}/set-password`, { tab: tabId, path: filePath, password })
  } catch {
    return { ok: false }
  }
}

export async function docPasswordIntentRevision(): Promise<number> {
  try {
    const { revision } = await http.post<{ revision: number }>(`${API}/password-intent-revision`, { tab: tabId })
    return Number.isSafeInteger(revision) && revision >= 0 ? revision : 0
  } catch {
    return 0
  }
}

export async function discardDocPasswordIntents(throughRevision: number): Promise<{ ok: boolean }> {
  try {
    return await http.post<{ ok: boolean }>(`${API}/discard-password-intents`, { tab: tabId, throughRevision })
  } catch {
    return { ok: false }
  }
}

// Home renamed or moved the open document: the server keeps its password under the new path
bus.on('file:moved', (paths: { oldPath: string; newPath: string }) => {
  const hash = knownHash.get(paths.oldPath)
  if (hash) {
    knownHash.delete(paths.oldPath)
    knownHash.set(paths.newPath, hash)
  }
  void http.post(`${API}/renamed`, { tab: tabId, ...paths }).catch(() => undefined)
})

