/**
 * Helpers shared by the Markdown, HTML and PDF bridges: save-target choice
 * (the desktop main process' save dialog), printing an HTML string, exports
 * that land as downloads, and dirty-state close guarding.
 */

import {
  basename,
  bus,
  dirname,
  downloadBlob,
  files,
  getPrefs,
  http,
  launchDir,
  promptSaveAs,
  setLaunchPath,
  stripExt,
  toast,
} from '../core'

let uiLang = ''
void getPrefs().then((p) => {
  uiLang = p.language
})

/** UI language: the user's preference once loaded (the static pages ship lang="zh-CN") */
export function isKo(): boolean {
  return (uiLang || navigator.language || '').toLowerCase().startsWith('ko')
}

/** the document an editor view holds; mirrors savePathByWc in the desktop main processes */
export class DocState {
  path: string | null = null
  dirty = false

  constructor(readonly ext: string) {
    window.addEventListener('beforeunload', (ev) => {
      if (!this.dirty) return
      ev.preventDefault()
      ev.returnValue = ''
    })
  }

  setPath(path: string): void {
    this.path = path
    setLaunchPath(path)
    document.title = basename(path)
  }

  /**
   * Where a save goes: the open file for a plain save, a silent unique name
   * for an AI-named first save, otherwise the in-page Save As dialog.
   */
  async resolveTarget(
    mode: 'save' | 'saveAs',
    opts: { suggestedName?: string; defaultName?: string } = {},
  ): Promise<string | 'canceled'> {
    if (mode === 'save' && this.path) return this.path
    if (mode === 'save' && !this.path && opts.suggestedName) {
      const base = opts.suggestedName.replace(/[/\\:*?"<>|]/g, '_').slice(0, 80).trim()
      if (base) return (await files.uniquePath(launchDir(), `${base}${this.ext}`)).path
    }
    const defaultName = this.path
      ? basename(this.path)
      : `${opts.defaultName ? stripExt(opts.defaultName) : isKo() ? '제목 없음' : 'Untitled'}${this.ext}`
    const picked = await promptSaveAs({
      defaultName,
      ext: this.ext,
      defaultDir: this.path ? dirname(this.path) : launchDir(),
    })
    return picked ?? 'canceled'
  }
}

/** shortcuts the desktop menu turns into save/print requests */
export function installSaveShortcuts(handlers: {
  save?: () => void
  saveAs?: () => void
  print?: () => void
}): void {
  window.addEventListener(
    'keydown',
    (ev) => {
      const mod = /mac|iphone|ipad/i.test(navigator.platform) ? ev.metaKey : ev.ctrlKey
      if (!mod || ev.altKey) return
      const key = ev.key.toLowerCase()
      const run = key === 's' ? (ev.shiftKey ? handlers.saveAs : handlers.save) : key === 'p' && !ev.shiftKey ? handlers.print : undefined
      if (!run) return
      ev.preventDefault()
      ev.stopPropagation()
      run()
    },
    { capture: true },
  )
}

/**
 * Print an HTML document through a hidden frame (the browser's print dialog
 * also offers "Save as PDF"). Scripts never run: the frame is sandboxed
 * without allow-scripts; allow-same-origin only lets us call print().
 */
export function printHtmlString(html: string, baseHref?: string | null): Promise<void> {
  return new Promise((resolve) => {
    const frame = document.createElement('iframe')
    frame.setAttribute('sandbox', 'allow-same-origin allow-modals')
    frame.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0;visibility:hidden'
    const withBase =
      baseHref && !/<base\s/i.test(html)
        ? html.replace(/<head[^>]*>/i, (m) => `${m}<base href="${baseHref}">`)
        : html
    frame.srcdoc = withBase
    frame.onload = () => {
      const win = frame.contentWindow
      const done = () => {
        setTimeout(() => frame.remove(), 1000)
        resolve()
      }
      if (!win) return done()
      win.addEventListener('afterprint', done, { once: true })
      // let images settle
      setTimeout(() => {
        try {
          win.focus()
          win.print()
        } catch {
          done()
        }
        // browsers without afterprint
        setTimeout(done, 60_000)
      }, 300)
    }
    document.body.appendChild(frame)
  })
}

/** POST to an export endpoint answering bytes; JSON error bodies become exceptions */
export async function postForBytes(url: string, body: unknown): Promise<Blob> {
  const res = await fetch(url, {
    method: 'POST',
    credentials: 'same-origin',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
  })
  if (!res.ok) {
    const data = (await res.json().catch(() => ({}))) as { error?: string }
    throw new Error(data.error ?? `HTTP ${res.status}`)
  }
  return res.blob()
}

/**
 * Write an export into the user's tree (folder of the document, else the
 * launch folder) under a free name, then offer it as a download too.
 */
export async function storeExport(
  data: Blob | string,
  name: string,
  opts: { besidePath?: string | null; download?: boolean; mime?: string } = {},
): Promise<string> {
  const dir = opts.besidePath ? dirname(opts.besidePath) : launchDir()
  const { path } = await files.uniquePath(dir, name)
  await files.write(path, data, { overwrite: false })
  if (opts.download !== false) downloadBlob(data, basename(path), opts.mime)
  toast(isKo() ? `"${basename(path)}"(으)로 내보냈습니다` : `Exported as "${basename(path)}"`)
  return path
}

export function blobToBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = () => resolve(String(reader.result).replace(/^data:[^,]*,/, ''))
    reader.onerror = () => reject(reader.error)
    reader.readAsDataURL(blob)
  })
}

export function readFileAsBase64(file: File): Promise<string> {
  return blobToBase64(file)
}

export { bus, http }

/**
 * The desktop app reaches Export/Print through the native File menu, which
 * the browser has no equivalent of: a compact menu at the end of the title row
 * raises the same requests the menu would.
 */
export function installExportMenu(build: () => Array<{ label: string; run: () => void }>): void {
  const mount = () => {
    const wrap = document.createElement('div')
    wrap.style.cssText =
      'position:fixed;right:14px;top:9px;z-index:2147482000;font:12px system-ui,-apple-system,"Segoe UI",sans-serif'
    const button = document.createElement('button')
    button.type = 'button'
    button.textContent = isKo() ? '내보내기 · 인쇄 ▾' : 'Export · Print ▾'
    button.style.cssText =
      'border:1px solid var(--border,#d0d0d0);background:var(--surface,#fff);color:var(--text-secondary,#555);border-radius:5px;padding:1px 9px;cursor:pointer;font:inherit'
    const menu = document.createElement('div')
    menu.hidden = true
    menu.style.cssText =
      'position:absolute;top:26px;right:0;min-width:180px;background:var(--surface,#fff);color:var(--text,#222);border:1px solid var(--border,#ddd);border-radius:8px;box-shadow:var(--shadow-menu,0 8px 24px rgba(0,0,0,.18));padding:4px'
    for (const item of build()) {
      const b = document.createElement('button')
      b.type = 'button'
      b.textContent = item.label
      b.style.cssText =
        'display:block;width:100%;text-align:left;border:0;background:none;color:inherit;padding:7px 10px;border-radius:5px;cursor:pointer;font:inherit;font-size:13px'
      b.onmouseenter = () => (b.style.background = 'var(--hover,#f2f2f2)')
      b.onmouseleave = () => (b.style.background = 'none')
      b.onclick = () => {
        menu.hidden = true
        item.run()
      }
      menu.appendChild(b)
    }
    button.onclick = (ev) => {
      ev.stopPropagation()
      menu.hidden = !menu.hidden
    }
    document.addEventListener('mousedown', (ev) => {
      if (!wrap.contains(ev.target as Node)) menu.hidden = true
    })
    wrap.append(menu, button)
    document.body.appendChild(wrap)
  }
  void getPrefs()
    .catch(() => undefined)
    .then(() => {
      if (document.body) mount()
      else document.addEventListener('DOMContentLoaded', mount, { once: true })
    })
}
