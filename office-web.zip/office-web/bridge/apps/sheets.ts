/**
 * Sheets (xlsx editor) — web implementation of apps/sheets/src/preload.
 * Interface: DesktopApi in upstream/soffice/apps/sheets/src/shared/desktop-api.ts,
 * exposed as `window.desktopApi`. Workbook sessions live in the server's
 * xlsx engine (/api/apps/sheets/*).
 */

import {
  basename,
  bus,
  commonApi,
  confirmDialog,
  dirname,
  expose,
  files as treeFiles,
  getPrefs,
  http,
  installMacFileMenu,
  installShortcuts,
  launch,
  launchDir,
  openInNewTab,
  pickServerFile,
  projectApi,
  promptSaveAs,
  setLaunchPath,
  stripExt,
  toast,
  withFallback,
} from '../core'

const API = '/api/apps/sheets'
const WORKBOOK_EXTS = ['.xlsx', '.xlsm', '.xls', '.csv', '.tsv', '.ods', '.ots']
const KO = () => (document.documentElement.lang || navigator.language).startsWith('ko')

interface WorkbookFile {
  sessionId: string
  name: string
  path?: string
  needsSaveAs?: boolean
  unsavedNew?: boolean
  csvPath?: string
  [key: string]: unknown
}

/** what the bridge knows about each open session (Save As decisions, heartbeat) */
const files = new Map<string, WorkbookFile>()

function track(file: WorkbookFile | null): WorkbookFile | null {
  if (file?.sessionId) files.set(file.sessionId, file)
  return file
}

const post = <T>(route: string, body: unknown) => http.post<T>(`${API}/${route}`, body)
const locale = () => navigator.language || 'en-US'

// ---- launch queue: ?path=… or ?new=1 is the "shell-queued workbook" ----
let queued: { kind: 'path'; path: string } | { kind: 'new' } | null = launch.path
  ? { kind: 'path', path: launch.path }
  : launch.isNew
    ? { kind: 'new' }
    : null

async function openPath(path: string): Promise<WorkbookFile> {
  return track(await post<WorkbookFile>('open', { path, locale: locale() }))!
}

async function selectWorkbook(): Promise<WorkbookFile | null> {
  const q = queued
  queued = null
  try {
    if (q?.kind === 'path') return await openPath(q.path)
    if (q?.kind === 'new') {
      return track(await post<WorkbookFile>('new', { dir: launchDir(), locale: locale() }))
    }
    const path = await pickServerFile({ exts: WORKBOOK_EXTS })
    if (!path) return null
    const file = await openPath(path)
    setLaunchPath(path)
    return file
  } catch (err) {
    toast(err instanceof Error ? err.message : String(err))
    throw err
  }
}

// ---- liveness: the server closes sessions a tab stops heartbeating ----
setInterval(() => {
  const sessionIds = [...files.keys()]
  if (sessionIds.length === 0) return
  void post<{ crashed: boolean }>('heartbeat', { sessionIds })
    .then((r) => {
      if (r?.crashed) bus.emit('sheets:sidecar-crashed')
    })
    .catch(() => undefined)
}, 60_000)

window.addEventListener('pagehide', () => {
  for (const sessionId of files.keys()) {
    navigator.sendBeacon(
      `${API}/close`,
      new Blob([JSON.stringify({ sessionId })], { type: 'application/json' }),
    )
  }
})

// ---- close guard: unsaved journal edits ----
let pendingEdits = 0
window.addEventListener('beforeunload', (ev) => {
  if (pendingEdits > 0) {
    ev.preventDefault()
    ev.returnValue = ''
  }
})

installShortcuts(
  [
    { keys: 'mod+s', command: 'save' },
    { keys: 'mod+shift+s', command: 'save-as' },
    { keys: 'mod+o', command: 'open' },
    { keys: 'mod+p', command: 'print' },
  ],
  'sheets:menu-action',
)

/** does this save need a Save As target first (where the desktop shows a dialog)? */
function needsTarget(request: { sessionId: string; mode: string; quiet?: boolean }): boolean {
  const file = files.get(request.sessionId)
  if (request.mode === 'save-as') return true
  if (!file?.needsSaveAs) return false
  return !(request.mode === 'save' && request.quiet === true && file.unsavedNew === true)
}

void installMacFileMenu({
  items: [
    { label: { en: 'Open…', ko: '열기…' }, command: 'open' },
    { label: { en: 'Save', ko: '저장' }, command: 'save' },
    { label: { en: 'Save As…', ko: '다른 이름으로 저장…' }, command: 'save-as' },
    { label: { en: 'Export PDF…', ko: 'PDF로 내보내기…' }, command: 'export-pdf' },
    { label: { en: 'Export CSV…', ko: 'CSV로 내보내기…' }, command: 'export-csv' },
    { label: { en: 'Print…', ko: '인쇄…' }, command: 'print' },
  ],
  run: (command) => bus.emit('sheets:menu-action', command),
  top: 8,
})

/**
 * Print the renderer's laid-out workbook pages (not the grid UI): a hidden
 * frame with scripts disabled, as the desktop prints a script-less window.
 */
function printLaidOutHtml(html: string): Promise<{ ok: boolean; error?: string }> {
  return new Promise((resolve) => {
    const frame = document.createElement('iframe')
    frame.setAttribute('sandbox', 'allow-same-origin allow-modals')
    frame.style.cssText = 'position:fixed;width:0;height:0;border:0;left:-10000px'
    frame.srcdoc = html
    frame.onload = async () => {
      try {
        await frame.contentDocument?.fonts?.ready
        frame.contentWindow!.focus()
        frame.contentWindow!.print()
        resolve({ ok: true })
      } catch (err) {
        resolve({ ok: false, error: String(err) })
      } finally {
        setTimeout(() => frame.remove(), 60_000)
      }
    }
    document.body.append(frame)
  })
}

function downloadFromTree(path: string): void {
  const a = document.createElement('a')
  a.href = treeFiles.rawUrl(path, { download: true })
  a.download = basename(path)
  document.body.append(a)
  a.click()
  a.remove()
}

// Home renamed or moved this workbook: the server session and the tab title follow
bus.on('file:moved', (paths: { oldPath: string; newPath: string }) => {
  void http
    .post<{ renamed: boolean }>('/api/apps/sheets/file-moved', paths)
    .then((r) => {
      if (r?.renamed) bus.emit('sheets:renamed', basename(paths.newPath))
    })
    .catch(() => undefined)
})

const api = {
  ...commonApi(),

  // ---- open ----
  selectWorkbook,
  hasQueuedWorkbook: async () => queued !== null,
  consumeNewBlankWorkbook: async () => false,
  reopenWorkbook: (path: string) => openPath(path),
  selectWorkbooksForMerge: async () => {
    const path = await pickServerFile({ exts: WORKBOOK_EXTS })
    return path ? [await openPath(path)] : null
  },
  openWorkbooksForMerge: async (paths: string[]) => {
    const out: WorkbookFile[] = []
    try {
      for (const p of paths) out.push(await openPath(p))
    } catch (err) {
      for (const f of out) void api.closeWorkbook(f.sessionId)
      throw err
    }
    return out.length > 0 ? out : null
  },
  onSidecarCrashed: (h: () => void) => bus.on('sheets:sidecar-crashed', h),
  closeWorkbook: async (sessionId: string) => {
    files.delete(sessionId)
    await post('close', { sessionId })
  },

  // ---- reads ----
  readWorkbookRange: (r: unknown) => post('read-range', r),
  readWorkbookFormulas: (r: unknown) => post('read-formulas', r),
  findWorkbookCells: (r: unknown) => post('find-cells', r),
  readWorkbookRowOutline: (r: unknown) => post('read-row-outline', r),
  recalcWorkbook: (r: unknown) => post('recalc', r),
  readWorkbookMedia: (r: unknown) => post('read-media', r),
  readPivotDefinition: (r: unknown) => post('read-pivot', r),
  readLocalImage: (r: { path: string }) => post('read-local-image', { path: r.path }),
  captureScreenSources: async () => ({ status: 'denied', sources: [] }),
  captureScreenSource: async () => null,

  // ---- save ----
  saveWorkbookEdits: async (request: { sessionId: string; mode: string; quiet?: boolean }) => {
    let target: string | undefined
    if (needsTarget(request)) {
      const file = files.get(request.sessionId)
      const shown = file?.csvPath ?? file?.path
      const picked = await promptSaveAs({
        defaultName: `${stripExt(file?.name ?? 'Book')}.xlsx`,
        ext: /\.xlsm$/i.test(file?.name ?? '') ? '.xlsm' : '.xlsx',
        defaultDir: shown ? dirname(shown) : launchDir(),
      })
      if (!picked) return { canceled: true }
      target = picked
    }
    const result = await post<{ canceled: boolean; file?: WorkbookFile }>('save', { request, target })
    if (!result.canceled && result.file) {
      files.delete(request.sessionId)
      track(result.file)
      if (result.file.path && !result.file.unsavedNew) setLaunchPath(result.file.csvPath ?? result.file.path)
    }
    return result
  },
  beginSaveEditsTransfer: (r: unknown) => post('save-edits-begin', r),
  sendSaveEditsChunk: (r: unknown) => post('save-edits-chunk', r),
  abortSaveEditsTransfer: (r: unknown) => post('save-edits-abort', r),
  writeWorkbookRecovery: async () => ({ ok: false }),
  autoRenameWorkbook: async () => ({ renamed: false }),
  confirmCsvSave: async () =>
    (await confirmDialog(
      KO()
        ? 'CSV 형식으로 저장하면 활성 시트의 값만 저장되고 서식·수식·다른 시트는 사라집니다. 계속하시겠습니까? (모두 유지하려면 다른 이름으로 저장에서 .xlsx를 선택하세요.)'
        : 'Saving as CSV keeps only the values of the active sheet; formatting, formulas and other sheets are lost. Continue? (Use Save As .xlsx to keep everything.)',
    ))
      ? 'csv'
      : 'cancel',

  // ---- export & print ----
  exportCsv: async (request: { fileName: string; content: string; hasFormulas: boolean; targetPath?: string }) => {
    if (request.hasFormulas) {
      const go = await confirmDialog(
        KO()
          ? 'CSV에는 수식이 저장되지 않고 계산된 값만 남습니다. 계속하시겠습니까?'
          : 'CSV keeps only calculated values, not formulas. Continue?',
      )
      if (!go) return { canceled: true }
    }
    const path =
      request.targetPath ??
      (await promptSaveAs({ defaultName: request.fileName, ext: '.csv', defaultDir: launchDir() }))
    if (!path) return { canceled: true }
    return post('export-csv', { path, content: request.content })
  },
  // the renderer lays the live workbook out as print HTML (unsaved edits included);
  // the server prints it like the desktop's hidden window and writes the PDF
  // next to the workbook, then the browser downloads it
  exportPdf: async (request: { html: string; fileName: string }) => {
    try {
      const r = await post<{ canceled: boolean; path?: string }>('export-pdf', { request, dir: launchDir() })
      if (r.path) {
        downloadFromTree(r.path)
        toast(KO() ? `PDF로 내보냈습니다: ${basename(r.path)}` : `Exported PDF: ${basename(r.path)}`)
      }
      return r
    } catch (err) {
      // no headless Chrome on this server: the browser prints the same layout
      toast(err instanceof Error ? err.message : String(err))
      await printLaidOutHtml(request.html)
      return { canceled: true }
    }
  },
  printWorkbook: async (request: { html: string }) => printLaidOutHtml(request.html),
  listPrinters: async () => [],
  createDocument: async (request: { type: string; title: string; content: string; sheetName?: string }) => {
    const result = await post<{ ok: boolean; path?: string; error?: string }>('create-document', {
      ...request,
      dir: launchDir(),
    })
    if (result.ok && result.path) openInNewTab(result.path)
    return result
  },

  // ---- menus, names, guards ----
  onMenuAction: (h: (action: string) => void) => bus.on('sheets:menu-action', h),
  onWorkbookRenamed: (h: (name: string) => void) => bus.on('sheets:renamed', h),
  notifyPendingEdits: (count: number) => {
    pendingEdits = Number.isFinite(count) ? count : 0
  },
  onCloseSaveRequest: () => () => undefined,
  reportCloseSaveResult: () => undefined,
  onRecoveryPrompt: () => () => undefined,
  replyRecoveryPrompt: () => undefined,
  getUserDisplayName: async () => (await getPrefs()).authorName,
  onUserDisplayNameChanged: (h: (n: string) => void) => bus.on('app:author-name-changed', h),

  // ---- AI extras ----
  generateImage: (op: unknown) => http.post<unknown>('/api/ai/generate-image', op),

  // ---- desktop-only integrations ----
  onMcpCommand: () => () => undefined,
  reportMcpResult: () => undefined,
  signalMcpReady: () => undefined,
  consumeHeadlessExport: async () => null,
  headlessExportDone: () => undefined,
}

expose('desktopApi', withFallback('desktopApi', api))
expose('projectApi', projectApi())
