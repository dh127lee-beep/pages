/**
 * Minimal in-page dialogs standing in for the native ones Electron's main
 * process shows (Save As, overwrite confirmations). They render with the
 * suite's chrome tokens so they follow the light/dark theme.
 */

import { http } from './core'

const STRINGS = {
  en: {
    saveAs: 'Save as',
    folder: 'Folder',
    name: 'File name',
    save: 'Save',
    cancel: 'Cancel',
    ok: 'OK',
    root: 'My files',
    exists: 'A file with this name already exists. Replace it?',
    replace: 'Replace',
  },
  ko: {
    saveAs: '다른 이름으로 저장',
    folder: '폴더',
    name: '파일 이름',
    save: '저장',
    cancel: '취소',
    ok: '확인',
    root: '내 파일',
    exists: '같은 이름의 파일이 이미 있습니다. 바꾸시겠습니까?',
    replace: '바꾸기',
  },
} as const

function t(): Record<keyof (typeof STRINGS)['en'], string> {
  const lang = (document.documentElement.lang || navigator.language || 'en').slice(0, 2)
  return lang === 'ko' ? STRINGS.ko : STRINGS.en
}

const CSS = `
.ow-backdrop{position:fixed;inset:0;z-index:2147483000;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.35);font:14px/1.4 system-ui,-apple-system,"Segoe UI",sans-serif}
.ow-dialog{min-width:min(420px,calc(100vw - 32px));max-width:calc(100vw - 32px);background:var(--surface,#fff);color:var(--text,#1f1f1f);border:1px solid var(--border,#ddd);border-radius:10px;box-shadow:0 12px 40px rgba(0,0,0,.25);padding:18px 20px}
.ow-dialog h2{margin:0 0 14px;font-size:16px;font-weight:600}
.ow-dialog label{display:block;margin:10px 0 4px;font-size:12px;color:var(--text-secondary,#666)}
.ow-dialog input,.ow-dialog select{width:100%;box-sizing:border-box;padding:7px 9px;border:1px solid var(--border,#ccc);border-radius:6px;background:var(--surface,#fff);color:inherit;font:inherit}
.ow-dialog .ow-actions{display:flex;justify-content:flex-end;gap:8px;margin-top:18px}
.ow-dialog button{padding:7px 14px;border-radius:6px;border:1px solid var(--border,#ccc);background:var(--surface,#fff);color:inherit;font:inherit;cursor:pointer}
.ow-dialog button.ow-primary{background:var(--accent,#2b579a);border-color:var(--accent,#2b579a);color:#fff}
.ow-toast{position:fixed;left:50%;bottom:28px;transform:translateX(-50%);z-index:2147483001;background:var(--text,#222);color:var(--surface,#fff);padding:9px 16px;border-radius:8px;font:13px system-ui,sans-serif;box-shadow:0 6px 20px rgba(0,0,0,.25)}
`

function ensureStyles(): void {
  if (document.getElementById('ow-dialog-css')) return
  const style = document.createElement('style')
  style.id = 'ow-dialog-css'
  style.textContent = CSS
  document.head.appendChild(style)
}

function el<K extends keyof HTMLElementTagNameMap>(
  tag: K,
  props: Partial<HTMLElementTagNameMap[K]> = {},
  children: Array<Node | string> = [],
): HTMLElementTagNameMap[K] {
  const node = document.createElement(tag)
  Object.assign(node, props)
  for (const c of children) node.append(c)
  return node
}

function modal<T>(build: (close: (value: T) => void) => HTMLElement, cancelValue: T): Promise<T> {
  ensureStyles()
  return new Promise((resolve) => {
    const backdrop = el('div', { className: 'ow-backdrop' })
    const close = (value: T) => {
      backdrop.remove()
      window.removeEventListener('keydown', onKey, true)
      resolve(value)
    }
    const onKey = (ev: KeyboardEvent) => {
      if (ev.key === 'Escape') {
        ev.stopPropagation()
        close(cancelValue)
      }
    }
    window.addEventListener('keydown', onKey, true)
    backdrop.addEventListener('mousedown', (ev) => {
      if (ev.target === backdrop) close(cancelValue)
    })
    backdrop.append(build(close))
    document.body.append(backdrop)
    backdrop.querySelector<HTMLInputElement>('input')?.focus()
  })
}

export function confirmDialog(message: string, okLabel?: string): Promise<boolean> {
  const s = t()
  return modal<boolean>(
    (close) =>
      el('div', { className: 'ow-dialog' }, [
        el('div', { textContent: message }),
        el('div', { className: 'ow-actions' }, [
          el('button', { textContent: s.cancel, onclick: () => close(false) }),
          el('button', {
            className: 'ow-primary',
            textContent: okLabel ?? s.ok,
            onclick: () => close(true),
          }),
        ]),
      ]),
    false,
  )
}

async function listFolders(): Promise<string[]> {
  try {
    const dirs = await http.get<string[]>('/api/fs/dirs')
    return ['/', ...dirs.filter((d) => d !== '/')]
  } catch {
    return ['/']
  }
}

/**
 * Save As: pick a folder in the user's tree and a file name. Resolves to the
 * chosen absolute virtual path, or null on cancel. Asks before replacing.
 */
export async function promptSaveAs(opts: {
  defaultName: string
  ext: string
  defaultDir?: string
}): Promise<string | null> {
  const s = t()
  const folders = await listFolders()
  const ext = opts.ext.startsWith('.') ? opts.ext : `.${opts.ext}`
  let name = opts.defaultName || 'Untitled'
  if (!name.toLowerCase().endsWith(ext)) name = name.replace(/\.[^.]+$/, '') + ext
  for (;;) {
    const picked = await modal<{ dir: string; name: string } | null>((close) => {
      const select = el(
        'select',
        {},
        folders.map((f) => el('option', { value: f, textContent: f === '/' ? s.root : f })),
      )
      select.value = folders.includes(opts.defaultDir ?? '/') ? (opts.defaultDir ?? '/') : '/'
      const input = el('input', { value: name, spellcheck: false })
      const submit = () => {
        const n = input.value.trim().replace(/[/\\]/g, '_')
        if (!n) return
        close({ dir: select.value, name: n.toLowerCase().endsWith(ext) ? n : n + ext })
      }
      input.addEventListener('keydown', (ev) => {
        if (ev.key === 'Enter') submit()
      })
      queueMicrotask(() => {
        const dot = input.value.lastIndexOf('.')
        input.setSelectionRange(0, dot > 0 ? dot : input.value.length)
      })
      return el('div', { className: 'ow-dialog' }, [
        el('h2', { textContent: s.saveAs }),
        el('label', { textContent: s.folder }),
        select,
        el('label', { textContent: s.name }),
        input,
        el('div', { className: 'ow-actions' }, [
          el('button', { textContent: s.cancel, onclick: () => close(null) }),
          el('button', { className: 'ow-primary', textContent: s.save, onclick: submit }),
        ]),
      ])
    }, null)
    if (!picked) return null
    const path = picked.dir === '/' ? `/${picked.name}` : `${picked.dir}/${picked.name}`
    let exists = false
    try {
      await http.get(`/api/fs/stat?${new URLSearchParams({ path })}`)
      exists = true
    } catch {
      exists = false
    }
    if (!exists || (await confirmDialog(s.exists, s.replace))) return path
    name = picked.name
  }
}

interface ListEntry {
  path: string
  name: string
  isDir: boolean
  size: number
  mtimeMs: number
}

const OPEN_STRINGS = {
  en: { open: 'Open', upload: 'Upload from computer…', empty: 'No matching files', up: 'Up' },
  ko: { open: '열기', upload: '컴퓨터에서 업로드…', empty: '열 수 있는 파일이 없습니다', up: '상위 폴더' },
} as const

/**
 * Open: browse the user's tree for a file with one of `exts`, or upload one
 * from the computer into the folder being viewed. Resolves to its path.
 */
export async function pickServerFile(opts: { exts: string[]; title?: string }): Promise<string | null> {
  const s = t()
  const o = (document.documentElement.lang || navigator.language || 'en').startsWith('ko')
    ? OPEN_STRINGS.ko
    : OPEN_STRINGS.en
  const exts = opts.exts.map((e) => (e.startsWith('.') ? e : `.${e}`).toLowerCase())
  const accepts = (name: string) => exts.some((e) => name.toLowerCase().endsWith(e))
  return modal<string | null>((close) => {
    let dir = '/'
    const crumb = el('div', { style: 'font-size:12px;color:var(--text-secondary,#666);margin-bottom:6px' } as never)
    const list = el('div', {
      style:
        'height:300px;overflow:auto;border:1px solid var(--border,#ddd);border-radius:6px;padding:4px' as never,
    } as never)
    const row = (label: string, onClick: () => void, bold = false) => {
      const b = el('button', { textContent: label, onclick: onClick })
      b.style.cssText = `display:block;width:100%;text-align:left;border:0;background:none;padding:6px 8px;border-radius:4px;${bold ? 'font-weight:600' : ''}`
      b.onmouseenter = () => (b.style.background = 'var(--hover,#f0f0f0)')
      b.onmouseleave = () => (b.style.background = 'none')
      return b
    }
    const render = async () => {
      crumb.textContent = dir === '/' ? s.root : `${s.root}${dir}`
      list.replaceChildren()
      if (dir !== '/') {
        list.append(row(`⬑ ${o.up}`, () => {
          dir = dir.slice(0, dir.lastIndexOf('/')) || '/'
          void render()
        }))
      }
      let entries: ListEntry[] = []
      try {
        entries = await http.get<ListEntry[]>(`/api/fs/list?${new URLSearchParams({ path: dir })}`)
      } catch {
        entries = []
      }
      const shown = entries.filter((e) => e.isDir || accepts(e.name))
      for (const e of shown) {
        list.append(
          e.isDir
            ? row(`📁 ${e.name}`, () => {
                dir = e.path
                void render()
              }, true)
            : row(`📄 ${e.name}`, () => close(e.path)),
        )
      }
      if (shown.length === 0) {
        list.append(el('div', { textContent: o.empty, style: 'padding:12px;color:var(--text-secondary,#888)' } as never))
      }
    }
    const upload = el('button', {
      textContent: o.upload,
      onclick: () => {
        const input = el('input', { type: 'file', accept: exts.join(',') })
        input.onchange = async () => {
          const file = input.files?.[0]
          if (!file) return
          const { path } = await http.get<{ path: string }>(
            `/api/fs/unique?${new URLSearchParams({ dir, name: file.name })}`,
          )
          await http.put(`/api/fs/raw?${new URLSearchParams({ path })}`, file)
          close(path)
        }
        input.click()
      },
    })
    void render()
    return el('div', { className: 'ow-dialog', style: 'width:min(520px,calc(100vw - 32px))' } as never, [
      el('h2', { textContent: opts.title ?? o.open }),
      crumb,
      list,
      el('div', { className: 'ow-actions', style: 'justify-content:space-between' } as never, [
        upload,
        el('button', { textContent: s.cancel, onclick: () => close(null) }),
      ]),
    ])
  }, null)
}

export function toast(message: string, ms = 2600): void {
  ensureStyles()
  const node = el('div', { className: 'ow-toast', textContent: message })
  document.body.append(node)
  setTimeout(() => node.remove(), ms)
}
