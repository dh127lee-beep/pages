import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import type { Plugin } from 'vite'
import { defineConfig } from 'vitest/config'

const ROOT = dirname(fileURLToPath(import.meta.url))
const UPSTREAM = join(ROOT, 'upstream', 'soffice')

/**
 * Our server imports upstream workspace packages (@soffice/*) and their
 * dependencies, which are installed only in the vendored tree. The server
 * bundle finds them through esbuild nodePaths; tests resolve them the same
 * way: anything our own files cannot resolve is retried from upstream's root.
 */
function upstreamModules(): Plugin {
  return {
    name: 'office-web-upstream-modules',
    enforce: 'pre',
    async resolveId(source, importer, options) {
      if (!importer || source.startsWith('.') || source.startsWith('/') || source.startsWith('\0')) return null
      if (source.startsWith('node:')) return null
      const own = await this.resolve(source, importer, { ...options, skipSelf: true })
      if (own) return own
      return this.resolve(source, join(UPSTREAM, 'package.json'), { ...options, skipSelf: true })
    },
  }
}

export default defineConfig({
  plugins: [upstreamModules()],
  define: { __OFFICE_WEB_ROOT__: JSON.stringify(ROOT) },
  test: {
    include: ['tests/**/*.test.ts'],
    environment: 'node',
    testTimeout: 60_000,
    hookTimeout: 60_000,
    pool: 'forks',
  },
})
