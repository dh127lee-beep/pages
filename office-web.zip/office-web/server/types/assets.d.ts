// Vite/esbuild asset imports used by vendored upstream sources (resolved by the build plugins)
declare module '*?raw' {
  const text: string
  export default text
}
declare module '*?asset' {
  const path: string
  export default path
}
declare module '*.css'
declare module 'bidi-js'
