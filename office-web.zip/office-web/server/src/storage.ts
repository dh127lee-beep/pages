/**
 * Per-user file tree. Editors address files by virtual POSIX paths rooted at
 * "/" ("/Reports/q3.docx"); this module maps them onto
 * DATA_DIR/users/<id>/files and refuses anything that would escape it.
 */

import { createHash, randomBytes } from 'node:crypto'
import { createReadStream, existsSync, mkdirSync } from 'node:fs'
import * as fsp from 'node:fs/promises'
import { join, posix } from 'node:path'
import { config } from './config'

export class StorageError extends Error {
  constructor(
    readonly status: 400 | 403 | 404 | 409 | 413,
    message: string,
  ) {
    super(message)
  }
}

export interface Entry {
  path: string
  name: string
  isDir: boolean
  size: number
  mtimeMs: number
}

const FORBIDDEN_NAME = /[\u0000-\u001f<>:"|?*\\]/

/** "/a/b.docx" with "..", empty segments, control characters and reserved names rejected */
export function normalizeVirtualPath(input: unknown): string {
  if (typeof input !== 'string' || input.length === 0 || input.length > 1024) {
    throw new StorageError(400, 'Invalid path')
  }
  let p = input.replace(/\\/g, '/')
  if (!p.startsWith('/')) p = `/${p}`
  const segments = p.split('/').filter((s) => s.length > 0)
  for (const s of segments) {
    if (s === '.' || s === '..') throw new StorageError(400, 'Invalid path')
    if (FORBIDDEN_NAME.test(s) || s.length > 255) throw new StorageError(400, `Invalid name: ${s}`)
  }
  return `/${segments.join('/')}`
}

export function validateName(name: unknown): string {
  if (typeof name !== 'string') throw new StorageError(400, 'Invalid name')
  const n = name.trim()
  if (!n || n === '.' || n === '..' || n.includes('/') || FORBIDDEN_NAME.test(n) || n.length > 255) {
    throw new StorageError(400, 'Invalid name')
  }
  return n
}

export function userDir(userId: string): string {
  if (!/^[0-9a-f-]{36}$/.test(userId)) throw new Error('bad user id')
  return join(config.dataDir, 'users', userId)
}

export class UserStorage {
  readonly root: string
  /** private per-user state outside the visible tree (chat history, attachments, recovery) */
  readonly appData: string

  constructor(readonly userId: string) {
    const base = userDir(userId)
    this.root = join(base, 'files')
    this.appData = join(base, 'appdata')
    mkdirSync(this.root, { recursive: true })
    mkdirSync(this.appData, { recursive: true })
  }

  /** absolute disk path for a virtual path */
  resolve(virtualPath: unknown): string {
    const v = normalizeVirtualPath(virtualPath)
    return v === '/' ? this.root : join(this.root, ...v.slice(1).split('/'))
  }

  toVirtual(diskPath: string): string {
    const rel = diskPath.slice(this.root.length).split(/[\\/]/).filter(Boolean).join('/')
    return `/${rel}`
  }

  async stat(virtualPath: string): Promise<Entry> {
    const v = normalizeVirtualPath(virtualPath)
    try {
      const st = await fsp.stat(this.resolve(v))
      return {
        path: v,
        name: v === '/' ? '' : posix.basename(v),
        isDir: st.isDirectory(),
        size: st.isDirectory() ? 0 : st.size,
        mtimeMs: Math.round(st.mtimeMs),
      }
    } catch (err) {
      if ((err as NodeJS.ErrnoException).code === 'ENOENT') throw new StorageError(404, 'Not found')
      throw err
    }
  }

  async exists(virtualPath: string): Promise<boolean> {
    return existsSync(this.resolve(virtualPath))
  }

  async list(dir: string): Promise<Entry[]> {
    const v = normalizeVirtualPath(dir)
    const abs = this.resolve(v)
    let names: string[]
    try {
      names = await fsp.readdir(abs)
    } catch (err) {
      if ((err as NodeJS.ErrnoException).code === 'ENOENT') throw new StorageError(404, 'Not found')
      if ((err as NodeJS.ErrnoException).code === 'ENOTDIR') throw new StorageError(400, 'Not a folder')
      throw err
    }
    const out: Entry[] = []
    for (const name of names) {
      if (name.startsWith('.~') || name === '.DS_Store') continue
      try {
        const st = await fsp.stat(join(abs, name))
        out.push({
          path: v === '/' ? `/${name}` : `${v}/${name}`,
          name,
          isDir: st.isDirectory(),
          size: st.isDirectory() ? 0 : st.size,
          mtimeMs: Math.round(st.mtimeMs),
        })
      } catch {
        // vanished between readdir and stat
      }
    }
    out.sort((a, b) => (a.isDir === b.isDir ? a.name.localeCompare(b.name) : a.isDir ? -1 : 1))
    return out
  }

  /** every folder in the tree (for Save As pickers), depth-capped */
  async listDirs(maxDepth = 6): Promise<string[]> {
    const out: string[] = []
    const walk = async (v: string, depth: number) => {
      if (depth > maxDepth) return
      for (const e of await this.list(v).catch(() => [])) {
        if (e.isDir) {
          out.push(e.path)
          await walk(e.path, depth + 1)
        }
      }
    }
    await walk('/', 0)
    return out
  }

  /** every file in the tree, for search */
  async walkFiles(limit = 20_000): Promise<Entry[]> {
    const out: Entry[] = []
    const walk = async (v: string) => {
      for (const e of await this.list(v).catch(() => [])) {
        if (out.length >= limit) return
        if (e.isDir) await walk(e.path)
        else out.push(e)
      }
    }
    await walk('/')
    return out
  }

  async read(virtualPath: string): Promise<Buffer> {
    const abs = this.resolve(virtualPath)
    try {
      const st = await fsp.stat(abs)
      if (st.isDirectory()) throw new StorageError(400, 'Is a folder')
      return await fsp.readFile(abs)
    } catch (err) {
      if ((err as NodeJS.ErrnoException).code === 'ENOENT') throw new StorageError(404, 'Not found')
      throw err
    }
  }

  readStream(virtualPath: string) {
    return createReadStream(this.resolve(virtualPath))
  }

  async hash(virtualPath: string): Promise<string> {
    return sha256(await this.read(virtualPath))
  }

  async usage(): Promise<number> {
    let total = 0
    for (const e of await this.walkFiles(1_000_000)) total += e.size
    return total
  }

  /**
   * Atomic write (temp file + rename). `overwrite: false` refuses an existing
   * file; `expectHash` refuses when the file changed since it was opened.
   */
  async write(
    virtualPath: string,
    data: Uint8Array,
    opts: { overwrite?: boolean; expectHash?: string; mkdirs?: boolean } = {},
  ): Promise<Entry> {
    const v = normalizeVirtualPath(virtualPath)
    if (v === '/') throw new StorageError(400, 'Invalid path')
    const abs = this.resolve(v)
    const parent = posix.dirname(v)
    const parentAbs = this.resolve(parent)
    if (opts.mkdirs) await fsp.mkdir(parentAbs, { recursive: true })
    else if (!existsSync(parentAbs)) throw new StorageError(404, 'Folder not found')
    const exists = existsSync(abs)
    if (exists && opts.overwrite === false) throw new StorageError(409, 'File already exists')
    if (exists && opts.expectHash) {
      const current = sha256(await fsp.readFile(abs))
      if (current !== opts.expectHash) throw new StorageError(409, 'File was modified elsewhere')
    }
    if (config.quotaBytes > 0) {
      const used = await this.usage()
      const previous = exists ? (await fsp.stat(abs)).size : 0
      if (used - previous + data.byteLength > config.quotaBytes) {
        throw new StorageError(413, 'Storage quota exceeded')
      }
    }
    const tmp = join(parentAbs, `.~${randomBytes(6).toString('hex')}.tmp`)
    await fsp.writeFile(tmp, data)
    await fsp.rename(tmp, abs)
    return this.stat(v)
  }

  async mkdir(virtualPath: string): Promise<Entry> {
    const v = normalizeVirtualPath(virtualPath)
    const abs = this.resolve(v)
    if (existsSync(abs)) throw new StorageError(409, 'Already exists')
    await fsp.mkdir(abs, { recursive: true })
    return this.stat(v)
  }

  async move(from: string, to: string, opts: { overwrite?: boolean } = {}): Promise<Entry> {
    const src = normalizeVirtualPath(from)
    const dst = normalizeVirtualPath(to)
    if (src === '/' || dst === '/') throw new StorageError(400, 'Invalid path')
    if (dst === src) return this.stat(src)
    if (dst.startsWith(`${src}/`)) throw new StorageError(400, 'Cannot move a folder into itself')
    const srcAbs = this.resolve(src)
    const dstAbs = this.resolve(dst)
    if (!existsSync(srcAbs)) throw new StorageError(404, 'Not found')
    if (!existsSync(this.resolve(posix.dirname(dst)))) throw new StorageError(404, 'Folder not found')
    const caseOnly = src.toLowerCase() === dst.toLowerCase()
    if (existsSync(dstAbs) && !caseOnly && !opts.overwrite) {
      throw new StorageError(409, 'Already exists')
    }
    await fsp.rename(srcAbs, dstAbs)
    return this.stat(dst)
  }

  async copy(from: string, to: string): Promise<Entry> {
    const src = normalizeVirtualPath(from)
    const dst = normalizeVirtualPath(to)
    if (existsSync(this.resolve(dst))) throw new StorageError(409, 'Already exists')
    await fsp.cp(this.resolve(src), this.resolve(dst), { recursive: true, errorOnExist: true })
    return this.stat(dst)
  }

  /** deleted items go to a per-user trash so a mistaken delete can be undone */
  async remove(virtualPath: string): Promise<void> {
    const v = normalizeVirtualPath(virtualPath)
    if (v === '/') throw new StorageError(400, 'Cannot delete the root folder')
    const abs = this.resolve(v)
    if (!existsSync(abs)) throw new StorageError(404, 'Not found')
    const trash = join(this.appData, 'trash')
    await fsp.mkdir(trash, { recursive: true })
    const id = `${Date.now()}-${randomBytes(4).toString('hex')}`
    await fsp.rename(abs, join(trash, id))
    await fsp.writeFile(join(trash, `${id}.json`), JSON.stringify({ path: v, deletedAt: Date.now() }))
  }

  async listTrash(): Promise<Array<{ id: string; path: string; deletedAt: number }>> {
    const trash = join(this.appData, 'trash')
    const names = await fsp.readdir(trash).catch(() => [] as string[])
    const out: Array<{ id: string; path: string; deletedAt: number }> = []
    for (const n of names) {
      if (!n.endsWith('.json')) continue
      try {
        const meta = JSON.parse(await fsp.readFile(join(trash, n), 'utf8'))
        out.push({ id: n.slice(0, -5), path: meta.path, deletedAt: meta.deletedAt })
      } catch {
        // skip broken metadata
      }
    }
    return out.sort((a, b) => b.deletedAt - a.deletedAt)
  }

  async restoreTrash(id: string): Promise<Entry> {
    if (!/^[0-9]+-[0-9a-f]{8}$/.test(id)) throw new StorageError(400, 'Invalid id')
    const trash = join(this.appData, 'trash')
    const meta = JSON.parse(await fsp.readFile(join(trash, `${id}.json`), 'utf8')) as { path: string }
    let target = meta.path
    if (existsSync(this.resolve(target))) target = await this.uniquePath(posix.dirname(target), posix.basename(target))
    await fsp.mkdir(this.resolve(posix.dirname(target)), { recursive: true })
    await fsp.rename(join(trash, id), this.resolve(target))
    await fsp.rm(join(trash, `${id}.json`), { force: true })
    return this.stat(target)
  }

  async emptyTrash(): Promise<void> {
    await fsp.rm(join(this.appData, 'trash'), { recursive: true, force: true })
  }

  /** "Document.docx" → "Document 2.docx" … until free */
  async uniquePath(dir: string, name: string): Promise<string> {
    const d = normalizeVirtualPath(dir)
    const n = validateName(name)
    const dot = n.lastIndexOf('.')
    const stem = dot > 0 ? n.slice(0, dot) : n
    const ext = dot > 0 ? n.slice(dot) : ''
    for (let i = 1; i < 10_000; i++) {
      const candidate = i === 1 ? n : `${stem} ${i}${ext}`
      const v = d === '/' ? `/${candidate}` : `${d}/${candidate}`
      if (!existsSync(this.resolve(v))) return v
    }
    throw new StorageError(409, 'No free name')
  }

  /** private app-state directory (not visible in the tree) */
  appDataDir(...parts: string[]): string {
    const dir = join(this.appData, ...parts)
    mkdirSync(dir, { recursive: true })
    return dir
  }
}

export function sha256(data: Uint8Array): string {
  return createHash('sha256').update(data).digest('hex')
}

const cache = new Map<string, UserStorage>()

export function storageFor(userId: string): UserStorage {
  let s = cache.get(userId)
  if (!s) {
    s = new UserStorage(userId)
    cache.set(userId, s)
  }
  return s
}

export const MIME_BY_EXT: Record<string, string> = {
  '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  '.dotx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.template',
  '.doc': 'application/msword',
  '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  '.xlsm': 'application/vnd.ms-excel.sheet.macroEnabled.12',
  '.xls': 'application/vnd.ms-excel',
  '.csv': 'text/csv; charset=utf-8',
  '.pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
  '.ppt': 'application/vnd.ms-powerpoint',
  '.pdf': 'application/pdf',
  '.md': 'text/markdown; charset=utf-8',
  '.markdown': 'text/markdown; charset=utf-8',
  '.html': 'text/html; charset=utf-8',
  '.htm': 'text/html; charset=utf-8',
  '.txt': 'text/plain; charset=utf-8',
  '.json': 'application/json',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.webp': 'image/webp',
  '.svg': 'image/svg+xml',
  '.odt': 'application/vnd.oasis.opendocument.text',
  '.ods': 'application/vnd.oasis.opendocument.spreadsheet',
  '.odp': 'application/vnd.oasis.opendocument.presentation',
  '.rtf': 'application/rtf',
  '.zip': 'application/zip',
}

export function mimeFor(path: string): string {
  const ext = posix.extname(path).toLowerCase()
  return MIME_BY_EXT[ext] ?? 'application/octet-stream'
}
