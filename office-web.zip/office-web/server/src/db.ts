import { mkdirSync } from 'node:fs'
import { join } from 'node:path'
import { DatabaseSync } from 'node:sqlite'
import { config } from './config'

export interface UserRow {
  id: string
  username: string
  display_name: string
  pass_hash: string
  is_admin: number
  created_at: number
}

let db: DatabaseSync | null = null

export function getDb(): DatabaseSync {
  if (db) return db
  mkdirSync(config.dataDir, { recursive: true })
  db = new DatabaseSync(join(config.dataDir, 'office.db'))
  db.exec(`
    PRAGMA journal_mode = WAL;
    PRAGMA foreign_keys = ON;
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      username TEXT NOT NULL UNIQUE COLLATE NOCASE,
      display_name TEXT NOT NULL DEFAULT '',
      pass_hash TEXT NOT NULL,
      is_admin INTEGER NOT NULL DEFAULT 0,
      created_at INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS sessions (
      token_hash TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      expires_at INTEGER NOT NULL,
      created_at INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS user_settings (
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      key TEXT NOT NULL,
      value TEXT NOT NULL,
      PRIMARY KEY (user_id, key)
    );
    CREATE TABLE IF NOT EXISTS recent_files (
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      path TEXT NOT NULL,
      opened_at INTEGER NOT NULL,
      PRIMARY KEY (user_id, path)
    );
    CREATE TABLE IF NOT EXISTS starred_files (
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      path TEXT NOT NULL,
      starred_at INTEGER NOT NULL,
      PRIMARY KEY (user_id, path)
    );
    CREATE TABLE IF NOT EXISTS server_settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );
  `)
  return db
}

export function closeDb(): void {
  db?.close()
  db = null
}

// ---- per-user JSON settings -------------------------------------------------

export function getUserSetting<T>(userId: string, key: string, fallback: T): T {
  const row = getDb()
    .prepare('SELECT value FROM user_settings WHERE user_id = ? AND key = ?')
    .get(userId, key) as { value: string } | undefined
  if (!row) return fallback
  try {
    return JSON.parse(row.value) as T
  } catch {
    return fallback
  }
}

export function setUserSetting(userId: string, key: string, value: unknown): void {
  getDb()
    .prepare(
      `INSERT INTO user_settings (user_id, key, value) VALUES (?, ?, ?)
       ON CONFLICT(user_id, key) DO UPDATE SET value = excluded.value`,
    )
    .run(userId, key, JSON.stringify(value))
}

export function getServerSetting<T>(key: string, fallback: T): T {
  const row = getDb().prepare('SELECT value FROM server_settings WHERE key = ?').get(key) as
    | { value: string }
    | undefined
  if (!row) return fallback
  try {
    return JSON.parse(row.value) as T
  } catch {
    return fallback
  }
}

export function setServerSetting(key: string, value: unknown): void {
  getDb()
    .prepare(
      `INSERT INTO server_settings (key, value) VALUES (?, ?)
       ON CONFLICT(key) DO UPDATE SET value = excluded.value`,
    )
    .run(key, JSON.stringify(value))
}

// ---- recent / starred --------------------------------------------------------

export function touchRecent(userId: string, path: string): void {
  const d = getDb()
  d.prepare(
    `INSERT INTO recent_files (user_id, path, opened_at) VALUES (?, ?, ?)
     ON CONFLICT(user_id, path) DO UPDATE SET opened_at = excluded.opened_at`,
  ).run(userId, path, Date.now())
  // keep the list bounded
  d.prepare(
    `DELETE FROM recent_files WHERE user_id = ? AND path NOT IN (
       SELECT path FROM recent_files WHERE user_id = ? ORDER BY opened_at DESC LIMIT 100)`,
  ).run(userId, userId)
}

export function listRecent(userId: string, limit = 30): Array<{ path: string; openedAt: number }> {
  const rows = getDb()
    .prepare(
      'SELECT path, opened_at FROM recent_files WHERE user_id = ? ORDER BY opened_at DESC LIMIT ?',
    )
    .all(userId, limit) as Array<{ path: string; opened_at: number }>
  return rows.map((r) => ({ path: r.path, openedAt: r.opened_at }))
}

export function listStarred(userId: string): string[] {
  const rows = getDb()
    .prepare('SELECT path FROM starred_files WHERE user_id = ? ORDER BY starred_at DESC')
    .all(userId) as Array<{ path: string }>
  return rows.map((r) => r.path)
}

export function setStarred(userId: string, path: string, starred: boolean): void {
  const d = getDb()
  if (starred) {
    d.prepare(
      'INSERT OR IGNORE INTO starred_files (user_id, path, starred_at) VALUES (?, ?, ?)',
    ).run(userId, path, Date.now())
  } else {
    d.prepare('DELETE FROM starred_files WHERE user_id = ? AND path = ?').run(userId, path)
  }
}

/** a file or folder moved: carry its recent/starred entries along */
export function renamePathRefs(userId: string, from: string, to: string): void {
  const d = getDb()
  for (const table of ['recent_files', 'starred_files']) {
    d.prepare(`UPDATE OR REPLACE ${table} SET path = ? WHERE user_id = ? AND path = ?`).run(
      to,
      userId,
      from,
    )
    d.prepare(
      `UPDATE OR REPLACE ${table} SET path = ? || substr(path, ?) WHERE user_id = ? AND path LIKE ? ESCAPE '\\'`,
    ).run(to, from.length + 1, userId, `${escapeLike(from)}/%`)
  }
}

export function deletePathRefs(userId: string, path: string): void {
  const d = getDb()
  for (const table of ['recent_files', 'starred_files']) {
    d.prepare(
      `DELETE FROM ${table} WHERE user_id = ? AND (path = ? OR path LIKE ? ESCAPE '\\')`,
    ).run(userId, path, `${escapeLike(path)}/%`)
  }
}

function escapeLike(s: string): string {
  return s.replace(/[\\%_]/g, (m) => `\\${m}`)
}
