import { existsSync } from 'node:fs'
import { dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

function envInt(name: string, fallback: number): number {
  const raw = process.env[name]
  const n = raw ? Number.parseInt(raw, 10) : NaN
  return Number.isFinite(n) ? n : fallback
}

function envBool(name: string, fallback: boolean): boolean {
  const raw = process.env[name]?.trim().toLowerCase()
  if (!raw) return fallback
  return raw === '1' || raw === 'true' || raw === 'yes' || raw === 'on'
}

declare const __OFFICE_WEB_ROOT__: string | undefined

/** dist/server/index.mjs → project root (two levels up), also right for src/ under tsx/vitest */
function projectRoot(): string {
  if (process.env.OFFICE_WEB_ROOT) return resolve(process.env.OFFICE_WEB_ROOT)
  let dir = dirname(fileURLToPath(import.meta.url))
  for (let i = 0; i < 5; i++) {
    if (existsSync(join(dir, 'package.json')) && existsSync(join(dir, 'upstream'))) return dir
    dir = dirname(dir)
  }
  // a bundle built outside the tree (SERVER_OUT) remembers where it was built from
  if (typeof __OFFICE_WEB_ROOT__ === 'string' && existsSync(__OFFICE_WEB_ROOT__)) return __OFFICE_WEB_ROOT__
  return process.cwd()
}

const root = projectRoot()

export const config = {
  root,
  host: process.env.HOST ?? '0.0.0.0',
  port: envInt('PORT', 8080),
  /** users, sessions, files, chat history */
  dataDir: resolve(process.env.DATA_DIR ?? join(root, 'data')),
  /** built home page and editors */
  publicDir: resolve(process.env.PUBLIC_DIR ?? join(root, 'dist', 'public')),
  /** server-side helper binaries and bundles (CLI, xlsx sidecar) */
  toolsDir: resolve(process.env.TOOLS_DIR ?? join(root, 'dist', 'tools')),
  /** anyone may create an account (the very first account is always allowed and becomes admin) */
  allowSignup: envBool('ALLOW_SIGNUP', false),
  /** set behind HTTPS so the session cookie gets the Secure flag */
  secureCookies: envBool('SECURE_COOKIES', false),
  sessionDays: envInt('SESSION_DAYS', 30),
  maxUploadBytes: envInt('MAX_UPLOAD_MB', 200) * 1024 * 1024,
  /** per-user storage quota; 0 = unlimited */
  quotaBytes: envInt('QUOTA_MB', 0) * 1024 * 1024,
  /** create the admin account on first boot (non-interactive deployments) */
  adminUser: process.env.ADMIN_USER ?? '',
  adminPassword: process.env.ADMIN_PASSWORD ?? '',
  /** extra origins allowed to send state-changing requests (comma separated) */
  trustedOrigins: (process.env.TRUSTED_ORIGINS ?? '')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean),
}

export type Config = typeof config
