import { createHash, randomBytes, randomUUID, scrypt, timingSafeEqual } from 'node:crypto'
import type { Context, MiddlewareHandler } from 'hono'
import { deleteCookie, getCookie, setCookie } from 'hono/cookie'
import { config } from './config'
import { getDb, type UserRow } from './db'

export const SESSION_COOKIE = 'office_session'

export interface User {
  id: string
  username: string
  displayName: string
  isAdmin: boolean
}

export type AppEnv = { Variables: { user: User } }

function toUser(row: UserRow): User {
  return {
    id: row.id,
    username: row.username,
    displayName: row.display_name || row.username,
    isAdmin: row.is_admin === 1,
  }
}

function scryptAsync(password: string, salt: Buffer): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    scrypt(password, salt, 64, { N: 16384, r: 8, p: 1 }, (err, key) =>
      err ? reject(err) : resolve(key),
    )
  })
}

export async function hashPassword(password: string): Promise<string> {
  const salt = randomBytes(16)
  const key = await scryptAsync(password, salt)
  return `scrypt$${salt.toString('base64')}$${key.toString('base64')}`
}

export async function verifyPassword(password: string, stored: string): Promise<boolean> {
  const [scheme, saltB64, keyB64] = stored.split('$')
  if (scheme !== 'scrypt' || !saltB64 || !keyB64) return false
  const expected = Buffer.from(keyB64, 'base64')
  const actual = await scryptAsync(password, Buffer.from(saltB64, 'base64'))
  return actual.length === expected.length && timingSafeEqual(actual, expected)
}

const USERNAME_RE = /^[a-zA-Z0-9][a-zA-Z0-9._-]{1,31}$/

export function validateCredentials(username: unknown, password: unknown): string | null {
  if (typeof username !== 'string' || !USERNAME_RE.test(username)) {
    return 'Username must be 2–32 characters: letters, digits, dot, dash or underscore'
  }
  if (typeof password !== 'string' || password.length < 8 || password.length > 256) {
    return 'Password must be at least 8 characters'
  }
  return null
}

export function userCount(): number {
  const row = getDb().prepare('SELECT COUNT(*) AS n FROM users').get() as { n: number }
  return row.n
}

export async function createUser(
  username: string,
  password: string,
  opts: { displayName?: string; isAdmin?: boolean } = {},
): Promise<User> {
  const row: UserRow = {
    id: randomUUID(),
    username,
    display_name: opts.displayName?.trim() || username,
    pass_hash: await hashPassword(password),
    is_admin: opts.isAdmin ? 1 : 0,
    created_at: Date.now(),
  }
  getDb()
    .prepare(
      'INSERT INTO users (id, username, display_name, pass_hash, is_admin, created_at) VALUES (?, ?, ?, ?, ?, ?)',
    )
    .run(row.id, row.username, row.display_name, row.pass_hash, row.is_admin, row.created_at)
  return toUser(row)
}

export function findUserByName(username: string): UserRow | undefined {
  return getDb().prepare('SELECT * FROM users WHERE username = ?').get(username) as
    | UserRow
    | undefined
}

export function getUser(id: string): User | null {
  const row = getDb().prepare('SELECT * FROM users WHERE id = ?').get(id) as UserRow | undefined
  return row ? toUser(row) : null
}

export function listUsers(): User[] {
  const rows = getDb().prepare('SELECT * FROM users ORDER BY created_at').all() as unknown as UserRow[]
  return rows.map(toUser)
}

export function updateDisplayName(id: string, displayName: string): void {
  getDb().prepare('UPDATE users SET display_name = ? WHERE id = ?').run(displayName, id)
}

export async function changePassword(id: string, password: string): Promise<void> {
  getDb()
    .prepare('UPDATE users SET pass_hash = ? WHERE id = ?')
    .run(await hashPassword(password), id)
  getDb().prepare('DELETE FROM sessions WHERE user_id = ?').run(id)
}

export function deleteUser(id: string): void {
  getDb().prepare('DELETE FROM users WHERE id = ?').run(id)
}

const tokenHash = (token: string) => createHash('sha256').update(token).digest('hex')

export function startSession(c: Context, user: User): void {
  const token = randomBytes(32).toString('base64url')
  const now = Date.now()
  const expires = now + config.sessionDays * 86_400_000
  getDb()
    .prepare('INSERT INTO sessions (token_hash, user_id, expires_at, created_at) VALUES (?, ?, ?, ?)')
    .run(tokenHash(token), user.id, expires, now)
  setCookie(c, SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: 'Lax',
    secure: config.secureCookies,
    path: '/',
    maxAge: config.sessionDays * 86_400,
  })
}

export function endSession(c: Context): void {
  const token = getCookie(c, SESSION_COOKIE)
  if (token) getDb().prepare('DELETE FROM sessions WHERE token_hash = ?').run(tokenHash(token))
  deleteCookie(c, SESSION_COOKIE, { path: '/' })
}

export function sessionUser(c: Context): User | null {
  const token = getCookie(c, SESSION_COOKIE)
  if (!token) return null
  const row = getDb()
    .prepare(
      `SELECT u.* FROM sessions s JOIN users u ON u.id = s.user_id
       WHERE s.token_hash = ? AND s.expires_at > ?`,
    )
    .get(tokenHash(token), Date.now()) as UserRow | undefined
  return row ? toUser(row) : null
}

export function pruneSessions(): void {
  getDb().prepare('DELETE FROM sessions WHERE expires_at <= ?').run(Date.now())
}

/** 401 for API calls without a session; the user is available as c.get('user') */
export const requireUser: MiddlewareHandler<AppEnv> = async (c, next) => {
  const user = sessionUser(c)
  if (!user) return c.json({ error: 'Not signed in' }, 401)
  c.set('user', user)
  await next()
}

export const requireAdmin: MiddlewareHandler<AppEnv> = async (c, next) => {
  if (!c.get('user')?.isAdmin) return c.json({ error: 'Administrator only' }, 403)
  await next()
}

/**
 * CSRF guard for state-changing requests: browsers always send Origin on
 * cross-site POST/PUT/DELETE, so a mismatch with our own host is refused.
 */
export const sameOrigin: MiddlewareHandler = async (c, next) => {
  const method = c.req.method
  if (method === 'GET' || method === 'HEAD' || method === 'OPTIONS') return next()
  const origin = c.req.header('origin')
  if (origin) {
    let host = ''
    try {
      host = new URL(origin).host
    } catch {
      return c.json({ error: 'Bad origin' }, 403)
    }
    const expected = c.req.header('x-forwarded-host') ?? c.req.header('host')
    if (host !== expected && !config.trustedOrigins.includes(origin)) {
      return c.json({ error: 'Cross-origin request refused' }, 403)
    }
  }
  return next()
}

/** first boot with ADMIN_USER/ADMIN_PASSWORD set and no accounts yet */
export async function ensureBootstrapAdmin(): Promise<void> {
  if (!config.adminUser || !config.adminPassword || userCount() > 0) return
  const problem = validateCredentials(config.adminUser, config.adminPassword)
  if (problem) {
    console.warn(`[auth] ADMIN_USER/ADMIN_PASSWORD ignored: ${problem}`)
    return
  }
  await createUser(config.adminUser, config.adminPassword, { isAdmin: true })
  console.log(`[auth] created administrator "${config.adminUser}"`)
}

/**
 * A short-lived session for server-side rendering: the headless browser that
 * prints a document opens our own editor page as the document's owner.
 * Revoke it as soon as the job ends.
 */
export function mintSessionToken(userId: string, ttlMs = 10 * 60_000): string {
  const token = randomBytes(32).toString('base64url')
  const now = Date.now()
  getDb()
    .prepare('INSERT INTO sessions (token_hash, user_id, expires_at, created_at) VALUES (?, ?, ?, ?)')
    .run(tokenHash(token), userId, now + ttlMs, now)
  return token
}

export function revokeSessionToken(token: string): void {
  getDb().prepare('DELETE FROM sessions WHERE token_hash = ?').run(tokenHash(token))
}
