import { serve } from '@hono/node-server'
import { createApp } from './app'
import { ensureBootstrapAdmin, pruneSessions } from './auth'
import { config } from './config'
import { appModules } from './apps'
import { closeDb, getDb } from './db'
import { closeChrome } from './lib/chrome'

export async function startServer(): Promise<void> {
  getDb()
  await ensureBootstrapAdmin()
  pruneSessions()
  for (const mod of appModules()) await mod.start?.()

  const app = createApp()
  const server = serve({ fetch: app.fetch, hostname: config.host, port: config.port }, (info) => {
    console.log(`[server] office-web listening on http://${info.address}:${info.port}`)
    console.log(`[server] data directory: ${config.dataDir}`)
  })
  const prune = setInterval(pruneSessions, 3_600_000)
  prune.unref()

  let stopping = false
  const shutdown = async (signal: string) => {
    if (stopping) return
    stopping = true
    console.log(`[server] ${signal}: shutting down`)
    server.close()
    for (const mod of appModules()) await Promise.resolve(mod.stop?.()).catch(() => undefined)
    await closeChrome().catch(() => undefined)
    closeDb()
    process.exit(0)
  }
  process.on('SIGINT', () => void shutdown('SIGINT'))
  process.on('SIGTERM', () => void shutdown('SIGTERM'))
}
