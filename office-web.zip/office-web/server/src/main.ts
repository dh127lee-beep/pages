/**
 * Entry point. Upstream helpers resolve per-user state under os.homedir()
 * (desktop sign-ins, caches); on a shared server that must never be the
 * operator's real home, so HOME is pointed into the data directory before
 * any of them is loaded.
 */
import { mkdirSync } from 'node:fs'
import { join } from 'node:path'
import { config } from './config'

const home = join(config.dataDir, '.home')
mkdirSync(home, { recursive: true })
process.env.HOME = home
process.env.USERPROFILE = home

const { startServer } = await import('./index')
await startServer()
