import { existsSync, readFileSync } from 'node:fs'
import { join } from 'node:path'
import { serveStatic } from '@hono/node-server/serve-static'
import { Hono } from 'hono'
import { HTTPException } from 'hono/http-exception'
import { requireUser, sameOrigin, sessionUser, type AppEnv } from './auth'
import { config } from './config'
import { appModules } from './apps'
import './apps/all'
import { accountRoutesMount } from './routes/mount'
import { StorageError } from './storage'

export const APP_IDS = ['docs', 'sheets', 'slides', 'pdf', 'markdown', 'html'] as const

export function createApp(): Hono<AppEnv> {
  const app = new Hono<AppEnv>()

  app.use('*', async (c, next) => {
    await next()
    c.header('x-content-type-options', 'nosniff')
    c.header('referrer-policy', 'same-origin')
    if (!c.res.headers.has('x-frame-options')) c.header('x-frame-options', 'SAMEORIGIN')
  })
  app.use('/api/*', sameOrigin)

  app.onError((err, c) => {
    if (err instanceof StorageError) return c.json({ error: err.message }, err.status)
    if (err instanceof HTTPException) return c.json({ error: err.message }, err.status)
    if (err instanceof SyntaxError) return c.json({ error: 'Malformed request body' }, 400)
    console.error(`[server] ${c.req.method} ${c.req.path}`, err)
    return c.json({ error: 'Internal server error' }, 500)
  })

  app.get('/healthz', (c) => c.json({ ok: true }))

  accountRoutesMount(app)

  for (const mod of appModules()) {
    const sub = new Hono<AppEnv>()
    sub.use('*', requireUser)
    sub.route('/', mod.routes)
    app.route(`/api/apps/${mod.id}`, sub)
    if (mod.publicRoutes) app.route(`/pub/${mod.id}`, mod.publicRoutes)
  }

  app.all('/api/*', (c) => c.json({ error: 'Not found' }, 404))

  // ---- static: editors under /app/<id>/, the home page everywhere else ----
  const pub = config.publicDir
  const noCache = { 'cache-control': 'no-cache' }

  // hashed build output never changes under the same name
  app.use('/assets/*', serveStatic({ root: pub, onFound: immutable }))
  app.use('/app/:id/assets/*', serveStatic({ root: pub, onFound: immutable }))

  // editors need a session; send the browser to sign in first
  app.use('/app/:id/*', async (c, next) => {
    const id = c.req.param('id')
    if (!(APP_IDS as readonly string[]).includes(id)) return c.notFound()
    if (!sessionUser(c)) {
      const nextUrl = encodeURIComponent(c.req.path + (new URL(c.req.url).search || ''))
      return c.redirect(`/login?next=${nextUrl}`)
    }
    await next()
  })
  app.get('/app/:id', (c) => c.redirect(`/app/${c.req.param('id')}/${new URL(c.req.url).search}`))
  app.use(
    '/app/:id/*',
    serveStatic({ root: pub, onFound: (_p, c) => c.header('cache-control', 'no-cache') }),
  )
  app.get('/app/:id/*', (c) => {
    const index = join(pub, 'app', c.req.param('id'), 'index.html')
    if (!existsSync(index)) return c.text(`The ${c.req.param('id')} editor is not built`, 404)
    return c.html(readFileSync(index, 'utf8'), 200, noCache)
  })

  app.get('/login', (c) => {
    const page = join(pub, 'login.html')
    if (!existsSync(page)) return c.text('Login page is not built. Run "npm run build".', 503)
    return c.html(readFileSync(page, 'utf8'), 200, noCache)
  })
  // the home page needs a session too
  app.get('/', async (c, next) => {
    if (!sessionUser(c)) return c.redirect('/login')
    await next()
  })

  app.use('*', serveStatic({ root: pub, onFound: (_p, c) => c.header('cache-control', 'no-cache') }))
  app.get('*', (c) => {
    const index = join(pub, 'index.html')
    if (!existsSync(index)) return c.text('Home page is not built. Run "npm run build".', 503)
    return c.html(readFileSync(index, 'utf8'), 200, noCache)
  })

  return app
}

function immutable(_path: string, c: { header(name: string, value: string): void }): void {
  c.header('cache-control', 'public, max-age=31536000, immutable')
}
