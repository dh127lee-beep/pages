import { posix } from 'node:path'
import { Readable } from 'node:stream'
import { Hono } from 'hono'
import type { AppEnv } from '../auth'
import { deletePathRefs, listRecent, listStarred, renamePathRefs, setStarred, touchRecent } from '../db'
import { readBody } from '../lib/body'
import { projectFileMoved } from './assist'
import { mimeFor, normalizeVirtualPath, sha256, storageFor, StorageError, validateName } from '../storage'

export const fsRoutes = new Hono<AppEnv>()

const storage = (c: { get(key: 'user'): { id: string } }) => storageFor(c.get('user').id)

/** raw bytes are untrusted user content: never let a browser run them on our origin */
function contentHeaders(path: string, download: boolean): Record<string, string> {
  const name = posix.basename(path)
  const encoded = encodeURIComponent(name)
  return {
    'content-type': mimeFor(path),
    'content-security-policy': "sandbox; default-src 'none'; style-src 'unsafe-inline'; img-src data:",
    'x-content-type-options': 'nosniff',
    'cache-control': 'private, no-cache',
    'content-disposition': `${download ? 'attachment' : 'inline'}; filename*=UTF-8''${encoded}`,
  }
}

fsRoutes.get('/list', async (c) => {
  const path = c.req.query('path') ?? '/'
  const s = storage(c)
  const entries = await s.list(path)
  const starred = new Set(listStarred(c.get('user').id))
  return c.json(entries.map((e) => ({ ...e, starred: starred.has(e.path) })))
})

fsRoutes.get('/stat', async (c) => {
  const path = c.req.query('path')
  const s = storage(c)
  const st = await s.stat(path ?? '')
  if (c.req.query('hash') === '1' && !st.isDir) return c.json({ ...st, hash: await s.hash(st.path) })
  return c.json(st)
})

fsRoutes.get('/raw', async (c) => {
  const path = normalizeVirtualPath(c.req.query('path'))
  const s = storage(c)
  const st = await s.stat(path)
  if (st.isDir) throw new StorageError(400, 'Is a folder')
  const headers = contentHeaders(path, c.req.query('download') === '1')
  headers['content-length'] = String(st.size)
  headers['last-modified'] = new Date(st.mtimeMs).toUTCString()
  const stream = Readable.toWeb(s.readStream(path)) as ReadableStream
  return new Response(stream, { status: 200, headers })
})

fsRoutes.put('/raw', async (c) => {
  const path = normalizeVirtualPath(c.req.query('path'))
  const body = await readBody(c)
  const st = await storage(c).write(path, body, {
    overwrite: c.req.query('overwrite') !== '0',
    expectHash: c.req.query('expectHash') || undefined,
    mkdirs: c.req.query('mkdirs') === '1',
  })
  touchRecent(c.get('user').id, st.path)
  return c.json({ ...st, hash: sha256(body) })
})

fsRoutes.post('/mkdir', async (c) => {
  const { path } = await c.req.json<{ path: string }>()
  return c.json(await storage(c).mkdir(path))
})

fsRoutes.post('/move', async (c) => {
  const { from, to, overwrite } = await c.req.json<{ from: string; to: string; overwrite?: boolean }>()
  const st = await storage(c).move(from, to, { overwrite })
  renamePathRefs(c.get('user').id, normalizeVirtualPath(from), st.path)
  projectFileMoved(c.get('user').id, normalizeVirtualPath(from), st.path)
  return c.json(st)
})

fsRoutes.post('/rename', async (c) => {
  const { path, name } = await c.req.json<{ path: string; name: string }>()
  const src = normalizeVirtualPath(path)
  const dst = posix.join(posix.dirname(src), validateName(name))
  const st = await storage(c).move(src, dst)
  renamePathRefs(c.get('user').id, src, st.path)
  projectFileMoved(c.get('user').id, src, st.path)
  return c.json(st)
})

fsRoutes.post('/copy', async (c) => {
  const { from, to } = await c.req.json<{ from: string; to?: string }>()
  const s = storage(c)
  const src = normalizeVirtualPath(from)
  const target = to
    ? normalizeVirtualPath(to)
    : await s.uniquePath(posix.dirname(src), posix.basename(src))
  return c.json(await s.copy(src, target))
})

fsRoutes.post('/delete', async (c) => {
  const { paths } = await c.req.json<{ paths: string[] }>()
  const s = storage(c)
  for (const p of paths ?? []) {
    const v = normalizeVirtualPath(p)
    await s.remove(v)
    deletePathRefs(c.get('user').id, v)
  }
  return c.json({ ok: true })
})

fsRoutes.get('/unique', async (c) => {
  const path = await storage(c).uniquePath(c.req.query('dir') ?? '/', c.req.query('name') ?? '')
  return c.json({ path })
})

fsRoutes.get('/dirs', async (c) => c.json(await storage(c).listDirs()))

fsRoutes.get('/recent', async (c) => {
  const s = storage(c)
  const out = []
  for (const r of listRecent(c.get('user').id)) {
    try {
      const st = await s.stat(r.path)
      if (!st.isDir) out.push({ ...st, openedAt: r.openedAt })
    } catch {
      // deleted outside the app
    }
  }
  return c.json(out)
})

fsRoutes.post('/recent', async (c) => {
  const { path } = await c.req.json<{ path: string }>()
  touchRecent(c.get('user').id, normalizeVirtualPath(path))
  return c.json({ ok: true })
})

fsRoutes.get('/starred', async (c) => {
  const s = storage(c)
  const out = []
  for (const p of listStarred(c.get('user').id)) {
    try {
      out.push({ ...(await s.stat(p)), starred: true })
    } catch {
      // gone
    }
  }
  return c.json(out)
})

fsRoutes.post('/star', async (c) => {
  const { path, starred } = await c.req.json<{ path: string; starred: boolean }>()
  setStarred(c.get('user').id, normalizeVirtualPath(path), starred !== false)
  return c.json({ ok: true })
})

/** file-name search across the whole tree (content search lives in /api/search) */
fsRoutes.get('/search', async (c) => {
  const q = (c.req.query('q') ?? '').trim().toLowerCase()
  if (!q) return c.json([])
  const all = await storage(c).walkFiles()
  return c.json(all.filter((e) => e.path.toLowerCase().includes(q)).slice(0, 200))
})

fsRoutes.get('/trash', async (c) => c.json(await storage(c).listTrash()))

fsRoutes.post('/trash/restore', async (c) => {
  const { id } = await c.req.json<{ id: string }>()
  return c.json(await storage(c).restoreTrash(id))
})

fsRoutes.post('/trash/empty', async (c) => {
  await storage(c).emptyTrash()
  return c.json({ ok: true })
})

fsRoutes.get('/usage', async (c) => {
  return c.json({ used: await storage(c).usage(), quota: Number(process.env.QUOTA_MB ?? 0) * 1048576 })
})
