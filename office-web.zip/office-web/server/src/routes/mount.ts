import { Hono } from 'hono'
import { requireUser, type AppEnv } from '../auth'
import { adminRoutes, authRoutes, meRoutes } from './account'
import { aiRoutes } from './ai'
import { assistRoutes } from './assist'
import { convertRoutes } from './convert'
import { fsRoutes } from './fs'
import { homeRoutes } from './home'

export function accountRoutesMount(app: Hono<AppEnv>): void {
  app.route('/api/auth', authRoutes)
  app.route('/api/me', meRoutes)
  app.route('/api/admin', adminRoutes)

  const authed = new Hono<AppEnv>()
  authed.use('*', requireUser)
  authed.route('/fs', fsRoutes)
  authed.route('/ai', aiRoutes)
  authed.route('/convert', convertRoutes)
  authed.route('/home', homeRoutes)
  authed.route('/', assistRoutes)
  app.route('/api', authed)
}
