import { Hono } from 'hono'
import {
  changePassword,
  createUser,
  deleteUser,
  endSession,
  findUserByName,
  listUsers,
  requireAdmin,
  requireUser,
  startSession,
  updateDisplayName,
  userCount,
  validateCredentials,
  verifyPassword,
  type AppEnv,
} from '../auth'
import { config } from '../config'
import { getUserSetting, setUserSetting } from '../db'

// the shell's UiLanguage set (editors normalize anything they lack)
const LANGS = [
  'zh', 'en', 'ja', 'ko', 'fr', 'de', 'es', 'th', 'id', 'ru', 'ar',
  'pt', 'it', 'pl', 'cs', 'nl', 'ms', 'he', 'hi', 'zh-TW', 'vi',
]
const THEMES = ['light', 'dark', 'system']
const DOC_THEMES = ['follow', 'light', 'dark']

export interface Prefs {
  language?: string
  theme?: string
  documentTheme?: string
  autoSaveDefault?: { on: boolean; updatedAt: number }
  authorName?: string
  aiPanelPrefs?: Record<string, unknown> | null
}

function sanitizePrefs(input: unknown): Prefs {
  const raw = (input && typeof input === 'object' ? input : {}) as Record<string, unknown>
  const out: Prefs = {}
  if (typeof raw.language === 'string' && LANGS.includes(raw.language)) out.language = raw.language
  if (typeof raw.theme === 'string' && THEMES.includes(raw.theme)) out.theme = raw.theme
  if (typeof raw.documentTheme === 'string' && DOC_THEMES.includes(raw.documentTheme)) {
    out.documentTheme = raw.documentTheme
  }
  const auto = raw.autoSaveDefault as { on?: unknown; updatedAt?: unknown } | undefined
  if (auto && typeof auto === 'object' && typeof auto.on === 'boolean') {
    out.autoSaveDefault = {
      on: auto.on,
      updatedAt: typeof auto.updatedAt === 'number' && auto.updatedAt > 0 ? auto.updatedAt : Date.now(),
    }
  }
  if (typeof raw.authorName === 'string') out.authorName = raw.authorName.slice(0, 120)
  if (raw.aiPanelPrefs && typeof raw.aiPanelPrefs === 'object' && !Array.isArray(raw.aiPanelPrefs)) {
    const json = JSON.stringify(raw.aiPanelPrefs)
    if (json.length < 4096) out.aiPanelPrefs = JSON.parse(json) as Record<string, unknown>
  }
  return out
}

// ---- public: sign in / sign up ------------------------------------------------

export const authRoutes = new Hono<AppEnv>()

authRoutes.get('/status', (c) =>
  c.json({ needsSetup: userCount() === 0, allowSignup: config.allowSignup || userCount() === 0 }),
)

authRoutes.post('/login', async (c) => {
  const { username, password } = await c.req.json<{ username: string; password: string }>()
  const row = typeof username === 'string' ? findUserByName(username) : undefined
  // constant-ish work whether or not the user exists
  const ok = row ? await verifyPassword(String(password ?? ''), row.pass_hash) : false
  if (!row || !ok) return c.json({ error: 'Wrong username or password' }, 401)
  const user = {
    id: row.id,
    username: row.username,
    displayName: row.display_name || row.username,
    isAdmin: row.is_admin === 1,
  }
  startSession(c, user)
  return c.json(user)
})

authRoutes.post('/signup', async (c) => {
  const first = userCount() === 0
  if (!first && !config.allowSignup) return c.json({ error: 'Sign-up is disabled on this server' }, 403)
  const { username, password, displayName } = await c.req.json<{
    username: string
    password: string
    displayName?: string
  }>()
  const problem = validateCredentials(username, password)
  if (problem) return c.json({ error: problem }, 400)
  if (findUserByName(username)) return c.json({ error: 'That username is taken' }, 409)
  const user = await createUser(username, password, { displayName, isAdmin: first })
  startSession(c, user)
  return c.json(user)
})

authRoutes.post('/logout', (c) => {
  endSession(c)
  return c.json({ ok: true })
})

// ---- signed in: profile and preferences ---------------------------------------

export const meRoutes = new Hono<AppEnv>()
meRoutes.use('*', requireUser)

meRoutes.get('/', (c) => {
  const user = c.get('user')
  return c.json({ ...user, prefs: getUserSetting<Prefs>(user.id, 'prefs', {}) })
})

meRoutes.put('/prefs', async (c) => {
  const user = c.get('user')
  const patch = sanitizePrefs(await c.req.json())
  const next = { ...getUserSetting<Prefs>(user.id, 'prefs', {}), ...patch }
  setUserSetting(user.id, 'prefs', next)
  return c.json(next)
})

meRoutes.put('/profile', async (c) => {
  const { displayName } = await c.req.json<{ displayName: string }>()
  if (typeof displayName !== 'string' || !displayName.trim() || displayName.length > 80) {
    return c.json({ error: 'Invalid display name' }, 400)
  }
  updateDisplayName(c.get('user').id, displayName.trim())
  return c.json({ ok: true })
})

meRoutes.put('/password', async (c) => {
  const user = c.get('user')
  const { current, next } = await c.req.json<{ current: string; next: string }>()
  const row = findUserByName(user.username)
  if (!row || !(await verifyPassword(String(current ?? ''), row.pass_hash))) {
    return c.json({ error: 'Current password is wrong' }, 400)
  }
  const problem = validateCredentials(user.username, next)
  if (problem) return c.json({ error: problem }, 400)
  await changePassword(user.id, next)
  startSession(c, user)
  return c.json({ ok: true })
})

// ---- administrator: accounts ------------------------------------------------------

export const adminRoutes = new Hono<AppEnv>()
adminRoutes.use('*', requireUser, requireAdmin)

adminRoutes.get('/users', (c) => c.json(listUsers()))

adminRoutes.post('/users', async (c) => {
  const { username, password, displayName, isAdmin } = await c.req.json<{
    username: string
    password: string
    displayName?: string
    isAdmin?: boolean
  }>()
  const problem = validateCredentials(username, password)
  if (problem) return c.json({ error: problem }, 400)
  if (findUserByName(username)) return c.json({ error: 'That username is taken' }, 409)
  return c.json(await createUser(username, password, { displayName, isAdmin: isAdmin === true }))
})

adminRoutes.put('/users/:id/password', async (c) => {
  const { password } = await c.req.json<{ password: string }>()
  if (typeof password !== 'string' || password.length < 8) {
    return c.json({ error: 'Password must be at least 8 characters' }, 400)
  }
  await changePassword(c.req.param('id'), password)
  return c.json({ ok: true })
})

adminRoutes.delete('/users/:id', (c) => {
  const id = c.req.param('id')
  if (id === c.get('user').id) return c.json({ error: 'You cannot delete your own account' }, 400)
  deleteUser(id)
  return c.json({ ok: true })
})
