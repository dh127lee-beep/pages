/**
 * Document conversion. Two engines, one table:
 *
 *  - "cli": the upstream `soffice` command line (headless, no model calls)
 *    run as a child process — md→docx, pdf→docx/xlsx/pptx, odt→docx, …
 *  - "chrome": conversions the desktop app performs in hidden Electron
 *    windows, done here by a sandboxed headless Chromium (lib/chrome.ts):
 *    html/md→pdf, html→docx, and docx/xlsx/csv/pptx→pdf through the
 *    Docs, Sheets and Slides editors themselves.
 *
 * Outputs are written next to the source (or into `outDir`) under a free
 * name; the source is never touched.
 */

import { mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { basename, extname, join, posix } from 'node:path'
import { Hono } from 'hono'
import type { AppEnv } from '../auth'
import { cliAvailable, CliUnavailableError, runCli, withSlot, xlsxSidecarPath } from '../lib/cli'
import {
  chromeAvailable,
  ChromeUnavailableError,
  EDITOR_PDF_EXTS,
  exportViaEditor,
  htmlToDocx,
  printHtmlToPdf,
} from '../lib/chrome'
import { normalizeVirtualPath, storageFor, StorageError } from '../storage'

type Engine = 'cli' | 'chrome' | 'editor'

interface Route {
  engine: Engine
  /** needs the Rust xlsx engine */
  sidecar?: boolean
}

/** from-extension → to-extension → engine */
export const ROUTES: Record<string, Record<string, Route>> = {
  pdf: { docx: { engine: 'cli' }, pptx: { engine: 'cli' }, xlsx: { engine: 'cli', sidecar: true }, md: { engine: 'cli' } },
  md: { docx: { engine: 'cli' }, html: { engine: 'cli' }, pdf: { engine: 'chrome' } },
  markdown: { docx: { engine: 'cli' }, html: { engine: 'cli' }, pdf: { engine: 'chrome' } },
  docx: { md: { engine: 'cli' }, html: { engine: 'cli' }, pdf: { engine: 'editor' } },
  dotx: { pdf: { engine: 'editor' } },
  html: { pdf: { engine: 'chrome' }, docx: { engine: 'chrome' } },
  htm: { pdf: { engine: 'chrome' }, docx: { engine: 'chrome' } },
  odt: { docx: { engine: 'cli' } },
  ott: { docx: { engine: 'cli' } },
  odp: { pptx: { engine: 'cli' } },
  otp: { pptx: { engine: 'cli' } },
  csv: { xlsx: { engine: 'cli', sidecar: true }, pdf: { engine: 'editor', sidecar: true } },
  xls: { xlsx: { engine: 'cli', sidecar: true } },
  xlsb: { xlsx: { engine: 'cli', sidecar: true } },
  ods: { xlsx: { engine: 'cli', sidecar: true } },
  ots: { xlsx: { engine: 'cli', sidecar: true } },
  xlsx: { csv: { engine: 'cli', sidecar: true }, pdf: { engine: 'editor', sidecar: true } },
  xlsm: { csv: { engine: 'cli', sidecar: true }, pdf: { engine: 'editor', sidecar: true } },
  pptx: { pdf: { engine: 'editor' } },
}

const extOf = (p: string) => extname(p).slice(1).toLowerCase()

async function engineReady(route: Route, from: string): Promise<string | null> {
  if (route.engine === 'editor' && !EDITOR_PDF_EXTS[`.${from}`]) {
    return 'server-side printing of this format through its editor is not available yet'
  }
  if (route.engine === 'cli' && !cliAvailable()) return 'conversion tools are not built'
  if (route.sidecar && !xlsxSidecarPath()) return 'the xlsx engine (xlsx-sidecar) is not built'
  if ((route.engine === 'chrome' || route.engine === 'editor') && !(await chromeAvailable())) {
    return 'no headless Chrome is available on the server (set CHROME_PATH)'
  }
  return null
}

export const convertRoutes = new Hono<AppEnv>()

/** what converts to what on this server, with the reason a route is off */
convertRoutes.get('/formats', async (c) => {
  const out: Record<string, Array<{ to: string; available: boolean; reason?: string }>> = {}
  for (const [from, targets] of Object.entries(ROUTES)) {
    out[from] = []
    for (const [to, route] of Object.entries(targets)) {
      const reason = await engineReady(route, from)
      out[from].push(reason ? { to, available: false, reason } : { to, available: true })
    }
  }
  return c.json(out)
})

function withTemp<T>(fn: (dir: string) => Promise<T>): Promise<T> {
  const dir = mkdtempSync(join(tmpdir(), 'office-web-convert-'))
  return fn(dir).finally(() => rmSync(dir, { recursive: true, force: true }))
}

/** CLI conversion into a temp file; returns its bytes */
async function cliConvert(
  inputDisk: string,
  to: string,
  extra: string[],
): Promise<Uint8Array> {
  return withTemp(async (dir) => {
    const out = join(dir, `${basename(inputDisk, extname(inputDisk))}.${to}`)
    const res = await runCli(['convert', inputDisk, '--to', to, '--out', out, '--force', ...extra])
    if (res.status !== 'ok') {
      throw new ConversionError(res.message ?? res.error ?? 'conversion failed', res.error === 'unsupported' ? 400 : 422)
    }
    return new Uint8Array(readFileSync(res.output_path ?? out))
  })
}

class ConversionError extends Error {
  constructor(
    message: string,
    readonly status: 400 | 422 | 501 | 503 = 422,
  ) {
    super(message)
  }
}

/** pick a mutable copy of the HTML a Markdown file renders to (CLI md→html) */
async function markdownHtml(inputDisk: string): Promise<string> {
  const html = new TextDecoder().decode(await cliConvert(inputDisk, 'html', []))
  return html.includes('</head>') ? html.replace('</head>', `${MARKDOWN_PRINT_CSS}</head>`) : MARKDOWN_PRINT_CSS + html
}

/** the CLI's HTML is bare; give printed Markdown a readable document look */
const MARKDOWN_PRINT_CSS = `<style>
body{font:11pt/1.6 "Noto Sans","Noto Sans CJK KR","Apple SD Gothic Neo","Malgun Gothic",system-ui,sans-serif;color:#1f1f1f;max-width:none;margin:0}
h1,h2,h3,h4{line-height:1.25;margin:1.2em 0 .5em}h1{font-size:22pt}h2{font-size:16pt;border-bottom:1px solid #ddd;padding-bottom:.2em}h3{font-size:13pt}
table{border-collapse:collapse;margin:.8em 0}th,td{border:1px solid #bbb;padding:4px 10px;text-align:left}th{background:#f3f4f6}
code{font-family:"Noto Sans Mono",Menlo,Consolas,monospace;font-size:.92em;background:#f3f4f6;padding:1px 4px;border-radius:3px}
pre{background:#f6f8fa;padding:10px 12px;border-radius:6px;overflow:hidden;white-space:pre-wrap}pre code{background:none;padding:0}
blockquote{margin:.8em 0;padding:.2em 1em;border-left:4px solid #d0d7de;color:#555}img{max-width:100%}
</style>`

export async function convertDocument(
  userId: string,
  path: string,
  to: string,
  opts: { password?: string; sheet?: string } = {},
): Promise<Uint8Array> {
  const s = storageFor(userId)
  const v = normalizeVirtualPath(path)
  const from = extOf(v)
  const route = ROUTES[from]?.[to]
  if (!route) throw new ConversionError(`Cannot convert .${from} to .${to}`, 400)
  const notReady = await engineReady(route, from)
  if (notReady) throw new ConversionError(`Conversion .${from} → .${to} is unavailable: ${notReady}`, 501)
  const st = await s.stat(v)
  if (st.isDir) throw new StorageError(400, 'Is a folder')
  const disk = s.resolve(v)
  const dir = posix.dirname(v)
  const name = posix.basename(v)

  if (route.engine === 'cli' && from === 'docx' && to === 'html') {
    // the desktop app uses the Word editor's HTML export; here: docx → md → html
    const md = await cliConvert(disk, 'md', [])
    return withTemp(async (tmp) => {
      const mdPath = join(tmp, `${posix.basename(v, posix.extname(v))}.md`)
      writeFileSync(mdPath, md)
      return cliConvert(mdPath, 'html', [])
    })
  }
  if (route.engine === 'cli') {
    const extra: string[] = []
    if (opts.password) extra.push('--password', opts.password)
    if (opts.sheet) extra.push('--sheet', opts.sheet)
    return cliConvert(disk, to, extra)
  }
  if (route.engine === 'chrome') {
    return withSlot(async () => {
      if (from === 'md' || from === 'markdown') {
        const html = await markdownHtml(disk)
        return printHtmlToPdf(userId, dir, `${name}.html`, { inlineHtml: html })
      }
      if (to === 'docx') return htmlToDocx(userId, dir, name)
      return printHtmlToPdf(userId, dir, name)
    })
  }
  if (!EDITOR_PDF_EXTS[`.${from}`]) throw new ConversionError(`Cannot print .${from}`, 501)
  return withSlot(() => exportViaEditor(userId, v))
}

function errorResponse(err: unknown): {
  status: 400 | 403 | 404 | 409 | 413 | 422 | 500 | 501 | 503
  error: string
} {
  if (err instanceof ConversionError) return { status: err.status, error: err.message }
  if (err instanceof StorageError) return { status: err.status, error: err.message }
  if (err instanceof CliUnavailableError || err instanceof ChromeUnavailableError) {
    return { status: 501, error: err.message }
  }
  const message = err instanceof Error ? err.message : String(err)
  return { status: 500, error: `Conversion failed: ${message}` }
}

/** POST { path, to, outDir?, name?, password?, sheet? } → stat of the written file */
convertRoutes.post('/', async (c) => {
  const userId = c.get('user').id
  const body = await c.req.json<{
    path: string
    to: string
    outDir?: string
    name?: string
    password?: string
    sheet?: string
  }>()
  const to = String(body.to ?? '').toLowerCase().replace(/^\./, '')
  try {
    const v = normalizeVirtualPath(body.path)
    const bytes = await convertDocument(userId, v, to, { password: body.password, sheet: body.sheet })
    const s = storageFor(userId)
    const outDir = body.outDir ? normalizeVirtualPath(body.outDir) : posix.dirname(v)
    const stem = (body.name ? basename(String(body.name), extname(String(body.name))) : posix.basename(v, posix.extname(v))) || 'converted'
    const target = await s.uniquePath(outDir, `${stem}.${to}`)
    return c.json(await s.write(target, bytes, { overwrite: false }))
  } catch (err) {
    const { status, error } = errorResponse(err)
    return c.json({ error }, status)
  }
})

/** GET ?path&to → the converted bytes as a download (nothing written to the tree) */
convertRoutes.get('/download', async (c) => {
  const userId = c.get('user').id
  const to = String(c.req.query('to') ?? '').toLowerCase()
  try {
    const v = normalizeVirtualPath(c.req.query('path'))
    const bytes = await convertDocument(userId, v, to)
    const name = `${posix.basename(v, posix.extname(v))}.${to}`
    return new Response(toArrayBuffer(bytes), {
      headers: {
        'content-type': 'application/octet-stream',
        'content-disposition': `attachment; filename*=UTF-8''${encodeURIComponent(name)}`,
        'x-content-type-options': 'nosniff',
      },
    })
  } catch (err) {
    const { status, error } = errorResponse(err)
    return c.json({ error }, status)
  }
})

/** POST { path } → `soffice info` (structure summary: headings, sheets, slides, pages) */
convertRoutes.post('/info', async (c) => {
  const userId = c.get('user').id
  const { path } = await c.req.json<{ path: string }>()
  try {
    const disk = storageFor(userId).resolve(normalizeVirtualPath(path))
    await storageFor(userId).stat(path)
    const res = await runCli(['info', disk], { timeoutMs: 60_000 })
    if (res.status !== 'ok') return c.json({ error: res.message ?? 'info failed' }, 422)
    const { output_path: _o, ...rest } = res
    return c.json(scrubPaths(rest, disk, normalizeVirtualPath(path)))
  } catch (err) {
    const { status, error } = errorResponse(err)
    return c.json({ error }, status)
  }
})

/**
 * GET ?path&page=1&scale=1 → one page as PNG. PDFs rasterize directly; other
 * documents go through their PDF conversion first.
 */
convertRoutes.get('/render', async (c) => {
  const userId = c.get('user').id
  const page = Math.max(1, Math.floor(Number(c.req.query('page') ?? 1)) || 1)
  const scale = Math.min(3, Math.max(0.2, Number(c.req.query('scale') ?? 1) || 1))
  try {
    const v = normalizeVirtualPath(c.req.query('path'))
    const s = storageFor(userId)
    await s.stat(v)
    const png = await withTemp(async (dir) => {
      let pdfDisk = s.resolve(v)
      if (extOf(v) !== 'pdf') {
        pdfDisk = join(dir, 'doc.pdf')
        writeFileSync(pdfDisk, await convertDocument(userId, v, 'pdf'))
      }
      const res = await runCli(['render', pdfDisk, '--out', dir, '--page', String(page), '--scale', String(scale)], {
        timeoutMs: 120_000,
      })
      if (res.status !== 'ok') throw new ConversionError(res.message ?? 'render failed')
      const files = (res.detail?.files ?? res.files) as Array<{ path: string }> | undefined
      const first = files?.[0]?.path
      if (!first) throw new ConversionError('render produced no image')
      return readFileSync(first)
    })
    return new Response(toArrayBuffer(png), {
      headers: { 'content-type': 'image/png', 'cache-control': 'private, max-age=60' },
    })
  } catch (err) {
    const { status, error } = errorResponse(err)
    return c.json({ error }, status)
  }
})

/** CLI results mention absolute disk paths; the browser only ever sees virtual ones */
function scrubPaths<T>(value: T, disk: string, virtual: string): T {
  return JSON.parse(JSON.stringify(value).split(JSON.stringify(disk).slice(1, -1)).join(virtual)) as T
}

function toArrayBuffer(bytes: Uint8Array): ArrayBuffer {
  return bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength) as ArrayBuffer
}
