/**
 * The AI panel's supporting channels: chat attachments (files:*), the
 * starred-files knowledge base (kb:*) and chat history (project:*).
 */

import { randomBytes } from 'node:crypto'
import { existsSync, mkdirSync, readFileSync, statSync, writeFileSync } from 'node:fs'
import { basename, join } from 'node:path'
import { parseFileToText } from '@soffice/file-parse'
import { ProjectStore } from '@soffice/project-store'
import { Hono } from 'hono'
import {
  listKnowledgeFiles,
  readKnowledgeFilePage,
  readKnowledgeFileText,
} from '../../../upstream/soffice/apps/shell/src/main/knowledge-base'
import type { AppEnv } from '../auth'
import { listStarred } from '../db'
import { readBody } from '../lib/body'
import { normalizeVirtualPath, storageFor, StorageError, validateName, type UserStorage } from '../storage'

export const assistRoutes = new Hono<AppEnv>()

// ---- attachments -------------------------------------------------------------

const TEXT_EXTS = new Set(
  'txt md markdown csv tsv json yaml yml xml html htm log js ts tsx jsx py java c h cpp go rs rb sh sql css'.split(
    ' ',
  ),
)
const IMAGE_MIME: Record<string, string> = {
  png: 'image/png',
  jpg: 'image/jpeg',
  jpeg: 'image/jpeg',
  gif: 'image/gif',
  webp: 'image/webp',
}
const ATTACHMENT_EXTS = new Set([
  ...TEXT_EXTS,
  ...'doc docx pdf pptx ppt xlsx xlsm xls'.split(' '),
  ...Object.keys(IMAGE_MIME),
])
const ATTACHMENT_MAX_BYTES = 50 * 1024 * 1024
const IMAGE_MAX_BYTES = 5 * 1024 * 1024
export const ATTACHMENT_PREFIX = '/.attachments/'

const extOf = (name: string) => (name.includes('.') ? name.split('.').pop()!.toLowerCase() : '')

/**
 * An attachment path names either an uploaded copy ("/.attachments/<id>/<name>",
 * stored outside the visible tree) or a document in the user's own tree.
 */
export function attachmentDiskPath(s: UserStorage, path: string): string {
  if (path.startsWith(ATTACHMENT_PREFIX)) {
    const [id, name] = path.slice(ATTACHMENT_PREFIX.length).split('/')
    if (!id || !/^[0-9a-z]{6,40}$/.test(id) || !name) throw new StorageError(400, 'Invalid attachment')
    return join(s.appDataDir('attachments'), id, validateName(name))
  }
  return s.resolve(normalizeVirtualPath(path))
}

function attachmentMeta(s: UserStorage, path: string): { meta?: object; error?: string } {
  const name = basename(path)
  const ext = extOf(name)
  if (!ATTACHMENT_EXTS.has(ext)) return { error: `${name}: unsupported file type (.${ext})` }
  try {
    const st = statSync(attachmentDiskPath(s, path))
    if (!st.isFile()) return { error: `${name}: not a file` }
    if (st.size > ATTACHMENT_MAX_BYTES) return { error: `${name}: larger than 50 MB` }
    return { meta: { path, name, ext, sizeBytes: st.size } }
  } catch {
    return { error: `${name}: unreadable` }
  }
}

assistRoutes.put('/attachments', async (c) => {
  const s = storageFor(c.get('user').id)
  const name = validateName(c.req.query('name') ?? 'file')
  const requested = c.req.query('id') ?? ''
  const id = /^[0-9a-z]{6,40}$/.test(requested) ? requested : randomBytes(8).toString('hex')
  const body = await readBody(c, ATTACHMENT_MAX_BYTES)
  const dir = join(s.appDataDir('attachments'), id)
  mkdirSync(dir, { recursive: true })
  writeFileSync(join(dir, name), body)
  const path = `${ATTACHMENT_PREFIX}${id}/${name}`
  const { meta, error } = attachmentMeta(s, path)
  return c.json({ accepted: meta ? [meta] : [], rejected: error ? [error] : [] })
})

assistRoutes.post('/attachments/add', async (c) => {
  const s = storageFor(c.get('user').id)
  const { paths } = await c.req.json<{ paths: string[] }>()
  const accepted: object[] = []
  const rejected: string[] = []
  for (const p of paths ?? []) {
    const { meta, error } = attachmentMeta(s, String(p))
    if (meta) accepted.push(meta)
    else if (error) rejected.push(error)
  }
  return c.json({ accepted, rejected })
})

const textCache = new Map<string, { stamp: string; text: string }>()

async function extractText(diskPath: string): Promise<string> {
  const st = statSync(diskPath)
  const stamp = `${st.mtimeMs}:${st.size}`
  const cached = textCache.get(diskPath)
  if (cached?.stamp === stamp) return cached.text
  if (st.size > ATTACHMENT_MAX_BYTES) throw new Error('File too large')
  const parsed = await parseFileToText(diskPath)
  if (!parsed.ok || parsed.kind !== 'text' || parsed.text == null) {
    throw new Error(parsed.error ?? 'Could not extract text')
  }
  textCache.set(diskPath, { stamp, text: parsed.text })
  if (textCache.size > 16) textCache.delete(textCache.keys().next().value!)
  return parsed.text
}

assistRoutes.post('/attachments/read', async (c) => {
  const s = storageFor(c.get('user').id)
  const { path, offset, maxChars } = await c.req.json<{ path: string; offset: number; maxChars: number }>()
  const name = basename(String(path))
  const ext = extOf(name)
  if (!ATTACHMENT_EXTS.has(ext)) return c.json({ ok: false, error: `Unsupported file type .${ext}` })
  if (IMAGE_MIME[ext]) return c.json({ ok: false, error: 'Images carry no text' })
  try {
    const text = await extractText(attachmentDiskPath(s, String(path)))
    const start = Math.max(0, Math.floor(offset) || 0)
    const size = Math.min(Math.max(1, Math.floor(maxChars) || 1), 48_000)
    return c.json({ ok: true, name, totalChars: text.length, offset: start, text: text.slice(start, start + size) })
  } catch (err) {
    return c.json({ ok: false, error: err instanceof Error ? err.message : String(err) })
  }
})

assistRoutes.post('/attachments/read-image', async (c) => {
  const s = storageFor(c.get('user').id)
  const { path } = await c.req.json<{ path: string }>()
  const name = basename(String(path))
  const mime = IMAGE_MIME[extOf(name)]
  if (!mime) return c.json({ ok: false, error: `${name}: not an image` })
  try {
    const disk = attachmentDiskPath(s, String(path))
    if (statSync(disk).size > IMAGE_MAX_BYTES) return c.json({ ok: false, error: `${name}: image too large` })
    return c.json({ ok: true, base64: readFileSync(disk).toString('base64'), mime })
  } catch {
    return c.json({ ok: false, error: `${name}: unreadable` })
  }
})

// ---- knowledge base (starred files) -----------------------------------------

function starredDisk(userId: string): { s: UserStorage; disk: string[] } {
  const s = storageFor(userId)
  const disk: string[] = []
  for (const v of listStarred(userId)) {
    try {
      disk.push(s.resolve(v))
    } catch {
      // stale entry with a path we no longer accept
    }
  }
  return { s, disk }
}

assistRoutes.get('/kb/list', (c) => {
  const { s, disk } = starredDisk(c.get('user').id)
  return c.json(
    listKnowledgeFiles(disk).map((f) => ({
      ...f,
      path: s.toVirtual(f.path),
      folderPath: s.toVirtual(f.folderPath),
      folder: f.folderPath === s.root ? '' : f.folder,
    })),
  )
})

/** plain scan over the starred set: case-insensitive term match with a snippet */
assistRoutes.post('/kb/search', async (c) => {
  const { q, limit } = await c.req.json<{ q: string; limit?: number }>()
  const query = String(q ?? '').trim().slice(0, 200)
  if (!query) return c.json([])
  const terms = query.toLowerCase().split(/\s+/).filter(Boolean)
  const { s, disk } = starredDisk(c.get('user').id)
  const hits: Array<{ path: string; name: string; ext: string; folder: string; snippet: string; score: number }> = []
  for (const file of listKnowledgeFiles(disk)) {
    let text = ''
    try {
      text = await readKnowledgeFileText(file.path)
    } catch {
      continue
    }
    const lower = text.toLowerCase()
    const nameLower = file.name.toLowerCase()
    let score = 0
    let first = -1
    for (const t of terms) {
      const at = lower.indexOf(t)
      if (at >= 0) {
        score += 2
        if (first < 0 || at < first) first = at
      }
      if (nameLower.includes(t)) score += 3
    }
    if (score === 0) continue
    const start = Math.max(0, first - 80)
    const snippet = first >= 0 ? text.slice(start, start + 240).replace(/\s+/g, ' ').trim() : ''
    hits.push({
      path: s.toVirtual(file.path),
      name: file.name,
      ext: file.ext,
      folder: file.folderPath === s.root ? '' : file.folder,
      snippet,
      score,
    })
  }
  hits.sort((a, b) => b.score - a.score)
  const max = Math.min(Math.max(1, Number(limit) || 8), 20)
  return c.json(hits.slice(0, max).map(({ score: _score, ...h }) => h))
})

assistRoutes.post('/kb/read', async (c) => {
  const userId = c.get('user').id
  const { path, offset } = await c.req.json<{ path: string; offset: number }>()
  const v = normalizeVirtualPath(path)
  if (!listStarred(userId).includes(v)) return c.json({ error: 'path is not in the knowledge base' }, 400)
  return c.json(await readKnowledgeFilePage(storageFor(userId).resolve(v), Number(offset) || 0))
})

// ---- chat history (project-store) -------------------------------------------

const projectStores = new Map<string, ProjectStore>()

/** sheets addresses chats by workbook session id; its module registers the lookup */
let sessionPathResolver: ((userId: string, sessionId: string) => string | null) | null = null

export function setSessionPathResolver(
  resolver: (userId: string, sessionId: string) => string | null,
): void {
  sessionPathResolver = resolver
}

function projectStore(userId: string): ProjectStore {
  let store = projectStores.get(userId)
  if (!store) {
    store = new ProjectStore(storageFor(userId).appDataDir('projects'))
    store.ensureDefaultProject()
    projectStores.set(userId, store)
  }
  return store
}

/** chat history is keyed by the document's on-disk path, so virtual paths are resolved first */
function diskPathOrNull(userId: string, path: unknown): string | null {
  if (typeof path !== 'string' || !path) return null
  try {
    return storageFor(userId).resolve(normalizeVirtualPath(path))
  } catch {
    return null
  }
}

assistRoutes.post('/project/resolve-chat', async (c) => {
  const userId = c.get('user').id
  const args = await c.req.json<{ filePath: string | null; tempChatId?: string; sessionId?: string }>()
  const store = projectStore(userId)
  const path = args.filePath ?? (args.sessionId ? sessionPathResolver?.(userId, args.sessionId) : null)
  const disk = diskPathOrNull(userId, path)
  if (!disk) return c.json({ projectId: 'default', chatId: args.tempChatId ?? `unsaved-${Date.now()}` })
  return c.json(store.resolveChatForFile(disk))
})

assistRoutes.post('/project/append-chat', async (c) => {
  const args = await c.req.json<{
    projectId: string
    chatId: string
    role: 'user' | 'assistant'
    text: string
    tools?: unknown[]
    attachments?: unknown[]
    scope?: { label: string; text?: string }
  }>()
  if (args.role !== 'user' && args.role !== 'assistant') return c.json({ error: 'Invalid chat role' }, 400)
  if (typeof args.text !== 'string' || args.text.length > 200_000) {
    return c.json({ error: 'Invalid chat text' }, 400)
  }
  const msg: Parameters<ProjectStore['appendChatMessage']>[2] = { role: args.role, text: args.text }
  if (Array.isArray(args.tools)) msg.tools = args.tools as never
  if (Array.isArray(args.attachments)) msg.attachments = args.attachments as never
  if (args.scope) msg.scope = args.scope
  projectStore(c.get('user').id).appendChatMessage(args.projectId, args.chatId, msg)
  return c.json(null)
})

assistRoutes.post('/project/load-chat', async (c) => {
  const args = await c.req.json<{ projectId: string; chatId: string; limit?: number }>()
  return c.json(projectStore(c.get('user').id).loadChat(args.projectId, args.chatId, args.limit ?? 200))
})

assistRoutes.post('/project/rebind-chat', async (c) => {
  const userId = c.get('user').id
  const args = await c.req.json<{
    projectId: string
    tempChatId: string
    newChatId?: string
    newFilePath?: string
    sessionId?: string
  }>()
  const store = projectStore(userId)
  const path = args.newFilePath ?? (args.sessionId ? sessionPathResolver?.(userId, args.sessionId) : null)
  const disk = diskPathOrNull(userId, path)
  if (disk) return c.json(store.rebindChatToFile(args.projectId, args.tempChatId, disk))
  if (args.newChatId) store.rebindChat(args.projectId, args.tempChatId, args.newChatId)
  return c.json({ projectId: args.projectId, chatId: args.newChatId ?? args.tempChatId })
})

export function projectFileMoved(userId: string, fromVirtual: string, toVirtual: string): void {
  try {
    const s = storageFor(userId)
    projectStore(userId).fileRenamed(s.resolve(fromVirtual), s.resolve(toVirtual))
  } catch {
    // history stays under the old key
  }
}

export function attachmentsDirExists(userId: string): boolean {
  return existsSync(join(storageFor(userId).appData, 'attachments'))
}
