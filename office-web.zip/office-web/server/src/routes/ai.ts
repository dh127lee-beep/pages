/**
 * AI endpoints: the desktop main process' ai:* IPC handlers, served per user.
 *
 * Credentials never leave the server. Settings go to the browser with every
 * key replaced by a mask; a masked key coming back means "keep the stored
 * one". Streaming requests carry the renderer's settings copy, but only its
 * provider/model choice is honoured: keys, base URLs and custom endpoint
 * definitions always come from the server-side settings file.
 */

import { existsSync, mkdirSync, readFileSync, renameSync, writeFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import {
  activeProvider,
  chatForProvider,
  defaultAiSettings,
  isAiNetworkError,
  isAiOverloadedError,
  maxOutputTokensOf,
  resolveAiSettings,
  sanitizeAiSettings,
  streamForProvider,
  AiCreditsError,
  AiTimeoutError,
  type AiProviderId,
  type AiSettings,
  type AiStreamChunk,
  type AiStreamRequest,
} from '@soffice/ai-provider'
import { analyzeMediaTool, generateImageTool, imageSearchTool, webSearchTool } from '@soffice/ai-search'
import { isSafeRemoteUrl } from '@soffice/electron-utils/safe-remote-url'
import { Hono } from 'hono'
import type { AppEnv } from '../auth'
import { storageFor } from '../storage'
import { fetchImageAsBase64 } from '../lib/remote'

export const KEY_MASK = '••••••••'

/** providers that would spawn local binaries or rely on a desktop sign-in */
const DISABLED_PROVIDERS = new Set<AiProviderId>(['codex'])

// ---- settings file (same JSON shape the desktop app keeps in ai-settings.json)

export function aiSettingsPath(userId: string): string {
  return join(storageFor(userId).appDataDir(), 'ai-settings.json')
}

/** server-wide default from the environment (AI_PROVIDER / AI_API_KEY / AI_MODEL / AI_BASE_URL) */
function envDefaults(): { provider?: AiProviderId; apiKey?: string; model?: string; baseUrl?: string } {
  const provider = process.env.AI_PROVIDER?.trim() as AiProviderId | undefined
  const fromVendorEnv: Partial<Record<AiProviderId, string | undefined>> = {
    anthropic: process.env.ANTHROPIC_API_KEY,
    openai: process.env.OPENAI_API_KEY,
    gemini: process.env.GEMINI_API_KEY ?? process.env.GOOGLE_API_KEY,
    deepseek: process.env.DEEPSEEK_API_KEY,
    openrouter: process.env.OPENROUTER_API_KEY,
    mistral: process.env.MISTRAL_API_KEY,
    xai: process.env.XAI_API_KEY,
  }
  if (provider) {
    return {
      provider,
      apiKey: process.env.AI_API_KEY ?? fromVendorEnv[provider],
      model: process.env.AI_MODEL,
      baseUrl: process.env.AI_BASE_URL,
    }
  }
  for (const [id, key] of Object.entries(fromVendorEnv)) {
    if (key) return { provider: id as AiProviderId, apiKey: key, model: process.env.AI_MODEL }
  }
  return {}
}

function readStored(userId: string): Partial<AiSettings> | null {
  const path = aiSettingsPath(userId)
  if (!existsSync(path)) return null
  try {
    return JSON.parse(readFileSync(path, 'utf8')) as Partial<AiSettings>
  } catch {
    return null
  }
}

function writeStored(userId: string, settings: AiSettings): void {
  const path = aiSettingsPath(userId)
  mkdirSync(dirname(path), { recursive: true })
  const tmp = `${path}.${process.pid}.tmp`
  writeFileSync(tmp, JSON.stringify(settings, null, 2))
  renameSync(tmp, path)
}

/** the user's settings with server defaults filled in (real keys; server-side only) */
export function effectiveAiSettings(userId: string): AiSettings {
  const env = envDefaults()
  const defaults = defaultAiSettings(env.provider && env.apiKey ? { [env.provider]: env.apiKey } : {})
  if (env.provider) {
    defaults.provider = env.provider
    const cfg = defaults.providers[env.provider]
    if (cfg) {
      if (env.model) cfg.model = env.model
      if (env.baseUrl) cfg.baseUrl = env.baseUrl
    }
  }
  const stored = readStored(userId)
  const settings = resolveAiSettings(stored ?? {}, defaults)
  if (!stored && env.provider) settings.provider = env.provider
  // a provider the user selected without their own key inherits the server key
  if (env.provider && env.apiKey) {
    const cfg = settings.providers[env.provider]
    if (cfg && !cfg.apiKey) cfg.apiKey = env.apiKey
  }
  if (DISABLED_PROVIDERS.has(settings.provider)) settings.provider = 'scloud'
  settings.provider = activeProvider(settings)
  return settings
}

/** deep copy with every non-empty `apiKey`/`key`/`token` string replaced by the mask */
export function maskSecrets<T>(value: T): T {
  if (Array.isArray(value)) return value.map(maskSecrets) as T
  if (value && typeof value === 'object') {
    const out: Record<string, unknown> = {}
    for (const [k, v] of Object.entries(value)) {
      out[k] = isSecretKey(k) && typeof v === 'string' && v ? KEY_MASK : maskSecrets(v)
    }
    return out as T
  }
  return value
}

/** put stored secrets back wherever the incoming copy still carries the mask */
export function unmaskSecrets<T>(incoming: T, stored: unknown): T {
  if (Array.isArray(incoming)) {
    const prev = Array.isArray(stored) ? stored : []
    return incoming.map((item, i) => {
      // custom endpoints are matched by id, not position
      const id = item && typeof item === 'object' ? (item as { id?: unknown }).id : undefined
      const match =
        id !== undefined
          ? prev.find((p) => p && typeof p === 'object' && (p as { id?: unknown }).id === id)
          : prev[i]
      return unmaskSecrets(item, match)
    }) as T
  }
  if (incoming && typeof incoming === 'object') {
    const prev = stored && typeof stored === 'object' ? (stored as Record<string, unknown>) : {}
    const out: Record<string, unknown> = {}
    for (const [k, v] of Object.entries(incoming)) {
      out[k] = isSecretKey(k) && v === KEY_MASK ? (prev[k] ?? '') : unmaskSecrets(v, prev[k])
    }
    return out as T
  }
  return incoming
}

function isSecretKey(k: string): boolean {
  return /^(apiKey|apiKeys|key|token|secret|accessToken)$/i.test(k)
}

/**
 * What a stream/chat request may choose: provider and model. Everything that
 * decides where a key is sent comes from the server copy.
 */
function requestSettings(userId: string, fromClient: unknown): AiSettings {
  const server = effectiveAiSettings(userId)
  const client = sanitizeAiSettings(fromClient)
  if (!client) return server
  const provider = client.provider
  if (DISABLED_PROVIDERS.has(provider) || !server.providers[provider]) return server
  const merged: AiSettings = { ...server, provider }
  const model = client.providers?.[provider]?.model
  if (model && provider !== 'custom') {
    merged.providers = { ...server.providers, [provider]: { ...server.providers[provider], model } }
  }
  if (client.maxOutputTokens !== undefined) merged.maxOutputTokens = client.maxOutputTokens
  return merged
}

/**
 * A user-supplied base URL is an SSRF vector on a shared server (the request
 * carries the user's prompt to wherever it points). Only administrators, or
 * every user when ALLOW_PRIVATE_AI_ENDPOINTS is set, may target loopback,
 * private or link-local addresses (e.g. a local Ollama).
 */
export async function endpointRefusal(
  user: { isAdmin: boolean },
  config: { baseUrl?: string } | undefined,
): Promise<string | null> {
  const baseUrl = config?.baseUrl?.trim()
  if (!baseUrl || user.isAdmin) return null
  if (/^(1|true|yes|on)$/i.test(process.env.ALLOW_PRIVATE_AI_ENDPOINTS ?? '')) return null
  if (process.env.AI_BASE_URL && baseUrl === process.env.AI_BASE_URL) return null
  return (await isSafeRemoteUrl(baseUrl))
    ? null
    : 'This AI endpoint points to a private or local address, which only an administrator may configure.'
}

/** every `baseUrl` anywhere in a settings object (providers, custom endpoints, media, search) */
function collectBaseUrls(value: unknown, out: string[] = []): string[] {
  if (Array.isArray(value)) value.forEach((v) => collectBaseUrls(v, out))
  else if (value && typeof value === 'object') {
    for (const [k, v] of Object.entries(value)) {
      if (k === 'baseUrl' && typeof v === 'string' && v.trim()) out.push(v.trim())
      else collectBaseUrls(v, out)
    }
  }
  return out
}

// ---- routes ----------------------------------------------------------------

export const aiRoutes = new Hono<AppEnv>()

const active = new Map<string, AbortController>()

aiRoutes.get('/settings', (c) => {
  const settings = effectiveAiSettings(c.get('user').id)
  return c.json(maskSecrets(settings))
})

aiRoutes.put('/settings', async (c) => {
  const userId = c.get('user').id
  const incoming = await c.req.json<unknown>()
  const stored = readStored(userId) ?? effectiveAiSettings(userId)
  const restored = unmaskSecrets(incoming, stored)
  const sanitized = sanitizeAiSettings(restored)
  if (!sanitized) return c.json({ error: 'Invalid AI settings' }, 400)
  if (DISABLED_PROVIDERS.has(sanitized.provider)) {
    return c.json({ error: `The ${sanitized.provider} provider is not available on the server` }, 400)
  }
  for (const baseUrl of new Set(collectBaseUrls(sanitized))) {
    const refusal = await endpointRefusal(c.get('user'), { baseUrl })
    if (refusal) return c.json({ error: `${refusal} (${baseUrl})` }, 400)
  }
  // the server's own key is inherited at request time, never copied into a user's file
  const env = envDefaults()
  if (env.provider && env.apiKey) {
    const cfg = sanitized.providers[env.provider]
    if (cfg?.apiKey === env.apiKey) cfg.apiKey = ''
  }
  writeStored(userId, sanitized)
  return c.json(maskSecrets(effectiveAiSettings(userId)))
})

/** which providers the web edition offers, and whether the server supplies a default key */
aiRoutes.get('/capabilities', (c) => {
  const env = envDefaults()
  return c.json({
    disabledProviders: [...DISABLED_PROVIDERS, 'scloud'],
    serverDefault: env.provider && env.apiKey ? { provider: env.provider, model: env.model ?? null } : null,
  })
})

aiRoutes.post('/stream', async (c) => {
  const userId = c.get('user').id
  const request = await c.req.json<AiStreamRequest>()
  const requestId = String(request.requestId ?? '')
  const settings = requestSettings(userId, request.settings)
  const provider = settings.provider
  const config = settings.providers?.[provider]
  const tools = request.tools ?? []
  const maxTokens = request.maxTokens ?? maxOutputTokensOf(settings)

  const encoder = new TextEncoder()
  const controller = new AbortController()
  active.set(`${userId}:${requestId}`, controller)
  c.req.raw.signal.addEventListener('abort', () => controller.abort())

  const body = new ReadableStream<Uint8Array>({
    async start(stream) {
      const send = (chunk: AiStreamChunk) => {
        try {
          stream.enqueue(encoder.encode(`${JSON.stringify(chunk)}\n`))
        } catch {
          // client went away
        }
      }
      try {
        if (provider === 'scloud' || !config || !config.apiKey) {
          send({
            requestId,
            type: 'error',
            error:
              'No AI provider is configured. Open Settings → AI on the home page and add an API key.',
          })
          return
        }
        if (!config.model) {
          send({ requestId, type: 'error', error: 'No model selected for the AI provider.' })
          return
        }
        const refusal = await endpointRefusal(c.get('user'), config)
        if (refusal) {
          send({ requestId, type: 'error', error: refusal })
          return
        }
        let lastPing = 0
        let stopReason: string | undefined
        await streamForProvider(provider, config, request.system, request.messages, tools, maxTokens, {
          ...(request.sessionId ? { sessionId: request.sessionId } : {}),
          signal: controller.signal,
          onDelta: (text) => send({ requestId, type: 'delta', text }),
          onReasoningDelta: (text) => send({ requestId, type: 'reasoning', text }),
          onToolCall: (toolCall) => send({ requestId, type: 'tool-call', toolCall }),
          onActivity: () => {
            const now = Date.now()
            if (now - lastPing < 5_000) return
            lastPing = now
            send({ requestId, type: 'ping' })
          },
          onStopReason: (reason) => {
            stopReason = reason
          },
          onUsage: (usage) => send({ requestId, type: 'usage', usage }),
        })
        send({ requestId, type: 'done', stopReason })
      } catch (err) {
        if (controller.signal.aborted) {
          send({ requestId, type: 'done' })
        } else {
          send({
            requestId,
            type: 'error',
            error: err instanceof Error ? err.message : String(err),
            ...(err instanceof AiTimeoutError
              ? { errorCode: 'timeout' as const }
              : err instanceof AiCreditsError
                ? { errorCode: 'credits' as const }
                : isAiNetworkError(err)
                  ? { errorCode: 'network' as const }
                  : isAiOverloadedError(err)
                    ? { errorCode: 'overloaded' as const }
                    : {}),
          })
        }
      } finally {
        active.delete(`${userId}:${requestId}`)
        try {
          stream.close()
        } catch {
          // already closed
        }
      }
    },
    cancel() {
      controller.abort()
    },
  })
  return new Response(body, {
    headers: {
      'content-type': 'application/x-ndjson; charset=utf-8',
      'cache-control': 'no-cache, no-transform',
      'x-accel-buffering': 'no',
    },
  })
})

aiRoutes.post('/stream-cancel', async (c) => {
  const { requestId } = await c.req.json<{ requestId: string }>()
  active.get(`${c.get('user').id}:${requestId}`)?.abort()
  return c.json({ ok: true })
})

aiRoutes.post('/chat', async (c) => {
  const userId = c.get('user').id
  const request = await c.req.json<{ settings: unknown; system: string; user: string }>()
  const settings = requestSettings(userId, request.settings)
  const provider = settings.provider
  const config = settings.providers?.[provider]
  if (provider === 'scloud' || !config?.apiKey) {
    return c.json({ ok: false, error: 'No AI provider is configured (Settings → AI).' })
  }
  if (!config.model) return c.json({ ok: false, error: 'No model selected.' })
  const refusal = await endpointRefusal(c.get('user'), config)
  if (refusal) return c.json({ ok: false, error: refusal })
  try {
    const result = await chatForProvider(provider, config, String(request.system ?? ''), String(request.user ?? ''))
    if (!result.ok && isAiOverloadedError(result.error)) {
      return c.json({ ok: false, error: 'The AI service is busy. Try again in a moment.' })
    }
    return c.json(result)
  } catch (err) {
    return c.json({ ok: false, error: err instanceof Error ? err.message : String(err) })
  }
})

aiRoutes.post('/web-search', async (c) => {
  const { query, maxResults } = await c.req.json<{ query: string; maxResults?: number }>()
  try {
    return c.json(await webSearchTool(aiSettingsPath(c.get('user').id), String(query), maxResults ?? 6))
  } catch (err) {
    return c.json({ results: [], method: 'error', error: String(err) })
  }
})

aiRoutes.post('/image-search', async (c) => {
  const { query, maxResults } = await c.req.json<{ query: string; maxResults?: number }>()
  try {
    return c.json(await imageSearchTool(aiSettingsPath(c.get('user').id), String(query), maxResults ?? 8))
  } catch (err) {
    return c.json({ images: [], method: 'error', error: String(err) })
  }
})

aiRoutes.post('/fetch-image', async (c) => {
  const { url } = await c.req.json<{ url: string }>()
  return c.json(await fetchImageAsBase64(String(url)))
})

aiRoutes.post('/analyze-media', async (c) => {
  const op = await c.req.json<{ mediaUrls?: string[]; requirements?: string }>()
  const mediaUrls = (op.mediaUrls ?? []).map(String).filter((u) => /^(https?:|data:)/.test(u))
  try {
    return c.json(
      await analyzeMediaTool(
        aiSettingsPath(c.get('user').id),
        { mediaUrls, requirements: String(op.requirements ?? '') },
        { mediaRoots: [] },
      ),
    )
  } catch (err) {
    return c.json({ error: String(err) })
  }
})

aiRoutes.post('/generate-image', async (c) => {
  const op = await c.req.json<{ prompt?: string; aspectRatio?: string }>()
  try {
    return c.json(
      await generateImageTool(
        aiSettingsPath(c.get('user').id),
        { prompt: String(op.prompt ?? ''), aspectRatio: op.aspectRatio ? String(op.aspectRatio) : undefined },
        { mediaRoots: [] },
      ),
    )
  } catch (err) {
    return c.json({ error: String(err) })
  }
})
