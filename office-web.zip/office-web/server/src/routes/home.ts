/**
 * Home-screen endpoints the shell renderer needs beyond plain file I/O:
 * the paged recents/starred lists, starred groups, file search over names
 * and extracted text, first-run state, and the Settings › AI connection tests.
 */

import { posix } from 'node:path'
import { statSync } from 'node:fs'
import {
  chatForProvider,
  sanitizeAiSettings,
  testMediaProvider,
  type AiMediaProviderConfig,
  type AiSettings,
} from '@soffice/ai-provider'
import { listCustomModelsForIpc } from '@soffice/ai-provider/custom-models'
import { parseFileToText } from '@soffice/file-parse'
import { testSearchProvider } from '@soffice/ai-search'
import { Hono } from 'hono'
import type { AppEnv } from '../auth'
import { getUserSetting, listRecent, listStarred, setUserSetting } from '../db'
import { normalizeVirtualPath, storageFor, type Entry, type UserStorage } from '../storage'
import { effectiveAiSettings, endpointRefusal, KEY_MASK } from './ai'

export const homeRoutes = new Hono<AppEnv>()

/** documents the home lists show (everything the editors open) */
const DOC_EXTS = new Set(
  'docx doc dotx odt rtf xlsx xlsm xls csv ods pptx ppt odp pdf md markdown html htm'.split(' '),
)

const extOf = (name: string) => (name.includes('.') ? name.split('.').pop()!.toLowerCase() : '')

/** sidebar filter keys → extensions (mirrors the shell's SEARCH_EXT_FAMILY) */
const EXT_FAMILY: Record<string, string[]> = {
  docx: ['docx', 'doc', 'dotx', 'odt', 'rtf'],
  xlsx: ['xlsx', 'xlsm', 'xls', 'csv', 'ods'],
  pptx: ['pptx', 'ppt', 'odp'],
  pdf: ['pdf'],
  md: ['md', 'markdown'],
  html: ['html', 'htm'],
}

function matchesExt(name: string, filter: unknown): boolean {
  if (typeof filter !== 'string' || !filter || filter === 'all') return true
  return (EXT_FAMILY[filter] ?? [filter]).includes(extOf(name))
}

interface RecentEntry {
  path: string
  name: string
  ext: string
  mtimeMs: number
  sizeBytes: number
  starred: boolean
  group?: string
  missing?: boolean
}

function toEntry(e: Entry, starred: Set<string>): RecentEntry {
  return {
    path: e.path,
    name: e.name,
    ext: extOf(e.name),
    mtimeMs: e.mtimeMs,
    sizeBytes: e.size,
    starred: starred.has(e.path),
  }
}

async function statEntry(s: UserStorage, path: string, starred: Set<string>): Promise<RecentEntry> {
  try {
    const st = await s.stat(path)
    return toEntry(st, starred)
  } catch {
    const name = posix.basename(path)
    return { path, name, ext: extOf(name), mtimeMs: 0, sizeBytes: 0, starred: starred.has(path), missing: true }
  }
}

function page<T extends { name: string }>(all: T[], q: { offset?: unknown; limit?: unknown; ext?: unknown }) {
  const filtered = all.filter((e) => matchesExt(e.name, q.ext))
  const offset = Math.max(0, Number(q.offset) || 0)
  const limit = q.limit === undefined ? 50 : Math.max(0, Number(q.limit) || 0)
  return { entries: filtered.slice(offset, offset + limit), total: filtered.length, totalAll: all.length }
}

// ---- recents / starred ---------------------------------------------------------

homeRoutes.post('/recents', async (c) => {
  const userId = c.get('user').id
  const q = await c.req.json<{ offset?: number; limit?: number; ext?: string }>().catch(() => ({}))
  const s = storageFor(userId)
  const starred = new Set(listStarred(userId))
  const hidden = new Set(getUserSetting<string[]>(userId, 'hiddenRecents', []))
  const all: RecentEntry[] = []
  for (const r of listRecent(userId, 100)) {
    if (hidden.has(r.path)) continue
    all.push(await statEntry(s, r.path, starred))
  }
  return c.json(page(all, q))
})

homeRoutes.post('/remove-recent', async (c) => {
  const userId = c.get('user').id
  const { paths } = await c.req.json<{ paths: string[] }>()
  const { getDb } = await import('../db')
  const del = getDb().prepare('DELETE FROM recent_files WHERE user_id = ? AND path = ?')
  for (const p of paths ?? []) del.run(userId, String(p))
  return c.json({ ok: true })
})

type Groups = { order: string[]; byPath: Record<string, string> }

function readGroups(userId: string): Groups {
  return getUserSetting<Groups>(userId, 'starredGroups', { order: [], byPath: {} })
}

homeRoutes.post('/starred', async (c) => {
  const userId = c.get('user').id
  const q = await c.req.json<{ offset?: number; limit?: number; ext?: string; group?: string }>().catch(() => ({}))
  const s = storageFor(userId)
  const paths = listStarred(userId)
  const starred = new Set(paths)
  const groups = readGroups(userId)
  let all: RecentEntry[] = []
  for (const p of paths) {
    const entry = await statEntry(s, p, starred)
    const group = groups.byPath[p]
    all.push(group ? { ...entry, group } : entry)
  }
  if ((q as { group?: string }).group) all = all.filter((e) => e.group === (q as { group?: string }).group)
  return c.json(page(all, q))
})

homeRoutes.get('/starred-groups', (c) => {
  const userId = c.get('user').id
  const groups = readGroups(userId)
  const starred = new Set(listStarred(userId))
  const used = new Set(Object.entries(groups.byPath).filter(([p]) => starred.has(p)).map(([, g]) => g))
  return c.json(groups.order.filter((g) => used.has(g)))
})

homeRoutes.post('/starred-group', async (c) => {
  const userId = c.get('user').id
  const { paths, group } = await c.req.json<{ paths: string[]; group: string | null }>()
  const groups = readGroups(userId)
  const name = typeof group === 'string' ? group.trim().slice(0, 80) : ''
  for (const p of paths ?? []) {
    if (name) groups.byPath[String(p)] = name
    else delete groups.byPath[String(p)]
  }
  if (name && !groups.order.includes(name)) groups.order.push(name)
  setUserSetting(userId, 'starredGroups', groups)
  return c.json({ ok: true })
})

homeRoutes.post('/stat-paths', async (c) => {
  const userId = c.get('user').id
  const { paths } = await c.req.json<{ paths: string[] }>()
  const s = storageFor(userId)
  const starred = new Set(listStarred(userId))
  const out: RecentEntry[] = []
  for (const p of paths ?? []) {
    try {
      out.push(await statEntry(s, normalizeVirtualPath(p), starred))
    } catch {
      // invalid path
    }
  }
  return c.json(out)
})

// ---- folder tree -------------------------------------------------------------------

homeRoutes.get('/folder', async (c) => {
  const userId = c.get('user').id
  const dir = normalizeVirtualPath(c.req.query('dir') ?? '/')
  const s = storageFor(userId)
  const starred = new Set(listStarred(userId))
  let entries: Entry[]
  try {
    entries = await s.list(dir)
  } catch {
    return c.json({ dir, folders: [], files: [], missing: true })
  }
  const folders = []
  for (const e of entries.filter((x) => x.isDir)) {
    const sub = await s.list(e.path).catch(() => [])
    folders.push({ path: e.path, name: e.name, mtimeMs: e.mtimeMs, hasSubfolders: sub.some((x) => x.isDir) })
  }
  const files = entries
    .filter((e) => !e.isDir && DOC_EXTS.has(extOf(e.name)))
    .map((e) => toEntry(e, starred))
    .sort((a, b) => b.mtimeMs - a.mtimeMs)
  return c.json({ dir, folders, files })
})

// ---- search over names, folders and extracted text -------------------------------------

const textCache = new Map<string, { stamp: string; text: string }>()
const TEXT_CACHE_MAX = 400
const SEARCH_MAX_BYTES = 20 * 1024 * 1024

async function fileText(disk: string): Promise<string> {
  let stamp: string
  try {
    const st = statSync(disk)
    if (st.size > SEARCH_MAX_BYTES) return ''
    stamp = `${st.mtimeMs}:${st.size}`
  } catch {
    return ''
  }
  const hit = textCache.get(disk)
  if (hit?.stamp === stamp) return hit.text
  let text = ''
  try {
    const parsed = await parseFileToText(disk)
    if (parsed.ok && parsed.kind === 'text' && parsed.text) text = parsed.text
  } catch {
    text = ''
  }
  textCache.set(disk, { stamp, text })
  if (textCache.size > TEXT_CACHE_MAX) textCache.delete(textCache.keys().next().value!)
  return text
}

function snippetAround(text: string, needles: string[]): Array<{ text: string; hit: boolean }> | null {
  const lower = text.toLowerCase()
  let at = -1
  let len = 0
  for (const n of needles) {
    const i = lower.indexOf(n)
    if (i >= 0 && (at < 0 || i < at)) {
      at = i
      len = n.length
    }
  }
  if (at < 0) return null
  const start = Math.max(0, at - 60)
  const end = Math.min(text.length, at + len + 120)
  const clean = (s: string) => s.replace(/\s+/g, ' ')
  return [
    { text: (start > 0 ? '…' : '') + clean(text.slice(start, at)), hit: false },
    { text: clean(text.slice(at, at + len)), hit: true },
    { text: clean(text.slice(at + len, end)) + (end < text.length ? '…' : ''), hit: false },
  ]
}

homeRoutes.post('/search', async (c) => {
  const userId = c.get('user').id
  const q = await c.req.json<{ q: string; ext?: string; offset?: number; limit?: number }>()
  const query = String(q.q ?? '').trim().toLowerCase().slice(0, 200)
  const empty = { hits: [], total: 0, index: { indexed: 0, pending: 0, scanning: false } }
  if (!query) return c.json(empty)
  const needles = query.split(/\s+/).filter(Boolean)
  const s = storageFor(userId)
  const starred = new Set(listStarred(userId))
  const all = (await s.walkFiles()).filter((e) => DOC_EXTS.has(extOf(e.name)))
  const scored: Array<{ hit: RecentEntry & { snippet: unknown; needles: string[] }; score: number }> = []
  for (const e of all) {
    if (!matchesExt(e.name, q.ext)) continue
    const nameHay = e.path.toLowerCase()
    let score = 0
    const matched: string[] = []
    let snippet: ReturnType<typeof snippetAround> = null
    const text = await fileText(s.resolve(e.path))
    const textLower = text.toLowerCase()
    let all = true
    for (const n of needles) {
      const inName = nameHay.includes(n)
      const inText = textLower.includes(n)
      if (!inName && !inText) {
        all = false
        break
      }
      if (inName) score += posix.basename(nameHay).includes(n) ? 10 : 4
      if (inText) score += 2
      matched.push(n)
    }
    if (!all) continue
    if (text) snippet = snippetAround(text, needles)
    scored.push({ hit: { ...toEntry(e, starred), snippet, needles: matched }, score })
  }
  scored.sort((a, b) => b.score - a.score || b.hit.mtimeMs - a.hit.mtimeMs)
  const offset = Math.max(0, Number(q.offset) || 0)
  const limit = q.limit === undefined ? 50 : Math.max(0, Number(q.limit) || 0)
  return c.json({
    hits: scored.slice(offset, offset + limit).map((x) => x.hit),
    total: scored.length,
    index: { indexed: all.length, pending: 0, scanning: false },
  })
})

// ---- small per-user flags -------------------------------------------------------------

homeRoutes.get('/flags', (c) => {
  const userId = c.get('user').id
  return c.json(getUserSetting<Record<string, unknown>>(userId, 'homeFlags', {}))
})

homeRoutes.put('/flags', async (c) => {
  const userId = c.get('user').id
  const patch = await c.req.json<Record<string, unknown>>()
  const next = { ...getUserSetting<Record<string, unknown>>(userId, 'homeFlags', {}) }
  for (const [k, v] of Object.entries(patch ?? {})) {
    if (/^[a-zA-Z]{1,40}$/.test(k) && JSON.stringify(v).length < 8192) next[k] = v
  }
  setUserSetting(userId, 'homeFlags', next)
  return c.json(next)
})

// ---- Settings › AI connection tests ------------------------------------------------------

/**
 * The settings form holds masked keys. A masked key is only filled in from
 * the server copy when the request would send it to the same endpoint the
 * server copy uses — a key must never travel to an address the user typed.
 */
function resolveForTest(userId: string, input: unknown): AiSettings | { error: string } {
  const client = sanitizeAiSettings(input)
  if (!client) return { error: 'Invalid AI settings' }
  const server = effectiveAiSettings(userId)
  const provider = client.provider
  const cfg = { ...client.providers[provider] }
  if (cfg.apiKey === KEY_MASK) {
    const stored = server.providers[provider]
    const sameUrl = (cfg.baseUrl ?? '').trim() === (stored?.baseUrl ?? '').trim()
    if (!stored?.apiKey || !sameUrl) return { error: 'Save the settings with the API key first' }
    cfg.apiKey = stored.apiKey
  }
  return { ...client, providers: { ...client.providers, [provider]: cfg } }
}

homeRoutes.post('/ai-test', async (c) => {
  const userId = c.get('user').id
  const settings = resolveForTest(userId, await c.req.json())
  if ('error' in settings) return c.json({ ok: false, error: settings.error })
  const provider = settings.provider
  const config = settings.providers[provider]
  if (provider === 'scloud' || provider === 'codex') {
    return c.json({ ok: false, error: 'This provider is not available on the web server' })
  }
  if (!config?.model) return c.json({ ok: false, error: 'No model selected' })
  const refusal = await endpointRefusal(c.get('user'), config)
  if (refusal) return c.json({ ok: false, error: refusal })
  try {
    const result = await chatForProvider(
      provider,
      config,
      'You are a connectivity test. Reply with the single word OK.',
      'ping',
    )
    return c.json(result.ok ? { ok: true } : { ok: false, error: result.error })
  } catch (err) {
    return c.json({ ok: false, error: err instanceof Error ? err.message : String(err) })
  }
})

homeRoutes.post('/custom-models', async (c) => {
  if (process.env.AI_ALLOW_CUSTOM_ENDPOINTS === '0') return c.json({ models: [], defaultModel: '' })
  const userId = c.get('user').id
  const input = await c.req.json<{ baseUrl?: string; apiKey?: string; api?: string }>()
  if (await endpointRefusal(c.get('user'), input)) return c.json({ models: [], defaultModel: '' })
  let apiKey = input.apiKey
  if (apiKey === KEY_MASK) {
    const stored = effectiveAiSettings(userId).providers.custom
    apiKey = stored && (stored.baseUrl ?? '').trim() === (input.baseUrl ?? '').trim() ? stored.apiKey : ''
  }
  try {
    return c.json(await listCustomModelsForIpc({ ...input, apiKey }))
  } catch {
    return c.json({ models: [], defaultModel: '' })
  }
})

homeRoutes.post('/search-test', async (c) => {
  const userId = c.get('user').id
  const { provider, apiKey } = await c.req.json<{ provider: string; apiKey: string }>()
  if (!provider || provider === 'scloud') return c.json({ ok: false, error: 'Not available on the web server' })
  let key = String(apiKey ?? '')
  if (key === KEY_MASK) {
    const search = effectiveAiSettings(userId).search as
      | { providers?: Record<string, { apiKey?: string }> }
      | undefined
    key = search?.providers?.[provider]?.apiKey ?? ''
  }
  return c.json(await testSearchProvider(provider as never, key))
})

homeRoutes.post('/media-test', async (c) => {
  const userId = c.get('user').id
  const { provider, config } = await c.req.json<{ provider: string; config?: AiMediaProviderConfig }>()
  if (!provider || provider === 'scloud') return c.json({ ok: false, error: 'Not available on the web server' })
  if (!config) return c.json({ ok: false, error: 'No media provider configuration' })
  const cfg = { ...config } as AiMediaProviderConfig & { apiKey?: string; baseUrl?: string }
  if (cfg.apiKey === KEY_MASK) {
    const media = effectiveAiSettings(userId).media as
      | { providers?: Record<string, { apiKey?: string; baseUrl?: string }> }
      | undefined
    const stored = media?.providers?.[provider]
    if (!stored?.apiKey || (stored.baseUrl ?? '').trim() !== (cfg.baseUrl ?? '').trim()) {
      return c.json({ ok: false, error: 'Save the settings with the API key first' })
    }
    cfg.apiKey = stored.apiKey
  }
  const refusal = await endpointRefusal(c.get('user'), cfg)
  if (refusal) return c.json({ ok: false, error: refusal })
  return c.json(await testMediaProvider(provider as never, cfg))
})
