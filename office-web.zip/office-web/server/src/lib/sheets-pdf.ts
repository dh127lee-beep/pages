/**
 * Sheets "Export PDF": the renderer lays the workbook out as print HTML
 * (WorkbookExportPdfRequest) and the desktop main process prints it in a
 * hidden, script-disabled window (apps/sheets/src/main/pdf-export.ts). This
 * is the same pipeline on headless Chrome: one print pass, plus the extra
 * first-page / even-page passes Excel's header variants need, stitched with
 * pdf-lib exactly like upstream.
 */

import {
  evenPageRanges,
  stitchPlan,
  type PageVariant,
} from '../../../upstream/soffice/apps/sheets/src/main/pdf-page-variants'
import {
  workbookExportPdfRequestSchema,
  type WorkbookExportPdfRequest,
} from '../../../upstream/soffice/apps/sheets/src/shared/desktop-api'
import { withIsolatedHtmlPage } from './chrome'

type Page = import('playwright-core').Page
type PDFDocument = import('pdf-lib').PDFDocument

interface TemplatePair {
  readonly headerTemplate?: string | undefined
  readonly footerTemplate?: string | undefined
}

/** schema-checked request (the renderer is untrusted) */
export function parseWorkbookPdfRequest(input: unknown): WorkbookExportPdfRequest {
  return workbookExportPdfRequestSchema.parse(input)
}

async function printPass(
  page: Page,
  request: WorkbookExportPdfRequest,
  templates: TemplatePair | undefined,
  pageRanges?: string,
): Promise<Buffer> {
  const size =
    typeof request.pageSize === 'string'
      ? { format: request.pageSize }
      : { width: `${request.pageSize.width}in`, height: `${request.pageSize.height}in` }
  const m = request.margins
  return page.pdf({
    landscape: request.landscape,
    ...size,
    margin: { top: `${m.top}in`, bottom: `${m.bottom}in`, left: `${m.left}in`, right: `${m.right}in` },
    scale: request.scale,
    // pages declare their own paper via @page (a job may mix sheet sizes)
    preferCSSPageSize: true,
    printBackground: true,
    ...(pageRanges === undefined ? {} : { pageRanges }),
    ...(templates
      ? {
          displayHeaderFooter: true,
          headerTemplate: templates.headerTemplate ?? '<span></span>',
          footerTemplate: templates.footerTemplate ?? '<span></span>',
        }
      : {}),
  })
}

export async function renderWorkbookPdf(request: WorkbookExportPdfRequest): Promise<Uint8Array> {
  return withIsolatedHtmlPage(request.html, async (page) => {
    const oddTemplates: TemplatePair | undefined =
      request.headerTemplate !== undefined || request.footerTemplate !== undefined
        ? { headerTemplate: request.headerTemplate, footerTemplate: request.footerTemplate }
        : undefined
    const flags = { hasFirst: request.firstPage !== undefined, hasEven: request.evenPages !== undefined }
    const showHeaderFooter = oddTemplates !== undefined || flags.hasFirst || flags.hasEven
    const odd = await printPass(page, request, showHeaderFooter ? (oddTemplates ?? {}) : undefined)
    if (!flags.hasFirst && !flags.hasEven) return new Uint8Array(odd)

    const { PDFDocument: PdfDocument } = await import('pdf-lib')
    const oddDocument = await PdfDocument.load(odd)
    const total = oddDocument.getPageCount()
    const passes: Partial<Record<PageVariant, PDFDocument>> = { odd: oddDocument }
    if (request.firstPage !== undefined && total >= 1) {
      passes.first = await PdfDocument.load(await printPass(page, request, request.firstPage, '1'))
    }
    const evenRanges = evenPageRanges(total)
    if (request.evenPages !== undefined && evenRanges !== '') {
      passes.even = await PdfDocument.load(await printPass(page, request, request.evenPages, evenRanges))
    }
    const merged = await PdfDocument.create()
    for (const step of stitchPlan(total, flags)) {
      // a pass with fewer pages than planned falls back to the odd print of that page
      const source = passes[step.source]
      const [copied] =
        source !== undefined && step.index < source.getPageCount()
          ? await merged.copyPages(source, [step.index])
          : await merged.copyPages(oddDocument, [step.page - 1])
      if (copied) merged.addPage(copied)
    }
    return merged.save()
  })
}
