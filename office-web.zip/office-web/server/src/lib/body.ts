import type { Context } from 'hono'
import { config } from '../config'
import { StorageError } from '../storage'

/** request body as bytes, refusing anything over MAX_UPLOAD_MB */
export async function readBody(c: Context, limit = config.maxUploadBytes): Promise<Uint8Array> {
  const declared = Number(c.req.header('content-length') ?? NaN)
  if (Number.isFinite(declared) && declared > limit) throw new StorageError(413, 'File too large')
  const body = c.req.raw.body
  if (!body) return new Uint8Array(0)
  const reader = body.getReader()
  const chunks: Uint8Array[] = []
  let total = 0
  for (;;) {
    const { value, done } = await reader.read()
    if (done) break
    total += value.byteLength
    if (total > limit) {
      await reader.cancel()
      throw new StorageError(413, 'File too large')
    }
    chunks.push(value)
  }
  const out = new Uint8Array(total)
  let offset = 0
  for (const chunk of chunks) {
    out.set(chunk, offset)
    offset += chunk.byteLength
  }
  return out
}
