/**
 * Server-side headless Chromium: the web edition's stand-in for the desktop
 * app's hidden "--headless-export" windows.
 *
 *  - printHtmlToPdf / htmlToDocx: a user's HTML page rendered in a context
 *    whose only reachable origin is a virtual host serving that user's own
 *    folder; every other request is aborted, so a page (or a Markdown file
 *    with an <img src="http://169.254…">) cannot make the server fetch
 *    anything on its behalf.
 *  - exportViaEditor: loads our own editor page for a document as its owner
 *    (short-lived session) and runs the editor's own headless-export path,
 *    so the PDF is laid out by exactly the code the user edits with.
 */

import { existsSync } from 'node:fs'
import { createRequire } from 'node:module'
import { extname, join } from 'node:path'
import { mintSessionToken, revokeSessionToken, SESSION_COOKIE } from '../auth'
import { config } from '../config'
import { mimeFor, storageFor, normalizeVirtualPath } from '../storage'

type Browser = import('playwright-core').Browser
type BrowserContext = import('playwright-core').BrowserContext

const VIRTUAL_HOST = 'http://document.office-web.invalid'

const CHROME_CANDIDATES = [
  '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
  '/Applications/Chromium.app/Contents/MacOS/Chromium',
  '/usr/bin/chromium',
  '/usr/bin/chromium-browser',
  '/usr/bin/google-chrome',
  '/usr/bin/google-chrome-stable',
]

export class ChromeUnavailableError extends Error {}

let browserPromise: Promise<Browser> | null = null

/**
 * playwright-core stays out of the server bundle (it ships driver assets and
 * resolves files relative to itself); it is loaded at runtime from the
 * vendored upstream install, where it is a dev dependency.
 */
async function playwright(): Promise<typeof import('playwright-core')> {
  try {
    const req = createRequire(join(config.root, 'upstream', 'soffice', 'package.json'))
    return req('playwright-core') as typeof import('playwright-core')
  } catch {
    throw new ChromeUnavailableError('playwright-core is not installed (run "npm run setup")')
  }
}

export async function chromeExecutable(): Promise<string | null> {
  if (process.env.CHROME_PATH) return existsSync(process.env.CHROME_PATH) ? process.env.CHROME_PATH : null
  const bundled = await playwright()
    .then((pw) => pw.chromium.executablePath())
    .catch(() => '')
  if (bundled && existsSync(bundled)) return bundled
  return CHROME_CANDIDATES.find((p) => existsSync(p)) ?? null
}

export async function chromeAvailable(): Promise<boolean> {
  if (process.env.DISABLE_CHROME === '1') return false
  return (await chromeExecutable().catch(() => null)) !== null
}

async function browser(): Promise<Browser> {
  if (process.env.DISABLE_CHROME === '1') throw new ChromeUnavailableError('Headless Chrome is disabled')
  if (!browserPromise) {
    browserPromise = (async () => {
      const executablePath = await chromeExecutable()
      if (!executablePath) {
        throw new ChromeUnavailableError('No Chrome/Chromium found for PDF rendering (set CHROME_PATH)')
      }
      const pw = await playwright()
      const b = await pw.chromium.launch({
        executablePath,
        headless: true,
        args: ['--no-sandbox', '--disable-dev-shm-usage', '--font-render-hinting=none'],
      })
      b.on('disconnected', () => {
        browserPromise = null
      })
      return b
    })().catch((err) => {
      browserPromise = null
      throw err
    })
  }
  return browserPromise
}

export async function closeChrome(): Promise<void> {
  const p = browserPromise
  browserPromise = null
  if (p) await p.then((b) => b.close()).catch(() => undefined)
}

/**
 * A context that can only see `dir` of the user's tree through VIRTUAL_HOST
 * (plus inline data:/blob: URLs).
 */
async function sandboxedContext(userId: string, dir: string): Promise<BrowserContext> {
  const ctx = await (await browser()).newContext({
    viewport: { width: 1240, height: 1754 },
    javaScriptEnabled: true,
    serviceWorkers: 'block',
  })
  const s = storageFor(userId)
  const base = normalizeVirtualPath(dir)
  await ctx.route('**/*', async (route) => {
    const url = route.request().url()
    if (url.startsWith('data:') || url.startsWith('blob:')) return route.continue()
    if (!url.startsWith(`${VIRTUAL_HOST}/`)) return route.abort('blockedbyclient')
    try {
      const rel = decodeURIComponent(new URL(url).pathname)
      const v = normalizeVirtualPath(base === '/' ? rel : `${base}${rel}`)
      if (!v.startsWith(base)) return route.abort('accessdenied')
      const body = await s.read(v)
      return route.fulfill({ status: 200, body, headers: { 'content-type': mimeFor(v) } })
    } catch {
      return route.fulfill({ status: 404, body: '' })
    }
  })
  return ctx
}

function pageUrl(name: string): string {
  return `${VIRTUAL_HOST}/${encodeURIComponent(name)}`
}

/** print an HTML file of the user's tree (relative assets resolve inside its folder) */
export async function printHtmlToPdf(
  userId: string,
  dir: string,
  fileName: string,
  opts: { timeoutMs?: number; inlineHtml?: string } = {},
): Promise<Uint8Array> {
  const ctx = await sandboxedContext(userId, dir)
  try {
    if (opts.inlineHtml !== undefined) {
      // generated HTML (e.g. from Markdown) stands in for the file; its assets still come from the folder
      const html = opts.inlineHtml
      await ctx.route(pageUrl(fileName), (route) =>
        route.fulfill({ status: 200, body: html, headers: { 'content-type': 'text/html; charset=utf-8' } }),
      )
    }
    const page = await ctx.newPage()
    await page
      .goto(pageUrl(fileName), { waitUntil: 'networkidle', timeout: opts.timeoutMs ?? 60_000 })
      .catch(() => undefined)
    await page.evaluate(() => document.fonts.ready.then(() => undefined)).catch(() => undefined)
    await page.emulateMedia({ media: 'print' })
    return await page.pdf({
      printBackground: true,
      preferCSSPageSize: true,
      format: 'A4',
      margin: { top: '16mm', bottom: '16mm', left: '14mm', right: '14mm' },
    })
  } finally {
    await ctx.close().catch(() => undefined)
  }
}

/** html → docx through upstream html2docx, driven by this sandboxed browser */
export async function htmlToDocx(userId: string, dir: string, fileName: string): Promise<Uint8Array> {
  const { convertHtmlToDocx } = await import('../../../upstream/soffice/packages/html2docx/src/index')
  const ctx = await sandboxedContext(userId, dir)
  try {
    const page = await ctx.newPage()
    const driver = new PageDriver(ctx, page)
    const result = await convertHtmlToDocx({ url: pageUrl(fileName) }, driver, {})
    return result.docx
  } finally {
    await ctx.close().catch(() => undefined)
  }
}

/** html2docx's BrowserDriver over a page we own (mirrors its playwright driver) */
class PageDriver {
  constructor(
    private readonly ctx: BrowserContext,
    private readonly page: import('playwright-core').Page,
  ) {}
  async setViewport(v: { width: number; height: number }): Promise<void> {
    await this.page.setViewportSize({ width: v.width, height: v.height })
  }
  async goto(url: string, { timeoutMs }: { timeoutMs: number }): Promise<void> {
    await this.page.goto(url, { waitUntil: 'networkidle', timeout: timeoutMs }).catch(() => undefined)
  }
  evaluate<T>(fn: string | ((arg?: unknown) => T | Promise<T>), arg?: unknown): Promise<T> {
    if (typeof fn === 'string') return this.page.evaluate(fn) as Promise<T>
    return this.page.evaluate(fn as (a: unknown) => T, arg)
  }
  async addScript(source: string): Promise<void> {
    await this.page.addScriptTag({ content: source })
  }
  async addInitScript(source: string): Promise<void> {
    await this.page.addInitScript(source)
  }
  async screenshot(o: { clip?: { x: number; y: number; width: number; height: number }; omitBackground?: boolean }) {
    return this.page.screenshot({ type: 'png', fullPage: Boolean(o.clip), clip: o.clip, omitBackground: o.omitBackground })
  }
  async screenshotElement(selector: string, o: { omitBackground?: boolean }): Promise<Uint8Array | null> {
    const el = await this.page.$(selector)
    if (!el) return null
    const box = await el.evaluate((node) => {
      const r = node.getBoundingClientRect()
      return {
        x: Math.max(0, Math.round(r.left + window.scrollX)),
        y: Math.max(0, Math.round(r.top + window.scrollY)),
        width: Math.round(r.width),
        height: Math.round(r.height),
      }
    })
    if (box.width <= 0 || box.height <= 0) return null
    return this.screenshot({ clip: box, omitBackground: o.omitBackground })
  }
  async elementExists(selector: string): Promise<boolean> {
    return (await this.page.$(selector)) !== null
  }
  async close(): Promise<void> {
    await this.ctx.close()
  }
}

// ---- isolated HTML printing ------------------------------------------------------

/**
 * Print HTML an editor laid out (sheets print pages): scripts off and every
 * request refused except inline data:, the equivalent of the desktop's hidden
 * `javascript: false` window loading a temp file.
 */
export async function withIsolatedHtmlPage<T>(
  html: string,
  fn: (page: import('playwright-core').Page) => Promise<T>,
): Promise<T> {
  const ctx = await (await browser()).newContext({ javaScriptEnabled: false, serviceWorkers: 'block' })
  try {
    await ctx.route('**/*', (route) => {
      const url = route.request().url()
      if (url.startsWith('data:') || url === 'about:blank') return route.continue()
      return route.abort('blockedbyclient')
    })
    const page = await ctx.newPage()
    await page.setContent(html, { waitUntil: 'load', timeout: 60_000 })
    await page.emulateMedia({ media: 'print' })
    return await fn(page)
  } finally {
    await ctx.close().catch(() => undefined)
  }
}

// ---- editor-driven export ---------------------------------------------------

/**
 * Runs inside the editor page before its bundle. When the bridge exposes the
 * editor's API global, its headless-export calls are redirected into the
 * Playwright bindings below; everything else stays the bridge's.
 */
function headlessInit(globalName: string, overrides: string): string {
  return `
(() => {
  const origDefine = Object.defineProperty
  const OUT = '/__office_web_headless__/out.pdf'
  const overrides = ${overrides}
  Object.defineProperty = function (target, name, desc) {
    if (target === window && name === ${JSON.stringify(globalName)} && desc && desc.value) {
      const api = desc.value
      desc = Object.assign({}, desc, {
        value: new Proxy(api, { get: (t, p) => (p in overrides ? overrides[p] : Reflect.get(t, p)) }),
      })
    }
    return origDefine.call(this, target, name, desc)
  }
  window.print = () => undefined
})()
`
}

/** Docs: docs/src/renderer file-actions exportPdf + the headless-export grammar */
const DOCS_HEADLESS_INIT = headlessInit(
  'desktop',
  `{
    consumeHeadlessExport: async () => ({ outPath: OUT, format: 'pdf' }),
    headlessExportDone: (report) => { void window.__owDone(report) },
    exportPdf: async (_name, w, h, _out, scale) => {
      await window.__owPdf({ w, h, scale })
      return { ok: true, path: OUT }
    },
    printPdfBuffer: async (w, h, scale) => ({ ok: true, base64: await window.__owPdfBuffer({ w, h, scale }) }),
    saveMergedPdf: async (_name, parts) => {
      await window.__owMerged(parts)
      return { ok: true, path: OUT }
    },
  }`,
)

/** in-flight /api/apps/sheets requests, for SHEETS_HEADLESS_INIT's settle wait */
const SHEETS_ACTIVITY_INIT = `
(() => {
  const origFetch = window.fetch
  window.__owInflight = 0
  window.__owLastActivity = Date.now()
  window.fetch = function (input, init) {
    const url = typeof input === 'string' ? input : (input && input.url) || ''
    if (!url.includes('/api/apps/sheets/') || url.includes('/heartbeat')) return origFetch.call(this, input, init)
    window.__owInflight++
    window.__owLastActivity = Date.now()
    return origFetch.call(this, input, init).then((res) => {
      if (url.includes('/api/apps/sheets/open') && res.ok) window.__owOpened = true
      return res
    }).finally(() => {
      window.__owInflight--
      window.__owLastActivity = Date.now()
    })
  }
})()
`

/** Sheets: the renderer hands its print HTML to desktopApi.exportPdf (WorkbookExportPdfRequest) */
const SHEETS_HEADLESS_INIT = headlessInit(
  'desktopApi',
  `{
    // Formulas without cached values (files written by other tools) are computed
    // after the workbook opens; upstream's headless path only waits for the
    // open. Hold the export until the workbook is open and the page is quiet.
    consumeHeadlessExport: async () => {
      const started = Date.now()
      const quiet = () => (window.__owInflight || 0) === 0 && Date.now() - (window.__owLastActivity || 0) > 2000
      while (Date.now() - started < 120000 && !(window.__owOpened && quiet())) {
        await new Promise((r) => setTimeout(r, 250))
      }
      await new Promise((r) => setTimeout(r, 1500))
      return OUT
    },
    headlessExportDone: (report) => { void window.__owDone(report) },
    exportPdf: async (request) => {
      await window.__owSheetsPdf(request)
      return { canceled: false, path: OUT }
    },
  }`,
)

/** Slides: the renderer hands its laid-out pages to slidesApi.exportPdf (ExportPdfOp) */
const SLIDES_HEADLESS_INIT = headlessInit(
  'slidesApi',
  `{
    consumeHeadlessExport: async () => OUT,
    headlessExportDone: (report) => { void window.__owDone(report) },
    pickExportPdfPath: async () => OUT,
    exportPdf: async (op) => {
      await window.__owSlidesPdf(op)
      return { ok: true, path: OUT }
    },
  }`,
)

const TWIPS_PER_INCH = 1440

export type EditorApp = 'docs' | 'sheets' | 'slides'

/** which editor can print which extension through its headless-export path */
export const EDITOR_PDF_EXTS: Record<string, EditorApp> = {
  '.docx': 'docs',
  '.dotx': 'docs',
  '.xlsx': 'sheets',
  '.xlsm': 'sheets',
  '.csv': 'sheets',
  '.pptx': 'slides',
}

export async function exportViaEditor(
  userId: string,
  virtualPath: string,
  opts: { timeoutMs?: number } = {},
): Promise<Uint8Array> {
  const app = EDITOR_PDF_EXTS[extname(virtualPath).toLowerCase()]
  if (!app) throw new ChromeUnavailableError(`No editor can print ${extname(virtualPath)} files`)
  const origin = process.env.INTERNAL_ORIGIN ?? `http://127.0.0.1:${config.port}`
  const token = mintSessionToken(userId)
  const ctx = await (await browser()).newContext({ viewport: { width: 1400, height: 1000 } })
  try {
    const { hostname } = new URL(origin)
    await ctx.addCookies([{ name: SESSION_COOKIE, value: token, domain: hostname, path: '/', httpOnly: true }])
    // the editor talks to our origin only
    await ctx.route('**/*', (route) => {
      const url = route.request().url()
      if (url.startsWith(origin) || url.startsWith('data:') || url.startsWith('blob:')) return route.continue()
      return route.abort('blockedbyclient')
    })
    const page = await ctx.newPage()
    if (app === 'sheets') await page.addInitScript(SHEETS_ACTIVITY_INIT)
    await page.addInitScript(
      app === 'docs' ? DOCS_HEADLESS_INIT : app === 'sheets' ? SHEETS_HEADLESS_INIT : SLIDES_HEADLESS_INIT,
    )

    let result: Uint8Array | null = null
    const done = new Promise<{ ok: boolean; error?: string }>((resolve) => {
      void page.exposeFunction('__owDone', (report: { ok: boolean; error?: string }) => resolve(report))
    })

    if (app === 'docs') {
      const printPage = async (g: { w: number; h: number; scale?: number }) => {
        await page.emulateMedia({ media: 'print' })
        const scale = typeof g.scale === 'number' && g.scale >= 0.1 && g.scale <= 2 ? g.scale : undefined
        return page.pdf({
          printBackground: true,
          width: `${g.w / TWIPS_PER_INCH}in`,
          height: `${g.h / TWIPS_PER_INCH}in`,
          margin: { top: '0', bottom: '0', left: '0', right: '0' },
          ...(scale ? { scale } : {}),
        })
      }
      await page.exposeFunction('__owPdf', async (g: { w: number; h: number; scale?: number }) => {
        result = await printPage(g)
      })
      await page.exposeFunction('__owPdfBuffer', async (g: { w: number; h: number; scale?: number }) =>
        Buffer.from(await printPage(g)).toString('base64'),
      )
      await page.exposeFunction('__owMerged', async (parts: string[]) => {
        const { PDFDocument } = await import('pdf-lib')
        const merged = await PDFDocument.create()
        for (const b64 of parts) {
          const src = await PDFDocument.load(Buffer.from(b64, 'base64'))
          for (const p of await merged.copyPages(src, src.getPageIndices())) merged.addPage(p)
        }
        result = await merged.save()
      })
    } else if (app === 'sheets') {
      await page.exposeFunction('__owSheetsPdf', async (request: unknown) => {
        const { parseWorkbookPdfRequest, renderWorkbookPdf } = await import('./sheets-pdf')
        result = await renderWorkbookPdf(parseWorkbookPdfRequest({ ...(request as object), outPath: undefined }))
      })
    } else {
      await page.exposeFunction('__owSlidesPdf', async (op: never) => {
        const { renderSlidesPdf } = await import('../apps/slides')
        result = await renderSlidesPdf(userId, op)
      })
    }

    const timeoutMs = opts.timeoutMs ?? 180_000
    await page.goto(`${origin}/app/${app}/?${new URLSearchParams({ path: normalizeVirtualPath(virtualPath) })}`, {
      waitUntil: 'domcontentloaded',
      timeout: 60_000,
    })
    const report = await Promise.race([
      done,
      new Promise<{ ok: false; error: string }>((resolve) =>
        setTimeout(() => resolve({ ok: false, error: 'the editor did not finish the export in time' }), timeoutMs),
      ),
    ])
    if (!report.ok) throw new Error(report.error ?? 'export failed')
    if (!result) throw new Error('the editor reported success but produced no PDF')
    return result
  } finally {
    await ctx.close().catch(() => undefined)
    revokeSessionToken(token)
  }
}
