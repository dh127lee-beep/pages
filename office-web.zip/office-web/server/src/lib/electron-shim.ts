/**
 * Stand-in for the `electron` module in the server bundle. Some upstream
 * main-process helpers that are otherwise plain Node import one or two
 * Electron APIs (e.g. nativeImage for PNG encoding); this provides those on
 * top of pure-JS codecs and turns everything else into an explicit error.
 */

import { PNG } from 'pngjs'

class ServerNativeImage {
  constructor(
    private readonly width: number,
    private readonly height: number,
    /** straight-alpha BGRA */
    private readonly bgra: Buffer | null,
  ) {}

  isEmpty(): boolean {
    return !this.bgra || this.width === 0 || this.height === 0
  }

  getSize(): { width: number; height: number } {
    return { width: this.width, height: this.height }
  }

  /** premultiplied BGRA, as Electron returns it */
  toBitmap(): Buffer {
    const src = this.bgra ?? Buffer.alloc(0)
    const out = Buffer.from(src)
    for (let i = 0; i < out.length; i += 4) {
      const a = out[i + 3]!
      if (a < 255) {
        out[i] = Math.round((out[i]! * a) / 255)
        out[i + 1] = Math.round((out[i + 1]! * a) / 255)
        out[i + 2] = Math.round((out[i + 2]! * a) / 255)
      }
    }
    return out
  }

  toPNG(): Buffer {
    const png = new PNG({ width: this.width, height: this.height })
    const src = this.bgra ?? Buffer.alloc(0)
    for (let i = 0; i < src.length; i += 4) {
      png.data[i] = src[i + 2]!
      png.data[i + 1] = src[i + 1]!
      png.data[i + 2] = src[i]!
      png.data[i + 3] = src[i + 3]!
    }
    return PNG.sync.write(png)
  }
}

export const nativeImage = {
  createEmpty: () => new ServerNativeImage(0, 0, null),
  /** PNG only (no JPEG decoder on the server) */
  createFromBuffer(buf: Buffer): ServerNativeImage {
    try {
      const png = PNG.sync.read(buf)
      const bgra = Buffer.alloc(png.data.length)
      for (let i = 0; i < png.data.length; i += 4) {
        bgra[i] = png.data[i + 2]!
        bgra[i + 1] = png.data[i + 1]!
        bgra[i + 2] = png.data[i]!
        bgra[i + 3] = png.data[i + 3]!
      }
      return new ServerNativeImage(png.width, png.height, bgra)
    } catch {
      return new ServerNativeImage(0, 0, null)
    }
  },
  /** input: BGRA as pdfium/Chromium produce it, treated as straight alpha */
  createFromBitmap(buf: Buffer, size: { width: number; height: number }): ServerNativeImage {
    return new ServerNativeImage(size.width, size.height, Buffer.from(buf))
  },
}

function unavailable(name: string): never {
  throw new Error(`electron.${name} is not available on the web server`)
}

const stub = (name: string) =>
  new Proxy(
    {},
    {
      get(_t, prop) {
        if (prop === 'then' || typeof prop === 'symbol') return undefined
        return () => unavailable(`${name}.${String(prop)}`)
      },
    },
  ) as never

export const app = stub('app')
export const BrowserWindow = stub('BrowserWindow')
export const BrowserView = stub('BrowserView')
export const WebContentsView = stub('WebContentsView')
export const dialog = stub('dialog')
export const ipcMain = stub('ipcMain')
export const ipcRenderer = stub('ipcRenderer')
export const contextBridge = stub('contextBridge')
export const webUtils = stub('webUtils')
export const shell = stub('shell')
export const protocol = stub('protocol')
export const net = stub('net')
export const session = stub('session')
export const clipboard = stub('clipboard')
export const Menu = stub('Menu')
export const MenuItem = stub('MenuItem')
export const screen = stub('screen')
export const webContents = stub('webContents')
export const nativeTheme = stub('nativeTheme')
export const systemPreferences = stub('systemPreferences')
export const powerMonitor = stub('powerMonitor')
export const safeStorage = stub('safeStorage')
export const utilityProcess = stub('utilityProcess')
export const globalShortcut = stub('globalShortcut')
export const desktopCapturer = stub('desktopCapturer')
export const Notification = stub('Notification')
export const Tray = stub('Tray')
export const autoUpdater = stub('autoUpdater')
export const crashReporter = stub('crashReporter')
export const MessageChannelMain = stub('MessageChannelMain')

export default {
  nativeImage,
  app,
  BrowserWindow,
  dialog,
  ipcMain,
  shell,
  protocol,
  net,
  session,
  clipboard,
}
