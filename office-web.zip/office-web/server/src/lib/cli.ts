/**
 * The upstream `soffice` command line (built into dist/tools/cli by
 * scripts/build-tools.mjs), run as a child process: a crash or a runaway
 * conversion never takes the server down, and every call is bounded in time
 * and in how many run at once.
 */

import { spawn } from 'node:child_process'
import { existsSync } from 'node:fs'
import { join } from 'node:path'
import { config } from '../config'

export interface CliResult {
  status: 'ok' | 'error' | string
  summary?: string
  output_path?: string
  code?: number
  error?: string
  message?: string
  detail?: Record<string, unknown>
  [key: string]: unknown
}

export class CliUnavailableError extends Error {}

export function cliPath(): string {
  return process.env.SOFFICE_CLI ?? join(config.toolsDir, 'cli', 'soffice.cjs')
}

export function cliAvailable(): boolean {
  return existsSync(cliPath())
}

/** where the Rust workbook engine lives, if it was built */
export function xlsxSidecarPath(): string | null {
  if (process.env.XLSX_SIDECAR_PATH) return process.env.XLSX_SIDECAR_PATH
  const exe = process.platform === 'win32' ? 'xlsx-sidecar.exe' : 'xlsx-sidecar'
  const candidates = [
    join(config.toolsDir, exe),
    join(config.toolsDir, 'native', exe),
    join(config.toolsDir, 'xlsx-engine-target', 'release', exe),
    join(config.root, 'upstream', 'soffice', 'apps', 'sheets', 'native', 'xlsx-engine', 'target', 'release', exe),
  ]
  return candidates.find((p) => existsSync(p)) ?? null
}

// ---- concurrency gate --------------------------------------------------------

const MAX_PARALLEL = Math.max(1, Number(process.env.CONVERT_CONCURRENCY ?? 2) || 2)
let running = 0
const waiting: Array<() => void> = []

export async function withSlot<T>(fn: () => Promise<T>): Promise<T> {
  if (running >= MAX_PARALLEL) await new Promise<void>((resolve) => waiting.push(resolve))
  running++
  try {
    return await fn()
  } finally {
    running--
    waiting.shift()?.()
  }
}

/**
 * Run `soffice <args…> --json` and parse its one-line JSON envelope. Never
 * throws for a CLI-reported failure (status "error"); throws only when the
 * CLI is missing, times out or prints something unparsable.
 */
export function runCli(args: string[], opts: { timeoutMs?: number; cwd?: string } = {}): Promise<CliResult> {
  const bin = cliPath()
  if (!existsSync(bin)) {
    return Promise.reject(new CliUnavailableError('The conversion tools are not built (run "npm run build")'))
  }
  const timeoutMs = opts.timeoutMs ?? Number(process.env.CONVERT_TIMEOUT_MS ?? 180_000)
  const env: NodeJS.ProcessEnv = {
    PATH: process.env.PATH,
    HOME: process.env.HOME,
    LANG: process.env.LANG ?? 'C.UTF-8',
    TMPDIR: process.env.TMPDIR,
    // the CLI must never try to launch a desktop app on the server
    SOFFICE_APP_BIN: '/nonexistent/soffice-app',
  }
  const sidecar = xlsxSidecarPath()
  if (sidecar) env.XLSX_SIDECAR_PATH = sidecar
  return withSlot(
    () =>
      new Promise<CliResult>((resolve, reject) => {
        const child = spawn(process.execPath, [bin, ...args, '--json'], {
          cwd: opts.cwd,
          env,
          stdio: ['ignore', 'pipe', 'pipe'],
        })
        let stdout = ''
        let stderr = ''
        child.stdout.on('data', (d: Buffer) => {
          if (stdout.length < 8_000_000) stdout += d.toString('utf8')
        })
        child.stderr.on('data', (d: Buffer) => {
          if (stderr.length < 64_000) stderr += d.toString('utf8')
        })
        const timer = setTimeout(() => {
          child.kill('SIGKILL')
          reject(new Error(`conversion timed out after ${Math.round(timeoutMs / 1000)}s`))
        }, timeoutMs)
        child.on('error', (err) => {
          clearTimeout(timer)
          reject(err)
        })
        child.on('close', () => {
          clearTimeout(timer)
          const line = stdout.trim().split('\n').reverse().find((l) => l.startsWith('{'))
          if (!line) {
            reject(new Error(`conversion produced no result${stderr ? `: ${stderr.trim().slice(0, 500)}` : ''}`))
            return
          }
          try {
            resolve(JSON.parse(line) as CliResult)
          } catch {
            reject(new Error('conversion produced an unreadable result'))
          }
        })
      }),
  )
}
