import {
  fetchRemoteImage,
  MAX_REMOTE_IMAGE_BYTES,
  readBodyCapped,
} from '@soffice/electron-utils/remote-image'

/**
 * Download a picture an AI tool call pointed at. The URL is prompt-injectable,
 * so it goes through the upstream SSRF guard (no private/link-local targets,
 * every redirect hop re-validated) and a size cap.
 */
export async function fetchImageAsBase64(url: string): Promise<{ base64: string; mime: string } | null> {
  try {
    if (!/^https?:\/\//i.test(url)) return null
    const resp = await fetchRemoteImage(url)
    if (!resp || !resp.ok) return null
    const buf = Buffer.from(await readBodyCapped(resp, MAX_REMOTE_IMAGE_BYTES))
    const ct = resp.headers.get('content-type') ?? ''
    const mime = ct.includes('png')
      ? 'image/png'
      : ct.includes('gif')
        ? 'image/gif'
        : ct.includes('webp')
          ? 'image/webp'
          : 'image/jpeg'
    return { base64: buf.toString('base64'), mime }
  } catch {
    return null
  }
}
