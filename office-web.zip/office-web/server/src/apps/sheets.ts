/**
 * Sheets: server side of upstream apps/sheets/src/main/sheets-main.ts.
 *
 * Workbooks live in the Rust xlsx sidecar (one process per active user).
 * Every session works on a byte snapshot of the file taken at open; saves
 * patch that snapshot into the target file and the session is swapped for a
 * fresh one over the saved bytes, exactly like the desktop app. Sessions the
 * browser stops heartbeating (tab closed, crashed, offline) are closed by a
 * sweeper so neither sidecar memory nor temp snapshots leak.
 */

import { createHash, randomUUID } from 'node:crypto'
import { existsSync, statSync } from 'node:fs'
import { copyFile, mkdir, readFile, rm, stat, writeFile } from 'node:fs/promises'
import { basename, join, posix } from 'node:path'
import { Hono } from 'hono'
import { z } from 'zod'
import {
  csvToXlsxBufferForOpen,
  decodeCsvBuffer,
  sheetCsvToXlsxBuffer,
} from '@soffice/xlsx-gateway/gateway/csv-import'
import { readArchiveEntryText } from '@soffice/xlsx-gateway/gateway/xlsx-package-io'
import { parsePivotDefinition } from '@soffice/xlsx-gateway/gateway/xlsx-pivot'
import {
  setSystemShortDate,
  shortDatePatternForSystemLocale,
} from '@soffice/xlsx-gateway/shared/short-date'
import {
  workbookFileSchema,
  workbookFindCellsRequestSchema,
  workbookFindCellsResultSchema,
  workbookFormulaCellsRequestSchema,
  workbookFormulaCellsResultSchema,
  workbookMediaRequestSchema,
  workbookMediaResultSchema,
  workbookPivotDefinitionSchema,
  workbookPivotRequestSchema,
  workbookRangeRequestSchema,
  workbookRangeResultSchema,
  workbookRecalcRequestSchema,
  workbookRecalcResultSchema,
  workbookRowOutlineResultSchema,
  workbookSaveEditsAbortSchema,
  workbookSaveEditsBeginSchema,
  workbookSaveEditsChunkSchema,
  saveEditsChunkArraySchema,
  workbookSaveRequestSchema,
  type WorkbookFile,
  type WorkbookSaveRequest,
} from '../../../upstream/soffice/apps/sheets/src/shared/desktop-api'
import { allowsAutomaticWorkbookRecovery } from '../../../upstream/soffice/apps/sheets/src/main/recovery-policy'
import { SaveEditsTransferStore } from '../../../upstream/soffice/apps/sheets/src/main/save-edits-transfer'
import {
  cleanupImportTempDirectory,
  cleanupSessionResources,
} from '../../../upstream/soffice/apps/sheets/src/main/temp-files'
import { sessionAfterRename } from '../../../upstream/soffice/apps/sheets/src/main/session-rename'
import { XlsxSidecarClient } from '../../../upstream/soffice/apps/sheets/src/main/xlsx-sidecar-client'
import type { AppEnv } from '../auth'
import { config } from '../config'
import { getUserSetting, touchRecent } from '../db'
import { setSessionPathResolver } from '../routes/assist'
import { normalizeVirtualPath, storageFor, StorageError } from '../storage'
import { registerAppModule } from './index'
import { writeWorkbookTo } from './sheets/write'

// ---- configuration ------------------------------------------------------------

const EXE = process.platform === 'win32' ? 'xlsx-sidecar.exe' : 'xlsx-sidecar'

function sidecarBinary(): string {
  return process.env.XLSX_ENGINE_BIN ?? join(config.toolsDir, EXE)
}

/** temp root for snapshots and converted imports (names checked by temp-files.ts) */
const TEMP_ROOT = () => join(config.dataDir, 'tmp', 'sheets')
const SNAPSHOT_DIR = () => join(TEMP_ROOT(), 'soffice-sheets-sessions')
const IMPORT_DIR = () => join(TEMP_ROOT(), 'soffice-imports')

const BLANK_TEMPLATE = join(
  config.root,
  'upstream',
  'soffice',
  'apps',
  'shell',
  'build',
  'shell-new',
  'blank.xlsx',
)

const WORKBOOK_EXTS = new Set(['xlsx', 'xlsm', 'xls', 'csv', 'tsv', 'ods', 'ots'])
const MAX_DELIMITED_IMPORT_BYTES = 32 * 1024 * 1024
/** a session nobody has touched or heartbeated for this long is closed */
const SESSION_IDLE_MS = Number(process.env.SHEETS_SESSION_IDLE_MS ?? 10 * 60_000)
/** a user's sidecar with no sessions is stopped after this long */
const CLIENT_IDLE_MS = 5 * 60_000

// ---- per-user state ---------------------------------------------------------------

interface Session {
  /** disk path the session writes back to (the backing temp file for imports/new) */
  readonly path: string
  /** what the browser sees: the user's file (virtual) */
  readonly virtualPath: string | null
  readonly snapshotPath: string
  readonly sha256: string
  readonly sheetNames: ReadonlyMap<string, string>
  readonly automaticRecoveryDisabled: boolean
  /** first save goes through Save As, defaulting to this virtual path */
  readonly suggestSaveAs?: string
  readonly unsavedNew?: boolean
  readonly csvImport?: boolean
  /** CSV session: the original .csv (disk path) Save writes back to */
  readonly csvSourcePath?: string
  readonly csvSourceSha?: string
  readonly importTempDir?: string
  lastSeen: number
}

interface UserSheets {
  readonly userId: string
  client: XlsxSidecarClient
  readonly sessions: Map<string, Session>
  readonly saveTransfers: SaveEditsTransferStore
  /** session ids lost to a sidecar crash, reported once to their tab */
  readonly crashed: Set<string>
  lastUsed: number
}

const users = new Map<string, UserSheets>()

function newClient(entry: Pick<UserSheets, 'sessions' | 'crashed'>): XlsxSidecarClient {
  const bin = sidecarBinary()
  if (!existsSync(bin)) {
    throw new StorageError(
      400,
      'The spreadsheet engine is not installed on this server (run "npm run setup").',
    )
  }
  const client = new XlsxSidecarClient(bin)
  client.onProcessExit(() => {
    // every session id the process held is gone; temp files go with them
    for (const [id, s] of entry.sessions) {
      entry.crashed.add(id)
      void rm(s.snapshotPath, { force: true }).catch(() => undefined)
      if (s.importTempDir) void cleanupImportTempDirectory(TEMP_ROOT(), s.importTempDir)
    }
    entry.sessions.clear()
  })
  return client
}

function userSheets(userId: string): UserSheets {
  let entry = users.get(userId)
  if (!entry) {
    const partial = { sessions: new Map<string, Session>(), crashed: new Set<string>() }
    entry = {
      userId,
      ...partial,
      client: newClient(partial),
      saveTransfers: new SaveEditsTransferStore(),
      lastUsed: Date.now(),
    }
    users.set(userId, entry)
  }
  entry.lastUsed = Date.now()
  return entry
}

function sessionOf(entry: UserSheets, sessionId: string): Session {
  const session = entry.sessions.get(sessionId)
  if (!session) throw new Error('Unknown workbook session.')
  session.lastSeen = Date.now()
  return session
}

async function closeSession(entry: UserSheets, sessionId: string): Promise<void> {
  entry.saveTransfers.discardSession(sessionId)
  const session = entry.sessions.get(sessionId)
  if (!session || !entry.sessions.delete(sessionId)) return
  await cleanupSessionResources({
    tempRoot: TEMP_ROOT(),
    snapshotPath: session.snapshotPath,
    importTempDir: session.importTempDir,
    closeSidecar: () => entry.client.close(sessionId),
  })
}

async function sweep(): Promise<void> {
  const now = Date.now()
  for (const entry of [...users.values()]) {
    for (const [id, s] of [...entry.sessions]) {
      if (now - s.lastSeen > SESSION_IDLE_MS) await closeSession(entry, id).catch(() => undefined)
    }
    if (entry.sessions.size === 0 && now - entry.lastUsed > CLIENT_IDLE_MS) {
      entry.client.stop()
      users.delete(entry.userId)
    }
  }
}

// ---- helpers ------------------------------------------------------------------------

async function sha256File(path: string): Promise<string> {
  return createHash('sha256')
    .update(await readFile(path))
    .digest('hex')
}

function uiLang(userId: string): string {
  return getUserSetting<{ language?: string }>(userId, 'prefs', {}).language ?? 'en'
}

const LOCALE_BY_LANG: Record<string, string> = {
  zh: 'zh-CN',
  en: 'en-US',
  ja: 'ja-JP',
  ko: 'ko-KR',
  fr: 'fr-FR',
  de: 'de-DE',
  es: 'es-ES',
  th: 'th-TH',
  id: 'id-ID',
  ru: 'ru-RU',
  ar: 'ar-SA',
}

/** the gateway's short date is process-wide; follow the requesting user's locale */
function shortDateFor(locale: string): string {
  const pattern = shortDatePatternForSystemLocale(locale)
  setSystemShortDate(pattern)
  return pattern
}

const LEGACY_CSV_CHARSET: Record<string, string> = {
  zh: 'gb18030',
  ja: 'shift_jis',
  ko: 'euc-kr',
}

async function snapshotWorkbook(path: string): Promise<string> {
  await mkdir(SNAPSHOT_DIR(), { recursive: true })
  const snapshotPath = join(SNAPSHOT_DIR(), `${randomUUID()}.xlsx`)
  await copyFile(path, snapshotPath)
  return snapshotPath
}

async function newImportDir(): Promise<string> {
  const dir = join(IMPORT_DIR(), randomUUID())
  await mkdir(dir, { recursive: true })
  return dir
}

interface OpenOptions {
  virtualPath: string | null
  locale: string
  suggestSaveAs?: string
  csvImport?: boolean
  csvSourcePath?: string
  csvVirtualPath?: string
  emptyCsv?: boolean
  importTempDir?: string
  unsavedNew?: boolean
}

async function openWorkbookSession(
  entry: UserSheets,
  path: string,
  options: OpenOptions,
): Promise<WorkbookFile> {
  const snapshotPath = await snapshotWorkbook(path)
  try {
    const lang = uiLang(entry.userId)
    const [opened, digest, snapshotStat, csvSourceSha] = await Promise.all([
      entry.client.open(snapshotPath, lang, shortDateFor(options.locale)).then((result) =>
        workbookFileSchema.omit({ sha256: true, readOnly: true }).parse(result),
      ),
      sha256File(snapshotPath),
      stat(snapshotPath),
      options.csvSourcePath === undefined
        ? Promise.resolve(undefined)
        : sha256File(options.csvSourcePath).catch(() => undefined),
    ])
    const recoveryDisabled = !allowsAutomaticWorkbookRecovery(opened.sheets)
    entry.sessions.set(opened.sessionId, {
      path,
      virtualPath: options.virtualPath,
      snapshotPath,
      sha256: digest,
      sheetNames: new Map(opened.sheets.map((sheet) => [sheet.id, sheet.name])),
      automaticRecoveryDisabled: recoveryDisabled,
      lastSeen: Date.now(),
      ...(options.suggestSaveAs === undefined ? {} : { suggestSaveAs: options.suggestSaveAs }),
      ...(options.unsavedNew ? { unsavedNew: true } : {}),
      ...(options.csvImport ? { csvImport: true } : {}),
      ...(options.csvSourcePath === undefined ? {} : { csvSourcePath: options.csvSourcePath }),
      ...(csvSourceSha === undefined ? {} : { csvSourceSha }),
      ...(options.importTempDir === undefined ? {} : { importTempDir: options.importTempDir }),
    })
    const shownPath = options.csvVirtualPath ?? options.virtualPath ?? options.suggestSaveAs
    return workbookFileSchema.parse({
      ...opened,
      // the browser only ever sees virtual paths of the user's own tree
      ...(options.virtualPath && !options.unsavedNew
        ? { path: options.virtualPath }
        : { path: undefined }),
      name: shownPath ? posix.basename(shownPath) : opened.name,
      sha256: digest,
      fileBytes: snapshotStat.size,
      readOnly: false,
      needsSaveAs: options.suggestSaveAs !== undefined,
      ...(options.unsavedNew ? { unsavedNew: true } : {}),
      ...(options.csvVirtualPath ? { csvPath: options.csvVirtualPath } : {}),
      ...(options.emptyCsv ? { emptyCsv: true } : {}),
      restoredFromRecovery: false,
      automaticRecoveryDisabled: recoveryDisabled,
    })
  } catch (error) {
    await rm(snapshotPath, { force: true }).catch(() => undefined)
    if (options.importTempDir !== undefined) {
      await cleanupImportTempDirectory(TEMP_ROOT(), options.importTempDir)
    }
    throw error
  }
}

/**
 * Open a file of the user's tree. .csv/.tsv/.xls/.ods convert to an .xlsx copy
 * in the temp dir: CSV keeps its identity (Save writes values back), the
 * others save through Save As to a sibling .xlsx — the desktop rules.
 */
async function openUserWorkbook(entry: UserSheets, virtualPath: string, locale: string): Promise<WorkbookFile> {
  const storage = storageFor(entry.userId)
  const v = normalizeVirtualPath(virtualPath)
  const disk = storage.resolve(v)
  if (!existsSync(disk) || statSync(disk).isDirectory()) throw new StorageError(404, 'Workbook not found')
  const ext = v.slice(v.lastIndexOf('.') + 1).toLowerCase()
  if (!WORKBOOK_EXTS.has(ext)) throw new StorageError(400, `Unsupported workbook: .${ext}`)
  touchRecent(entry.userId, v)

  if (ext === 'xlsx' || ext === 'xlsm') {
    if ((await stat(disk)).size === 0) {
      // a 0-byte .xlsx is an empty workbook: run on a blank archive, save over the original
      const dir = await newImportDir()
      const openPath = join(dir, basename(disk))
      await writeFile(openPath, (await csvToXlsxBufferForOpen('', 'Sheet1')).buffer)
      const file = await openWorkbookSession(entry, openPath, {
        virtualPath: v,
        locale,
        importTempDir: dir,
      })
      // saves of this session land on the real file
      const s = [...entry.sessions.values()].find((x) => x.path === openPath)
      if (s) entry.sessions.set(file.sessionId, { ...s, path: disk })
      return file
    }
    return openWorkbookSession(entry, disk, { virtualPath: v, locale })
  }

  const stem = posix.basename(v).replace(/\.[^.]+$/, '')
  const dir = await newImportDir()
  const openPath = join(dir, `${stem}.xlsx`)
  let emptyCsv = false
  try {
    if (ext === 'csv' || ext === 'tsv') {
      if ((await stat(disk)).size > MAX_DELIMITED_IMPORT_BYTES) throw new StorageError(413, 'File too large')
      const converted = await csvToXlsxBufferForOpen(
        decodeCsvBuffer(await readFile(disk), LEGACY_CSV_CHARSET[uiLang(entry.userId)]),
        'Sheet1',
        ext === 'tsv' ? '\t' : undefined,
      )
      emptyCsv = converted.empty
      await writeFile(openPath, converted.buffer)
    } else {
      await entry.client.convertWorkbook({ path: disk, targetPath: openPath })
    }
  } catch (error) {
    await cleanupImportTempDirectory(TEMP_ROOT(), dir)
    throw error
  }
  if (ext === 'csv') {
    return openWorkbookSession(entry, openPath, {
      virtualPath: v,
      locale,
      importTempDir: dir,
      csvImport: true,
      csvSourcePath: disk,
      csvVirtualPath: v,
      ...(emptyCsv ? { emptyCsv: true } : {}),
    })
  }
  const suggestSaveAs = await storage.uniquePath(posix.dirname(v), `${stem}.xlsx`)
  return openWorkbookSession(entry, openPath, {
    virtualPath: v,
    locale,
    importTempDir: dir,
    suggestSaveAs,
    ...(ext === 'tsv' ? { csvImport: true } : {}),
  })
}

/** "New spreadsheet": the blank template in a temp dir; the first Save is a Save As */
async function openNewWorkbook(entry: UserSheets, dir: string, name: string, locale: string): Promise<WorkbookFile> {
  const storage = storageFor(entry.userId)
  const suggestSaveAs = await storage.uniquePath(normalizeVirtualPath(dir || '/'), name)
  const tempDir = await newImportDir()
  const openPath = join(tempDir, posix.basename(suggestSaveAs))
  if (existsSync(BLANK_TEMPLATE)) await copyFile(BLANK_TEMPLATE, openPath)
  else await writeFile(openPath, (await csvToXlsxBufferForOpen('', 'Sheet1')).buffer)
  return openWorkbookSession(entry, openPath, {
    virtualPath: null,
    locale,
    suggestSaveAs,
    importTempDir: tempDir,
    unsavedNew: true,
  })
}

const BOM = Buffer.from([0xef, 0xbb, 0xbf])

// ---- routes -------------------------------------------------------------------------

const routes = new Hono<AppEnv>()

const userId = (c: { get(key: 'user'): { id: string } }) => c.get('user').id

routes.get('/status', (c) => c.json({ engine: existsSync(sidecarBinary()) }))

routes.post('/open', async (c) => {
  const body = await c.req.json<{ path?: string; locale?: string }>()
  const entry = userSheets(userId(c))
  return c.json(await openUserWorkbook(entry, String(body.path ?? ''), String(body.locale ?? 'en-US')))
})

routes.post('/new', async (c) => {
  const body = await c.req.json<{ dir?: string; name?: string; locale?: string }>()
  const entry = userSheets(userId(c))
  const name = typeof body.name === 'string' && /\.xlsx$/i.test(body.name) ? body.name : 'Book.xlsx'
  return c.json(await openNewWorkbook(entry, String(body.dir ?? '/'), name, String(body.locale ?? 'en-US')))
})

routes.post('/read-range', async (c) => {
  const entry = userSheets(userId(c))
  const request = workbookRangeRequestSchema.parse(await c.req.json())
  sessionOf(entry, request.sessionId)
  return c.json(workbookRangeResultSchema.parse(await entry.client.readRange(request)))
})

routes.post('/read-formulas', async (c) => {
  const entry = userSheets(userId(c))
  const request = workbookFormulaCellsRequestSchema.parse(await c.req.json())
  sessionOf(entry, request.sessionId)
  return c.json(workbookFormulaCellsResultSchema.parse(await entry.client.readFormulaCells(request)))
})

routes.post('/find-cells', async (c) => {
  const entry = userSheets(userId(c))
  const request = workbookFindCellsRequestSchema.parse(await c.req.json())
  sessionOf(entry, request.sessionId)
  return c.json(workbookFindCellsResultSchema.parse(await entry.client.findCells(request)))
})

routes.post('/read-row-outline', async (c) => {
  const entry = userSheets(userId(c))
  const request = workbookFormulaCellsRequestSchema.parse(await c.req.json())
  sessionOf(entry, request.sessionId)
  return c.json(workbookRowOutlineResultSchema.parse(await entry.client.readRowOutline(request)))
})

const sidecarRecalcResultSchema = z
  .object({
    cells: z.array(
      z
        .object({
          sheet: z.string(),
          row: z.number().int().nonnegative(),
          column: z.number().int().nonnegative(),
          formatted: z.string(),
          number: z.number().optional(),
          isError: z.boolean().optional(),
          isFormula: z.boolean(),
        })
        .strict(),
    ),
    cached: z.boolean().optional(),
  })
  .strict()

routes.post('/recalc', async (c) => {
  const entry = userSheets(userId(c))
  const request = workbookRecalcRequestSchema.parse(await c.req.json())
  const session = sessionOf(entry, request.sessionId)
  const fileSheetName = (sheetId: string): string => {
    const name = session.sheetNames.get(sheetId)
    if (name === undefined) throw new Error(`Unknown sheet for recalculation: ${sheetId}`)
    return name
  }
  const result = sidecarRecalcResultSchema.parse(
    await entry.client.recalcCells({
      path: session.snapshotPath,
      edits: request.edits.map((edit) => ({
        sheet: fileSheetName(edit.sheetId),
        row: edit.row,
        column: edit.column,
        input: edit.input,
      })),
      reads: request.reads.map((read) => ({ sheet: fileSheetName(read.sheetId), range: read.range })),
    }),
  )
  const idsByName = new Map([...session.sheetNames].map(([id, name]) => [name, id]))
  return c.json(
    workbookRecalcResultSchema.parse({
      cells: result.cells.flatMap((cell) => {
        const sheetId = idsByName.get(cell.sheet)
        if (sheetId === undefined) return []
        return [
          {
            sheetId,
            row: cell.row,
            column: cell.column,
            formatted: cell.formatted,
            ...(cell.number === undefined ? {} : { number: cell.number }),
            ...(cell.isError ? { isError: true } : {}),
            isFormula: cell.isFormula,
          },
        ]
      }),
    }),
  )
})

routes.post('/read-media', async (c) => {
  const entry = userSheets(userId(c))
  const request = workbookMediaRequestSchema.parse(await c.req.json())
  sessionOf(entry, request.sessionId)
  return c.json(workbookMediaResultSchema.parse(await entry.client.readMedia(request)))
})

routes.post('/read-pivot', async (c) => {
  const entry = userSheets(userId(c))
  const request = workbookPivotRequestSchema.parse(await c.req.json())
  const session = sessionOf(entry, request.sessionId)
  const [pivotXml, cacheXml] = await Promise.all([
    readArchiveEntryText(entry.client, session.snapshotPath, request.path),
    readArchiveEntryText(entry.client, session.snapshotPath, request.cachePath),
  ])
  return c.json(workbookPivotDefinitionSchema.parse(parsePivotDefinition(pivotXml, cacheXml)))
})

routes.post('/save-edits-begin', async (c) => {
  const entry = userSheets(userId(c))
  const request = workbookSaveEditsBeginSchema.parse(await c.req.json())
  sessionOf(entry, request.sessionId)
  entry.saveTransfers.begin(request)
  return c.json(null)
})

routes.post('/save-edits-chunk', async (c) => {
  const entry = userSheets(userId(c))
  const request = workbookSaveEditsChunkSchema.parse(await c.req.json())
  entry.saveTransfers.addChunk({
    sessionId: request.sessionId,
    transferId: request.transferId,
    seq: request.seq,
    edits: saveEditsChunkArraySchema.parse(JSON.parse(request.editsJson)),
  })
  return c.json(null)
})

routes.post('/save-edits-abort', async (c) => {
  const entry = userSheets(userId(c))
  const request = workbookSaveEditsAbortSchema.parse(await c.req.json())
  entry.saveTransfers.discard(request.transferId, request.sessionId)
  return c.json(null)
})

const DISK_CHANGED =
  'The file was changed elsewhere after it was opened. Use Save As to keep your version.'

/**
 * Save. Where the desktop app shows a Save As dialog, the browser has already
 * asked the user (bridge) and passes the chosen virtual path as `target`;
 * without one such a save is reported as canceled.
 */
routes.post('/save', async (c) => {
  const uid = userId(c)
  const entry = userSheets(uid)
  const storage = storageFor(uid)
  const body = await c.req.json<{ request: unknown; target?: string }>()
  let request: WorkbookSaveRequest = workbookSaveRequestSchema.parse(body.request)
  if (request.targetPath !== undefined) throw new StorageError(400, 'Explicit save paths are not supported')
  if (request.editsTransferId !== undefined) {
    if (request.edits.length > 0) throw new Error('Save request mixes inline and transferred edits.')
    request = { ...request, edits: entry.saveTransfers.take(request.editsTransferId, request.sessionId) }
  }
  const session = sessionOf(entry, request.sessionId)

  const csvInPlace = request.mode === 'save' && session.csvSourcePath !== undefined
  let targetPath = session.path
  let targetVirtual = session.virtualPath
  const quietUnsavedNew = request.mode === 'save' && request.quiet === true && session.unsavedNew === true
  if (quietUnsavedNew) {
    targetPath = session.path
  } else if (request.mode === 'save-as' || session.suggestSaveAs !== undefined) {
    if (!body.target) return c.json({ canceled: true })
    const chosen = normalizeVirtualPath(body.target)
    if (chosen.toLowerCase().endsWith('.csv')) return c.json({ canceled: true, csvSaveAsPath: chosen })
    const macroEnabled = /\.xlsm$/i.test(session.suggestSaveAs ?? session.virtualPath ?? '')
    const ext = macroEnabled ? '.xlsm' : '.xlsx'
    targetVirtual = chosen.toLowerCase().endsWith(ext) ? chosen : `${chosen}${ext}`
    targetPath = storage.resolve(targetVirtual)
    if (!existsSync(storage.resolve(posix.dirname(targetVirtual)))) throw new StorageError(404, 'Folder not found')
  } else {
    // refuse to silently overwrite a file changed elsewhere since open
    const currentSha = await sha256File(session.path).catch(() => undefined)
    if (currentSha !== undefined && currentSha !== session.sha256) throw new Error(DISK_CHANGED)
  }
  if (csvInPlace && session.csvSourcePath !== undefined) {
    const csvSha = await sha256File(session.csvSourcePath).catch(() => undefined)
    if (csvSha !== undefined && csvSha !== session.csvSourceSha) throw new Error(DISK_CHANGED)
  }

  const mutation = await writeWorkbookTo(entry.client, session, request, targetPath)

  if (csvInPlace && session.csvSourcePath !== undefined && request.csvContent !== undefined) {
    await writeFile(session.csvSourcePath, Buffer.concat([BOM, Buffer.from(request.csvContent, 'utf8')]))
  }

  // swap the session for a fresh one over the saved bytes
  entry.sessions.delete(request.sessionId)
  await cleanupSessionResources({
    tempRoot: TEMP_ROOT(),
    snapshotPath: session.snapshotPath,
    importTempDir: csvInPlace || quietUnsavedNew ? undefined : session.importTempDir,
    closeSidecar: () => entry.client.close(request.sessionId),
  })
  const locale = LOCALE_BY_LANG[uiLang(uid)] ?? 'en-US'
  const file = await openWorkbookSession(
    entry,
    targetPath,
    csvInPlace
      ? {
          virtualPath: session.virtualPath,
          locale,
          csvImport: true,
          csvSourcePath: session.csvSourcePath,
          csvVirtualPath: session.virtualPath ?? undefined,
          importTempDir: session.importTempDir,
        }
      : quietUnsavedNew
        ? {
            virtualPath: null,
            locale,
            suggestSaveAs: session.suggestSaveAs,
            importTempDir: session.importTempDir,
            unsavedNew: true,
          }
        : { virtualPath: targetVirtual, locale },
  )
  if (!quietUnsavedNew && targetVirtual) touchRecent(uid, targetVirtual)
  return c.json({ canceled: false, file, touchedEntries: mutation.touchedEntries })
})

routes.post('/close', async (c) => {
  const { sessionId } = await c.req.json<{ sessionId: string }>()
  const entry = users.get(userId(c))
  if (entry && typeof sessionId === 'string') await closeSession(entry, sessionId)
  return c.json(null)
})

/** Home renamed or moved a file: sessions that write back to it follow (upstream session-rename) */
routes.post('/file-moved', async (c) => {
  const uid = userId(c)
  const { oldPath, newPath } = await c.req.json<{ oldPath: string; newPath: string }>()
  const entry = users.get(uid)
  if (!entry) return c.json({ renamed: false })
  const s = storageFor(uid)
  const oldV = normalizeVirtualPath(oldPath)
  const newV = normalizeVirtualPath(newPath)
  const oldDisk = s.resolve(oldV)
  const newDisk = s.resolve(newV)
  let renamed = false
  for (const [id, session] of entry.sessions) {
    let next = sessionAfterRename(session, oldDisk, newDisk)
    if (session.virtualPath === oldV) next = { ...(next ?? session), virtualPath: newV }
    if (next) {
      entry.sessions.set(id, next)
      renamed = true
    }
  }
  return c.json({ renamed })
})

/** the tab is alive: keep its sessions; reports sessions a sidecar crash took */
routes.post('/heartbeat', async (c) => {
  const { sessionIds } = await c.req.json<{ sessionIds: string[] }>()
  const entry = users.get(userId(c))
  let crashed = false
  for (const id of Array.isArray(sessionIds) ? sessionIds : []) {
    const s = entry?.sessions.get(id)
    if (s) s.lastSeen = Date.now()
    else if (entry?.crashed.delete(id)) crashed = true
  }
  if (entry) entry.lastUsed = Date.now()
  return c.json({ crashed })
})

/** CSV export: UTF-8 with BOM into the user's tree */
routes.post('/export-csv', async (c) => {
  const uid = userId(c)
  const { path, content } = await c.req.json<{ path: string; content: string }>()
  if (typeof content !== 'string' || content.length > 64_000_000) throw new StorageError(400, 'Invalid CSV')
  let v = normalizeVirtualPath(path)
  if (!v.toLowerCase().endsWith('.csv')) v = `${v}.csv`
  const st = await storageFor(uid).write(v, Buffer.concat([BOM, Buffer.from(content, 'utf8')]))
  // a CSV session over this very file must not read its own export as an external change
  const entry = users.get(uid)
  if (entry) {
    const disk = storageFor(uid).resolve(v)
    const sha = await sha256File(disk).catch(() => undefined)
    for (const [id, s] of entry.sessions) {
      if (s.csvSourcePath === disk && sha) entry.sessions.set(id, { ...s, csvSourceSha: sha })
    }
  }
  return c.json({ canceled: false, path: st.path })
})

/**
 * PDF export: the print HTML the renderer laid out (live workbook state, so
 * unsaved edits are included), printed by headless Chrome like the desktop's
 * hidden window, written next to the workbook under a free name.
 */
routes.post('/export-pdf', async (c) => {
  const uid = userId(c)
  if (Number(c.req.header('content-length') ?? 0) > 48 * 1024 * 1024) {
    throw new StorageError(413, 'Workbook print layout too large')
  }
  const { request, dir } = await c.req.json<{ request: unknown; dir?: string }>()
  const { parseWorkbookPdfRequest, renderWorkbookPdf } = await import('../lib/sheets-pdf')
  let parsed
  try {
    parsed = parseWorkbookPdfRequest({ ...(request as object), outPath: undefined })
  } catch {
    throw new StorageError(400, 'Invalid PDF export request')
  }
  const pdf = await renderWorkbookPdf(parsed)
  const s = storageFor(uid)
  const stem = basename(parsed.fileName).replace(/\.[^.]+$/, '') || 'workbook'
  const target = await s.uniquePath(normalizeVirtualPath(dir || '/'), `${stem}.pdf`)
  const st = await s.write(target, pdf, { overwrite: false })
  return c.json({ canceled: false, path: st.path })
})

/** AI create_document for csv/xlsx: a new file in the given folder */
routes.post('/create-document', async (c) => {
  const uid = userId(c)
  const body = await c.req.json<{ type: string; title: string; content: string; sheetName?: string; dir?: string }>()
  const storage = storageFor(uid)
  const base = (String(body.title ?? '').replace(/[\\/:*?"<>|\u0000-\u001f]/g, '_').trim() || 'Untitled').slice(0, 120)
  const dir = normalizeVirtualPath(body.dir || '/')
  try {
    if (body.type === 'csv') {
      const path = await storage.uniquePath(dir, `${base}.csv`)
      await storage.write(path, Buffer.concat([BOM, Buffer.from(String(body.content), 'utf8')]), { overwrite: false })
      return c.json({ ok: true, path })
    }
    if (body.type === 'xlsx') {
      const buffer = await sheetCsvToXlsxBuffer(String(body.content), body.sheetName ?? 'Sheet1')
      const path = await storage.uniquePath(dir, `${base}.xlsx`)
      await storage.write(path, new Uint8Array(buffer), { overwrite: false })
      return c.json({ ok: true, path })
    }
    if (body.type === 'md') {
      const path = await storage.uniquePath(dir, `${base}.md`)
      await storage.write(path, Buffer.from(String(body.content), 'utf8'), { overwrite: false })
      return c.json({ ok: true, path })
    }
    return c.json({ ok: false, error: `Creating ${body.type} files is not available in the web edition` })
  } catch (err) {
    return c.json({ ok: false, error: err instanceof Error ? err.message : String(err) })
  }
})

/** AI add_image from a file: only pictures inside the user's own tree */
routes.post('/read-local-image', async (c) => {
  const { path } = await c.req.json<{ path: string }>()
  const bytes = await storageFor(userId(c)).read(normalizeVirtualPath(path))
  if (bytes.length > 20 * 1024 * 1024) throw new StorageError(413, 'Image too large')
  const mediaType =
    bytes[0] === 0x89 && bytes[1] === 0x50
      ? 'image/png'
      : bytes[0] === 0xff && bytes[1] === 0xd8
        ? 'image/jpeg'
        : bytes.subarray(0, 4).toString('latin1') === 'GIF8'
          ? 'image/gif'
          : null
  if (!mediaType) throw new StorageError(400, 'Not a PNG, JPEG or GIF picture')
  return c.json({ mediaType, base64: bytes.toString('base64') })
})

// chat history for an unsaved workbook resolves through its session
setSessionPathResolver((uid, sessionId) => users.get(uid)?.sessions.get(sessionId)?.virtualPath ?? null)

let sweeper: NodeJS.Timeout | null = null

registerAppModule({
  id: 'sheets',
  routes,
  async start() {
    await mkdir(TEMP_ROOT(), { recursive: true })
    // snapshots/imports of a previous run belong to sessions that no longer exist
    await rm(SNAPSHOT_DIR(), { recursive: true, force: true }).catch(() => undefined)
    await rm(IMPORT_DIR(), { recursive: true, force: true }).catch(() => undefined)
    if (!existsSync(sidecarBinary())) {
      console.warn(`[sheets] spreadsheet engine missing at ${sidecarBinary()} — run "npm run setup"`)
    }
    sweeper = setInterval(() => void sweep(), 60_000)
    sweeper.unref()
  },
  async stop() {
    if (sweeper) clearInterval(sweeper)
    for (const entry of users.values()) {
      for (const id of [...entry.sessions.keys()]) await closeSession(entry, id).catch(() => undefined)
      entry.client.stop()
    }
    users.clear()
  },
})
