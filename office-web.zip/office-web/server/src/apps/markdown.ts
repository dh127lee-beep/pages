/**
 * markdown: server side of apps/markdown/src/main (ported).
 *
 * The document text lives in the user's tree; pasted/picked images become
 * owned assets next to it, managed by the upstream asset-lifecycle module
 * (manifest, Save As relocation, orphan cleanup) — unchanged, on disk paths.
 */

import { existsSync } from 'node:fs'
import { readFile } from 'node:fs/promises'
import { dirname, extname, resolve } from 'node:path'
import { Hono } from 'hono'
import {
  extractMarkdownImageSources,
  pendingOwnedAssetsForDocument,
  prepareAssetsForSaveAs,
  reconcileOwnedAssets,
  resolveSafeRelativeImagePath,
  resolveSourcePendingAfterSaveAs,
  rollbackPreparedSaveAsAssets,
  writeImageIntoOwnedAssets,
} from '../../../upstream/soffice/apps/markdown/src/main/asset-lifecycle'
import { resolveWikiLinks, nodeFs } from '../../../upstream/soffice/apps/markdown/src/main/wiki-resolve'
import { nodeVaultFs, wikiBacklinks, wikiGraph } from '../../../upstream/soffice/apps/markdown/src/main/wiki-index'
import { EXPORT_IMAGE_MIME_BY_EXT } from '../../../upstream/soffice/apps/markdown/src/shared/export-image-mime'
import type { AppEnv } from '../auth'
import { touchRecent } from '../db'
import { fetchImageAsBase64 } from '../lib/remote'
import { registerAppModule } from './index'
import { docCtx, safeBaseName } from './pmh/paths'
import { htmlToPdf } from './pmh/render'

const routes = new Hono<AppEnv>()
const MAX_IMAGE_B64 = Math.ceil((50 * 1024 * 1024) / 3) * 4
const IMAGE_EXTS = Object.keys(EXPORT_IMAGE_MIME_BY_EXT).map((e) => e.replace(/^\./, ''))

/**
 * Write the document. `currentPath` is the file the editor had open (null when
 * untitled), `target` where it goes now — the bridge already chose it (Save As
 * dialog / silent first save), so this is the upstream save handler minus the dialog.
 */
routes.post('/save', async (c) => {
  const userId = c.get('user').id
  const ctx = docCtx(userId)
  const body = await c.req.json<{
    text: string
    imageSources?: string[]
    currentPath?: string | null
    target: string
    mode?: 'save' | 'saveAs'
  }>()
  if (typeof body.text !== 'string') return c.json({ ok: false, error: 'markdown: bad save request' })
  if (body.imageSources && !body.imageSources.every((s) => typeof s === 'string')) {
    return c.json({ ok: false, error: 'markdown: bad image references' })
  }
  try {
    const target = ctx.disk(body.target)
    if (!existsSync(dirname(target))) return c.json({ ok: false, error: 'Folder not found' })
    const currentPath = body.currentPath ? ctx.disk(body.currentPath) : null
    const pendingAtRequest = currentPath ? await pendingOwnedAssetsForDocument(currentPath) : []
    const imageSources = [...(body.imageSources ?? [])]
    const known = new Set(imageSources)
    for (const source of extractMarkdownImageSources(body.text)) {
      if (!known.has(source)) {
        known.add(source)
        imageSources.push(source)
      }
    }
    const prepared =
      currentPath && resolve(dirname(currentPath)) !== resolve(dirname(target))
        ? await prepareAssetsForSaveAs(currentPath, target, body.text, imageSources)
        : null
    const textToWrite = prepared?.text ?? body.text
    try {
      await ctx.s.write(body.target, Buffer.from(textToWrite, 'utf8'))
    } catch (err) {
      if (prepared) await rollbackPreparedSaveAsAssets(prepared).catch(() => undefined)
      throw err
    }
    const pendingNames = prepared
      ? prepared.created.map((r) => r.name)
      : currentPath && resolve(currentPath) === resolve(target)
        ? pendingAtRequest
        : []
    await reconcileOwnedAssets(target, prepared?.imageSources ?? imageSources, { pendingNames }).catch(
      (err) => console.warn('[markdown] asset reconciliation failed:', err),
    )
    if (body.mode === 'saveAs' && currentPath && resolve(currentPath) !== resolve(target)) {
      await resolveSourcePendingAfterSaveAs(currentPath, pendingAtRequest).catch(() => undefined)
    }
    touchRecent(userId, ctx.virtual(target))
    return c.json({
      ok: true,
      path: ctx.virtual(target),
      ...(prepared?.rewrites.length ? { imageRewrites: prepared.rewrites, writtenText: textToWrite } : {}),
    })
  } catch (err) {
    return c.json({ ok: false, error: err instanceof Error ? err.message : String(err) })
  }
})

/** pasted/dropped/picked picture → owned asset beside the document; returns the path to author */
routes.post('/save-image', async (c) => {
  const ctx = docCtx(c.get('user').id)
  const { docPath, base64, ext, name } = await c.req.json<{
    docPath: string
    base64: string
    ext: string
    name?: string
  }>()
  const e = String(ext ?? '').toLowerCase().replace(/^\./, '')
  if (!docPath || typeof base64 !== 'string' || !base64 || base64.length > MAX_IMAGE_B64) {
    return c.json({ path: null })
  }
  if (!IMAGE_EXTS.includes(e)) return c.json({ path: null })
  const stem = name ? safeBaseName(String(name).replace(/\.[^.]+$/, ''), 'image') : 'image'
  const rel = await writeImageIntoOwnedAssets(ctx.disk(docPath), `${stem}.${e}`, Buffer.from(base64, 'base64'))
  return c.json({ path: rel })
})

/** picture bytes for the DOCX export: doc-relative files, or remote URLs through the SSRF guard */
routes.post('/read-image', async (c) => {
  const ctx = docCtx(c.get('user').id)
  const { docPath, src } = await c.req.json<{ docPath: string | null; src: string }>()
  if (typeof src !== 'string') return c.json(null)
  if (/^https?:/i.test(src)) return c.json(await fetchImageAsBase64(src))
  if (!docPath || /^[a-z][a-z0-9+.-]*:/i.test(src)) return c.json(null)
  const target = await resolveSafeRelativeImagePath(ctx.disk(docPath), src)
  if (!target) return c.json(null)
  const mime = EXPORT_IMAGE_MIME_BY_EXT[extname(target).toLowerCase() as keyof typeof EXPORT_IMAGE_MIME_BY_EXT]
  if (!mime || !existsSync(target)) return c.json(null)
  return c.json({ base64: (await readFile(target)).toString('base64'), mime })
})

// ---- wiki links: the vault is the user's whole tree ----

routes.post('/wiki/resolve', async (c) => {
  const ctx = docCtx(c.get('user').id)
  const { fromPath, targets } = await c.req.json<{ fromPath: string; targets: string[] }>()
  const list = Array.isArray(targets) ? targets.filter((t) => typeof t === 'string').slice(0, 500) : []
  const from = fromPath ? ctx.disk(fromPath) : ''
  const resolved = await resolveWikiLinks(list, { fromPath: from, root: ctx.s.root }, nodeFs())
  const out: Record<string, unknown> = {}
  for (const [key, value] of resolved) {
    out[key] = { ...value, path: value.path ? ctx.virtual(value.path) : '' }
  }
  return c.json(out)
})

routes.post('/wiki/backlinks', async (c) => {
  const ctx = docCtx(c.get('user').id)
  const { path } = await c.req.json<{ path: string }>()
  if (!path) return c.json([])
  const links = await wikiBacklinks(ctx.s.root, ctx.disk(path), nodeVaultFs())
  return c.json(links.map((l) => ({ ...l, source: ctx.virtual(l.source) })))
})

routes.get('/wiki/graph', async (c) => {
  const ctx = docCtx(c.get('user').id)
  const graph = await wikiGraph(ctx.s.root, nodeVaultFs())
  return c.json({
    ...graph,
    nodes: graph.nodes.map((n) => ({ ...n, path: ctx.virtual(n.path) })),
    edges: graph.edges.map((e) => ({ from: ctx.virtual(e.from), to: ctx.virtual(e.to) })),
  })
})

/** print HTML (self-contained, built by the renderer) → PDF bytes */
routes.post('/print-pdf', async (c) => {
  const { html } = await c.req.json<{ html: string }>()
  if (typeof html !== 'string') return c.json({ error: 'bad request' }, 400)
  try {
    const pdf = await htmlToPdf(html)
    return new Response(new Uint8Array(pdf), { headers: { 'content-type': 'application/pdf' } })
  } catch (err) {
    return c.json({ error: err instanceof Error ? err.message : String(err) }, 503)
  }
})

registerAppModule({ id: 'markdown', routes })
