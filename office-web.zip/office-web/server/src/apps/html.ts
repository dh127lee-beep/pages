/**
 * html: server side of apps/html/src/main (ported).
 *
 * Live preview: the desktop app serves the editor buffer on html-preview://
 * with relative assets on html-asset://. Here each editor view gets an
 * unguessable token; the buffer is served at /pub/html/p/<token>/ and the
 * document's folder at /pub/html/p/<token>/a/…. Those responses always carry
 * a CSP sandbox (opaque origin), so user scripts never run with this origin's
 * privileges even when the URL is opened top-level.
 */

import { randomBytes } from 'node:crypto'
import { existsSync } from 'node:fs'
import { readFile, open } from 'node:fs/promises'
import { dirname, extname, posix, resolve } from 'node:path'
import { Hono } from 'hono'
import {
  extractHtmlAssetReferences,
  pendingOwnedAssetsForDocument,
  prepareAssetsForSaveAs,
  reconcileOwnedAssets,
  resolveSafeRelativeImagePath,
  resolveSourcePendingAfterSaveAs,
  rollbackPreparedSaveAsAssets,
  writeImageIntoOwnedAssets,
} from '../../../upstream/soffice/apps/html/src/main/asset-lifecycle'
import { ASSET_SNIFF_BYTES, editableImageMime } from '../../../upstream/soffice/apps/html/src/main/asset-mime'
import { buildPreviewDocument } from '../../../upstream/soffice/apps/html/src/main/preview-document'
import { inlineImagesForSingleFile } from '../../../upstream/soffice/apps/html/src/main/single-file-html'
import { convertHtmlToDocx } from '../../../upstream/soffice/packages/html2docx/src'
import type { AppEnv } from '../auth'
import { touchRecent } from '../db'
import { mimeFor, normalizeVirtualPath, storageFor } from '../storage'
import { registerAppModule } from './index'
import { docCtx, folderAssets, safeBaseName } from './pmh/paths'
import { DOC_ORIGIN, DOCUMENT_URL, htmlToPdf, SandboxedDriver, withSandboxedPage } from './pmh/render'

const routes = new Hono<AppEnv>()
const publicRoutes = new Hono()

const IMAGE_EXTS = ['png', 'jpg', 'jpeg', 'gif']
const MIME_BY_EXT: Record<string, string> = {
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
}

// ---- live preview -------------------------------------------------------------

interface PreviewEntry {
  userId: string
  text: string
  /** virtual path of the open document, null while untitled */
  docPath: string | null
  touched: number
}

const previews = new Map<string, PreviewEntry>()
const PREVIEW_TTL_MS = 12 * 3_600_000

const pruneTimer = setInterval(() => {
  const cutoff = Date.now() - PREVIEW_TTL_MS
  for (const [token, entry] of previews) if (entry.touched < cutoff) previews.delete(token)
}, 600_000)
pruneTimer.unref()

const SANDBOX_CSP = 'sandbox allow-scripts allow-forms allow-popups allow-modals'

routes.post('/preview', async (c) => {
  const userId = c.get('user').id
  const body = await c.req.json<{ token?: string; text?: string; docPath?: string | null }>()
  let token = typeof body.token === 'string' ? body.token : ''
  let entry = token ? previews.get(token) : undefined
  if (!entry || entry.userId !== userId) {
    token = randomBytes(24).toString('base64url')
    entry = { userId, text: '', docPath: null, touched: Date.now() }
    previews.set(token, entry)
  }
  if (typeof body.text === 'string') entry.text = body.text
  if (body.docPath !== undefined) {
    entry.docPath = body.docPath ? normalizeVirtualPath(body.docPath) : null
  }
  entry.touched = Date.now()
  return c.json({ token, url: `/pub/html/p/${token}/` })
})

publicRoutes.get('/p/:token/', (c) => {
  const entry = previews.get(c.req.param('token'))
  if (!entry) return c.text('Preview expired', 404)
  entry.touched = Date.now()
  const base = `/pub/html/p/${c.req.param('token')}/a/`
  return c.body(buildPreviewDocument(entry.text, entry.docPath ? base : null), 200, {
    'content-type': 'text/html; charset=utf-8',
    'cache-control': 'no-store',
    'content-security-policy': SANDBOX_CSP,
    'x-frame-options': 'SAMEORIGIN',
  })
})

/** files of the previewed document's folder (and below), nothing else */
publicRoutes.get('/p/:token/a/*', async (c) => {
  const entry = previews.get(c.req.param('token'))
  if (!entry || !entry.docPath) return c.text('Not found', 404)
  const prefix = `/pub/html/p/${c.req.param('token')}/a/`
  let rel: string
  try {
    rel = decodeURIComponent(new URL(c.req.url).pathname.slice(prefix.length))
  } catch {
    return c.text('Bad path', 400)
  }
  if (!rel || rel.split('/').some((s) => s === '..' || s === '.')) return c.text('Not found', 404)
  const s = storageFor(entry.userId)
  let v: string
  try {
    v = normalizeVirtualPath(posix.join(posix.dirname(entry.docPath), rel))
  } catch {
    return c.text('Not found', 404)
  }
  const st = await s.stat(v).catch(() => null)
  if (!st || st.isDir) return c.text('Not found', 404)
  const ext = extname(v).toLowerCase()
  let type =
    ext === '.css' ? 'text/css; charset=utf-8' : ext === '.js' || ext === '.mjs' ? 'text/javascript' : mimeFor(v)
  if (type === 'application/octet-stream') {
    // "save page as, complete" assets have no extension
    const fh = await open(s.resolve(v), 'r')
    try {
      const head = Buffer.alloc(ASSET_SNIFF_BYTES)
      await fh.read(head, 0, head.length, 0)
      type = editableImageMime(head) ?? type
    } finally {
      await fh.close()
    }
  }
  return c.body(await readFile(s.resolve(v)), 200, {
    'content-type': type,
    'cache-control': 'no-cache',
    'content-security-policy': SANDBOX_CSP,
    'x-content-type-options': 'nosniff',
  })
})

// ---- save / images ---------------------------------------------------------------

routes.post('/save', async (c) => {
  const userId = c.get('user').id
  const ctx = docCtx(userId)
  const body = await c.req.json<{
    text: string
    imageSources?: string[]
    currentPath?: string | null
    target: string
    mode?: 'save' | 'saveAs'
  }>()
  if (typeof body.text !== 'string') return c.json({ ok: false, error: 'html: bad save request' })
  try {
    const target = ctx.disk(body.target)
    if (!existsSync(dirname(target))) return c.json({ ok: false, error: 'Folder not found' })
    const currentPath = body.currentPath ? ctx.disk(body.currentPath) : null
    const pendingAtRequest = currentPath ? await pendingOwnedAssetsForDocument(currentPath) : []
    const imageSources = [...(body.imageSources ?? []).filter((s) => typeof s === 'string')]
    const known = new Set(imageSources)
    for (const source of extractHtmlAssetReferences(body.text)) {
      if (!known.has(source)) {
        known.add(source)
        imageSources.push(source)
      }
    }
    const prepared =
      currentPath && resolve(dirname(currentPath)) !== resolve(dirname(target))
        ? await prepareAssetsForSaveAs(currentPath, target, body.text, imageSources)
        : null
    const textToWrite = prepared?.text ?? body.text
    try {
      await ctx.s.write(body.target, Buffer.from(textToWrite, 'utf8'))
    } catch (err) {
      if (prepared) await rollbackPreparedSaveAsAssets(prepared).catch(() => undefined)
      throw err
    }
    const pendingNames = prepared
      ? prepared.created.map((r) => r.name)
      : currentPath && resolve(currentPath) === resolve(target)
        ? pendingAtRequest
        : []
    await reconcileOwnedAssets(target, prepared?.imageSources ?? imageSources, { pendingNames }).catch(
      (err) => console.warn('[html] asset reconciliation failed:', err),
    )
    if (body.mode === 'saveAs' && currentPath && resolve(currentPath) !== resolve(target)) {
      await resolveSourcePendingAfterSaveAs(currentPath, pendingAtRequest).catch(() => undefined)
    }
    touchRecent(userId, ctx.virtual(target))
    return c.json({
      ok: true,
      path: ctx.virtual(target),
      ...(prepared?.rewrites.length ? { imageRewrites: prepared.rewrites } : {}),
    })
  } catch (err) {
    return c.json({ ok: false, error: err instanceof Error ? err.message : String(err) })
  }
})

routes.post('/save-image', async (c) => {
  const ctx = docCtx(c.get('user').id)
  const { docPath, base64, ext, name } = await c.req.json<{
    docPath: string
    base64: string
    ext: string
    name?: string
  }>()
  const e = String(ext ?? '').toLowerCase().replace(/^\./, '')
  if (!docPath || typeof base64 !== 'string' || !base64 || !IMAGE_EXTS.includes(e)) {
    return c.json({ path: null })
  }
  if (base64.length > Math.ceil((50 * 1024 * 1024) / 3) * 4) return c.json({ path: null })
  const stem = name ? safeBaseName(String(name).replace(/\.[^.]+$/, ''), 'image') : 'image'
  const rel = await writeImageIntoOwnedAssets(ctx.disk(docPath), `${stem}.${e}`, Buffer.from(base64, 'base64'))
  return c.json({ path: rel })
})

routes.post('/read-image', async (c) => {
  const ctx = docCtx(c.get('user').id)
  const { docPath, src } = await c.req.json<{ docPath: string | null; src: string }>()
  if (!docPath || typeof src !== 'string' || /^[a-z][a-z0-9+.-]*:/i.test(src)) return c.json(null)
  const target = await resolveSafeRelativeImagePath(ctx.disk(docPath), src)
  if (!target || !existsSync(target)) return c.json(null)
  const bytes = await readFile(target)
  const mime = MIME_BY_EXT[extname(target).toLowerCase()] ?? editableImageMime(bytes.subarray(0, ASSET_SNIFF_BYTES))
  if (!mime) return c.json(null)
  return c.json({ base64: bytes.toString('base64'), mime })
})

// ---- exports ---------------------------------------------------------------------

/** the document as the preview shows it, with relative assets served from its folder */
function renderSource(userId: string, html: string, docPath: string | null) {
  const ctx = docCtx(userId)
  const dir = docPath ? posix.dirname(normalizeVirtualPath(docPath)) : null
  return {
    html: buildPreviewDocument(html, dir ? `${DOC_ORIGIN}/` : null),
    assets: folderAssets(ctx, dir),
  }
}

routes.post('/export-pdf', async (c) => {
  const { html, docPath } = await c.req.json<{ html: string; docPath?: string | null }>()
  if (typeof html !== 'string') return c.json({ error: 'bad request' }, 400)
  try {
    const src = renderSource(c.get('user').id, html, docPath ?? null)
    // same as the desktop export window: scripts off, 0.6in margins
    const pdf = await htmlToPdf(src.html, { assets: src.assets, javaScript: false, marginIn: 0.6 })
    return new Response(new Uint8Array(pdf), { headers: { 'content-type': 'application/pdf' } })
  } catch (err) {
    return c.json({ error: err instanceof Error ? err.message : String(err) }, 503)
  }
})

routes.post('/export-docx', async (c) => {
  const { html, docPath } = await c.req.json<{ html: string; docPath?: string | null }>()
  if (typeof html !== 'string') return c.json({ error: 'bad request' }, 400)
  try {
    const src = renderSource(c.get('user').id, html, docPath ?? null)
    const docx = await withSandboxedPage(
      { html: src.html, assets: src.assets, viewport: { width: 794, height: 1123, deviceScaleFactor: 2 } },
      async (page) => {
        const driver = new SandboxedDriver(page)
        let timer: NodeJS.Timeout | undefined
        try {
          return await Promise.race([
            convertHtmlToDocx({ url: DOCUMENT_URL }, driver).then((r) => r.docx),
            new Promise<never>((_, reject) => {
              timer = setTimeout(() => reject(new Error('html export timed out')), 180_000)
            }),
          ])
        } finally {
          clearTimeout(timer)
        }
      },
    )
    return new Response(Buffer.from(docx), {
      headers: {
        'content-type': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      },
    })
  } catch (err) {
    return c.json({ error: err instanceof Error ? err.message : String(err) }, 503)
  }
})

/** single-file HTML: local images inlined as data URLs */
routes.post('/export-html', async (c) => {
  const ctx = docCtx(c.get('user').id)
  const { html, docPath } = await c.req.json<{ html: string; docPath?: string | null }>()
  if (typeof html !== 'string') return c.json({ error: 'bad request' }, 400)
  const result = await inlineImagesForSingleFile(html, docPath ? ctx.disk(docPath) : null)
  return c.json({ html: result.html, skipped: result.skipped })
})

registerAppModule({ id: 'html', routes, publicRoutes })
