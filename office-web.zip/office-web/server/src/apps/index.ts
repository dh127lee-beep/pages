/**
 * Per-editor server modules: whatever an app's Electron main process did
 * beyond plain file I/O (workbook sessions, PDF text edits, exports...) is
 * ported into a module here and mounted under /api/apps/<id>.
 */

import { Hono } from 'hono'
import type { AppEnv } from '../auth'

export interface AppModule {
  id: 'docs' | 'sheets' | 'slides' | 'pdf' | 'markdown' | 'html'
  routes: Hono<AppEnv>
  /**
   * optional routes served WITHOUT a session under /pub/<id>/* — only for
   * capability URLs (unguessable tokens), e.g. sandboxed HTML previews whose
   * subresource requests carry no cookies
   */
  publicRoutes?: Hono
  /** optional background work started with the server (e.g. a sidecar process) */
  start?(): Promise<void> | void
  stop?(): Promise<void> | void
}

const modules: AppModule[] = []

export function registerAppModule(mod: AppModule): void {
  modules.push(mod)
}

export function appModules(): readonly AppModule[] {
  return modules
}
