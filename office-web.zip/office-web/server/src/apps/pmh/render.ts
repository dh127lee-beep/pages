/**
 * Headless Chrome for the exports the desktop app renders in hidden Electron
 * windows (Markdown/HTML → PDF, HTML → Word).
 *
 * The document is user content, so the page gets no network: it is served at
 * a fake origin (http://doc.invalid/) whose only answers come from `assets`
 * (files of the document's own folder); every other request — other hosts,
 * file://, the server's own network — is aborted. data:/blob: URLs still work.
 */

import { existsSync } from 'node:fs'
import { createRequire } from 'node:module'
import { join } from 'node:path'
import { config } from '../../config'
import type { BrowserDriver, ScreenshotOptions, Viewport } from '../../../../upstream/soffice/packages/html2docx/src/driver'

type PW = typeof import('playwright-core')
type Browser = import('playwright-core').Browser
type BrowserContext = import('playwright-core').BrowserContext
type Page = import('playwright-core').Page

export const DOC_ORIGIN = 'http://doc.invalid'

/** playwright-core is loaded from the vendored tree at runtime (it does not survive bundling) */
function loadPlaywright(): PW {
  const req = createRequire(join(config.root, 'upstream', 'soffice', 'node_modules', 'noop.js'))
  return req('playwright-core') as PW
}

function chromeCandidates(): string[] {
  const list = [
    process.env.CHROME_PATH,
    '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
    '/Applications/Chromium.app/Contents/MacOS/Chromium',
    '/usr/bin/google-chrome',
    '/usr/bin/google-chrome-stable',
    '/usr/bin/chromium',
    '/usr/bin/chromium-browser',
  ]
  return list.filter((p): p is string => Boolean(p))
}

export function findChrome(): string | null {
  return chromeCandidates().find((p) => existsSync(p)) ?? null
}

let browserPromise: Promise<Browser> | null = null
let idleTimer: NodeJS.Timeout | null = null
let active = 0

async function getBrowser(): Promise<Browser> {
  if (idleTimer) {
    clearTimeout(idleTimer)
    idleTimer = null
  }
  if (!browserPromise) {
    const executablePath = findChrome()
    if (!executablePath) {
      throw new Error('No Chrome/Chromium found on the server (set CHROME_PATH) — export unavailable')
    }
    browserPromise = loadPlaywright()
      .chromium.launch({
        executablePath,
        headless: true,
        args: ['--no-sandbox', '--disable-dev-shm-usage', '--force-device-scale-factor=2'],
      })
      .catch((err) => {
        browserPromise = null
        throw err
      })
  }
  return browserPromise
}

function release(): void {
  active--
  if (active > 0) return
  idleTimer = setTimeout(() => {
    const p = browserPromise
    browserPromise = null
    void p?.then((b) => b.close()).catch(() => undefined)
  }, 60_000)
  idleTimer.unref()
}

export type AssetResolver = (relPath: string) => Promise<{ body: Buffer; contentType: string } | null>

/** an isolated context whose only reachable origin is DOC_ORIGIN */
export async function withSandboxedPage<T>(
  opts: { html: string; assets?: AssetResolver; viewport?: Viewport; javaScript?: boolean },
  run: (page: Page, context: BrowserContext) => Promise<T>,
): Promise<T> {
  active++
  try {
    const browser = await getBrowser()
    const context = await browser.newContext({
      viewport: opts.viewport
        ? { width: opts.viewport.width, height: opts.viewport.height }
        : { width: 1024, height: 1400 },
      deviceScaleFactor: opts.viewport?.deviceScaleFactor ?? 1,
      javaScriptEnabled: opts.javaScript !== false,
      serviceWorkers: 'block',
      acceptDownloads: false,
    })
    try {
      await context.route('**/*', async (route) => {
        const url = route.request().url()
        if (url === `${DOC_ORIGIN}/__document.html`) {
          return route.fulfill({ status: 200, contentType: 'text/html; charset=utf-8', body: opts.html })
        }
        if (url.startsWith(`${DOC_ORIGIN}/`) && opts.assets) {
          const rel = decodeURIComponent(new URL(url).pathname.slice(1))
          const hit = await opts.assets(rel).catch(() => null)
          if (hit) return route.fulfill({ status: 200, contentType: hit.contentType, body: hit.body })
          return route.fulfill({ status: 404, body: '' })
        }
        return route.abort('blockedbyclient')
      })
      const page = await context.newPage()
      return await run(page, context)
    } finally {
      await context.close().catch(() => undefined)
    }
  } finally {
    release()
  }
}

export const DOCUMENT_URL = `${DOC_ORIGIN}/__document.html`

/** print HTML → PDF bytes (A4 unless the document's @page says otherwise) */
export async function htmlToPdf(
  html: string,
  opts: { assets?: AssetResolver; javaScript?: boolean; marginIn?: number } = {},
): Promise<Buffer> {
  return withSandboxedPage({ html, assets: opts.assets, javaScript: opts.javaScript }, async (page) => {
    await page.goto(DOCUMENT_URL, { waitUntil: 'networkidle', timeout: 60_000 }).catch(() => undefined)
    if (opts.javaScript !== false) {
      await page.evaluate(() => document.fonts.ready.then(() => undefined)).catch(() => undefined)
    }
    const m = opts.marginIn !== undefined ? `${opts.marginIn}in` : undefined
    return page.pdf({
      printBackground: true,
      preferCSSPageSize: true,
      format: 'A4',
      ...(m ? { margin: { top: m, bottom: m, left: m, right: m } } : {}),
    })
  })
}

/** html2docx's driver contract over a sandboxed page */
export class SandboxedDriver implements BrowserDriver {
  constructor(private readonly page: Page) {}

  async setViewport(viewport: Viewport): Promise<void> {
    await this.page.setViewportSize({ width: viewport.width, height: viewport.height })
  }

  async goto(url: string, { timeoutMs }: { timeoutMs: number }): Promise<void> {
    try {
      await this.page.goto(url, { waitUntil: 'networkidle', timeout: timeoutMs })
    } catch {
      // render whatever loaded
    }
  }

  evaluate<T>(fn: string | ((arg?: any) => T | Promise<T>), arg?: unknown): Promise<T> {
    if (typeof fn === 'string') return this.page.evaluate(fn) as Promise<T>
    return this.page.evaluate(fn as (a: unknown) => T, arg)
  }

  async addScript(source: string): Promise<void> {
    await this.page.addScriptTag({ content: source })
  }

  async addInitScript(source: string): Promise<void> {
    await this.page.addInitScript(source)
  }

  async screenshot(options: ScreenshotOptions): Promise<Uint8Array> {
    return this.page.screenshot({
      type: 'png',
      fullPage: Boolean(options.clip),
      clip: options.clip,
      omitBackground: options.omitBackground,
    })
  }

  async screenshotElement(
    selector: string,
    options: Pick<ScreenshotOptions, 'omitBackground'>,
  ): Promise<Uint8Array | null> {
    const el = await this.page.$(selector)
    if (!el) return null
    const box = await el.evaluate((node) => {
      const r = node.getBoundingClientRect()
      return {
        x: Math.max(0, Math.round(r.left + window.scrollX)),
        y: Math.max(0, Math.round(r.top + window.scrollY)),
        width: Math.round(r.width),
        height: Math.round(r.height),
      }
    })
    if (box.width <= 0 || box.height <= 0) return null
    return this.screenshot({ clip: box, omitBackground: options.omitBackground })
  }

  async elementExists(selector: string): Promise<boolean> {
    return (await this.page.$(selector)) !== null
  }

  async close(): Promise<void> {
    // the context is owned by withSandboxedPage
  }
}
