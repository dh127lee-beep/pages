import { readFile } from 'node:fs/promises'
import { extname, relative, sep } from 'node:path'
import { mimeFor, normalizeVirtualPath, storageFor, StorageError, type UserStorage } from '../../storage'
import type { AssetResolver } from './render'

export interface DocCtx {
  s: UserStorage
  /** virtual → disk */
  disk(path: string): string
  /** disk → virtual (refuses anything outside the user's tree) */
  virtual(abs: string): string
}

export function docCtx(userId: string): DocCtx {
  const s = storageFor(userId)
  return {
    s,
    disk: (p) => s.resolve(normalizeVirtualPath(p)),
    virtual: (abs) => {
      const rel = relative(s.root, abs)
      if (rel.startsWith('..') || rel.startsWith(sep)) throw new StorageError(403, 'Outside the file tree')
      return s.toVirtual(abs)
    },
  }
}

/** files of one folder in the user's tree, for a sandboxed render */
export function folderAssets(ctx: DocCtx, dirVirtual: string | null): AssetResolver | undefined {
  if (!dirVirtual) return undefined
  return async (rel) => {
    if (!rel || rel.split('/').some((seg) => seg === '..' || seg === '')) return null
    const v = normalizeVirtualPath(`${dirVirtual}/${rel}`)
    const st = await ctx.s.stat(v).catch(() => null)
    if (!st || st.isDir || st.size > 50 * 1024 * 1024) return null
    const ext = extname(v).toLowerCase()
    const contentType =
      ext === '.css' ? 'text/css' : ext === '.js' || ext === '.mjs' ? 'text/javascript' : mimeFor(v)
    return { body: await readFile(ctx.s.resolve(v)), contentType }
  }
}

export function safeBaseName(name: unknown, fallback: string): string {
  const base = String(name ?? '')
    .replace(/[/\\:*?"<>|\u0000-\u001f]/g, '_')
    .trim()
    .slice(0, 120)
  return base || fallback
}
