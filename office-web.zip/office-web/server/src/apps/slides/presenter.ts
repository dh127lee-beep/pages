/**
 * Presenter view with an audience window, ported from
 * apps/slides/src/main/presenter-show.ts for the browser.
 *
 * The desktop opens a full-screen audience BrowserWindow on a second display
 * that shares the presenter's Session (so it renders the in-memory deck,
 * unsaved edits included) and forwards show state presenter → audience and
 * navigation audience → presenter. Here the audience is a browser popup the
 * presenter tab opens; on the server it is one more editor channel whose
 * webContents id is mapped onto the presenter's Session. Without a popup
 * (blocked, or a single screen) the presenter view runs alone, as it does on
 * a one-display desktop.
 */

import { sessions, viewerWcIds } from '../../../../upstream/soffice/apps/slides/src/main/session-state'
import { createWebContents, ipcMain, type FakeWebContents } from './electron-shim'

interface Show {
  presenter: FakeWebContents
  audience: FakeWebContents | null
  /** last state broadcast, replayed to an audience that mounts afterwards */
  lastSync: unknown
}

const shows = new Map<number, Show>()
/** audience wc id → presenter wc id */
const audienceOf = new Map<number, number>()

interface IpcEventLike {
  sender: FakeWebContents
}

/** the audience page closes itself when told; the server channel is dropped shortly after */
export const CLOSE_WINDOW_CHANNEL = 'office-web:close-window'
const CLOSE_GRACE_MS = 5_000

export function registerWebPresenter(hooks: {
  /** make a server-created webContents reachable as an editor channel (/events?wc=, /ipc) */
  adopt(wc: FakeWebContents): void
  /** drop an editor channel */
  destroy(wcId: number): void
}): void {
  const close = (presenterId: number) => {
    const show = shows.get(presenterId)
    if (!show) return
    shows.delete(presenterId)
    const audience = show.audience
    show.audience = null
    if (audience && !audience.isDestroyed()) {
      audience.send(CLOSE_WINDOW_CHANNEL)
      setTimeout(() => hooks.destroy(audience.id), CLOSE_GRACE_MS).unref()
    }
  }

  // registered after upstream's registerSlidesIpc: these replace its window-based handlers
  ipcMain.handle('slides:presenter-start', (e: unknown, raw?: unknown) => {
    const opts = raw as { popup?: boolean } | undefined
    const presenter = (e as IpcEventLike).sender
    const existing = shows.get(presenter.id)
    if (existing) return { audience: existing.audience !== null, audienceWc: existing.audience?.id }
    const show: Show = { presenter, audience: null, lastSync: null }
    shows.set(presenter.id, show)
    presenter.once('destroyed', () => close(presenter.id))

    const session = sessions.get(presenter.id)
    if (!opts?.popup || !session) return { audience: false }
    const audience = createWebContents(presenter.userId)
    hooks.adopt(audience)
    sessions.set(audience.id, session)
    viewerWcIds.add(audience.id)
    audienceOf.set(audience.id, presenter.id)
    show.audience = audience
    audience.once('destroyed', () => {
      viewerWcIds.delete(audience.id)
      audienceOf.delete(audience.id)
      if (show.audience === audience) show.audience = null
    })
    return { audience: true, audienceWc: audience.id }
  })

  // a browser cannot move windows between screens; the user drags the popup
  ipcMain.handle('slides:presenter-swap', () => false)

  ipcMain.handle('slides:presenter-end', (e: unknown) => {
    close((e as IpcEventLike).sender.id)
  })

  ipcMain.on('slides:presenter-sync', (e: unknown, state: unknown) => {
    const show = shows.get((e as IpcEventLike).sender.id)
    if (!show) return
    show.lastSync = state
    if (show.audience && !show.audience.isDestroyed()) show.audience.send('slides:show-sync', state)
  })

  ipcMain.on('slides:presenter-ink', (e: unknown, ev: unknown) => {
    const audience = shows.get((e as IpcEventLike).sender.id)?.audience
    if (audience && !audience.isDestroyed()) audience.send('slides:show-ink', ev)
  })

  ipcMain.handle('slides:audience-ready', (e: unknown) => {
    const pid = audienceOf.get((e as IpcEventLike).sender.id)
    return (pid !== undefined ? shows.get(pid)?.lastSync : null) ?? null
  })

  ipcMain.on('slides:audience-nav', (e: unknown, action: unknown) => {
    const pid = audienceOf.get((e as IpcEventLike).sender.id)
    const presenter = pid !== undefined ? shows.get(pid)?.presenter : undefined
    if (presenter && !presenter.isDestroyed()) presenter.send('slides:audience-nav', action)
  })
}
