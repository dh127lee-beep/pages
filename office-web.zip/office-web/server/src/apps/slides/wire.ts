/**
 * JSON wire format for IPC over HTTP. Electron's structured clone carries
 * binary data; JSON does not, so byte arrays travel as {__ow_bin, t}:
 * t='ab' → ArrayBuffer, otherwise Uint8Array (what a Node Buffer becomes in
 * the renderer). Mirrored in bridge/apps/slides.ts.
 */

export function encodeWire(value: unknown, mapString?: (s: string) => string): unknown {
  if (typeof value === 'string') return mapString ? mapString(value) : value
  if (value === null || typeof value !== 'object') return value
  if (value instanceof ArrayBuffer) {
    return { __ow_bin: Buffer.from(value).toString('base64'), t: 'ab' }
  }
  if (ArrayBuffer.isView(value)) {
    return {
      __ow_bin: Buffer.from(value.buffer, value.byteOffset, value.byteLength).toString('base64'),
      t: 'u8',
    }
  }
  if (Array.isArray(value)) return value.map((v) => encodeWire(v, mapString))
  if (value instanceof Map) return encodeWire(Object.fromEntries(value), mapString)
  if (value instanceof Set) return encodeWire([...value], mapString)
  if (value instanceof Date) return value.toISOString()
  const out: Record<string, unknown> = {}
  for (const [k, v] of Object.entries(value)) {
    if (typeof v === 'function' || v === undefined) continue
    out[k] = encodeWire(v, mapString)
  }
  return out
}

/**
 * Inverse of encodeWire. `mapPath(key, s)` may rewrite path-like strings on
 * the way in (virtual paths → disk paths).
 */
export function decodeWire(value: unknown, mapPath?: (key: string, s: string) => string, key = ''): unknown {
  if (typeof value === 'string') return mapPath ? mapPath(key, value) : value
  if (value === null || typeof value !== 'object') return value
  if (Array.isArray(value)) return value.map((v) => decodeWire(v, mapPath, key))
  const rec = value as Record<string, unknown>
  if (typeof rec.__ow_bin === 'string') {
    const buf = Buffer.from(rec.__ow_bin, 'base64')
    if (rec.t === 'ab') return buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength)
    return new Uint8Array(buf.buffer, buf.byteOffset, buf.byteLength)
  }
  const out: Record<string, unknown> = {}
  for (const [k, v] of Object.entries(rec)) out[k] = decodeWire(v, mapPath, k)
  return out
}
