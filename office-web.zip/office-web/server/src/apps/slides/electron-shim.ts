/**
 * A stand-in for the `electron` module, so upstream's Slides main process
 * (apps/slides/src/main) runs unmodified inside the web server.
 *
 * - Each browser tab is a FakeWebContents; `wc.send()` pushes to that tab's
 *   event stream and `ipcMain.handle()` handlers are invoked over HTTP.
 * - Per-user state (userData, the clipboard) follows the request through an
 *   AsyncLocalStorage context, so the shared main-process singletons never
 *   mix two users' files.
 * - Native dialogs are forwarded to the tab as in-page dialogs.
 * - Everything desktop-only (menus, screens, GPU, capture) is an inert stub.
 */

import { AsyncLocalStorage } from 'node:async_hooks'
import { EventEmitter } from 'node:events'
import { mkdirSync, readFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { imageSize } from 'image-size'

// ---- request context ---------------------------------------------------------

export interface ShimContext {
  userId: string
  /** private per-user state (doubles as Electron's userData) */
  appData: string
  /** the user's visible file tree */
  filesRoot: string
  /** tab the current request came from */
  wcId?: number
}

export const shimContext = new AsyncLocalStorage<ShimContext>()

let globalDataDir = join(tmpdir(), 'office-web-slides')
export function setGlobalDataDir(dir: string): void {
  globalDataDir = dir
}

/** inert callable for anything we do not emulate: every member is another inert callable */
function inert(name: string): any {
  const fn = function () {
    return undefined
  }
  return new Proxy(fn, {
    get(_t, prop) {
      if (prop === 'then') return undefined
      if (prop === Symbol.toPrimitive) return () => name
      if (prop === 'toString') return () => name
      return inert(`${name}.${String(prop)}`)
    },
    apply() {
      return undefined
    },
    construct() {
      return inert(`new ${name}`)
    },
  })
}

function withFallback<T extends object>(name: string, target: T): T {
  return new Proxy(target, {
    get(t, prop, recv) {
      if (prop in t) return Reflect.get(t, prop, recv)
      if (typeof prop === 'symbol' || prop === 'then') return undefined
      return inert(`${name}.${prop}`)
    },
  })
}

// ---- webContents --------------------------------------------------------------

export type PushMessage =
  | { type: 'ipc'; channel: string; args: unknown[] }
  | { type: 'dialog'; id: number; kind: 'open' | 'save' | 'message' | 'error'; options: unknown }

export class FakeWebContents extends EventEmitter {
  destroyed = false
  private sinks = new Set<(msg: PushMessage) => void>()
  private backlog: PushMessage[] = []
  private dialogSeq = 0
  private pendingDialogs = new Map<number, (result: unknown) => void>()
  readonly session = inert('session')
  readonly hostWebContents = undefined
  readonly mainFrame = inert('mainFrame')

  constructor(
    readonly id: number,
    readonly userId: string,
  ) {
    super()
  }

  attach(sink: (msg: PushMessage) => void): () => void {
    this.sinks.add(sink)
    for (const msg of this.backlog.splice(0)) sink(msg)
    return () => this.sinks.delete(sink)
  }

  get connected(): boolean {
    return this.sinks.size > 0
  }

  push(msg: PushMessage): void {
    if (this.destroyed) return
    if (this.sinks.size === 0) {
      // keep a little while the tab reconnects
      if (this.backlog.length < 500) this.backlog.push(msg)
      return
    }
    for (const s of this.sinks) s(msg)
  }

  send(channel: string, ...args: unknown[]): void {
    this.push({ type: 'ipc', channel, args })
  }

  /** forward a native dialog to the tab; resolves with the tab's answer */
  requestDialog(kind: 'open' | 'save' | 'message' | 'error', options: unknown): Promise<unknown> {
    const id = ++this.dialogSeq
    return new Promise((resolve) => {
      this.pendingDialogs.set(id, resolve)
      this.push({ type: 'dialog', id, kind, options })
    })
  }

  answerDialog(id: number, result: unknown): void {
    const resolve = this.pendingDialogs.get(id)
    this.pendingDialogs.delete(id)
    resolve?.(result)
  }

  isDestroyed(): boolean {
    return this.destroyed
  }
  destroy(): void {
    if (this.destroyed) return
    for (const resolve of this.pendingDialogs.values()) resolve(null)
    this.pendingDialogs.clear()
    this.emit('destroyed')
    this.destroyed = true
    registry.delete(this.id)
    this.removeAllListeners()
  }
  getURL(): string {
    return 'https://office-web.local/app/slides/'
  }
  getTitle(): string {
    return 'Slides'
  }
  isLoading(): boolean {
    return false
  }
  isFocused(): boolean {
    return true
  }
  isCrashed(): boolean {
    return false
  }
  getOSProcessId(): number {
    return 0
  }
  getProcessId(): number {
    return 0
  }
  getZoomFactor(): number {
    return 1
  }
  setWindowOpenHandler(): void {}
  setZoomFactor(): void {}
  setBackgroundThrottling(): void {}
  focus(): void {}
  reload(): void {}
  forcefullyCrashRenderer(): void {}
  invalidate(): void {}
  openDevTools(): void {}
  async executeJavaScript(): Promise<never> {
    throw new Error('executeJavaScript is not available on the server')
  }
  async capturePage(): Promise<never> {
    throw new Error('capturePage is not available on the server')
  }
  async printToPDF(): Promise<never> {
    throw new Error('printToPDF is not available on the server')
  }
}

const registry = new Map<number, FakeWebContents>()
let nextWcId = 1000

export function createWebContents(userId: string): FakeWebContents {
  const wc = withFallback('webContents', new FakeWebContents(nextWcId++, userId))
  registry.set(wc.id, wc)
  return wc
}

export function getWebContents(id: number): FakeWebContents | undefined {
  return registry.get(id)
}

export const webContents = withFallback('webContents', {
  fromId: (id: number) => registry.get(id),
  getAllWebContents: () => [...registry.values()],
  getFocusedWebContents: () => {
    const id = shimContext.getStore()?.wcId
    return id !== undefined ? registry.get(id) : undefined
  },
})

function currentWc(): FakeWebContents | undefined {
  const id = shimContext.getStore()?.wcId
  return id !== undefined ? registry.get(id) : undefined
}

// ---- ipcMain --------------------------------------------------------------------

type Handler = (event: unknown, ...args: unknown[]) => unknown

class IpcMain extends EventEmitter {
  readonly handlers = new Map<string, Handler>()
  handle(channel: string, fn: Handler): void {
    this.handlers.set(channel, fn)
  }
  handleOnce(channel: string, fn: Handler): void {
    this.handlers.set(channel, (e, ...a) => {
      this.handlers.delete(channel)
      return fn(e, ...a)
    })
  }
  removeHandler(channel: string): void {
    this.handlers.delete(channel)
  }
}

export const ipcMain = new IpcMain()

function ipcEvent(wc: FakeWebContents) {
  return {
    sender: wc,
    senderFrame: { url: wc.getURL(), processId: 0, routingId: 0 },
    frameId: 0,
    processId: 0,
    returnValue: undefined as unknown,
    reply: (channel: string, ...args: unknown[]) => wc.send(channel, ...args),
    preventDefault() {},
  }
}

export async function invokeHandler(wc: FakeWebContents, channel: string, args: unknown[]): Promise<unknown> {
  const fn = ipcMain.handlers.get(channel)
  if (!fn) throw new Error(`No handler registered for '${channel}'`)
  return fn(ipcEvent(wc), ...args)
}

export function emitSend(wc: FakeWebContents, channel: string, args: unknown[]): void {
  ipcMain.emit(channel, ipcEvent(wc), ...args)
}

// ---- app -----------------------------------------------------------------------

function ensureDir(dir: string): string {
  mkdirSync(dir, { recursive: true })
  return dir
}

class App extends EventEmitter {
  readonly isPackaged = true
  readonly commandLine = inert('app.commandLine')
  readonly dock = inert('app.dock')
  private overrides = new Map<string, string>()

  getPath(name: string): string {
    const override = this.overrides.get(name)
    if (override) return override
    const store = shimContext.getStore()
    switch (name) {
      case 'userData':
      case 'appData':
      case 'sessionData':
      case 'logs':
      case 'crashDumps':
        return ensureDir(store ? store.appData : join(globalDataDir, 'userData'))
      case 'temp':
        return ensureDir(join(tmpdir(), 'office-web'))
      case 'documents':
      case 'home':
      case 'desktop':
      case 'downloads':
        return ensureDir(store ? store.filesRoot : join(globalDataDir, 'documents'))
      default:
        return ensureDir(join(store ? store.appData : globalDataDir, name))
    }
  }
  setPath(name: string, value: string): void {
    this.overrides.set(name, value)
  }
  getVersion(): string {
    try {
      return JSON.parse(readFileSync(join(process.cwd(), 'package.json'), 'utf8')).version ?? '0.1.0'
    } catch {
      return '0.1.0'
    }
  }
  getName(): string {
    return 'S-Office Web'
  }
  getLocale(): string {
    return 'en-US'
  }
  getSystemLocale(): string {
    return 'en-US'
  }
  getPreferredSystemLanguages(): string[] {
    return ['en-US']
  }
  getAppPath(): string {
    return process.cwd()
  }
  isReady(): boolean {
    return true
  }
  whenReady(): Promise<void> {
    return Promise.resolve()
  }
  requestSingleInstanceLock(): boolean {
    return true
  }
  getAppMetrics(): unknown[] {
    return []
  }
  getGPUFeatureStatus(): Record<string, string> {
    return {}
  }
  quit(): void {}
  exit(): void {}
  focus(): void {}
  addRecentDocument(): void {}
  setAboutPanelOptions(): void {}
}

export const app = withFallback('app', new App())

// ---- dialogs (answered by the tab) --------------------------------------------------

/** a tab's answer to an open/save dialog names files in its own tree; the host maps them to disk */
let resolveDialogPath: (ctx: ShimContext, answer: unknown) => string | null = () => null
export function setDialogPathResolver(fn: (ctx: ShimContext, answer: unknown) => string | null): void {
  resolveDialogPath = fn
}

function splitArgs<T>(a: unknown, b: unknown): T {
  return (b ?? a ?? {}) as T
}

export const dialog = withFallback('dialog', {
  async showOpenDialog(a: unknown, b?: unknown) {
    const options = splitArgs<Record<string, unknown>>(a, b)
    const wc = currentWc()
    const ctx = shimContext.getStore()
    if (!wc || !ctx) return { canceled: true, filePaths: [] }
    const answer = (await wc.requestDialog('open', options)) as unknown[] | null
    const filePaths = (Array.isArray(answer) ? answer : [])
      .map((x) => resolveDialogPath(ctx, x))
      .filter((p): p is string => !!p)
    return { canceled: filePaths.length === 0, filePaths }
  },
  async showSaveDialog(a: unknown, b?: unknown) {
    const options = splitArgs<Record<string, unknown>>(a, b)
    const wc = currentWc()
    const ctx = shimContext.getStore()
    if (!wc || !ctx) return { canceled: true, filePath: undefined }
    const answer = await wc.requestDialog('save', options)
    const filePath = answer ? resolveDialogPath(ctx, answer) : null
    return filePath ? { canceled: false, filePath } : { canceled: true, filePath: undefined }
  },
  async showMessageBox(a: unknown, b?: unknown) {
    const options = splitArgs<{ cancelId?: number; defaultId?: number; buttons?: string[] }>(a, b)
    const wc = currentWc()
    const fallback = options.cancelId ?? (options.buttons?.length ? options.buttons.length - 1 : 0)
    if (!wc) return { response: fallback, checkboxChecked: false }
    const answer = (await wc.requestDialog('message', options)) as
      | { response: number; checkboxChecked?: boolean }
      | null
    return answer && typeof answer.response === 'number'
      ? { response: answer.response, checkboxChecked: !!answer.checkboxChecked }
      : { response: fallback, checkboxChecked: false }
  },
  showMessageBoxSync(a: unknown, b?: unknown) {
    const options = splitArgs<{ cancelId?: number; defaultId?: number }>(a, b)
    return options.cancelId ?? options.defaultId ?? 0
  },
  showErrorBox(title: string, content: string) {
    currentWc()?.requestDialog('error', { title, content })
  },
  showOpenDialogSync() {
    return undefined
  },
  showSaveDialogSync() {
    return undefined
  },
})

// ---- clipboard (per user, in memory) ------------------------------------------------

interface Clip {
  text: string
  html: string
  image: NativeImageLike | null
  buffers: Map<string, Buffer>
}
const clips = new Map<string, Clip>()
function clip(): Clip {
  const key = shimContext.getStore()?.userId ?? ''
  let c = clips.get(key)
  if (!c) {
    c = { text: '', html: '', image: null, buffers: new Map() }
    clips.set(key, c)
  }
  return c
}

export const clipboard = withFallback('clipboard', {
  readText: () => clip().text,
  writeText: (t: string) => {
    const c = clip()
    c.text = String(t ?? '')
  },
  readHTML: () => clip().html,
  writeHTML: (h: string) => {
    clip().html = String(h ?? '')
  },
  readImage: () => clip().image ?? createImage(Buffer.alloc(0)),
  writeImage: (img: NativeImageLike) => {
    clip().image = img
  },
  readBuffer: (format: string) => clip().buffers.get(format) ?? Buffer.alloc(0),
  writeBuffer: (format: string, buf: Buffer) => {
    clip().buffers.set(format, Buffer.from(buf))
  },
  write: (data: { text?: string; html?: string; image?: NativeImageLike }) => {
    const c = clip()
    c.text = data.text ?? ''
    c.html = data.html ?? ''
    c.image = data.image ?? null
    c.buffers.clear()
  },
  clear: () => {
    clips.delete(shimContext.getStore()?.userId ?? '')
  },
  has: (format: string) => clip().buffers.has(format),
  availableFormats: () => {
    const c = clip()
    const out: string[] = [...c.buffers.keys()]
    if (c.text) out.push('text/plain')
    if (c.html) out.push('text/html')
    if (c.image && !c.image.isEmpty()) out.push('image/png')
    return out
  },
})

// ---- nativeImage (size probing only; no pixel work on the server) ------------------

export interface NativeImageLike {
  isEmpty(): boolean
  getSize(): { width: number; height: number }
  toPNG(): Buffer
  toJPEG(): Buffer
  toDataURL(): string
  toBitmap(): Buffer
  getAspectRatio(): number
  resize(): NativeImageLike
  crop(): NativeImageLike
}

function createImage(buf: Buffer): NativeImageLike {
  let size = { width: 0, height: 0 }
  let type = ''
  try {
    if (buf.length) {
      const s = imageSize(new Uint8Array(buf))
      size = { width: s.width ?? 0, height: s.height ?? 0 }
      type = s.type ?? ''
    }
  } catch {
    size = { width: 0, height: 0 }
  }
  const empty = size.width === 0 || size.height === 0
  const img: NativeImageLike = {
    isEmpty: () => empty,
    getSize: () => ({ ...size }),
    // only PNG can be handed through as PNG without a decoder
    toPNG: () => (type === 'png' ? buf : Buffer.alloc(0)),
    toJPEG: () => (type === 'jpg' ? buf : Buffer.alloc(0)),
    toBitmap: () => Buffer.alloc(0),
    toDataURL: () => (empty ? 'data:image/png;base64,' : `data:image/${type || 'png'};base64,${buf.toString('base64')}`),
    getAspectRatio: () => (size.height ? size.width / size.height : 1),
    resize: () => img,
    crop: () => img,
  }
  return img
}

export const nativeImage = withFallback('nativeImage', {
  createFromBuffer: (buf: Buffer | Uint8Array) => createImage(Buffer.from(buf ?? [])),
  createFromPath: (p: string) => {
    try {
      return createImage(readFileSync(p))
    } catch {
      return createImage(Buffer.alloc(0))
    }
  },
  createFromDataURL: (url: string) => {
    const comma = String(url).indexOf(',')
    return createImage(comma >= 0 ? Buffer.from(String(url).slice(comma + 1), 'base64') : Buffer.alloc(0))
  },
  createEmpty: () => createImage(Buffer.alloc(0)),
  createThumbnailFromPath: async () => {
    throw new Error('thumbnails are not available on the server')
  },
})

// ---- the rest: windows, menus, screens… ----------------------------------------------

const DISPLAY = {
  id: 1,
  bounds: { x: 0, y: 0, width: 1920, height: 1080 },
  workArea: { x: 0, y: 0, width: 1920, height: 1080 },
  size: { width: 1920, height: 1080 },
  workAreaSize: { width: 1920, height: 1080 },
  scaleFactor: 1,
  rotation: 0,
  internal: true,
}

export const screen = withFallback('screen', {
  getPrimaryDisplay: () => DISPLAY,
  getAllDisplays: () => [DISPLAY],
  getDisplayMatching: () => DISPLAY,
  getDisplayNearestPoint: () => DISPLAY,
  getCursorScreenPoint: () => ({ x: 0, y: 0 }),
})

export const shell = withFallback('shell', {
  openExternal: async () => undefined,
  openPath: async () => '',
  showItemInFolder: () => undefined,
  beep: () => undefined,
})

export const systemPreferences = withFallback('systemPreferences', {
  getMediaAccessStatus: () => 'granted',
  askForMediaAccess: async () => true,
  getUserDefault: () => undefined,
})

export const desktopCapturer = { getSources: async () => [] }

export const net = withFallback('net', {
  fetch: (input: RequestInfo | URL, init?: RequestInit) => fetch(input, init),
  isOnline: () => true,
})

const fakeSession = withFallback('session', {
  resolveProxy: async () => 'DIRECT',
  setDisplayMediaRequestHandler: () => undefined,
  setPermissionRequestHandler: () => undefined,
  setPermissionCheckHandler: () => undefined,
  setSpellCheckerLanguages: () => undefined,
  protocol: inert('session.protocol'),
  webRequest: inert('session.webRequest'),
})
export const session = withFallback('session', { defaultSession: fakeSession, fromPartition: () => fakeSession })

export const Menu = withFallback('Menu', {
  buildFromTemplate: (items: unknown[]) => ({ items, popup() {}, closePopup() {}, append() {}, insert() {} }),
  setApplicationMenu: () => undefined,
  getApplicationMenu: () => null,
})
export const MenuItem = class {
  constructor(readonly options: unknown) {}
}

/** windows never exist on the server: lookups come back empty */
export const BrowserWindow = Object.assign(
  function BrowserWindow() {
    throw new Error('BrowserWindow is not available on the server')
  },
  {
    fromWebContents: () => null,
    fromId: () => null,
    getAllWindows: () => [],
    getFocusedWindow: () => null,
  },
)
export const WebContentsView = function WebContentsView() {
  throw new Error('WebContentsView is not available on the server')
}
export const BaseWindow = BrowserWindow
export const protocol = inert('protocol')
export const nativeTheme = withFallback('nativeTheme', { shouldUseDarkColors: false, themeSource: 'system' })
export const powerSaveBlocker = inert('powerSaveBlocker')
export const globalShortcut = inert('globalShortcut')
export const contentTracing = inert('contentTracing')
export const crashReporter = inert('crashReporter')
export const autoUpdater = inert('autoUpdater')
export const Notification = inert('Notification')
export const Tray = inert('Tray')
export const TouchBar = inert('TouchBar')
export const utilityProcess = inert('utilityProcess')
export const contextBridge = inert('contextBridge')
export const ipcRenderer = inert('ipcRenderer')
export const webUtils = inert('webUtils')
export const webFrame = inert('webFrame')

export default {
  app,
  BrowserWindow,
  BaseWindow,
  WebContentsView,
  clipboard,
  contentTracing,
  desktopCapturer,
  dialog,
  ipcMain,
  Menu,
  MenuItem,
  nativeImage,
  nativeTheme,
  net,
  protocol,
  screen,
  session,
  shell,
  systemPreferences,
  webContents,
}
