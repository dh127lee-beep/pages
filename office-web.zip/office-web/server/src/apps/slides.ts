/**
 * Slides: upstream's main process (apps/slides/src/main) runs here unmodified.
 *
 * It keeps the deck model and applies every edit, exactly as in the desktop
 * app; the renderer's ipcRenderer.invoke/send become POST /ipc and the
 * main's webContents.send() pushes travel over a per-tab event stream
 * (GET /events). See ./slides/electron-shim.ts for the Electron stand-in.
 */

import { randomBytes } from 'node:crypto'
import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { Hono } from 'hono'
import { registerSlidesIpc, slidesFileRenamed } from '../../../upstream/soffice/apps/slides/src/main/slides-main'
import {
  buildPdfExportHtml,
  exportPageWidthIn,
  PDF_EXPORT_HEIGHT_IN,
} from '../../../upstream/soffice/apps/slides/src/main/pdf-export'
import type { ExportPdfOp } from '../../../upstream/soffice/apps/slides/src/shared/ipc'
import { printHtmlToPdf } from '../lib/chrome'
import { sessions } from '../../../upstream/soffice/apps/slides/src/main/session-state'
import type { AppEnv } from '../auth'
import { config } from '../config'
import { getUserSetting } from '../db'
import { normalizeLang, setUiLang } from '@soffice/i18n'
import { readBody } from '../lib/body'
import { ATTACHMENT_PREFIX, attachmentDiskPath } from '../routes/assist'
import { storageFor, validateName } from '../storage'
import { registerAppModule } from './index'
import {
  createWebContents,
  emitSend,
  ipcMain,
  getWebContents,
  invokeHandler,
  setDialogPathResolver,
  setGlobalDataDir,
  shimContext,
  type FakeWebContents,
  type PushMessage,
  type ShimContext,
} from './slides/electron-shim'
import { registerWebPresenter } from './slides/presenter'
import { decodeWire, encodeWire } from './slides/wire'

/** how long a tab's deck survives a dropped event stream (reloads get a new tab id) */
const DETACH_GRACE_MS = 120_000
/** a request whose predecessor never arrived stops blocking the queue after this */
const SEQ_GAP_MS = 10_000

/** channels the web edition serves elsewhere or must not expose */
const BLOCKED_CHANNELS = new Set([
  'slides:show-fullscreen',
  'slides:font-install-local', // installs fonts server-wide
])

function contextFor(userId: string): ShimContext {
  const s = storageFor(userId)
  // new untitled decks land in the user's own tree (the desktop "default save folder")
  const settingsPath = join(s.appData, 'app-settings.json')
  let settings: Record<string, unknown> = {}
  try {
    settings = JSON.parse(readFileSync(settingsPath, 'utf8')) as Record<string, unknown>
  } catch {
    settings = {}
  }
  if (settings.defaultSaveDir !== s.root) {
    settings.defaultSaveDir = s.root
    writeFileSync(settingsPath, JSON.stringify(settings, null, 2))
  }
  return { userId, appData: s.appData, filesRoot: s.root }
}

/** disk paths never reach the browser: the user's tree root becomes "/" */
function outMapper(ctx: ShimContext): (s: string) => string {
  const root = ctx.filesRoot
  return (s) => {
    if (!s.includes(root)) return s
    if (s === root) return '/'
    return s.split(`${root}/`).join('/').split(root).join('/')
  }
}

/** keys whose string values name files; partPath is an OPC part name, not a file */
const PATH_KEY = /(^|[a-z])(path|paths|dir|filepath|filepaths|outpath)$/i

function toDisk(ctx: ShimContext, virtualPath: string): string {
  const s = storageFor(ctx.userId)
  if (virtualPath.startsWith(ATTACHMENT_PREFIX)) return attachmentDiskPath(s, virtualPath)
  return s.resolve(virtualPath)
}

function inMapper(ctx: ShimContext): (key: string, s: string) => string {
  return (key, s) => {
    if (!s.startsWith('/') || key === 'partPath' || !PATH_KEY.test(key)) return s
    return toDisk(ctx, s)
  }
}

/** a dialog answer from the tab: {path} in the user's tree, or {upload} from the computer */
function dialogAnswerToDisk(ctx: ShimContext, answer: unknown): string | null {
  try {
    if (typeof answer === 'string') return toDisk(ctx, answer)
    const a = answer as { path?: string; upload?: string }
    if (a?.path) return toDisk(ctx, a.path)
    if (a?.upload) {
      const [id, name] = a.upload.split('/')
      if (!id || !/^[0-9a-f]{16}$/.test(id) || !name) return null
      const disk = join(storageFor(ctx.userId).appDataDir('slides-uploads'), id, validateName(name))
      return existsSync(disk) ? disk : null
    }
  } catch {
    // invalid path from the tab
  }
  return null
}

// ---- ordered dispatch: Electron starts IPC handlers in send order ------------------

interface TabState {
  wc: FakeWebContents
  nextSeq: number
  waiting: Map<number, () => void>
  gapTimer?: NodeJS.Timeout
  detachTimer?: NodeJS.Timeout
}

const tabs = new Map<number, TabState>()

function enqueue(tab: TabState, seq: number, start: () => void): void {
  if (!Number.isSafeInteger(seq) || seq < tab.nextSeq) {
    start()
    return
  }
  tab.waiting.set(seq, start)
  drain(tab)
}

function drain(tab: TabState): void {
  clearTimeout(tab.gapTimer)
  for (;;) {
    const next = tab.waiting.get(tab.nextSeq)
    if (!next) break
    tab.waiting.delete(tab.nextSeq)
    tab.nextSeq++
    next()
  }
  if (tab.waiting.size > 0) {
    tab.gapTimer = setTimeout(() => {
      // skip the missing request(s)
      tab.nextSeq = Math.min(...tab.waiting.keys())
      drain(tab)
    }, SEQ_GAP_MS)
  }
}

function destroyTab(tab: TabState): void {
  clearTimeout(tab.gapTimer)
  clearTimeout(tab.detachTimer)
  tabs.delete(tab.wc.id)
  sessions.delete(tab.wc.id)
  tab.wc.destroy()
}

function ownTab(userId: string, wcId: unknown): TabState | null {
  const tab = typeof wcId === 'number' ? tabs.get(wcId) : undefined
  return tab && tab.wc.userId === userId ? tab : null
}

// ---- routes ----------------------------------------------------------------------

const routes = new Hono<AppEnv>()

routes.get('/events', (c) => {
  const userId = c.get('user').id
  const ctx = contextFor(userId)
  let tab = ownTab(userId, Number(c.req.query('wc')))
  if (!tab) {
    const wc = createWebContents(userId)
    tab = { wc, nextSeq: 0, waiting: new Map() }
    tabs.set(wc.id, tab)
  }
  const current = tab
  clearTimeout(current.detachTimer)
  const encoder = new TextEncoder()
  const mapOut = outMapper(ctx)
  let detach: (() => void) | null = null
  let ping: NodeJS.Timeout | undefined
  const body = new ReadableStream<Uint8Array>({
    start(stream) {
      const write = (text: string) => {
        try {
          stream.enqueue(encoder.encode(text))
        } catch {
          // closed
        }
      }
      write(`event: hello\ndata: ${JSON.stringify({ wc: current.wc.id })}\n\n`)
      detach = current.wc.attach((msg: PushMessage) => {
        write(`data: ${JSON.stringify(encodeWire(msg, mapOut))}\n\n`)
      })
      ping = setInterval(() => write(': ping\n\n'), 20_000)
    },
    cancel() {
      clearInterval(ping)
      detach?.()
      if (!current.wc.connected) {
        current.detachTimer = setTimeout(() => {
          if (!current.wc.connected) destroyTab(current)
        }, DETACH_GRACE_MS)
      }
    },
  })
  c.req.raw.signal.addEventListener('abort', () => {
    clearInterval(ping)
    detach?.()
    detach = null
    if (!current.wc.connected) {
      clearTimeout(current.detachTimer)
      current.detachTimer = setTimeout(() => {
        if (!current.wc.connected) destroyTab(current)
      }, DETACH_GRACE_MS)
    }
  })
  return new Response(body, {
    headers: {
      'content-type': 'text/event-stream; charset=utf-8',
      'cache-control': 'no-cache, no-transform',
      'x-accel-buffering': 'no',
    },
  })
})

routes.post('/ipc', async (c) => {
  const userId = c.get('user').id
  const req = await c.req.json<{
    wc: number
    seq: number
    kind: 'invoke' | 'send'
    channel: string
    args: unknown[]
    lang?: string
  }>()
  const tab = ownTab(userId, req.wc)
  if (!tab) return c.json({ error: 'Unknown editor tab' }, 410)
  const channel = String(req.channel ?? '')
  if (BLOCKED_CHANNELS.has(channel)) {
    enqueue(tab, req.seq, () => undefined)
    return c.json({ result: null })
  }
  const ctx: ShimContext = { ...contextFor(userId), wcId: tab.wc.id }
  // main-process strings (draft names, dialogs) follow the user's language
  setUiLang(normalizeLang(getUserSetting<{ language?: string }>(userId, 'prefs', {}).language ?? req.lang ?? 'en'))
  const mapIn = inMapper(ctx)
  let args: unknown[]
  try {
    args = (Array.isArray(req.args) ? req.args : []).map((a, i) =>
      // slides:open-path takes the file as a bare first argument
      channel === 'slides:open-path' && i === 0 && typeof a === 'string'
        ? toDisk(ctx, a)
        : decodeWire(a, mapIn),
    )
  } catch (err) {
    enqueue(tab, req.seq, () => undefined)
    return c.json({ error: err instanceof Error ? err.message : String(err) }, 400)
  }
  const result = await new Promise<{ ok: true; value: unknown } | { ok: false; error: string }>((resolve) => {
    enqueue(tab, req.seq, () => {
      shimContext.run(ctx, () => {
        try {
          if (req.kind === 'send') {
            emitSend(tab.wc, channel, args)
            resolve({ ok: true, value: null })
            return
          }
          Promise.resolve(invokeHandler(tab.wc, channel, args)).then(
            (value) => resolve({ ok: true, value }),
            (err: unknown) => resolve({ ok: false, error: err instanceof Error ? err.message : String(err) }),
          )
        } catch (err) {
          resolve({ ok: false, error: err instanceof Error ? err.message : String(err) })
        }
      })
    })
  })
  if (!result.ok) {
    console.warn(`[slides] ${channel} failed: ${result.error}`)
    return c.json({ error: outMapper(ctx)(result.error) }, 500)
  }
  return c.json({ result: encodeWire(result.value, outMapper(ctx)) })
})

routes.post('/dialog-reply', async (c) => {
  const { wc, id, result } = await c.req.json<{ wc: number; id: number; result: unknown }>()
  const tab = ownTab(c.get('user').id, wc)
  if (!tab) return c.json({ error: 'Unknown editor tab' }, 410)
  tab.wc.answerDialog(Number(id), result)
  return c.json({ ok: true })
})

/** the file was renamed/moved from Home: later saves must go to the new path */
routes.post('/renamed', async (c) => {
  const userId = c.get('user').id
  const { wc, oldPath, newPath } = await c.req.json<{ wc: number; oldPath: string; newPath: string }>()
  const tab = ownTab(userId, wc)
  if (!tab) return c.json({ error: 'Unknown editor tab' }, 410)
  const ctx: ShimContext = { ...contextFor(userId), wcId: tab.wc.id }
  shimContext.run(ctx, () =>
    slidesFileRenamed(tab.wc as never, toDisk(ctx, String(oldPath)), toDisk(ctx, String(newPath))),
  )
  return c.json({ ok: true })
})

routes.post('/close', async (c) => {
  const { wc } = await c.req.json<{ wc: number }>()
  const tab = ownTab(c.get('user').id, wc)
  if (tab) destroyTab(tab)
  return c.json({ ok: true })
})

/** pictures/media/fonts picked from the computer for an open dialog */
routes.put('/upload', async (c) => {
  const s = storageFor(c.get('user').id)
  const name = validateName(c.req.query('name') ?? 'file')
  const id = randomBytes(8).toString('hex')
  const dir = join(s.appDataDir('slides-uploads'), id)
  mkdirSync(dir, { recursive: true })
  writeFileSync(join(dir, name), await readBody(c))
  return c.json({ upload: `${id}/${name}` })
})

registerAppModule({
  id: 'slides',
  routes,
  start() {
    setGlobalDataDir(join(config.dataDir, 'slides-global'))
    setDialogPathResolver(dialogAnswerToDisk)
    registerSlidesIpc()
    // audience window = a browser popup bound to the presenter's deck
    registerWebPresenter({
      adopt(wc) {
        const tab: TabState = { wc, nextSeq: 0, waiting: new Map() }
        tabs.set(wc.id, tab)
        // a popup that never connects does not keep the channel alive
        tab.detachTimer = setTimeout(() => {
          if (!wc.connected) destroyTab(tab)
        }, DETACH_GRACE_MS)
      },
      destroy(wcId) {
        const tab = tabs.get(wcId)
        if (tab) destroyTab(tab)
      },
    })
    // PDF export: the desktop prints a hidden window; here headless Chrome prints the same page
    ipcMain.handle('slides:export-pdf', async (_e, raw) => {
      const op = raw as ExportPdfOp
      const ctx = shimContext.getStore()
      if (!ctx) return { ok: false, error: 'no session' }
      try {
        const pdf = await renderSlidesPdf(ctx.userId, op)
        writeFileSync(op.filePath, pdf)
        return { ok: true, path: op.filePath }
      } catch (err) {
        return { ok: false, error: err instanceof Error ? err.message : String(err) }
      }
    })
  },
  stop() {
    for (const tab of [...tabs.values()]) destroyTab(tab)
  },
})

/**
 * The deck pages the renderer laid out for "Export PDF" (op from
 * fileActions.exportPdf), printed by headless Chrome. Shared by the in-editor
 * export above and the server-side pptx → pdf conversion (lib/chrome.ts).
 */
export async function renderSlidesPdf(
  userId: string,
  op: Pick<ExportPdfOp, 'pages' | 'widthPx' | 'heightPx' | 'links' | 'fontCss'>,
): Promise<Uint8Array> {
  const html = buildPdfExportHtml(
    op.pages,
    exportPageWidthIn(op.widthPx, op.heightPx),
    PDF_EXPORT_HEIGHT_IN,
    op.links,
    op.fontCss,
  )
  return printHtmlToPdf(userId, '/', 'slides.html', { inlineHtml: html })
}

export { getWebContents }
