// Each editor's server module registers itself on import.
import './docs'
import './sheets'
import './slides'
import './pdf'
import './markdown'
import './html'
