/**
 * pdf: server side of apps/pdf/src/main (ported).
 *
 * Every page operation and the save pipeline are the upstream modules
 * (save-pdf.ts, text-edit.ts on pdfium wasm, image-edit.ts, pdf-sign.ts),
 * called with disk paths resolved from the user's virtual tree. What the
 * desktop main process decided with native dialogs (Save As target, folder for
 * split output, the PDF to insert) arrives in the request — the bridge asked.
 */

import { randomBytes } from 'node:crypto'
import { copyFileSync, existsSync, mkdirSync } from 'node:fs'
import { readFile, stat, writeFile } from 'node:fs/promises'
import { join, posix } from 'node:path'
import { Hono } from 'hono'
import type { AppEnv } from '../auth'
import { config } from '../config'
import { touchRecent } from '../db'
import { readBody } from '../lib/body'
import { normalizeVirtualPath } from '../storage'
import { registerAppModule } from './index'
import { docCtx, safeBaseName, type DocCtx } from './pmh/paths'
import { blankPdfBuffer } from '../../../upstream/soffice/apps/pdf/src/main/blank-pdf'
import { buildExportImagePaths, hasValidExportPageNumbers } from '../../../upstream/soffice/apps/pdf/src/main/export-images'
import { validateRedactionRegions } from '../../../upstream/soffice/apps/pdf/src/main/redaction'
import {
  cropPagesBytes,
  extractPagesBytes,
  insertBlankPageBytes,
  insertPdfBytes,
  mergePagesBytes,
  mergePdfBytes,
  readStaticFormFills,
  replacePagesBytes,
  savePdfToPath,
  setPageSizeBytes,
  splitPagesBytes,
  splitPdfBytes,
} from '../../../upstream/soffice/apps/pdf/src/main/save-pdf'
import { addSignature, isSignatureData, loadSignatures, removeSignature, saveSignatures } from '../../../upstream/soffice/apps/pdf/src/main/signature-store'
import type { SavePdfRequest, SignWithCertificateRequest } from '../../../upstream/soffice/apps/pdf/src/shared/ipc'

// ---- runtime assets: pdfium / harfbuzz wasm ------------------------------------
// The upstream resolver looks next to its own module (dev) or under
// process.resourcesPath/wasm (packaged). A bundled server is neither, so the
// packaged layout is recreated under the data directory.
function prepareWasm(): void {
  const modules = join(config.root, 'upstream', 'soffice', 'node_modules')
  const res = (process as { resourcesPath?: string }).resourcesPath ?? join(config.dataDir, '.resources')
  ;(process as { resourcesPath?: string }).resourcesPath = res
  const dir = join(res, 'wasm')
  mkdirSync(dir, { recursive: true })
  const files: Array<[string, string]> = [
    [join(modules, '@embedpdf', 'pdfium', 'dist', 'pdfium.wasm'), 'pdfium.wasm'],
    [join(modules, 'harfbuzzjs', 'dist', 'harfbuzz-subset.wasm'), 'hb-subset.wasm'],
  ]
  for (const [src, name] of files) {
    const dst = join(dir, name)
    if (existsSync(src) && !existsSync(dst)) copyFileSync(src, dst)
  }
}

const routes = new Hono<AppEnv>()

/** same cap as pdf-main.ts (not imported: that module wires Electron windows on load) */
const MAX_MERGE_TOTAL_BYTES = 1_073_741_824
const SIGNATURE_POSITIONS = new Set(['bottom-right', 'bottom-left', 'top-right', 'top-left', 'center'])

type Ctx = { get(key: 'user'): { id: string } }
const ctxOf = (c: Ctx) => docCtx(c.get('user').id)
const err = (e: unknown) => (e instanceof Error ? e.message : String(e))

async function readPdf(ctx: DocCtx, virtual: string): Promise<Uint8Array> {
  return new Uint8Array(await readFile(ctx.disk(virtual)))
}

async function writePdf(ctx: DocCtx, virtual: string, bytes: Uint8Array): Promise<string> {
  const st = await ctx.s.write(virtual, bytes)
  return st.path
}

/** a free name for generated output in the document's folder */
async function generatedPath(ctx: DocCtx, docPath: string, suggested: unknown, fallback: string) {
  let name = safeBaseName(posix.basename(String(suggested || fallback)), fallback)
  if (!/\.pdf$/i.test(name)) name += '.pdf'
  return ctx.s.uniquePath(posix.dirname(normalizeVirtualPath(docPath)), name)
}

// ---- documents ------------------------------------------------------------------

/** "New PDF": the PDF module has no blank in-memory mode, so a one-page A4 file is created */
routes.post('/new', async (c) => {
  const ctx = ctxOf(c)
  const { dir, name } = await c.req.json<{ dir?: string; name?: string }>()
  const target = await ctx.s.uniquePath(dir || '/', safeBaseName(name, 'Untitled.pdf').replace(/(\.pdf)?$/i, '.pdf'))
  await ctx.s.write(target, await blankPdfBuffer(), { overwrite: false })
  return c.json({ path: target })
})

routes.post('/save', async (c) => {
  const ctx = ctxOf(c)
  let request = await c.req.json<SavePdfRequest>()
  const path = request?.path
  if (typeof path !== 'string') return c.json({ ok: false, error: 'pdf: bad save request' })
  const target = typeof request.targetPath === 'string' ? request.targetPath : path
  try {
    if (request.redactions !== undefined) {
      if (target === path) return c.json({ ok: false, error: 'pdf: permanent redaction requires Save As copy' })
      request = { ...request, redactions: validateRedactionRegions(request.redactions) }
    }
    const targetDisk = ctx.disk(target)
    const skips = await savePdfToPath(ctx.disk(path), targetDisk, request)
    touchRecent(c.get('user').id, normalizeVirtualPath(target))
    return c.json({
      ok: true,
      ...(skips.skippedTextEdits.length ? { skippedTextEdits: skips.skippedTextEdits } : {}),
      ...(skips.skippedTextInserts.length ? { skippedTextInserts: skips.skippedTextInserts } : {}),
      ...(skips.skippedImageEdits.length ? { skippedImageEdits: skips.skippedImageEdits } : {}),
    })
  } catch (e) {
    return c.json({ ok: false, error: err(e) })
  }
})

routes.post('/static-form-fills', async (c) => {
  const { path } = await c.req.json<{ path: string }>()
  return c.json(await readStaticFormFills(await readPdf(ctxOf(c), path)))
})

// ---- pdfium-backed text & image editing ------------------------------------------

routes.post('/validate-text-edits', async (c) => {
  const { path, edits } = await c.req.json<{ path: string; edits: unknown[] }>()
  if (!Array.isArray(edits)) return c.json({ error: 'bad request' }, 400)
  const { validateTextEdits } = await import('../../../upstream/soffice/apps/pdf/src/main/text-edit')
  return c.json(await validateTextEdits(await readPdf(ctxOf(c), path), edits as never))
})

routes.get('/edit-fonts', async (c) => {
  const { listEditFonts } = await import('../../../upstream/soffice/apps/pdf/src/main/text-edit')
  return c.json(await listEditFonts())
})

routes.post('/can-draw-text', async (c) => {
  const { text, font, bold, italic } = await c.req.json<{ text: string; font?: string; bold?: boolean; italic?: boolean }>()
  if (typeof text !== 'string') return c.json(false)
  const { canDrawText } = await import('../../../upstream/soffice/apps/pdf/src/main/text-edit')
  return c.json(await canDrawText(text, typeof font === 'string' ? font : undefined, bold === true, italic === true))
})

routes.post('/page-images', async (c) => {
  const { path } = await c.req.json<{ path: string }>()
  const { listPageImages } = await import('../../../upstream/soffice/apps/pdf/src/main/image-edit')
  return c.json(await listPageImages(await readPdf(ctxOf(c), path)))
})

routes.post('/page-image-png', async (c) => {
  const { path, pageIndex, rect, scale } = await c.req.json<{
    path: string
    pageIndex: number
    rect: [number, number, number, number]
    scale?: number
  }>()
  if (typeof pageIndex !== 'number' || !Array.isArray(rect)) return c.json(null)
  const { renderImagePng } = await import('../../../upstream/soffice/apps/pdf/src/main/image-edit')
  return c.json(
    await renderImagePng(
      await readPdf(ctxOf(c), path),
      pageIndex,
      rect,
      typeof scale === 'number' && Number.isFinite(scale) ? scale : 1,
    ),
  )
})

routes.post('/page-preview-png', async (c) => {
  const request = await c.req.json<{ path: string } & Record<string, unknown>>()
  const { path, ...rest } = request
  const { renderPagePreviewPng } = await import('../../../upstream/soffice/apps/pdf/src/main/image-edit')
  return c.json(await renderPagePreviewPng(await readPdf(ctxOf(c), path), rest as never))
})

// ---- page operations ------------------------------------------------------------

routes.post('/extract-pages', async (c) => {
  const ctx = ctxOf(c)
  const { path, pages, suggestedName } = await c.req.json<{ path: string; pages: number[]; suggestedName?: string }>()
  if (!Array.isArray(pages)) return c.json({ ok: false, error: 'pdf: bad request' })
  try {
    const bytes = await extractPagesBytes(await readPdf(ctx, path), pages)
    const out = await generatedPath(ctx, path, suggestedName, 'pages.pdf')
    return c.json({ ok: true, savedPath: await writePdf(ctx, out, bytes) })
  } catch (e) {
    return c.json({ ok: false, error: err(e) })
  }
})

routes.post('/insert-pdf', async (c) => {
  const ctx = ctxOf(c)
  const { path, otherPath, afterPageIndex } = await c.req.json<{ path: string; otherPath: string; afterPageIndex?: number }>()
  try {
    const { merged, count } = await insertPdfBytes(
      await readPdf(ctx, path),
      await readPdf(ctx, otherPath),
      typeof afterPageIndex === 'number' ? afterPageIndex : -1,
    )
    await writePdf(ctx, path, merged)
    return c.json({ ok: true, insertedCount: count })
  } catch (e) {
    return c.json({ ok: false, error: err(e) })
  }
})

routes.post('/insert-blank-page', async (c) => {
  const ctx = ctxOf(c)
  const { path, afterPageIndex } = await c.req.json<{ path: string; afterPageIndex?: number }>()
  try {
    const bytes = await insertBlankPageBytes(
      await readPdf(ctx, path),
      typeof afterPageIndex === 'number' ? afterPageIndex : -1,
    )
    await writePdf(ctx, path, bytes)
    return c.json({ ok: true })
  } catch (e) {
    return c.json({ ok: false, error: err(e) })
  }
})

/** split into chunks; the parts land in a new folder next to the document */
routes.post('/split-pdf', async (c) => {
  const ctx = ctxOf(c)
  const { path, chunkSize, baseName } = await c.req.json<{ path: string; chunkSize?: number; baseName?: string }>()
  try {
    const parts = await splitPdfBytes(await readPdf(ctx, path), typeof chunkSize === 'number' ? chunkSize : 1)
    const base = safeBaseName(baseName, 'split')
    const dir = await ctx.s.uniquePath(posix.dirname(normalizeVirtualPath(path)), `${base} (split)`)
    await ctx.s.mkdir(dir)
    for (const [i, bytes] of parts.entries()) await writePdf(ctx, `${dir}/${base}-${i + 1}.pdf`, bytes)
    return c.json({ ok: true, savedDir: dir, count: parts.length })
  } catch (e) {
    return c.json({ ok: false, error: err(e) })
  }
})

routes.post('/merge-pdf', async (c) => {
  const ctx = ctxOf(c)
  const { path, otherPaths, suggestedName } = await c.req.json<{ path: string; otherPaths: string[]; suggestedName?: string }>()
  if (!Array.isArray(otherPaths) || otherPaths.length === 0) return c.json({ ok: true, canceled: true })
  try {
    let total = 0
    for (const p of [path, ...otherPaths]) {
      total += (await stat(ctx.disk(p))).size
      if (total > MAX_MERGE_TOTAL_BYTES) throw new Error('pdf: merge too large')
    }
    const others: Uint8Array[] = []
    for (const p of otherPaths) others.push(await readPdf(ctx, p))
    const { merged, appended } = await mergePdfBytes(await readPdf(ctx, path), others)
    const out = await generatedPath(ctx, path, suggestedName, 'merged.pdf')
    return c.json({ ok: true, savedPath: await writePdf(ctx, out, merged), appendedCount: appended })
  } catch (e) {
    return c.json({ ok: false, error: err(e) })
  }
})

routes.post('/merge-pages', async (c) => {
  const ctx = ctxOf(c)
  const { path, perSheet, direction, separator, suggestedName } = await c.req.json<{
    path: string
    perSheet: number
    direction?: string
    separator?: boolean
    suggestedName?: string
  }>()
  if (!Number.isInteger(perSheet) || perSheet < 2 || perSheet > 16) {
    return c.json({ ok: false, error: 'pdf: pages-per-sheet must be 2-16' })
  }
  try {
    const bytes = await mergePagesBytes(await readPdf(ctx, path), {
      perSheet,
      direction: direction === 'horizontal' ? 'horizontal' : 'vertical',
      separator: separator === true,
    })
    const out = await generatedPath(ctx, path, suggestedName, 'merged-pages.pdf')
    return c.json({ ok: true, savedPath: await writePdf(ctx, out, bytes) })
  } catch (e) {
    return c.json({ ok: false, error: err(e) })
  }
})

routes.post('/replace-pages', async (c) => {
  const ctx = ctxOf(c)
  const { path, otherPath, pages } = await c.req.json<{ path: string; otherPath: string; pages: number[] }>()
  if (!Array.isArray(pages) || pages.length === 0) return c.json({ ok: false, error: 'pdf: bad request' })
  try {
    const { merged, removed, inserted } = await replacePagesBytes(
      await readPdf(ctx, path),
      await readPdf(ctx, otherPath),
      pages,
    )
    await writePdf(ctx, path, merged)
    return c.json({ ok: true, removed, inserted })
  } catch (e) {
    return c.json({ ok: false, error: err(e) })
  }
})

routes.post('/set-page-size', async (c) => {
  const ctx = ctxOf(c)
  const { path, width, height } = await c.req.json<{ path: string; width: number; height: number }>()
  if (!(Number.isFinite(width) && width > 0 && Number.isFinite(height) && height > 0)) {
    return c.json({ ok: false, error: 'pdf: invalid page size' })
  }
  try {
    await writePdf(ctx, path, await setPageSizeBytes(await readPdf(ctx, path), width, height))
    return c.json({ ok: true })
  } catch (e) {
    return c.json({ ok: false, error: err(e) })
  }
})

routes.post('/split-pages', async (c) => {
  const ctx = ctxOf(c)
  const { path, perPage, suggestedName } = await c.req.json<{ path: string; perPage: number; suggestedName?: string }>()
  if (perPage !== 2 && perPage !== 4 && perPage !== 9) return c.json({ ok: false, error: 'pdf: unsupported split grid' })
  try {
    const bytes = await splitPagesBytes(await readPdf(ctx, path), perPage)
    const out = await generatedPath(ctx, path, suggestedName, 'split-pages.pdf')
    return c.json({ ok: true, savedPath: await writePdf(ctx, out, bytes) })
  } catch (e) {
    return c.json({ ok: false, error: err(e) })
  }
})

routes.post('/crop-pages', async (c) => {
  const ctx = ctxOf(c)
  const { path, pages, rect } = await c.req.json<{ path: string; pages: number[]; rect: never }>()
  if (!Array.isArray(pages) || pages.length === 0 || !rect) return c.json({ ok: false, error: 'pdf: bad request' })
  try {
    await writePdf(ctx, path, await cropPagesBytes(await readPdf(ctx, path), pages, rect))
    return c.json({ ok: true })
  } catch (e) {
    return c.json({ ok: false, error: err(e) })
  }
})

/** page images go into a new folder next to the document */
routes.post('/export-images', async (c) => {
  const ctx = ctxOf(c)
  const { path, images, pageNumbers, baseName } = await c.req.json<{
    path: string
    images: string[]
    pageNumbers: number[]
    baseName?: string
  }>()
  if (!Array.isArray(images) || images.length === 0) return c.json({ ok: false, error: 'pdf: no images' })
  if (!hasValidExportPageNumbers(pageNumbers, images.length)) {
    return c.json({ ok: false, error: 'pdf: invalid page numbers' })
  }
  try {
    const base = safeBaseName(baseName, 'page')
    const dir = await ctx.s.uniquePath(posix.dirname(normalizeVirtualPath(path)), `${base} (images)`)
    await ctx.s.mkdir(dir)
    const outputs = buildExportImagePaths(ctx.disk(dir), base, pageNumbers)
    for (const [i, b64] of images.entries()) await writeFile(outputs[i]!, Buffer.from(b64, 'base64'))
    return c.json({ ok: true, savedDir: dir, count: images.length })
  } catch (e) {
    return c.json({ ok: false, error: err(e) })
  }
})

// ---- signatures ------------------------------------------------------------------

const signaturesPath = (ctx: DocCtx) => join(ctx.s.appDataDir('pdf'), 'signatures.json')

routes.get('/signatures', async (c) => c.json(await loadSignatures(signaturesPath(ctxOf(c)))))

routes.post('/signatures', async (c) => {
  const ctx = ctxOf(c)
  const data = await c.req.json<unknown>()
  const list = await loadSignatures(signaturesPath(ctx))
  if (!isSignatureData(data)) return c.json(list)
  const next = addSignature(list, data)
  await saveSignatures(signaturesPath(ctx), next)
  return c.json(next)
})

routes.delete('/signatures/:id', async (c) => {
  const ctx = ctxOf(c)
  const list = await loadSignatures(signaturesPath(ctx))
  const next = removeSignature(list, c.req.param('id'))
  if (next.length !== list.length) await saveSignatures(signaturesPath(ctx), next)
  return c.json(next)
})

routes.post('/digital-signatures', async (c) => {
  const { path } = await c.req.json<{ path: string }>()
  try {
    const { readPdfSignatures } = await import('../../../upstream/soffice/apps/pdf/src/main/pdf-signatures')
    return c.json(await readPdfSignatures(await readPdf(ctxOf(c), path)))
  } catch {
    return c.json([])
  }
})

/** certificates uploaded for one signing flow; held in memory only, never written to disk */
const certs = new Map<string, { userId: string; p12: Uint8Array; expires: number }>()

function certFor(userId: string, certId: unknown) {
  const entry = typeof certId === 'string' ? certs.get(certId) : undefined
  if (!entry || entry.userId !== userId || entry.expires < Date.now()) return null
  return entry
}

routes.put('/certificates', async (c) => {
  const body = await readBody(c, 1024 * 1024)
  const certId = randomBytes(16).toString('hex')
  certs.set(certId, { userId: c.get('user').id, p12: body, expires: Date.now() + 30 * 60_000 })
  return c.json({ certId })
})

routes.delete('/certificates/:id', (c) => {
  if (certFor(c.get('user').id, c.req.param('id'))) certs.delete(c.req.param('id'))
  return c.json({ ok: true })
})

routes.post('/certificates/inspect', async (c) => {
  const { certId, password } = await c.req.json<{ certId: string; password: string }>()
  const entry = certFor(c.get('user').id, certId)
  if (!entry || typeof password !== 'string') return c.json({ ok: false, error: 'cert-invalid' })
  const { inspectCertificate } = await import('../../../upstream/soffice/apps/pdf/src/main/pdf-sign')
  return c.json(inspectCertificate(entry.p12, password))
})

routes.post('/sign', async (c) => {
  const ctx = ctxOf(c)
  const request = await c.req.json<SignWithCertificateRequest & { targetPath: string }>()
  const entry = certFor(c.get('user').id, request.certId)
  if (!entry || typeof request.password !== 'string') return c.json({ ok: false, error: 'cert-invalid' })
  if (typeof request.path !== 'string' || typeof request.targetPath !== 'string') {
    return c.json({ ok: false, error: 'sign-failed', message: 'pdf: bad request' })
  }
  if (normalizeVirtualPath(request.path) === normalizeVirtualPath(request.targetPath)) {
    return c.json({ ok: false, cancelled: true })
  }
  const { SignError, openCertificate, signPdf } = await import('../../../upstream/soffice/apps/pdf/src/main/pdf-sign')
  try {
    const opened = openCertificate(entry.p12, request.password)
    if (!opened.ok) return c.json({ ok: false, error: opened.error })
    const v = request.visible
    const signed = await signPdf(await readPdf(ctx, request.path), {
      loaded: opened.loaded,
      p12: entry.p12,
      password: request.password,
      reason: request.reason?.trim().slice(0, 500) || undefined,
      location: request.location?.trim().slice(0, 500) || undefined,
      contactInfo: request.contactInfo?.trim().slice(0, 500) || undefined,
      certifyLevel: request.certifyLevel,
      ...(v &&
      typeof v.png === 'string' &&
      v.png.length <= 8 * 1024 * 1024 &&
      Number.isInteger(v.pageIndex) &&
      v.pageIndex >= 0 &&
      SIGNATURE_POSITIONS.has(v.position) &&
      v.width >= 40 &&
      v.width <= 800 &&
      v.height >= 20 &&
      v.height <= 800
        ? {
            visible: {
              pageIndex: v.pageIndex,
              position: v.position,
              width: v.width,
              height: v.height,
              png: new Uint8Array(Buffer.from(v.png, 'base64')),
            },
          }
        : {}),
    })
    const path = await writePdf(ctx, request.targetPath, signed)
    certs.delete(String(request.certId))
    return c.json({ ok: true, path })
  } catch (e) {
    if (e instanceof SignError) return c.json({ ok: false, error: e.code })
    return c.json({ ok: false, error: 'sign-failed', message: err(e) })
  }
})

registerAppModule({ id: 'pdf', routes, start: prepareWasm })
