/**
 * Docs: password-protected (ECMA-376 encrypted) .docx, ported from
 * apps/docs/src/main (docs:open-decrypt, docs:set-password, docs:save*).
 *
 * The upstream password store (docx-encryption.ts) is reused as-is. It keys
 * state by Electron webContents id; here every browser tab gets its own
 * numeric id, bound to the signed-in user. Passwords and decrypted bytes
 * live only in memory: plaintext is handed to the tab through a one-shot,
 * user-bound URL, and the password never travels back to the browser.
 */

import { randomBytes } from 'node:crypto'
import { posix } from 'node:path'
import { Hono } from 'hono'
import {
  commitDocPasswordSave,
  currentDocPasswordIntentRevision,
  decryptDocx,
  discardDocPasswordIntents,
  docPasswordFor,
  DocxDecryptError,
  encryptDocx,
  forgetDocPasswords,
  isEncryptedDocx,
  markDiskEncrypted,
  rememberDocPassword,
  renameDocPassword,
  setDocPassword,
  snapshotDocPassword,
} from '../../../upstream/soffice/apps/docs/src/main/docx-encryption'
import type { AppEnv } from '../auth'
import { touchRecent } from '../db'
import { readBody } from '../lib/body'
import { normalizeVirtualPath, sha256, storageFor, StorageError } from '../storage'
import { registerAppModule } from './index'

const routes = new Hono<AppEnv>()

/** a tab nobody has heard from for this long loses its passwords */
const TAB_IDLE_MS = Number(process.env.DOCS_PASSWORD_TTL_MS ?? 8 * 3_600_000)
/** a decrypted document waits this long for its tab to fetch it */
const BLOB_TTL_MS = 2 * 60_000

// ---- browser tab → upstream "webContents id" -------------------------------------

interface TabState {
  readonly wcId: number
  readonly userId: string
  lastSeen: number
}

const tabs = new Map<string, TabState>()
let nextWcId = 1

function tabKey(userId: string, tab: unknown): string {
  if (typeof tab !== 'string' || !/^[0-9a-f]{16,64}$/.test(tab)) {
    throw new StorageError(400, 'Invalid tab id')
  }
  return `${userId}:${tab}`
}

function tabFor(userId: string, tab: unknown): TabState {
  const key = tabKey(userId, tab)
  let state = tabs.get(key)
  if (!state) {
    state = { wcId: nextWcId++, userId, lastSeen: Date.now() }
    tabs.set(key, state)
  }
  state.lastSeen = Date.now()
  return state
}

function forgetTab(key: string): void {
  const state = tabs.get(key)
  if (!state) return
  forgetDocPasswords(state.wcId)
  tabs.delete(key)
}

// ---- one-shot plaintext hand-off ---------------------------------------------------

interface Handoff {
  readonly userId: string
  readonly bytes: Buffer
  readonly expires: number
}

const handoffs = new Map<string, Handoff>()

function handOff(userId: string, bytes: Buffer): string {
  const token = randomBytes(24).toString('base64url')
  handoffs.set(token, { userId, bytes, expires: Date.now() + BLOB_TTL_MS })
  return `/api/apps/docs/blob/${token}`
}

const sweeper = setInterval(() => {
  const now = Date.now()
  for (const [token, h] of handoffs) if (h.expires <= now) handoffs.delete(token)
  for (const [key, t] of tabs) if (now - t.lastSeen > TAB_IDLE_MS) forgetTab(key)
}, 60_000)
sweeper.unref()

routes.get('/blob/:token', (c) => {
  const token = c.req.param('token')
  const h = handoffs.get(token)
  // someone else's request must not burn the owner's one-shot URL
  if (!h || h.userId !== c.get('user').id) return c.json({ error: 'Not found' }, 404)
  handoffs.delete(token)
  if (h.expires <= Date.now()) return c.json({ error: 'Not found' }, 404)
  return new Response(new Uint8Array(h.bytes), {
    headers: {
      'content-type': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'cache-control': 'no-store',
      'content-security-policy': "sandbox; default-src 'none'",
    },
  })
})

// ---- open ---------------------------------------------------------------------------

/**
 * Plain files are reported as such (the tab fetches them like any file);
 * encrypted ones need a password the tab already gave, or a prompt.
 */
async function openFor(userId: string, wcId: number, path: string, password?: string) {
  const s = storageFor(userId)
  const v = normalizeVirtualPath(path)
  const original = await s.read(v)
  const name = posix.basename(v)
  const hash = sha256(original)
  if (!isEncryptedDocx(original)) {
    rememberDocPassword(wcId, v, null)
    markDiskEncrypted(wcId, v, false)
    return { plain: true as const, path: v, name, hash }
  }
  const pwd = password ?? docPasswordFor(wcId, v)
  if (!pwd) return { needsPassword: true as const, path: v, name }
  const plain = await decryptDocx(original, pwd) // throws DocxDecryptError
  rememberDocPassword(wcId, v, pwd)
  markDiskEncrypted(wcId, v, true)
  touchRecent(userId, v)
  return { path: v, name, dataUrl: handOff(userId, plain), hash, encrypted: true }
}

routes.post('/open', async (c) => {
  const userId = c.get('user').id
  const { tab, path } = await c.req.json<{ tab: string; path: string }>()
  const state = tabFor(userId, tab)
  try {
    return c.json(await openFor(userId, state.wcId, path))
  } catch (err) {
    // a remembered password that no longer fits (file replaced): ask again
    if (err instanceof DocxDecryptError) {
      rememberDocPassword(state.wcId, normalizeVirtualPath(path), null)
      return c.json({ needsPassword: true, path: normalizeVirtualPath(path), name: posix.basename(path) })
    }
    throw err
  }
})

routes.post('/decrypt', async (c) => {
  const userId = c.get('user').id
  const { tab, path, password } = await c.req.json<{ tab: string; path: string; password: string }>()
  if (typeof path !== 'string' || typeof password !== 'string' || password.length === 0) {
    return c.json({ ok: false, reason: 'error', error: 'invalid arguments' })
  }
  const state = tabFor(userId, tab)
  try {
    const result = await openFor(userId, state.wcId, path, password)
    if (!('dataUrl' in result)) return c.json({ ok: false, reason: 'error', error: 'not encrypted' })
    return c.json({ ok: true, result })
  } catch (err) {
    if (err instanceof DocxDecryptError) return c.json({ ok: false, reason: err.reason, error: err.message })
    if (err instanceof StorageError) return c.json({ ok: false, reason: 'error', error: err.message })
    throw err
  }
})

// ---- save (every Docs save comes through here so protected files stay encrypted) ----

routes.post('/save', async (c) => {
  const userId = c.get('user').id
  const q = c.req.query()
  const state = tabFor(userId, q.tab)
  const target = normalizeVirtualPath(q.path)
  const source = q.source ? normalizeVirtualPath(q.source) : null
  const plain = Buffer.from(await readBody(c))
  // desired state for this save; the on-disk password changes only once the write lands
  const snapshot = snapshotDocPassword(state.wcId, source)
  const bytes = snapshot.password ? encryptDocx(plain, snapshot.password) : plain
  let st
  try {
    st = await storageFor(userId).write(target, bytes, {
      overwrite: q.overwrite !== '0',
      expectHash: q.expectHash || undefined,
    })
  } catch (err) {
    if (err instanceof StorageError && err.status === 409) {
      return c.json({ ok: false, conflict: err.message }, 409)
    }
    throw err
  }
  const passwordIntentPending = commitDocPasswordSave(state.wcId, snapshot, st.path)
  touchRecent(userId, st.path)
  return c.json({
    ok: true,
    path: st.path,
    hash: sha256(bytes),
    encrypted: snapshot.password !== null,
    passwordIntentPending,
  })
})

// ---- Review › Protect ----------------------------------------------------------------

routes.post('/set-password', async (c) => {
  const userId = c.get('user').id
  const { tab, path, password } = await c.req.json<{ tab: string; path: string | null; password: string | null }>()
  if (password !== null && (typeof password !== 'string' || password.length === 0 || password.length > 255)) {
    return c.json({ ok: false })
  }
  const state = tabFor(userId, tab)
  setDocPassword(state.wcId, path ? normalizeVirtualPath(path) : null, password)
  return c.json({ ok: true })
})

routes.post('/password-intent-revision', async (c) => {
  const { tab } = await c.req.json<{ tab: string }>()
  tabFor(c.get('user').id, tab)
  return c.json({ revision: currentDocPasswordIntentRevision() })
})

routes.post('/discard-password-intents', async (c) => {
  const { tab, throughRevision } = await c.req.json<{ tab: string; throughRevision: number }>()
  if (typeof throughRevision !== 'number' || !Number.isSafeInteger(throughRevision) || throughRevision < 0) {
    return c.json({ ok: false })
  }
  discardDocPasswordIntents(tabFor(c.get('user').id, tab).wcId, throughRevision)
  return c.json({ ok: true })
})

/** Home renamed/moved an open document */
routes.post('/renamed', async (c) => {
  const { tab, oldPath, newPath } = await c.req.json<{ tab: string; oldPath: string; newPath: string }>()
  renameDocPassword(
    tabFor(c.get('user').id, tab).wcId,
    normalizeVirtualPath(oldPath),
    normalizeVirtualPath(newPath),
  )
  return c.json({ ok: true })
})

/** the tab closed: its passwords go with it */
routes.post('/forget', async (c) => {
  const { tab } = await c.req.json<{ tab: string }>().catch(() => ({ tab: '' }))
  try {
    forgetTab(tabKey(c.get('user').id, tab))
  } catch {
    // malformed id: nothing to forget
  }
  return c.json({ ok: true })
})

registerAppModule({
  id: 'docs',
  routes,
  stop: () => {
    for (const key of [...tabs.keys()]) forgetTab(key)
    handoffs.clear()
  },
})
