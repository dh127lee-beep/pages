# S-Office (office-web)

S-Office는 Docs·Sheets·Slides·PDF·Markdown·HTML 편집기와 AI 패널을 **웹 서비스로 제공하는 오피스 서버 앱**입니다. 편집기는 Apache-2.0 오픈소스 데스크톱 오피스 스위트에서 가져왔습니다. 브라우저에서 `.docx`·`.xlsx`·`.pptx`·PDF 파일을 열고 편집한 뒤 원래 형식으로 저장합니다. 계정마다 파일 공간이 따로 있고, AI 키는 서버만 보관합니다.

> **English summary** — A web office server that serves the S-Office editors to the browser. Each Electron preload API (`window.desktop`, …) is replaced by an HTTP bridge, and every main-process job (file I/O, AI streaming, workbook sessions, conversion, PDF export) runs on a multi-user Node server. The editor sources are vendored in `upstream/soffice` (rebranded by `scripts/rebrand.mjs`, otherwise unmodified), pinned to the commit in `upstream/SOFFICE_COMMIT`. Quick start: `npm install && npm run setup && npm run build && ADMIN_USER=admin ADMIN_PASSWORD=change-me-please npm start`, then open http://localhost:8080.

---

## 구성

```
 브라우저                                              office-web 서버 (Node ≥ 22, Hono)
┌──────────────────────────────────┐                ┌──────────────────────────────────────────────┐
│ /            홈(셸) 화면          │                │ /api/auth, /api/me, /api/admin  계정·세션     │
│ /app/docs/   upstream 렌더러 그대로│   HTTP(JSON,   │ /api/fs          사용자별 파일 트리·휴지통    │
│ /app/sheets/ …                    │   바이트,      │ /api/ai          AI 프록시(서버 보관 키)      │
│                                   │   NDJSON 스트림)│ /api/convert     변환(soffice CLI·Chromium) │
│  ┌─────────────────────────────┐  │ ─────────────▶ │ /api/apps/<id>   앱별 메인 프로세스 포팅       │
│  │ bridge/ (preload 대체)       │  │ ◀───────────── │   sheets: xlsx-sidecar(Rust) 세션           │
│  │ window.desktop, projectApi…  │  │                │   slides: upstream main + electron 대역     │
│  └─────────────────────────────┘  │                │   pdf/markdown/html: 저장·내보내기·미리보기  │
└──────────────────────────────────┘                │ node:sqlite(계정·세션·설정) + DATA_DIR/users │
                                                     └──────────────────────────────────────────────┘
```

- **upstream/soffice/** — 편집기 원본 소스입니다. `scripts/rebrand.mjs`로 제품명·업체명·호스팅 서비스 주소만 S-Office로 바꾸고 그 외에는 **수정하지 않습니다.** 커밋은 `upstream/SOFFICE_COMMIT`에 기록되어 있습니다.
- **bridge/** — Electron preload를 대신하는 브라우저 코드입니다. 빌드할 때 각 편집기 `index.html`의 첫 모듈 스크립트로 주입되어, 렌더러보다 먼저 `window.desktop`·`window.projectApi` 등을 설치합니다. 메인 프로세스 호출은 HTTP 요청이 되고, 네이티브 메뉴 단축키(⌘S 등)·저장 대화상자·닫기 확인(`beforeunload`)은 웹 방식으로 바뀝니다. 웹에 대응 기능이 없는 데스크톱 전용 API(프린터 목록, Zotero 등)는 "취소/사용 불가" 값을 돌려줍니다.
- **server/** — 데스크톱 메인 프로세스가 하던 일을 여러 사용자용으로 옮긴 서버입니다.
  - `routes/fs.ts`: 사용자별 가상 경로(`/폴더/파일.docx`)에 원자적으로 쓰고, 해시로 동시 수정을 감지(409)하고, 휴지통·최근 파일·즐겨찾기를 관리합니다.
  - `routes/ai.ts`: upstream `@soffice/ai-provider`로 스트리밍합니다. 키는 서버에만 있고 브라우저에는 마스킹된 값만 보냅니다.
  - `routes/assist.ts`: 첨부 파일, 별표 파일 지식베이스, 대화 기록(upstream `project-store`)을 다룹니다.
  - `routes/convert.ts`, `lib/cli.ts`, `lib/chrome.ts`: 변환과 서버 측 PDF 내보내기입니다(아래 참고).
  - `apps/*`: 편집기별 서버 모듈이며 `/api/apps/<id>`에 마운트됩니다.
- **home/** — 로그인 페이지입니다. 홈 화면은 upstream 셸 렌더러를 같은 브리지 방식으로 빌드합니다.
- **scripts/** — `setup.mjs`(upstream 의존성 설치, xlsx 엔진 빌드), `build.mjs`(편집기·홈·서버·도구 빌드), `update-upstream.mjs`, `rebrand.mjs`.

## 요구 사항

- Node.js **22.12 이상**(내장 `node:sqlite` 사용, 24 권장), npm 10 이상
- Rust 툴체인(`cargo`): Sheets 편집기와 xlsx 변환에 쓰는 xlsx 엔진을 빌드합니다. 설치: `curl https://sh.rustup.rs -sSf | sh -s -- -y --profile minimal`
- Chrome 또는 Chromium(선택): 서버 측 PDF 내보내기와 HTML→DOCX에 씁니다. 자동으로 찾으며 `CHROME_PATH`로 직접 지정할 수 있습니다.

## 설치·빌드·실행

```bash
npm install            # 이 저장소의 도구(Hono, Vite, esbuild, vitest…)
npm run setup          # upstream 의존성(npm ci, Electron 바이너리 제외) + xlsx 엔진(cargo)
npm run build          # 홈 → 셸 → 편집기 6종 → CLI 도구 → 서버 번들(dist/)
ADMIN_USER=admin ADMIN_PASSWORD='change-me-please' npm start
# → http://localhost:8080
```

`ADMIN_USER`를 지정하지 않으면 처음 가입한 계정이 관리자가 됩니다. 그 뒤의 가입은 `ALLOW_SIGNUP=true`일 때만 열리고, 그렇지 않으면 관리자가 계정을 만듭니다(`/api/admin/users`).

개별 빌드:

```bash
node scripts/build.mjs apps docs sheets   # 지정한 편집기만
node scripts/build.mjs home | shell | tools | server
SERVER_OUT=/tmp/s.mjs node scripts/build.mjs server   # 다른 위치에 서버 번들
```

### Docker

```bash
docker build -t office-web .
docker run -p 8080:8080 -v office-data:/data --shm-size=512m \
  -e ADMIN_USER=admin -e ADMIN_PASSWORD='change-me-please' \
  -e ANTHROPIC_API_KEY=sk-ant-... office-web
# 또는: cp .env.example .env && docker compose up -d
```

이미지는 세 단계로 빌드합니다(Rust로 xlsx 엔진 빌드 → 전체 빌드 → 런타임). 런타임은 Node, Chromium, Noto CJK 폰트를 포함하고 비root 사용자로 실행됩니다. 데이터는 `/data` 볼륨에 저장되고, `/healthz`로 헬스 체크를 합니다. 실서비스에서는 TLS를 처리하는 리버스 프록시 뒤에 두고 `SECURE_COOKIES=true`를 설정하세요.

## 설정(환경 변수)

전체 목록과 주석은 `.env.example`에 있습니다.

| 변수 | 기본값 | 설명 |
| --- | --- | --- |
| `PORT` / `HOST` | `8080` / `0.0.0.0` | 수신 주소 |
| `DATA_DIR` | `./data` | DB(`office.db`), 사용자 파일(`users/<id>/files`), 앱 상태(`users/<id>/appdata`) |
| `ADMIN_USER` / `ADMIN_PASSWORD` | – | 첫 부팅 때 만들 관리자 계정 |
| `ALLOW_SIGNUP` | `false` | 누구나 가입 가능(첫 계정은 항상 허용) |
| `SECURE_COOKIES` | `false` | HTTPS 환경에서 세션 쿠키에 `Secure` 부여 |
| `SESSION_DAYS` | `30` | 세션 유효 기간 |
| `TRUSTED_ORIGINS` | – | 상태 변경 요청을 허용할 추가 Origin(쉼표 구분) |
| `MAX_UPLOAD_MB` / `QUOTA_MB` | `200` / `0` | 업로드 한도 / 사용자별 용량(0 = 무제한) |
| `AI_PROVIDER`, `AI_API_KEY`, `AI_MODEL`, `AI_BASE_URL` | – | 모든 사용자가 쓰는 서버 기본 AI(사용자가 직접 키를 넣으면 그 키가 우선) |
| `ANTHROPIC_API_KEY`, `OPENAI_API_KEY`, `GEMINI_API_KEY`, `DEEPSEEK_API_KEY`, `OPENROUTER_API_KEY`, `MISTRAL_API_KEY`, `XAI_API_KEY` | – | `AI_PROVIDER`가 없을 때 처음 발견한 키를 서버 기본값으로 사용 |
| `ALLOW_PRIVATE_AI_ENDPOINTS` | `false` | 일반 사용자도 사설·루프백 주소(예: 사내 Ollama)를 AI 엔드포인트로 쓸 수 있게 허용. 기본값에서는 관리자만 가능 |
| `AI_ALLOW_CUSTOM_ENDPOINTS` | `1` | `0`이면 설정 화면의 사용자 지정 엔드포인트 모델 조회를 끔 |
| `CHROME_PATH` / `DISABLE_CHROME` | 자동 / `0` | 서버 측 PDF용 브라우저 / `1`이면 끔(해당 변환은 501) |
| `CONVERT_CONCURRENCY` / `CONVERT_TIMEOUT_MS` | `2` / `180000` | 동시 변환 수 / 변환 1건 제한 시간 |
| `INTERNAL_ORIGIN` | `http://127.0.0.1:$PORT` | 헤드리스 브라우저가 이 서버에 접속할 때 쓰는 주소 |
| `SHEETS_SESSION_IDLE_MS` | `600000` | 유휴 상태의 통합 문서 세션을 닫기까지 걸리는 시간 |
| `DOCS_PASSWORD_TTL_MS` | `28800000` | 응답 없는 브라우저 탭의 문서 암호를 서버 메모리에서 지우기까지 걸리는 시간 |
| `XLSX_ENGINE_BIN` / `XLSX_SIDECAR_PATH` / `SOFFICE_CLI` / `TOOLS_DIR` | `dist/tools/…` | 바이너리 위치 재지정 |
| `PUBLIC_DIR` / `OFFICE_WEB_ROOT` | `dist/public` / 자동 | 정적 파일 위치 / 프로젝트 루트 |

## Claude CLI를 AI 공급자로 쓰기

로그인된 Claude Code CLI(`claude`)를 OpenAI 호환 API로 감싸 오피스 서버의 AI로 쓸 수 있습니다.
요청마다 `claude -p`를 내장 도구 없이 실행하고, 편집기의 에이전트 도구는 프롬프트로 전달해
`<tool_call>` 블록을 OpenAI `tool_calls`로 돌려줍니다(문서 편집까지 동작).

```bash
BRIDGE_PORT=8788 BRIDGE_KEY=sk-bridge-xxxx node scripts/claude-cli-bridge.mjs   # 127.0.0.1:8788/v1
AI_PROVIDER=custom AI_BASE_URL=http://127.0.0.1:8788/v1 AI_API_KEY=sk-bridge-xxxx AI_MODEL=sonnet npm start
```

모델: `sonnet`(기본), `opus`, `haiku`. 동시 실행 수 `BRIDGE_CONCURRENCY`(3), 시간 제한 `BRIDGE_TIMEOUT_MS`.
브리지는 루프백에만 바인딩하고 Bearer 키를 요구합니다. 사용량은 CLI에 로그인한 계정으로 청구됩니다.

## 변환 API

`GET /api/convert/formats`는 이 서버에서 가능한 변환과, 불가능한 경우 그 이유를 알려 줍니다.

| 엔진 | 경로 |
| --- | --- |
| soffice CLI(자식 프로세스, 모델 호출 없음) | md→docx/html, docx→md/html(md를 거침), pdf→docx/pptx/md, pdf→xlsx·csv/xls/ods→xlsx·xlsx→csv(xlsx 엔진 필요), odt→docx, odp→pptx |
| 샌드박스 Chromium | html→pdf, md→pdf, html→docx(upstream html2docx) |
| 편집기 자체(헤드리스) | docx→pdf: Docs 편집기를 문서 소유자의 단기 세션으로 열어 편집기의 헤드리스 내보내기 경로로 인쇄합니다. 사용자가 보는 레이아웃과 같습니다. |

- `POST /api/convert {path, to, outDir?, name?, password?, sheet?}`: 결과를 원본 옆(또는 `outDir`)에 겹치지 않는 이름으로 저장하고 그 파일 정보를 돌려줍니다.
- `GET /api/convert/download?path&to`: 결과를 트리에 저장하지 않고 바로 다운로드합니다.
- `POST /api/convert/info {path}`: 문서 구조 요약(`soffice info`)을 돌려줍니다.
- `GET /api/convert/render?path&page&scale`: 한 페이지를 PNG로 렌더링합니다(PDF가 아닌 문서는 PDF 변환을 먼저 거침).

## 보안

- **계정과 세션**: 비밀번호는 scrypt로 해시합니다. 세션 토큰은 SHA-256 해시로만 DB에 저장하며, 쿠키는 `HttpOnly`, `SameSite=Lax`이고 설정에 따라 `Secure`가 붙습니다. 비밀번호를 바꾸면 모든 세션이 만료됩니다.
- **CSRF**: 상태를 바꾸는 `/api` 요청은 `Origin`이 서버 호스트(또는 `TRUSTED_ORIGINS`)와 다르면 403으로 거부합니다.
- **파일 격리**: 모든 경로를 정규화하고 `..`·제어문자·예약 문자를 거부합니다. 사용자 루트 밖으로는 나갈 수 없습니다. 쓰기는 임시 파일에 쓴 뒤 이름을 바꾸는 방식이며, 삭제한 항목은 휴지통으로 갑니다.
- **사용자 콘텐츠 실행 방지**: `/api/fs/raw` 응답에는 `Content-Security-Policy: sandbox`와 `nosniff`가 붙습니다. 업로드한 HTML이나 SVG가 이 사이트의 권한으로 실행되지 않습니다.
- **AI 키**: 키는 서버의 사용자별 설정 파일과 환경 변수에만 있고, 브라우저에는 `••••••••`로 보냅니다. 스트리밍 요청에서는 공급자·모델 선택만 받아들이고, 키·Base URL·사용자 지정 엔드포인트는 서버 사본을 씁니다. 일반 사용자가 사설·루프백 주소를 엔드포인트로 지정하면 거부합니다(`ALLOW_PRIVATE_AI_ENDPOINTS`). 로컬 바이너리를 실행하는 `codex` 공급자는 쓸 수 없습니다.
- **SSRF**: AI 도구가 가져오는 이미지는 upstream의 SSRF 가드(사설·링크로컬 주소 차단, 리다이렉트마다 재검증)를 거칩니다. 서버 측 Chromium은 사용자 폴더를 서비스하는 가상 호스트 외의 모든 요청을 차단하고, 편집기 인쇄 작업은 이 서버 Origin으로만 접속할 수 있습니다. 인쇄에 쓰는 세션은 작업이 끝나면 바로 폐기합니다.
- **홈 디렉터리 격리**: upstream 헬퍼가 `os.homedir()` 아래에 데스크톱 로그인 정보 등을 찾는 일이 운영자 계정에 닿지 않도록, 서버는 `HOME`을 `DATA_DIR/.home`으로 바꿔서 실행합니다.

## 개발

```bash
npm test             # vitest: 저장소 경로 안전성, 인증·CSRF, 파일 API, AI 키 마스킹·SSRF, 변환
npm run typecheck    # server/·tests/ + bridge/ (upstream 소스는 경로 매핑으로 함께 검사)
```

테스트는 매번 임시 `DATA_DIR`에 서버를 새로 띄우고 `app.request`로 직접 호출합니다. 편집기 모듈은 모킹합니다. 변환 테스트는 `dist/tools`가 빌드되어 있을 때만 실행됩니다.

## upstream 업데이트

```bash
UPSTREAM_REPO=<git url> npm run update-upstream -- v0.12.0   # 태그·브랜치·커밋(생략하면 기본 브랜치 최신), 받은 뒤 자동으로 rebrand
npm run setup && npm run build && npm test
git diff --stat upstream/            # 변경 범위 검토 후 커밋
```

웹 전용 동작은 모두 `bridge/`·`server/`·`scripts/`에 있고 브랜드 치환은 스크립트로 다시 적용되므로, upstream을 통째로 바꿔도 충돌이 나지 않습니다. 새로 생긴 preload API는 브라우저 콘솔에 `[bridge] … is not available in the web edition`으로 표시되므로, 그 목록을 보고 브리지에 구현을 추가하면 됩니다.

## 제한 사항

- 데스크톱 전용 기능은 웹에서 동작하지 않거나 대체됩니다: 시스템 프린터 선택(브라우저 인쇄 대화상자 사용), Zotero 연동, OS 맞춤법 사전, 호스팅 AI 계정 로그인(BYOK 또는 서버 키 사용), Codex CLI 공급자.
- 서버 측 PDF 변환은 현재 docx·html·md만 지원합니다. xlsx·pptx→pdf는 각 편집기에서 직접 내보내야 하고, API는 501과 이유를 돌려줍니다. pdf→html도 지원하지 않습니다.
- docx→html은 Markdown을 거치는 단순 변환입니다(Word 편집기의 HTML 내보내기와 다름).
- 실시간 공동 편집은 없습니다. 같은 파일을 동시에 저장하면 해시 비교로 충돌을 감지하고, 덮어쓸지 묻습니다.
- 전문(全文) 검색은 별표 파일 지식베이스에 대한 단순 스캔입니다.
- Slides 발표자 보기의 청중 화면은 브라우저 팝업 창으로 열립니다(팝업 차단을 해제해야 하며, 프로젝터 화면으로 직접 끌어다 놓고 "전체 화면"을 누릅니다). 브라우저는 창을 다른 모니터로 옮길 수 없어 "디스플레이 바꾸기"는 동작하지 않습니다. 팝업이 막히면 발표자 보기만 단독으로 진행됩니다.
- 암호로 보호된 docx는 서버가 메모리에서만 복호화·재암호화합니다. 암호는 브라우저 탭별로 서버 메모리에만 있고(`DOCS_PASSWORD_TTL_MS`, 기본 8시간 유휴 후 삭제) 서버를 재시작하면 다시 물어봅니다. 암호화 문서의 충돌 복구 사본은 만들지 않습니다.
- HTML 편집기 소스 창에 매우 빠르게 입력할 때 React 오류 #185(최대 업데이트 깊이)가 한 번 보고되었으나 재현되지 않았습니다(소스·분할 보기에서 지연 0으로 약 3,200자씩 6회 입력, 오류 0건). 웹 브리지의 미리보기 갱신은 React 상태로 되돌아가는 경로가 없어 원인일 가능성은 낮고, upstream 편집기 쪽 문제로 보고 있습니다. 발생하면 새로 고침으로 복구됩니다.

## 라이선스

Apache-2.0. `LICENSE`와 `NOTICE`를 참고하세요. 편집기 코드는 Copyright 2026 Mainfunc, Inc.의 Apache-2.0 코드를 바탕으로 하며, 원 저작권·NOTICE 문구는 라이선스 요구에 따라 `upstream/soffice/LICENSE`·`NOTICE`에 그대로 둡니다.
