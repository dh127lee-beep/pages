#!/usr/bin/env node
/**
 * One-time setup: install the vendored upstream's dependencies (no Electron
 * binary download, no install scripts) and build native helpers.
 *
 *   npm run setup
 */

import { spawnSync } from 'node:child_process'
import { existsSync } from 'node:fs'
import { dirname, join, resolve } from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..')
const UPSTREAM = join(ROOT, 'upstream', 'soffice')

function run(cmd, args, opts = {}) {
  console.log(`\x1b[36m[setup]\x1b[0m ${cmd} ${args.join(' ')}`)
  const res = spawnSync(cmd, args, { stdio: 'inherit', ...opts })
  if (res.status !== 0) process.exit(res.status ?? 1)
}

run('npm', ['ci', '--prefix', UPSTREAM, '--ignore-scripts', '--no-audit', '--no-fund'], {
  env: { ...process.env, ELECTRON_SKIP_BINARY_DOWNLOAD: '1' },
})

// optional native steps owned by separate modules (scripts/setup-<name>.mjs exporting setup())
for (const name of ['xlsx-engine']) {
  const file = join(ROOT, 'scripts', `setup-${name}.mjs`)
  if (existsSync(file)) await (await import(pathToFileURL(file).href)).setup({ ROOT, UPSTREAM, run })
}
console.log('\x1b[36m[setup]\x1b[0m done — now run "npm run build"')
