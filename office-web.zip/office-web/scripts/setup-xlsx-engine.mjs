/**
 * Builds the Sheets workbook engine (upstream apps/sheets/native/xlsx-engine,
 * a Rust sidecar the server drives over stdio) and installs the binary as
 * dist/tools/xlsx-sidecar. Needs a Rust toolchain (https://rustup.rs).
 */

import { spawnSync } from 'node:child_process'
import { copyFileSync, existsSync, mkdirSync } from 'node:fs'
import { homedir } from 'node:os'
import { join } from 'node:path'

function findCargo() {
  const candidates = [
    process.env.CARGO,
    join(homedir(), '.cargo', 'bin', process.platform === 'win32' ? 'cargo.exe' : 'cargo'),
    'cargo',
  ].filter(Boolean)
  for (const c of candidates) {
    const res = spawnSync(c, ['--version'], { stdio: 'ignore' })
    if (res.status === 0) return c
  }
  return null
}

export async function setup({ ROOT, UPSTREAM, run }) {
  const exe = process.platform === 'win32' ? 'xlsx-sidecar.exe' : 'xlsx-sidecar'
  const toolsDir = join(ROOT, 'dist', 'tools')
  const targetDir = join(toolsDir, 'xlsx-engine-target')
  const cargo = findCargo()
  if (!cargo) {
    console.warn(
      '\x1b[33m[setup]\x1b[0m Rust (cargo) not found: the Sheets editor needs it.\n' +
        '        Install with: curl https://sh.rustup.rs -sSf | sh -s -- -y --profile minimal\n' +
        '        then re-run "npm run setup".',
    )
    return
  }
  run(cargo, [
    'build',
    '--release',
    '--locked',
    '--manifest-path',
    join(UPSTREAM, 'apps', 'sheets', 'native', 'xlsx-engine', 'Cargo.toml'),
    '--target-dir',
    targetDir,
  ])
  const built = join(targetDir, 'release', exe)
  if (!existsSync(built)) throw new Error(`xlsx sidecar was not produced at ${built}`)
  mkdirSync(toolsDir, { recursive: true })
  copyFileSync(built, join(toolsDir, exe))
  console.log(`\x1b[36m[setup]\x1b[0m xlsx engine → ${join(toolsDir, exe)}`)
}
