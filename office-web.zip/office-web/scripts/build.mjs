#!/usr/bin/env node
/**
 * Build pipeline.
 *
 *   node scripts/build.mjs            everything
 *   node scripts/build.mjs apps [id…] editors only (optionally a subset)
 *   node scripts/build.mjs home       home page only
 *   node scripts/build.mjs server     server bundle only
 *
 * Editors are built from the vendored upstream sources with upstream's own
 * Vite config; the only additions are a URL base (/app/<id>/) and the web
 * bridge, injected as the first module script so `window.desktop` & co. exist
 * before the renderer's entry module runs. Upstream files are never modified.
 */

import { existsSync, mkdirSync, rmSync } from 'node:fs'
import { dirname, join, relative, resolve, sep } from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'
import { readFile } from 'node:fs/promises'

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..')
const UPSTREAM = join(ROOT, 'upstream', 'soffice')
const UPSTREAM_MODULES = join(UPSTREAM, 'node_modules')
const DIST = join(ROOT, 'dist')
const PUBLIC = join(DIST, 'public')

export const APP_IDS = ['docs', 'sheets', 'slides', 'pdf', 'markdown', 'html']

function log(msg) {
  console.log(`\x1b[36m[build]\x1b[0m ${msg}`)
}

function requireUpstreamInstall() {
  if (!existsSync(join(UPSTREAM_MODULES, 'vite'))) {
    console.error('upstream dependencies are missing: run "npm run setup" first')
    process.exit(1)
  }
}

/**
 * Desktop CSP entries that name Electron-only schemes, swapped for their web
 * equivalents (served from our own origin, still sandboxed by the frame and
 * by a CSP sandbox header on the response).
 */
const CSP_PATCHES = {
  html: [['frame-src html-preview:', "frame-src 'self'"]],
}

/** Vite plugin: prepend the app's bridge as the first module script of index.html */
export function bridgePlugin(id, entry = join(ROOT, 'bridge', 'apps', `${id}.ts`)) {
  const VIRTUAL = '/@office-web/bridge.ts'
  return {
    name: 'office-web-bridge',
    enforce: 'pre',
    resolveId(source) {
      if (source === VIRTUAL) return entry
      return null
    },
    transformIndexHtml: {
      order: 'pre',
      handler(html) {
        for (const [from, to] of CSP_PATCHES[id] ?? []) html = html.split(from).join(to)
        return {
          html,
          tags: [
            { tag: 'script', attrs: { type: 'module', src: VIRTUAL }, injectTo: 'head-prepend' },
          ],
        }
      },
    },
  }
}

async function buildApps(ids) {
  requireUpstreamInstall()
  const vite = await import(pathToFileURL(join(UPSTREAM_MODULES, 'vite', 'dist', 'node', 'index.js')).href)
  for (const id of ids) {
    if (!APP_IDS.includes(id)) throw new Error(`unknown app: ${id}`)
    const appDir = join(UPSTREAM, 'apps', id)
    const outDir = join(PUBLIC, 'app', id)
    const started = Date.now()
    log(`editor ${id} → ${outDir}`)
    const cwd = process.cwd()
    // upstream configs resolve paths relative to the app directory
    process.chdir(appDir)
    try {
      await vite.build({
        configFile: join(appDir, 'vite.renderer.config.ts'),
        root: join(appDir, 'src', 'renderer'),
        base: `/app/${id}/`,
        logLevel: 'warn',
        mode: 'production',
        plugins: [bridgePlugin(id)],
        define: { 'import.meta.env.OFFICE_WEB': 'true' },
        build: {
          outDir,
          emptyOutDir: true,
          chunkSizeWarningLimit: 1e9,
          reportCompressedSize: false,
        },
      })
    } finally {
      process.chdir(cwd)
    }
    log(`editor ${id} done in ${((Date.now() - started) / 1000).toFixed(1)}s`)
  }
}

async function buildHome() {
  const vite = await import('vite')
  const react = (await import('@vitejs/plugin-react')).default
  log(`login page → ${PUBLIC}`)
  // only the login page's own output; the shell home (index.html, assets) and editors stay
  for (const entry of ['login.html', 'login-assets', 'favicon.svg']) rmSync(join(PUBLIC, entry), { recursive: true, force: true })
  await vite.build({
    configFile: false,
    root: join(ROOT, 'home'),
    base: '/',
    logLevel: 'warn',
    plugins: [react()],
    resolve: {
      alias: {
        '@bridge': join(ROOT, 'bridge'),
        '@soffice/ai-provider/browser': join(UPSTREAM, 'packages', 'ai-provider', 'src', 'browser.ts'),
        '@soffice/ui/tokens.css': join(UPSTREAM, 'packages', 'ui', 'src', 'tokens.css'),
      },
    },
    build: {
      outDir: PUBLIC,
      emptyOutDir: false,
      reportCompressedSize: false,
      assetsDir: 'login-assets',
      rollupOptions: { input: { login: join(ROOT, 'home', 'login.html') } },
    },
  })
}

async function buildServer() {
  requireUpstreamInstall()
  const esbuild = await import('esbuild')
  const outfile = process.env.SERVER_OUT ? resolve(process.env.SERVER_OUT) : join(DIST, 'server', 'index.mjs')
  log(`server → ${outfile}`)
  await esbuild.build({
    entryPoints: [join(ROOT, 'server', 'src', 'main.ts')],
    outfile,
    bundle: true,
    platform: 'node',
    format: 'esm',
    target: 'node22',
    sourcemap: true,
    legalComments: 'none',
    logLevel: 'warning',
    // upstream workspace packages resolve through the vendored tree
    nodePaths: [UPSTREAM_MODULES, join(ROOT, 'node_modules')],
    define: { __OFFICE_WEB_ROOT__: JSON.stringify(ROOT) },
    external: ['node:sqlite', '*.node', 'canvas', 'bufferutil', 'utf-8-validate'],
    // the Slides main process runs unmodified on an interactive stand-in (IPC over HTTP, tab dialogs)
    plugins: [
      {
        // Vite-style `?raw` text imports (html2docx's in-page scripts, op guides)
        name: 'raw-text',
        setup(b) {
          b.onResolve({ filter: /\?raw$/ }, (args) => ({
            path: resolve(args.resolveDir, args.path.replace(/\?raw$/, '')),
            namespace: 'raw-text',
          }))
          b.onLoad({ filter: /.*/, namespace: 'raw-text' }, async (args) => ({
            contents: await readFile(args.path, 'utf8'),
            loader: 'text',
          }))
        },
      },
      {
        name: 'slides-electron',
        setup(b) {
          const slidesMain = join(UPSTREAM, 'apps', 'slides', 'src', 'main')
          b.onResolve({ filter: /^electron$/ }, (args) =>
            args.importer.startsWith(slidesMain)
              ? { path: join(ROOT, 'server', 'src', 'apps', 'slides', 'electron-shim.ts') }
              : undefined,
          )
          // electron-vite `?asset` imports evaluate to the file's absolute path
          b.onResolve({ filter: /\?asset$/ }, async (args) => {
            const res = await b.resolve(args.path.replace(/\?asset$/, ''), {
              resolveDir: args.resolveDir,
              kind: 'import-statement',
            })
            return res.errors.length ? undefined : { path: res.path, namespace: 'ow-asset' }
          })
          // resolved against the install root at runtime, so a relocated install
          // (or a Docker image built elsewhere) still finds the file
          b.onLoad({ filter: /.*/, namespace: 'ow-asset' }, (args) => ({
            contents: [
              "import { join } from 'node:path'",
              "import { config } from './config'",
              `export default join(config.root, ...${JSON.stringify(relative(ROOT, args.path).split(sep))})`,
            ].join('\n'),
            resolveDir: join(ROOT, 'server', 'src'),
            loader: 'js',
          }))
        },
      },
      {
        // any other upstream main helper importing electron gets a generic stand-in
        // (nativeImage via pngjs, everything else throws) — must stay after slides-electron
        name: 'electron-fallback',
        setup(b) {
          b.onResolve({ filter: /^electron$/ }, () => ({
            path: join(ROOT, 'server', 'src', 'lib', 'electron-shim.ts'),
          }))
        },
      },
    ],
    banner: {
      js: [
        "import { createRequire as __owCreateRequire } from 'node:module';",
        "import { fileURLToPath as __owFileURLToPath } from 'node:url';",
        "import { dirname as __owDirname } from 'node:path';",
        'const require = __owCreateRequire(import.meta.url);',
        'const __filename = __owFileURLToPath(import.meta.url);',
        'const __dirname = __owDirname(__filename);',
      ].join('\n'),
    },
  })
}

/** optional build steps owned by separate modules (scripts/build-<name>.mjs exporting build()) */
async function runHook(name) {
  const file = join(ROOT, 'scripts', `build-${name}.mjs`)
  if (!existsSync(file)) return false
  const mod = await import(pathToFileURL(file).href)
  await mod.build({ ROOT, UPSTREAM, UPSTREAM_MODULES, DIST, PUBLIC, log })
  return true
}

async function main() {
  const [target, ...rest] = process.argv.slice(2)
  mkdirSync(PUBLIC, { recursive: true })
  const started = Date.now()
  if (!target || target === 'all') {
    await buildHome()
    await runHook('shell')
    await buildApps(APP_IDS)
    await runHook('tools')
    await buildServer()
  } else if (target === 'apps') {
    await buildApps(rest.length ? rest : APP_IDS)
  } else if (target === 'home') {
    await buildHome()
  } else if (target === 'server') {
    await buildServer()
  } else if (await runHook(target)) {
    // scripts/build-<target>.mjs
  } else {
    throw new Error(`unknown target: ${target}`)
  }
  log(`finished in ${((Date.now() - started) / 1000).toFixed(1)}s`)
}

// importable by build hooks without running the CLI
if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  main().catch((err) => {
    console.error(err)
    process.exit(1)
  })
}
