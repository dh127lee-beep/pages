#!/usr/bin/env node
/**
 * Rebrand a source tree to S-Office.
 *
 *   node scripts/rebrand.mjs <dir> [--prune]
 *
 * Applied to the editor sources after every upstream update (see
 * update-upstream.mjs). Rewrites every text file under <dir>, and renames
 * files and folders, so the upstream product and vendor names are gone:
 *
 *   display text   product / vendor name      -> S-Office
 *   identifiers    <Name>X / login<Name>      -> SOfficeX / loginSCloud
 *   lowercase      keys, packages, paths      -> soffice / scloud
 *   hosts          the vendor's domains        -> s-office.invalid
 *
 * The hosted-service endpoints become unresolvable (.invalid never resolves),
 * which is what the web edition wants: it routes AI through the server.
 *
 * The upstream names are spelled from pieces below so this file does not
 * rewrite itself when run over the whole repository.
 *
 * License files are left verbatim: the Apache-2.0 license requires the
 * original copyright and NOTICE text to be kept with redistributed code.
 * --prune also deletes upstream's desktop packaging and marketing documents,
 * which the web build does not use.
 */

import { existsSync, readdirSync, readFileSync, renameSync, rmSync, statSync, writeFileSync } from 'node:fs'
import { basename, join, relative, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

const SELF = fileURLToPath(import.meta.url)
const SKIP_DIRS = new Set(['node_modules', '.git', 'target', 'dist', 'data'])
const KEEP_VERBATIM = /^(LICENSE.*|NOTICE)$/
const PRUNE = ['packaging', 'docs/i18n', 'PRIVACY.md', 'CODE_OF_CONDUCT.md', 'CONTRIBUTING.md', 'SECURITY.md']

const GEN = 'Gen'
const OFFICE = 'office'
const SPARK = 'spark'
const product = `${GEN}[Oo]${OFFICE.slice(1)}` // the product name, either capitalisation
const vendor = `${GEN}[Ss]${SPARK.slice(1)}`
const lower = (s) => s.toLowerCase()

const ID = 'A-Za-z0-9_$'
// left edge of a word: start, a non-identifier char, or an escape like "\n"
const L = `(?<=^|[^${ID}]|\\\\[ntr])`
const R = `(?![${ID}])`

/** [pattern, replacement] in order; earlier rules win */
const RULES = [
  [new RegExp(`github\\.com/${lower(GEN + SPARK)}-ai/${lower(GEN + OFFICE)}(?:\\.git)?`, 'g'), 's-office.invalid'],
  [new RegExp(`(?:[a-z0-9-]+\\.)*(?:${lower(GEN + SPARK)}|${lower(GEN + OFFICE)})\\.ai`, 'gi'), 's-office.invalid'],
  // names in prose (Polish/Czech case endings dropped)
  [new RegExp(`${L}(?:${product}|${vendor})(?:u|em|a|ie|iem)?${R}`, 'g'), 'S-Office'],
  [new RegExp(`${L}(?:${product}|${vendor})(?=['’])`, 'g'), 'S-Office'],
  // identifiers and keys
  [new RegExp(`${GEN}O${OFFICE.slice(1)}`, 'g'), 'SOffice'],
  [new RegExp(`${GEN}${OFFICE}`, 'g'), 'Soffice'],
  [new RegExp(`${lower(GEN)}O${OFFICE.slice(1)}`, 'g'), 'sOffice'],
  [new RegExp(`${GEN + OFFICE}`.toUpperCase(), 'g'), 'SOFFICE'],
  [new RegExp(lower(GEN + OFFICE), 'g'), 'soffice'],
  [new RegExp(vendor, 'g'), 'SCloud'],
  [new RegExp(`${GEN + SPARK}`.toUpperCase(), 'g'), 'SCLOUD'],
  [new RegExp(lower(GEN + SPARK), 'gi'), 'scloud'],
]

export function rebrandText(text) {
  let out = text
  for (const [re, to] of RULES) out = out.replace(re, to)
  return out
}

/** path segments use the identifier forms (no spaces or hyphens added) */
export function rebrandName(name) {
  return name
    .replace(new RegExp(`${GEN}O${OFFICE.slice(1)}`, 'g'), 'SOffice')
    .replace(new RegExp(lower(GEN + OFFICE), 'gi'), 'soffice')
    .replace(new RegExp(vendor, 'g'), 'SCloud')
    .replace(new RegExp(lower(GEN + SPARK), 'gi'), 'scloud')
}

function isBinary(buf) {
  const n = Math.min(buf.length, 8000)
  for (let i = 0; i < n; i++) if (buf[i] === 0) return true
  return false
}

function walk(dir, stats) {
  for (const entry of readdirSync(dir, { withFileTypes: true })) {
    let path = join(dir, entry.name)
    if (entry.isSymbolicLink() || path === SELF) continue
    if (entry.isDirectory()) {
      if (SKIP_DIRS.has(entry.name)) continue
      walk(path, stats)
    } else if (entry.isFile() && !KEEP_VERBATIM.test(entry.name)) {
      const buf = readFileSync(path)
      if (!isBinary(buf)) {
        const text = buf.toString('utf8')
        const next = rebrandText(text)
        if (next !== text) {
          writeFileSync(path, next)
          stats.files++
        }
      }
    }
    const renamed = rebrandName(entry.name)
    if (renamed !== entry.name) {
      const target = join(dir, renamed)
      if (existsSync(target)) throw new Error(`rename collision: ${relative(process.cwd(), target)}`)
      renameSync(path, target)
      path = target
      stats.renamed++
    }
  }
}

if (process.argv[1] && resolve(process.argv[1]) === SELF) {
  const dir = process.argv[2]
  if (!dir || !statSync(dir).isDirectory()) {
    console.error('usage: node scripts/rebrand.mjs <dir> [--prune]')
    process.exit(1)
  }
  if (process.argv.includes('--prune')) {
    for (const p of PRUNE) rmSync(join(dir, p), { recursive: true, force: true })
  }
  const stats = { files: 0, renamed: 0 }
  walk(resolve(dir), stats)
  console.log(`[rebrand] ${basename(resolve(dir))}: ${stats.files} files rewritten, ${stats.renamed} renamed`)
}
