/**
 * Build hook 'shell': the upstream shell renderer (tab strip, Home, Settings)
 * becomes the web home page at "/". Same rules as the editors: upstream's
 * sources and plugins, plus the web bridge as the first module script.
 */

import { rmSync } from 'node:fs'
import { join } from 'node:path'
import { pathToFileURL } from 'node:url'
import { bridgePlugin } from './build.mjs'

/**
 * Web-edition edits applied to upstream modules at build time (the files on
 * disk stay untouched). Each is an exact string swap; a swap that no longer
 * matches fails the build so an upstream update cannot silently drop it.
 */
const WEB_PATCHES = [
  {
    file: 'apps/shell/src/renderer/src/Home.tsx',
    why: 'cloud projects need a hosted AI account sign-in, which the web edition does not have',
    from: '{loggedIn && (\n            <button\n              className={`nav-item${cloudMode',
    to: '{false && loggedIn && (\n            <button\n              className={`nav-item${cloudMode',
  },
  {
    file: 'apps/shell/src/renderer/src/SettingsModal.tsx',
    why: 'hosted AI credits do not apply to server accounts',
    from: "{loggedIn && (\n                  <Field\n                    label={t('credits')}",
    to: "{false && loggedIn && (\n                  <Field\n                    label={t('credits')}",
  },
  {
    file: 'apps/shell/src/renderer/src/SettingsModal.tsx',
    why: 'CLI / agent-skill installation targets the desktop machine',
    from: "  { id: 'integrations', labelKey: 'setSecIntegrations' },\n",
    to: '',
  },
]

function webPatchPlugin(UPSTREAM) {
  const byFile = new Map()
  for (const p of WEB_PATCHES) {
    const abs = join(UPSTREAM, p.file)
    byFile.set(abs, [...(byFile.get(abs) ?? []), p])
  }
  return {
    name: 'office-web-patches',
    enforce: 'pre',
    transform(code, id) {
      const patches = byFile.get(id.split('?')[0])
      if (!patches) return null
      let out = code
      for (const p of patches) {
        if (!out.includes(p.from)) throw new Error(`web patch no longer applies to ${p.file}: ${p.why}`)
        out = out.replace(p.from, p.to)
      }
      return { code: out, map: null }
    },
  }
}

export async function build({ ROOT, UPSTREAM, UPSTREAM_MODULES, PUBLIC, log }) {
  const vite = await import(pathToFileURL(join(UPSTREAM_MODULES, 'vite', 'dist', 'node', 'index.js')).href)
  const react = (await import(pathToFileURL(join(UPSTREAM_MODULES, '@vitejs', 'plugin-react', 'dist', 'index.js')).href)).default
  const appDir = join(UPSTREAM, 'apps', 'shell')
  const root = join(appDir, 'src', 'renderer')
  const started = Date.now()
  log(`shell home → ${PUBLIC}`)
  // only the shell's own output; editors (public/app) and the login page stay
  for (const entry of ['index.html', 'assets']) rmSync(join(PUBLIC, entry), { recursive: true, force: true })
  const cwd = process.cwd()
  process.chdir(appDir)
  try {
    await vite.build({
      configFile: false,
      root,
      base: '/',
      logLevel: 'warn',
      mode: 'production',
      plugins: [
        webPatchPlugin(UPSTREAM),
        react(),
        bridgePlugin('shell', join(ROOT, 'bridge', 'apps', 'shell.ts')),
      ],
      resolve: {
        // the bridge lives outside the upstream tree; point its upstream imports there
        alias: {
          '@soffice/ai-provider/browser': join(UPSTREAM, 'packages', 'ai-provider', 'src', 'browser.ts'),
          '@soffice/ui/ai-panel-prefs': join(UPSTREAM, 'packages', 'ui', 'src', 'ai-panel-prefs.ts'),
        },
      },
      define: { 'import.meta.env.OFFICE_WEB': 'true' },
      build: {
        outDir: PUBLIC,
        emptyOutDir: false,
        chunkSizeWarningLimit: 1e9,
        reportCompressedSize: false,
        rollupOptions: { input: { index: join(root, 'index.html') } },
      },
    })
  } finally {
    process.chdir(cwd)
  }
  log(`shell home done in ${((Date.now() - started) / 1000).toFixed(1)}s`)
}
