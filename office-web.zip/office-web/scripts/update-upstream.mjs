#!/usr/bin/env node
/**
 * Replace the vendored editor sources (upstream/soffice) with another ref of
 * the upstream repository, rebrand them, and record the commit.
 *
 *   UPSTREAM_REPO=<git url> node scripts/update-upstream.mjs          latest default branch
 *   UPSTREAM_REPO=<git url> node scripts/update-upstream.mjs v0.12.0  a tag, branch or commit
 *
 * The vendored tree is never edited by hand: every web-specific behaviour
 * lives in bridge/, server/ and scripts/, and the S-Office rebrand is
 * re-applied by scripts/rebrand.mjs. After updating, run
 * `npm run setup && npm run build && npm test`, open each editor, and review
 * `git diff --stat upstream/` before committing — new preload methods show
 * up as "[bridge] … is not available in the web edition" in the console.
 */

import { spawnSync } from 'node:child_process'
import { existsSync, mkdtempSync, readFileSync, renameSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..')
const TARGET = join(ROOT, 'upstream', 'soffice')
const COMMIT_FILE = join(ROOT, 'upstream', 'SOFFICE_COMMIT')
const REPO = process.env.UPSTREAM_REPO
if (!REPO) {
  console.error('set UPSTREAM_REPO to the git URL of the upstream editor sources')
  process.exit(1)
}
const ref = process.argv[2] ?? ''

function git(args, cwd) {
  const res = spawnSync('git', args, { cwd, stdio: ['ignore', 'pipe', 'inherit'], encoding: 'utf8' })
  if (res.status !== 0) {
    console.error(`git ${args.join(' ')} failed`)
    process.exit(res.status ?? 1)
  }
  return res.stdout.trim()
}

const dirty = spawnSync('git', ['status', '--porcelain', '--', 'upstream'], { cwd: ROOT, encoding: 'utf8' })
if (dirty.status === 0 && dirty.stdout.trim()) {
  console.error('upstream/ has uncommitted changes; commit or discard them first')
  process.exit(1)
}

const work = mkdtempSync(join(tmpdir(), 'soffice-upstream-'))
const checkout = join(work, 'soffice')
try {
  console.log(`[upstream] fetching ${REPO}${ref ? ` @ ${ref}` : ''}`)
  git(['init', '-q', checkout])
  git(['remote', 'add', 'origin', REPO], checkout)
  git(['fetch', '-q', '--depth', '1', 'origin', ref || 'HEAD'], checkout)
  git(['checkout', '-q', 'FETCH_HEAD'], checkout)
  const commit = git(['rev-parse', 'HEAD'], checkout)
  rmSync(join(checkout, '.git'), { recursive: true, force: true })
  writeFileSync(
    join(checkout, 'README.md'),
    '# S-Office editors\n\nEditor sources used by the S-Office web server. Licensed under the\nApache License, Version 2.0; see LICENSE and NOTICE in this folder.\n',
  )
  const rebrand = spawnSync(process.execPath, [join(ROOT, 'scripts', 'rebrand.mjs'), checkout, '--prune'], {
    stdio: 'inherit',
  })
  if (rebrand.status !== 0) process.exit(rebrand.status ?? 1)

  const previous = existsSync(COMMIT_FILE) ? readFileSync(COMMIT_FILE, 'utf8').trim() : '(none)'
  // keep the installed node_modules out of the swap; `npm run setup` refreshes it
  const backup = `${TARGET}.old`
  rmSync(backup, { recursive: true, force: true })
  if (existsSync(TARGET)) renameSync(TARGET, backup)
  renameSync(checkout, TARGET)
  rmSync(backup, { recursive: true, force: true })
  writeFileSync(COMMIT_FILE, `${commit}\n`)
  console.log(`[upstream] ${previous.slice(0, 12)} → ${commit.slice(0, 12)}`)
  console.log('[upstream] next: npm run setup && npm run build && npm test')
} finally {
  rmSync(work, { recursive: true, force: true })
}
