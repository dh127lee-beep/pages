/**
 * Server-side tools: the upstream `soffice` CLI, laid out the way the
 * packaged desktop app ships it so its resource lookup (src/resources.ts)
 * finds everything beside the bundle:
 *
 *   dist/tools/cli/soffice.cjs          the CLI (one CommonJS bundle)
 *   dist/tools/cli/node_modules/jsdom…    the externals it loads at runtime
 *   dist/tools/wasm/pdfium.wasm           PDF rasterizer / text engine
 *   dist/tools/xlsx-sidecar               Rust workbook engine (scripts/setup-xlsx-engine.mjs)
 *
 * Mirrors upstream packages/cli/build.mjs + collect-deps.mjs but writes into
 * our dist/ instead of the vendored tree. Runs as the `tools` build hook.
 */

import { cpSync, existsSync, mkdirSync, readFileSync, rmSync } from 'node:fs'
import { readFile } from 'node:fs/promises'
import { dirname, join, relative, resolve, sep } from 'node:path'
import { pathToFileURL } from 'node:url'

export async function build({ UPSTREAM, UPSTREAM_MODULES, DIST, log }) {
  const cliDir = join(UPSTREAM, 'packages', 'cli')
  const tools = join(DIST, 'tools')
  const outDir = join(tools, 'cli')
  const outfile = join(outDir, 'soffice.cjs')
  mkdirSync(outDir, { recursive: true })
  const { version } = JSON.parse(readFileSync(join(cliDir, 'package.json'), 'utf8'))

  // same esbuild the upstream CLI build uses
  const esbuild = await import(pathToFileURL(join(UPSTREAM_MODULES, 'esbuild', 'lib', 'main.js')).href)
  const rawText = {
    name: 'raw-text',
    setup(b) {
      b.onResolve({ filter: /\?raw$/ }, (args) => ({
        path: resolve(args.resolveDir, args.path.replace(/\?raw$/, '')),
        namespace: 'raw-text',
      }))
      b.onLoad({ filter: /.*/, namespace: 'raw-text' }, async (args) => ({
        contents: await readFile(args.path, 'utf8'),
        loader: 'text',
      }))
    },
  }
  log(`soffice CLI ${version} → ${outfile}`)
  await (esbuild.build ?? esbuild.default.build)({
    entryPoints: [join(cliDir, 'src', 'cli.ts')],
    outfile,
    bundle: true,
    platform: 'node',
    target: 'node22',
    format: 'cjs',
    logLevel: 'warning',
    absWorkingDir: cliDir,
    define: {
      'import.meta.url': '__cliImportMetaUrl',
      __SOFFICE_VERSION__: JSON.stringify(version),
    },
    banner: {
      js: [
        "const __cliImportMetaUrl = require('node:url').pathToFileURL(__filename).href;",
        `const __cliAppVersion = ${JSON.stringify(version)};`,
      ].join('\n'),
    },
    jsx: 'automatic',
    external: ['electron', 'jsdom', 'mermaid'],
    loader: {
      '.css': 'empty',
      '.ttf': 'empty',
      '.woff': 'empty',
      '.woff2': 'empty',
      '.svg': 'empty',
      '.png': 'empty',
    },
    plugins: [rawText],
  })

  // jsdom and its dependency closure, keeping the node_modules layout
  copyExternals(['jsdom'], UPSTREAM, UPSTREAM_MODULES, join(outDir, 'node_modules'), log)

  // pdfium.wasm: its presence marks dist/tools as the "packaged resources" dir
  const wasm = resolvePackageFile(UPSTREAM_MODULES, '@embedpdf/pdfium', 'dist/pdfium.wasm')
  mkdirSync(join(tools, 'wasm'), { recursive: true })
  cpSync(wasm, join(tools, 'wasm', 'pdfium.wasm'))

  // the xlsx sidecar (dist/tools/xlsx-sidecar) comes from `npm run setup`; the server passes
  // its path to the CLI through XLSX_SIDECAR_PATH
  log(`tools ready in ${tools}`)
}

function resolvePackageFile(modules, pkg, file) {
  const path = join(modules, ...pkg.split('/'), file)
  if (!existsSync(path)) throw new Error(`build-tools: ${pkg}/${file} not found under ${modules}`)
  return path
}

function copyExternals(names, from, rootModules, out, log) {
  const resolvePkg = (name, start) => {
    let dir = start
    for (;;) {
      const candidate = join(dir, 'node_modules', name)
      if (existsSync(join(candidate, 'package.json'))) return candidate
      const parent = dirname(dir)
      if (parent === dir) return null
      dir = parent
    }
  }
  const seen = new Set()
  const walk = (name, start) => {
    const dir = resolvePkg(name, start)
    if (!dir) throw new Error(`build-tools: cannot resolve ${name} from ${start}`)
    if (seen.has(dir)) return
    seen.add(dir)
    const pkg = JSON.parse(readFileSync(join(dir, 'package.json'), 'utf8'))
    for (const dep of Object.keys(pkg.dependencies ?? {})) walk(dep, dir)
    for (const dep of Object.keys(pkg.optionalDependencies ?? {})) {
      if (resolvePkg(dep, dir)) walk(dep, dir)
    }
  }
  for (const name of names) walk(name, from)
  rmSync(out, { recursive: true, force: true })
  mkdirSync(out, { recursive: true })
  for (const dir of seen) {
    const rel = relative(rootModules, dir)
    if (rel.startsWith('..')) throw new Error(`build-tools: ${dir} is outside ${rootModules}`)
    cpSync(dir, join(out, rel), {
      recursive: true,
      dereference: true,
      filter: (src) => !relative(dir, src).split(sep).includes('node_modules'),
    })
  }
  log(`CLI runtime deps: ${seen.size} packages`)
}
