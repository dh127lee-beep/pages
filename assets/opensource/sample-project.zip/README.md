# Sample Project

This is a sample open source project.

## Usage

```bash
echo "Hello, World!"
```
