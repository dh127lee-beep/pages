(function () {
  const data = window.SKILL_PAGE_DATA;

  function byId(id) {
    return document.getElementById(id);
  }

  function escapeHtml(value) {
    return String(value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function renderBadges(items) {
    return items
      .map(
        (item) =>
          `<span class="badge ${escapeHtml(item.className)}">${escapeHtml(item.label)}</span>`
      )
      .join("");
  }

  function renderList(items) {
    return `<ul>${items.map((item) => `<li>${escapeHtml(item)}</li>`).join("")}</ul>`;
  }

  function renderDocsCards(cards) {
    return cards
      .map(
        (card) => `
          <a class="slide-card" href="${escapeHtml(card.href)}">
            <h3>${escapeHtml(card.index)}. ${escapeHtml(card.title)}</h3>
            <p>${escapeHtml(card.copy)}</p>
          </a>
        `
      )
      .join("");
  }

  function buildSlides() {
    return [
      {
        kicker: "Overview",
        title: "Browser Agent Skill System",
        copy:
          "WebSkill과 GeneralSkill을 함께 다루는 구조, 그리고 개인 편집에서 퍼블리시와 사용까지 이어지는 제품 흐름을 슬라이드 형태로 요약한 뷰입니다.",
        body: `
          <div class="slide-grid-3">
            ${data.heroStats
              .map(
                (item) => `
                  <div class="slide-metric">
                    <strong>${escapeHtml(item.value)}</strong>
                    <span>${escapeHtml(item.label)}</span>
                  </div>
                `
              )
              .join("")}
          </div>
          <div class="slide-grid-3">
            ${data.heroCards
              .map(
                (card) => `
                  <article class="slide-card">
                    <h3>${escapeHtml(card.title)}</h3>
                    <p>${escapeHtml(card.copy)}</p>
                    <div class="badge-row">${renderBadges(card.badges)}</div>
                  </article>
                `
              )
              .join("")}
          </div>
        `
      },
      {
        kicker: "Classification",
        title: "Kind and Tier",
        copy:
          "사용자에게는 스킬 종류와 배포 단계를 동시에 이해시키고, 내부적으로는 kind와 distribution tier를 분리해 관리합니다.",
        body: `
          <div class="slide-grid-2">
            ${data.skillKinds
              .map(
                (card) => `
                  <article class="slide-card">
                    <h3>${escapeHtml(card.title)}</h3>
                    <p>${escapeHtml(card.copy)}</p>
                    ${renderList(card.points)}
                  </article>
                `
              )
              .join("")}
          </div>
          <div class="table-wrap">
            <table class="layer-table">
              <thead>
                <tr>
                  <th>Layer</th>
                  <th>Description</th>
                  <th>Exposure</th>
                  <th>Toggle</th>
                  <th>Edit</th>
                </tr>
              </thead>
              <tbody>
                ${data.skillLayerTable
                  .map(
                    (row) => `
                      <tr>
                        <td><strong>${escapeHtml(row.layer)}</strong></td>
                        <td>${escapeHtml(row.description)}</td>
                        <td>${escapeHtml(row.exposure)}</td>
                        <td>${escapeHtml(row.toggle)}</td>
                        <td>${escapeHtml(row.edit)}</td>
                      </tr>
                    `
                  )
                  .join("")}
              </tbody>
            </table>
          </div>
          <div class="slide-grid-4">
            ${data.overviewTypes
              .map(
                (card) => `
                  <article class="slide-card">
                    <h3>${escapeHtml(card.title)}</h3>
                    <p>${escapeHtml(card.copy)}</p>
                  </article>
                `
              )
              .join("")}
          </div>
        `
      },
      {
        kicker: "Model",
        title: "Kind-Aware Runtime Model",
        copy:
          "공통 스킬 코어 위에 WebSkill 계약과 GeneralSkill 계약을 얹고, runtime에서는 먼저 kind를 라우팅합니다.",
        body: `
          <div class="slide-grid-3">
            ${data.modelPanels
              .map(
                (panel) => `
                  <article class="slide-card">
                    <h3>${escapeHtml(panel.title)}</h3>
                    ${renderList(panel.items)}
                  </article>
                `
              )
              .join("")}
          </div>
          <div class="slide-grid-4">
            ${data.overviewAxes
              .map(
                (axis) => `
                  <article class="slide-card">
                    <h3>${escapeHtml(axis.title)}</h3>
                    <p>${escapeHtml(axis.copy)}</p>
                    <code>${escapeHtml(axis.code)}</code>
                  </article>
                `
              )
              .join("")}
          </div>
        `
      },
      {
        kicker: "Creation",
        title: "Four Creation Entries",
        copy:
          "생성 방식은 네 가지지만, 모두 Draft Skill로 들어와 테스트를 거쳐 kind-aware private skill로 저장되는 동일한 파이프라인으로 수렴합니다.",
        body: `
          <div class="slide-grid-2">
            ${data.creationMethods
              .map(
                (method) => `
                  <article class="slide-card">
                    <h3>${escapeHtml(method.title)}</h3>
                    <p>${escapeHtml(method.copy)}</p>
                    <div class="badge-row">${renderBadges(method.badges)}</div>
                    ${renderList(method.points)}
                  </article>
                `
              )
              .join("")}
          </div>
        `
      },
      {
        kicker: "Marketplace",
        title: "Unified Skill Marketplace",
        copy:
          "Marketplace는 WebSkill과 GeneralSkill을 모두 포괄하는 배포 레이어입니다. 탐색은 kind filter로, 설치는 kind별 설정으로 분기됩니다.",
        body: `
          <div class="slide-grid-4">
            ${data.marketCards
              .map(
                (card) => `
                  <article class="slide-card">
                    <h3>${escapeHtml(card.title)}</h3>
                    <p>${escapeHtml(card.copy)}</p>
                    ${renderList(card.points)}
                  </article>
                `
              )
              .join("")}
          </div>
          <div class="slide-grid-3">
            ${data.riskRows
              .map(
                (row) => `
                  <article class="slide-card">
                    <h3>${escapeHtml(row.label)}</h3>
                    <div class="badge-row">
                      <span class="badge ${escapeHtml(row.badgeClass)}">${escapeHtml(row.badge)}</span>
                    </div>
                  </article>
                `
              )
              .join("")}
          </div>
        `
      },
      {
        kicker: "Lifecycle",
        title: "Personal Edit to Publish to Use",
        copy:
          "실제 핵심 루프는 개인 편집에서 시작해 테스트, 퍼블리시, 설치, 사용, 로그 기반 재편집으로 이어지는 end-to-end lifecycle입니다.",
        body: `
          <div class="slide-grid-3">
            ${data.lifecycleStages
              .map(
                (card) => `
                  <article class="slide-card">
                    <h3>${escapeHtml(card.title)}</h3>
                    <p>${escapeHtml(card.copy)}</p>
                    ${renderList(card.points)}
                  </article>
                `
              )
              .join("")}
          </div>
        `
      },
      {
        kicker: "Screens",
        title: "Screen Direction",
        copy:
          "공개 홈, 퍼블리시 위저드, 개인 편집기는 그대로 유지하고, 슬라이드 뷰에서는 각 화면의 역할만 빠르게 비교할 수 있게 구성합니다.",
        body: `
          <div class="slide-grid-3">
            ${data.galleryCards
              .map(
                (card) => `
                  <article class="slide-card">
                    <div class="badge-row">
                      <span class="badge ${escapeHtml(card.badgeClass)}">${escapeHtml(card.badge)}</span>
                    </div>
                    <h3 style="margin-top:12px">${escapeHtml(card.title)}</h3>
                    <div class="slide-visual" style="margin-top:14px">
                      <img src="${escapeHtml(card.img)}" alt="${escapeHtml(card.alt)}" />
                    </div>
                    <p style="margin-top:14px">${escapeHtml(card.copy)}</p>
                  </article>
                `
              )
              .join("")}
          </div>
        `
      },
      {
        kicker: "Docs",
        title: "Detailed Planning Documents",
        copy:
          "슬라이드 뷰는 빠른 설명용이고, 실제 정책과 화면 단위 설계는 분리된 문서에서 이어서 읽는 구조입니다. 특히 lifecycle 문서가 개인 편집에서 사용까지의 상세 설계를 담고 있습니다.",
        body: `
          <div class="slide-grid-3">
            ${renderDocsCards(data.docsCards)}
          </div>
        `
      }
    ];
  }

  function renderSlides(slides) {
    byId("deck-track").innerHTML = slides
      .map(
        (slide, index) => `
          <section class="presentation-slide" data-slide-index="${index}">
            <div class="slide-inner">
              <span class="slide-kicker">${escapeHtml(slide.kicker)}</span>
              <h1 class="slide-title">${escapeHtml(slide.title)}</h1>
              <p class="slide-copy">${escapeHtml(slide.copy)}</p>
              ${slide.body}
            </div>
          </section>
        `
      )
      .join("");
  }

  function renderDots(slides) {
    byId("deck-dots").innerHTML = slides
      .map(
        (slide, index) => `
          <button class="deck-dot${index === 0 ? " is-active" : ""}" type="button" data-slide-dot="${index}">
            ${escapeHtml(slide.kicker)}
          </button>
        `
      )
      .join("");
  }

  function initDeck(slides) {
    const track = byId("deck-track");
    const shell = document.querySelector(".deck-shell");
    const counter = byId("deck-counter");
    const prev = byId("prev-slide");
    const next = byId("next-slide");
    const dots = () => Array.from(document.querySelectorAll("[data-slide-dot]"));
    let current = 0;

    function update() {
      track.style.transform = `translateX(-${current * 100}%)`;
      if (shell) shell.scrollTop = 0;
      counter.textContent = `${current + 1} / ${slides.length}`;
      prev.disabled = current === 0;
      next.disabled = current === slides.length - 1;
      dots().forEach((dot, index) => {
        dot.classList.toggle("is-active", index === current);
      });
    }

    function goTo(index) {
      current = Math.max(0, Math.min(slides.length - 1, index));
      update();
    }

    prev.addEventListener("click", () => goTo(current - 1));
    next.addEventListener("click", () => goTo(current + 1));
    dots().forEach((dot) => {
      dot.addEventListener("click", () => goTo(Number(dot.dataset.slideDot)));
    });

    window.addEventListener("keydown", (event) => {
      if (event.key === "ArrowRight" || event.key === "PageDown" || event.key === " ") {
        event.preventDefault();
        goTo(current + 1);
      } else if (event.key === "ArrowLeft" || event.key === "PageUp") {
        event.preventDefault();
        goTo(current - 1);
      } else if (event.key === "Home") {
        event.preventDefault();
        goTo(0);
      } else if (event.key === "End") {
        event.preventDefault();
        goTo(slides.length - 1);
      }
    });

    update();
  }

  function init() {
    const slides = buildSlides();
    renderSlides(slides);
    renderDots(slides);
    initDeck(slides);
  }

  document.addEventListener("DOMContentLoaded", init);
})();
