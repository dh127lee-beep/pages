(function () {
  const data = window.SKILL_PAGE_DATA;

  function byId(id) {
    return document.getElementById(id);
  }

  function escapeHtml(value) {
    return String(value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function renderBadges(badges) {
    return badges
      .map(
        (badge) =>
          `<span class="badge ${escapeHtml(badge.className)}">${escapeHtml(badge.label)}</span>`
      )
      .join("");
  }

  function renderListItems(items) {
    return items.map((item) => `<li>${escapeHtml(item)}</li>`).join("");
  }

  function renderPipes(steps) {
    return steps.map((step) => `<div class="pipe">${escapeHtml(step)}</div>`).join("");
  }

  function renderNav() {
    byId("topnav").innerHTML = data.nav
      .map((item) => `<a href="${escapeHtml(item.href)}">${escapeHtml(item.label)}</a>`)
      .join("");
  }

  function renderHeroStats() {
    byId("hero-stats").innerHTML = data.heroStats
      .map(
        (item) => `
          <div class="hero-stat">
            <strong>${escapeHtml(item.value)}</strong>
            <span>${escapeHtml(item.label)}</span>
          </div>
        `
      )
      .join("");
  }

  function renderHeroCards() {
    byId("hero-cards").innerHTML = data.heroCards
      .map(
        (card) => `
          <article class="float-card ${escapeHtml(card.className)}">
            <h3>${escapeHtml(card.title)}</h3>
            <p>${escapeHtml(card.copy)}</p>
            <div class="badge-row">${renderBadges(card.badges)}</div>
          </article>
        `
      )
      .join("");
  }

  function renderOverviewTypes() {
    byId("overview-types").innerHTML = data.overviewTypes
      .map(
        (card) => `
          <article class="type-card">
            <h3>${escapeHtml(card.title)}</h3>
            <p>${escapeHtml(card.copy)}</p>
            <ul>${renderListItems(card.points)}</ul>
          </article>
        `
      )
      .join("");
  }

  function renderSkillKinds() {
    byId("skill-kinds").innerHTML = data.skillKinds
      .map(
        (card) => `
          <article class="settings-card">
            <h3>${escapeHtml(card.title)}</h3>
            <p>${escapeHtml(card.copy)}</p>
            <ul>${renderListItems(card.points)}</ul>
          </article>
        `
      )
      .join("");
  }

  function renderSkillLayerTable() {
    byId("skill-layer-table").innerHTML = `
      <div class="table-wrap">
        <table class="layer-table">
          <thead>
            <tr>
              <th>Layer</th>
              <th>Description</th>
              <th>Exposure</th>
              <th>Toggle</th>
              <th>Edit</th>
            </tr>
          </thead>
          <tbody>
            ${data.skillLayerTable
              .map(
                (row) => `
                  <tr>
                    <td><strong>${escapeHtml(row.layer)}</strong></td>
                    <td>${escapeHtml(row.description)}</td>
                    <td>${escapeHtml(row.exposure)}</td>
                    <td>${escapeHtml(row.toggle)}</td>
                    <td>${escapeHtml(row.edit)}</td>
                  </tr>
                `
              )
              .join("")}
          </tbody>
        </table>
      </div>
    `;
  }

  function renderOverviewAxes() {
    byId("overview-axes").innerHTML = data.overviewAxes
      .map(
        (axis) => `
          <div class="axis">
            <h3>${escapeHtml(axis.title)}</h3>
            <p>${escapeHtml(axis.copy)}</p>
            <code>${escapeHtml(axis.code)}</code>
          </div>
        `
      )
      .join("");
  }

  function renderModelPanels() {
    byId("model-panels").innerHTML = data.modelPanels
      .map(
        (panel) => `
          <article class="panel">
            <h3>${escapeHtml(panel.title)}</h3>
            <ul>${renderListItems(panel.items)}</ul>
          </article>
        `
      )
      .join("");
  }

  function renderMethodButtons() {
    byId("method-buttons").innerHTML = data.creationMethods
      .map(
        (method, index) => `
          <button
            class="method-button${index === 0 ? " is-active" : ""}"
            type="button"
            data-method="${escapeHtml(method.key)}"
            role="tab"
            aria-selected="${index === 0 ? "true" : "false"}"
          >
            <strong>${escapeHtml(method.buttonTitle)}</strong>
            <span>${escapeHtml(method.buttonCopy)}</span>
          </button>
        `
      )
      .join("");
  }

  function renderMethodDetail(key) {
    const method = data.creationMethods.find((item) => item.key === key) || data.creationMethods[0];
    byId("method-title").textContent = method.title;
    byId("method-copy").textContent = method.copy;
    byId("method-pipeline").innerHTML = renderPipes(method.pipeline);
    byId("method-badges").innerHTML = renderBadges(method.badges);
    byId("method-points").innerHTML = renderListItems(method.points);
  }

  function bindMethodButtons() {
    const buttons = document.querySelectorAll(".method-button");
    buttons.forEach((button) => {
      button.addEventListener("click", () => {
        buttons.forEach((item) => {
          item.classList.remove("is-active");
          item.setAttribute("aria-selected", "false");
        });
        button.classList.add("is-active");
        button.setAttribute("aria-selected", "true");
        renderMethodDetail(button.dataset.method);
      });
    });
  }

  function renderRuntimePipeline() {
    byId("runtime-pipeline").innerHTML = renderPipes(data.runtimePipeline);
  }

  function renderRuntimeGuardrails() {
    byId("runtime-guardrails").innerHTML = renderListItems(data.runtimeGuardrails);
    byId("risk-rows").innerHTML = data.riskRows
      .map(
        (row) => `
          <div class="risk-row">
            <span>${escapeHtml(row.label)}</span>
            <span class="badge ${escapeHtml(row.badgeClass)}">${escapeHtml(row.badge)}</span>
          </div>
        `
      )
      .join("");
  }

  function renderMarketCards() {
    byId("market-cards").innerHTML = data.marketCards
      .map(
        (card) => `
          <article class="settings-card">
            <h3>${escapeHtml(card.title)}</h3>
            <p>${escapeHtml(card.copy)}</p>
            <ul>${renderListItems(card.points)}</ul>
          </article>
        `
      )
      .join("");
  }

  function renderLifecycleStages() {
    byId("lifecycle-stages").innerHTML = data.lifecycleStages
      .map(
        (card) => `
          <article class="settings-card">
            <h3>${escapeHtml(card.title)}</h3>
            <p>${escapeHtml(card.copy)}</p>
            <ul>${renderListItems(card.points)}</ul>
          </article>
        `
      )
      .join("");
  }

  function renderGallery() {
    byId("screen-gallery").innerHTML = data.galleryCards
      .map(
        (card) => `
          <article class="gallery-card">
            <div class="meta">
              <h3>${escapeHtml(card.title)}</h3>
              <span class="badge ${escapeHtml(card.badgeClass)}">${escapeHtml(card.badge)}</span>
            </div>
            <img src="${escapeHtml(card.img)}" alt="${escapeHtml(card.alt)}" />
            <p>${escapeHtml(card.copy)}</p>
          </article>
        `
      )
      .join("");
  }

  function renderDocs() {
    byId("docs-cards").innerHTML = data.docsCards
      .map(
        (card) => `
          <a class="doc-card" href="${escapeHtml(card.href)}">
            <span class="doc-index">${escapeHtml(card.index)}</span>
            <h3>${escapeHtml(card.title)}</h3>
            <p>${escapeHtml(card.copy)}</p>
          </a>
        `
      )
      .join("");
  }

  function init() {
    renderNav();
    renderHeroStats();
    renderHeroCards();
    renderSkillKinds();
    renderSkillLayerTable();
    renderOverviewTypes();
    renderOverviewAxes();
    renderModelPanels();
    renderMethodButtons();
    renderMethodDetail(data.creationMethods[0].key);
    bindMethodButtons();
    renderRuntimePipeline();
    renderRuntimeGuardrails();
    renderMarketCards();
    renderLifecycleStages();
    renderGallery();
    renderDocs();
  }

  document.addEventListener("DOMContentLoaded", init);
})();
