window.SKILL_PAGE_DATA = {
  nav: [
    { href: "#overview", label: "Overview" },
    { href: "#model", label: "Model" },
    { href: "#creation", label: "Creation" },
    { href: "#runtime", label: "Runtime" },
    { href: "#marketplace", label: "Marketplace" },
    { href: "#lifecycle", label: "Lifecycle" },
    { href: "#screens", label: "Screens" },
    { href: "#docs", label: "Docs" }
  ],
  heroStats: [
    { value: "2 kinds", label: "WebSkill and GeneralSkill" },
    { value: "4 tiers", label: "Base, Built-In, Public, Private" },
    { value: "1 market", label: "Unified marketplace for both kinds" }
  ],
  heroCards: [
    {
      className: "card-a",
      title: "WebSkill",
      copy: "사이트, 탭, DOM, selector, browser capability에 직접 연결되는 브라우저 자동화 스킬입니다.",
      badges: [
        { label: "SITE-SCOPED", className: "badge-blue" },
        { label: "DOM ACTIONS", className: "badge-amber" }
      ]
    },
    {
      className: "card-b",
      title: "GeneralSkill",
      copy: "특정 사이트에 묶이지 않고, 요약, 분류, 템플릿 실행 같은 범용 워크플로우를 담당합니다.",
      badges: [
        { label: "REUSABLE", className: "badge-lime" },
        { label: "NOT SITE-BOUND", className: "badge-blue" }
      ]
    },
    {
      className: "card-c",
      title: "Unified Marketplace",
      copy: "Marketplace는 WebSkill과 GeneralSkill을 모두 포괄하고, kind 필터로 탐색하게 설계합니다.",
      badges: [
        { label: "ALL SKILLS", className: "badge-red" },
        { label: "FILTER BY KIND", className: "badge-blue" }
      ]
    }
  ],
  skillKinds: [
    {
      title: "WebSkill",
      copy: "브라우저 사이트, 탭, DOM, selector, 클릭, 입력, 추출 같은 page action에 직접 연결되는 스킬입니다.",
      points: [
        "site scope 필요",
        "browser capability 필요",
        "step canvas와 selector picker 필요"
      ]
    },
    {
      title: "GeneralSkill",
      copy: "특정 사이트에 종속되지 않고, 요약, 분류, 템플릿 적용, 범용 로직 실행을 담당하는 스킬입니다.",
      points: [
        "input/output schema 중심",
        "selected text, clipboard, post-run hook에 연결 가능",
        "범용 워크플로우 재사용에 적합"
      ]
    }
  ],
  skillLayerTable: [
    {
      layer: "Base Skill",
      description: "동작이나 Agent Loop를 효과적으로 관리하기 위한 내부 스킬",
      exposure: "비공개",
      toggle: "불가능",
      edit: "불가능"
    },
    {
      layer: "Built-In Skill",
      description: "Domain 단위 스킬로 개발팀에서 제공하는 스킬",
      exposure: "공개",
      toggle: "가능",
      edit: "불가능"
    },
    {
      layer: "Public Skill",
      description: "Marketplace에서 제공하는 스킬, 인증 단계를 거쳐 공개되는 스킬",
      exposure: "공개",
      toggle: "가능",
      edit: "불가능"
    },
    {
      layer: "Private Skill",
      description: "사용자가 직접 제작한 스킬",
      exposure: "공개",
      toggle: "가능",
      edit: "가능"
    }
  ],
  overviewTypes: [
    {
      title: "Base",
      copy: "항상 탑재되는 필수 스킬입니다. WebSkill과 GeneralSkill 모두 Base 형태로 제공될 수 있습니다.",
      points: ["필수 안전 장치", "핵심 시스템 동작", "앱 버전과 함께 업데이트"]
    },
    {
      title: "Built-In",
      copy: "내장 제공되지만 사용자가 켜고 끌 수 있는 기본 스킬입니다.",
      points: ["on/off 가능", "직접 수정은 불가", "앱 릴리즈와 함께 관리"]
    },
    {
      title: "Public",
      copy: "Marketplace에서 설치하는 공유 스킬입니다. WebSkill과 GeneralSkill을 모두 포함합니다.",
      points: ["버전 고정 설치 권장", "업데이트 알림 기반", "검수와 신뢰 배지 필요"]
    },
    {
      title: "Private",
      copy: "사용자 개인 스킬입니다. 개인 편집, 테스트, 저장, 퍼블리시 진입점이 여기서 시작됩니다.",
      points: ["직접 수정 가능", "개인 라이브러리 중심", "향후 팀 공유로 확장 가능"]
    }
  ],
  overviewAxes: [
    {
      title: "Kind",
      copy: "무엇을 실행하는 스킬인가를 정의합니다.",
      code: "web | general"
    },
    {
      title: "Source",
      copy: "누가 배포하는가를 정의합니다.",
      code: "system | marketplace | personal"
    },
    {
      title: "Visibility",
      copy: "누가 볼 수 있는가를 정의합니다.",
      code: "internal | public | private"
    },
    {
      title: "Manageability",
      copy: "사용자가 무엇을 바꿀 수 있는가를 정의합니다.",
      code: "immutable | toggleable | editable | forkable"
    }
  ],
  modelPanels: [
    {
      title: "Package Core",
      items: [
        "Kind",
        "Manifest",
        "Instruction",
        "Trigger",
        "Parameter Schema",
        "Execution Plan",
        "Permission Scope",
        "Optional JS Module",
        "Test Cases",
        "Version Metadata"
      ]
    },
    {
      title: "WebSkill Contract",
      items: [
        "Site scope",
        "Selector and step actions",
        "Browser capability permissions",
        "Current tab side-by-side test",
        "Approval gate for risky actions"
      ]
    },
    {
      title: "GeneralSkill Contract",
      items: [
        "Input schema",
        "Output schema",
        "Invocation contexts",
        "Reusable prompt blocks",
        "Structured sample input test"
      ]
    }
  ],
  creationMethods: [
    {
      key: "demo",
      buttonTitle: "Human Demonstration",
      buttonCopy: "실제 브라우저 행동을 녹화하고 WebSkill 또는 GeneralSkill로 일반화",
      title: "Human Demonstration",
      copy: "사용자의 실제 브라우저 액션을 기록하고, Agent가 이를 WebSkill 또는 GeneralSkill로 일반화합니다.",
      pipeline: ["Record actions", "Infer intent", "Choose kind", "Test and save"],
      badges: [
        { label: "BEST FOR UI TASKS", className: "badge-lime" },
        { label: "MASK SENSITIVE DATA", className: "badge-amber" }
      ],
      points: [
        "민감 필드 자동 마스킹이 필수입니다.",
        "우연히 들어간 클릭을 제거할 수 있어야 합니다.",
        "WebSkill로 남길지 GeneralSkill로 추상화할지 제안해야 합니다."
      ]
    },
    {
      key: "manual",
      buttonTitle: "Manual Translation",
      buttonCopy: "문서와 SOP를 kind-aware draft로 번역",
      title: "Manual Translation",
      copy: "문서, SOP, PDF, URL 기반 절차를 브라우저 액션과 범용 로직으로 나눠 kind-aware draft를 만듭니다.",
      pipeline: ["Parse manual", "Map to actions", "Split by kind", "Validate draft"],
      badges: [
        { label: "GOOD FOR SOP", className: "badge-blue" },
        { label: "BACKOFFICE FRIENDLY", className: "badge-lime" }
      ],
      points: [
        "사내 운영 문서나 CS 플레이북에 적합합니다.",
        "브라우저 종속 부분과 범용 로직을 분리하기 좋습니다.",
        "문서 업데이트 시 재번역 워크플로우를 붙이기 쉽습니다."
      ]
    },
    {
      key: "nl",
      buttonTitle: "Natural Language",
      buttonCopy: "자연어 목표를 구조화해 kind를 제안하고 초안 생성",
      title: "Natural Language",
      copy: "사용자의 목표를 자연어로 입력받아, 사이트와 입력값, 성공 조건을 구조화하고 적절한 kind를 제안합니다.",
      pipeline: ["Parse goal", "Infer kind", "Draft skill", "Test on sample"],
      badges: [
        { label: "LOWEST BARRIER", className: "badge-lime" },
        { label: "FAST FIRST SKILL", className: "badge-blue" }
      ],
      points: [
        "초기 진입 장벽이 가장 낮습니다.",
        "사이트와 성공 조건이 불명확하면 최소 질문이 필요합니다.",
        "첫 버전 생성 후 Visual Editor에서 다듬는 흐름이 좋습니다."
      ]
    },
    {
      key: "after",
      buttonTitle: "Save After Execution",
      buttonCopy: "성공한 실행 로그를 kind-aware private skill로 저장",
      title: "Save After Execution",
      copy: "성공한 일회성 실행 로그를 재사용 가능한 패턴으로 일반화해 Private WebSkill 또는 GeneralSkill로 저장합니다.",
      pipeline: ["Run once", "Capture trace", "Choose kind", "Save private"],
      badges: [
        { label: "STRONGEST ENTRY", className: "badge-red" },
        { label: "HIGH QUALITY SOURCE", className: "badge-lime" }
      ],
      points: [
        "사용자가 처음부터 설계할 필요가 없습니다.",
        "실제 성공 로그 기반이라 정확도와 신뢰도가 높습니다.",
        "개인 자동화 라이브러리를 가장 자연스럽게 쌓을 수 있습니다."
      ]
    }
  ],
  runtimePipeline: [
    "Intent parse",
    "Kind routing",
    "Skill search",
    "Permission match",
    "Plan generation",
    "Execution",
    "Result log",
    "Save suggestion"
  ],
  runtimeGuardrails: [
    "sandboxed runtime",
    "SDK capability only",
    "allowlist network",
    "CPU, memory, timeout 제한",
    "권한 증가 시 재승인"
  ],
  riskRows: [
    { label: "GeneralSkill summary or classification", badge: "LOW", badgeClass: "badge-lime" },
    {
      label: "WebSkill input, download, external network",
      badge: "MEDIUM",
      badgeClass: "badge-amber"
    },
    {
      label: "Payment flow, upload, mass action, high-trust sites",
      badge: "HIGH",
      badgeClass: "badge-red"
    }
  ],
  marketCards: [
    {
      title: "Unified Discovery",
      copy: "Marketplace는 WebSkill과 GeneralSkill을 모두 보여주되, kind filter와 badge로 빠르게 구분하게 해야 합니다.",
      points: ["All / WebSkills / GeneralSkills", "kind badge on card", "kind-specific filters"]
    },
    {
      title: "Publish",
      copy: "Private Skill에서 Public으로 승격할 때는 kind를 먼저 확정하고, kind에 맞는 metadata와 validation을 요구해야 합니다.",
      points: ["kind selection", "risk explanation", "review and approval"]
    },
    {
      title: "Install",
      copy: "설치 모달은 kind에 따라 다른 설정을 요구해야 합니다. WebSkill은 site scope, GeneralSkill은 invocation context가 중심입니다.",
      points: ["site or context config", "pinned or auto-update", "activate now or later"]
    },
    {
      title: "Settings",
      copy: "Global, Site, Skill 세 층으로 나누고, WebSkill과 GeneralSkill에 맞는 노출 위치를 조정할 수 있어야 합니다.",
      points: ["Global defaults", "Site defaults", "Skill priority and logs"]
    }
  ],
  lifecycleStages: [
    {
      title: "1. My Skills",
      copy: "개인 라이브러리에서 kind, 상태, 최근 실행률 기준으로 필터링하고 편집 또는 퍼블리시 진입점을 제공합니다.",
      points: ["kind filter", "Draft / Saved / Published", "Edit / Test / Publish / Run"]
    },
    {
      title: "2. Personal Edit",
      copy: "편집기에서는 kind를 명시하고, WebSkill은 step canvas, GeneralSkill은 IO schema 중심으로 수정합니다.",
      points: ["kind switch", "step or schema editor", "inspector and diff"]
    },
    {
      title: "3. Test and Save",
      copy: "샘플 입력 또는 현재 탭에서 테스트하고, 검증을 통과한 뒤 Private Skill로 저장합니다.",
      points: ["test trace", "validation errors", "save as private"]
    },
    {
      title: "4. Publish Wizard",
      copy: "kind, behavior, permissions, assets, validation, listing preview를 순차적으로 확인하고 리뷰에 제출합니다.",
      points: ["kind and overview", "permissions reason", "submit for review"]
    },
    {
      title: "5. Install and Configure",
      copy: "Marketplace 상세에서 kind를 확인하고 설치한 뒤, WebSkill은 site scope, GeneralSkill은 invocation context를 설정합니다.",
      points: ["install modal", "config after install", "sample run"]
    },
    {
      title: "6. Run and Iterate",
      copy: "popup, overlay, result sheet, logs를 통해 사용하고, 이후 다시 편집하거나 fork, update, republish 루프로 돌아갑니다.",
      points: ["popup entry", "run overlay", "logs and edit again"]
    }
  ],
  galleryCards: [
    {
      title: "Marketplace Home",
      badge: "ALL KINDS",
      badgeClass: "badge-blue",
      img: "../docs/assets/marketplace-home.svg",
      alt: "Marketplace Home UI sample",
      copy: "kind filter와 trust badge가 함께 보여지는 공개용 홈 화면입니다."
    },
    {
      title: "Publish Wizard",
      badge: "PUBLISH",
      badgeClass: "badge-amber",
      img: "../docs/assets/publish-wizard.svg",
      alt: "Publish Wizard UI sample",
      copy: "kind 확정과 권한 설명이 중심이 되는 업로드용 멀티 스텝 위저드입니다."
    },
    {
      title: "Skill Editor",
      badge: "PRIVATE",
      badgeClass: "badge-lime",
      img: "../docs/assets/skill-editor.svg",
      alt: "Skill Editor UI sample",
      copy: "WebSkill과 GeneralSkill을 모두 개인 편집 단계에서 다룰 수 있는 편집기입니다."
    }
  ],
  docsCards: [
    {
      index: "01",
      title: "Overview & Principles",
      href: "../docs/01-overview-and-principles.md",
      copy: "WebSkill / GeneralSkill 분류와 배포 tier, 제품 원칙을 정리합니다."
    },
    {
      index: "02",
      title: "Skill Model & Runtime",
      href: "../docs/02-skill-model-and-runtime.md",
      copy: "kind-aware manifest, runtime routing, permission model을 다룹니다."
    },
    {
      index: "03",
      title: "Creation & Editing",
      href: "../docs/03-skill-creation-and-editing.md",
      copy: "생성 시 kind 판단과 개인 편집 흐름을 설명합니다."
    },
    {
      index: "04",
      title: "Marketplace & Settings",
      href: "../docs/04-marketplace-publishing-and-settings.md",
      copy: "Marketplace가 두 종류를 포괄하는 방식과 설치/설정 정책을 다룹니다."
    },
    {
      index: "05",
      title: "UI, UX & Screens",
      href: "../docs/05-ui-ux-and-screens.md",
      copy: "주요 화면 구조와 screen-level 목적을 정리합니다."
    },
    {
      index: "06",
      title: "Detailed UI Flow",
      href: "../docs/06-detailed-ui-flow-personal-edit-publish-use.md",
      copy: "개인 편집에서 퍼블리시, 설치, 사용까지 상세 UI 플로우를 다룹니다."
    }
  ]
};
