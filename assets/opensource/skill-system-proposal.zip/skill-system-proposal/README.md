# Browser Agent Skill System Proposal

Browser Agent용 스킬 시스템 기획 문서를 주요 주제별로 분리했습니다.

## Documents

- [01. Overview and Principles](./docs/01-overview-and-principles.md)
- [02. Skill Model and Runtime](./docs/02-skill-model-and-runtime.md)
- [03. Skill Creation and Editing](./docs/03-skill-creation-and-editing.md)
- [04. Marketplace, Publishing, and Settings](./docs/04-marketplace-publishing-and-settings.md)
- [05. UI, UX, and Screens](./docs/05-ui-ux-and-screens.md)
- [06. Detailed UI Flow: Personal Edit to Publish to Use](./docs/06-detailed-ui-flow-personal-edit-publish-use.md)

## Recommended Reading Order

1. Overview and Principles
2. Skill Model and Runtime
3. Skill Creation and Editing
4. Marketplace, Publishing, and Settings
5. UI, UX, and Screens
6. Detailed UI Flow: Personal Edit to Publish to Use

## UI Samples

### HTML Preview

- [Open HTML mockup](./html/index.html)
- [Open presentation view](./html/presentation.html)

### Marketplace Home

![Marketplace Home](./docs/assets/marketplace-home.svg)

### Publish Wizard

![Publish Wizard](./docs/assets/publish-wizard.svg)

### Skill Editor

![Skill Editor](./docs/assets/skill-editor.svg)

## Core Recommendations

- 사용자에게는 `WebSkill / GeneralSkill` 종류와 `Base / Built-In / Public / Private` 배포 단계를 함께 보이게 하고, 내부 모델은 `kind / source / visibility / manageability` 4축으로 분리한다.
- Skill Marketplace는 `WebSkill`과 `GeneralSkill`을 모두 포괄하는 배포 레이어로 설계한다.
- `Public Skill`은 기본적으로 버전 고정 설치로 두고, 업데이트는 알림 기반으로 적용한다.
- 생성 방식은 여러 개여도 최종적으로 `Draft Skill -> Test -> Private Save -> Optional Publish` 파이프라인으로 수렴시킨다.
- JS는 자유 실행이 아니라 sandbox와 capability 기반 SDK를 통해 제한한다.
- 초반 MVP는 Marketplace보다 `개인 자동화 저장과 재사용`에 우선순위를 둔다.
