# 03. Skill Creation and Editing

## One Unified Creation Pipeline

생성 방식은 여러 개여도 최종적으로는 같은 파이프라인에 들어와야 한다.

1. Source Input 수집
2. Draft Skill 생성
3. Skill kind 제안 또는 선택
4. Parameter 추출
5. Permission 제안
6. Test Run
7. Human Review
8. Save as Private
9. Optional Publish

## 1. Human Demonstration

### User Flow

1. 사용자가 `시연으로 스킬 만들기`를 선택한다.
2. 익스텐션이 브라우저 액션을 녹화한다.
3. 중간중간 사용자의 의도를 짧게 묻는다.
4. 완료 후 Agent가 액션 시퀀스를 일반화한다.
5. `WebSkill`로 볼지 `GeneralSkill`로 추상화할지 제안한다.
6. 변수 후보를 추출한다.
7. 재실행 테스트를 수행한다.
8. 사용자가 이름, 설명, 권한, 적용 범위를 확정한다.
9. Private Skill로 저장한다.

### Required UX

- 민감 필드 자동 마스킹
- 단계 삭제와 병합
- 특정 값을 파라미터로 승격
- 특정 단계에 사용자 승인 추가

### Best Use Cases

- 반복 클릭 중심 업무
- 특정 사이트 안의 고정된 처리 절차
- 텍스트보다 실제 행동이 설명하기 쉬운 작업

## 2. Manual Translation

### User Flow

1. 사용자가 가이드 문서, URL, PDF, 텍스트를 입력한다.
2. Agent가 절차를 단계별로 추출한다.
3. 웹 상호작용이 필요한 부분을 브라우저 액션으로 매핑한다.
4. 브라우저 종속 부분은 `WebSkill`, 범용 로직은 `GeneralSkill` 후보로 나눈다.
5. 모호한 부분은 질문 또는 추론으로 보완한다.
6. 테스트 가능한 Draft Skill을 만든다.
7. 사용자가 적용 범위와 파라미터를 확정한다.

### Best Use Cases

- 사내 SOP
- CS 응대 매뉴얼
- 백오피스 운영 문서

## 3. Natural Language Creation

### User Flow

1. 사용자가 자동화 목표를 자연어로 입력한다.
2. Agent가 사이트, 입력값, 성공 조건을 구조화한다.
3. `WebSkill / GeneralSkill` 중 더 적절한 kind를 제안한다.
4. 부족한 정보는 최소 질문으로 보완한다.
5. 초안 스킬을 생성한다.
6. 샘플 페이지 또는 샘플 입력으로 테스트한다.
7. 수정 후 저장한다.

### Example Prompt

`Gmail에서 첨부파일을 찾아 다운로드하고 요약 메모를 만들어줘.`

이 경우 전반부는 WebSkill, 후반부는 GeneralSkill 또는 두 스킬의 조합으로 모델링할 수 있다.

## 4. Save After Execution

이 방식은 가장 중요한 진입점으로 보는 것이 좋다.

### User Flow

1. 사용자가 Browser Agent로 일회성 작업을 수행한다.
2. 완료 후 시스템이 `이 작업을 스킬로 저장할까요?`를 제안한다.
3. Agent가 실제 실행 로그와 선택 근거를 바탕으로 일반화한다.
4. 반복 가능한 입력값만 파라미터로 추출한다.
5. `WebSkill / GeneralSkill / split into both` 제안을 보여준다.
6. 테스트 후 Private Skill로 저장한다.

### Why It Matters

- 사용자가 처음부터 스킬을 설계할 필요가 없다.
- 실제 성공 로그 기반이라 품질이 높다.
- 개인 자동화 저장소가 자연스럽게 쌓인다.

## Editing Experience

Private Skill은 시각 편집기와 고급 편집기를 모두 제공해야 한다.

### Editing Modes

- Visual Mode
- Advanced Mode
- Side-by-Side Test Mode

### Editable Fields

- 이름, 설명, 아이콘
- Skill kind
- 적용 사이트 또는 invocation context
- 트리거 방식
- 단계 순서
- 파라미터
- 실패 시 처리
- 권한
- JS 사용 여부
- 버전 메모

### Safety During Editing

- 권한이 늘어나면 재승인
- JS 추가 시 경고 배너
- 변경 전후 diff 표시
- 테스트 통과 전 게시 불가

## Editing by Skill Kind

### WebSkill Editor

- 사이트 scope 편집
- step canvas와 selector picker
- browser capability 편집
- 현재 탭에서 side-by-side test

### GeneralSkill Editor

- input/output schema 편집
- prompt/instruction structure 편집
- reusable variable template 편집
- 샘플 입력과 예상 출력 테스트

## Editor Recommendations

### Visual Mode

- 비개발자 중심
- 단계 블록 편집
- 요소 선택기로 selector 입력
- 조건문과 승인 단계 삽입
- kind 전환 시 영향 차이 설명

### Advanced Mode

- Manifest 편집
- Instruction 편집
- JS 편집
- Permission 편집
- Tests 편집

### Side-by-Side Test Mode

- 현재 탭 또는 샘플 입력에서 바로 실행
- 입력값 샘플 교체
- DOM 미리보기와 로그 확인
- 실패 지점 재시도

## Good Default Actions

편집기에서 자주 필요한 액션은 버튼으로 바로 제공하는 것이 좋다.

- `Turn to variable`
- `Require approval`
- `Retry on failure`
- `Fork from public`
- `Convert to GeneralSkill`
- `Convert to WebSkill`
- `Test with sample input`
