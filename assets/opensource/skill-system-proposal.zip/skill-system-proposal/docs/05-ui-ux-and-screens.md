# 05. UI, UX, and Screens

## Visual Direction

브랜드 톤은 `developer tool + consumer marketplace`의 중간이 좋다.

- 메인 컬러: ink navy, cobalt blue, lime accent
- 배경: 밝은 회색 베이스 위의 약한 그리드
- 카드: 브라우저 패널 같은 라운드 카드
- 타이포그래피: 강한 헤드라인 + 읽기 쉬운 본문
- 모션: hover 시 capability badge가 먼저 보이는 방식

## Information Architecture

### Main Surfaces

1. Marketplace Home
2. Skill Detail
3. My Skills
4. Create Skill
5. Edit Skill
6. Publish Skill
7. Settings
8. Execution Logs
9. Lifecycle Detail

### Navigation

- 상단 전역 검색
- `All / WebSkills / GeneralSkills` kind switch
- 좌측 카테고리/필터
- 우측 사용자 메뉴
- 익스텐션 팝업에서는 축약형 탐색 제공

## Screen 1. Marketplace Home

### Purpose

- 신규 사용자에게 스킬의 개념과 신뢰를 전달
- 설치 가능한 스킬을 빠르게 탐색하게 함
- Marketplace가 WebSkill과 GeneralSkill을 모두 다룬다는 점을 명확히 보여줌

### Layout

- Hero: 문제 정의 + 2개의 CTA + 시각적 스킬 스택
- kind switch: `All / WebSkills / GeneralSkills`
- Category rail
- Verified Collections
- No-JS Safe Picks
- New and Rising

### Filters

- Skill kind
- 사이트
- 카테고리
- JS 포함 여부
- 권한 수준
- 무료/유료
- Verified

### Sample

![Marketplace Home](./assets/marketplace-home.svg)

## Screen 2. Skill Detail

### Purpose

- 설치 전 신뢰와 위험을 동시에 이해시키는 화면

### Layout

- 상단: 이름, 작성자, kind badge, trust badge, 설치 버튼
- 좌측: 설명, 데모, 사용 예시, 업데이트 로그
- 우측: 권한 요약, 적용 사이트 또는 invocation context, 최근 버전, 리스크 레벨
- 하단: 리뷰, 유사 스킬, 포크 수

### UX Rule

- 권한 패널은 접히지 않게 유지
- `JS`와 `External Network`는 상단에서도 다시 강조
- `WebSkill / GeneralSkill` 배지는 제목 옆에 항상 보이게 둔다

## Screen 3. Publish Wizard

### Purpose

- 게시 전 kind, 메타데이터, 권한 검토를 강제

### Steps

1. Kind and Overview
2. Behavior
3. Permissions
4. Assets
5. Validation
6. Review and Submit

### Key Rule

- Step 1에서 `WebSkill / GeneralSkill`을 확정하게 해야 한다.
- `Permissions` 단계에서 단순 체크박스만 두지 말고, 왜 필요한 권한인지 설명을 작성하게 해야 한다.

### Sample

![Publish Wizard](./assets/publish-wizard.svg)

## Screen 4. Edit Skill

### Purpose

- 비개발자도 시각적으로 수정 가능
- 고급 사용자는 JS와 manifest까지 제어 가능
- kind별로 다른 편집 affordance를 제공

### Recommended Layout

- 좌측: Outline, Trigger, Tests
- 중앙: Flow Canvas 또는 Instruction Editor
- 우측: Inspector
- 하단: Console, DOM Preview, Diff, Trace

### Key Interactions

- 스텝 드래그 정렬
- 현재 탭 요소 선택 후 selector 자동 입력
- kind 전환 시 영향 범위 안내
- 파라미터 토글
- 조건문 블록 추가
- 실패 처리 블록 추가
- 샘플 입력으로 즉시 실행

### Sample

![Skill Editor](./assets/skill-editor.svg)

## Screen 5. My Skills

### Purpose

- 개인 라이브러리에서 Private Skill을 관리
- kind, 상태, 최근 실행, 퍼블리시 가능 여부를 한눈에 확인

### Required Modules

- kind filter
- Draft / Saved / Published 상태 필터
- 최근 수정일
- 최근 실행 성공률
- `Edit`, `Test`, `Publish`, `Run` 액션

## Screen 6. Install Modal

### Purpose

- 설치 직전 요약 화면에서 kind와 위험을 분명하게 전달

### Required Modules

- kind badge
- 적용 사이트 또는 invocation context
- 권한 요약
- 버전 고정/자동 업데이트 선택
- 설치 후 기본 활성화 여부

## Screen 7. Run Surfaces

### Popup

- 현재 페이지에서 사용 가능한 WebSkill
- 현재 문맥에서 사용 가능한 GeneralSkill
- 추천 스킬
- 최근 사용 스킬
- `이번 작업 저장하기`

### In-Run Overlay

- 현재 수행 단계
- 사용자 승인 대기
- 실패 시 복구 선택지
- `이 흐름을 스킬로 저장` CTA

### Result Sheet

- 무엇을 했는지
- 어떤 데이터를 사용했는지
- 재실행 가능 여부
- 스킬로 저장 버튼
- 사용한 WebSkill / GeneralSkill 표시

## Related Doc

개인 편집 -> 퍼블리시 -> 사용까지의 상세 UI 플로우는 아래 문서에서 단계별로 정리한다.

- [06. Detailed UI Flow: Personal Edit to Publish to Use](./06-detailed-ui-flow-personal-edit-publish-use.md)
