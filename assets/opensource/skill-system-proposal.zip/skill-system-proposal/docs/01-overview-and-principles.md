# 01. Overview and Principles

## Goal

Browser Agent의 스킬 시스템은 아래 3가지를 동시에 달성해야 한다.

- 사용자가 개인용 자동화와 노하우를 빠르게 스킬로 만들 수 있어야 한다.
- 만들어진 스킬이 안전하게 실행되고, 권한과 변경 이력이 통제되어야 한다.
- 검증된 스킬은 마켓플레이스를 통해 공유되고 재사용되어야 한다.

핵심 원칙은 생성 방식이 달라도, 최종적으로는 동일한 실행 계약과 배포 모델로 수렴해야 한다는 점이다.

## User-Facing Dimensions

스킬은 사용자에게 아래 두 축으로 이해되도록 설계하는 편이 좋다.

### 1. Skill Kind

1. WebSkill
2. GeneralSkill

`WebSkill`은 브라우저 탭, 사이트, DOM, selector, page action에 직접 연결되는 스킬이다.

`GeneralSkill`은 특정 사이트에 종속되지 않고, 브라우저 작업 전후의 판단, 요약, 변환, 템플릿 실행, 범용 워크플로우를 담당하는 스킬이다.

### 2. Distribution Tier

1. Base Skill
2. Built-In Skill
3. Public Skill
4. Private Skill

### Skill Layer Summary Table

아래 표는 Skill Layer를 사용자 노출과 관리 정책 기준으로 요약한 것이다.

| Layer | 설명 | 사용자 노출 | 토글 | 편집 |
| --- | --- | --- | --- | --- |
| Base Skill | 동작이나 Agent Loop를 효과적으로 관리하기 위한 내부 스킬 | 비공개 | 불가능 | 불가능 |
| Built-In Skill | Domain 단위 스킬로 개발팀에서 제공하는 스킬 | 공개 | 가능 | 불가능 |
| Public Skill | Marketplace에서 제공하는 스킬, 인증 단계를 거쳐 공개되는 스킬 | 공개 | 가능 | 불가능 |
| Private Skill | 사용자가 직접 제작한 스킬 | 공개 | 가능 | 가능 |

`Base / Built-In`은 배포 주체에 가깝고, `Public / Private`는 공개 범위에 가깝다.

따라서 내부적으로는 아래 4개 축으로 모델링하는 것이 가장 명확하다.

- `kind`: `web | general`
- `source`: `system | marketplace | personal`
- `visibility`: `internal | public | private`
- `manageability`: `immutable | toggleable | editable | forkable`

## Recommended Policy by Tier

| User Tier | Internal Meaning | Editable | Toggleable | Update Mode | Notes |
| --- | --- | --- | --- | --- | --- |
| Base | `system + internal + immutable` | No | No | Bundled with app version | 필수 안전/기본 기능 |
| Built-In | `system + internal + toggleable` | No | Yes | Bundled with app version | 기본 제공 기능 |
| Public | `marketplace + public + forkable` | No direct edit, fork allowed | Yes | Versioned update | 설치 후 버전 고정 권장 |
| Private | `personal + private + editable` | Yes | Yes | User-managed | 개인 또는 향후 팀 전용 |

이 Tier는 `WebSkill`과 `GeneralSkill` 모두에 적용된다.

## When to Use Each Skill Kind

| Kind | Best For | Key UI Requirement |
| --- | --- | --- |
| WebSkill | 사이트 조작, 폼 입력, 클릭, DOM 추출, 특정 서비스 워크플로우 | 사이트 scope, selector/step editor, capability permission |
| GeneralSkill | 요약, 분류, 템플릿 적용, 브라우저 작업 전후 처리, 범용 로직 | input/output schema, reusable parameter editor, cross-context invoke |

## Key Product Decisions

### 1. Skill Marketplace는 WebSkill과 GeneralSkill을 모두 포괄해야 한다

Marketplace는 Public Skill만 모아두는 곳이 아니라, 공개 가능한 모든 스킬을 배포하는 레이어여야 한다.

- WebSkill도 Marketplace에 올라간다.
- GeneralSkill도 Marketplace에 올라간다.
- 목록, 검색, 상세 페이지, 설치 모달은 두 종류를 모두 처리해야 한다.
- 대신 탐색 단계에서 `All / WebSkills / GeneralSkills` 필터를 제공해야 한다.

즉, Marketplace는 Tier가 아니라 Distribution Channel이다.

### 2. Public Skill은 자동 최신 반영보다 버전 고정이 기본이어야 한다

마켓플레이스 변경이 즉시 사용자 실행 환경에 반영되면 아래 리스크가 생긴다.

- 기존 자동화가 갑자기 깨질 수 있다.
- 작성자가 의도하지 않은 변경이 설치자 전체에 전파된다.
- JS 포함 스킬이면 보안 사고 반경이 커진다.

권장 정책은 아래와 같다.

- 기본 설치는 `pinned version`
- 새 버전은 `update available` 상태로만 노출
- 사용자가 원하면 `auto update`를 켤 수 있음
- 자동 업데이트는 기본적으로 `minor / patch`만 허용
- 보안 패치는 예외적으로 강제 차단 또는 강제 업데이트 가능

### 3. Marketplace보다 Personal Library가 먼저다

제품 초반에는 공개 마켓보다 아래 경험이 더 중요하다.

- 작업을 수행한 뒤 바로 스킬로 저장하기
- 저장한 스킬을 다시 실행하고 다듬기
- WebSkill과 GeneralSkill을 개인 라이브러리 안에서 함께 관리하기

즉, 초기 PMF는 "공개 배포 플랫폼"보다 "개인 자동화 저장소"에 더 가깝다.

### 4. JS는 기능이 아니라 위험한 확장권이다

JS 실행을 허용하는 순간 스킬은 단순한 프롬프트 묶음이 아니라 코드 실행 패키지가 된다.

필수 원칙은 아래와 같다.

- JS는 sandbox에서만 실행
- 허용된 SDK만 접근 가능
- 네트워크는 allowlist 기반
- 고위험 권한 증가 시 재승인 필요

이 정책은 특히 WebSkill에서 중요하지만, GeneralSkill의 외부 호출이나 자동 처리에도 동일한 원칙이 적용되어야 한다.

## Product Principles

### Easy to Create

- 자연어만으로도 첫 스킬을 만들 수 있어야 한다.
- 실행 후 바로 스킬화하는 흐름이 가장 짧아야 한다.
- 비개발자도 Visual Editor만으로 수정 가능해야 한다.
- 생성 초반에 `WebSkill / GeneralSkill` 판단이 쉬워야 한다.

### Safe to Run

- 사이트 범위와 capability가 명확해야 한다.
- 권한 확대는 항상 재확인해야 한다.
- Public Skill은 품질과 보안 검사를 통과해야 한다.
- GeneralSkill도 입력/출력과 외부 의존성을 명확히 가져야 한다.

### Easy to Trust

- 스킬 카드만 봐도 위험도를 알 수 있어야 한다.
- `Verified`, `No JS`, `Minimal Permissions` 같은 신뢰 배지가 중요하다.
- 스킬 종류가 카드에서 바로 보여야 한다.
- 업데이트 방식과 변경 이력이 사용자에게 명확해야 한다.

### Easy to Reuse

- 개인용에서 공개용으로 자연스럽게 승격 가능해야 한다.
- Public Skill은 포크해서 Private으로 가져오기 쉬워야 한다.
- 사이트별 기본 스킬 설정이 가능해야 한다.
- WebSkill과 GeneralSkill을 조합해 실행할 수 있어야 한다.

## MVP Recommendation

### Phase 1

- Built-In + Private Skill
- WebSkill + GeneralSkill 기본 분류
- 자연어 생성
- 실행 후 스킬 저장
- Visual Editor
- 개인 라이브러리

### Phase 2

- Human Demonstration
- Public Marketplace 설치
- Marketplace kind 필터
- 버전 고정 업데이트 정책
- 신고/검수 최소 체계

### Phase 3

- Public 업로드
- JS Skill
- 리뷰/평판/Verified
- 포크와 업스트림 업데이트 병합
- WebSkill + GeneralSkill 번들 또는 조합 실행

## Bottom Line

이 시스템의 성패는 스킬을 얼마나 쉽게 만들 수 있는가보다, 만든 스킬을 얼마나 안전하게 유지하고 공유할 수 있는가에 더 크게 좌우된다.
