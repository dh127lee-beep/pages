# 04. Marketplace, Publishing, and Settings

## Marketplace Scope

Skill Marketplace는 `WebSkill`과 `GeneralSkill`을 모두 포괄하는 배포 레이어로 설계하는 것이 좋다.

- All Skills
- WebSkills
- GeneralSkills

사용자는 Marketplace에서 종류를 필터링하고, 설치와 설정은 kind별로 다르게 경험하게 된다.

## Publish Flow

Private Skill을 Public Skill로 승격하는 흐름은 아래와 같이 설계하는 것이 좋다.

1. 사용자가 `공유하기`를 누른다.
2. 시스템이 퍼블리싱 체크리스트를 실행한다.
3. Skill kind와 메타데이터를 확인한다.
4. 권한과 JS 사용 여부를 강조 표시한다.
5. 샘플 실행 또는 데모 영상을 첨부한다.
6. 보안/품질 자동 검사를 통과한다.
7. 제출 후 리뷰를 기다린다.
8. 승인되면 Public으로 게시된다.

## Publishing Checklist

- 제목과 설명
- Skill kind
- 카테고리
- 대상 사이트 또는 invocation context
- 입력값 설명
- 최소 권한
- 스크린샷 또는 데모
- changelog
- 라이선스 또는 공유 범위
- 민감정보 포함 여부 확인

## Review Model

### Automated Review

- 악성 JS 패턴
- 과도한 권한 요청
- 알려진 피싱 도메인 접근
- 민감 데이터 수집 코드
- 설명과 동작 불일치
- kind 선언과 실제 동작 불일치

### Human or Trusted Reviewer Review

- 실제로 설명한 기능을 수행하는지
- 사용자에게 위험하지 않은지
- 설명, 샘플, 데모 품질이 충분한지
- WebSkill / GeneralSkill 분류가 적절한지

## Marketplace Quality Signals

- 설치 수
- 활성 사용자 수
- 성공 실행률
- 최근 업데이트
- 권한 민감도
- Verified 여부
- 신고 이력
- Skill kind

## Installation Flow

1. 사용자가 Skill Detail에서 설치를 누른다.
2. 시스템이 Skill kind, 적용 범위, 권한을 요약한다.
3. 설치 직후 기본값으로 on 또는 off를 고르게 한다.
4. 버전 고정 또는 자동 업데이트 여부를 고르게 한다.
5. kind에 맞는 추가 설정을 요청한다.
6. 설치 완료 후 샘플 실행을 제안한다.

### WebSkill Install Config

- 어떤 사이트에서 활성화할지
- 기본 트리거를 manual로 둘지 auto-suggest로 둘지
- 고위험 site에서 별도 승인 필요 여부

### GeneralSkill Install Config

- 어떤 context에서 보일지
- selected text / page summary / post-run hook 중 어디에 연결할지
- 기본 출력 형식과 저장 위치

## Settings Model

설정은 아래 3층 구조가 가장 명확하다.

- Global Settings
- Site Settings
- Skill Settings

### Global Settings

- 스킬 추천 on/off
- 실행 후 스킬 저장 제안 on/off
- Public Skill 자동 업데이트 정책
- 고위험 권한 스킬 기본 차단
- WebSkill / GeneralSkill 기본 노출 정책

### Site Settings

- 이 사이트의 기본 WebSkill
- 이 사이트에서 Public Skill 허용 여부
- 이 사이트에서 JS Skill 허용 여부

### Skill Settings

- on/off
- 우선순위
- 권한 확인
- 실행 기록
- 업데이트 정책
- 포크, 복제, 삭제
- invocation 위치 변경

## Trust and Safety UX

### Trust Badges

- Verified
- WebSkill
- GeneralSkill
- No JS
- Minimal Permissions
- Popular
- Recently Updated

### Risk Emphasis

아래 요소는 빨간 계열 또는 강한 경고 시각으로 노출하는 것이 좋다.

- JS 포함
- 외부 네트워크 호출
- 파일 업로드/다운로드
- 결제 또는 송금 사이트
- 대량 메시지 발송

## Reporting and Moderation

### Report Reasons

- 보안 위험
- 사기 또는 피싱
- 오작동
- 저작권
- 스팸
- 분류 오류

### Moderation Actions

- 배포 일시 중지
- 검색 노출 제외
- 경고 배지 부착
- 작성자 추가 검수
- kind 재분류 요청

## Creator Trust Levels

- New Creator
- Trusted Creator
- Verified Partner

신뢰 등급에 따라 공개 심사 속도와 노출 우선순위를 다르게 가져갈 수 있다.

## Fork Policy

Public Skill은 직접 수정하게 두지 말고 아래 흐름으로 유도하는 것이 좋다.

1. Public Skill 설치
2. `Fork to Private`
3. 개인용 수정
4. 원본 업데이트를 가져올지 선택

이 방식이 원본 안정성과 개인 커스터마이징을 동시에 보장한다.
