# 02. Skill Model and Runtime

## Standard Skill Package

스킬 생성 방식이 무엇이든 최종 결과물은 동일한 Skill Package로 정규화되어야 한다.

### Package Components

1. Kind
2. Manifest
3. Instruction
4. Trigger
5. Parameter Schema
6. Execution Plan
7. Permission Scope
8. Optional JS Module
9. Test Cases
10. Version Metadata

## Skill Kind Contract

### WebSkill

- 특정 사이트, URL 패턴, DOM 컨텍스트에 묶인다.
- selector, click, fill, extract, upload 같은 page action을 가진다.
- site scope와 browser capability를 명시해야 한다.

### GeneralSkill

- 특정 사이트에 묶이지 않는다.
- 입력값을 받아 판단, 생성, 정리, 포맷팅, 분류, 사전/사후 처리 같은 범용 로직을 수행한다.
- input/output schema와 invocation context를 명시해야 한다.

## Suggested Manifest Shape

```json
{
  "skillId": "gmail-save-attachments",
  "displayName": "Save Gmail Attachments",
  "kind": "web",
  "ownerId": "user_123",
  "tier": "private",
  "source": "personal",
  "visibility": "private",
  "version": "1.2.0",
  "compatibility": {
    "extension": ">=1.0.0",
    "sites": ["mail.google.com"]
  },
  "invocation": {
    "entrypoints": ["manual", "context-menu", "suggested-after-run"]
  },
  "permissions": {
    "sites": ["mail.google.com"],
    "capabilities": ["read_dom", "click", "download_file"],
    "networkDomains": [],
    "js": false
  }
}
```

GeneralSkill은 `compatibility.sites` 대신 아래 같은 구조를 가질 수 있다.

```json
{
  "kind": "general",
  "invocation": {
    "entrypoints": ["manual", "post-run", "selection-action"]
  },
  "io": {
    "input": ["text", "clipboard", "structured-data"],
    "output": ["summary", "draft", "classification"]
  }
}
```

## Execution Unit

각 스킬은 아래 단위를 명시적으로 가져야 한다.

- `Context`: 현재 탭, URL, DOM, 사용자 입력, 저장 변수
- `Precondition`: 어느 상황에서만 동작하는지
- `Action`: 클릭, 입력, 탐색, 추출, 판단, JS 실행
- `Output`: 성공 여부, 추출 데이터, 파일, 후속 제안
- `Recovery`: 재시도 또는 대체 경로

WebSkill은 `Context`와 `Precondition`에서 사이트와 DOM 매칭이 중요하고, GeneralSkill은 입력 타입과 실행 시점이 더 중요하다.

## Runtime Pipeline

Browser Agent는 아래 순서로 스킬을 실행하는 것이 적절하다.

1. 자연어 의도 해석
2. Skill kind 추정
3. 스킬 후보 검색
4. 권한 및 환경 매칭
5. 실행 계획 생성
6. 브라우저 액션 또는 범용 로직 수행
7. 결과 기록
8. 재사용 가능 시 스킬화 제안

## Skill Resolution Priority

### Web Context가 강한 경우

1. 현재 사이트에 강하게 매칭되는 Private WebSkill
2. 사용자가 Preferred로 고정한 Public WebSkill
3. Built-In WebSkill
4. 관련 GeneralSkill
5. 기타 Public WebSkill

### Generic Context가 강한 경우

1. Private GeneralSkill
2. 사용자가 Preferred로 고정한 Public GeneralSkill
3. Built-In GeneralSkill
4. 기타 Public GeneralSkill
5. 필요 시 보조 WebSkill

## Conflict Resolution

동일 트리거에 여러 스킬이 충돌하면 아래 중 하나를 사용한다.

- 자동 선택: 신뢰도, 최근 성공률, 최근 사용 이력 기반
- 사용자 선택: 이번 실행만 사용할 스킬 선택
- 기본값 고정: 사이트별 또는 context별 기본 스킬 지정

## Permission Model

권한은 단순히 on/off가 아니라 아래 레이어로 나누는 것이 좋다.

### WebSkill Permission

- Site Scope
- Browser Capability Scope
- Risk Level

#### Site Scope

- 특정 도메인만 허용
- 서브도메인 범위 명시
- 고위험 사이트 별도 표시

#### Capability Scope

- `read_dom`
- `click`
- `fill`
- `download_file`
- `upload_file`
- `clipboard`
- `network_fetch`

### GeneralSkill Permission

- Input Source Scope
- Output Action Scope
- External Dependency Scope

#### Input Source Scope

- selected text
- page summary
- clipboard
- user prompt
- saved variables

#### Output Action Scope

- generate draft
- save note
- handoff to WebSkill
- copy to clipboard

### Risk Level

- Low: 읽기 중심, 단순 생성, 단순 이동
- Medium: 입력, 다운로드, 상태 변경, 외부 호출
- High: 업로드, 외부 네트워크, 결제/송금, 대량 작업

## JS Execution Model

사용자 정의 JS가 가능하더라도 자유 실행은 금지하고, Browser Agent SDK 기반의 제한된 실행 모델로 설계해야 한다.

### Allowed Shape

- JS는 sandboxed runtime에서 실행
- `chrome.*` 전체 접근 금지
- 허용된 SDK만 노출
- 네트워크는 allowlist 기반
- CPU, 메모리, 실행 시간 제한
- 장기 백그라운드 실행 금지

### Sample SDK

```js
await browser.page.click({ selector: "button.submit" });
const text = await browser.page.text({ selector: ".invoice-total" });
await browser.storage.set("last_total", text);
```

### Denylist or Restricted APIs

- `eval`
- `new Function`
- arbitrary remote script loading
- unrestricted fetch
- full cookie/session access

## Public Skill JS Policy

Public Skill에서 JS가 포함되면 아래 검사를 필수로 둔다.

- 정적 분석
- 위험 API 탐지
- 권한 diff 리뷰
- 서명된 배포 아티팩트
- 리뷰 승인 후 공개

## Versioning

- `major`: 권한 증가, 파라미터 호환성 파괴, 실행 방식 변경
- `minor`: 기능 추가, 새 옵션 추가
- `patch`: 버그 수정, 안정성 개선

## Draft, Saved, Published

- `Draft`: 편집 중이며 아직 검증되지 않은 버전
- `Saved`: 개인용으로 즉시 실행 가능한 버전
- `Published`: 마켓플레이스에서 설치 가능한 버전

이 3단을 분리해야 편집 중 실수와 공개 배포를 분리할 수 있다.
