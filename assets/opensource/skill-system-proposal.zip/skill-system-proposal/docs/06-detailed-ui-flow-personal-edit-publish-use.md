# 06. Detailed UI Flow: Personal Edit to Publish to Use

## Scope

이 문서는 아래 전체 여정을 화면 단위로 설계한다.

1. 개인 라이브러리 진입
2. 개인 편집
3. 테스트와 저장
4. 퍼블리시
5. 마켓 게시
6. 설치
7. 사용
8. 실행 후 관리

대상은 `WebSkill`과 `GeneralSkill` 모두이며, 차이가 나는 부분은 각 단계에서 분리해 적는다.

## End-to-End Journey

1. My Skills
2. Create or Edit Private Skill
3. Test and Save
4. Publish Wizard
5. Review Queue
6. Marketplace Listing
7. Install and Configure
8. Run
9. Logs, Rating, Update, Fork

## Stage 1. My Skills Home

### Goal

- 사용자가 자신의 Private Skill을 빠르게 찾고 편집 또는 실행할 수 있어야 한다.

### Primary UI

- 상단 검색
- kind filter: `All / WebSkills / GeneralSkills`
- status filter: `Draft / Saved / Published`
- 정렬: 최근 수정 / 최근 실행 / 성공률
- 카드 또는 테이블 리스트

### Card Fields

- 이름
- kind badge
- 상태 badge
- 최근 수정일
- 최근 실행 성공률
- 최근 버전
- 주요 액션: `Edit`, `Test`, `Run`, `Publish`

### Empty State

- `Create your first WebSkill`
- `Create your first GeneralSkill`
- `Save after run` 안내

### Exit Paths

- 새 스킬 생성
- 기존 스킬 편집
- 바로 테스트
- 퍼블리시 시작

## Stage 2. Create Entry

### Goal

- 사용자가 어떤 방식으로 스킬을 만들지, 어떤 kind로 만들지 빠르게 결정하게 한다.

### Entry Options

1. Human Demonstration
2. Manual Translation
3. Natural Language
4. Save After Execution

### Required Choice

- `This is a WebSkill`
- `This is a GeneralSkill`
- `Not sure, recommend for me`

### UX Rule

- 추천은 시스템이 하되, 최종 선택은 사용자가 확인하게 한다.

## Stage 3. Personal Editor

### Goal

- 사용자가 개인용 초안을 수정하고, 실행 가능한 Private Skill로 다듬게 한다.

### Shared Layout

- 좌측: Outline, Trigger, Tests
- 중앙: Main editor
- 우측: Inspector
- 하단: Console, Preview, Diff

### Shared Top Bar

- Skill name
- kind badge
- version state
- `Test Run`
- `Save Draft`
- `Save Private`
- `Publish`

### WebSkill Editor Modules

- 사이트 scope 설정
- step canvas
- selector picker
- capability editor
- approval gate 삽입
- 현재 탭 side-by-side test

### GeneralSkill Editor Modules

- input schema
- output schema
- instruction editor
- reusable prompt blocks
- structured test input
- expected output preview

### Inspector Fields

- name
- description
- icon
- kind
- trigger
- variables
- permission
- retry policy
- version note

### Validation

- 필수 메타데이터 확인
- kind에 맞는 필드가 채워졌는지 확인
- WebSkill은 site scope와 step 유효성 검사
- GeneralSkill은 input/output contract 유효성 검사

## Stage 4. Test Run and Save

### Goal

- 퍼블리시 이전에 Private Skill로서 신뢰 가능한 최소 품질을 확보한다.

### Test Run UI

- sample input picker
- run trace
- failed step highlight
- retry from here
- compare expected vs actual

### Save Flow

1. `Save Draft`
2. `Run Validation`
3. `Save as Private`
4. version note 입력

### Success State

- `Private Skill saved`
- 다음 CTA: `Run now`, `Edit again`, `Publish`

### Failure State

- 실패한 step 또는 field 강조
- `Fix and retest` CTA

## Stage 5. Publish Entry Gate

### Goal

- 아직 퍼블리시 준비가 안 된 스킬을 위저드에 올리지 않게 막는다.

### Gate Checks

- 이름과 설명 존재
- kind 확정
- 테스트 최소 1회 성공
- 권한 설명 존재
- 공개 메타데이터 최소 충족

### Gate Outcomes

- Pass: Publish Wizard 진입
- Blocked: 어떤 항목이 부족한지 리스트로 노출

## Stage 6. Publish Wizard

### Step 1. Kind and Overview

- kind 확정
- 제목
- 짧은 설명
- 카테고리
- 대상 사이트 또는 invocation context
- 공개용 카드 미리보기

### Step 2. Behavior

- 해결하는 문제
- 입력값
- 결과물
- 실패 시 동작
- WebSkill이면 실행 step 요약
- GeneralSkill이면 입력/출력 예시

### Step 3. Permissions

- requested permissions
- 왜 필요한 권한인지 설명
- user-facing consent text preview
- risk score preview

### Step 4. Assets

- cover image
- screenshots
- demo video
- usage examples

### Step 5. Validation

- 최근 테스트 결과
- 성공률
- 경고 항목
- JS 또는 external network 경고

### Step 6. Review and Submit

- 최종 listing preview
- 위험 요약
- changelog
- `Submit for Review`

## Stage 7. Review Queue

### Goal

- 제출 이후의 상태를 사용자가 명확히 이해하게 한다.

### Status Types

- In Review
- Requires Changes
- Approved
- Rejected

### Required UI

- 제출 버전
- kind
- 제출 시점
- 자동 검사 결과
- 리뷰어 피드백
- `Apply changes and resubmit`

## Stage 8. Marketplace Listing

### Goal

- 사용자에게 설치 전 충분한 판단 근거를 제공한다.

### Listing Card

- 이름
- kind badge
- trust badges
- 설치 수
- 성공률
- 한 줄 설명

### Detail Page

- overview
- demo
- version history
- permissions
- 대상 사이트 또는 invocation context
- similar skills
- reviews

### UX Rule

- kind badge는 카드와 상세 둘 다에 항상 노출한다.

## Stage 9. Install and Configure

### Install Modal

- kind
- 권한 요약
- 적용 범위
- 버전 정책
- 활성화 여부

### WebSkill Post-Install Config

- 어떤 사이트에서 활성화할지
- default trigger
- sensitive site에서 approval required 여부

### GeneralSkill Post-Install Config

- 어떤 context에서 호출할지
- 기본 입력 소스
- 기본 출력 형식

### Completion State

- `Installed successfully`
- `Run sample now`
- `Pin to popup`

## Stage 10. Run Experience

### Entry Surfaces

- extension popup
- context menu
- command palette
- post-run suggestion

### Popup Rules

- 현재 문맥에 맞는 WebSkill과 GeneralSkill을 분리해 보여준다.
- 각 스킬 카드에 kind badge를 유지한다.

### In-Run Overlay

- current step
- approval waits
- fallback options
- cancel

### Result Sheet

- 무엇을 했는지
- 어떤 입력을 사용했는지
- 결과물
- `Run again`
- `Edit this skill`
- `Save this flow`

## Stage 11. Logs and Iteration

### Goal

- 사용 후 다시 편집하고 개선하는 루프를 짧게 만든다.

### Required UI

- execution logs
- 성공률
- 최근 실패 이유
- 버전별 diff
- update available
- fork to private

### Important Loop

1. Run
2. See result
3. Open logs
4. Edit
5. Save new private version
6. Republish if needed

## State Design Checklist

각 화면은 아래 상태를 반드시 가져야 한다.

- empty
- loading
- success
- partial success
- blocked
- error

## Final Recommendation

이 여정에서 가장 중요한 것은 퍼블리시 화면 자체가 아니라, `개인 편집 -> 테스트 -> Private 저장 -> 사용 -> 다시 편집` 루프다.

퍼블리시는 그 위에 올라가는 확장 단계로 설계하는 편이 제품 품질과 성공률이 높다.
