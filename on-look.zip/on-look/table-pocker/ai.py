"""테이블포켓 AI 기능 - LLM 연결, 테이블 분석, 대시보드

LLM은 OpenAI 호환 API(/v1/chat/completions)면 무엇이든 연결된다.
설정은 llm.env 파일에 있다 (화면의 'AI 설정'에서 바꿀 수 있음).

대시보드는 LLM이 '무엇을 보여줄지'(어떤 열로 묶고, 무엇을 합칠지)만 정하고,
실제 숫자는 이 파일이 엑셀 데이터로 직접 계산한다. → 숫자를 지어낼 수 없고, 데이터가 바뀌면 자동 반영.
"""
import csv
import io
import json
import os
import re
import urllib.error
import urllib.request

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(BASE_DIR, "llm.env")
DASH_DIR = os.path.join(BASE_DIR, "data", "_dashboards")
DEFAULTS = {"LLM_URL": "http://127.0.0.1:8788/v1", "LLM_MODEL": "sonnet", "LLM_KEY": ""}
MAX_ROWS = 500  # 분석할 때 LLM에 보내는 최대 줄 수


class AIError(Exception):
    """사용자에게 그대로 보여줄 수 있는 오류"""


# ---------- 설정 ----------

def load_config():
    cfg = dict(DEFAULTS)
    if os.path.exists(CONFIG_PATH):
        with open(CONFIG_PATH, encoding="utf-8") as f:
            for line in f:
                key, sep, value = line.strip().partition("=")
                if sep and key.strip() in cfg:
                    cfg[key.strip()] = value.strip()
    for key in cfg:
        cfg[key] = os.environ.get(key, cfg[key])
    return cfg


def save_config(url, model, key):
    lines = ["# 테이블포켓 AI 설정 (OpenAI 호환 API)",
             f"LLM_URL={url}", f"LLM_MODEL={model}", f"LLM_KEY={key}", ""]
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))


# ---------- LLM 호출 ----------

def chat(system, user):
    cfg = load_config()
    if not cfg["LLM_KEY"]:
        raise AIError("AI 설정에서 API 키를 먼저 입력해주세요.")
    req = urllib.request.Request(
        cfg["LLM_URL"].rstrip("/") + "/chat/completions",
        data=json.dumps({"model": cfg["LLM_MODEL"], "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ]}).encode("utf-8"),
        headers={"Content-Type": "application/json", "Authorization": "Bearer " + cfg["LLM_KEY"]},
    )
    try:
        with urllib.request.urlopen(req, timeout=300) as r:
            data = json.load(r)
    except urllib.error.HTTPError as e:
        if e.code == 401:
            raise AIError("API 키가 맞지 않아요. AI 설정에서 키를 확인해주세요.")
        raise AIError(f"AI 서버에서 오류가 났어요. (코드 {e.code})")
    except (urllib.error.URLError, OSError):
        raise AIError("AI 서버에 연결할 수 없어요. 브리지가 켜져 있는지 확인해주세요.")
    try:
        return data["choices"][0]["message"]["content"]
    except (KeyError, IndexError, TypeError):
        raise AIError("AI 응답을 이해하지 못했어요.")


def to_csv(headers, rows):
    out = io.StringIO()
    w = csv.writer(out)
    w.writerow(headers)
    w.writerows(rows)
    return out.getvalue()


def describe(name, headers, rows, limit):
    note = f"전체 {len(rows)}줄" + (f" 중 앞 {limit}줄만 첨부" if len(rows) > limit else "")
    return f"테이블 이름: {name}\n{note}\n\n```csv\n{to_csv(headers, rows[:limit])}```"


# ---------- 분석 ----------

ANALYZE_SYSTEM = """너는 친절한 데이터 분석가야. 사용자는 개발자가 아니야.
첨부된 표(CSV)를 보고 질문에 한국어로 답해.
- 마크다운으로, 핵심부터 간결하게. 필요하면 작은 표나 목록을 써.
- 데이터에 없는 내용은 지어내지 말고, 모르면 모른다고 말해.
- 숫자를 말할 땐 직접 세거나 계산한 값만 말해."""


def analyze(name, headers, rows, question):
    return chat(ANALYZE_SYSTEM, describe(name, headers, rows, MAX_ROWS) + f"\n\n질문: {question}")


# ---------- 대시보드 ----------

DASH_SYSTEM = """너는 대시보드 디자이너야. 표의 구조를 보고 한눈에 보기 좋은 대시보드 구성을 JSON으로만 답해.
설명 없이 JSON 하나만 출력해. 형식:
{
  "title": "대시보드 제목",
  "kpis": [ {"label": "표시 이름", "agg": "count|unique|sum|avg|min|max", "column": "열 이름 (count면 생략 가능)"} ],
  "charts": [ {"title": "차트 제목", "type": "bar|line|pie|doughnut", "group_by": "묶을 열 이름",
               "agg": "count|sum|avg", "column": "sum/avg 할 숫자 열 이름 (count면 생략)", "limit": 10} ],
  "insights": ["데이터에서 읽히는 짧은 관찰 1~4개"]
}
규칙:
- 열 이름은 반드시 표에 있는 그대로 써.
- sum/avg/min/max는 숫자가 들어있는 열에만 써.
- group_by는 값이 반복되는 열(분류, 상태, 지역, 날짜 등)을 써. 모든 값이 다른 열(이름, 전화번호)은 피해.
- 날짜·시간 흐름은 line, 비율은 pie/doughnut, 나머지는 bar.
- kpis 2~4개, charts 1~4개."""

AGGS = {"count", "unique", "sum", "avg", "min", "max"}
CHART_TYPES = {"bar", "line", "pie", "doughnut"}


def design_dashboard(name, headers, rows, wish):
    user = describe(name, headers, rows, 40)
    if wish:
        user += f"\n\n사용자 요청: {wish}"
    text = chat(DASH_SYSTEM, user)
    match = re.search(r"\{.*\}", text, re.S)
    try:
        spec = json.loads(match.group(0)) if match else None
    except json.JSONDecodeError:
        spec = None
    if not isinstance(spec, dict):
        raise AIError("AI가 대시보드를 제대로 만들지 못했어요. 한 번 더 시도해주세요.")
    return clean_spec(spec, headers)


def clean_spec(spec, headers):
    """AI가 준 구성에서 잘못된 열·계산 방법은 걸러낸다."""
    def ok(item, need_column):
        col = item.get("column")
        return item.get("agg") in AGGS and (col in headers or (not need_column and not col))

    kpis = [k for k in spec.get("kpis", []) if isinstance(k, dict) and ok(k, k.get("agg") != "count")]
    charts = [c for c in spec.get("charts", []) if isinstance(c, dict) and c.get("group_by") in headers
              and c.get("type") in CHART_TYPES and ok(c, c.get("agg") in ("sum", "avg"))]
    insights = [str(s) for s in spec.get("insights", []) if s][:4]
    if not kpis and not charts:
        raise AIError("AI가 만든 대시보드에 쓸 수 있는 항목이 없어요. 한 번 더 시도해주세요.")
    return {"title": str(spec.get("title") or "대시보드"), "kpis": kpis[:4], "charts": charts[:4], "insights": insights}


def num(v):
    try:
        return float(str(v).replace(",", "").strip())
    except ValueError:
        return None


def aggregate(values, how):
    if how == "count":
        return len(values)
    if how == "unique":
        return len({v for v in values if v != ""})
    nums = [n for n in map(num, values) if n is not None]
    if not nums:
        return 0
    return {"sum": sum(nums), "avg": sum(nums) / len(nums), "min": min(nums), "max": max(nums)}[how]


def fmt(x):
    if isinstance(x, float) and not x.is_integer():
        return f"{x:,.2f}"
    return f"{int(x):,}"


def build(spec, headers, rows):
    """저장된 구성 + 현재 데이터 → 화면에 그릴 숫자"""
    col = {h: i for i, h in enumerate(headers)}

    def values(column):
        return [r[col[column]] for r in rows] if column in col else [""] * len(rows)

    kpis = [{"label": k["label"] if k.get("label") else k["agg"],
             "value": fmt(aggregate(values(k.get("column")), k["agg"]))}
            for k in spec["kpis"] if k.get("column") in col or not k.get("column")]

    charts = []
    for c in spec["charts"]:
        if c["group_by"] not in col or (c.get("column") and c["column"] not in col):
            continue  # 그 사이 열 이름이 바뀐 경우
        groups = {}
        for r in rows:
            key = r[col[c["group_by"]]] or "(빈칸)"
            groups.setdefault(key, []).append(r[col[c["column"]]] if c.get("column") else "")
        pairs = [(k, aggregate(v, c["agg"])) for k, v in groups.items()]
        limit = int(c.get("limit") or 10)
        if c["type"] == "line":
            pairs = sorted(pairs)[-max(limit, 30):]
        else:
            pairs = sorted(pairs, key=lambda p: -p[1])[:limit]
        charts.append({"title": c.get("title") or c["group_by"], "type": c["type"],
                       "labels": [p[0] for p in pairs], "values": [round(p[1], 2) for p in pairs]})

    return {"title": spec["title"], "kpis": kpis, "charts": charts, "insights": spec["insights"]}


def spec_path(name):
    return os.path.join(DASH_DIR, name + ".json")


def load_spec(name):
    try:
        with open(spec_path(name), encoding="utf-8") as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError):
        return None


def save_spec(name, spec):
    os.makedirs(DASH_DIR, exist_ok=True)
    tmp = spec_path(name) + ".saving"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(spec, f, ensure_ascii=False, indent=2)
    os.replace(tmp, spec_path(name))
