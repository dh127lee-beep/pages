#!/bin/bash
# Claude CLI 브리지 켜기 (127.0.0.1:8788). 키는 llm.env 의 LLM_KEY 를 그대로 쓴다.
cd "$(dirname "$0")"
BRIDGE_SCRIPT="/Users/leedonghyeon/Work/office-web/scripts/claude-cli-bridge.mjs"
NODE="$(command -v node || echo "$HOME/.local/share/mise/installs/node/24/bin/node")"
KEY="$(grep '^LLM_KEY=' llm.env | cut -d= -f2-)"

if lsof -nP -iTCP:8788 -sTCP:LISTEN >/dev/null 2>&1; then
  echo "브리지가 이미 켜져 있어요."
  exit 0
fi
BRIDGE_PORT=8788 BRIDGE_KEY="$KEY" nohup "$NODE" "$BRIDGE_SCRIPT" > bridge.log 2>&1 &
echo "브리지를 켰어요. (기록: bridge.log)"
