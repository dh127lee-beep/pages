#!/bin/bash
# 테이블포켓 실행 (Mac에서 더블클릭)
cd "$(dirname "$0")"
if [ ! -d .venv ]; then
  echo "처음 실행: 필요한 프로그램을 설치합니다..."
  python3 -m venv .venv && .venv/bin/pip install -q -r requirements.txt
fi
./bridge.sh
(sleep 2 && open http://localhost:8000) &
.venv/bin/python app.py
