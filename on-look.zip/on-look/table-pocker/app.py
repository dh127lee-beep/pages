"""테이블포켓 - 엑셀 파일을 테이블처럼 쓰는 간단한 웹 서비스

data 폴더 안의 엑셀 파일(.xlsx) 하나가 테이블 하나입니다.
첫 번째 시트의 첫 줄은 열 이름, 그 아래 줄부터가 데이터입니다.
"""
import json
import os
import re
import secrets
import threading
from datetime import date, datetime
from io import BytesIO

from flask import (Flask, abort, flash, jsonify, redirect, render_template, request, send_file,
                   send_from_directory, url_for)
from openpyxl import Workbook, load_workbook

import ai

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
os.makedirs(DATA_DIR, exist_ok=True)

app = Flask(__name__)
app.secret_key = "table-pocket"
app.json.sort_keys = False  # API 응답에서 열 순서 유지
app.json.ensure_ascii = False  # 한글을 \uXXXX 대신 그대로

# 테이블(엑셀 파일)마다 자물쇠를 하나씩 둔다.
# 같은 테이블에 대한 읽기/쓰기는 한 번에 하나씩, 들어온 순서대로 처리된다.
_locks = {}
_locks_guard = threading.Lock()


def lock_for(name):
    with _locks_guard:
        return _locks.setdefault(name, threading.Lock())


class Conflict(Exception):
    """보고 있던 줄을 그 사이에 다른 사람이 바꾼 경우"""


# ---------- 엑셀 읽기/쓰기 ----------

NAME_RE = re.compile(r"^[\w \-]{1,50}$")


def table_path(name):
    if not NAME_RE.match(name):
        abort(404)
    return os.path.join(DATA_DIR, name + ".xlsx")


def list_tables():
    return sorted(f[:-5] for f in os.listdir(DATA_DIR)
                  if f.endswith(".xlsx") and not f.startswith(("~$", ".")))


def to_text(v):
    if v is None:
        return ""
    if isinstance(v, datetime):
        return v.strftime("%Y-%m-%d") if v.time() == datetime.min.time() else v.strftime("%Y-%m-%d %H:%M")
    if isinstance(v, date):
        return v.strftime("%Y-%m-%d")
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    return str(v)


def to_cell(s):
    """화면에서 입력한 글자를 엑셀 칸 값으로. 숫자는 숫자로 저장 (010 같은 번호는 글자 그대로)."""
    s = s.strip()
    if re.fullmatch(r"-?(0|[1-9]\d{0,14})", s):
        return int(s)
    if re.fullmatch(r"-?(0|[1-9]\d*)\.\d+", s):
        return float(s)
    return s or None


def load(name):
    path = table_path(name)
    if not os.path.exists(path):
        abort(404)
    return load_workbook(path)


def save(wb, name):
    # 임시 파일에 다 쓴 뒤 바꿔치기 → 저장 중에 멈춰도 파일이 깨지지 않음
    path = table_path(name)
    tmp = path + ".saving"
    wb.save(tmp)
    os.replace(tmp, path)


def read_table(name):
    """(열 이름 목록, 데이터 줄 목록) 반환. 데이터 줄 i 는 엑셀의 i+2 번째 줄."""
    with lock_for(name):
        ws = load(name).active
        rows = [[to_text(v) for v in r] for r in ws.iter_rows(values_only=True)]
    if not rows:
        return [], []
    headers = rows[0]
    while headers and headers[-1] == "":
        headers.pop()
    width = len(headers)
    body = [(r + [""] * width)[:width] for r in rows[1:]]
    return headers, body


def current_row(ws, idx, width):
    row = [to_text(c.value) for c in ws[idx + 2]][:width]
    return row + [""] * (width - len(row))


def add_row(name, values):
    with lock_for(name):
        wb = load(name)
        wb.active.append([to_cell(v) for v in values])
        save(wb, name)


def update_row(name, idx, original, values):
    with lock_for(name):
        wb = load(name)
        ws = wb.active
        if idx + 2 > ws.max_row or current_row(ws, idx, len(values)) != original:
            raise Conflict
        for col, v in enumerate(values, start=1):
            ws.cell(row=idx + 2, column=col, value=to_cell(v))
        save(wb, name)


def delete_row(name, idx, original):
    with lock_for(name):
        wb = load(name)
        ws = wb.active
        if idx + 2 > ws.max_row or current_row(ws, idx, len(original)) != original:
            raise Conflict
        ws.delete_rows(idx + 2)
        save(wb, name)


def add_column(name, column):
    with lock_for(name):
        wb = load(name)
        ws = wb.active
        headers = [to_text(c.value) for c in ws[1]]
        while headers and headers[-1] == "":
            headers.pop()
        ws.cell(row=1, column=len(headers) + 1, value=column)
        save(wb, name)


def create_table(name, columns):
    with lock_for(name):
        path = table_path(name)
        if os.path.exists(path):
            return False
        wb = Workbook()
        wb.active.append(columns)
        save(wb, name)
        return True


# ---------- 화면 ----------

def table_info(name):
    headers, body = read_table(name)
    mtime = datetime.fromtimestamp(os.path.getmtime(table_path(name)))
    return {"name": name, "headers": headers, "count": sum(1 for r in body if any(r)),
            "updated": mtime.strftime("%Y-%m-%d %H:%M")}


@app.route("/")
def home():
    return render_template("home.html", tables=[table_info(t) for t in list_tables()])


@app.post("/new")
def new_table():
    name = request.form["name"].strip()
    columns = [c.strip() for c in request.form["columns"].split(",") if c.strip()]
    if not NAME_RE.match(name):
        flash("테이블 이름은 글자, 숫자, 공백, -, _ 만 쓸 수 있어요.")
    elif not columns:
        flash("열 이름을 하나 이상 적어주세요.")
    elif not create_table(name, columns):
        flash(f"'{name}' 테이블이 이미 있어요.")
    else:
        return redirect(url_for("table", name=name))
    return redirect(url_for("home"))


@app.post("/upload")
def upload():
    f = request.files.get("file")
    name = os.path.splitext(os.path.basename(f.filename if f else ""))[0].strip()
    if not f or not f.filename.lower().endswith(".xlsx"):
        flash(".xlsx 엑셀 파일을 골라주세요.")
    elif not NAME_RE.match(name):
        flash("파일 이름은 글자, 숫자, 공백, -, _ 만 쓸 수 있어요.")
    else:
        with lock_for(name):
            path = table_path(name)
            if os.path.exists(path):
                flash(f"'{name}' 테이블이 이미 있어요. 파일 이름을 바꿔서 올려주세요.")
                return redirect(url_for("home"))
            f.save(path)
        return redirect(url_for("table", name=name))
    return redirect(url_for("home"))


@app.route("/t/<name>")
def table(name):
    headers, body = read_table(name)
    q = request.args.get("q", "").strip()
    rows = [(i, r) for i, r in enumerate(body) if any(r)]
    if q:
        rows = [(i, r) for i, r in rows if any(q.lower() in v.lower() for v in r)]
    return render_template("table.html", name=name, headers=headers, rows=rows, q=q,
                           edit=request.args.get("edit", type=int), json=json)


@app.post("/t/<name>/add")
def add(name):
    values = request.form.getlist("v")
    if any(v.strip() for v in values):
        add_row(name, values)
        flash("한 줄 추가했어요.")
    return redirect(url_for("table", name=name))


@app.post("/t/<name>/edit/<int:idx>")
def edit(name, idx):
    try:
        update_row(name, idx, json.loads(request.form["original"]), request.form.getlist("v"))
        flash("저장했어요.")
    except Conflict:
        flash("그 사이에 다른 사람이 이 줄을 바꿨어요. 최신 내용을 확인하고 다시 해주세요.")
    return redirect(url_for("table", name=name))


@app.post("/t/<name>/delete/<int:idx>")
def delete(name, idx):
    try:
        delete_row(name, idx, json.loads(request.form["original"]))
        flash("한 줄 지웠어요.")
    except Conflict:
        flash("그 사이에 다른 사람이 이 줄을 바꿨어요. 최신 내용을 확인하고 다시 해주세요.")
    return redirect(url_for("table", name=name))


@app.post("/t/<name>/column")
def column(name):
    col = request.form["column"].strip()
    if col:
        add_column(name, col)
        flash(f"'{col}' 열을 추가했어요.")
    return redirect(url_for("table", name=name))


# ---------- AI ----------

def filled_rows(name):
    headers, body = read_table(name)
    return headers, [r for r in body if any(r)]


@app.route("/t/<name>/ask", methods=["GET", "POST"])
def ask(name):
    headers, rows = filled_rows(name)
    question = request.form.get("question", "").strip()
    answer = None
    if request.method == "POST" and question:
        try:
            answer = ai.analyze(name, headers, rows, question)
        except ai.AIError as e:
            flash(str(e))
    return render_template("ask.html", name=name, question=question, answer=answer)


@app.route("/t/<name>/dashboard")
def dashboard(name):
    headers, rows = filled_rows(name)
    spec = ai.load_spec(name)
    return render_template("dashboard.html", name=name, dash=ai.build(spec, headers, rows) if spec else None)


@app.post("/t/<name>/dashboard")
def make_dashboard(name):
    headers, rows = filled_rows(name)
    try:
        ai.save_spec(name, ai.design_dashboard(name, headers, rows, request.form.get("wish", "").strip()))
        flash("대시보드를 만들었어요. 데이터가 바뀌면 숫자도 자동으로 바뀌어요.")
    except ai.AIError as e:
        flash(str(e))
    return redirect(url_for("dashboard", name=name))


@app.route("/settings", methods=["GET", "POST"])
def settings():
    cfg = ai.load_config()
    if request.method == "POST":
        key = request.form.get("key", "").strip() or cfg["LLM_KEY"]  # 비워두면 기존 키 유지
        ai.save_config(request.form["url"].strip(), request.form["model"].strip(), key)
        flash("AI 설정을 저장했어요.")
        return redirect(url_for("settings"))
    return render_template("settings.html", cfg=cfg, keys=load_keys())


# ---------- API (다른 웹페이지에서 테이블을 쓰기 위한 JSON 주소) ----------
# 인증: 요청 헤더 X-API-Key 또는 주소 끝 ?key=  /  읽기 키는 읽기만, 쓰기 키는 읽기+쓰기

KEYS_PATH = os.path.join(BASE_DIR, "api_keys.json")
PAGES_DIR = os.path.join(BASE_DIR, "pages")
os.makedirs(PAGES_DIR, exist_ok=True)


def new_key(kind):
    return f"tp-{kind}-" + secrets.token_urlsafe(18)


def load_keys():
    try:
        with open(KEYS_PATH, encoding="utf-8") as f:
            keys = json.load(f)
    except (OSError, json.JSONDecodeError):
        keys = {}
    if not keys.get("read") or not keys.get("write"):
        keys = {"read": keys.get("read") or new_key("read"), "write": keys.get("write") or new_key("write")}
        save_keys(keys)
    return keys


def save_keys(keys):
    with open(KEYS_PATH, "w", encoding="utf-8") as f:
        json.dump(keys, f, indent=2)


@app.post("/settings/keys/<kind>")
def regenerate_key(kind):
    if kind in ("read", "write"):
        keys = load_keys()
        keys[kind] = new_key(kind)
        save_keys(keys)
        flash(f"{'읽기' if kind == 'read' else '쓰기'} 키를 새로 만들었어요. 예전 키를 쓰던 페이지는 새 키로 바꿔주세요.")
    return redirect(url_for("settings"))


def api_error(message, code):
    return jsonify({"error": message}), code


def need_key(write=False):
    key = request.headers.get("X-API-Key") or request.args.get("key", "")
    keys = load_keys()
    allowed = [keys["write"]] if write else [keys["read"], keys["write"]]
    return None if key in allowed else api_error("API 키가 없거나 맞지 않아요." + (" 쓰기 키가 필요해요." if write else ""), 401)


def api_table(name):
    if not NAME_RE.match(name) or not os.path.exists(table_path(name)):
        return None
    return filled_rows(name)


@app.after_request
def allow_other_pages(resp):
    # 다른 주소(파일로 연 페이지 등)에서도 API를 부를 수 있게
    if request.path.startswith("/api/"):
        resp.headers["Access-Control-Allow-Origin"] = "*"
        resp.headers["Access-Control-Allow-Headers"] = "Content-Type, X-API-Key"
        resp.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
    return resp


@app.get("/api/tables")
def api_tables():
    return need_key() or jsonify({"tables": list_tables()})


@app.get("/api/tables/<name>")
def api_rows(name):
    if err := need_key():
        return err
    found = api_table(name)
    if not found:
        return api_error("그런 테이블이 없어요.", 404)
    headers, rows = found
    q = request.args.get("q", "").strip().lower()
    items = [dict(zip(headers, r)) for r in rows if not q or any(q in v.lower() for v in r)]
    return jsonify({"table": name, "columns": headers, "count": len(items), "rows": items})


@app.post("/api/tables/<name>/rows")
def api_add_row(name):
    if err := need_key(write=True):
        return err
    found = api_table(name)
    if not found:
        return api_error("그런 테이블이 없어요.", 404)
    data = request.get_json(silent=True)
    headers = found[0]
    if not isinstance(data, dict) or not any(h in data for h in headers):
        return api_error(f"열 이름을 키로 하는 JSON을 보내주세요. 열: {', '.join(headers)}", 400)
    add_row(name, ["" if data.get(h) is None else str(data.get(h)) for h in headers])
    return jsonify({"ok": True}), 201


@app.get("/api/tables/<name>/dashboard")
def api_dashboard(name):
    if err := need_key():
        return err
    found = api_table(name)
    spec = ai.load_spec(name) if found else None
    if not spec:
        return api_error("대시보드가 아직 없어요. 테이블 화면에서 먼저 만들어주세요.", 404)
    return jsonify(ai.build(spec, *found))


@app.post("/api/tables/<name>/ask")
def api_ask(name):
    if err := need_key():
        return err
    found = api_table(name)
    if not found:
        return api_error("그런 테이블이 없어요.", 404)
    question = str((request.get_json(silent=True) or {}).get("question", "")).strip()
    if not question:
        return api_error('{"question": "질문"} 형식으로 보내주세요.', 400)
    try:
        return jsonify({"answer": ai.analyze(name, *found, question)})
    except ai.AIError as e:
        return api_error(str(e), 502)


@app.route("/pages/<path:filename>")
def pages(filename):
    # pages 폴더에 넣은 HTML 파일을 그대로 보여준다 → AI로 만든 페이지 올려두는 곳
    return send_from_directory(PAGES_DIR, filename)


@app.route("/t/<name>/guide")
def guide(name):
    headers, rows = filled_rows(name)
    sample = {"table": name, "columns": headers, "count": len(rows), "rows": [dict(zip(headers, r)) for r in rows[:2]]}
    cfg = ai.load_config()
    return render_template("guide.html", name=name, headers=headers, keys=load_keys(),
                           ai_url=cfg["LLM_URL"].rstrip("/"), ai_model=cfg["LLM_MODEL"],
                           base=request.host_url.rstrip("/"), has_dash=bool(ai.load_spec(name)),
                           sample=json.dumps(sample, ensure_ascii=False, indent=2),
                           pages=sorted(f for f in os.listdir(PAGES_DIR) if f.endswith(".html")))


@app.route("/t/<name>/download")
def download(name):
    with lock_for(name):
        path = table_path(name)
        if not os.path.exists(path):
            abort(404)
        with open(path, "rb") as fp:
            data = fp.read()
    return send_file(BytesIO(data), as_attachment=True, download_name=name + ".xlsx")


if __name__ == "__main__":
    print("테이블포켓 시작! 브라우저에서 http://localhost:8000 을 열어주세요.")
    app.run(host="0.0.0.0", port=8000, threaded=True)
