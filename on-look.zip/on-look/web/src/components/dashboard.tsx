'use client';

import { ArrowRight, Copy, ExternalLink, LayoutTemplate, MoreHorizontal, Pencil, Sparkles, Trash2 } from 'lucide-react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
import type { ProjectSummary } from '@/lib/types';

interface TemplateSummary {
    id: string;
    name: string;
    description: string;
}

function timeAgo(iso: string): string {
    const diff = (Date.now() - new Date(iso).getTime()) / 1000;
    if (diff < 60) return '방금 전';
    if (diff < 3600) return `${Math.floor(diff / 60)}분 전`;
    if (diff < 86400) return `${Math.floor(diff / 3600)}시간 전`;
    return new Date(iso).toLocaleDateString('ko-KR');
}

function Thumbnail({ src }: { src: string }) {
    // Render the page at desktop width and scale it down to the card.
    return (
        <div className="relative aspect-[16/10] overflow-hidden rounded-t-xl bg-white">
            <iframe
                src={src}
                title="미리보기"
                loading="lazy"
                sandbox="allow-scripts"
                tabIndex={-1}
                className="pointer-events-none absolute left-0 top-0 h-[400%] w-[400%] origin-top-left scale-25 border-0"
            />
        </div>
    );
}

export function Dashboard({ initialProjects, templates }: { initialProjects: ProjectSummary[]; templates: TemplateSummary[] }) {
    const router = useRouter();
    const [projects, setProjects] = useState(initialProjects);
    const [prompt, setPrompt] = useState('');
    const [busy, setBusy] = useState<string | null>(null);
    const [menu, setMenu] = useState<string | null>(null);

    async function create(templateId: string, opts: { name?: string; ai?: string } = {}) {
        setBusy(templateId);
        try {
            const res = await fetch('/api/projects', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ templateId, name: opts.name }),
            });
            if (!res.ok) throw new Error();
            const project = (await res.json()) as ProjectSummary;
            router.push(`/project/${project.id}${opts.ai ? `?ai=${encodeURIComponent(opts.ai)}` : ''}`);
        } catch {
            alert('프로젝트를 만들지 못했습니다.');
            setBusy(null);
        }
    }

    async function remove(p: ProjectSummary) {
        setMenu(null);
        if (!confirm(`"${p.name}" 프로젝트를 삭제할까요? 되돌릴 수 없습니다.`)) return;
        const res = await fetch(`/api/projects/${p.id}`, { method: 'DELETE' });
        if (res.ok) setProjects((list) => list.filter((x) => x.id !== p.id));
    }

    async function rename(p: ProjectSummary) {
        setMenu(null);
        const name = window.prompt('새 이름', p.name);
        if (!name?.trim()) return;
        const res = await fetch(`/api/projects/${p.id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name }),
        });
        if (res.ok) {
            const updated = (await res.json()) as ProjectSummary;
            setProjects((list) => list.map((x) => (x.id === p.id ? { ...x, name: updated.name, updatedAt: updated.updatedAt } : x)));
        }
    }

    async function duplicate(p: ProjectSummary) {
        setMenu(null);
        const src = await fetch(`/api/projects/${p.id}`).then((r) => r.json());
        const res = await fetch('/api/projects', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name: `${p.name} 사본`, pages: src.pages }),
        });
        if (res.ok) {
            const copy = (await res.json()) as ProjectSummary;
            setProjects((list) => [{ id: copy.id, name: copy.name, createdAt: copy.createdAt, updatedAt: copy.updatedAt }, ...list]);
        }
    }

    function startWithAi(e: React.FormEvent) {
        e.preventDefault();
        if (!prompt.trim()) return;
        create('blank', { name: prompt.trim().slice(0, 40), ai: prompt.trim() });
    }

    return (
        <div className="min-h-screen" onClick={() => setMenu(null)}>
            <header className="border-b border-line">
                <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
                    <Link href="/" className="flex items-center gap-2 font-semibold tracking-tight">
                        <span className="grid h-7 w-7 place-items-center rounded-lg bg-accent text-sm">◎</span>
                        On-Look
                    </Link>
                    <a href="https://github.com/onlook-dev/onlook" target="_blank" rel="noreferrer" className="text-xs text-muted hover:text-foreground">
                        Based on onlook-dev/onlook ↗
                    </a>
                </div>
            </header>

            <main className="mx-auto max-w-6xl px-6 pb-24">
                <section className="py-16 text-center">
                    <h1 className="text-4xl font-bold tracking-tight md:text-5xl">보면서 바로 고치는 웹 디자인</h1>
                    <p className="mx-auto mt-4 max-w-xl text-muted">
                        캔버스에서 요소를 클릭해 선택하고, 스타일을 조정하고, AI에게 수정을 맡기세요. 결과는 바로 공유 가능한 웹 페이지가 됩니다.
                    </p>
                    <form onSubmit={startWithAi} className="mx-auto mt-10 flex max-w-2xl items-center gap-2 rounded-2xl border border-line bg-panel p-2 focus-within:border-accent">
                        <Sparkles className="ml-2 h-4 w-4 shrink-0 text-accent" />
                        <input
                            value={prompt}
                            onChange={(e) => setPrompt(e.target.value)}
                            placeholder="예: 강아지 수제 간식 브랜드의 랜딩 페이지를 만들어줘"
                            className="flex-1 bg-transparent px-2 py-2 text-sm outline-none placeholder:text-muted"
                        />
                        <button type="submit" disabled={!prompt.trim() || busy !== null} className="inline-flex items-center gap-1 rounded-xl bg-accent px-4 py-2 text-sm font-medium disabled:opacity-40">
                            AI로 만들기 <ArrowRight className="h-4 w-4" />
                        </button>
                    </form>
                </section>

                <section>
                    <h2 className="mb-4 flex items-center gap-2 text-sm font-semibold text-muted">
                        <LayoutTemplate className="h-4 w-4" /> 템플릿으로 시작
                    </h2>
                    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
                        {templates.map((t) => (
                            <button
                                key={t.id}
                                onClick={() => create(t.id)}
                                disabled={busy !== null}
                                className="group rounded-xl border border-line bg-panel p-4 text-left transition hover:border-accent disabled:opacity-60"
                            >
                                <div className="font-medium">{busy === t.id ? '만드는 중…' : t.name}</div>
                                <div className="mt-1 text-xs leading-relaxed text-muted">{t.description}</div>
                            </button>
                        ))}
                    </div>
                </section>

                <section className="mt-14">
                    <h2 className="mb-4 text-sm font-semibold text-muted">내 프로젝트 · {projects.length}</h2>
                    {projects.length === 0 ? (
                        <div className="rounded-xl border border-dashed border-line py-16 text-center text-sm text-muted">
                            아직 프로젝트가 없습니다. 위에서 템플릿을 고르거나 AI로 시작해 보세요.
                        </div>
                    ) : (
                        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
                            {projects.map((p) => (
                                <div key={p.id} className="group relative rounded-xl border border-line bg-panel transition hover:border-accent">
                                    <Link href={`/project/${p.id}`}>
                                        <Thumbnail src={`/p/${p.id}?v=${encodeURIComponent(p.updatedAt)}`} />
                                    </Link>
                                    <div className="flex items-center justify-between px-4 py-3">
                                        <Link href={`/project/${p.id}`} className="min-w-0">
                                            <div className="truncate text-sm font-medium">{p.name}</div>
                                            <div className="text-xs text-muted">{timeAgo(p.updatedAt)} 수정</div>
                                        </Link>
                                        <button
                                            aria-label="더보기"
                                            onClick={(e) => {
                                                e.stopPropagation();
                                                setMenu(menu === p.id ? null : p.id);
                                            }}
                                            className="ol-btn"
                                        >
                                            <MoreHorizontal className="h-4 w-4" />
                                        </button>
                                    </div>
                                    {menu === p.id && (
                                        <div onClick={(e) => e.stopPropagation()} className="absolute bottom-12 right-3 z-10 w-40 rounded-lg border border-line bg-panel-2 p-1 shadow-xl">
                                            <button onClick={() => rename(p)} className="ol-btn w-full justify-start"><Pencil className="h-3.5 w-3.5" /> 이름 바꾸기</button>
                                            <button onClick={() => duplicate(p)} className="ol-btn w-full justify-start"><Copy className="h-3.5 w-3.5" /> 복제</button>
                                            <a href={`/p/${p.id}`} target="_blank" rel="noreferrer" className="ol-btn w-full justify-start"><ExternalLink className="h-3.5 w-3.5" /> 게시 페이지 열기</a>
                                            <button onClick={() => remove(p)} className="ol-btn w-full justify-start text-red-400"><Trash2 className="h-3.5 w-3.5" /> 삭제</button>
                                        </div>
                                    )}
                                </div>
                            ))}
                        </div>
                    )}
                </section>
            </main>
        </div>
    );
}
