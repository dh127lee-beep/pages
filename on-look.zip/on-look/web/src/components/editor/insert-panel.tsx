'use client';

import { Columns2, Heading, Image as ImageIcon, LayoutPanelTop, Link2, Minus, MousePointerClick, Square, SquareStack, TextCursorInput, Type } from 'lucide-react';
import { useState } from 'react';

export type InsertPosition = 'after' | 'inside';

const BLOCKS = [
    { id: 'heading', label: '제목', icon: Heading, html: '<h2 class="text-3xl font-bold tracking-tight">새 제목</h2>' },
    { id: 'text', label: '텍스트', icon: Type, html: '<p class="text-base leading-relaxed text-slate-600">여기에 내용을 입력하세요. 더블클릭하면 바로 수정할 수 있습니다.</p>' },
    { id: 'button', label: '버튼', icon: MousePointerClick, html: '<a href="#" class="inline-block rounded-lg bg-indigo-600 px-5 py-2.5 text-sm font-medium text-white hover:bg-indigo-500">버튼</a>' },
    { id: 'link', label: '링크', icon: Link2, html: '<a href="#" class="text-indigo-600 underline underline-offset-4">링크 텍스트</a>' },
    { id: 'image', label: '이미지', icon: ImageIcon, html: '<img src="https://picsum.photos/seed/onlook-img/800/500" alt="이미지 설명" class="w-full rounded-xl object-cover">' },
    { id: 'box', label: '컨테이너', icon: Square, html: '<div class="rounded-xl border border-slate-200 p-6"><p>컨테이너</p></div>' },
    { id: 'divider', label: '구분선', icon: Minus, html: '<hr class="my-8 border-slate-200">' },
    { id: 'input', label: '입력 폼', icon: TextCursorInput, html: '<form class="flex max-w-md gap-2"><input type="email" placeholder="이메일 주소" class="flex-1 rounded-lg border border-slate-300 px-3 py-2"><button class="rounded-lg bg-slate-900 px-4 py-2 text-white">구독</button></form>' },
    {
        id: 'hero', label: '히어로 섹션', icon: LayoutPanelTop,
        html: '<section class="px-6 py-24 text-center"><h1 class="text-5xl font-bold tracking-tight">멋진 헤드라인</h1><p class="mx-auto mt-4 max-w-xl text-lg text-slate-500">한두 문장으로 핵심 가치를 설명하세요.</p><div class="mt-8 flex justify-center gap-3"><a href="#" class="rounded-lg bg-indigo-600 px-5 py-3 font-medium text-white">시작하기</a><a href="#" class="rounded-lg border border-slate-300 px-5 py-3 font-medium">더 알아보기</a></div></section>',
    },
    {
        id: 'cards', label: '카드 3개', icon: SquareStack,
        html: '<section class="mx-auto grid max-w-5xl gap-6 px-6 py-16 md:grid-cols-3"><div class="rounded-2xl border border-slate-200 p-6"><h3 class="text-lg font-semibold">첫 번째</h3><p class="mt-2 text-sm text-slate-500">설명을 입력하세요.</p></div><div class="rounded-2xl border border-slate-200 p-6"><h3 class="text-lg font-semibold">두 번째</h3><p class="mt-2 text-sm text-slate-500">설명을 입력하세요.</p></div><div class="rounded-2xl border border-slate-200 p-6"><h3 class="text-lg font-semibold">세 번째</h3><p class="mt-2 text-sm text-slate-500">설명을 입력하세요.</p></div></section>',
    },
    {
        id: 'split', label: '2단 레이아웃', icon: Columns2,
        html: '<section class="mx-auto grid max-w-5xl items-center gap-10 px-6 py-16 md:grid-cols-2"><div><h2 class="text-3xl font-bold">왼쪽 제목</h2><p class="mt-4 text-slate-500">이미지와 함께 기능이나 이야기를 소개하세요.</p></div><img src="https://picsum.photos/seed/onlook-split/800/600" alt="" class="rounded-2xl"></section>',
    },
];

export function InsertPanel({ hasSelection, onInsert }: { hasSelection: boolean; onInsert: (html: string, position: InsertPosition) => void }) {
    const [position, setPosition] = useState<InsertPosition>('after');
    return (
        <div className="space-y-3 p-3">
            <div className="grid grid-cols-2 gap-1 rounded-lg bg-panel-2 p-1 text-xs">
                {(['after', 'inside'] as const).map((p) => (
                    <button key={p} onClick={() => setPosition(p)} className={`rounded-md py-1 ${position === p ? 'bg-accent text-white' : 'text-muted'}`}>
                        {p === 'after' ? '선택 요소 다음에' : '선택 요소 안에'}
                    </button>
                ))}
            </div>
            {!hasSelection && <p className="text-[11px] text-muted">선택한 요소가 없으면 페이지 맨 아래에 추가됩니다.</p>}
            <div className="grid grid-cols-2 gap-2">
                {BLOCKS.map((b) => (
                    <button
                        key={b.id}
                        onClick={() => onInsert(b.html, position)}
                        className="flex flex-col items-center gap-1.5 rounded-lg border border-line bg-panel-2 px-2 py-3 text-xs text-foreground/85 transition hover:border-accent hover:text-foreground"
                    >
                        <b.icon className="h-4 w-4" />
                        {b.label}
                    </button>
                ))}
            </div>
        </div>
    );
}
