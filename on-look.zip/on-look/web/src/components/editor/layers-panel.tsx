'use client';

import { ChevronRight } from 'lucide-react';
import { useEffect, useState } from 'react';
import type { TreeNode } from '@/lib/types';

type DropPosition = 'before' | 'after' | 'inside';

interface Props {
    tree: TreeNode | null;
    selectedOid: string | null;
    selectedPath: string[];
    hoveredOid: string | null;
    onSelect: (oid: string) => void;
    onHover: (oid: string | null) => void;
    onMove: (oid: string, targetOid: string, position: DropPosition) => void;
}

const TAG_COLORS: Record<string, string> = {
    section: 'text-sky-400', header: 'text-sky-400', footer: 'text-sky-400', main: 'text-sky-400', nav: 'text-sky-400',
    div: 'text-slate-400', h1: 'text-amber-300', h2: 'text-amber-300', h3: 'text-amber-300', p: 'text-amber-200',
    a: 'text-emerald-300', button: 'text-emerald-300', img: 'text-pink-300',
};

export function LayersPanel({ tree, selectedOid, selectedPath, hoveredOid, onSelect, onHover, onMove }: Props) {
    const [collapsed, setCollapsed] = useState<Set<string>>(new Set());
    const [drag, setDrag] = useState<string | null>(null);
    const [drop, setDrop] = useState<{ oid: string; position: DropPosition } | null>(null);

    // Reveal the selected element by expanding its ancestors.
    useEffect(() => {
        if (!selectedPath.length) return;
        setCollapsed((prev) => {
            if (!selectedPath.some((oid) => prev.has(oid))) return prev;
            const next = new Set(prev);
            selectedPath.forEach((oid) => next.delete(oid));
            return next;
        });
        if (selectedOid) {
            document.querySelector(`[data-layer="${selectedOid}"]`)?.scrollIntoView({ block: 'nearest' });
        }
    }, [selectedOid, selectedPath]);

    if (!tree) return <div className="p-4 text-xs text-muted">페이지를 불러오는 중…</div>;

    const toggle = (oid: string) =>
        setCollapsed((prev) => {
            const next = new Set(prev);
            if (next.has(oid)) next.delete(oid);
            else next.add(oid);
            return next;
        });

    const render = (node: TreeNode, depth: number) => {
        const isCollapsed = collapsed.has(node.oid);
        const isSelected = node.oid === selectedOid;
        const isHovered = node.oid === hoveredOid;
        const isDropTarget = drop?.oid === node.oid;
        return (
            <div key={node.oid}>
                <div
                    data-layer={node.oid}
                    draggable={depth > 0}
                    onDragStart={(e) => {
                        setDrag(node.oid);
                        e.dataTransfer.effectAllowed = 'move';
                    }}
                    onDragEnd={() => {
                        setDrag(null);
                        setDrop(null);
                    }}
                    onDragOver={(e) => {
                        if (!drag || drag === node.oid) return;
                        e.preventDefault();
                        const rect = e.currentTarget.getBoundingClientRect();
                        const y = (e.clientY - rect.top) / rect.height;
                        const position: DropPosition = depth === 0 ? 'inside' : y < 0.3 ? 'before' : y > 0.7 ? 'after' : 'inside';
                        setDrop({ oid: node.oid, position });
                    }}
                    onDrop={(e) => {
                        e.preventDefault();
                        if (drag && drop) onMove(drag, drop.oid, drop.position);
                        setDrag(null);
                        setDrop(null);
                    }}
                    onClick={() => onSelect(node.oid)}
                    onMouseEnter={() => onHover(node.oid)}
                    onMouseLeave={() => onHover(null)}
                    style={{ paddingLeft: 6 + depth * 12 }}
                    className={[
                        'group flex h-7 cursor-pointer items-center gap-1 rounded-md pr-2 text-xs',
                        isSelected ? 'bg-accent/25 text-foreground' : isHovered ? 'bg-panel-2' : 'text-foreground/85',
                        isDropTarget && drop.position === 'inside' ? 'ring-1 ring-accent' : '',
                        isDropTarget && drop.position === 'before' ? 'shadow-[inset_0_2px_0_0_var(--accent)]' : '',
                        isDropTarget && drop.position === 'after' ? 'shadow-[inset_0_-2px_0_0_var(--accent)]' : '',
                        drag === node.oid ? 'opacity-40' : '',
                    ].join(' ')}
                >
                    <button
                        aria-label={isCollapsed ? '펼치기' : '접기'}
                        onClick={(e) => {
                            e.stopPropagation();
                            toggle(node.oid);
                        }}
                        className={`grid h-4 w-4 place-items-center rounded text-muted hover:text-foreground ${node.children.length ? '' : 'invisible'}`}
                    >
                        <ChevronRight className={`h-3 w-3 transition ${isCollapsed ? '' : 'rotate-90'}`} />
                    </button>
                    <span className={`font-mono ${TAG_COLORS[node.tag] ?? 'text-violet-300'}`}>{node.label}</span>
                    {node.text && <span className="truncate text-muted">{node.text}</span>}
                </div>
                {!isCollapsed && node.children.map((c) => render(c, depth + 1))}
            </div>
        );
    };

    return <div className="p-2">{render(tree, 0)}</div>;
}
