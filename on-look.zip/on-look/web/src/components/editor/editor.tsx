'use client';

import {
    Check, Code2, Download, ExternalLink, Eye, FileStack, Layers, Loader2, Monitor, MousePointer2, Plus, Redo2, RotateCw, Smartphone, Sparkles, SlidersHorizontal, Tablet, Undo2, X,
} from 'lucide-react';
import { nanoid } from 'nanoid';
import Link from 'next/link';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { slugify, withPreload } from '@/lib/html';
import { buildPageDocument, rewritePageLinks } from '@/lib/page-doc';
import { pageUrl, pathFromName } from '@/lib/pages';
import type { ElementInfo, Page, Project, TreeNode } from '@/lib/types';
import { createZip } from '@/lib/zip';
import { AiPanel, type AiScope } from './ai-panel';
import { InsertPanel, type InsertPosition } from './insert-panel';
import { LayersPanel } from './layers-panel';
import { PagesPanel } from './pages-panel';
import { StylePanel } from './style-panel';

type Mode = 'design' | 'preview' | 'code';
type Device = 'desktop' | 'tablet' | 'mobile';
type SaveState = 'saved' | 'dirty' | 'saving' | 'error';
type LeftTab = 'pages' | 'layers' | 'insert';

const DEVICE_WIDTH: Record<Device, string> = { desktop: '100%', tablet: '768px', mobile: '390px' };
const HISTORY_LIMIT = 100;
const HISTORY_MERGE_MS = 500;

interface History {
    stack: string[];
    index: number;
    lastPush: number;
}

interface PreloadMessage {
    source: 'ol-preload';
    type: 'ready' | 'change' | 'select' | 'hover' | 'key' | 'response' | 'editing';
    payload: unknown;
}

/** A new page reuses the current page's <head> (Tailwind, fonts, meta) with an empty body. */
function blankPageFrom(source: string, title: string): string {
    const head = source.match(/<head[\s\S]*?<\/head>/i)?.[0] ?? '<head>\n<meta charset="utf-8">\n<script src="https://cdn.tailwindcss.com"></script>\n</head>';
    const bodyClass = source.match(/<body[^>]*class="([^"]*)"/i)?.[1] ?? 'bg-white text-slate-900';
    const safe = title.replace(/[<>&"]/g, '');
    return `<!DOCTYPE html>\n<html lang="ko">\n${head.replace(/<title>[\s\S]*?<\/title>/i, `<title>${safe}</title>`)}\n<body class="${bodyClass}">\n  <main class="max-w-3xl mx-auto px-6 py-24">\n    <h1 class="text-4xl font-bold tracking-tight">${safe}</h1>\n    <p class="mt-4 text-slate-500">새 페이지입니다. 요소를 추가하거나 AI에게 내용을 맡겨 보세요.</p>\n    <a href="index" class="mt-8 inline-block text-indigo-500 underline underline-offset-4">← 홈으로</a>\n  </main>\n</body>\n</html>`;
}

export function Editor({ project, initialPrompt }: { project: Project; initialPrompt?: string }) {
    const iframeRef = useRef<HTMLIFrameElement>(null);
    const [name, setName] = useState(project.name);
    const [pages, setPages] = useState<Page[]>(project.pages);
    const [currentId, setCurrentId] = useState(() => (project.pages.find((p) => p.path === 'index') ?? project.pages[0]).id);
    const current = pages.find((p) => p.id === currentId) ?? pages[0];
    const html = current.html;
    const [frame, setFrame] = useState({ html: current.html, key: 0 });
    const [tree, setTree] = useState<TreeNode | null>(null);
    const [selected, setSelected] = useState<ElementInfo | null>(null);
    const [hovered, setHovered] = useState<string | null>(null);
    const [mode, setMode] = useState<Mode>('design');
    const [device, setDevice] = useState<Device>('desktop');
    const [leftTab, setLeftTab] = useState<LeftTab>(project.pages.length > 1 ? 'pages' : 'layers');
    const [rightTab, setRightTab] = useState<'style' | 'ai'>(initialPrompt ? 'ai' : 'style');
    const [saveState, setSaveState] = useState<SaveState>('saved');
    const [codeTab, setCodeTab] = useState<'html' | 'js'>('html');
    const [codeDraft, setCodeDraft] = useState({ html: '', js: '' });
    const [previewKey, setPreviewKey] = useState(0);
    const [, forceRender] = useState(0);

    const histories = useRef(new Map<string, History>());
    const pendingSelect = useRef<string | null>(null);
    const pending = useRef(new Map<string, (data: unknown) => void>());
    const saved = useRef(JSON.stringify({ name: project.name, pages: project.pages }));
    const selectedRef = useRef(selected);
    selectedRef.current = selected;
    const currentIdRef = useRef(currentId);
    currentIdRef.current = currentId;
    const pagesRef = useRef(pages);
    pagesRef.current = pages;

    const historyFor = useCallback((pageId: string): History => {
        let h = histories.current.get(pageId);
        if (!h) {
            const page = pagesRef.current.find((p) => p.id === pageId);
            h = { stack: [page?.html ?? ''], index: 0, lastPush: 0 };
            histories.current.set(pageId, h);
        }
        return h;
    }, []);

    const updatePage = useCallback((pageId: string, patch: Partial<Page>) => {
        setPages((ps) => ps.map((p) => (p.id === pageId ? { ...p, ...patch } : p)));
    }, []);

    const setHtml = useCallback((next: string) => updatePage(currentIdRef.current, { html: next }), [updatePage]);

    const send = useCallback((type: string, payload: object = {}) => {
        iframeRef.current?.contentWindow?.postMessage({ target: 'ol-preload', type, payload }, '*');
    }, []);

    const request = useCallback(
        <T,>(type: string, payload: object): Promise<T | null> =>
            new Promise((resolve) => {
                const reqId = Math.random().toString(36).slice(2);
                const timer = setTimeout(() => {
                    pending.current.delete(reqId);
                    resolve(null);
                }, 3000);
                pending.current.set(reqId, (data) => {
                    clearTimeout(timer);
                    resolve(data as T);
                });
                send(type, { ...payload, reqId });
            }),
        [send],
    );

    /* ---------- history (per page) ---------- */

    const pushHistory = useCallback(
        (next: string) => {
            const h = historyFor(currentIdRef.current);
            if (h.stack[h.index] === next) return;
            const now = Date.now();
            h.stack = h.stack.slice(0, h.index + 1);
            if (now - h.lastPush < HISTORY_MERGE_MS && h.index > 0) h.stack[h.index] = next;
            else h.stack.push(next);
            if (h.stack.length > HISTORY_LIMIT) h.stack.shift();
            h.index = h.stack.length - 1;
            h.lastPush = now;
            forceRender((n) => n + 1);
        },
        [historyFor],
    );

    /** Load new HTML into the canvas (undo/redo, code edits, AI page rewrites, page switches). */
    const loadIntoFrame = useCallback(
        (next: string, keepSelection: boolean) => {
            pendingSelect.current = keepSelection ? selectedRef.current?.oid ?? null : null;
            setHtml(next);
            setFrame((f) => ({ html: next, key: f.key + 1 }));
            if (!keepSelection) setSelected(null);
        },
        [setHtml],
    );

    const commitExternal = useCallback(
        (next: string) => {
            const h = historyFor(currentIdRef.current);
            h.lastPush = 0;
            pushHistory(next);
            h.lastPush = 0;
            loadIntoFrame(next, false);
        },
        [historyFor, loadIntoFrame, pushHistory],
    );

    const undo = useCallback(() => {
        const h = historyFor(currentIdRef.current);
        if (h.index === 0) return;
        h.index -= 1;
        h.lastPush = 0;
        loadIntoFrame(h.stack[h.index], true);
        forceRender((n) => n + 1);
    }, [historyFor, loadIntoFrame]);

    const redo = useCallback(() => {
        const h = historyFor(currentIdRef.current);
        if (h.index >= h.stack.length - 1) return;
        h.index += 1;
        h.lastPush = 0;
        loadIntoFrame(h.stack[h.index], true);
        forceRender((n) => n + 1);
    }, [historyFor, loadIntoFrame]);

    /* ---------- persistence ---------- */

    const snapshot = useMemo(() => JSON.stringify({ name, pages }), [name, pages]);

    const save = useCallback(async () => {
        if (snapshot === saved.current) {
            setSaveState('saved');
            return true;
        }
        setSaveState('saving');
        try {
            const res = await fetch(`/api/projects/${project.id}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: snapshot,
            });
            if (!res.ok) throw new Error();
            saved.current = snapshot;
            setSaveState('saved');
            return true;
        } catch {
            setSaveState('error');
            return false;
        }
    }, [project.id, snapshot]);

    useEffect(() => {
        if (snapshot === saved.current) return;
        setSaveState('dirty');
        const t = setTimeout(save, 800);
        return () => clearTimeout(t);
    }, [snapshot, save]);

    useEffect(() => {
        const warn = (e: BeforeUnloadEvent) => {
            if (snapshot !== saved.current) e.preventDefault();
        };
        window.addEventListener('beforeunload', warn);
        return () => window.removeEventListener('beforeunload', warn);
    }, [snapshot]);

    /* ---------- pages ---------- */

    const openPage = useCallback(
        (pageId: string) => {
            const page = pagesRef.current.find((p) => p.id === pageId);
            if (!page) return;
            setCurrentId(pageId);
            currentIdRef.current = pageId;
            setSelected(null);
            setHovered(null);
            setTree(null);
            pendingSelect.current = null;
            setFrame((f) => ({ html: page.html, key: f.key + 1 }));
            setCodeDraft({ html: page.html, js: page.script });
            setPreviewKey((k) => k + 1);
        },
        [],
    );

    function addPage(pageName: string) {
        const page: Page = {
            id: nanoid(8),
            name: pageName,
            path: pathFromName(pageName, pages.map((p) => p.path)),
            html: blankPageFrom(html, pageName),
            script: '',
        };
        pagesRef.current = [...pages, page];
        setPages(pagesRef.current);
        openPage(page.id);
    }

    function renamePage(pageId: string, patch: { name?: string; path?: string }): string | null {
        const page = pages.find((p) => p.id === pageId);
        if (!page) return null;
        const newPath = page.path === 'index' ? 'index' : patch.path ?? page.path;
        if (pages.some((p) => p.id !== pageId && p.path === newPath)) return '같은 주소의 페이지가 이미 있습니다.';
        let next = pages.map((p) => (p.id === pageId ? { ...p, name: patch.name ?? p.name, path: newPath } : p));
        if (newPath !== page.path) {
            // Keep links working: point every link to the old path at the new one.
            next = next.map((p) => ({ ...p, html: rewritePageLinks(p.html, [{ path: page.path }], () => newPath) }));
            const cur = next.find((p) => p.id === currentId);
            if (cur && cur.html !== html) {
                historyFor(currentId).lastPush = 0;
                pushHistory(cur.html);
                setFrame((f) => ({ html: cur.html, key: f.key + 1 }));
            }
        }
        setPages(next);
        return null;
    }

    function duplicatePage(pageId: string) {
        const page = pages.find((p) => p.id === pageId);
        if (!page) return;
        const copy: Page = { ...page, id: nanoid(8), name: `${page.name} 사본`, path: pathFromName(`${page.path === 'index' ? 'home' : page.path}-copy`, pages.map((p) => p.path)) };
        const index = pages.findIndex((p) => p.id === pageId);
        setPages([...pages.slice(0, index + 1), copy, ...pages.slice(index + 1)]);
    }

    function deletePage(pageId: string) {
        const page = pages.find((p) => p.id === pageId);
        if (!page || page.path === 'index') return;
        const next = pages.filter((p) => p.id !== pageId);
        pagesRef.current = next;
        setPages(next);
        histories.current.delete(pageId);
        if (pageId === currentId) openPage(next.find((p) => p.path === 'index')!.id);
    }

    /* ---------- element actions ---------- */

    const action = useCallback(
        (kind: 'parent' | 'up' | 'down' | 'duplicate' | 'remove') => {
            const oid = selectedRef.current?.oid;
            if (!oid) return;
            if (kind === 'parent') send('selectParent');
            else if (kind === 'up') send('move', { oid, dir: -1 });
            else if (kind === 'down') send('move', { oid, dir: 1 });
            else if (kind === 'duplicate') send('duplicate', { oid });
            else send('remove', { oid });
        },
        [send],
    );

    const handleKey = useCallback(
        (k: { key: string; meta: boolean; shift: boolean; alt: boolean }) => {
            const key = k.key.toLowerCase();
            if (k.meta && key === 'z') return k.shift ? redo() : undo();
            if (k.meta && key === 'y') return redo();
            if (k.meta && key === 's') return void save();
            if (k.meta && key === 'd') return action('duplicate');
            if (key === 'delete' || key === 'backspace') return action('remove');
            if (key === 'escape') {
                send('select', { oid: null });
                return;
            }
            if (k.alt && key === 'arrowup') return action('up');
            if (k.alt && key === 'arrowdown') return action('down');
        },
        [action, redo, save, send, undo],
    );

    /* ---------- iframe bridge ---------- */

    useEffect(() => {
        const onMessage = (e: MessageEvent) => {
            if (e.source !== iframeRef.current?.contentWindow) return;
            const msg = e.data as PreloadMessage;
            if (!msg || msg.source !== 'ol-preload') return;
            switch (msg.type) {
                case 'ready': {
                    const p = msg.payload as { tree: TreeNode };
                    setTree(p.tree);
                    if (pendingSelect.current) {
                        send('select', { oid: pendingSelect.current });
                        pendingSelect.current = null;
                    }
                    break;
                }
                case 'change': {
                    const p = msg.payload as { html: string; tree: TreeNode; selected: ElementInfo | null };
                    setHtml(p.html);
                    setTree(p.tree);
                    setSelected(p.selected);
                    pushHistory(p.html);
                    break;
                }
                case 'select':
                    setSelected(msg.payload as ElementInfo | null);
                    break;
                case 'hover':
                    setHovered(msg.payload as string | null);
                    break;
                case 'key':
                    handleKey(msg.payload as { key: string; meta: boolean; shift: boolean; alt: boolean });
                    break;
                case 'response': {
                    const p = msg.payload as { reqId: string; data: unknown };
                    pending.current.get(p.reqId)?.(p.data);
                    pending.current.delete(p.reqId);
                    break;
                }
            }
        };
        window.addEventListener('message', onMessage);
        return () => window.removeEventListener('message', onMessage);
    }, [handleKey, pushHistory, send, setHtml]);

    // Shortcuts while focus is in the editor chrome (not in a text field).
    useEffect(() => {
        const onKey = (e: KeyboardEvent) => {
            const t = e.target as HTMLElement;
            if (t.closest('input, textarea, select, [contenteditable]')) return;
            if (mode !== 'design') return;
            const meta = e.metaKey || e.ctrlKey;
            const key = e.key.toLowerCase();
            const handled = (meta && ['z', 'y', 's', 'd'].includes(key)) || ['delete', 'backspace', 'escape'].includes(key) || (e.altKey && key.startsWith('arrow'));
            if (!handled) return;
            e.preventDefault();
            handleKey({ key: e.key, meta, shift: e.shiftKey, alt: e.altKey });
        };
        window.addEventListener('keydown', onKey);
        return () => window.removeEventListener('keydown', onKey);
    }, [handleKey, mode]);

    /* ---------- AI ---------- */

    const getAiSource = useCallback(
        async (scope: AiScope) => {
            if (scope === 'element' && selectedRef.current) return request<string>('getOuter', { oid: selectedRef.current.oid });
            return html;
        },
        [html, request],
    );

    const getAiContext = useCallback(
        () => ({ pages: pages.map(({ name: n, path }) => ({ name: n, path })), currentPath: current.path, script: current.script }),
        [current.path, current.script, pages],
    );

    const applyAi = useCallback(
        (scope: AiScope, result: string, script: string | null) => {
            if (scope === 'element' && selectedRef.current) {
                send('replace', { oid: selectedRef.current.oid, html: result });
                return;
            }
            commitExternal(result);
            if (script !== null) updatePage(currentIdRef.current, { script });
        },
        [commitExternal, send, updatePage],
    );

    /* ---------- modes, preview, export ---------- */

    async function switchMode(next: Mode) {
        if (next === mode) return;
        if (next === 'code') {
            setCodeDraft({ html, js: current.script });
            setCodeTab('html');
        }
        if (next === 'preview') {
            // Preview renders the real published page, so persist pending edits first.
            await save();
            setPreviewKey((k) => k + 1);
        }
        // The canvas iframe unmounts outside design mode; remount it with the latest HTML.
        if (next === 'design') loadIntoFrame(html, true);
        setMode(next);
    }

    function applyCode() {
        if (codeDraft.js !== current.script) updatePage(currentId, { script: codeDraft.js });
        if (codeDraft.html !== html) {
            commitExternal(codeDraft.html);
            setMode('design');
        } else switchMode('design');
    }

    async function exportZip() {
        const runtime = await fetch('/ol-runtime.js').then((r) => r.text());
        const files = pages.map((page) => ({
            name: `${page.path}.html`,
            content: buildPageDocument(page, pages, { linkFor: (p) => `${p}.html`, runtime: { src: 'ol-runtime.js' } }),
        }));
        files.push({ name: 'ol-runtime.js', content: runtime });
        const url = URL.createObjectURL(createZip(files));
        const a = document.createElement('a');
        a.href = url;
        a.download = `${slugify(name)}.zip`;
        a.click();
        setTimeout(() => URL.revokeObjectURL(url), 1000);
    }

    async function openPublished() {
        await save();
        window.open(pageUrl(project.id, current.path), '_blank', 'noopener');
    }

    const srcDoc = useMemo(() => withPreload(frame.html), [frame.html]);
    const selectedPath = useMemo(() => selected?.path.map((p) => p.oid) ?? [], [selected]);
    const h = historyFor(currentId);
    const canUndo = h.index > 0;
    const canRedo = h.index < h.stack.length - 1;
    const selectedLabel = selected ? selected.path[selected.path.length - 1]?.label ?? selected.tag : null;
    const pageLinks = useMemo(() => pages.map(({ name: n, path }) => ({ name: n, path })), [pages]);

    return (
        <div className="flex h-screen flex-col overflow-hidden">
            {/* Top bar */}
            <header className="flex h-12 shrink-0 items-center gap-2 border-b border-line bg-panel px-3">
                <Link href="/" className="grid h-7 w-7 place-items-center rounded-lg bg-accent text-sm" title="대시보드">◎</Link>
                <input
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-40 rounded-md bg-transparent px-2 py-1 text-sm font-medium outline-none hover:bg-panel-2 focus:bg-panel-2"
                    aria-label="프로젝트 이름"
                />
                <select
                    value={currentId}
                    onChange={(e) => openPage(e.target.value)}
                    className="max-w-40 rounded-md border border-line bg-panel-2 px-2 py-1 text-xs outline-none"
                    aria-label="현재 페이지"
                >
                    {pages.map((p) => (
                        <option key={p.id} value={p.id}>{p.name} · /{p.path === 'index' ? '' : p.path}</option>
                    ))}
                </select>
                <span className="flex items-center gap-1 text-[11px] text-muted" aria-live="polite">
                    {saveState === 'saving' && <><Loader2 className="h-3 w-3 animate-spin" /> 저장 중</>}
                    {saveState === 'saved' && <><Check className="h-3 w-3" /> 저장됨</>}
                    {saveState === 'dirty' && '변경됨'}
                    {saveState === 'error' && <span className="text-red-400">저장 실패 — ⌘S로 재시도</span>}
                </span>

                <div className="mx-auto flex items-center gap-1 rounded-lg bg-panel-2 p-0.5">
                    {([['design', MousePointer2, '디자인'], ['preview', Eye, '미리보기'], ['code', Code2, '코드']] as const).map(([m, Icon, label]) => (
                        <button key={m} onClick={() => switchMode(m)} className={`ol-btn ${mode === m ? 'bg-background' : 'text-muted'}`}>
                            <Icon className="h-3.5 w-3.5" /> {label}
                        </button>
                    ))}
                </div>

                <div className="flex items-center gap-0.5">
                    {([['desktop', Monitor], ['tablet', Tablet], ['mobile', Smartphone]] as const).map(([d, Icon]) => (
                        <button key={d} title={d} onClick={() => setDevice(d)} className={`ol-btn px-2 ${device === d ? 'bg-panel-2' : 'text-muted'}`}>
                            <Icon className="h-4 w-4" />
                        </button>
                    ))}
                </div>
                <div className="h-5 w-px bg-line" />
                <button className="ol-btn px-2" title="실행 취소 (⌘Z)" onClick={undo} disabled={!canUndo || mode !== 'design'}><Undo2 className="h-4 w-4" /></button>
                <button className="ol-btn px-2" title="다시 실행 (⇧⌘Z)" onClick={redo} disabled={!canRedo || mode !== 'design'}><Redo2 className="h-4 w-4" /></button>
                <div className="h-5 w-px bg-line" />
                <button className="ol-btn" onClick={exportZip} title="모든 페이지를 ZIP으로 내보내기"><Download className="h-3.5 w-3.5" /> 내보내기</button>
                <button className="ol-btn bg-accent hover:bg-accent/80" onClick={openPublished}><ExternalLink className="h-3.5 w-3.5" /> 게시 페이지</button>
            </header>

            <div className="flex min-h-0 flex-1">
                {/* Left panel */}
                {mode === 'design' && (
                    <aside className="flex w-60 shrink-0 flex-col border-r border-line bg-panel">
                        <div className="flex border-b border-line">
                            {([['pages', FileStack, '페이지'], ['layers', Layers, '레이어'], ['insert', Plus, '추가']] as const).map(([t, Icon, label]) => (
                                <button key={t} onClick={() => setLeftTab(t)} className={`flex flex-1 items-center justify-center gap-1 py-2.5 text-xs ${leftTab === t ? 'border-b-2 border-accent text-foreground' : 'text-muted'}`}>
                                    <Icon className="h-3.5 w-3.5" /> {label}
                                </button>
                            ))}
                        </div>
                        <div className="ol-scroll min-h-0 flex-1 overflow-y-auto">
                            {leftTab === 'pages' && (
                                <PagesPanel
                                    pages={pages}
                                    currentId={currentId}
                                    onOpen={openPage}
                                    onAdd={addPage}
                                    onUpdate={renamePage}
                                    onDuplicate={duplicatePage}
                                    onDelete={deletePage}
                                />
                            )}
                            {leftTab === 'layers' && (
                                <LayersPanel
                                    tree={tree}
                                    selectedOid={selected?.oid ?? null}
                                    selectedPath={selectedPath}
                                    hoveredOid={hovered}
                                    onSelect={(oid) => send('select', { oid })}
                                    onHover={(oid) => send('hover', { oid })}
                                    onMove={(oid, targetOid, position) => send('moveTo', { oid, targetOid, position })}
                                />
                            )}
                            {leftTab === 'insert' && (
                                <InsertPanel
                                    hasSelection={!!selected}
                                    onInsert={(blockHtml: string, position: InsertPosition) =>
                                        send('insert', { oid: selected?.oid ?? null, html: blockHtml, position: selected ? position : 'inside' })
                                    }
                                />
                            )}
                        </div>
                    </aside>
                )}

                {/* Canvas */}
                <main className="relative min-w-0 flex-1 bg-[#07070a]">
                    {mode === 'code' ? (
                        <div className="flex h-full flex-col">
                            <div className="flex items-center justify-between border-b border-line bg-panel px-3 py-2 text-xs text-muted">
                                <div className="flex items-center gap-1 rounded-lg bg-panel-2 p-0.5">
                                    <button onClick={() => setCodeTab('html')} className={`ol-btn ${codeTab === 'html' ? 'bg-background' : 'text-muted'}`}>{current.path}.html</button>
                                    <button onClick={() => setCodeTab('js')} className={`ol-btn ${codeTab === 'js' ? 'bg-background' : 'text-muted'}`}>
                                        JavaScript{current.script.trim() ? ' ●' : ''}
                                    </button>
                                </div>
                                <span className="hidden lg:inline">
                                    {codeTab === 'js'
                                        ? '페이지 스크립트는 미리보기·게시 페이지에서 실행됩니다. ol.getJSON(url)로 외부 API를 부를 수 있습니다.'
                                        : '직접 수정한 뒤 적용하세요'}
                                </span>
                                <div className="flex gap-2">
                                    <button className="ol-btn" onClick={() => switchMode('design')}><X className="h-3.5 w-3.5" /> 취소</button>
                                    <button className="ol-btn bg-accent hover:bg-accent/80" onClick={applyCode}><Check className="h-3.5 w-3.5" /> 적용</button>
                                </div>
                            </div>
                            <textarea
                                key={codeTab}
                                value={codeTab === 'html' ? codeDraft.html : codeDraft.js}
                                onChange={(e) => setCodeDraft((d) => ({ ...d, [codeTab]: e.target.value }))}
                                spellCheck={false}
                                placeholder={codeTab === 'js' ? "// 예: 버튼 클릭 처리\ndocument.querySelector('#cta')?.addEventListener('click', () => alert('안녕하세요!'));\n\n// 예: API 데이터 불러오기\nconst users = await ol.getJSON('https://jsonplaceholder.typicode.com/users');" : ''}
                                onKeyDown={(e) => {
                                    if (e.key === 'Tab') {
                                        e.preventDefault();
                                        const t = e.currentTarget;
                                        const { selectionStart: s, selectionEnd: end } = t;
                                        const value = t.value.slice(0, s) + '  ' + t.value.slice(end);
                                        setCodeDraft((d) => ({ ...d, [codeTab]: value }));
                                        requestAnimationFrame(() => t.setSelectionRange(s + 2, s + 2));
                                    }
                                }}
                                className="ol-scroll flex-1 resize-none bg-[#0d0d12] p-4 font-mono text-xs leading-relaxed text-slate-200 outline-none placeholder:text-slate-600"
                            />
                        </div>
                    ) : (
                        <div className="ol-scroll flex h-full flex-col items-center overflow-auto p-6">
                            {mode === 'preview' && (
                                <div className="mb-2 flex w-full max-w-full items-center gap-2 text-[11px] text-muted" style={{ width: DEVICE_WIDTH[device] }}>
                                    <span className="rounded bg-emerald-500/15 px-1.5 py-0.5 text-emerald-300">실행 중</span>
                                    링크·버튼·스크립트·API 데이터가 실제로 동작합니다.
                                    <button className="ol-btn ml-auto px-1.5" title="새로고침" onClick={() => setPreviewKey((k) => k + 1)}><RotateCw className="h-3.5 w-3.5" /></button>
                                </div>
                            )}
                            <div
                                className="min-h-0 flex-1 shrink-0 overflow-hidden rounded-lg bg-white shadow-2xl ring-1 ring-white/10 transition-[width] duration-300"
                                style={{ width: DEVICE_WIDTH[device], maxWidth: '100%' }}
                            >
                                {mode === 'design' ? (
                                    <iframe
                                        key={frame.key}
                                        ref={iframeRef}
                                        title="캔버스"
                                        srcDoc={srcDoc}
                                        sandbox="allow-scripts"
                                        className="h-full w-full border-0"
                                    />
                                ) : (
                                    <iframe
                                        key={previewKey}
                                        title="미리보기"
                                        src={pageUrl(project.id, current.path)}
                                        sandbox="allow-scripts allow-popups allow-forms"
                                        className="h-full w-full border-0"
                                    />
                                )}
                            </div>
                        </div>
                    )}
                </main>

                {/* Right panel */}
                {mode === 'design' && (
                    <aside className="flex w-72 shrink-0 flex-col border-l border-line bg-panel">
                        <div className="flex border-b border-line">
                            {([['style', SlidersHorizontal, '스타일'], ['ai', Sparkles, 'AI']] as const).map(([t, Icon, label]) => (
                                <button key={t} onClick={() => setRightTab(t)} className={`flex flex-1 items-center justify-center gap-1.5 py-2.5 text-xs ${rightTab === t ? 'border-b-2 border-accent text-foreground' : 'text-muted'}`}>
                                    <Icon className="h-3.5 w-3.5" /> {label}
                                </button>
                            ))}
                        </div>
                        <div className={`ol-scroll min-h-0 flex-1 overflow-y-auto ${rightTab === 'style' ? '' : 'hidden'}`}>
                            {selected ? (
                                <StylePanel
                                    el={selected}
                                    pages={pageLinks}
                                    onStyle={(prop, value) => send('setStyle', { oid: selected.oid, prop, value })}
                                    onClass={(value) => send('setClass', { oid: selected.oid, value })}
                                    onText={(value) => send('setText', { oid: selected.oid, value })}
                                    onAttr={(attr, value) => send('setAttr', { oid: selected.oid, name: attr, value })}
                                    onSelect={(oid) => send('select', { oid })}
                                    onAction={action}
                                />
                            ) : (
                                <div className="space-y-3 p-4 text-xs leading-relaxed text-muted">
                                    <p className="text-foreground">캔버스에서 요소를 클릭해 선택하세요.</p>
                                    <ul className="space-y-1.5">
                                        <li>• 더블클릭 — 텍스트 바로 수정</li>
                                        <li>• ⌘Z / ⇧⌘Z — 실행 취소 / 다시 실행</li>
                                        <li>• ⌘D — 복제, Delete — 삭제</li>
                                        <li>• ⌥↑ / ⌥↓ — 순서 이동</li>
                                        <li>• 레이어를 드래그해서 위치 변경</li>
                                        <li>• ⚡ 표시는 API 데이터가 연결된 요소</li>
                                    </ul>
                                    <p>디자인 모드에서는 스크립트와 API 데이터가 실행되지 않습니다. <b className="text-foreground">미리보기</b>에서 실제 동작을 확인하세요.</p>
                                </div>
                            )}
                        </div>
                        <div className={`min-h-0 flex-1 ${rightTab === 'ai' ? '' : 'hidden'}`}>
                            <AiPanel
                                hasSelection={!!selected}
                                selectedLabel={selectedLabel}
                                initialPrompt={initialPrompt}
                                getSource={getAiSource}
                                getContext={getAiContext}
                                onResult={applyAi}
                            />
                        </div>
                    </aside>
                )}
            </div>
        </div>
    );
}
