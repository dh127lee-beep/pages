'use client';

import { Copy, FileText, Home, Pencil, Plus, Trash2 } from 'lucide-react';
import { useState } from 'react';
import { PAGE_PATH } from '@/lib/pages';
import type { Page } from '@/lib/types';

interface Props {
    pages: Page[];
    currentId: string;
    onOpen: (id: string) => void;
    onAdd: (name: string) => void;
    onUpdate: (id: string, patch: { name?: string; path?: string }) => string | null;
    onDuplicate: (id: string) => void;
    onDelete: (id: string) => void;
}

function PageEditor({ page, onSave, onCancel }: { page: Page; onSave: (name: string, path: string) => string | null; onCancel: () => void }) {
    const [name, setName] = useState(page.name);
    const [path, setPath] = useState(page.path);
    const [error, setError] = useState<string | null>(null);
    const isHome = page.path === 'index';
    return (
        <form
            onSubmit={(e) => {
                e.preventDefault();
                setError(onSave(name.trim(), path.trim()));
            }}
            className="space-y-1.5 rounded-lg border border-accent/50 bg-panel-2 p-2"
        >
            <input autoFocus value={name} onChange={(e) => setName(e.target.value)} placeholder="페이지 이름" className="ol-input" />
            <div className="flex items-center gap-1 font-mono text-[11px] text-muted">
                /
                <input
                    value={path}
                    disabled={isHome}
                    onChange={(e) => setPath(e.target.value.toLowerCase())}
                    placeholder="about"
                    className="ol-input font-mono disabled:opacity-50"
                />
            </div>
            {isHome && <p className="text-[10px] text-muted">홈 페이지의 주소(index)는 바꿀 수 없습니다.</p>}
            {error && <p className="text-[10px] text-red-400">{error}</p>}
            <div className="flex justify-end gap-1">
                <button type="button" onClick={onCancel} className="ol-btn">취소</button>
                <button type="submit" className="ol-btn bg-accent hover:bg-accent/80">저장</button>
            </div>
        </form>
    );
}

export function PagesPanel({ pages, currentId, onOpen, onAdd, onUpdate, onDuplicate, onDelete }: Props) {
    const [editing, setEditing] = useState<string | null>(null);
    const [adding, setAdding] = useState(false);
    const [newName, setNewName] = useState('');

    return (
        <div className="space-y-1 p-2 text-xs">
            {pages.map((page) =>
                editing === page.id ? (
                    <PageEditor
                        key={page.id}
                        page={page}
                        onCancel={() => setEditing(null)}
                        onSave={(name, path) => {
                            if (!name) return '이름을 입력하세요.';
                            if (!PAGE_PATH.test(path)) return '주소는 영문 소문자, 숫자, - 만 쓸 수 있습니다.';
                            const error = onUpdate(page.id, { name, path });
                            if (!error) setEditing(null);
                            return error;
                        }}
                    />
                ) : (
                    <div
                        key={page.id}
                        onClick={() => onOpen(page.id)}
                        className={`group flex cursor-pointer items-center gap-2 rounded-md px-2 py-1.5 ${page.id === currentId ? 'bg-accent/25' : 'hover:bg-panel-2'}`}
                    >
                        {page.path === 'index' ? <Home className="h-3.5 w-3.5 shrink-0 text-muted" /> : <FileText className="h-3.5 w-3.5 shrink-0 text-muted" />}
                        <div className="min-w-0 flex-1">
                            <div className="truncate">{page.name}</div>
                            <div className="truncate font-mono text-[10px] text-muted">/{page.path === 'index' ? '' : page.path}</div>
                        </div>
                        <div className="flex opacity-0 transition group-hover:opacity-100" onClick={(e) => e.stopPropagation()}>
                            <button title="이름·주소 변경" className="ol-btn px-1" onClick={() => setEditing(page.id)}><Pencil className="h-3 w-3" /></button>
                            <button title="복제" className="ol-btn px-1" onClick={() => onDuplicate(page.id)}><Copy className="h-3 w-3" /></button>
                            {page.path !== 'index' && (
                                <button
                                    title="삭제"
                                    className="ol-btn px-1 text-red-400"
                                    onClick={() => confirm(`"${page.name}" 페이지를 삭제할까요?`) && onDelete(page.id)}
                                >
                                    <Trash2 className="h-3 w-3" />
                                </button>
                            )}
                        </div>
                    </div>
                ),
            )}
            {adding ? (
                <form
                    onSubmit={(e) => {
                        e.preventDefault();
                        if (!newName.trim()) return;
                        onAdd(newName.trim());
                        setNewName('');
                        setAdding(false);
                    }}
                    className="flex gap-1 pt-1"
                >
                    <input autoFocus value={newName} onChange={(e) => setNewName(e.target.value)} onBlur={() => !newName && setAdding(false)} placeholder="새 페이지 이름" className="ol-input" />
                    <button type="submit" className="ol-btn bg-accent px-2 hover:bg-accent/80">추가</button>
                </form>
            ) : (
                <button onClick={() => setAdding(true)} className="ol-btn mt-1 w-full justify-start text-muted">
                    <Plus className="h-3.5 w-3.5" /> 페이지 추가
                </button>
            )}
            <p className="px-2 pt-3 text-[10px] leading-relaxed text-muted">
                다른 페이지로 링크하려면 링크 주소에 페이지 주소(예: <code className="font-mono">about</code>)를 쓰세요. 스타일 패널에서 고를 수도 있습니다.
            </p>
        </div>
    );
}
