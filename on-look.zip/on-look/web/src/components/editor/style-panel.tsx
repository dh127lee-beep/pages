'use client';

import { AlignCenter, AlignJustify, AlignLeft, AlignRight, ArrowDown, ArrowUp, Copy, CornerLeftUp, Database, Loader2, Trash2, Unlink } from 'lucide-react';
import { useEffect, useState } from 'react';
import type { ElementInfo, Page } from '@/lib/types';

interface Props {
    el: ElementInfo;
    pages: Pick<Page, 'name' | 'path'>[];
    onStyle: (prop: string, value: string) => void;
    onClass: (value: string) => void;
    onText: (value: string) => void;
    onAttr: (name: string, value: string) => void;
    onSelect: (oid: string) => void;
    onAction: (action: 'parent' | 'up' | 'down' | 'duplicate' | 'remove') => void;
}

function toHex(color: string): string {
    if (!color) return '#000000';
    if (color.startsWith('#')) return color.length === 4 ? '#' + [...color.slice(1)].map((c) => c + c).join('') : color.slice(0, 7);
    const m = color.match(/rgba?\(([^)]+)\)/);
    if (!m) return '#000000';
    const [r, g, b] = m[1].split(/[\s,/]+/).map(Number);
    return '#' + [r, g, b].map((n) => Math.max(0, Math.min(255, n || 0)).toString(16).padStart(2, '0')).join('');
}

function isTransparent(color: string) {
    return !color || color === 'transparent' || /rgba\([^)]*,\s*0\)$/.test(color);
}

/** Text field that keeps a local draft and commits on blur / Enter. */
function Field({ value, placeholder, onCommit, multiline, mono, className }: {
    value: string; placeholder?: string; onCommit: (v: string) => void; multiline?: boolean; mono?: boolean; className?: string;
}) {
    const [draft, setDraft] = useState(value);
    useEffect(() => setDraft(value), [value]);
    const commit = () => {
        if (draft !== value) onCommit(draft);
    };
    const common = {
        value: draft,
        placeholder,
        onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => setDraft(e.target.value),
        onBlur: commit,
        className: `ol-input ${mono ? 'font-mono' : ''} ${className ?? ''}`,
    };
    if (multiline) {
        return (
            <textarea
                {...common}
                rows={3}
                onKeyDown={(e) => {
                    if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) commit();
                }}
                className={`${common.className} resize-y leading-relaxed`}
            />
        );
    }
    return <input {...common} onKeyDown={(e) => e.key === 'Enter' && commit()} />;
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
    return (
        <div className="border-b border-line px-3 py-3">
            <div className="mb-2 text-[11px] font-semibold uppercase tracking-wider text-muted">{title}</div>
            <div className="space-y-2">{children}</div>
        </div>
    );
}

function Row({ label, children }: { label: string; children: React.ReactNode }) {
    return (
        <label className="flex items-center gap-2">
            <span className="w-16 shrink-0 text-[11px] text-muted">{label}</span>
            <div className="min-w-0 flex-1">{children}</div>
        </label>
    );
}

function Select({ value, options, onChange }: { value: string; options: [string, string][]; onChange: (v: string) => void }) {
    return (
        <select value={value} onChange={(e) => onChange(e.target.value)} className="ol-input">
            {!options.some(([v]) => v === value) && <option value={value}>{value}</option>}
            {options.map(([v, l]) => (
                <option key={v} value={v}>{l}</option>
            ))}
        </select>
    );
}

function ColorField({ value, inline, onCommit }: { value: string; inline?: string; onCommit: (v: string) => void }) {
    const shown = inline ?? (isTransparent(value) ? '' : toHex(value));
    return (
        <div className="flex items-center gap-1.5">
            <input
                type="color"
                value={toHex(inline ?? value)}
                onChange={(e) => onCommit(e.target.value)}
                className="h-6 w-7 shrink-0 cursor-pointer rounded border border-line bg-transparent p-0"
            />
            <Field value={shown} placeholder={isTransparent(value) ? '없음' : toHex(value)} onCommit={onCommit} mono />
        </div>
    );
}

const SIDES = ['top', 'right', 'bottom', 'left'] as const;
const SIDE_LABELS = { top: '위', right: '오른쪽', bottom: '아래', left: '왼쪽' };

export function StylePanel({ el, pages, onStyle, onClass, onText, onAttr, onSelect, onAction }: Props) {
    const s = (prop: string) => el.inline[prop] ?? '';
    const c = (prop: string) => el.computed[prop] ?? '';
    const styleField = (prop: string) => <Field value={s(prop)} placeholder={c(prop)} onCommit={(v) => onStyle(prop, v)} mono />;
    const display = s('display') || c('display');
    const isFlex = display.includes('flex') || display.includes('grid');

    return (
        <div className="text-xs">
            <div className="border-b border-line px-3 py-3">
                <div className="flex items-center justify-between">
                    <span className="rounded bg-accent/20 px-1.5 py-0.5 font-mono text-[11px] text-indigo-300">&lt;{el.tag}&gt;</span>
                    <div className="flex">
                        <button title="부모 선택" className="ol-btn px-1.5" onClick={() => onAction('parent')} disabled={el.path.length < 2}><CornerLeftUp className="h-3.5 w-3.5" /></button>
                        <button title="위로 이동 (⌥↑)" className="ol-btn px-1.5" onClick={() => onAction('up')} disabled={!el.canMove}><ArrowUp className="h-3.5 w-3.5" /></button>
                        <button title="아래로 이동 (⌥↓)" className="ol-btn px-1.5" onClick={() => onAction('down')} disabled={!el.canMove}><ArrowDown className="h-3.5 w-3.5" /></button>
                        <button title="복제 (⌘D)" className="ol-btn px-1.5" onClick={() => onAction('duplicate')} disabled={!el.canMove}><Copy className="h-3.5 w-3.5" /></button>
                        <button title="삭제 (Delete)" className="ol-btn px-1.5 text-red-400" onClick={() => onAction('remove')} disabled={!el.canMove}><Trash2 className="h-3.5 w-3.5" /></button>
                    </div>
                </div>
                <div className="mt-2 flex flex-wrap items-center gap-0.5 text-[11px] text-muted">
                    {el.path.slice(-5).map((p, i, arr) => (
                        <span key={p.oid} className="flex items-center gap-0.5">
                            <button onClick={() => onSelect(p.oid)} className={`font-mono hover:text-foreground ${i === arr.length - 1 ? 'text-foreground' : ''}`}>{p.label}</button>
                            {i < arr.length - 1 && <span>›</span>}
                        </span>
                    ))}
                </div>
            </div>

            {el.text !== null && (
                <Section title="텍스트">
                    <Field value={el.text} onCommit={onText} multiline placeholder="텍스트" />
                    <p className="text-[10px] text-muted">캔버스에서 더블클릭해도 바로 수정됩니다. ⌘+Enter로 적용.</p>
                </Section>
            )}

            {(el.tag === 'a' || el.tag === 'img' || el.tag === 'input') && (
                <Section title="속성">
                    {el.tag === 'a' && (
                        <Row label="페이지">
                            <select
                                className="ol-input"
                                value={pages.some((p) => p.path === el.attrs.href) ? el.attrs.href : ''}
                                onChange={(e) => e.target.value && onAttr('href', e.target.value)}
                            >
                                <option value="">— 페이지 선택 —</option>
                                {pages.map((p) => (
                                    <option key={p.path} value={p.path}>{p.name} (/{p.path === 'index' ? '' : p.path})</option>
                                ))}
                            </select>
                        </Row>
                    )}
                    {el.tag === 'a' && <Row label="링크"><Field value={el.attrs.href ?? ''} placeholder="about 또는 https://" onCommit={(v) => onAttr('href', v)} mono /></Row>}
                    {el.tag === 'a' && (
                        <Row label="새 탭">
                            <input type="checkbox" checked={el.attrs.target === '_blank'} onChange={(e) => onAttr('target', e.target.checked ? '_blank' : '')} />
                        </Row>
                    )}
                    {el.tag === 'img' && <Row label="이미지 URL"><Field value={el.attrs.src ?? ''} onCommit={(v) => onAttr('src', v)} mono /></Row>}
                    {el.tag === 'img' && <Row label="대체 텍스트"><Field value={el.attrs.alt ?? ''} onCommit={(v) => onAttr('alt', v)} /></Row>}
                    {el.tag === 'input' && <Row label="안내 문구"><Field value={el.attrs.placeholder ?? ''} onCommit={(v) => onAttr('placeholder', v)} /></Row>}
                </Section>
            )}

            <DataSection key={el.bound?.oid ?? el.oid} el={el} onAttr={onAttr} onSelect={onSelect} />

            <Section title="Tailwind 클래스">
                <Field value={el.className} onCommit={onClass} multiline mono placeholder="예: flex items-center gap-4 p-6" />
                <Row label="ID"><Field value={el.attrs.id ?? ''} onCommit={(v) => onAttr('id', v)} mono /></Row>
            </Section>

            <Section title="레이아웃">
                <Row label="표시">
                    <Select value={display} onChange={(v) => onStyle('display', v)} options={[['block', 'block'], ['flex', 'flex'], ['grid', 'grid'], ['inline-block', 'inline-block'], ['inline', 'inline'], ['none', '숨김']]} />
                </Row>
                {isFlex && (
                    <>
                        <Row label="방향">
                            <Select value={s('flex-direction') || c('flex-direction')} onChange={(v) => onStyle('flex-direction', v)} options={[['row', '가로'], ['column', '세로'], ['row-reverse', '가로 (역순)'], ['column-reverse', '세로 (역순)']]} />
                        </Row>
                        <Row label="주축 정렬">
                            <Select value={s('justify-content') || c('justify-content')} onChange={(v) => onStyle('justify-content', v)} options={[['normal', '기본'], ['flex-start', '시작'], ['center', '가운데'], ['flex-end', '끝'], ['space-between', '양끝 배분'], ['space-around', '균등 배분']]} />
                        </Row>
                        <Row label="교차 정렬">
                            <Select value={s('align-items') || c('align-items')} onChange={(v) => onStyle('align-items', v)} options={[['normal', '기본'], ['stretch', '늘이기'], ['flex-start', '시작'], ['center', '가운데'], ['flex-end', '끝']]} />
                        </Row>
                        <Row label="간격">{styleField('gap')}</Row>
                    </>
                )}
                <div className="grid grid-cols-2 gap-2">
                    <Row label="너비">{styleField('width')}</Row>
                    <Row label="높이">{styleField('height')}</Row>
                </div>
            </Section>

            <Section title="여백">
                <div className="text-[11px] text-muted">안쪽 여백 (padding)</div>
                <div className="grid grid-cols-4 gap-1">
                    {SIDES.map((side) => (
                        <div key={side} title={SIDE_LABELS[side]}>{styleField(`padding-${side}`)}</div>
                    ))}
                </div>
                <div className="text-[11px] text-muted">바깥 여백 (margin)</div>
                <div className="grid grid-cols-4 gap-1">
                    {SIDES.map((side) => (
                        <div key={side} title={SIDE_LABELS[side]}>{styleField(`margin-${side}`)}</div>
                    ))}
                </div>
            </Section>

            <Section title="타이포그래피">
                <div className="grid grid-cols-2 gap-2">
                    <Row label="크기">{styleField('font-size')}</Row>
                    <Row label="행간">{styleField('line-height')}</Row>
                </div>
                <Row label="굵기">
                    <Select
                        value={s('font-weight') || c('font-weight')}
                        onChange={(v) => onStyle('font-weight', v)}
                        options={[['300', 'Light 300'], ['400', 'Regular 400'], ['500', 'Medium 500'], ['600', 'Semibold 600'], ['700', 'Bold 700'], ['800', 'Extrabold 800']]}
                    />
                </Row>
                <Row label="자간">{styleField('letter-spacing')}</Row>
                <Row label="글자색"><ColorField value={c('color')} inline={el.inline['color']} onCommit={(v) => onStyle('color', v)} /></Row>
                <Row label="정렬">
                    <div className="flex gap-1">
                        {([['left', AlignLeft], ['center', AlignCenter], ['right', AlignRight], ['justify', AlignJustify]] as const).map(([v, Icon]) => (
                            <button
                                key={v}
                                onClick={() => onStyle('text-align', v)}
                                className={`ol-btn px-2 ${(s('text-align') || c('text-align')) === v ? 'bg-accent/30' : 'bg-panel-2'}`}
                            >
                                <Icon className="h-3.5 w-3.5" />
                            </button>
                        ))}
                    </div>
                </Row>
            </Section>

            <Section title="배경 · 테두리">
                <Row label="배경색"><ColorField value={c('background-color')} inline={el.inline['background-color']} onCommit={(v) => onStyle('background-color', v)} /></Row>
                <div className="grid grid-cols-2 gap-2">
                    <Row label="모서리">{styleField('border-radius')}</Row>
                    <Row label="테두리">{styleField('border-width')}</Row>
                </div>
                <Row label="테두리색"><ColorField value={c('border-color')} inline={el.inline['border-color']} onCommit={(v) => { onStyle('border-color', v); if (!s('border-style')) onStyle('border-style', 'solid'); }} /></Row>
                <Row label="불투명도">
                    <div className="flex items-center gap-2">
                        <input
                            type="range" min={0} max={1} step={0.05}
                            value={Number(s('opacity') || c('opacity') || 1)}
                            onChange={(e) => onStyle('opacity', e.target.value)}
                            className="flex-1 accent-indigo-500"
                        />
                        <span className="w-8 text-right font-mono text-muted">{Math.round(Number(s('opacity') || c('opacity') || 1) * 100)}%</span>
                    </div>
                </Row>
            </Section>
        </div>
    );
}

/* ---------- data binding ---------- */

function sampleUrl(url: string) {
    // {query.x} has no value in the editor; use 1 so detail endpoints still resolve for the preview.
    return url.replace(/\{query\.[^}]+\}/g, '1');
}

function pathGet(obj: unknown, path: string): unknown {
    if (!path) return obj;
    return path.split('.').reduce<unknown>((cur, k) => (cur == null ? undefined : (cur as Record<string, unknown>)[k]), obj);
}

/** Flatten an object's keys to dot paths (2 levels) so they can be picked as fields. */
function fieldPaths(obj: unknown, prefix = '', depth = 0): string[] {
    if (!obj || typeof obj !== 'object' || Array.isArray(obj)) return [];
    return Object.entries(obj as Record<string, unknown>).flatMap(([k, v]) => {
        const key = prefix ? `${prefix}.${k}` : k;
        return v && typeof v === 'object' && !Array.isArray(v) && depth < 1 ? fieldPaths(v, key, depth + 1) : [key];
    });
}

function DataSection({ el, onAttr, onSelect }: { el: ElementInfo; onAttr: (name: string, value: string) => void; onSelect: (oid: string) => void }) {
    const [newUrl, setNewUrl] = useState('');
    const [sample, setSample] = useState<{ url: string; status: 'loading' | 'ok' | 'error'; fields: string[]; message?: string; preview?: string } | null>(null);
    const isSource = el.attrs['data-ol-fetch'] !== undefined;
    const scope = el.bound;

    async function loadSample() {
        if (!scope) return;
        const url = sampleUrl(scope.url);
        setSample({ url, status: 'loading', fields: [] });
        try {
            const res = await fetch(`/api/proxy?url=${encodeURIComponent(url)}`);
            const json = await res.json();
            if (!res.ok) throw new Error(json?.error ?? `HTTP ${res.status}`);
            const data = pathGet(json, scope.path);
            const item = Array.isArray(data) ? data[0] : data;
            setSample({
                url,
                status: 'ok',
                fields: fieldPaths(item),
                preview: Array.isArray(data) ? `배열 ${data.length}개 항목` : typeof data === 'object' ? '객체 1개' : String(data),
            });
        } catch (err) {
            setSample({ url, status: 'error', fields: [], message: err instanceof Error ? err.message : String(err) });
        }
    }

    const bindAttr = el.tag === 'img' ? 'data-ol-src' : 'data-ol-text';

    return (
        <Section title="데이터 연결 (API)">
            {!scope && (
                <>
                    <p className="text-[11px] leading-relaxed text-muted">이 요소에 API 데이터를 연결합니다. 목록이면 첫 번째 자식 요소가 항목마다 반복됩니다.</p>
                    <div className="flex gap-1">
                        <input value={newUrl} onChange={(e) => setNewUrl(e.target.value)} placeholder="https://api.example.com/items" className="ol-input font-mono" />
                        <button
                            className="ol-btn shrink-0 bg-accent hover:bg-accent/80"
                            disabled={!/^https?:\/\//.test(newUrl)}
                            onClick={() => {
                                onAttr('data-ol-fetch', newUrl);
                                setNewUrl('');
                            }}
                        >
                            <Database className="h-3.5 w-3.5" /> 연결
                        </button>
                    </div>
                </>
            )}

            {scope && isSource && (
                <>
                    <Row label="API URL"><Field value={el.attrs['data-ol-fetch'] ?? ''} onCommit={(v) => onAttr('data-ol-fetch', v)} mono /></Row>
                    <Row label="데이터 경로"><Field value={el.attrs['data-ol-path'] ?? ''} placeholder="예: data.items (전체면 비움)" onCommit={(v) => onAttr('data-ol-path', v)} mono /></Row>
                    <Row label="목록 반복">
                        <input type="checkbox" checked={el.attrs['data-ol-list'] !== undefined} onChange={(e) => onAttr('data-ol-list', e.target.checked ? 'true' : '')} />
                    </Row>
                    {el.attrs['data-ol-list'] !== undefined && (
                        <Row label="최대 개수"><Field value={el.attrs['data-ol-limit'] ?? ''} placeholder="전체" onCommit={(v) => onAttr('data-ol-limit', v)} mono /></Row>
                    )}
                    <p className="text-[10px] leading-relaxed text-muted">
                        URL에 <code className="font-mono">{'{query.id}'}</code>를 쓰면 페이지 주소의 <code className="font-mono">?id=</code> 값이 들어갑니다 (상세 페이지용).
                    </p>
                    <button
                        className="ol-btn text-red-400"
                        onClick={() => ['data-ol-fetch', 'data-ol-path', 'data-ol-list', 'data-ol-limit'].forEach((a) => onAttr(a, ''))}
                    >
                        <Unlink className="h-3.5 w-3.5" /> 연결 해제
                    </button>
                </>
            )}

            {scope && !isSource && (
                <p className="text-[11px] text-muted">
                    <button className="font-mono text-indigo-300 underline" onClick={() => onSelect(scope.oid)}>데이터 소스</button>
                    {scope.list ? '의 목록 항목 안에 있습니다.' : ' 안에 있습니다.'}
                </p>
            )}

            {scope && (
                <>
                    <Row label={el.tag === 'img' ? '이미지 필드' : '텍스트 필드'}>
                        <Field value={el.attrs[bindAttr] ?? ''} placeholder="예: title 또는 {name} 님" onCommit={(v) => onAttr(bindAttr, v)} mono />
                    </Row>
                    {el.tag === 'a' && (
                        <Row label="링크 필드"><Field value={el.attrs['data-ol-href'] ?? ''} placeholder="post?id={id}" onCommit={(v) => onAttr('data-ol-href', v)} mono /></Row>
                    )}
                    <button className="ol-btn bg-panel-2" onClick={loadSample} disabled={sample?.status === 'loading'}>
                        {sample?.status === 'loading' ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Database className="h-3.5 w-3.5" />}
                        API 응답에서 필드 고르기
                    </button>
                    {sample?.status === 'error' && <p className="text-[11px] text-red-400">불러오기 실패: {sample.message}</p>}
                    {sample?.status === 'ok' && (
                        <div className="space-y-1.5">
                            <p className="text-[10px] text-muted">{sample.preview} · 클릭하면 이 요소에 연결됩니다</p>
                            <div className="flex flex-wrap gap-1">
                                {sample.fields.map((f) => (
                                    <button key={f} onClick={() => onAttr(bindAttr, f)} className="rounded bg-accent/20 px-1.5 py-0.5 font-mono text-[10px] text-indigo-200 hover:bg-accent/40">
                                        {f}
                                    </button>
                                ))}
                            </div>
                        </div>
                    )}
                </>
            )}
        </Section>
    );
}
