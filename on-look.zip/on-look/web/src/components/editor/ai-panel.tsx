'use client';

import { Loader2, Send, Sparkles } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';
import { extractHtml } from '@/lib/html';

export type AiScope = 'page' | 'element';

interface Entry {
    role: 'user' | 'assistant' | 'error';
    text: string;
}

interface Props {
    hasSelection: boolean;
    selectedLabel: string | null;
    initialPrompt?: string;
    getSource: (scope: AiScope) => Promise<string | null>;
    /** Project context sent with every request: the page list, current page path and script. */
    getContext: () => { pages: { name: string; path: string }[]; currentPath: string; script: string };
    onResult: (scope: AiScope, html: string, script: string | null) => void;
}

const SUGGESTIONS = [
    '전체 색상을 따뜻한 파스텔 톤으로 바꿔줘',
    '모바일에서도 보기 좋게 다듬어줘',
    '고객 후기 섹션을 추가해줘',
    '더 고급스러운 느낌으로 타이포그래피를 바꿔줘',
];

export function AiPanel({ hasSelection, selectedLabel, initialPrompt, getSource, getContext, onResult }: Props) {
    const [status, setStatus] = useState<{ enabled: boolean; model: string; provider?: string } | null>(null);
    const [input, setInput] = useState('');
    const [scope, setScope] = useState<AiScope>('page');
    const [log, setLog] = useState<Entry[]>([]);
    const [streaming, setStreaming] = useState<string | null>(null);
    const ranInitial = useRef(false);
    const logRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        fetch('/api/ai').then((r) => r.json()).then(setStatus).catch(() => setStatus({ enabled: false, model: '' }));
    }, []);

    useEffect(() => {
        if (!hasSelection) setScope('page');
    }, [hasSelection]);

    useEffect(() => {
        logRef.current?.scrollTo({ top: logRef.current.scrollHeight });
    }, [log, streaming]);

    async function run(instruction: string, runScope: AiScope = scope) {
        if (!instruction.trim() || streaming !== null) return;
        setInput('');
        setLog((l) => [...l, { role: 'user', text: runScope === 'element' && selectedLabel ? `[${selectedLabel}] ${instruction}` : instruction }]);
        setStreaming('');
        try {
            const html = await getSource(runScope);
            const res = await fetch('/api/ai', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ instruction, html, scope: runScope, ...getContext() }),
            });
            if (!res.ok || !res.body) throw new Error((await res.json().catch(() => null))?.error ?? 'AI 요청 실패');
            const reader = res.body.getReader();
            const decoder = new TextDecoder();
            let buffer = '';
            let text = '';
            let finished = false;
            while (true) {
                const { done, value } = await reader.read();
                if (done) break;
                buffer += decoder.decode(value, { stream: true });
                const lines = buffer.split('\n');
                buffer = lines.pop() ?? '';
                for (const line of lines) {
                    if (!line.trim()) continue;
                    const event = JSON.parse(line) as { type: string; text?: string; html?: string; script?: string | null; summary?: string; message?: string };
                    if (event.type === 'text') {
                        text += event.text;
                        setStreaming(text);
                    } else if (event.type === 'done' && event.html) {
                        finished = true;
                        onResult(runScope, event.html, event.script ?? null);
                        setLog((l) => [...l, { role: 'assistant', text: event.summary || '변경 사항을 적용했습니다.' }]);
                    } else if (event.type === 'error') {
                        finished = true;
                        setLog((l) => [...l, { role: 'error', text: event.message ?? '알 수 없는 오류' }]);
                    }
                }
            }
            if (!finished) {
                const html = extractHtml(text);
                if (html) {
                    onResult(runScope, html, null);
                    setLog((l) => [...l, { role: 'assistant', text: '변경 사항을 적용했습니다.' }]);
                } else {
                    setLog((l) => [...l, { role: 'error', text: '응답이 중간에 끊겼습니다.' }]);
                }
            }
        } catch (err) {
            setLog((l) => [...l, { role: 'error', text: err instanceof Error ? err.message : 'AI 요청 실패' }]);
        } finally {
            setStreaming(null);
        }
    }

    // Auto-run the prompt passed from the dashboard ("AI로 만들기").
    useEffect(() => {
        if (initialPrompt && status?.enabled && !ranInitial.current) {
            ranInitial.current = true;
            window.history.replaceState(null, '', window.location.pathname);
            run(`다음 설명에 맞는 완성도 높은 웹 페이지를 처음부터 새로 만들어줘: ${initialPrompt}`, 'page');
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [initialPrompt, status]);

    const progress = streaming !== null ? Math.min(99, Math.round(streaming.length / 120)) : 0;

    return (
        <div className="flex h-full flex-col text-xs">
            <div ref={logRef} className="ol-scroll flex-1 space-y-2 overflow-y-auto p-3">
                {status && !status.enabled && (
                    <div className="rounded-lg border border-amber-500/30 bg-amber-500/10 p-3 leading-relaxed text-amber-200">
                        AI 기능을 쓰려면 <code className="font-mono">web/.env.local</code> 파일에
                        <code className="mx-1 font-mono">{status.provider === 'bridge' ? 'ONLOOK_AI_API_KEY=...' : 'ANTHROPIC_API_KEY=...'}</code>를 추가하고 서버를 다시 시작하세요.
                    </div>
                )}
                {log.length === 0 && streaming === null && (
                    <div className="space-y-3">
                        <div className="flex items-center gap-2 text-muted">
                            <Sparkles className="h-4 w-4 text-accent" /> 원하는 변경을 말로 설명하세요.
                        </div>
                        <div className="flex flex-col gap-1.5">
                            {SUGGESTIONS.map((s) => (
                                <button key={s} onClick={() => run(s, 'page')} disabled={!status?.enabled} className="rounded-lg border border-line bg-panel-2 px-3 py-2 text-left text-foreground/80 hover:border-accent disabled:opacity-40">
                                    {s}
                                </button>
                            ))}
                        </div>
                    </div>
                )}
                {log.map((e, i) => (
                    <div
                        key={i}
                        className={`whitespace-pre-wrap rounded-lg px-3 py-2 leading-relaxed ${
                            e.role === 'user' ? 'ml-6 bg-accent/20' : e.role === 'error' ? 'border border-red-500/30 bg-red-500/10 text-red-300' : 'mr-6 bg-panel-2'
                        }`}
                    >
                        {e.text}
                    </div>
                ))}
                {streaming !== null && (
                    <div className="mr-6 rounded-lg bg-panel-2 px-3 py-2">
                        <div className="flex items-center gap-2 text-muted">
                            <Loader2 className="h-3.5 w-3.5 animate-spin" />
                            {streaming ? `디자인을 작성하는 중… ${progress}%` : '생각하는 중…'}
                        </div>
                        {streaming && <pre className="mt-2 max-h-24 overflow-hidden font-mono text-[10px] leading-snug text-muted/70">{streaming.slice(-400)}</pre>}
                    </div>
                )}
            </div>
            <form
                onSubmit={(e) => {
                    e.preventDefault();
                    run(input);
                }}
                className="border-t border-line p-3"
            >
                <div className="mb-2 grid grid-cols-2 gap-1 rounded-lg bg-panel-2 p-1">
                    <button type="button" onClick={() => setScope('page')} className={`rounded-md py-1 ${scope === 'page' ? 'bg-accent text-white' : 'text-muted'}`}>페이지 전체</button>
                    <button type="button" disabled={!hasSelection} onClick={() => setScope('element')} className={`truncate rounded-md px-1 py-1 disabled:opacity-40 ${scope === 'element' ? 'bg-accent text-white' : 'text-muted'}`}>
                        {selectedLabel ? `선택: ${selectedLabel}` : '선택한 요소'}
                    </button>
                </div>
                <div className="flex items-end gap-2 rounded-lg border border-line bg-panel-2 p-2 focus-within:border-accent">
                    <textarea
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        onKeyDown={(e) => {
                            if (e.key === 'Enter' && !e.shiftKey && !e.nativeEvent.isComposing) {
                                e.preventDefault();
                                run(input);
                            }
                        }}
                        rows={2}
                        placeholder={scope === 'element' ? '선택한 요소를 어떻게 바꿀까요?' : '예: 히어로 섹션 배경을 그라데이션으로'}
                        className="max-h-40 flex-1 resize-none bg-transparent text-xs outline-none placeholder:text-muted"
                    />
                    <button type="submit" disabled={!input.trim() || streaming !== null || !status?.enabled} className="rounded-md bg-accent p-1.5 disabled:opacity-40">
                        <Send className="h-3.5 w-3.5" />
                    </button>
                </div>
            </form>
        </div>
    );
}
