import { buildPageDocument } from '@/lib/page-doc';
import { pageUrl } from '@/lib/pages';
import { getProject } from '@/lib/store';

/**
 * Published pages: /p/<id> is the home page, /p/<id>/<path> the others.
 * Served under a CSP sandbox so user HTML/JS runs in an opaque origin, isolated from the app.
 */
export async function GET(_req: Request, { params }: { params: Promise<{ id: string; slug?: string[] }> }) {
    const { id, slug } = await params;
    const project = await getProject(id);
    if (!project) return new Response('Not found', { status: 404 });
    const path = (slug?.[0] ?? 'index').replace(/\.html?$/i, '') || 'index';
    const page = slug && slug.length > 1 ? undefined : project.pages.find((p) => p.path === path);
    if (!page) return new Response('Page not found', { status: 404, headers: { 'Content-Type': 'text/plain; charset=utf-8' } });

    const html = buildPageDocument(page, project.pages, {
        linkFor: (p) => pageUrl(project.id, p),
        runtime: { src: '/ol-runtime.js' },
        proxy: '/api/proxy',
    });
    return new Response(html, {
        headers: {
            'Content-Type': 'text/html; charset=utf-8',
            'Content-Security-Policy': 'sandbox allow-scripts allow-popups allow-forms',
            'Cache-Control': 'no-store',
        },
    });
}
