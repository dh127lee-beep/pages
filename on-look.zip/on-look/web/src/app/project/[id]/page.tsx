import { notFound } from 'next/navigation';
import { Editor } from '@/components/editor/editor';
import { getProject } from '@/lib/store';

export const dynamic = 'force-dynamic';

export default async function ProjectPage({
    params,
    searchParams,
}: {
    params: Promise<{ id: string }>;
    searchParams: Promise<{ ai?: string }>;
}) {
    const [{ id }, { ai }] = await Promise.all([params, searchParams]);
    const project = await getProject(id);
    if (!project) notFound();
    return <Editor project={project} initialPrompt={ai} />;
}
