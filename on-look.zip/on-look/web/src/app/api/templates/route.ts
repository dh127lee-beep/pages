import { NextResponse } from 'next/server';
import { TEMPLATES } from '@/lib/templates';

export function GET() {
    return NextResponse.json(TEMPLATES.map(({ id, name, description }) => ({ id, name, description })));
}
