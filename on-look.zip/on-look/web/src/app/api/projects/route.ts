import { NextResponse } from 'next/server';
import { validatePages } from '@/lib/pages';
import { createProject, listProjects, type NewPage } from '@/lib/store';
import { getTemplate } from '@/lib/templates';

export async function GET() {
    return NextResponse.json(await listProjects());
}

export async function POST(req: Request) {
    const body = (await req.json().catch(() => ({}))) as { name?: string; templateId?: string; pages?: NewPage[] };
    const template = getTemplate(body.templateId);
    let pages: NewPage[] = template.pages;
    if (body.pages !== undefined) {
        // Copying an existing project: ids are reassigned, so give each page a temporary one to validate.
        const error = validatePages(body.pages.map((p, i) => ({ ...p, id: `tmp${i}`, script: p.script ?? '' })));
        if (error) return NextResponse.json({ error }, { status: 400 });
        pages = body.pages;
    }
    const name = body.name?.trim().slice(0, 80) || template.name;
    return NextResponse.json(await createProject(name, pages), { status: 201 });
}
