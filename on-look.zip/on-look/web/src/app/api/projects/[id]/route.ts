import { NextResponse } from 'next/server';
import { validatePages } from '@/lib/pages';
import { deleteProject, getProject, updateProject } from '@/lib/store';
import type { Page } from '@/lib/types';

type Ctx = { params: Promise<{ id: string }> };

const MAX_PROJECT_BYTES = 10 * 1024 * 1024;

export async function GET(_req: Request, { params }: Ctx) {
    const project = await getProject((await params).id);
    return project ? NextResponse.json(project) : NextResponse.json({ error: 'Not found' }, { status: 404 });
}

export async function PUT(req: Request, { params }: Ctx) {
    const body = (await req.json().catch(() => ({}))) as { name?: unknown; pages?: unknown };
    const patch: { name?: string; pages?: Page[] } = {};
    if (typeof body.name === 'string' && body.name.trim()) patch.name = body.name.trim().slice(0, 80);
    if (body.pages !== undefined) {
        const error = validatePages(body.pages);
        if (error) return NextResponse.json({ error }, { status: 400 });
        if (Buffer.byteLength(JSON.stringify(body.pages)) > MAX_PROJECT_BYTES) {
            return NextResponse.json({ error: 'Project is too large' }, { status: 413 });
        }
        patch.pages = (body.pages as Page[]).map(({ id, name, path, html, script }) => ({ id, name: name.trim().slice(0, 60), path, html, script }));
    }
    const project = await updateProject((await params).id, patch);
    return project ? NextResponse.json(project) : NextResponse.json({ error: 'Not found' }, { status: 404 });
}

export async function DELETE(_req: Request, { params }: Ctx) {
    const ok = await deleteProject((await params).id);
    return ok ? new NextResponse(null, { status: 204 }) : NextResponse.json({ error: 'Not found' }, { status: 404 });
}
