import Anthropic from '@anthropic-ai/sdk';
import { extractHtml, extractScript } from '@/lib/html';

export const runtime = 'nodejs';
export const maxDuration = 300;

/**
 * Two providers:
 * - bridge: any OpenAI-compatible endpoint (e.g. the local Claude CLI bridge) when ONLOOK_AI_BASE_URL is set
 * - anthropic: the Anthropic SDK, using ANTHROPIC_API_KEY / ANTHROPIC_AUTH_TOKEN
 */
const BRIDGE_URL = process.env.ONLOOK_AI_BASE_URL?.replace(/\/$/, '');
const BRIDGE_KEY = process.env.ONLOOK_AI_API_KEY ?? '';
const PROVIDER = BRIDGE_URL ? 'bridge' : 'anthropic';
const MODEL = process.env.ONLOOK_AI_MODEL ?? (BRIDGE_URL ? 'opus' : 'claude-opus-5-5');

const SYSTEM_PROMPT = `You are the AI design engine inside On-Look, a visual web page editor.
A project has one or more pages. Each page is a self-contained HTML document styled with Tailwind CSS
(loaded from the Tailwind Play CDN), plus an optional page script.

Reply format:
- The updated HTML inside one \`\`\`html code fence.
- Page scope only, and only if the page needs JavaScript: the complete page script inside one \`\`\`js code fence. Omit the fence to keep the current script unchanged; send an empty fence to remove it.
- Then one short sentence (in the user's language) describing what changed.

HTML rules:
- Page scope: return the full document from <!DOCTYPE html> to </html>, keeping the Tailwind CDN <script> tag in <head>.
- Element scope: return only the replacement for the given element (a single root element), not a full document.
- Style with Tailwind utility classes. Keep the page responsive and accessible (alt text, sufficient contrast, semantic tags).
- Preserve existing content and structure the user did not ask to change.
- For images use https://picsum.photos/seed/<word>/<w>/<h> placeholders unless the user provides URLs.
- Do not put <script> tags in the HTML (other than the Tailwind CDN); JavaScript goes in the page script.
- Link to other pages of the project with href="<page path>" (e.g. href="about", href="index" for home). Query strings are allowed (href="post?id=3").

Showing API data — prefer declarative binding (no JavaScript needed; it runs when the page loads, so it works on every page transition):
  <ul data-ol-fetch="https://api.example.com/items" data-ol-path="data.items" data-ol-list data-ol-limit="10">
    <li><a href="detail" data-ol-href="detail?id={id}" data-ol-text="title">Example title</a></li>
  </ul>
  - data-ol-fetch: JSON URL to GET; {query.x} inserts the current page's ?x= parameter (for detail pages).
  - data-ol-path: dot path into the response. data-ol-list repeats the FIRST child element per array item.
  - data-ol-text / data-ol-src / data-ol-href / data-ol-alt: a field path ("author.name") or a template ("#{id} {title}").
  - Without data-ol-list, fields inside the element are filled from a single object.
  - Keep realistic placeholder content in the template markup: it is what the user sees and edits in the design canvas.
- Page scripts run after the page loads in preview/published mode (never in the design canvas).
  Use await ol.getJSON(url) to fetch external APIs (it goes through a CORS proxy); ol.query is the page's URLSearchParams.
- Only use public APIs that need no secret keys.`;

interface AiRequest {
    instruction?: string;
    html?: string;
    script?: string;
    scope?: 'page' | 'element';
    pages?: { name: string; path: string }[];
    currentPath?: string;
}

interface Completion {
    text: string;
    truncated: boolean;
    refused: boolean;
}

class ProviderError extends Error {}

export function GET() {
    const enabled = BRIDGE_URL ? Boolean(BRIDGE_KEY) : Boolean(process.env.ANTHROPIC_API_KEY || process.env.ANTHROPIC_AUTH_TOKEN);
    return Response.json({ enabled, model: MODEL, provider: PROVIDER });
}

async function completeWithAnthropic(userContent: string, onText: (t: string) => void): Promise<Completion> {
    const client = new Anthropic();
    try {
        const response = client.beta.messages.stream({
            model: MODEL,
            max_tokens: 64000,
            thinking: { type: 'adaptive' },
            output_config: { effort: 'medium' },
            betas: ['server-side-fallback-2026-07-01'],
            // Re-run policy declines on Anthropic's recommended fallback model.
            fallbacks: 'default',
            system: SYSTEM_PROMPT,
            messages: [{ role: 'user', content: userContent }],
        });
        response.on('text', onText);
        const message = await response.finalMessage();
        return {
            text: message.content.map((b) => (b.type === 'text' ? b.text : '')).join(''),
            truncated: message.stop_reason === 'max_tokens',
            refused: message.stop_reason === 'refusal',
        };
    } catch (err) {
        if (err instanceof Anthropic.AuthenticationError) throw new ProviderError('Anthropic API 키가 없거나 올바르지 않습니다. web/.env.local 의 ANTHROPIC_API_KEY 를 확인하세요.');
        if (err instanceof Anthropic.RateLimitError) throw new ProviderError('요청 한도를 초과했습니다. 잠시 후 다시 시도하세요.');
        if (err instanceof Anthropic.APIError) throw new ProviderError(`AI 오류 (${err.status ?? 'network'}): ${err.message}`);
        if (err instanceof Error && /credentials|apiKey|authToken/i.test(err.message)) throw new ProviderError('Anthropic API 키가 설정되지 않았습니다. web/.env.local 에 ANTHROPIC_API_KEY 를 추가하세요.');
        throw err;
    }
}

/** OpenAI-compatible streaming chat completion (used for the local Claude CLI bridge). */
async function completeWithBridge(userContent: string, onText: (t: string) => void, signal: AbortSignal): Promise<Completion> {
    let res: Response;
    try {
        res = await fetch(`${BRIDGE_URL}/chat/completions`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${BRIDGE_KEY}` },
            body: JSON.stringify({
                model: MODEL,
                stream: true,
                messages: [
                    { role: 'system', content: SYSTEM_PROMPT },
                    { role: 'user', content: userContent },
                ],
            }),
            signal,
        });
    } catch {
        throw new ProviderError(`AI 브리지(${BRIDGE_URL})에 연결할 수 없습니다. 브리지가 실행 중인지 확인하세요.`);
    }
    if (res.status === 401) throw new ProviderError('AI 브리지 키가 올바르지 않습니다. web/.env.local 의 ONLOOK_AI_API_KEY 를 확인하세요.');
    if (!res.ok || !res.body) {
        const detail = await res.text().catch(() => '');
        throw new ProviderError(`AI 브리지 오류 (${res.status}): ${detail.slice(0, 200)}`);
    }

    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';
    let text = '';
    let finish: string | null = null;
    while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() ?? '';
        for (const raw of lines) {
            const line = raw.trim();
            if (!line.startsWith('data:')) continue;
            const data = line.slice(5).trim();
            if (data === '[DONE]') continue;
            const chunk = JSON.parse(data) as {
                error?: { message?: string };
                choices?: { delta?: { content?: string }; finish_reason?: string | null }[];
            };
            if (chunk.error) throw new ProviderError(`AI 브리지 오류: ${chunk.error.message ?? 'unknown'}`);
            const choice = chunk.choices?.[0];
            if (choice?.delta?.content) {
                text += choice.delta.content;
                onText(choice.delta.content);
            }
            if (choice?.finish_reason) finish = choice.finish_reason;
        }
    }
    return { text, truncated: finish === 'length', refused: finish === 'content_filter' };
}

export async function POST(req: Request) {
    const body = (await req.json().catch(() => ({}))) as AiRequest;
    const instruction = body.instruction?.trim();
    const html = body.html ?? '';
    const scope = body.scope === 'element' ? 'element' : 'page';
    if (!instruction) return Response.json({ error: 'instruction is required' }, { status: 400 });

    const encoder = new TextEncoder();
    const send = (controller: ReadableStreamDefaultController, event: object) =>
        controller.enqueue(encoder.encode(JSON.stringify(event) + '\n'));

    const pageList = (body.pages ?? [])
        .slice(0, 50)
        .map((p) => `- ${p.path}${p.path === body.currentPath ? ' (this page)' : ''}: ${p.name}`)
        .join('\n');
    const context = pageList ? `Pages in this project (path: name):\n${pageList}\n\n` : '';
    const script = body.script?.trim();
    const userContent =
        scope === 'element'
            ? `${context}Scope: element. Rewrite this element according to the instruction.\n\nElement HTML:\n\`\`\`html\n${html}\n\`\`\`\n\nInstruction: ${instruction}`
            : `${context}Scope: page.${html ? ` Current page:\n\`\`\`html\n${html}\n\`\`\`` : ' There is no page yet; create one from scratch.'}` +
              `${script ? `\n\nCurrent page script:\n\`\`\`js\n${script}\n\`\`\`` : ''}\n\nInstruction: ${instruction}`;

    const stream = new ReadableStream({
        async start(controller) {
            try {
                const onText = (text: string) => send(controller, { type: 'text', text });
                const result = BRIDGE_URL
                    ? await completeWithBridge(userContent, onText, req.signal)
                    : await completeWithAnthropic(userContent, onText);

                const htmlOut = extractHtml(result.text);
                if (result.refused) {
                    send(controller, { type: 'error', message: '이 요청은 처리할 수 없습니다. 지시를 바꿔서 다시 시도해 주세요.' });
                } else if (result.truncated) {
                    send(controller, { type: 'error', message: '응답이 너무 길어 중간에 잘렸습니다. 범위를 좁혀서 다시 시도해 주세요.' });
                } else if (!htmlOut) {
                    send(controller, { type: 'error', message: 'AI 응답에서 HTML을 찾지 못했습니다.' });
                } else {
                    const summary = result.text.split('```').pop()?.trim() ?? '';
                    const scriptOut = scope === 'page' ? extractScript(result.text) : null;
                    send(controller, { type: 'done', html: htmlOut, script: scriptOut, summary });
                }
            } catch (err) {
                const message = err instanceof ProviderError ? err.message : 'AI 요청에 실패했습니다.';
                if (!(err instanceof ProviderError)) console.error('[ai]', err);
                send(controller, { type: 'error', message });
            } finally {
                controller.close();
            }
        },
    });

    return new Response(stream, { headers: { 'Content-Type': 'application/x-ndjson; charset=utf-8', 'Cache-Control': 'no-store' } });
}
