import { lookup } from 'node:dns/promises';
import { isIP } from 'node:net';

/**
 * CORS proxy for published pages: GET/POST https://… on behalf of a page whose sandboxed
 * origin cannot call APIs that do not send CORS headers. Blocks loopback/private/link-local
 * targets (re-checked on every redirect) and can be limited to an allowlist via
 * ONLOOK_PROXY_ALLOW="api.example.com,*.example.org".
 */
export const runtime = 'nodejs';

const MAX_BYTES = 5 * 1024 * 1024;
const TIMEOUT_MS = 15_000;
const MAX_REDIRECTS = 3;
const ALLOW = (process.env.ONLOOK_PROXY_ALLOW ?? '').split(',').map((s) => s.trim().toLowerCase()).filter(Boolean);

const CORS = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Accept',
};

function fail(status: number, message: string) {
    return Response.json({ error: message }, { status, headers: CORS });
}

function isPrivateAddress(ip: string): boolean {
    if (ip.startsWith('::ffff:')) ip = ip.slice(7);
    if (isIP(ip) === 4) {
        const [a, b] = ip.split('.').map(Number);
        return (
            a === 0 || a === 10 || a === 127 || (a === 100 && b >= 64 && b <= 127) || (a === 169 && b === 254) ||
            (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) || (a === 198 && (b === 18 || b === 19)) || a >= 224
        );
    }
    const v6 = ip.toLowerCase();
    return v6 === '::' || v6 === '::1' || v6.startsWith('fc') || v6.startsWith('fd') || v6.startsWith('fe8') || v6.startsWith('fe9') || v6.startsWith('fea') || v6.startsWith('feb') || v6.startsWith('ff');
}

function allowedHost(host: string): boolean {
    if (!ALLOW.length) return true;
    return ALLOW.some((rule) => (rule.startsWith('*.') ? host.endsWith(rule.slice(1)) : host === rule));
}

async function checkTarget(url: URL): Promise<string | null> {
    if (url.protocol !== 'https:' && url.protocol !== 'http:') return 'only http(s) URLs are allowed';
    if (url.username || url.password) return 'credentials in URL are not allowed';
    const host = url.hostname.replace(/^\[|\]$/g, '').toLowerCase();
    if (!allowedHost(host)) return `host not in ONLOOK_PROXY_ALLOW: ${host}`;
    if (host === 'localhost' || host.endsWith('.localhost') || host.endsWith('.internal') || host.endsWith('.local')) return 'local hosts are not allowed';
    const addresses = isIP(host) ? [{ address: host }] : await lookup(host, { all: true }).catch(() => []);
    if (!addresses.length) return `cannot resolve ${host}`;
    if (addresses.some((a) => isPrivateAddress(a.address))) return 'private network addresses are not allowed';
    return null;
}

async function proxy(req: Request): Promise<Response> {
    const raw = new URL(req.url).searchParams.get('url');
    if (!raw) return fail(400, 'url parameter is required');
    let target: URL;
    try {
        target = new URL(raw);
    } catch {
        return fail(400, 'invalid url');
    }

    const init: RequestInit = {
        method: req.method,
        headers: { Accept: req.headers.get('accept') ?? 'application/json, */*', 'User-Agent': 'On-Look-Proxy/1.0' },
        redirect: 'manual',
        signal: AbortSignal.timeout(TIMEOUT_MS),
    };
    if (req.method === 'POST') {
        const body = await req.arrayBuffer();
        if (body.byteLength > MAX_BYTES) return fail(413, 'request body too large');
        init.body = body;
        (init.headers as Record<string, string>)['Content-Type'] = req.headers.get('content-type') ?? 'application/json';
    }

    let res: Response;
    for (let hop = 0; ; hop++) {
        const problem = await checkTarget(target);
        if (problem) return fail(403, problem);
        try {
            res = await fetch(target, init);
        } catch (err) {
            return fail(502, `upstream request failed: ${err instanceof Error ? err.message : err}`);
        }
        const location = res.headers.get('location');
        if (res.status >= 300 && res.status < 400 && location) {
            if (hop >= MAX_REDIRECTS) return fail(502, 'too many redirects');
            target = new URL(location, target);
            if (res.status === 303) {
                init.method = 'GET';
                delete init.body;
            }
            continue;
        }
        break;
    }

    const length = Number(res.headers.get('content-length') ?? 0);
    if (length > MAX_BYTES) return fail(502, 'upstream response too large');
    const body = await res.arrayBuffer();
    if (body.byteLength > MAX_BYTES) return fail(502, 'upstream response too large');
    return new Response(body, {
        status: res.status,
        headers: { ...CORS, 'Content-Type': res.headers.get('content-type') ?? 'application/octet-stream', 'Cache-Control': 'no-store' },
    });
}

export const GET = proxy;
export const POST = proxy;

export function OPTIONS() {
    return new Response(null, { status: 204, headers: CORS });
}
