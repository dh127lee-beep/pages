import { Dashboard } from '@/components/dashboard';
import { listProjects } from '@/lib/store';
import { TEMPLATES } from '@/lib/templates';

export const dynamic = 'force-dynamic';

export default async function Home() {
    const projects = await listProjects();
    const templates = TEMPLATES.map(({ id, name, description }) => ({ id, name, description }));
    return <Dashboard initialProjects={projects} templates={templates} />;
}
