export interface Page {
    id: string;
    /** Display name shown in the editor. */
    name: string;
    /** URL segment: "index" for the home page, otherwise [a-z0-9-]. */
    path: string;
    html: string;
    /** Page JavaScript. Runs in preview/published pages only, never in the design canvas. */
    script: string;
}

export interface Project {
    id: string;
    name: string;
    pages: Page[];
    createdAt: string;
    updatedAt: string;
}

export type ProjectSummary = Omit<Project, 'pages'>;

export interface TreeNode {
    oid: string;
    tag: string;
    label: string;
    text: string;
    children: TreeNode[];
}

export interface ElementInfo {
    oid: string;
    tag: string;
    className: string;
    text: string | null;
    attrs: Record<string, string>;
    inline: Record<string, string>;
    computed: Record<string, string>;
    path: { oid: string; label: string }[];
    canMove: boolean;
    /** The nearest data-bound ancestor (or the element itself), if any. */
    bound: { oid: string; url: string; list: boolean; path: string } | null;
}
