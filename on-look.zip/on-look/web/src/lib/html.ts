const PRELOAD_TAG = '<script src="/ol-preload.js" data-ol-ignore></script>';

/**
 * Disable inline scripts for the design canvas so they cannot mutate the DOM that the
 * editor serializes back into the page source. The preload script restores the original
 * type attribute when serializing. External scripts (Tailwind CDN, libraries) still load.
 */
export function inertInlineScripts(html: string): string {
    return html.replace(/<script\b([^>]*)>/gi, (tag, attrs: string) => {
        if (/\bsrc\s*=/i.test(attrs) || /\bdata-ol-/i.test(attrs)) return tag;
        const typeMatch = attrs.match(/\btype\s*=\s*(["'])(.*?)\1/i);
        const rest = attrs.replace(/\s*\btype\s*=\s*(["']).*?\1/i, '');
        const original = typeMatch ? ` data-ol-type="${typeMatch[2]}"` : '';
        return `<script${rest} type="text/ol-inert" data-ol-inert${original}>`;
    });
}

/** Prepare page HTML for the design canvas: inert inline scripts + the editor preload script. */
export function withPreload(html: string): string {
    const doc = inertInlineScripts(html);
    if (/<\/body>/i.test(doc)) return doc.replace(/<\/body>(?![\s\S]*<\/body>)/i, `${PRELOAD_TAG}</body>`);
    return doc + PRELOAD_TAG;
}

/** Pull an HTML document or fragment out of a model reply that may wrap it in a code fence. */
export function extractHtml(text: string): string | null {
    const fenced = text.match(/```html\s*\n([\s\S]*?)```/i) ?? text.match(/```\s*\n(<[\s\S]*?)```/);
    const body = (fenced ? fenced[1] : text).trim();
    return body.startsWith('<') ? body : null;
}

/** Pull the page script out of a model reply (a ```js / ```javascript fence), if any. */
export function extractScript(text: string): string | null {
    const fenced = text.match(/```(?:js|javascript)\s*\n([\s\S]*?)```/i);
    return fenced ? fenced[1].trim() : null;
}

export function slugify(name: string): string {
    return name.trim().toLowerCase().replace(/[^a-z0-9가-힣]+/g, '-').replace(/^-|-$/g, '') || 'page';
}
