import type { Page } from './types';

/**
 * Build the document served for a page (published page, preview, or exported file):
 * page links are rewritten for the target, then the data-binding runtime and the
 * page script are appended. The design canvas never goes through this.
 */
export interface DocOptions {
    /** Maps a page path to the URL it should link to. */
    linkFor: (path: string) => string;
    /** Where the data-binding runtime is loaded from, or its source inlined. */
    runtime: { src: string } | { inline: string };
    /** CORS proxy endpoint for external API calls; omit to call APIs directly. */
    proxy?: string;
}

const LINK_ATTR = /(\s(?:href|data-ol-href)\s*=\s*)(["'])([^"']*)\2/gi;

export function rewritePageLinks(html: string, pages: Pick<Page, 'path'>[], linkFor: (path: string) => string): string {
    const paths = new Set(pages.map((p) => p.path));
    return html.replace(LINK_ATTR, (whole, prefix: string, quote: string, value: string) => {
        if (/^[a-z][a-z0-9+.-]*:|^\/\/|^#/i.test(value)) return whole; // external, protocol or anchor
        const m = value.match(/^([^?#]*)(.*)$/);
        if (!m) return whole;
        let target = m[1].replace(/^\.?\//, '').replace(/\/$/, '').replace(/\.html?$/i, '');
        if (target === '' || target === '.') target = 'index';
        if (!paths.has(target)) return whole;
        return `${prefix}${quote}${linkFor(target)}${m[2]}${quote}`;
    });
}

function scriptTag(code: string): string {
    return `<script>\n${code.replace(/<\/script/gi, '<\\/script')}\n</script>`;
}

export function buildPageDocument(page: Page, pages: Page[], opts: DocOptions): string {
    let html = rewritePageLinks(page.html, pages, opts.linkFor);
    const runtime =
        (opts.proxy ? scriptTag(`window.OL_PROXY = ${JSON.stringify(opts.proxy)};`) : '') +
        ('src' in opts.runtime ? `<script src="${opts.runtime.src}"></script>` : scriptTag(opts.runtime.inline)) +
        (page.script.trim() ? scriptTag(page.script) : '');
    if (/<\/body>/i.test(html)) html = html.replace(/<\/body>(?![\s\S]*<\/body>)/i, `${runtime}\n</body>`);
    else html += runtime;
    return html;
}
