import type { NewPage } from './store';

export interface Template {
    id: string;
    name: string;
    description: string;
    pages: NewPage[];
}

const head = (title: string) => `<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${title}</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>`;

export const TEMPLATES: Template[] = [
    {
        id: 'blank',
        name: '빈 페이지',
        description: '아무것도 없는 캔버스에서 시작합니다.',
        pages: [{ name: '홈', path: 'index', html: `${head('새 페이지')}
<body class="min-h-screen bg-white text-slate-900">
  <main class="max-w-3xl mx-auto px-6 py-24 text-center">
    <h1 class="text-4xl font-bold tracking-tight">새 페이지</h1>
    <p class="mt-4 text-slate-500">요소를 클릭해서 선택하고, 더블클릭해서 텍스트를 바로 수정해 보세요.</p>
  </main>
</body>
</html>` }],
    },
    {
        id: 'saas',
        name: 'SaaS 랜딩',
        description: '히어로, 기능 소개, 가격표, CTA가 있는 제품 랜딩 페이지.',
        pages: [{ name: '홈', path: 'index', html: `${head('Nimbus — 팀을 위한 협업 도구')}
<body class="bg-slate-950 text-slate-100 antialiased">
  <header class="max-w-6xl mx-auto flex items-center justify-between px-6 py-5">
    <a href="#" class="text-lg font-semibold tracking-tight">☁️ Nimbus</a>
    <nav class="hidden md:flex gap-8 text-sm text-slate-400">
      <a href="#features" class="hover:text-white">기능</a>
      <a href="#pricing" class="hover:text-white">가격</a>
      <a href="#" class="hover:text-white">고객 사례</a>
    </nav>
    <a href="#" class="rounded-lg bg-white px-4 py-2 text-sm font-medium text-slate-900">무료로 시작하기</a>
  </header>
  <section class="max-w-4xl mx-auto px-6 pt-20 pb-24 text-center">
    <span class="inline-block rounded-full border border-indigo-400/40 bg-indigo-500/10 px-3 py-1 text-xs text-indigo-300">새로운 기능 · AI 회의록 요약</span>
    <h1 class="mt-6 text-5xl md:text-6xl font-bold tracking-tight">흩어진 업무를<br>한 곳에서 정리하세요</h1>
    <p class="mt-6 text-lg text-slate-400">문서, 일정, 대화를 하나의 공간에. Nimbus는 팀이 더 적게 회의하고 더 많이 만들도록 돕습니다.</p>
    <div class="mt-10 flex flex-wrap justify-center gap-3">
      <a href="#" class="rounded-xl bg-indigo-500 px-6 py-3 font-medium hover:bg-indigo-400">14일 무료 체험</a>
      <a href="#" class="rounded-xl border border-slate-700 px-6 py-3 font-medium hover:bg-slate-900">데모 보기</a>
    </div>
  </section>
  <section id="features" class="max-w-6xl mx-auto grid md:grid-cols-3 gap-6 px-6 pb-24">
    <div class="rounded-2xl border border-slate-800 bg-slate-900/60 p-6">
      <div class="text-2xl">⚡️</div>
      <h3 class="mt-4 text-lg font-semibold">실시간 동기화</h3>
      <p class="mt-2 text-sm text-slate-400">모든 변경 사항이 팀 전체에 즉시 반영됩니다.</p>
    </div>
    <div class="rounded-2xl border border-slate-800 bg-slate-900/60 p-6">
      <div class="text-2xl">🔒</div>
      <h3 class="mt-4 text-lg font-semibold">엔터프라이즈 보안</h3>
      <p class="mt-2 text-sm text-slate-400">SSO, 감사 로그, 데이터 암호화를 기본 제공합니다.</p>
    </div>
    <div class="rounded-2xl border border-slate-800 bg-slate-900/60 p-6">
      <div class="text-2xl">🤖</div>
      <h3 class="mt-4 text-lg font-semibold">AI 어시스턴트</h3>
      <p class="mt-2 text-sm text-slate-400">회의록 요약, 할 일 추출을 자동으로 처리합니다.</p>
    </div>
  </section>
  <section id="pricing" class="max-w-4xl mx-auto grid md:grid-cols-2 gap-6 px-6 pb-24">
    <div class="rounded-2xl border border-slate-800 p-8">
      <h3 class="font-semibold">스타터</h3>
      <p class="mt-4 text-4xl font-bold">₩0<span class="text-base font-normal text-slate-500"> /월</span></p>
      <ul class="mt-6 space-y-2 text-sm text-slate-400"><li>✓ 팀원 5명</li><li>✓ 프로젝트 3개</li><li>✓ 커뮤니티 지원</li></ul>
    </div>
    <div class="rounded-2xl border-2 border-indigo-500 bg-indigo-500/5 p-8">
      <h3 class="font-semibold text-indigo-300">프로</h3>
      <p class="mt-4 text-4xl font-bold">₩12,000<span class="text-base font-normal text-slate-500"> /인·월</span></p>
      <ul class="mt-6 space-y-2 text-sm text-slate-400"><li>✓ 무제한 팀원</li><li>✓ 무제한 프로젝트</li><li>✓ 우선 지원 · AI 기능</li></ul>
    </div>
  </section>
  <footer class="border-t border-slate-800 py-10 text-center text-sm text-slate-500">© 2026 Nimbus Inc.</footer>
</body>
</html>` }],
    },
    {
        id: 'portfolio',
        name: '포트폴리오',
        description: '디자이너·개발자를 위한 미니멀한 소개 페이지.',
        pages: [{ name: '홈', path: 'index', html: `${head('김하늘 — 프로덕트 디자이너')}
<body class="bg-stone-50 text-stone-900">
  <main class="max-w-3xl mx-auto px-6 py-20">
    <div class="flex items-center gap-4">
      <img src="https://picsum.photos/seed/onlook/160/160" alt="프로필" class="h-16 w-16 rounded-full object-cover">
      <div>
        <h1 class="text-2xl font-semibold">김하늘</h1>
        <p class="text-stone-500">프로덕트 디자이너 · 서울</p>
      </div>
    </div>
    <p class="mt-10 text-xl leading-relaxed">복잡한 문제를 단순한 인터페이스로 바꾸는 일을 합니다. 지난 6년간 핀테크와 헬스케어 제품을 디자인했습니다.</p>
    <h2 class="mt-16 text-sm font-semibold uppercase tracking-widest text-stone-400">작업</h2>
    <div class="mt-6 grid sm:grid-cols-2 gap-6">
      <a href="#" class="group block">
        <img src="https://picsum.photos/seed/work1/600/400" alt="" class="rounded-xl aspect-[3/2] object-cover w-full">
        <h3 class="mt-3 font-medium group-hover:underline">모바일 뱅킹 리디자인</h3>
        <p class="text-sm text-stone-500">2025 · UX 리서치, UI</p>
      </a>
      <a href="#" class="group block">
        <img src="https://picsum.photos/seed/work2/600/400" alt="" class="rounded-xl aspect-[3/2] object-cover w-full">
        <h3 class="mt-3 font-medium group-hover:underline">원격 진료 예약 시스템</h3>
        <p class="text-sm text-stone-500">2024 · 서비스 디자인</p>
      </a>
    </div>
    <h2 class="mt-16 text-sm font-semibold uppercase tracking-widest text-stone-400">연락</h2>
    <p class="mt-4"><a href="mailto:hello@example.com" class="underline underline-offset-4">hello@example.com</a></p>
  </main>
</body>
</html>` }],
    },
    {
        id: 'cafe',
        name: '카페 · 로컬 매장',
        description: '메뉴, 위치, 영업시간을 담은 매장 소개 페이지.',
        pages: [{ name: '홈', path: 'index', html: `${head('모래알 커피')}
<body class="bg-amber-50 text-amber-950">
  <section class="relative h-[70vh] min-h-[420px] flex items-end">
    <img src="https://picsum.photos/seed/cafe/1600/900" alt="" class="absolute inset-0 h-full w-full object-cover">
    <div class="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"></div>
    <div class="relative max-w-5xl mx-auto w-full px-6 pb-12 text-white">
      <p class="text-sm tracking-widest">SINCE 2019 · 연남동</p>
      <h1 class="mt-2 text-5xl font-bold">모래알 커피</h1>
      <p class="mt-3 max-w-md text-white/80">직접 로스팅한 원두로 매일 아침 천천히 내립니다.</p>
    </div>
  </section>
  <section class="max-w-5xl mx-auto px-6 py-16">
    <h2 class="text-2xl font-bold">메뉴</h2>
    <div class="mt-6 divide-y divide-amber-200">
      <div class="flex justify-between py-4"><span>아메리카노</span><span class="font-medium">4,500</span></div>
      <div class="flex justify-between py-4"><span>플랫 화이트</span><span class="font-medium">5,500</span></div>
      <div class="flex justify-between py-4"><span>시그니처 모래알 라떼</span><span class="font-medium">6,500</span></div>
      <div class="flex justify-between py-4"><span>바스크 치즈케이크</span><span class="font-medium">7,000</span></div>
    </div>
  </section>
  <section class="bg-amber-900 text-amber-50">
    <div class="max-w-5xl mx-auto grid md:grid-cols-2 gap-8 px-6 py-16">
      <div><h2 class="text-xl font-bold">오시는 길</h2><p class="mt-3 text-amber-200">서울 마포구 연남로 12, 1층<br>홍대입구역 3번 출구 도보 5분</p></div>
      <div><h2 class="text-xl font-bold">영업시간</h2><p class="mt-3 text-amber-200">평일 08:00 – 21:00<br>주말 10:00 – 22:00 · 월요일 휴무</p></div>
    </div>
  </section>
</body>
</html>` }],
    },
    {
        id: 'blog',
        name: '블로그 · API 연동',
        description: '여러 페이지 + API 데이터 표시. 목록에서 글을 누르면 상세 페이지가 API로 내용을 불러옵니다.',
        pages: [
            {
                name: '홈',
                path: 'index',
                html: `${head('오늘의 기록')}
<body class="bg-white text-slate-900">
  <header class="border-b border-slate-200">
    <nav class="max-w-5xl mx-auto flex items-center justify-between px-6 py-4">
      <a href="index" class="font-bold">📝 오늘의 기록</a>
      <div class="flex gap-6 text-sm text-slate-500"><a href="index" class="text-slate-900">글 목록</a><a href="about" class="hover:text-slate-900">소개</a></div>
    </nav>
  </header>
  <section class="max-w-5xl mx-auto px-6 pt-16 pb-8">
    <h1 class="text-4xl font-bold tracking-tight">최근 글</h1>
    <p class="mt-3 text-slate-500">아래 목록은 페이지를 열 때마다 API에서 불러옵니다.</p>
  </section>
  <section class="max-w-5xl mx-auto px-6 pb-24">
    <div data-ol-fetch="https://jsonplaceholder.typicode.com/posts" data-ol-list data-ol-limit="9" class="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
      <a href="post" data-ol-href="post?id={id}" class="block rounded-2xl border border-slate-200 p-6 transition hover:border-indigo-400 hover:shadow-lg">
        <span class="text-xs font-medium text-indigo-500" data-ol-text="글 #{id}">글 #1</span>
        <h2 class="mt-2 text-lg font-semibold leading-snug" data-ol-text="title">글 제목이 여기에 표시됩니다</h2>
        <p class="mt-2 line-clamp-3 text-sm text-slate-500" data-ol-text="body">본문 미리보기가 여기에 표시됩니다.</p>
      </a>
    </div>
  </section>
</body>
</html>`,
            },
            {
                name: '글 상세',
                path: 'post',
                html: `${head('글 상세 — 오늘의 기록')}
<body class="bg-white text-slate-900">
  <header class="border-b border-slate-200">
    <nav class="max-w-3xl mx-auto flex items-center justify-between px-6 py-4">
      <a href="index" class="font-bold">📝 오늘의 기록</a>
      <a href="index" class="text-sm text-slate-500 hover:text-slate-900">← 목록으로</a>
    </nav>
  </header>
  <article data-ol-fetch="https://jsonplaceholder.typicode.com/posts/{query.id}" class="max-w-3xl mx-auto px-6 py-16">
    <p class="text-sm font-medium text-indigo-500" data-ol-text="글 #{id} · 작성자 {userId}">글 #1</p>
    <h1 class="mt-3 text-4xl font-bold tracking-tight" data-ol-text="title">글 제목</h1>
    <p class="mt-8 whitespace-pre-line text-lg leading-relaxed text-slate-700" data-ol-text="body">글 본문이 여기에 표시됩니다.</p>
  </article>
  <section class="max-w-3xl mx-auto px-6 pb-24">
    <h2 class="text-xl font-semibold">댓글</h2>
    <ul data-ol-fetch="https://jsonplaceholder.typicode.com/posts/{query.id}/comments" data-ol-list class="mt-6 space-y-4">
      <li class="rounded-xl bg-slate-50 p-5">
        <p class="text-sm font-semibold" data-ol-text="name">댓글 제목</p>
        <p class="text-xs text-slate-400" data-ol-text="email">email@example.com</p>
        <p class="mt-2 text-sm text-slate-600" data-ol-text="body">댓글 내용</p>
      </li>
    </ul>
  </section>
</body>
</html>`,
            },
            {
                name: '소개',
                path: 'about',
                html: `${head('소개 — 오늘의 기록')}
<body class="bg-slate-50 text-slate-900">
  <header class="border-b border-slate-200 bg-white">
    <nav class="max-w-3xl mx-auto flex items-center justify-between px-6 py-4">
      <a href="index" class="font-bold">📝 오늘의 기록</a>
      <div class="flex gap-6 text-sm text-slate-500"><a href="index" class="hover:text-slate-900">글 목록</a><a href="about" class="text-slate-900">소개</a></div>
    </nav>
  </header>
  <main class="max-w-3xl mx-auto px-6 py-16">
    <h1 class="text-4xl font-bold tracking-tight">안녕하세요 👋</h1>
    <p class="mt-6 text-lg leading-relaxed text-slate-600">매일 조금씩 배우고 기록하는 블로그입니다. 이 페이지의 버튼은 페이지 스크립트(JavaScript)로 동작합니다.</p>
    <button id="like" class="mt-8 rounded-full bg-pink-500 px-6 py-3 font-medium text-white hover:bg-pink-400">❤️ 좋아요 <span id="like-count">0</span></button>
  </main>
</body>
</html>`,
                script: `const button = document.getElementById('like');
const count = document.getElementById('like-count');
let likes = 0;
button.addEventListener('click', () => {
  likes += 1;
  count.textContent = likes;
});`,
            },
        ],
    },
];

export function getTemplate(id: string | undefined): Template {
    return TEMPLATES.find((t) => t.id === id) ?? TEMPLATES[0];
}
