import type { Page } from './types';

export const PAGE_PATH = /^(index|[a-z0-9][a-z0-9-]{0,47})$/;
export const MAX_PAGES = 50;

/** Turn a page name into a URL segment; falls back to page-N for names without ASCII letters. */
export function pathFromName(name: string, taken: string[]): string {
    const base =
        name
            .trim()
            .toLowerCase()
            .replace(/[^a-z0-9]+/g, '-')
            .replace(/^-+|-+$/g, '')
            .slice(0, 40) || 'page';
    let candidate = base === 'index' ? 'page' : base;
    for (let n = 2; taken.includes(candidate); n++) candidate = `${base}-${n}`;
    return candidate;
}

export function pageUrl(projectId: string, path: string): string {
    return path === 'index' ? `/p/${projectId}` : `/p/${projectId}/${path}`;
}

/** Validate a client-supplied page list. Returns an error message, or null when valid. */
export function validatePages(pages: unknown): string | null {
    if (!Array.isArray(pages) || pages.length === 0) return 'pages must be a non-empty array';
    if (pages.length > MAX_PAGES) return `at most ${MAX_PAGES} pages`;
    const paths = new Set<string>();
    const ids = new Set<string>();
    for (const p of pages as Page[]) {
        if (!p || typeof p !== 'object') return 'invalid page';
        if (typeof p.id !== 'string' || !p.id || ids.has(p.id)) return 'invalid or duplicate page id';
        if (typeof p.name !== 'string' || !p.name.trim()) return 'page name is required';
        if (typeof p.path !== 'string' || !PAGE_PATH.test(p.path) || paths.has(p.path)) return `invalid or duplicate page path: ${p.path}`;
        if (typeof p.html !== 'string' || typeof p.script !== 'string') return 'page html/script must be strings';
        ids.add(p.id);
        paths.add(p.path);
    }
    if (!paths.has('index')) return 'an index page is required';
    return null;
}
