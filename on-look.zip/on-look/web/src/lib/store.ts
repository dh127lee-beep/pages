import 'server-only';
import { promises as fs } from 'fs';
import path from 'path';
import { nanoid } from 'nanoid';
import type { Page, Project, ProjectSummary } from './types';

const DATA_DIR = process.env.ONLOOK_DATA_DIR ?? path.join(process.cwd(), 'data', 'projects');
const ID_PATTERN = /^[A-Za-z0-9_-]{6,32}$/;

export type NewPage = Pick<Page, 'name' | 'path' | 'html'> & { script?: string };

async function ensureDir() {
    await fs.mkdir(DATA_DIR, { recursive: true });
}

function fileFor(id: string): string {
    if (!ID_PATTERN.test(id)) throw new Error('Invalid project id');
    return path.join(DATA_DIR, `${id}.json`);
}

/** Projects saved before multi-page support stored a single `html` string. */
function normalize(raw: Project & { html?: string }): Project {
    if (Array.isArray(raw.pages) && raw.pages.length) return raw;
    const { html = '', ...rest } = raw;
    return { ...rest, pages: [{ id: nanoid(8), name: '홈', path: 'index', html, script: '' }] };
}

export function newPage(p: NewPage): Page {
    return { id: nanoid(8), name: p.name, path: p.path, html: p.html, script: p.script ?? '' };
}

export async function listProjects(): Promise<ProjectSummary[]> {
    await ensureDir();
    const files = (await fs.readdir(DATA_DIR)).filter((f) => f.endsWith('.json'));
    const projects = await Promise.all(
        files.map(async (f) => {
            const p = JSON.parse(await fs.readFile(path.join(DATA_DIR, f), 'utf8')) as Project;
            return { id: p.id, name: p.name, createdAt: p.createdAt, updatedAt: p.updatedAt };
        }),
    );
    return projects.sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
}

export async function getProject(id: string): Promise<Project | null> {
    try {
        return normalize(JSON.parse(await fs.readFile(fileFor(id), 'utf8')));
    } catch {
        return null;
    }
}

async function write(project: Project) {
    await ensureDir();
    const target = fileFor(project.id);
    const tmp = `${target}.${process.pid}.tmp`;
    await fs.writeFile(tmp, JSON.stringify(project), 'utf8');
    await fs.rename(tmp, target);
}

export async function createProject(name: string, pages: NewPage[]): Promise<Project> {
    const now = new Date().toISOString();
    const project: Project = { id: nanoid(10), name, pages: pages.map(newPage), createdAt: now, updatedAt: now };
    await write(project);
    return project;
}

export async function updateProject(id: string, patch: Partial<Pick<Project, 'name' | 'pages'>>): Promise<Project | null> {
    const project = await getProject(id);
    if (!project) return null;
    const next: Project = { ...project, ...patch, updatedAt: new Date().toISOString() };
    await write(next);
    return next;
}

export async function deleteProject(id: string): Promise<boolean> {
    try {
        await fs.unlink(fileFor(id));
        return true;
    } catch {
        return false;
    }
}
