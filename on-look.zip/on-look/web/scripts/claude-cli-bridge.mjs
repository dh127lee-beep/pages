#!/usr/bin/env node
/**
 * OpenAI-compatible chat endpoint backed by the local Claude Code CLI.
 *
 *   node scripts/claude-cli-bridge.mjs            # http://127.0.0.1:8787/v1
 *
 * Lets the office server use a signed-in `claude` CLI as its AI provider
 * (Settings → AI → Custom, or AI_PROVIDER=custom + AI_BASE_URL). Every
 * request runs `claude -p` with all built-in tools disabled; the editors' own
 * agent tools are described in the system prompt and the model answers with
 * <tool_call> blocks, which are returned as OpenAI `tool_calls`.
 *
 * Env: BRIDGE_PORT (8787), BRIDGE_HOST (127.0.0.1), BRIDGE_KEY (required bearer
 * token; generated and printed when unset), BRIDGE_MODEL (default model),
 * BRIDGE_CONCURRENCY (3), BRIDGE_TIMEOUT_MS (300000), CLAUDE_BIN (claude).
 */

import { spawn } from 'node:child_process'
import { randomBytes, randomUUID } from 'node:crypto'
import { mkdtempSync } from 'node:fs'
import http from 'node:http'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

const PORT = Number(process.env.BRIDGE_PORT ?? 8787)
const HOST = process.env.BRIDGE_HOST ?? '127.0.0.1'
const KEY = process.env.BRIDGE_KEY || `sk-bridge-${randomBytes(18).toString('base64url')}`
const DEFAULT_MODEL = process.env.BRIDGE_MODEL ?? 'sonnet'
const CONCURRENCY = Number(process.env.BRIDGE_CONCURRENCY ?? 3)
const TIMEOUT_MS = Number(process.env.BRIDGE_TIMEOUT_MS ?? 300_000)
const CLAUDE = process.env.CLAUDE_BIN ?? 'claude'
const MODELS = ['sonnet', 'opus', 'haiku']

/** an empty working directory: no project CLAUDE.md or settings leak into requests */
const WORKDIR = mkdtempSync(join(tmpdir(), 'claude-bridge-'))

// ---- concurrency gate ---------------------------------------------------------------

let running = 0
const waiting = []
async function acquire() {
  if (running < CONCURRENCY) {
    running++
    return
  }
  await new Promise((resolve) => waiting.push(resolve))
  running++
}
function release() {
  running--
  waiting.shift()?.()
}

// ---- prompt construction ------------------------------------------------------------

const TOOL_PROTOCOL = `
# Tools
You can call the tools listed below. To call a tool, write a block exactly like:
<tool_call>{"name": "TOOL_NAME", "arguments": {...}}</tool_call>
- "arguments" must be a JSON object matching the tool's parameter schema.
- You may write a short sentence before the block(s). You may emit several blocks.
- After your tool call block(s), STOP and end your reply: the results arrive in the next turn as [tool result] entries.
- Never invent tool results. When no tool is needed, just answer normally.

Available tools (JSON schema):
`

function textOf(content) {
  if (typeof content === 'string') return content
  if (Array.isArray(content)) {
    return content
      .map((p) => (p?.type === 'text' ? p.text : p?.type === 'image_url' ? '[image attached]' : ''))
      .join('\n')
  }
  return content == null ? '' : String(content)
}

function imagesOf(content) {
  if (!Array.isArray(content)) return []
  const out = []
  for (const p of content) {
    const url = p?.type === 'image_url' ? p.image_url?.url : null
    const m = typeof url === 'string' ? /^data:(image\/[a-z+.-]+);base64,(.*)$/i.exec(url) : null
    if (m) out.push({ type: 'image', source: { type: 'base64', media_type: m[1], data: m[2] } })
  }
  return out
}

/** OpenAI chat request → { system, user content blocks } for one `claude -p` turn */
function buildPrompt(body) {
  const messages = Array.isArray(body.messages) ? body.messages : []
  const systemParts = messages.filter((m) => m.role === 'system').map((m) => textOf(m.content))
  const tools = Array.isArray(body.tools) ? body.tools : []
  if (tools.length) {
    const defs = tools.map((t) => ({
      name: t.function?.name,
      description: t.function?.description,
      parameters: t.function?.parameters,
    }))
    systemParts.push(TOOL_PROTOCOL + JSON.stringify(defs, null, 1))
  }

  const turns = messages.filter((m) => m.role !== 'system')
  const transcript = []
  const images = []
  turns.forEach((m, i) => {
    const last = i === turns.length - 1
    if (m.role === 'user') {
      transcript.push(`[user]\n${textOf(m.content)}`)
      // pictures are only sent for the turn being answered (they are large)
      if (last) images.push(...imagesOf(m.content))
    } else if (m.role === 'assistant') {
      const calls = (m.tool_calls ?? [])
        .map((c) => `<tool_call>{"name": ${JSON.stringify(c.function?.name)}, "arguments": ${c.function?.arguments || '{}'}}</tool_call>`)
        .join('\n')
      transcript.push(`[assistant]\n${[textOf(m.content), calls].filter(Boolean).join('\n')}`)
    } else if (m.role === 'tool') {
      transcript.push(`[tool result id=${m.tool_call_id}]\n${textOf(m.content)}`)
    }
  })
  const lastRole = turns.at(-1)?.role
  const instruction =
    turns.length > 1 || lastRole === 'tool'
      ? '\n\nContinue the conversation above as the assistant. Reply with your next assistant message only.'
      : ''
  const text =
    turns.length === 1 && lastRole === 'user'
      ? textOf(turns[0].content)
      : `Conversation so far:\n\n${transcript.join('\n\n')}${instruction}`
  return { system: systemParts.join('\n\n'), content: [{ type: 'text', text }, ...images] }
}

// ---- tool-call parsing ------------------------------------------------------------------

const OPEN = '<tool_call>'
const CALL_RE = /<tool_call>\s*([\s\S]*?)\s*<\/tool_call>/g

function parseToolCalls(text) {
  const calls = []
  for (const m of text.matchAll(CALL_RE)) {
    try {
      const obj = JSON.parse(m[1])
      if (obj && typeof obj.name === 'string') {
        calls.push({ name: obj.name, arguments: JSON.stringify(obj.arguments ?? {}) })
      }
    } catch {
      // malformed block: left out; the visible text still shows it
    }
  }
  return calls
}

/** how much of `buf` can be shown now without risking half of an opening tag */
function safeLength(buf) {
  const at = buf.indexOf(OPEN)
  if (at >= 0) return at
  for (let k = Math.min(OPEN.length - 1, buf.length); k > 0; k--) {
    if (OPEN.startsWith(buf.slice(buf.length - k))) return buf.length - k
  }
  return buf.length
}

// ---- running the CLI ---------------------------------------------------------------------

function runClaude({ system, content, model, signal, onText }) {
  return new Promise((resolve, reject) => {
    const args = [
      '-p',
      '--input-format', 'stream-json',
      '--output-format', 'stream-json',
      '--include-partial-messages',
      '--verbose',
      '--tools', '',
      '--no-session-persistence',
      '--strict-mcp-config',
      '--setting-sources', '',
      '--model', model,
    ]
    if (system) args.push('--system-prompt', system)
    const child = spawn(CLAUDE, args, { cwd: WORKDIR, stdio: ['pipe', 'pipe', 'pipe'] })
    let full = ''
    let usage = null
    let stderr = ''
    let lineBuf = ''
    let failure = null
    const timer = setTimeout(() => child.kill('SIGTERM'), TIMEOUT_MS)
    const onAbort = () => child.kill('SIGTERM')
    signal.addEventListener('abort', onAbort)

    child.stdout.setEncoding('utf8')
    child.stdout.on('data', (chunk) => {
      lineBuf += chunk
      let nl
      while ((nl = lineBuf.indexOf('\n')) >= 0) {
        const line = lineBuf.slice(0, nl).trim()
        lineBuf = lineBuf.slice(nl + 1)
        if (!line) continue
        let ev
        try {
          ev = JSON.parse(line)
        } catch {
          continue
        }
        const e = ev.type === 'stream_event' ? ev.event : null
        if (e?.type === 'content_block_delta' && e.delta?.type === 'text_delta') {
          full += e.delta.text
          onText(full)
        } else if (ev.type === 'result') {
          usage = ev.usage ?? null
          if (ev.is_error) failure = ev.result || ev.subtype || 'claude CLI error'
          // the final text, in case partial events were missed
          if (typeof ev.result === 'string' && ev.result.length > full.length && !ev.is_error) {
            full = ev.result
            onText(full)
          }
        }
      }
    })
    child.stderr.on('data', (d) => (stderr += d).length > 8000 && (stderr = stderr.slice(-8000)))
    child.on('error', reject)
    child.on('close', (code) => {
      clearTimeout(timer)
      signal.removeEventListener('abort', onAbort)
      if (signal.aborted) return reject(new Error('aborted'))
      if (failure) return reject(new Error(failure))
      if (code !== 0 && !full) return reject(new Error(stderr.trim() || `claude exited with ${code}`))
      resolve({ text: full, usage })
    })
    child.stdin.end(`${JSON.stringify({ type: 'user', message: { role: 'user', content } })}\n`)
  })
}

// ---- HTTP ------------------------------------------------------------------------------

function sendJson(res, status, obj) {
  res.writeHead(status, { 'content-type': 'application/json' })
  res.end(JSON.stringify(obj))
}

function authorized(req) {
  return req.headers.authorization === `Bearer ${KEY}`
}

async function readJson(req) {
  let raw = ''
  for await (const chunk of req) {
    raw += chunk
    if (raw.length > 64 * 1024 * 1024) throw new Error('request too large')
  }
  return JSON.parse(raw || '{}')
}

async function chatCompletions(req, res) {
  const body = await readJson(req)
  const model = typeof body.model === 'string' && body.model ? body.model : DEFAULT_MODEL
  const { system, content } = buildPrompt(body)
  const id = `chatcmpl-${randomUUID()}`
  const created = Math.floor(Date.now() / 1000)
  const controller = new AbortController()
  res.on('close', () => {
    if (!res.writableEnded) controller.abort()
  })

  const chunk = (delta, finish = null, extra = {}) => ({
    id,
    object: 'chat.completion.chunk',
    created,
    model,
    choices: [{ index: 0, delta, finish_reason: finish }],
    ...extra,
  })

  await acquire()
  const started = Date.now()
  try {
    if (body.stream) {
      res.writeHead(200, {
        'content-type': 'text/event-stream',
        'cache-control': 'no-cache',
        connection: 'keep-alive',
      })
      const write = (obj) => res.write(`data: ${JSON.stringify(obj)}\n\n`)
      // keepalive while the CLI starts / thinks
      const ping = setInterval(() => res.write(': ping\n\n'), 5_000)
      write(chunk({ role: 'assistant', content: '' }))
      let shown = 0
      try {
        const { text, usage } = await runClaude({
          system,
          content,
          model,
          signal: controller.signal,
          onText: (full) => {
            const safe = safeLength(full)
            if (safe > shown) {
              write(chunk({ content: full.slice(shown, safe) }))
              shown = safe
            }
          },
        })
        const calls = parseToolCalls(text)
        if (!calls.length && shown < text.length) write(chunk({ content: text.slice(shown) }))
        calls.forEach((c, index) =>
          write(
            chunk({
              tool_calls: [
                { index, id: `call_${randomUUID().slice(0, 12)}`, type: 'function', function: { name: c.name, arguments: c.arguments } },
              ],
            }),
          ),
        )
        write(
          chunk({}, calls.length ? 'tool_calls' : 'stop', {
            usage: usage
              ? { prompt_tokens: usage.input_tokens ?? 0, completion_tokens: usage.output_tokens ?? 0 }
              : undefined,
          }),
        )
        res.end('data: [DONE]\n\n')
        console.log(`[bridge] ${model} ${calls.length ? `${calls.length} tool call(s)` : 'text'} in ${Date.now() - started}ms`)
      } catch (err) {
        if (!controller.signal.aborted) {
          write({ error: { message: String(err.message ?? err), type: 'bridge_error' } })
          res.end('data: [DONE]\n\n')
          console.warn(`[bridge] error: ${err.message ?? err}`)
        }
      } finally {
        clearInterval(ping)
      }
      return
    }

    const { text, usage } = await runClaude({ system, content, model, signal: controller.signal, onText: () => {} })
    const calls = parseToolCalls(text)
    const visible = calls.length ? text.slice(0, safeLength(text)).trim() : text
    sendJson(res, 200, {
      id,
      object: 'chat.completion',
      created,
      model,
      choices: [
        {
          index: 0,
          message: {
            role: 'assistant',
            content: visible || null,
            ...(calls.length
              ? {
                  tool_calls: calls.map((c) => ({
                    id: `call_${randomUUID().slice(0, 12)}`,
                    type: 'function',
                    function: { name: c.name, arguments: c.arguments },
                  })),
                }
              : {}),
          },
          finish_reason: calls.length ? 'tool_calls' : 'stop',
        },
      ],
      usage: usage ? { prompt_tokens: usage.input_tokens ?? 0, completion_tokens: usage.output_tokens ?? 0 } : undefined,
    })
    console.log(`[bridge] ${model} (json) in ${Date.now() - started}ms`)
  } catch (err) {
    if (!res.headersSent) sendJson(res, 502, { error: { message: String(err.message ?? err) } })
  } finally {
    release()
  }
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url ?? '/', 'http://bridge')
    if (req.method === 'GET' && url.pathname === '/healthz') return sendJson(res, 200, { ok: true })
    if (!authorized(req)) return sendJson(res, 401, { error: { message: 'invalid API key' } })
    if (req.method === 'GET' && url.pathname === '/v1/models') {
      return sendJson(res, 200, {
        object: 'list',
        data: MODELS.map((id) => ({ id, object: 'model', owned_by: 'claude-cli' })),
      })
    }
    if (req.method === 'POST' && url.pathname === '/v1/chat/completions') return await chatCompletions(req, res)
    sendJson(res, 404, { error: { message: 'not found' } })
  } catch (err) {
    if (!res.headersSent) sendJson(res, 400, { error: { message: String(err.message ?? err) } })
  }
})

server.listen(PORT, HOST, () => {
  console.log(`[bridge] Claude CLI as OpenAI-compatible API on http://${HOST}:${PORT}/v1`)
  console.log(`[bridge] API key: ${KEY}`)
  console.log(`[bridge] models: ${MODELS.join(', ')} (default ${DEFAULT_MODEL})`)
})
