#!/usr/bin/env node
/**
 * Starts the Claude CLI bridge for On-Look using the settings in .env.local:
 *   ONLOOK_AI_BASE_URL → port, ONLOOK_AI_API_KEY → bearer key, ONLOOK_AI_MODEL → default model.
 *   npm run bridge
 */
import { readFileSync } from 'node:fs';

const envFile = new URL('../.env.local', import.meta.url);
for (const line of readFileSync(envFile, 'utf8').split('\n')) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
    if (m && !(m[1] in process.env)) process.env[m[1]] = m[2].replace(/^["']|["']$/g, '');
}

const url = new URL(process.env.ONLOOK_AI_BASE_URL ?? 'http://127.0.0.1:8789/v1');
process.env.BRIDGE_HOST ??= url.hostname;
process.env.BRIDGE_PORT ??= url.port || '8789';
process.env.BRIDGE_MODEL ??= process.env.ONLOOK_AI_MODEL ?? 'opus';
// Generating a full page can take several minutes; the bridge's own default (5 min) is too tight.
process.env.BRIDGE_TIMEOUT_MS ??= '600000';
if (!process.env.BRIDGE_KEY) {
    if (!process.env.ONLOOK_AI_API_KEY) throw new Error('ONLOOK_AI_API_KEY is missing in .env.local');
    process.env.BRIDGE_KEY = process.env.ONLOOK_AI_API_KEY;
}

await import('./claude-cli-bridge.mjs');
