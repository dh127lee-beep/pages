/*
 * On-Look runtime: declarative API data binding for published and preview pages.
 * (Not loaded in the design canvas, so the bound markup stays editable as a template.)
 *
 *   <ul data-ol-fetch="https://api.example.com/items?page={query.page}" data-ol-path="data.items" data-ol-list data-ol-limit="10">
 *     <li><a data-ol-href="detail?id={id}" data-ol-text="title">template item</a></li>
 *   </ul>
 *
 * - data-ol-fetch   URL to GET (JSON). {query.x} is replaced with the page's ?x= value.
 * - data-ol-path    dot path into the response (e.g. "data.items").
 * - data-ol-list    repeat the first child element once per array item (implied when the data is an array).
 * - data-ol-limit   max number of list items.
 * - data-ol-text / data-ol-src / data-ol-href / data-ol-alt / data-ol-value
 *                   a field path ("author.name", "." for the item itself) or a template ("#{id} {title}").
 *
 * Scripts can use window.ol.getJSON(url) / window.ol.api(url, init); external URLs go through the
 * On-Look CORS proxy when one is configured (window.OL_PROXY).
 */
(function () {
    'use strict';

    var FIELDS = ['text', 'src', 'href', 'alt', 'value'];
    var query = new URLSearchParams(location.search);

    function api(url, init) {
        var u = new URL(url, location.href);
        var external = /^https?:$/.test(u.protocol) && u.host !== location.host;
        if (window.OL_PROXY && external) {
            return fetch(window.OL_PROXY + '?url=' + encodeURIComponent(u.href), init);
        }
        return fetch(u.href, init);
    }

    function getJSON(url) {
        return api(url).then(function (res) {
            if (!res.ok) throw new Error('HTTP ' + res.status);
            return res.json();
        });
    }

    function get(obj, path) {
        if (path === '.' || path === '' || path == null) return obj;
        return String(path).split('.').reduce(function (cur, key) {
            return cur == null ? undefined : cur[key];
        }, obj);
    }

    function interpolate(template, data, encode) {
        return template.replace(/\{([^{}]+)\}/g, function (_, path) {
            path = path.trim();
            var v = path.indexOf('query.') === 0 ? query.get(path.slice(6)) : get(data, path);
            if (v == null) return '';
            return encode ? encodeURIComponent(String(v)) : String(v);
        });
    }

    function resolve(spec, data, isUrl) {
        if (spec.indexOf('{') !== -1) return interpolate(spec, data, isUrl);
        var v = get(data, spec);
        return v == null ? '' : typeof v === 'object' ? JSON.stringify(v) : String(v);
    }

    /** Fill bound fields of `root` (itself included) without descending into nested fetch scopes. */
    function fill(root, data) {
        var nodes = [root].concat(Array.prototype.slice.call(root.querySelectorAll('*')));
        nodes.forEach(function (el) {
            if (el !== root && el.closest('[data-ol-fetch]') !== root.closest('[data-ol-fetch]')) return;
            FIELDS.forEach(function (f) {
                var spec = el.getAttribute('data-ol-' + f);
                if (spec == null) return;
                var isUrl = f === 'src' || f === 'href';
                var value = resolve(spec, data, isUrl);
                if (f === 'text') el.textContent = value;
                else if (f === 'value') el.value = value;
                else el.setAttribute(f, value);
            });
        });
    }

    function load(el) {
        var spec = el.getAttribute('data-ol-fetch') || '';
        var missing = (spec.match(/\{query\.([^}]+)\}/g) || []).filter(function (m) { return !query.get(m.slice(7, -1)); });
        if (missing.length) {
            // e.g. a detail page opened without ?id= : keep the template instead of fetching a wrong URL.
            el.setAttribute('data-ol-error', 'missing ' + missing.join(', '));
            return Promise.resolve();
        }
        var url = interpolate(spec, {}, true);
        if (!url) return Promise.resolve();
        el.setAttribute('aria-busy', 'true');
        return getJSON(url)
            .then(function (json) {
                var data = get(json, el.getAttribute('data-ol-path'));
                if (el.hasAttribute('data-ol-list') || Array.isArray(data)) {
                    var template = el.__olTemplate || el.firstElementChild;
                    if (!template) return;
                    el.__olTemplate = template;
                    var items = Array.isArray(data) ? data : [];
                    var limit = parseInt(el.getAttribute('data-ol-limit') || '0', 10);
                    if (limit > 0) items = items.slice(0, limit);
                    el.replaceChildren();
                    items.forEach(function (item) {
                        var node = template.cloneNode(true);
                        el.appendChild(node);
                        fill(node, item);
                        // Nested fetches may reference the current item, e.g. /users/{userId}.
                        node.querySelectorAll('[data-ol-fetch]').forEach(function (nested) {
                            nested.setAttribute('data-ol-fetch', interpolate(nested.getAttribute('data-ol-fetch'), item, true));
                            load(nested);
                        });
                    });
                } else {
                    fill(el, data || {});
                }
                el.removeAttribute('data-ol-error');
                el.dispatchEvent(new CustomEvent('ol:loaded', { bubbles: true, detail: data }));
            })
            .catch(function (err) {
                el.setAttribute('data-ol-error', String(err.message || err));
                console.error('[on-look] data-ol-fetch failed for', url, err);
            })
            .then(function () {
                el.removeAttribute('aria-busy');
            });
    }

    function render(root) {
        var scope = root || document;
        var all = Array.prototype.slice.call(scope.querySelectorAll('[data-ol-fetch]'));
        // Only top-level scopes; nested ones load after their parent renders.
        var top = all.filter(function (el) {
            return !el.parentElement || !el.parentElement.closest('[data-ol-fetch]');
        });
        return Promise.all(top.map(load));
    }

    window.ol = { api: api, getJSON: getJSON, render: render, query: query };

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { render(); });
    else render();
})();
