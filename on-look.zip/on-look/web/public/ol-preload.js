/*
 * On-Look preload script.
 * Injected into the sandboxed canvas iframe (modeled on onlook's apps/web/preload).
 * Tags every element with a stable data-oid, draws hover/selection overlays,
 * handles inline text editing and applies DOM edits requested by the editor.
 * Communication with the editor happens over window.postMessage.
 */
(function () {
    'use strict';

    var OID = 'data-oid';
    var IGNORE = 'data-ol-ignore';
    var SKIP_TAGS = { SCRIPT: 1, STYLE: 1, LINK: 1, META: 1, NOSCRIPT: 1, TEMPLATE: 1 };
    var COMPUTED_PROPS = [
        'display', 'position', 'width', 'height', 'color', 'background-color',
        'font-size', 'font-weight', 'font-family', 'line-height', 'letter-spacing', 'text-align',
        'padding-top', 'padding-right', 'padding-bottom', 'padding-left',
        'margin-top', 'margin-right', 'margin-bottom', 'margin-left',
        'border-radius', 'border-width', 'border-color', 'opacity',
        'flex-direction', 'justify-content', 'align-items', 'gap',
    ];

    var nextOid = 1;
    var selectedOid = null;
    var hoveredOid = null;
    var editingEl = null;
    var hoverBox, selectBox, selectLabel;

    function post(type, payload) {
        window.parent.postMessage({ source: 'ol-preload', type: type, payload: payload || null }, '*');
    }

    function isEditable(el) {
        return el && el.nodeType === 1 && !SKIP_TAGS[el.tagName] && !el.closest('[' + IGNORE + ']');
    }

    function assignOids(root) {
        var all = [root].concat(Array.prototype.slice.call(root.querySelectorAll('*')));
        all.forEach(function (el) {
            if (!isEditable(el)) return;
            if (!el.hasAttribute(OID)) el.setAttribute(OID, 'e' + nextOid++);
        });
    }

    function byOid(oid) {
        if (!oid) return null;
        return document.querySelector('[' + OID + '="' + oid + '"]');
    }

    /* ---------- serialization ---------- */

    function serialize() {
        var clone = document.documentElement.cloneNode(true);
        clone.querySelectorAll('[' + IGNORE + ']').forEach(function (n) { n.remove(); });
        // Tailwind Play CDN injects its generated CSS at runtime; never persist it.
        clone.querySelectorAll('style').forEach(function (s) {
            if ((s.textContent || '').indexOf('! tailwindcss v') !== -1) s.remove();
        });
        clone.querySelectorAll('[' + OID + ']').forEach(function (n) { n.removeAttribute(OID); });
        clone.removeAttribute(OID);
        clone.querySelectorAll('[contenteditable]').forEach(function (n) { n.removeAttribute('contenteditable'); });
        // Inline scripts were made inert for the canvas; restore their original type.
        clone.querySelectorAll('script[data-ol-inert]').forEach(function (n) {
            var type = n.getAttribute('data-ol-type');
            if (type) n.setAttribute('type', type); else n.removeAttribute('type');
            n.removeAttribute('data-ol-type');
            n.removeAttribute('data-ol-inert');
        });
        return '<!DOCTYPE html>\n' + clone.outerHTML;
    }

    function cleanOuter(el) {
        var clone = el.cloneNode(true);
        clone.removeAttribute(OID);
        clone.querySelectorAll('[' + OID + ']').forEach(function (n) { n.removeAttribute(OID); });
        clone.querySelectorAll('[' + IGNORE + ']').forEach(function (n) { n.remove(); });
        return clone.outerHTML;
    }

    /* ---------- element info ---------- */

    function labelFor(el) {
        var label = el.tagName.toLowerCase();
        if (el.id) label += '#' + el.id;
        if (el.hasAttribute('data-ol-fetch')) label += ' ⚡';
        return label;
    }

    function textSnippet(el) {
        var t = '';
        el.childNodes.forEach(function (c) { if (c.nodeType === 3) t += c.textContent; });
        t = t.trim().replace(/\s+/g, ' ');
        return t.length > 40 ? t.slice(0, 40) + '…' : t;
    }

    function buildTree(el) {
        var children = [];
        Array.prototype.forEach.call(el.children, function (c) {
            if (isEditable(c)) children.push(buildTree(c));
        });
        return { oid: el.getAttribute(OID), tag: el.tagName.toLowerCase(), label: labelFor(el), text: textSnippet(el), children: children };
    }

    function isTextLeaf(el) {
        if (!el.childNodes.length) return ['P', 'H1', 'H2', 'H3', 'H4', 'H5', 'H6', 'SPAN', 'A', 'BUTTON', 'LI', 'LABEL'].indexOf(el.tagName) !== -1;
        return Array.prototype.every.call(el.childNodes, function (c) {
            return c.nodeType === 3 || (c.nodeType === 1 && ['BR', 'B', 'STRONG', 'I', 'EM', 'SPAN', 'U', 'SMALL'].indexOf(c.tagName) !== -1 && c.children.length === 0);
        });
    }

    function info(el) {
        if (!el) return null;
        var cs = getComputedStyle(el);
        var computed = {};
        COMPUTED_PROPS.forEach(function (p) { computed[p] = cs.getPropertyValue(p); });
        var inline = {};
        for (var i = 0; i < el.style.length; i++) {
            var p = el.style[i];
            inline[p] = el.style.getPropertyValue(p);
        }
        var attrs = {};
        ['id', 'href', 'src', 'alt', 'placeholder', 'target'].forEach(function (a) {
            if (el.hasAttribute(a)) attrs[a] = el.getAttribute(a);
        });
        // Data-binding attributes (see /ol-runtime.js).
        Array.prototype.forEach.call(el.attributes, function (a) {
            if (/^data-ol-(fetch|path|list|limit|text|src|href|alt|value)$/.test(a.name)) attrs[a.name] = a.value;
        });
        var scope = el.closest('[data-ol-fetch]');
        var bound = null;
        if (scope) bound = { oid: scope.getAttribute(OID), url: scope.getAttribute('data-ol-fetch'), list: scope.hasAttribute('data-ol-list'), path: scope.getAttribute('data-ol-path') || '' };
        var path = [];
        var cur = el;
        while (cur && cur.nodeType === 1 && cur.hasAttribute(OID)) {
            path.unshift({ oid: cur.getAttribute(OID), label: labelFor(cur) });
            cur = cur.parentElement;
        }
        var leaf = isTextLeaf(el);
        return {
            oid: el.getAttribute(OID),
            tag: el.tagName.toLowerCase(),
            className: typeof el.className === 'string' ? el.className : (el.getAttribute('class') || ''),
            text: leaf ? el.innerText : null,
            attrs: attrs,
            inline: inline,
            computed: computed,
            path: path,
            canMove: el !== document.body && el !== document.documentElement,
            bound: bound,
        };
    }

    /* ---------- overlays ---------- */

    function makeBox(color, dashed) {
        var d = document.createElement('div');
        d.setAttribute(IGNORE, '');
        d.style.cssText = 'position:fixed;pointer-events:none;z-index:2147483646;box-sizing:border-box;display:none;' +
            'border:' + (dashed ? '1px dashed ' : '2px solid ') + color + ';' + (dashed ? '' : 'background:rgba(99,102,241,.06);');
        document.documentElement.appendChild(d);
        return d;
    }

    function ensureOverlays() {
        if (hoverBox && hoverBox.isConnected) return;
        hoverBox = makeBox('#a5b4fc', true);
        selectBox = makeBox('#6366f1', false);
        selectLabel = document.createElement('div');
        selectLabel.setAttribute(IGNORE, '');
        selectLabel.style.cssText = 'position:fixed;pointer-events:none;z-index:2147483647;display:none;background:#6366f1;color:#fff;' +
            'font:600 10px/1 ui-sans-serif,system-ui,sans-serif;padding:3px 5px;border-radius:3px;white-space:nowrap;';
        document.documentElement.appendChild(selectLabel);
    }

    function place(box, el) {
        if (!el || !el.isConnected) { box.style.display = 'none'; return null; }
        var r = el.getBoundingClientRect();
        box.style.display = 'block';
        box.style.left = r.left + 'px';
        box.style.top = r.top + 'px';
        box.style.width = r.width + 'px';
        box.style.height = r.height + 'px';
        return r;
    }

    function renderOverlays() {
        ensureOverlays();
        var hEl = hoveredOid !== selectedOid ? byOid(hoveredOid) : null;
        place(hoverBox, hEl);
        var sEl = byOid(selectedOid);
        var r = place(selectBox, sEl);
        if (r && !editingEl) {
            selectLabel.style.display = 'block';
            selectLabel.textContent = labelFor(sEl) + '  ' + Math.round(r.width) + '×' + Math.round(r.height);
            selectLabel.style.left = Math.max(0, r.left) + 'px';
            selectLabel.style.top = (r.top > 18 ? r.top - 18 : r.bottom + 2) + 'px';
        } else {
            selectLabel.style.display = 'none';
        }
    }

    /* ---------- state changes ---------- */

    function select(oid, notify) {
        selectedOid = oid;
        renderOverlays();
        if (notify !== false) post('select', info(byOid(oid)));
    }

    function emitChange() {
        assignOids(document.documentElement);
        renderOverlays();
        post('change', { html: serialize(), tree: buildTree(document.body), selected: info(byOid(selectedOid)) });
    }

    /* ---------- inline text editing ---------- */

    function startEditing(el) {
        if (editingEl || !isTextLeaf(el)) return;
        editingEl = el;
        el.setAttribute('contenteditable', 'true');
        el.focus();
        var range = document.createRange();
        range.selectNodeContents(el);
        var sel = window.getSelection();
        sel.removeAllRanges();
        sel.addRange(range);
        renderOverlays();
        post('editing', true);
    }

    function stopEditing() {
        if (!editingEl) return;
        var el = editingEl;
        editingEl = null;
        el.removeAttribute('contenteditable');
        window.getSelection().removeAllRanges();
        post('editing', false);
        emitChange();
    }

    /* ---------- events ---------- */

    function targetFromEvent(e) {
        var el = e.target;
        while (el && !isEditable(el)) el = el.parentElement;
        if (el === document.documentElement) el = document.body;
        return el;
    }

    document.addEventListener('mousemove', function (e) {
        if (editingEl) return;
        var el = targetFromEvent(e);
        var oid = el ? el.getAttribute(OID) : null;
        if (oid !== hoveredOid) {
            hoveredOid = oid;
            renderOverlays();
            post('hover', oid);
        }
    }, true);

    document.addEventListener('mouseleave', function () {
        hoveredOid = null;
        renderOverlays();
        post('hover', null);
    });

    document.addEventListener('click', function (e) {
        if (editingEl && editingEl.contains(e.target)) return;
        e.preventDefault();
        e.stopPropagation();
        if (editingEl) stopEditing();
        var el = targetFromEvent(e);
        select(el ? el.getAttribute(OID) : null);
    }, true);

    document.addEventListener('dblclick', function (e) {
        e.preventDefault();
        var el = targetFromEvent(e);
        if (el) { select(el.getAttribute(OID)); startEditing(el); }
    }, true);

    document.addEventListener('submit', function (e) { e.preventDefault(); }, true);

    document.addEventListener('keydown', function (e) {
        if (editingEl) {
            if (e.key === 'Escape' || (e.key === 'Enter' && !e.shiftKey)) {
                e.preventDefault();
                stopEditing();
            }
            return;
        }
        var tag = (e.target && e.target.tagName) || '';
        if (tag === 'INPUT' || tag === 'TEXTAREA') return;
        e.preventDefault();
        post('key', { key: e.key, meta: e.metaKey || e.ctrlKey, shift: e.shiftKey, alt: e.altKey });
    }, true);

    window.addEventListener('scroll', renderOverlays, true);
    window.addEventListener('resize', renderOverlays);

    /* ---------- commands from editor ---------- */

    function insertFragment(html) {
        var tpl = document.createElement('template');
        tpl.innerHTML = html.trim();
        return tpl.content;
    }

    var commands = {
        select: function (p) { select(p.oid); },
        hover: function (p) { hoveredOid = p.oid; renderOverlays(); },
        setStyle: function (p) {
            var el = byOid(p.oid); if (!el) return;
            if (p.value === '' || p.value == null) el.style.removeProperty(p.prop);
            else el.style.setProperty(p.prop, p.value);
            if (!el.getAttribute('style')) el.removeAttribute('style');
            emitChange();
        },
        setClass: function (p) {
            var el = byOid(p.oid); if (!el) return;
            if (p.value.trim()) el.setAttribute('class', p.value.trim()); else el.removeAttribute('class');
            // Give the Tailwind CDN a frame to generate CSS before measuring.
            requestAnimationFrame(function () { setTimeout(emitChange, 30); });
        },
        setText: function (p) {
            var el = byOid(p.oid); if (!el) return;
            el.innerText = p.value;
            emitChange();
        },
        setAttr: function (p) {
            var el = byOid(p.oid); if (!el) return;
            if (p.value === '' || p.value == null) el.removeAttribute(p.name); else el.setAttribute(p.name, p.value);
            emitChange();
        },
        remove: function (p) {
            var el = byOid(p.oid); if (!el || el === document.body) return;
            var next = el.nextElementSibling || el.previousElementSibling || el.parentElement;
            el.remove();
            selectedOid = next && isEditable(next) ? next.getAttribute(OID) : null;
            emitChange();
            post('select', info(byOid(selectedOid)));
        },
        duplicate: function (p) {
            var el = byOid(p.oid); if (!el || el === document.body) return;
            var copy = el.cloneNode(true);
            copy.removeAttribute(OID);
            copy.querySelectorAll('[' + OID + ']').forEach(function (n) { n.removeAttribute(OID); });
            el.after(copy);
            assignOids(copy);
            selectedOid = copy.getAttribute(OID);
            emitChange();
            post('select', info(copy));
        },
        move: function (p) {
            var el = byOid(p.oid); if (!el || el === document.body) return;
            if (p.dir < 0 && el.previousElementSibling) el.previousElementSibling.before(el);
            else if (p.dir > 0 && el.nextElementSibling) el.nextElementSibling.after(el);
            else return;
            emitChange();
        },
        moveTo: function (p) {
            var el = byOid(p.oid);
            var target = byOid(p.targetOid);
            if (!el || !target || el === target || el.contains(target) || el === document.body) return;
            if (p.position === 'before') target.before(el);
            else if (p.position === 'after') target.after(el);
            else target.appendChild(el);
            emitChange();
        },
        insert: function (p) {
            var anchor = byOid(p.oid) || document.body;
            var frag = insertFragment(p.html);
            var first = frag.firstElementChild;
            if (p.position === 'after' && anchor !== document.body) anchor.after(frag);
            else anchor.appendChild(frag);
            if (first) {
                assignOids(first);
                selectedOid = first.getAttribute(OID);
                first.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
            }
            emitChange();
            post('select', info(byOid(selectedOid)));
        },
        replace: function (p) {
            var el = byOid(p.oid); if (!el) return;
            var frag = insertFragment(p.html);
            var first = frag.firstElementChild;
            if (el === document.body) {
                // Replacing body: swap its contents and attributes.
                var tmp = document.createElement('div');
                tmp.appendChild(frag);
                var newBody = tmp.querySelector('body') ? tmp.querySelector('body') : tmp;
                document.body.innerHTML = newBody.innerHTML;
                selectedOid = document.body.getAttribute(OID);
            } else {
                el.replaceWith(frag);
                if (first) { assignOids(first); selectedOid = first.getAttribute(OID); }
            }
            setTimeout(function () { emitChange(); post('select', info(byOid(selectedOid))); }, 30);
        },
        getOuter: function (p) {
            var el = byOid(p.oid);
            post('response', { reqId: p.reqId, data: el ? cleanOuter(el) : null });
        },
        selectParent: function () {
            var el = byOid(selectedOid);
            if (el && el.parentElement && isEditable(el.parentElement)) select(el.parentElement.getAttribute(OID));
        },
    };

    window.addEventListener('message', function (e) {
        var d = e.data;
        if (!d || d.target !== 'ol-preload' || !commands[d.type]) return;
        try { commands[d.type](d.payload || {}); } catch (err) { console.error('[on-look]', err); }
    });

    function init() {
        assignOids(document.documentElement);
        ensureOverlays();
        post('ready', { tree: buildTree(document.body), html: serialize() });
        // Re-render overlays once fonts/images/Tailwind settle.
        setTimeout(renderOverlays, 300);
        window.addEventListener('load', renderOverlays);
    }

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
    else init();
})();
