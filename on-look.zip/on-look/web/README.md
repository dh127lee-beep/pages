# On-Look

[onlook-dev/onlook](https://github.com/onlook-dev/onlook)의 구조를 바탕으로 만든 **브라우저 기반 비주얼 웹 에디터** 서비스입니다.
캔버스에서 요소를 클릭해 선택하고, 스타일·텍스트·Tailwind 클래스를 바로 수정하고, AI(Claude)에게 페이지 수정을 맡길 수 있습니다.
만든 페이지는 즉시 공유 가능한 URL(`/p/<id>`)로 게시되고, HTML 파일로 내보낼 수도 있습니다.

## 실행

```bash
cd web
npm install
cp .env.example .env.local   # AI를 쓰려면 ANTHROPIC_API_KEY 입력
npm run build && npm start   # http://localhost:3000
# 개발 모드: npm run dev
```

### AI: 로그인된 Claude CLI로 쓰기 (API 키 불필요)

`scripts/claude-cli-bridge.mjs`는 요청마다 로그인된 `claude -p`를 실행해 OpenAI 호환 형식으로 응답하는 로컬 브리지입니다.

```bash
# .env.local
ONLOOK_AI_BASE_URL=http://127.0.0.1:8789/v1
ONLOOK_AI_API_KEY=sk-onlook-<아무 긴 임의 문자열>   # 브리지와 앱이 같은 값을 공유
ONLOOK_AI_MODEL=opus                              # sonnet | opus | haiku

npm run bridge      # 터미널 1: 브리지 (127.0.0.1:8789)
npm start           # 터미널 2: On-Look
```

`ONLOOK_AI_BASE_URL`이 있으면 브리지를, 없으면 `ANTHROPIC_API_KEY`로 Anthropic API를 직접 씁니다. 페이지 전체 생성은 수 분이 걸릴 수 있습니다 (브리지 타임아웃 10분).

Docker·Supabase·외부 샌드박스 없이 Node.js 하나로 동작합니다. 프로젝트는 `data/projects/*.json`에 저장됩니다.

## 기능

| 영역 | 내용 |
|---|---|
| 대시보드 | 템플릿 5종(빈 페이지·SaaS 랜딩·포트폴리오·카페·**블로그 · API 연동**), "AI로 만들기", 썸네일, 이름 변경·복제·삭제 |
| 페이지 | 프로젝트당 여러 페이지. 추가·이름/주소 변경(다른 페이지의 링크 자동 수정)·복제·삭제 |
| 캔버스 | 호버/선택 오버레이, 더블클릭 인라인 텍스트 편집, 데스크톱·태블릿·모바일 뷰 |
| 레이어 · 추가 | DOM 트리, 드래그 앤 드롭 이동, 블록 삽입 |
| 스타일 | 텍스트, 링크(페이지 선택), 이미지, Tailwind 클래스, 레이아웃, 여백, 타이포, 색상, 테두리 |
| 데이터 연결 | 요소에 API URL 연결 → 목록 반복·필드 바인딩. 실제 API 응답에서 필드를 골라 연결 |
| 코드 | 페이지별 HTML / JavaScript 탭 |
| 미리보기 | 실제 게시 페이지를 실행 — 페이지 이동, 스크립트, API 데이터 모두 동작 |
| AI | 페이지 전체 또는 선택 요소 수정. 페이지 목록·데이터 바인딩·스크립트 규칙을 알고 작업 |
| 게시 · 내보내기 | `/p/<id>`, `/p/<id>/<페이지>`. 전체 페이지 ZIP 내보내기 |

## 페이지 · 자바스크립트 · API 데이터

- **링크**: 다른 페이지는 주소로 링크합니다 — `href="about"`, 홈은 `href="index"`, 쿼리도 가능(`href="post?id=3"`). 게시·내보내기 시 알맞은 URL로 바뀝니다.
- **페이지 스크립트**는 코드 → JavaScript 탭에서 편집하며 미리보기·게시 페이지에서만 실행됩니다. 디자인 캔버스에서는 스크립트(HTML 안의 인라인 `<script>` 포함)가 실행되지 않으므로 JS가 바꾼 화면이 소스에 저장되지 않습니다.
- **선언형 API 바인딩** (`public/ol-runtime.js`) — 페이지가 열릴 때마다 실행되므로 페이지 이동 시 데이터를 불러옵니다:

```html
<!-- 목록: 첫 번째 자식이 항목마다 반복 -->
<div data-ol-fetch="https://jsonplaceholder.typicode.com/posts" data-ol-list data-ol-limit="9">
  <a href="post" data-ol-href="post?id={id}">
    <h2 data-ol-text="title">글 제목</h2>
  </a>
</div>

<!-- 상세: {query.id} 에 현재 페이지의 ?id= 값이 들어감 -->
<article data-ol-fetch="https://jsonplaceholder.typicode.com/posts/{query.id}">
  <h1 data-ol-text="title">글 제목</h1>
  <p data-ol-text="작성자 {userId}"></p>
</article>
```

| 속성 | 의미 |
|---|---|
| `data-ol-fetch` | 불러올 JSON URL. `{query.x}` = 페이지 주소의 `?x=` 값 |
| `data-ol-path` | 응답 안의 경로 (예: `data.items`) |
| `data-ol-list` / `data-ol-limit` | 첫 번째 자식 요소를 항목마다 반복 / 최대 개수 |
| `data-ol-text` `-src` `-href` `-alt` `-value` | 필드 경로(`author.name`) 또는 템플릿(`#{id} {title}`) |

- 스크립트에서는 `await ol.getJSON(url)`, `ol.api(url, init)`, `ol.query`를 쓸 수 있습니다.
- 외부 API 호출은 `/api/proxy`를 거쳐 CORS 문제 없이 동작합니다. 내부망·localhost 주소는 차단되며, `ONLOOK_PROXY_ALLOW="api.example.com,*.example.org"`로 허용 호스트를 제한할 수 있습니다. ZIP으로 내보낸 정적 파일은 프록시 없이 API를 직접 호출하므로 CORS를 허용하는 API만 동작합니다.

## 구조 (onlook과의 대응)

| On-Look | onlook 원본 |
|---|---|
| `public/ol-preload.js` — iframe에 주입되어 `data-oid` 부여, 오버레이, DOM 편집, 직렬화 | `apps/web/preload` (penpal 기반 preload 스크립트) |
| `src/components/editor/*` — 레이어/스타일/AI 패널, 캔버스 | `apps/web/client/src/app/project/[id]/_components` |
| `src/app/api/*` — 프로젝트 CRUD, AI 편집 | tRPC 라우터 (`src/server/api/routers`) |
| 파일 저장소 (`src/lib/store.ts`) | Supabase Postgres |
| 페이지별 HTML + 페이지 스크립트 + 선언형 데이터 바인딩 (`public/ol-runtime.js`) | CodeSandbox 위의 Next.js 프로젝트 (React 코드) |

## 보안 메모

- 편집 캔버스는 `sandbox="allow-scripts"` iframe(불투명 origin)에서 실행되어 에디터와 분리됩니다.
- 게시 페이지(`/p/<id>`)는 `Content-Security-Policy: sandbox` 헤더로 서비스 origin과 격리됩니다.
- 인증 기능은 없습니다. 인터넷에 공개 배포할 때는 앞단에 인증(리버스 프록시 Basic Auth 등)을 두세요. 공개 배포 시 `/api/proxy`가 열린 프록시가 되지 않도록 `ONLOOK_PROXY_ALLOW`도 설정하세요.

라이선스: onlook과 동일하게 Apache-2.0을 따릅니다.
