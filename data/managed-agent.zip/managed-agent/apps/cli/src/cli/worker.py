"""`aw worker poll` — 참조 self_hosted 워커 (T-0606).

`plan/04-api.md` §3.3 · `ref/claude-managed-agents/08-self-hosted/`.

> **부서가 자기 인프라에서 돌리는 것이다.** 이 파일은 "우리 계약이
> 이렇게 생겼다"의 실행 가능한 명세다 — 부서가 자기 언어로 다시
> 쓸 때 보는 기준.

HTTP 만 쓴다. DB 에 닿지 않고, 닿을 수도 없다 — 그것이 self_hosted 를
쓰는 이유다 (데이터가 부서 경계를 안 넘는다).

```
poll  (long)  ──▶ 204 면 다시 poll
              ──▶ 200 이면 {work, secret, heartbeat_seconds}
                     │
                     ├─ heartbeat 를 주기적으로 보낸다 (백그라운드)
                     ├─ 툴을 실행한다 (여기서는 핸들러에 맡긴다)
                     └─ ack 로 결과를 올린다
```

**`409 claim_lost` 를 받으면 즉시 버린다.** 회수돼서 다른 워커가
이미 같은 일을 돌고 있고, 계속하면 결과가 두 벌 올라간다.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

import anyio

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable

    import httpx

_log = logging.getLogger("cli.worker")

#: long-poll 대기(ms). 서버 상한(30초)과 맞춘다.
BLOCK_MS = 25_000
#: 폴링이 실패했을 때 쉬는 시간. **즉시 재시도하지 않는다** — 제어
#: 평면이 재시작 중이면 그 트래픽이 재시작을 더 늦춘다.
BACKOFF_SECONDS = 2.0
#: 하트비트를 서버가 말해 주지 않을 때의 기본값.
FALLBACK_HEARTBEAT = 20.0


@dataclass(frozen=True, slots=True)
class ToolCall:
    """워커가 실행할 툴 하나."""

    tool_use_id: str
    name: str
    arguments: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class ToolResult:
    tool_use_id: str
    content: str = ""
    is_error: bool = False

    def wire(self) -> dict[str, Any]:
        return {
            "tool_use_id": self.tool_use_id,
            "content": self.content,
            "is_error": self.is_error,
        }


@dataclass(frozen=True, slots=True)
class Work:
    """집은 일. **시크릿은 여기 한 번만 온다.**"""

    id: str
    session_id: str
    environment_id: str
    claim_generation: int
    secret: str
    heartbeat_seconds: float

    def __repr__(self) -> str:
        return f"Work(id={self.id!r}, session_id={self.session_id!r}, secret=<가림>)"


class ClaimLost(RuntimeError):
    """회수됐다. **진행 중인 일을 버려야 한다.**"""


@dataclass
class WorkerStats:
    claimed: int = 0
    completed: int = 0
    failed: int = 0
    lost: int = 0
    empty: int = 0


#: 일 하나를 처리하는 함수. 부서가 여기에 자기 샌드박스를 꽂는다.
type Handler = Callable[[Work], Awaitable[tuple[ToolResult, ...]]]


@dataclass
class EnvironmentWorker:
    """always-on 폴링 워커.

    **`client` 를 주입받는다.** 부서 환경마다 프록시·CA·타임아웃이
    다르고, 여기서 만들면 그것을 못 바꾼다.
    """

    client: httpx.AsyncClient
    base_url: str
    environment_id: str
    api_key: str
    worker_id: str
    handler: Handler
    block_ms: int = BLOCK_MS
    stats: WorkerStats = field(default_factory=WorkerStats)
    #: `True` 면 큐가 비는 순간 멈춘다 (공식 계약의 `drain`).
    drain: bool = False
    _stopping: bool = False

    def stop(self) -> None:
        """다음 바퀴에서 멈춘다. **진행 중인 일은 끝낸다.**

        죽이지 않는 이유: 진행 중인 일을 ack 없이 버리면 TTL 이
        지날 때까지(60초) 그 세션이 멈춰 있는다.
        """
        self._stopping = True

    # ── 루프 ─────────────────────────────────────────────
    async def run(self) -> WorkerStats:
        while not self._stopping:
            try:
                work = await self.poll()
            except Exception as exc:
                _log.warning("폴링 실패: %s", exc)
                await anyio.sleep(BACKOFF_SECONDS)
                continue

            if work is None:
                self.stats.empty += 1
                if self.drain:
                    break
                continue

            self.stats.claimed += 1
            await self.handle(work)
        return self.stats

    async def handle(self, work: Work) -> None:
        """일 하나. **하트비트를 백그라운드로 보내면서** 실행한다."""
        results: tuple[ToolResult, ...] = ()
        failed = False
        error = ""

        try:
            try:
                async with anyio.create_task_group() as tg:
                    tg.start_soon(self._beat_until_done, work, tg.cancel_scope)
                    results = await self.handler(work)
                    tg.cancel_scope.cancel()
            except BaseExceptionGroup as group:
                # **task group 이 예외를 감싼다.** 그대로 두면 두 가지가
                # 깨진다: `ClaimLost` 가 안 잡히고(계속 돌아 결과를
                # 두 벌 올린다), 운영자가 보는 오류가
                # "unhandled errors in a TaskGroup" 이 된다.
                raise _unwrap(group) from None
        except ClaimLost:
            # **ack 하지 않는다.** 다른 워커가 이미 돌고 있고, 우리
            # 결과를 올리면 두 벌이 된다.
            await self._lost(work)
            return
        except Exception as exc:
            failed = True
            error = f"{type(exc).__name__}: {exc}"
            _log.warning("일 %s 실행 실패: %s", work.id, error)

        try:
            await self.ack(work, results, failed=failed, error=error)
        except ClaimLost:
            await self._lost(work, where="ack 중")
            return
        except Exception as exc:
            # **ack 를 못 했다.** TTL 이 지나면 회수돼 다른 워커가 돈다.
            self.stats.failed += 1
            _log.warning("일 %s ack 실패: %s", work.id, exc)
            return

        if failed:
            self.stats.failed += 1
        else:
            self.stats.completed += 1

    async def _lost(self, work: Work, *, where: str = "") -> None:
        """claim 을 잃었다. **쉬었다가 다음 일을 본다.**

        바로 다시 폴링하지 않는 이유: 잃었다는 것은 우리가 느리거나
        회수당하고 있다는 뜻이고, 그 상태로 곧장 더 달라고 하면
        같은 일이 반복되며 제어 평면만 두드린다.
        """
        self.stats.lost += 1
        _log.warning("일 %s 의 claim 을 %s잃었다 — 버린다", work.id, where)
        await anyio.sleep(BACKOFF_SECONDS)

    async def _beat_until_done(self, work: Work, scope: Any) -> None:
        """취소될 때까지 하트비트. **잃으면 작업을 취소한다.**"""
        while True:
            await anyio.sleep(work.heartbeat_seconds)
            try:
                await self.heartbeat(work)
            except ClaimLost:
                _log.warning("일 %s 하트비트가 거부됐다 — 멈춘다", work.id)
                scope.cancel()
                return
            except Exception as exc:
                # **한 번 실패로 포기하지 않는다.** TTL 이 주기의 3배다.
                _log.info("일 %s 하트비트 실패 (계속 시도): %s", work.id, exc)

    # ── HTTP ─────────────────────────────────────────────
    @property
    def _headers(self) -> dict[str, str]:
        return {"x-api-key": self.api_key}

    def _url(self, suffix: str) -> str:
        return f"{self.base_url.rstrip('/')}/api/v1/environments/{self.environment_id}/work{suffix}"

    async def poll(self) -> Work | None:
        """일 하나를 집는다. **204 면 `None`** — 오류가 아니다."""
        response = await self.client.post(
            self._url("/poll"),
            json={"worker_id": self.worker_id, "block_ms": self.block_ms},
            headers=self._headers,
        )
        if response.status_code == 204:
            return None
        response.raise_for_status()
        body = response.json()
        item = body["work"]
        return Work(
            id=item["id"],
            session_id=item["session_id"],
            environment_id=item["environment_id"],
            claim_generation=item["claim_generation"],
            secret=body["secret"],
            heartbeat_seconds=float(body["heartbeat_seconds"]) or FALLBACK_HEARTBEAT,
        )

    async def heartbeat(self, work: Work) -> None:
        response = await self.client.post(
            self._url(f"/{work.id}/heartbeat"),
            json={
                "worker_id": self.worker_id,
                "claim_generation": work.claim_generation,
            },
            headers=self._headers,
        )
        _raise_for_claim(response)
        response.raise_for_status()

    async def ack(
        self,
        work: Work,
        results: tuple[ToolResult, ...],
        *,
        failed: bool = False,
        error: str = "",
    ) -> None:
        response = await self.client.post(
            self._url(f"/{work.id}/ack"),
            json={
                "worker_id": self.worker_id,
                "claim_generation": work.claim_generation,
                "results": [r.wire() for r in results],
                "failed": failed,
                "error": error[:1000],
            },
            headers=self._headers,
        )
        _raise_for_claim(response)
        response.raise_for_status()


def _unwrap(group: BaseExceptionGroup) -> BaseException:
    """task group 이 감싼 것을 **원래 예외로** 돌려준다.

    여럿이면 첫 번째를 쓴다 — 하트비트와 핸들러가 동시에 터지는
    경우이고, 그때 사람이 먼저 봐야 하는 것은 핸들러 쪽이다
    (하트비트 실패는 로그에 따로 남는다).
    """
    first = group.exceptions[0]
    while isinstance(first, BaseExceptionGroup):
        first = first.exceptions[0]
    return first


def _raise_for_claim(response: Any) -> None:
    """`409 claim_lost` 를 다른 실패와 **구분한다.**

    전부 HTTP 오류로 뭉치면 워커가 재시도하고, 그 재시도가 새 워커의
    결과를 덮으려 든다.
    """
    if response.status_code != 409:
        return
    try:
        code = response.json().get("error", {}).get("code")
    except Exception:  # pragma: no cover — 본문이 JSON 이 아니면 일반 오류다
        return
    if code == "claim_lost":
        raise ClaimLost(response.text)


__all__ = [
    "BACKOFF_SECONDS",
    "BLOCK_MS",
    "ClaimLost",
    "EnvironmentWorker",
    "Handler",
    "ToolCall",
    "ToolResult",
    "Work",
    "WorkerStats",
]
