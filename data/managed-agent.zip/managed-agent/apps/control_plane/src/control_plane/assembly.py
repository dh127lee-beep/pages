"""생명주기와 워크스페이스별 앱 그래프.

`plan/09-codebase.md` §4 · `plan/03-layers.md` §6.

`GraphSource` 가 **워크스페이스 하나당 그래프 하나**를 만들어 캐시한다.
부서마다 모델 카드·정책·예산이 다르므로 그래프도 다르고, 요청마다 다시
조립하면 비싸다.
"""

from __future__ import annotations

from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from fastapi import FastAPI
from ma_api.internal.deps import AppGraph
from ma_application.agents import AgentsUseCases
from ma_application.approvals import ApprovalsUseCases
from ma_application.audit import AuditUseCases
from ma_application.budgets import BudgetsUseCases
from ma_application.deployments import DeploymentsUseCases
from ma_application.environment_work import EnvironmentWorkUseCases
from ma_application.files import FilesUseCases
from ma_application.mcp import McpUseCases
from ma_application.memory import MemoryUseCases
from ma_application.models import ModelResolver
from ma_application.session_events import SessionEventsUseCases
from ma_application.skills import SkillsUseCases
from ma_application.vaults import VaultsUseCases
from ma_application.webhooks import WebhooksUseCases
from ma_auth.principal import ApiKeyAuthenticator, Principal
from ma_domain.ids import WorkspaceId
from ma_governance.cipher import CipherBundle
from ma_sql.asyncpg_client import AsyncpgClient
from ma_store_sql.agents import SqlAgentStore
from ma_store_sql.credentials import SqlCredentialStore
from ma_store_sql.deployments import SqlDeploymentStore
from ma_store_sql.environment_work import SqlEnvironmentWorkStore
from ma_store_sql.events import SqlPendingEventStore, SqlSessionEventStore
from ma_store_sql.files import SqlFileStore, SqlSessionOutputStore, SqlSnapshotStore
from ma_store_sql.governance import (
    SqlApprovalPolicyStore,
    SqlApprovalStore,
    SqlAuditStore,
    SqlBudgetStore,
    SqlUsageStore,
)
from ma_store_sql.memory import SqlMemoryDocumentStore, SqlMemoryStoreStore
from ma_store_sql.models import SqlModelCardStore
from ma_store_sql.sessions import SqlSessionStore
from ma_store_sql.skills import SqlSkillStore
from ma_store_sql.vaults import SqlVaultStore
from ma_store_sql.webhooks import SqlWebhookStore
from ma_store_sql.workspaces import SqlApiKeyStore

if TYPE_CHECKING:
    from control_plane.components import Components


@dataclass
class GraphSource:
    """인증과 그래프 조립. **라우터는 이것을 모른다** — 미들웨어가 꽂는다."""

    components: Components
    _graphs: dict[str, AppGraph] = field(default_factory=dict)

    @property
    def _sql(self) -> AsyncpgClient:
        return AsyncpgClient(self.components.pool)

    @property
    def _ciphers(self) -> CipherBundle:
        """**조립 시점에만 만든다.** Port 가 아니다 (`plan/03` §3 L2).

        루트 시크릿이 설정에 없으면 여기서 죽는다 — 자격증명 기능이 꺼진
        채로 도는 것보다 낫다. 꺼진 채로 돌면 "왜 볼트가 안 되지"를 쫓게
        되고, 그 사이에 운영자가 평문을 다른 데 적어 둔다.
        """
        return CipherBundle.from_root(
            self.components.cfg.credential_root_secret,
            key_version=self.components.cfg.credential_key_version,
        )

    async def authenticate(self, key: str) -> Principal | None:
        auth = ApiKeyAuthenticator(
            keys=SqlApiKeyStore(self._sql),
            pepper=self.components.cfg.api_key_pepper,
        )
        return await auth.authenticate(key, self.components.clock.now())

    async def graph_for(self, workspace_id: str) -> AppGraph:
        cached = self._graphs.get(workspace_id)
        if cached is not None:
            return cached

        sql = self._sql
        events = SqlSessionEventStore(sql)
        pending = SqlPendingEventStore(sql)
        sessions = SqlSessionStore(sql)
        ciphers = self._ciphers

        from ma_observability.trace import carrier_for_db

        session_events = SessionEventsUseCases(
            events=events,
            pending_events=pending,
            sessions=sessions,
            clock=self.components.clock,
            # **제어 평면의 trace 를 outbox 에 싣는다** — 워커가 claim 할
            # 때 이어받는다 (`IMPL-0029`). 관측 패키지를 L4 가 들지
            # 않도록 조립이 함수를 넘긴다.
            trace_carrier=lambda: tuple(carrier_for_db().items()),
        )
        graph = AppGraph(
            agents=AgentsUseCases(
                workspace_id=WorkspaceId(workspace_id),
                clock=self.components.clock,
                store=SqlAgentStore(sql),
                next_id=lambda: self.components.ids.next("agent"),
            ),
            session_events=session_events,
            skills=SkillsUseCases(
                skills=SqlSkillStore(sql),
                clock=self.components.clock,
                ids=self.components.ids,
                # GitHub 로더는 조립이 꽂는다 — 없으면 `source` 를 준
                # 요청이 **조용히 빈 스킬을 만들지 않고** 거부된다.
                loader=self.components.skill_loader,
            ),
            approvals=ApprovalsUseCases(
                approvals=SqlApprovalStore(sql),
                policies=SqlApprovalPolicyStore(sql),
                sessions=sessions,
                # **승인이 세션 이벤트를 수용해 재개를 일으킨다** —
                # 같은 경로를 쓰므로 멱등성과 순서 보장이 그대로 적용된다.
                events=session_events,
                clock=self.components.clock,
                ids=self.components.ids,
            ),
            vaults=VaultsUseCases(
                vaults=SqlVaultStore(sql),
                # cipher 는 **Store 생성자 인자**다 — 유스케이스는 모른다.
                credentials=SqlCredentialStore(sql, ciphers.credential),
                clock=self.components.clock,
                ids=self.components.ids,
            ),
            webhooks=WebhooksUseCases(
                webhooks=SqlWebhookStore(sql, ciphers.credential),
                clock=self.components.clock,
                ids=self.components.ids,
                notifiers=self.components.notifiers,
                console_base_url=self.components.cfg.console_base_url,
            ),
            audit=AuditUseCases(
                audit=SqlAuditStore(sql),
                events=events,
                approvals=SqlApprovalStore(sql),
                credentials=SqlCredentialStore(sql, ciphers.credential),
            ),
            deployments=DeploymentsUseCases(
                deployments=SqlDeploymentStore(sql),
                # **핀한 버전을 읽어야** 한다 — 배포는 "현재 버전"이
                # 아니라 특정 버전을 돌린다.
                agents=SqlAgentStore(sql),
                # peak 창을 **카드에서** 읽는 길. 코드에 박지 않는다 (D12).
                resolver=ModelResolver(cards=SqlModelCardStore(sql)),
                clock=self.components.clock,
                ids=self.components.ids,
            ),
            budgets=BudgetsUseCases(
                budgets=SqlBudgetStore(sql),
                usage=SqlUsageStore(sql),
                clock=self.components.clock,
            ),
            environment_work=EnvironmentWorkUseCases(
                work=SqlEnvironmentWorkStore(sql, ciphers.credential),
                # **승인 재개와 같은 경로로** 결과를 넣는다 — 따로
                # 두면 멱등성과 순서 보장을 두 벌 유지해야 한다.
                events=session_events,
                clock=self.components.clock,
                ids=self.components.ids,
            ),
            files=FilesUseCases(
                files=SqlFileStore(sql),
                outputs=SqlSessionOutputStore(sql),
                snapshots=SqlSnapshotStore(sql),
                blob=self.components.blob,
                clock=self.components.clock,
                ids=self.components.ids,
            ),
            mcp=McpUseCases(
                credentials=SqlCredentialStore(sql, ciphers.credential),
                # **갱신은 제어 평면에서만** (D5 · `ADR-0009`).
                refresher=self.components.oauth_refresher,
                clock=self.components.clock,
            ),
            memory=MemoryUseCases(
                stores=SqlMemoryStoreStore(sql),
                docs=SqlMemoryDocumentStore(sql),
                clock=self.components.clock,
                ids=self.components.ids,
            ),
            sessions=sessions,
            events=events,
            models=SqlModelCardStore(sql),
            realtime=self.components.realtime,
            clock=self.components.clock,
            ids=self.components.ids,
        )
        self._graphs[workspace_id] = graph
        return graph


async def build_control_plane(components: Components) -> FastAPI:
    """`config → components → assembly → serve` 의 세 번째 단계."""
    from control_plane.http import build_app

    source = GraphSource(components=components)

    @asynccontextmanager
    async def lifespan(_: FastAPI) -> AsyncIterator[None]:
        """**종료 시 역순 정리.** SSE 연결이 열려 있을 수 있으므로
        uvicorn 의 graceful 타임아웃이 끝난 뒤에 닫힌다."""
        yield
        await components.aclose()

    app = build_app(source, lifespan=lifespan)
    app.state.components = components
    app.state.readiness = _readiness(components)
    return app


def _readiness(components: Components):  # type: ignore[no-untyped-def]
    async def probe() -> dict[str, str]:
        """**DB 왕복을 실제로 한다.** 풀이 살아 있다는 것만으로는 부족하다."""
        try:
            async with components.pool.acquire() as conn:
                await conn.fetchval("SELECT 1")
        except Exception as exc:
            return {"database": f"error: {type(exc).__name__}"}
        return {"database": "ok"}

    return probe


__all__ = ["GraphSource", "build_control_plane"]
