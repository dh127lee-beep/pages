"""어떤 구현을 쓸지 고른다. **교체 지점이 여기 하나다.**

`plan/09-codebase.md` §4.

```python
components = await default_components(
    cfg,
    overrides=ComponentOverrides(realtime=InProcessRealtime()),
)
```

테스트와 다른 배포 프리셋은 `os.environ` 을 건드리지 않고 여기서 갈아끼운다.
그것이 "배포 프리셋이 라이브러리 사용자가 된다"의 뜻이다.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from ma_adapters_runtime.realtime_pg import InProcessRealtime, PgRealtime
from ma_domain.clock import Clock, IdGenerator
from ma_platform.capabilities import SystemClock, UlidGenerator
from ma_sql.asyncpg_client import create_pool

if TYPE_CHECKING:
    import asyncpg
    from ma_application.blob import BlobPort
    from ma_application.mcp import Refresher
    from ma_application.realtime import RealtimePort
    from ma_application.skills import SkillSourceLoader
    from ma_application.webhooks import Notifier

    from control_plane.config import Config


@dataclass
class ComponentOverrides:
    """일부만 바꾼다. `None` 인 것은 기본 구현을 쓴다."""

    clock: Clock | None = None
    ids: IdGenerator | None = None
    realtime: RealtimePort | None = None
    blob: BlobPort | None = None
    skill_loader: SkillSourceLoader | None = None
    notifiers: tuple[Notifier, ...] | None = None
    oauth_refresher: Refresher | None = None
    pool: Any | None = None


@dataclass
class Components:
    """조립에 필요한 **살아 있는 것들**. `assembly` 가 이것으로 앱을 만든다."""

    cfg: Config
    pool: asyncpg.Pool
    realtime: RealtimePort
    blob: BlobPort
    #: GitHub 스킬 로더. `None` 이면 `source` 를 준 요청이 거부된다.
    skill_loader: SkillSourceLoader | None
    #: Slack·메일. **비어 있어도 된다** — 웹훅만 쓸 수 있다.
    notifiers: tuple[Notifier, ...]
    #: MCP OAuth 갱신. **제어 평면에만 있다** (D5 · `ADR-0009`) — 워커도
    #: 프록시도 갱신 토큰을 보지 않는다.
    oauth_refresher: Refresher
    clock: Clock
    ids: IdGenerator
    #: 종료 시 역순으로 정리한다.
    _closers: list[Any]

    async def aclose(self) -> None:
        """**역순 정리.** 먼저 연 것을 나중에 닫는다 — 의존이 그 방향이다."""
        for close in reversed(self._closers):
            await close()


async def default_components(
    cfg: Config, overrides: ComponentOverrides | None = None
) -> Components:
    o = overrides or ComponentOverrides()
    closers: list[Any] = []

    pool = o.pool
    if pool is None:
        pool = await create_pool(_pg_dsn(cfg.database_url), min_size=2, max_size=20)
        closers.append(pool.close)

    realtime = o.realtime
    if realtime is None:
        if cfg.in_process_realtime:
            realtime = InProcessRealtime()
        else:
            pg = PgRealtime(_pg_dsn(cfg.database_url))
            await pg.start()
            closers.append(pg.stop)
            realtime = pg

    clock = o.clock or SystemClock()
    return Components(
        cfg=cfg,
        pool=pool,
        realtime=realtime,
        blob=o.blob or _blob_for(cfg),
        skill_loader=o.skill_loader or _skill_loader_for(cfg, closers),
        notifiers=o.notifiers if o.notifiers is not None else _notifiers_for(cfg, closers),
        oauth_refresher=o.oauth_refresher or _oauth_refresher(closers),
        clock=clock,
        ids=o.ids or UlidGenerator(clock),
        _closers=closers,
    )


def _oauth_refresher(closers: list[Any]) -> Refresher:
    """MCP OAuth 갱신기. **토큰 엔드포인트로 나가므로 전용 클라이언트다.**

    짧은 타임아웃이 중요하다: 갱신은 툴 호출 하나를 **막고 있는**
    경로다. 느린 토큰 엔드포인트 하나가 세션을 세우면 안 된다.
    """
    import httpx
    from ma_connectors.mcp import OAuthRefresher
    from ma_connectors.mcp.oauth import TOKEN_TIMEOUT

    client = httpx.AsyncClient(timeout=httpx.Timeout(TOKEN_TIMEOUT))
    closers.append(client.aclose)
    return OAuthRefresher(client=client)


def _blob_for(cfg: Config) -> BlobPort:
    """버킷이 있으면 S3, 없으면 로컬.

    **로컬은 서명 URL 을 못 만든다** — 그래서 다운로드가 개발 머신에서
    정직하게 막힌다. 거기서 바이트 중계로 대체하는 길을 열면 그 경로가
    프로덕션에도 남고, 제어 평면이 대용량에서 막힌다.
    """
    if cfg.blob_bucket:
        from ma_adapters_blob.s3 import S3BlobStore, client_for

        return S3BlobStore(
            bucket=cfg.blob_bucket,
            client=client_for(endpoint_url=cfg.blob_endpoint, region=cfg.blob_region),
        )

    from pathlib import Path

    from ma_adapters_blob.local import LocalBlobStore

    return LocalBlobStore(root=Path(cfg.blob_local_root))


def _skill_loader_for(cfg: Config, closers: list[Any]) -> SkillSourceLoader | None:
    """GitHub 스킬 로더. 비활성이면 `None`.

    **egress 프록시를 거친다.** 토큰은 프록시가 주입하고, 이 코드는
    토큰을 보지 않는다 (D5). 프록시 주소가 없으면 직접 나가는데,
    그것은 개발 환경뿐이다.
    """
    if not cfg.github_skills_enabled:
        return None

    import httpx
    from ma_connectors.skills import GitHubSkillLoader

    client = httpx.AsyncClient(
        proxy=cfg.egress_proxy_url or None,
        timeout=httpx.Timeout(20.0),
    )
    closers.append(client.aclose)
    return GitHubSkillLoader(client=client, api_base=cfg.github_api_base)


def _notifiers_for(cfg: Config, closers: list[Any]) -> tuple[Notifier, ...]:
    """Slack·메일 알림. **설정된 것만 켠다.**

    둘 다 없으면 빈 tuple 이고, 그러면 승인 알림이 웹훅으로만 나간다 —
    그것도 유효한 배포다 (수신 측이 사내 봇일 수 있다).
    """
    made: list[Notifier] = []

    if cfg.slack_webhook_url:
        import httpx
        from ma_connectors.notify import SlackNotifier

        client = httpx.AsyncClient(timeout=httpx.Timeout(10.0))
        closers.append(client.aclose)
        made.append(SlackNotifier(client=client, webhook_url=cfg.slack_webhook_url))

    if cfg.smtp_host and cfg.notify_recipients:
        from ma_connectors.notify import SmtpNotifier

        made.append(
            SmtpNotifier(
                host=cfg.smtp_host,
                port=cfg.smtp_port,
                sender=cfg.smtp_sender,
                recipients=cfg.notify_recipients,
                username=cfg.smtp_username,
                password=cfg.smtp_password,
            )
        )

    return tuple(made)


def _pg_dsn(url: str) -> str:
    """SQLAlchemy 스타일 URL 도 받아 준다 — alembic 과 같은 값을 쓰게."""
    return url.replace("postgresql+psycopg://", "postgresql://")


__all__ = ["ComponentOverrides", "Components", "default_components"]
