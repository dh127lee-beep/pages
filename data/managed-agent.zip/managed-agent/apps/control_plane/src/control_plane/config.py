"""환경변수 → 타입된 `Config`. **환경변수를 읽는 유일한 파일.**

`plan/09-codebase.md` §4 · `tools/check_architecture.py` 가 검사한다.

다른 곳에서 `os.environ` 을 읽으면 "이 배포가 무엇을 요구하는가"를 한눈에
볼 수 없고, 테스트가 전역 상태에 묶인다.

**문제를 하나의 `ConfigError` 로 모아 보고한다.** 하나씩 터뜨리면 운영자가
배포를 N번 반복하며 한 번에 하나씩 고치게 된다.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field

#: `ma_governance.cipher.MIN_ROOT_BYTES` 와 같아야 한다. 여기서 다시 적는
#: 이유: `config.py` 는 레이어상 governance 를 import 하지 않는다 (앱 설정이
#: 패키지에 의존하면 설정 파싱 테스트가 그 패키지를 끌고 온다).
#: 두 값이 어긋나지 않는 것은 `tests/unit/test_config.py` 가 본다.
MIN_ROOT_BYTES = 32


class ConfigError(Exception):
    """설정 문제 **전부**를 모아 보고한다."""

    def __init__(self, problems: tuple[str, ...]) -> None:
        super().__init__("설정 오류 " + str(len(problems)) + "건:\n  - " + "\n  - ".join(problems))
        self.problems = problems


@dataclass(frozen=True, slots=True)
class Config:
    database_url: str
    host: str = "0.0.0.0"  # noqa: S104 — 컨테이너 안에서 바인딩한다
    port: int = 8000
    #: API 키 해시의 pepper. **DB 에 저장되지 않는다** — 유출돼도 키를 만들 수 없다.
    api_key_pepper: bytes = b""
    #: 자격증명 암호화의 루트 시크릿 (`plan/05` §7).
    #:
    #: **제어 평면만 안다.** 워커와 프록시에는 주지 않는다 — 이 값을 아는
    #: 프로세스가 곧 "평문을 만들 수 있는 프로세스"다 (D5).
    #: 백업에 포함하지 않는다.
    credential_root_secret: bytes = b""
    #: 현재 키 버전. 로테이션은 이 값을 올린다 (`IMPL-0020`).
    credential_key_version: int = 1
    #: 부트스트랩용 기본 모델 카드 핸들 (`plan/06` §1 ①).
    default_model_card: str | None = None
    log_level: str = "INFO"
    #: 실시간 fanout 을 DB 없이 돌린다 (단일 프로세스·테스트).
    in_process_realtime: bool = False
    #: 오브젝트 스토어 버킷 (`plan/08` §6). 비면 **로컬 백엔드**를 쓴다.
    blob_bucket: str | None = None
    #: S3 호환 엔드포인트 (MinIO 등). 비면 AWS 기본값.
    blob_endpoint: str | None = None
    blob_region: str | None = None
    #: 로컬 백엔드 루트. **서명 URL 을 못 만든다** — 개발 전용이다.
    blob_local_root: str = ".awp-blobs"
    #: GitHub 스킬 로드 (T-0602). **기본은 꺼져 있다** — 사내
    #: 네트워크에서 외부로 나가는 것은 명시적으로 켠다.
    github_skills_enabled: bool = False
    github_api_base: str = "https://api.github.com"
    #: egress 프록시. 스킬 로드가 이쪽을 지난다 — 토큰은 프록시가
    #: 주입하고 제어 평면은 보지 않는다 (D5).
    egress_proxy_url: str | None = None
    #: 콘솔 주소. 알림의 "열기" 링크가 여기로 간다 (T-0604).
    console_base_url: str = ""
    #: Slack incoming webhook. **URL 자체가 비밀이다.**
    slack_webhook_url: str = ""
    smtp_host: str = ""
    smtp_port: int = 587
    smtp_sender: str = "awp@example.invalid"
    smtp_username: str = ""
    smtp_password: str = ""
    #: 알림 수신자. 비면 메일을 보내지 않는다.
    notify_recipients: tuple[str, ...] = ()
    extra: Mapping[str, str] = field(default_factory=dict)


def load_config(env: Mapping[str, str]) -> Config:
    """`os.environ` 을 **인자로 받는다** — 전역을 읽지 않는다.

    테스트와 다른 배포 프리셋이 dict 를 넘길 수 있고, 그래야 환경이 테스트에
    새지 않는다.
    """
    problems: list[str] = []

    database_url = env.get("AWP_DATABASE_URL", "").strip()
    if not database_url:
        problems.append("AWP_DATABASE_URL 이 필요하다")

    port_raw = env.get("AWP_PORT", "8000")
    port = 8000
    try:
        port = int(port_raw)
        if not 1 <= port <= 65535:
            problems.append(f"AWP_PORT 가 범위를 벗어났다: {port}")
    except ValueError:
        problems.append(f"AWP_PORT 가 정수가 아니다: {port_raw!r}")

    # **길이를 기동 시점에 본다.** 짧은 루트로 돌기 시작하면, 그 상태로
    # 쓰인 자격증명이 전부 약한 키로 암호화된다. 나중에 알아채도 되돌릴 수
    # 없다 — 전부 다시 받아야 한다.
    root = env.get("AWP_CREDENTIAL_ROOT_SECRET", "").encode()
    if root and len(root) < MIN_ROOT_BYTES:
        problems.append(
            f"AWP_CREDENTIAL_ROOT_SECRET 이 {MIN_ROOT_BYTES}바이트보다 짧다 ({len(root)}바이트)"
        )

    key_version_raw = env.get("AWP_CREDENTIAL_KEY_VERSION", "1")
    key_version = 1
    try:
        key_version = int(key_version_raw)
        if key_version < 1:
            problems.append(f"AWP_CREDENTIAL_KEY_VERSION 은 1 이상이어야 한다: {key_version}")
    except ValueError:
        problems.append(f"AWP_CREDENTIAL_KEY_VERSION 이 정수가 아니다: {key_version_raw!r}")

    smtp_port = 587
    raw_smtp_port = env.get("AWP_SMTP_PORT", "587")
    try:
        smtp_port = int(raw_smtp_port)
    except ValueError:
        problems.append(f"AWP_SMTP_PORT 가 정수가 아니다: {raw_smtp_port!r}")

    level = env.get("AWP_LOG_LEVEL", "INFO").upper()
    if level not in {"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"}:
        problems.append(f"모르는 AWP_LOG_LEVEL: {level!r}")

    if problems:
        raise ConfigError(tuple(problems))

    return Config(
        database_url=database_url,
        host=env.get("AWP_HOST", "0.0.0.0"),  # noqa: S104
        port=port,
        api_key_pepper=env.get("AWP_API_KEY_PEPPER", "").encode(),
        credential_root_secret=root,
        credential_key_version=key_version,
        default_model_card=env.get("AWP_DEFAULT_MODEL_CARD") or None,
        log_level=level,
        in_process_realtime=env.get("AWP_IN_PROCESS_REALTIME", "").lower() in {"1", "true", "yes"},
        blob_bucket=env.get("AWP_BLOB_BUCKET") or None,
        blob_endpoint=env.get("AWP_BLOB_ENDPOINT") or None,
        blob_region=env.get("AWP_BLOB_REGION") or None,
        blob_local_root=env.get("AWP_BLOB_LOCAL_ROOT", ".awp-blobs"),
        github_skills_enabled=env.get("AWP_GITHUB_SKILLS", "").lower() in {"1", "true", "yes"},
        github_api_base=env.get("AWP_GITHUB_API_BASE", "https://api.github.com"),
        egress_proxy_url=env.get("AWP_EGRESS_PROXY_URL") or None,
        console_base_url=env.get("AWP_CONSOLE_BASE_URL", "").rstrip("/"),
        slack_webhook_url=env.get("AWP_SLACK_WEBHOOK_URL", ""),
        smtp_host=env.get("AWP_SMTP_HOST", ""),
        smtp_port=smtp_port,
        smtp_sender=env.get("AWP_SMTP_SENDER", "awp@example.invalid"),
        smtp_username=env.get("AWP_SMTP_USERNAME", ""),
        smtp_password=env.get("AWP_SMTP_PASSWORD", ""),
        notify_recipients=tuple(
            x.strip() for x in env.get("AWP_NOTIFY_RECIPIENTS", "").split(",") if x.strip()
        ),
    )


__all__ = ["MIN_ROOT_BYTES", "Config", "ConfigError", "load_config"]
