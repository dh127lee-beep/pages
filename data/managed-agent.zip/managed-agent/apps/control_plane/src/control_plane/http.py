"""미들웨어 8단계. **순서가 의미를 가진다.**

`plan/09-codebase.md` §4.

```
1. request_metrics   관측이 가장 밖 — 실패한 요청도 세야 한다
2. error_envelope    모든 4xx/5xx를 공통 envelope으로
3. request_id        트레이스 상관관계
4. /healthz /readyz  인증 없음. 여기서 분기
5. auth              principal + workspace_id 확정
6. rate_limit        인증 후 — 워크스페이스 키로 버킷
7. workspace_app     WorkspaceAppRegistry에서 앱 그래프 획득
8. 라우터
```

Starlette 의 미들웨어는 **등록 역순으로 바깥**이다. 그래서 `add_middleware` 를
8 → 1 순서로 부른다. 헷갈리기 쉬운 지점이라 아래 `build_app` 에 번호를 적어 뒀다.
"""

from __future__ import annotations

import logging
import time
import uuid
from collections.abc import Awaitable, Callable
from typing import TYPE_CHECKING, Any

from fastapi import FastAPI, Request, Response
from fastapi.responses import JSONResponse
from ma_api.shared.errors import ApiError, ErrorType

if TYPE_CHECKING:
    from control_plane.assembly import GraphSource

type Handler = Callable[[Request], Awaitable[Response]]

_log = logging.getLogger("control_plane.http")

#: 인증을 요구하지 않는 경로. **프로브가 실패하면 파드가 죽는다.**
PUBLIC_PATHS = frozenset({"/healthz", "/readyz", "/openapi.json", "/docs", "/redoc"})


def _envelope(err: ApiError, request_id: str) -> JSONResponse:
    body = err.envelope()
    body["error"]["request_id"] = request_id
    return JSONResponse(status_code=err.status, content=body)


async def request_metrics(request: Request, call_next: Handler) -> Response:
    """① 가장 바깥. **실패한 요청도 세야** 에러율을 알 수 있다."""
    started = time.perf_counter()
    status = 500
    try:
        response = await call_next(request)
        status = response.status_code
        return response
    finally:
        elapsed = (time.perf_counter() - started) * 1000
        _log.info(
            "http %s %s %s %.1fms",
            request.method,
            request.url.path,
            status,
            elapsed,
        )


def _unwrap(exc: BaseException, depth: int = 6) -> ApiError | None:
    """`ApiError` 를 체인에서 찾아낸다.

    **`BaseHTTPMiddleware` 가 예외를 감싼다.** Starlette 은 내부 태스크그룹의
    예외를 `raise app_exc from app_exc.__cause__` 로 다시 올리고, 그 과정에서
    원본이 `__cause__`/`__context__` 뒤로 들어가거나 `ExceptionGroup` 에
    담긴다. 그래서 `except ApiError` 만으로는 못 잡는다 (`IMPL-0011`).
    """
    seen = exc
    for _ in range(depth):
        if isinstance(seen, ApiError):
            return seen
        if isinstance(seen, BaseExceptionGroup):
            for sub in seen.exceptions:
                found = _unwrap(sub, depth - 1)
                if found is not None:
                    return found
            return None
        nxt = seen.__cause__ or seen.__context__
        if nxt is None:
            return None
        seen = nxt
    return None  # pragma: no cover — 체인이 6단계를 넘지 않는다


async def error_envelope(request: Request, call_next: Handler) -> Response:
    """② 모든 4xx/5xx 를 공통 envelope 으로.

    **내부 예외의 메시지를 본문에 싣지 않는다** — 경로·쿼리·스택이 새면
    그 자체가 정보 누설이다. 상세는 로그로만 간다.
    """
    request_id = getattr(request.state, "request_id", "-")
    try:
        return await call_next(request)
    except Exception as exc:
        err = _unwrap(exc)
        if err is None:
            _log.exception("처리하지 않은 예외 request_id=%s", request_id)
            err = ApiError(ErrorType.API, "내부 오류")
        elif err.status >= 500:
            _log.exception("api_error request_id=%s", request_id)
        return _envelope(err, request_id)


async def request_id_mw(request: Request, call_next: Handler) -> Response:
    """③ 트레이스 상관관계. 클라이언트가 준 것을 **신뢰하되 길이를 자른다**."""
    incoming = request.headers.get("x-request-id", "")
    rid = incoming[:64] if incoming else uuid.uuid4().hex
    request.state.request_id = rid
    response = await call_next(request)
    response.headers["x-request-id"] = rid
    return response


def make_auth(source: GraphSource) -> Callable[[Request, Handler], Awaitable[Response]]:
    """⑤ 인증. **워크스페이스는 여기서 한 번만 정해진다.**"""

    async def auth(request: Request, call_next: Handler) -> Response:
        if request.url.path in PUBLIC_PATHS:  # ④ 공개 경로 분기
            return await call_next(request)

        key = request.headers.get("x-api-key", "")
        if not key:
            bearer = request.headers.get("authorization", "")
            if bearer.lower().startswith("bearer "):
                key = bearer[7:].strip()

        principal = await source.authenticate(key)
        if principal is None:
            # **올리지 않고 응답한다.** `BaseHTTPMiddleware` 경계를 넘는 예외는
            # 감싸지므로, 미들웨어 안에서는 응답을 만드는 편이 정직하다.
            # 라우트 안에서는 그대로 `raise` 해도 된다 — 예외 핸들러가 잡는다.
            return _envelope(
                ApiError(ErrorType.AUTHENTICATION, "자격증명이 없거나 무효하다"),
                getattr(request.state, "request_id", "-"),
            )

        # `x-active-workspace` 는 **무시한다** — API 키는 발급 시점에
        # 워크스페이스가 정해진다. 덮어쓰기를 허용하면 키 탈취 시 횡적 이동이
        # 가능해진다 (`plan/04-api.md` §2.1).
        request.state.principal = principal
        return await call_next(request)

    return auth


def make_workspace_app(
    source: GraphSource,
) -> Callable[[Request, Handler], Awaitable[Response]]:
    """⑦ 워크스페이스별 앱 그래프를 꽂는다."""

    async def workspace_app(request: Request, call_next: Handler) -> Response:
        if request.url.path in PUBLIC_PATHS:
            return await call_next(request)
        principal = request.state.principal
        request.state.graph = await source.graph_for(principal.workspace_id)
        return await call_next(request)

    return workspace_app


def build_app(
    source: GraphSource,
    *,
    title: str = "AWP control plane",
    lifespan: Any = None,
) -> FastAPI:
    """미들웨어를 **8 → 1 순서로 등록**한다 (Starlette 은 역순으로 바깥)."""
    app = FastAPI(title=title, docs_url="/docs", openapi_url="/openapi.json", lifespan=lifespan)

    @app.exception_handler(ApiError)
    async def _api_error(request: Request, exc: Exception) -> JSONResponse:
        """라우트에서 올라온 `ApiError`.

        미들웨어의 `error_envelope` 과 **둘 다 필요하다**: 핸들러는 라우트
        안에서 난 것을, 미들웨어는 다른 미들웨어(인증 등)에서 난 것을 잡는다.
        Starlette 의 예외 핸들러는 미들웨어 체인 **안쪽**에 있기 때문이다.
        """
        err = exc if isinstance(exc, ApiError) else ApiError(ErrorType.API, "내부 오류")
        if err.status >= 500:
            _log.exception("api_error path=%s", request.url.path)
        return _envelope(err, getattr(request.state, "request_id", "-"))

    app.middleware("http")(make_workspace_app(source))  # ⑦
    app.middleware("http")(make_auth(source))  # ④⑤ (rate_limit ⑥ 은 M3)
    app.middleware("http")(request_id_mw)  # ③
    app.middleware("http")(error_envelope)  # ②
    app.middleware("http")(request_metrics)  # ①

    from ma_api.compat import mount_compat
    from ma_api.internal import mount_internal

    mount_internal(app)
    # 공식 호환 lane (`/v1/*`). **공식 모양 에러 핸들러를 함께 붙인다** —
    # 내부 envelope 의 확장이 공식 응답에 실리면 안 된다 (T-0605).
    mount_compat(app)
    return app


__all__ = ["PUBLIC_PATHS", "build_app", "error_envelope", "request_id_mw", "request_metrics"]
