"""uvicorn 기동과 graceful shutdown.

`plan/09-codebase.md` §4.

**SIGTERM 에서 진행 중인 요청을 끝내고 닫는다.** k8s 가 파드를 내릴 때
SSE 연결이 수십 개 열려 있을 수 있고, 그것을 강제로 끊으면 클라이언트가
전부 동시에 재연결해 새 파드를 때린다.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

import uvicorn

if TYPE_CHECKING:
    from fastapi import FastAPI

#: 종료 유예. SSE 하트비트(15s)보다 길어야 클라이언트가 정상 종료를 본다.
GRACEFUL_TIMEOUT = 25


async def serve(app: FastAPI, *, host: str, port: int, log_level: str = "INFO") -> None:
    logging.basicConfig(level=log_level)
    config = uvicorn.Config(
        app,
        host=host,
        port=port,
        log_level=log_level.lower(),
        timeout_graceful_shutdown=GRACEFUL_TIMEOUT,
        # SSE 는 응답이 끝나지 않으므로 접근 로그가 의미 없다 — 미들웨어가 센다.
        access_log=False,
    )
    await uvicorn.Server(config).serve()


__all__ = ["GRACEFUL_TIMEOUT", "serve"]
