"""`config → components → assembly → serve`.

`plan/09-codebase.md` §4.

**이 파일만 `os.environ` 을 본다** — 정확히는 `load_config` 에 넘겨준다.
"""

from __future__ import annotations

import os
import sys

import anyio


async def main() -> None:
    from control_plane.assembly import build_control_plane
    from control_plane.components import default_components
    from control_plane.config import ConfigError, load_config
    from control_plane.serve import serve

    try:
        cfg = load_config(os.environ)  # awp-env-ok — 환경을 읽는 유일한 지점
    except ConfigError as err:
        print(err, file=sys.stderr)  # noqa: T201 — 기동 실패는 stderr 로
        raise SystemExit(2) from err

    components = await default_components(cfg)
    app = await build_control_plane(components)
    await serve(app, host=cfg.host, port=cfg.port, log_level=cfg.log_level)


if __name__ == "__main__":
    anyio.run(main)
