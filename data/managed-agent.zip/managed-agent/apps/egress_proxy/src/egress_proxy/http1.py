"""HTTP/1.1 머리 파싱 — **프록시가 요청마다 주입하려면 필요하다.**

`task/M3-security-governance/T-0402-egress-proxy.md`.

터널을 뚫고 바이트를 그대로 흘려보내면 **첫 요청에만** 헤더를 주입할 수
있다. keep-alive 로 10번 호출하면 9번은 인증 없이 나간다 — 업스트림이
401 을 주므로 조용히 깨지지는 않지만, "주입했다"는 주장이 거짓이 된다.

그래서 요청마다 머리를 읽고 본문 길이를 센다. 지원하는 framing 둘:

| | |
|---|---|
| `Content-Length` | 그만큼 읽는다 |
| `Transfer-Encoding: chunked` | 청크를 세어 읽는다 |

**둘 다 아니면 `Connection: close` 로 떨어진다** — 길이를 모르는 본문을
추측하느니 연결을 하나 더 여는 편이 낫다.
"""

from __future__ import annotations

import asyncio
from contextlib import suppress
from dataclasses import dataclass, field

#: 요청 머리 상한. 넘으면 끊는다 — 헤더로 메모리를 채우는 공격이 있다.
MAX_HEAD_BYTES = 64 * 1024

#: 한 번에 읽는 본문 조각.
CHUNK = 64 * 1024

#: 본문 상한. 넘으면 끊는다.
MAX_BODY_BYTES = 100 * 1024 * 1024


class MalformedRequest(Exception):
    """읽을 수 없는 요청. **추측하지 않고 끊는다.**"""


@dataclass
class RequestHead:
    method: str
    target: str
    version: str
    #: 원래 순서를 유지한다 — 헤더 순서가 업스트림의 서명 검증에 쓰이는
    #: API 가 있다.
    headers: list[tuple[str, str]] = field(default_factory=list)

    def get(self, name: str) -> str | None:
        low = name.lower()
        for k, v in self.headers:
            if k.lower() == low:
                return v
        return None

    def mapping(self) -> dict[str, str]:
        return {k: v for k, v in self.headers}

    def with_headers(self, headers: dict[str, str]) -> RequestHead:
        """주입 결과로 헤더를 **교체한다.**

        원래 순서를 최대한 지키되, 새로 생긴 헤더는 뒤에 붙인다.
        """
        lowered = {k.lower(): (k, v) for k, v in headers.items()}
        out: list[tuple[str, str]] = []
        seen: set[str] = set()
        for k, _ in self.headers:
            low = k.lower()
            if low in seen:
                continue
            if low in lowered:
                out.append(lowered[low])
                seen.add(low)
        for low, (k, v) in lowered.items():
            if low not in seen:
                out.append((k, v))
        return RequestHead(
            method=self.method, target=self.target, version=self.version, headers=out
        )

    def serialize(self) -> bytes:
        lines = [f"{self.method} {self.target} {self.version}"]
        lines += [f"{k}: {v}" for k, v in self.headers]
        return ("\r\n".join(lines) + "\r\n\r\n").encode("latin-1")

    @property
    def body_length(self) -> int | None:
        """본문 길이. `None` 이면 **chunked 이거나 알 수 없다.**"""
        raw = self.get("content-length")
        if raw is None:
            return 0 if not self.is_chunked else None
        try:
            length = int(raw)
        except ValueError as exc:
            raise MalformedRequest(f"Content-Length 가 정수가 아니다: {raw!r}") from exc
        if length < 0 or length > MAX_BODY_BYTES:
            raise MalformedRequest(f"Content-Length 가 범위를 벗어났다: {length}")
        return length

    @property
    def is_chunked(self) -> bool:
        te = self.get("transfer-encoding") or ""
        return "chunked" in te.lower()


async def read_head(reader: asyncio.StreamReader) -> RequestHead | None:
    """요청 머리 하나. 연결이 닫혔으면 `None`."""
    try:
        raw = await reader.readuntil(b"\r\n\r\n")
    except asyncio.IncompleteReadError:
        return None
    except asyncio.LimitOverrunError as exc:
        raise MalformedRequest("요청 머리가 너무 크다") from exc

    if len(raw) > MAX_HEAD_BYTES:
        raise MalformedRequest("요청 머리가 너무 크다")

    text = raw.decode("latin-1")
    lines = text.split("\r\n")
    start = lines[0].split(" ")
    if len(start) != 3:
        raise MalformedRequest(f"요청 라인을 읽을 수 없다: {lines[0]!r}")

    headers: list[tuple[str, str]] = []
    for line in lines[1:]:
        if not line:
            continue
        name, sep, value = line.partition(":")
        if not sep:
            raise MalformedRequest(f"헤더를 읽을 수 없다: {line!r}")
        headers.append((name.strip(), value.strip()))

    return RequestHead(method=start[0], target=start[1], version=start[2], headers=headers)


async def pump_body(
    head: RequestHead, reader: asyncio.StreamReader, writer: asyncio.StreamWriter
) -> bool:
    """본문을 업스트림으로 옮긴다. **길이를 모르면 `False`.**

    `False` 면 호출자가 연결을 닫는다 — 추측해서 흘리면 다음 요청의
    머리를 본문으로 먹거나 그 반대가 된다.
    """
    if head.is_chunked:
        await _pump_chunked(reader, writer)
        return True

    remaining = head.body_length
    if remaining is None:
        return False

    while remaining > 0:
        block = await reader.read(min(CHUNK, remaining))
        if not block:
            raise MalformedRequest("본문이 예고보다 짧다")
        writer.write(block)
        remaining -= len(block)
    await writer.drain()
    return True


async def _pump_chunked(reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
    total = 0
    while True:
        size_line = await reader.readuntil(b"\r\n")
        writer.write(size_line)
        try:
            size = int(size_line.strip().split(b";")[0], 16)
        except ValueError as exc:
            raise MalformedRequest("청크 크기를 읽을 수 없다") from exc

        total += size
        if total > MAX_BODY_BYTES:
            raise MalformedRequest("본문이 상한을 넘었다")

        if size == 0:
            # 마지막 청크 뒤의 트레일러까지 옮긴다.
            trailer = await reader.readuntil(b"\r\n")
            writer.write(trailer)
            while trailer != b"\r\n":
                trailer = await reader.readuntil(b"\r\n")
                writer.write(trailer)
            await writer.drain()
            return

        body = await reader.readexactly(size + 2)  # 데이터 + CRLF
        writer.write(body)
        await writer.drain()


async def relay(src: asyncio.StreamReader, dst: asyncio.StreamWriter) -> None:
    """한 방향으로 흘린다. 응답을 돌려줄 때 쓴다."""
    try:
        while True:
            block = await src.read(CHUNK)
            if not block:
                break
            dst.write(block)
            await dst.drain()
    except (ConnectionError, asyncio.IncompleteReadError):
        pass
    finally:
        with suppress(Exception):
            dst.close()


__all__ = [
    "CHUNK",
    "MAX_BODY_BYTES",
    "MAX_HEAD_BYTES",
    "MalformedRequest",
    "RequestHead",
    "pump_body",
    "read_head",
    "relay",
]
