"""세션별 CA 와 리프 인증서 발급 — MITM 의 재료.

`plan/07-sandbox.md` §6.1 ① · `ADR-0010` · `IMPL-0021`.

MITM 을 하려면 샌드박스가 **우리 인증서를 믿어야** 한다. 그 믿음의 범위를
어디까지 둘 것인가가 이 파일의 유일한 설계 질문이다.

**세션마다 다른 CA 를 만든다.** 사내 공통 CA 하나를 샌드박스에 넣으면,
그 CA 로 서명한 인증서가 **모든 세션에서 유효**해진다 — 한 세션에서 CA 키가
새면 다른 세션의 트래픽도 가로챌 수 있다. 세션 CA 는 그 세션이 끝나면
쓸모가 없다.

```
세션 시작 → CA 키쌍 생성 (메모리)
          → CA 인증서를 샌드박스 신뢰 저장소에 넣는다 (파일 하나)
          → 프록시가 요청마다 리프 인증서를 그 CA 로 서명해 발급
세션 끝   → 둘 다 버린다
```

> **CA 개인키는 디스크에 쓰지 않는다.** 샌드박스에 들어가는 것은
> **인증서(공개)** 뿐이고, 키는 프록시 프로세스 메모리에만 있다.
"""

from __future__ import annotations

import datetime as dt
import ipaddress
from dataclasses import dataclass, field

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.x509.oid import NameOID

#: 리프 인증서 수명. 짧게 둔다 — 새어도 쓸 수 있는 창이 좁다.
LEAF_HOURS = 24

#: CA 수명. 세션보다 넉넉하되 무한하지 않다.
CA_DAYS = 7

#: 시계 오차 여유. 샌드박스와 프록시의 시계가 조금 다를 수 있다.
CLOCK_SKEW = dt.timedelta(minutes=5)

#: 캐시할 리프 인증서 수. 한 세션이 닿는 호스트 수의 상한이기도 하다 —
#: 넘으면 매번 새로 만들어 느려질 뿐 동작은 같다.
LEAF_CACHE_SIZE = 256

#: **ECDSA P-256 을 쓴다.** RSA-2048 키 생성이 수십~수백 ms 인데,
#: 리프를 요청마다 만들 수 있어야 하므로 그 비용을 낼 수 없다 (`IMPL-0021`).
_CURVE = ec.SECP256R1()


@dataclass(frozen=True, slots=True)
class Issued:
    """발급 결과. **PEM 바이트** — 파일로 쓰든 메모리에 두든 호출자가 정한다."""

    cert_pem: bytes
    key_pem: bytes


class SessionCa:
    """세션 하나의 인증 기관. **키는 메모리에만 있다.**

    `dataclass` 가 아닌 이유: 키를 기본값 `None` 으로 선언하면 타입이
    거짓이 된다 (`_key` 는 절대 `None` 이 아니다). 생성자에서 바로 만든다.
    """

    def __init__(self, session_id: str) -> None:
        self.session_id = session_id
        self._key = ec.generate_private_key(_CURVE)
        self._cert = self._self_signed()
        self._leaves: dict[str, Issued] = {}

    def __repr__(self) -> str:
        # 기본 `repr` 이 키 객체를 찍지는 않지만, 명시해 둔다 — 이 객체가
        # 예외 추적에 실릴 수 있고 그때 무엇이 보이는지가 중요하다.
        return f"SessionCa(session_id={self.session_id!r}, leaves={len(self._leaves)})"

    def _self_signed(self) -> x509.Certificate:
        name = x509.Name(
            [
                x509.NameAttribute(NameOID.ORGANIZATION_NAME, "AWP"),
                x509.NameAttribute(NameOID.COMMON_NAME, f"AWP Session CA {self.session_id}"),
            ]
        )
        now = dt.datetime.now(dt.UTC)
        return (
            x509.CertificateBuilder()
            .subject_name(name)
            .issuer_name(name)
            .public_key(self._key.public_key())
            .serial_number(x509.random_serial_number())
            .not_valid_before(now - CLOCK_SKEW)
            .not_valid_after(now + dt.timedelta(days=CA_DAYS))
            # **`path_length=0`** — 이 CA 로 만든 인증서는 또 다른 CA 가
            # 될 수 없다. 리프 키가 새도 체인을 늘릴 수 없다.
            .add_extension(x509.BasicConstraints(ca=True, path_length=0), critical=True)
            .add_extension(
                x509.KeyUsage(
                    digital_signature=True,
                    key_cert_sign=True,
                    crl_sign=True,
                    content_commitment=False,
                    key_encipherment=False,
                    data_encipherment=False,
                    key_agreement=False,
                    encipher_only=False,
                    decipher_only=False,
                ),
                critical=True,
            )
            # **SKI/AKI 가 없으면 OpenSSL 3 의 엄격 검증이 거부한다.**
            # `ssl.create_default_context()` 가 `VERIFY_X509_STRICT` 를
            # 켜고, 실제 클라이언트는 전부 그것을 쓴다 (`IMPL-0021`).
            .add_extension(
                x509.SubjectKeyIdentifier.from_public_key(self._key.public_key()),
                critical=False,
            )
            .sign(self._key, hashes.SHA256())
        )

    def ca_cert_pem(self) -> bytes:
        """**샌드박스에 들어가는 것.** 공개 인증서뿐이다 — 키는 아니다."""
        return self._cert.public_bytes(serialization.Encoding.PEM)

    def leaf_for(self, host: str) -> Issued:
        """이 호스트를 가장할 인증서. **캐시한다** — 호스트마다 한 번만."""
        key = host.lower().rstrip(".")
        cached = self._leaves.get(key)
        if cached is not None:
            return cached
        if len(self._leaves) >= LEAF_CACHE_SIZE:
            # 한 세션이 256개 호스트를 넘기면 가장 오래된 것부터 버린다.
            # LRU 가 아니라 FIFO 다 — 정확도보다 단순함이 낫고, 넘쳐도
            # 느려질 뿐 틀리지 않는다.
            self._leaves.pop(next(iter(self._leaves)))

        issued = self._mint(key)
        self._leaves[key] = issued
        return issued

    def _mint(self, host: str) -> Issued:
        leaf_key = ec.generate_private_key(_CURVE)
        now = dt.datetime.now(dt.UTC)

        try:
            san: x509.GeneralName = x509.IPAddress(ipaddress.ip_address(host))
        except ValueError:
            san = x509.DNSName(host)

        cert = (
            x509.CertificateBuilder()
            .subject_name(x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, host[:64])]))
            .issuer_name(self._cert.subject)
            .public_key(leaf_key.public_key())
            .serial_number(x509.random_serial_number())
            .not_valid_before(now - CLOCK_SKEW)
            .not_valid_after(now + dt.timedelta(hours=LEAF_HOURS))
            .add_extension(x509.SubjectAlternativeName([san]), critical=False)
            .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
            .add_extension(
                x509.ExtendedKeyUsage([x509.oid.ExtendedKeyUsageOID.SERVER_AUTH]),
                critical=False,
            )
            .add_extension(
                x509.SubjectKeyIdentifier.from_public_key(leaf_key.public_key()),
                critical=False,
            )
            # 리프가 **어느 CA 로 서명됐는지**를 가리킨다. 엄격 검증이
            # 이것을 요구한다.
            .add_extension(
                x509.AuthorityKeyIdentifier.from_issuer_public_key(self._key.public_key()),
                critical=False,
            )
            .sign(self._key, hashes.SHA256())
        )
        return Issued(
            cert_pem=cert.public_bytes(serialization.Encoding.PEM),
            key_pem=leaf_key.private_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PrivateFormat.PKCS8,
                # **암호를 걸지 않는다.** 걸면 그 암호를 어딘가에 둬야 하고,
                # 이 키는 메모리에만 있다가 세션과 함께 사라진다.
                encryption_algorithm=serialization.NoEncryption(),
            ),
        )


@dataclass
class CaRegistry:
    """세션 → CA. **세션이 끝나면 버린다.**"""

    _cas: dict[str, SessionCa] = field(default_factory=dict, repr=False)

    def for_session(self, session_id: str) -> SessionCa:
        existing = self._cas.get(session_id)
        if existing is None:
            existing = SessionCa(session_id)
            self._cas[session_id] = existing
        return existing

    def forget(self, session_id: str) -> bool:
        """**세션이 끝나면 반드시 부른다.**

        안 부르면 CA 키가 프로세스 수명 내내 메모리에 남고, 그 세션의
        샌드박스가 (정리에 실패해) 아직 살아 있으면 계속 쓸 수 있다.
        """
        return self._cas.pop(session_id, None) is not None

    def __len__(self) -> int:
        return len(self._cas)


__all__ = [
    "CA_DAYS",
    "CLOCK_SKEW",
    "LEAF_CACHE_SIZE",
    "LEAF_HOURS",
    "CaRegistry",
    "Issued",
    "SessionCa",
]
