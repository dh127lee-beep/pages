"""MITM 프록시 — `CONNECT` 를 받아 TLS 를 가로채고 자격증명을 주입한다.

`plan/07-sandbox.md` §6.1 · `ADR-0010` · `IMPL-0021`.

```
샌드박스                프록시                        업스트림
  │ CONNECT api.x:443     │
  │ Proxy-Authorization   │ ① 세션 식별
  │──────────────────────▶│ ② allowed_hosts 검사  ─── 아니면 403
  │                       │
  │◀── 200 Established ───│ 세션 CA 로 api.x 인증서 발급
  │═══ TLS 핸드셰이크 ════▶│ (샌드박스는 그 CA 를 믿는다)
  │                       │
  │ GET /v1/... ─────────▶│ ③ 자격증명 조회 (fence 검증)
  │                       │ ④ Authorization 주입
  │                       │ ⑤ 업스트림으로 ──────────▶│
  │◀──────────────────────│◀──────────────────────────│
  │                       │ ⑥ credential_events 적립
```

**판단은 여기 없다.** `ma_egress.EgressPipeline` 이 한다 — 이 파일은 소켓과
TLS 다. 나눈 이유: 판단은 네트워크 없이 테스트할 수 있어야 하고,
`tests/security/test_egress_bypass.py` 가 그렇게 한다.

> **프록시가 죽으면 세션이 막히는 것이 올바른 동작이다.** 가용성보다
> 기밀성이 우선이다. 그래서 모든 실패 경로가 "끊는다"로 간다.
"""

from __future__ import annotations

import asyncio
import logging
import ssl
import tempfile
from contextlib import suppress
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING

from egress_proxy import http1
from ma_egress import Forward, Refuse, Target

if TYPE_CHECKING:
    from egress_proxy.ca import CaRegistry, SessionCa
    from ma_egress import EgressPipeline

_log = logging.getLogger("egress_proxy")

#: `CONNECT` 머리를 기다리는 시간. 넘으면 끊는다.
CONNECT_TIMEOUT = 10.0

#: 업스트림 연결 시간.
UPSTREAM_TIMEOUT = 30.0

#: 세션 토큰을 싣는 헤더. **표준 프록시 인증 자리를 쓴다** — curl·httpx·
#: requests 가 전부 `HTTPS_PROXY` 의 userinfo 로 이것을 보낸다.
AUTH_HEADER = "proxy-authorization"

#: 샌드박스가 주장하는 fence generation. **권한이 아니라 주장이다** —
#: 파이프라인이 DB 의 값과 대조한다.
GENERATION_HEADER = "x-awp-generation"


@dataclass
class ProxyServer:
    pipeline: EgressPipeline
    cas: CaRegistry
    #: 세션 토큰 → 세션 id. CA 를 고르는 데만 쓴다 — 권한 판단은
    #: 파이프라인이 토큰으로 직접 한다.
    session_of: object
    host: str = "127.0.0.1"
    port: int = 0
    #: 업스트림 TLS 검증. **끄지 않는다** — 프록시가 가로채는 것과
    #: 업스트림을 검증하지 않는 것은 다른 이야기다.
    upstream_ssl: ssl.SSLContext = field(default_factory=ssl.create_default_context)
    _server: asyncio.Server | None = field(default=None, repr=False)
    _certs: Path | None = field(default=None, repr=False)

    async def start(self) -> int:
        """듣기 시작하고 **실제 포트**를 돌려준다 (0 을 주면 임시 포트)."""
        self._certs = Path(tempfile.mkdtemp(prefix="awp-egress-"))
        self._server = await asyncio.start_server(self._handle, self.host, self.port)
        bound = self._server.sockets[0].getsockname()[1]
        self.port = bound
        return int(bound)

    async def aclose(self) -> None:
        if self._server is not None:
            self._server.close()
            with suppress(Exception):
                await self._server.wait_closed()
        if self._certs is not None:
            # 리프 키가 디스크에 남지 않게 지운다. `SSLContext` 가 파일
            # 경로를 요구하므로 **잠깐은** 디스크에 있다 (`IMPL-0021`).
            import shutil

            with suppress(OSError):
                shutil.rmtree(self._certs)

    # ── 연결 하나 ────────────────────────────────────────
    async def _handle(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        try:
            await self._connect_phase(reader, writer)
        except (http1.MalformedRequest, TimeoutError) as exc:
            _log.info("연결을 끊었다: %s", exc)
            await _refuse(writer, 400, "bad_request")
        except (ConnectionError, ssl.SSLError) as exc:
            _log.debug("연결 오류: %s", type(exc).__name__)
        except Exception:
            _log.exception("프록시 처리 중 예외")
        finally:
            with suppress(Exception):
                writer.close()

    async def _connect_phase(
        self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter
    ) -> None:
        async with asyncio.timeout(CONNECT_TIMEOUT):
            head = await http1.read_head(reader)
        if head is None:
            return
        if head.method != "CONNECT":
            # **평문 HTTP 를 중계하지 않는다.** 중계하면 allowlist 를
            # 거치더라도 내용이 평문으로 네트워크에 나간다.
            await _refuse(writer, 405, "connect_required")
            return

        token = _bearer(head.get(AUTH_HEADER))
        if token is None:
            await _refuse(writer, 407, "proxy_auth_required")
            return

        generation = _int_or_none(head.get(GENERATION_HEADER))

        # **CONNECT 는 ①② 만 한다.** 안쪽 요청을 아직 모르므로 자격증명을
        # 조회할 이유가 없고, 조회하면 감사에 주입 기록이 두 번 남는다.
        decision = await self.pipeline.authorize(
            session_token=token, target=head.target, claimed_generation=generation
        )
        if isinstance(decision, Refuse):
            _log.info("CONNECT 거부 target=%s reason=%s", head.target, decision.reason)
            await _refuse(writer, decision.status, str(decision.reason))
            return

        writer.write(b"HTTP/1.1 200 Connection Established\r\n\r\n")
        await writer.drain()
        await self._tunnel(reader, writer, token, decision.target)

    # ── TLS 가로채기 ─────────────────────────────────────
    async def _tunnel(
        self,
        reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter,
        token: str,
        target: Target,
    ) -> None:
        session_id = self.session_of(token)  # type: ignore[operator]
        if session_id is None:  # pragma: no cover — 파이프라인이 이미 걸렀다
            return
        ca = self.cas.for_session(str(session_id))

        inner_r, inner_w = await self._wrap_tls(reader, writer, ca, target.host)
        try:
            await self._serve_requests(inner_r, inner_w, token, target)
        finally:
            with suppress(Exception):
                inner_w.close()

    async def _wrap_tls(
        self,
        reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter,
        ca: SessionCa,
        host: str,
    ) -> tuple[asyncio.StreamReader, asyncio.StreamWriter]:
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        cert, key = self._write_leaf(ca, host)
        context.load_cert_chain(str(cert), str(key))

        transport = writer.transport
        protocol = transport.get_protocol()
        loop = asyncio.get_running_loop()
        new_transport = await loop.start_tls(transport, protocol, context, server_side=True)
        # `start_tls` 뒤에는 **새 transport 로 쓰기**를 해야 한다.
        writer._transport = new_transport  # type: ignore[attr-defined]
        reader._transport = new_transport  # type: ignore[attr-defined]
        return reader, writer

    def _write_leaf(self, ca: SessionCa, host: str) -> tuple[Path, Path]:
        """`SSLContext.load_cert_chain` 이 **파일 경로를 요구한다.**

        메모리 BIO 로 넘기는 API 가 파이썬 `ssl` 에 없다. 그래서 잠깐
        디스크에 쓰고, `aclose()` 가 디렉터리째 지운다 (`IMPL-0021`).
        디렉터리는 `0o700` 으로 만들어진다 (`mkdtemp` 기본값).
        """
        assert self._certs is not None  # start() 가 만든다
        safe = host.replace("/", "_").replace("..", "_")[:80]
        cert = self._certs / f"{safe}.crt"
        key = self._certs / f"{safe}.key"
        if not cert.exists():
            issued = ca.leaf_for(host)
            cert.write_bytes(issued.cert_pem)
            key.write_bytes(issued.key_pem)
            key.chmod(0o600)
        return cert, key

    # ── 요청마다 주입 ────────────────────────────────────
    async def _serve_requests(
        self,
        reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter,
        token: str,
        tunnel: Target,
    ) -> None:
        """터널 안의 요청을 **하나씩** 처리한다.

        터널을 뚫고 바이트를 그대로 흘리면 keep-alive 의 두 번째 요청부터
        주입이 빠진다. 그래서 요청마다 머리를 읽는다.
        """
        while True:
            head = await http1.read_head(reader)
            if head is None:
                return

            decision = await self.pipeline.decide(
                session_token=token,
                target=f"{tunnel.host}:{tunnel.port}",
                headers=head.mapping(),
                claimed_generation=None,
            )
            if isinstance(decision, Refuse):
                await _refuse(writer, decision.status, str(decision.reason))
                return

            if not await self._forward_once(head, decision, reader, writer):
                return

    async def _forward_once(
        self,
        head: http1.RequestHead,
        decision: Forward,
        reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter,
    ) -> bool:
        """업스트림 왕복 하나. 계속 받아도 되면 `True`."""
        try:
            async with asyncio.timeout(UPSTREAM_TIMEOUT):
                up_r, up_w = await asyncio.open_connection(
                    decision.host,
                    decision.port,
                    ssl=self.upstream_ssl if decision.port != 80 else None,
                    server_hostname=decision.host if decision.port != 80 else None,
                )
        except (OSError, TimeoutError) as exc:
            _log.info("업스트림 연결 실패 host=%s: %s", decision.host, type(exc).__name__)
            await _refuse(writer, 502, "upstream_unreachable")
            return False

        try:
            up_w.write(head.with_headers(dict(decision.headers)).serialize())
            await up_w.drain()

            if not await http1.pump_body(head, reader, up_w):
                # 길이를 모르는 본문 — 추측하지 않고 한 번만 중계한다.
                await http1.relay(up_r, writer)
                return False

            await http1.relay(up_r, writer)
        finally:
            with suppress(Exception):
                up_w.close()
        # 응답을 끝까지 흘렸으면 업스트림 연결이 닫힌 것이다.
        # keep-alive 를 이어 가려면 응답 framing 도 파싱해야 하는데,
        # 그 복잡도를 지금 사지 않는다 (`IMPL-0021`).
        return False


# ── 작은 것들 ────────────────────────────────────────────
async def _refuse(writer: asyncio.StreamWriter, status: int, code: str) -> None:
    """**본문에 이유를 자세히 적지 않는다.**

    자세한 이유를 샌드박스에 주면 모델이 그것으로 목록을 더듬는다.
    `code` 는 짧은 토큰이고, 자세한 것은 감사와 프록시 로그로 간다.
    """
    body = f'{{"error":"{code}"}}'.encode()
    head = (
        f"HTTP/1.1 {status} {code}\r\n"
        f"Content-Type: application/json\r\n"
        f"Content-Length: {len(body)}\r\n"
        f"Connection: close\r\n\r\n"
    ).encode("latin-1")
    with suppress(Exception):
        writer.write(head + body)
        await writer.drain()


def _bearer(raw: str | None) -> str | None:
    if not raw:
        return None
    scheme, _, value = raw.partition(" ")
    if scheme.lower() not in {"bearer", "basic"} or not value.strip():
        return None
    return value.strip()


def _int_or_none(raw: str | None) -> int | None:
    if raw is None:
        return None
    try:
        return int(raw)
    except ValueError:
        return None


__all__ = [
    "AUTH_HEADER",
    "CONNECT_TIMEOUT",
    "GENERATION_HEADER",
    "UPSTREAM_TIMEOUT",
    "ProxyServer",
]
