"""프록시 기동 — DB 에 붙고 파이프라인을 조립해 듣는다.

`plan/09-codebase.md` §4 · `IMPL-0021`.

**세션 토큰 → 세션** 해소가 조립의 핵심이다. 발급은 샌드박스
프로비저닝이 하고, 프록시는 읽기만 한다. 비어 있으면 모든 요청이
`unknown_session` 으로 막힌다 — **열리는 쪽이 아니라 막히는 쪽이
기본값이다.**

> `serve()` 는 아직 단독 기동을 지원하지 않는다. 막힌 곳과 이유는 그
> 함수의 docstring 에 적혀 있다.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ma_egress.lookup import SessionTicket

    from egress_proxy.config import ProxyConfig

_log = logging.getLogger("egress_proxy.serve")


@dataclass
class InMemoryTickets:
    """세션 토큰 → `SessionTicket`.

    **발급은 샌드박스 프로비저닝이 한다** (T-0303 의 `SandboxOrchestrator`).
    프록시는 읽기만 한다.

    비어 있으면 모든 요청이 막힌다 — 그것이 올바른 기본값이다.
    """

    _by_token: dict[str, SessionTicket]

    def __init__(self, initial: dict[str, SessionTicket] | None = None) -> None:
        self._by_token = dict(initial or {})

    def resolve(self, session_token: str) -> SessionTicket | None:
        return self._by_token.get(session_token)

    def issue(self, token: str, ticket: SessionTicket) -> None:
        self._by_token[token] = ticket

    def revoke(self, token: str) -> bool:
        """**세션이 끝나면 반드시 부른다.** 안 부르면 좀비가 계속 붙는다."""
        return self._by_token.pop(token, None) is not None


async def serve(cfg: ProxyConfig) -> None:
    """**아직 단독 기동할 수 없다.** 막힌 곳이 둘이고, 둘 다 T-0402 밖이다.

    ~~`EnvironmentStore` 구현이 없다~~ → **풀렸다** (M4 선행 작업).

    남은 것 하나: **프록시가 루트 시크릿을 모른다** (`ADR-0009`). 그런데
    지금 구조는 DB 를 직접 읽으므로 복호화가 필요하다. 제어 평면 조회
    모드가 생기면 이 모순이 사라진다.

    **둘 다 "조립"의 문제이고 판단의 문제가 아니다.** 프록시의 판단
    (`ma_egress.EgressPipeline`)과 기계(`ProxyServer`)는 전부 구현돼 있고
    `tests/integration/test_egress_proxy.py` 가 진짜 TLS 로 검증한다.

    그래서 여기서 **조용히 반쪽으로 뜨지 않는다.** 반쪽으로 뜨면 운영이
    "프록시가 돌고 있다"고 믿고, 실제로는 모든 요청이 막히거나 — 더
    나쁘게는 — 정책을 못 읽어 통과시킨다.
    """
    raise NotImplementedError(
        "egress-proxy 단독 기동은 아직 지원하지 않는다.\n"
        "  · 제어 평면 조회 모드가 없다 (ADR-0009 — 프록시는 루트 시크릿을 모른다)\n"
        "  판단과 기계는 구현·검증돼 있다 — IMPL-0021 참고."
    )


__all__ = ["InMemoryTickets", "serve"]
