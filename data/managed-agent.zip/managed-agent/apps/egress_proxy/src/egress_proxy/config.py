"""egress-proxy 설정. `config → components → serve`.

`plan/09-codebase.md` §4 · `ADR-0009`.

**루트 시크릿이 없다.** 프록시는 복호화하지 않는다 — 제어 평면에 묻고
받은 평문을 헤더에 실어 바로 버린다. 그래서 이 설정에 그 이름이 없는
것이 D5 의 한 조각이다 (`ADR-0009` — "어느 Deployment 의 env 에 그
이름이 있느냐").

> 현재 구현은 프록시가 **DB 를 직접 읽는다** (단일 노드 배포). 제어
> 평면에 HTTP 로 묻는 모드는 `SessionContextSource` Protocol 뒤에 있고,
> 바꿀 자리가 조립 한 곳이다 (`IMPL-0021`).
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field

#: 기본 수신 포트.
DEFAULT_PORT = 8888


class ConfigError(Exception):
    def __init__(self, problems: tuple[str, ...]) -> None:
        super().__init__("설정 오류 " + str(len(problems)) + "건:\n  - " + "\n  - ".join(problems))
        self.problems = problems


@dataclass(frozen=True, slots=True)
class ProxyConfig:
    database_url: str
    host: str = "0.0.0.0"  # noqa: S104 — 컨테이너 안에서 바인딩한다
    port: int = DEFAULT_PORT
    #: 나갈 수 있는 포트. **배포 설정이다** (`ma_egress.allowlist`).
    allowed_ports: frozenset[int] = field(default_factory=frozenset)
    log_level: str = "INFO"
    extra: Mapping[str, str] = field(default_factory=dict)


def load_config(env: Mapping[str, str]) -> ProxyConfig:
    """`os.environ` 을 **인자로 받는다** — 전역을 읽지 않는다."""
    from ma_egress.allowlist import ALLOWED_PORTS

    problems: list[str] = []

    database_url = env.get("AWP_DATABASE_URL", "").strip()
    if not database_url:
        problems.append("AWP_DATABASE_URL 이 필요하다")

    # **루트 시크릿이 여기 있으면 설정이 틀린 것이다.**
    # 프록시는 복호화하지 않는다 (`ADR-0009`). 있으면 배포가 제어 평면의
    # Secret 을 잘못 붙인 것이고, 그대로 두면 D5 가 조용히 약해진다.
    if env.get("AWP_CREDENTIAL_ROOT_SECRET"):
        problems.append(
            "AWP_CREDENTIAL_ROOT_SECRET 이 프록시에 있다 — "
            "프록시는 복호화하지 않는다 (ADR-0009). 배포 설정을 확인하십시오"
        )

    port = _int(env, "AWP_PROXY_PORT", DEFAULT_PORT, problems)

    ports = ALLOWED_PORTS
    raw_ports = env.get("AWP_EGRESS_ALLOWED_PORTS", "").strip()
    if raw_ports:
        parsed: set[int] = set()
        for chunk in raw_ports.split(","):
            item = chunk.strip()
            if not item.isdigit() or not 1 <= int(item) <= 65535:
                problems.append(f"AWP_EGRESS_ALLOWED_PORTS 에 잘못된 값: {item!r}")
                continue
            parsed.add(int(item))
        if parsed:
            ports = frozenset(parsed)

    level = env.get("AWP_LOG_LEVEL", "INFO").upper()
    if level not in {"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"}:
        problems.append(f"모르는 AWP_LOG_LEVEL: {level!r}")

    if problems:
        raise ConfigError(tuple(problems))

    return ProxyConfig(
        database_url=database_url,
        host=env.get("AWP_PROXY_HOST", "0.0.0.0"),  # noqa: S104
        port=port,
        allowed_ports=ports,
        log_level=level,
    )


def _int(env: Mapping[str, str], key: str, default: int, problems: list[str]) -> int:
    raw = env.get(key, str(default))
    try:
        value = int(raw)
    except ValueError:
        problems.append(f"{key} 가 정수가 아니다: {raw!r}")
        return default
    if not 1 <= value <= 65535:
        problems.append(f"{key} 가 범위를 벗어났다: {value}")
        return default
    return value


__all__ = ["DEFAULT_PORT", "ConfigError", "ProxyConfig", "load_config"]
