"""프로세스 수준 실행 — 워커 N개 + drain 감시 + 인스턴스 하트비트.

`plan/09-codebase.md` §4 · `plan/08-infrastructure.md` §3.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

import anyio
from ma_domain.ids import WorkspaceId
from ma_harness.loop import DefaultHarness

from runtime_worker.assembly import WorkerDeps, mark_instance, register_instance
from runtime_worker.components import WorkerOverrides, default_components
from runtime_worker.drain import watch_signals
from runtime_worker.worker import Worker, instance_label

if TYPE_CHECKING:
    from ma_application.blob import BlobPort

    from runtime_worker.config import WorkerConfig

_log = logging.getLogger("runtime_worker.run")

#: `worker_instances` 하트비트 주기. lease 하트비트와 **다른 것이다** —
#: 이쪽은 관측이고, 놓쳐도 실행에 영향이 없다.
INSTANCE_HEARTBEAT = 15.0


async def run_workers(cfg: WorkerConfig, overrides: WorkerOverrides | None = None) -> None:
    components = await default_components(cfg, overrides)
    hostname, pid = instance_label()

    deps = WorkerDeps(
        pool=components.pool,
        model=components.model,
        realtime=components.realtime,
        workspace_id=WorkspaceId(cfg.workspace_id) if cfg.workspace_id else None,
    )

    # **MCP 는 워커들이 공유한다.** 세션 캐시이고 lane 별로 다르지
    # 않다 — 따로 만들면 같은 세션에 `tools/list` 를 lane 수만큼 친다.
    mcp_provider = _mcp_for(cfg, components, deps)

    # **워커마다 따로 만든다.** 웜업은 세션별 기준선을 캐시하고, 그
    # 캐시를 공유하면 두 lane 이 같은 `Mounted` 를 동시에 밀어 디프가
    # 어긋난다 (T-0501).
    workers = [
        Worker(
            deps=deps,
            harness=DefaultHarness(),
            clock=components.clock,
            ids=components.ids,
            lease_ttl=cfg.lease_ttl,
            heartbeat=cfg.heartbeat,
            idle_poll=cfg.idle_poll_seconds,
            warmup=_warmup_for(cfg, components),
            # **MCP 툴 (T-0601).** 없으면 에이전트가 MCP 서버를
            # 붙여도 툴이 등록되지 않는다.
            mcp=mcp_provider,
        )
        for _ in range(cfg.concurrency)
    ]

    for w in workers:
        await register_instance(components.pool, w.worker_id, hostname, pid, components.clock.now())
    _log.info("워커 %d개 기동 host=%s pid=%s", len(workers), hostname, pid)

    try:
        async with anyio.create_task_group() as tg:
            tg.start_soon(_heartbeat_instances, components, workers)
            tg.start_soon(watch_signals, workers, cfg.drain_timeout_seconds)
            for w in workers:
                tg.start_soon(w.run_forever)
            # drain 이 끝나면 워커들이 돌아오고, 남은 보조 태스크를 접는다.
            for w in workers:
                await w.done.wait()
            tg.cancel_scope.cancel()
    finally:
        for w in workers:
            await mark_instance(components.pool, w.worker_id, "stopped", components.clock.now())
        await components.aclose()
        _log.info("워커 종료")


def _mcp_for(cfg: WorkerConfig, components: object, deps: WorkerDeps) -> object | None:
    """MCP 툴 제공자 조립 (T-0601).

    **프록시를 지나는 클라이언트를 만든다.** 여기서 평범한
    `httpx.AsyncClient()` 를 만들면 MCP 호출이 egress 프록시를
    건너뛰고, 그러면 자격증명 주입도 호스트 allowlist 도 감사도 없다.

    프록시 주소가 없으면 (개발 머신) 직통이다 — 그 경우 토큰 주입이
    없으므로 인증이 필요한 MCP 서버는 401 을 낸다. **그것이 맞다.**
    """
    import httpx

    from runtime_worker.mcp import ControlPlaneRefresh, McpToolProvider

    client = httpx.AsyncClient(
        proxy=cfg.egress_proxy_url,
        timeout=httpx.Timeout(30.0),
    )
    components._closers.append(client.aclose)  # type: ignore[attr-defined]

    refresh = None
    if cfg.control_plane_url and cfg.control_plane_api_key:
        # 갱신 호출은 **프록시를 안 지난다** — 제어 평면은 내부
        # 서비스이고, egress 프록시는 바깥으로 나가는 길이다.
        cp = httpx.AsyncClient(timeout=httpx.Timeout(30.0))
        components._closers.append(cp.aclose)  # type: ignore[attr-defined]
        refresh = ControlPlaneRefresh(
            client=cp,
            base_url=cfg.control_plane_url,
            api_key=cfg.control_plane_api_key,
        )

    return McpToolProvider(
        client=client,
        allow_mcp_for=deps.allow_mcp_for,
        refresh=refresh,
    )


def _warmup_for(cfg: WorkerConfig, components: object) -> object:
    """세션 웜업 조립 — 마운트와 `turn_stopping` 을 쥔다 (T-0501 · T-0502)."""
    from pathlib import Path

    from ma_application.files import FilesUseCases
    from ma_sql.asyncpg_client import AsyncpgClient
    from ma_store_sql.files import SqlFileStore, SqlSessionOutputStore, SqlSnapshotStore
    from ma_store_sql.memory import SqlMemoryDocumentStore, SqlMemoryStoreStore
    from ma_store_sql.skills import SqlSkillStore

    from runtime_worker.session_warmup import SessionWarmup

    sql = AsyncpgClient(components.pool)  # type: ignore[attr-defined]
    return SessionWarmup(
        root=Path(cfg.workspace_root),
        memory_stores=SqlMemoryStoreStore(sql),
        memory_docs=SqlMemoryDocumentStore(sql),
        files=FilesUseCases(
            files=SqlFileStore(sql),
            outputs=SqlSessionOutputStore(sql),
            snapshots=SqlSnapshotStore(sql),
            blob=_blob_for(cfg),
            clock=components.clock,  # type: ignore[attr-defined]
            ids=components.ids,  # type: ignore[attr-defined]
        ),
        clock=components.clock,  # type: ignore[attr-defined]
        ids=components.ids,  # type: ignore[attr-defined]
        skills=SqlSkillStore(sql),
    )


def _blob_for(cfg: WorkerConfig) -> BlobPort:
    """제어 평면의 `_blob_for` 와 **같은 규칙**이다.

    두 벌인 이유: 두 앱이 서로를 import 하지 않는다 (같은 레이어).
    어긋나면 워커가 쓴 객체를 제어 평면이 못 읽으므로,
    `tests/unit/worker/test_config.py` 가 두 기본값을 비교한다.
    """
    if cfg.blob_bucket:
        from ma_adapters_blob.s3 import S3BlobStore, client_for

        return S3BlobStore(
            bucket=cfg.blob_bucket,
            client=client_for(endpoint_url=cfg.blob_endpoint, region=cfg.blob_region),
        )

    from pathlib import Path

    from ma_adapters_blob.local import LocalBlobStore

    return LocalBlobStore(root=Path(cfg.blob_local_root))


async def _heartbeat_instances(components: object, workers: list[Worker]) -> None:
    """관측용 하트비트. **실행에 영향이 없다** — 실패해도 조용히 지나간다."""
    while True:
        await anyio.sleep(INSTANCE_HEARTBEAT)
        for w in workers:
            await mark_instance(
                components.pool,  # type: ignore[attr-defined]
                w.worker_id,
                "draining" if w.is_draining else "running",
                components.clock.now(),  # type: ignore[attr-defined]
            )


__all__ = ["INSTANCE_HEARTBEAT", "run_workers"]
