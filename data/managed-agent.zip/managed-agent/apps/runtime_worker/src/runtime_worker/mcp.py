"""워커의 MCP 툴 준비 (T-0601).

`plan/04-api.md` §6.2 · `plan/07-sandbox.md` §6 · `ADR-0009`.

워커가 하는 일은 셋이다:

1. **환경이 MCP 를 허용하는가** (`networking.allow_mcp_servers`)
2. 서버들에 `tools/list` 를 물어 `mcp__<server>__<tool>` 을 만든다
3. 401 이면 **제어 평면에 갱신을 맡기고** 한 번 재시도한다

3번이 D5 다. 워커는 갱신 토큰을 보지 않는다 — 그것으로 토큰을
**새로 만들 수 있기** 때문이다. 루트 시크릿도 제어 평면에만 있다.

> **MCP 호출은 egress 프록시를 지난다.** `client` 를 조립이 넣어
> 주고, 그 클라이언트의 proxy 설정이 그 사실을 만든다. 워커가 직접
> `httpx.AsyncClient()` 를 만들면 프록시를 건너뛰는 경로가 생기고,
> 그러면 주입도 감사도 없다.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable

    import httpx
    from ma_connectors.mcp import McpToolset
    from ma_domain.agents import AgentDefinition
    from ma_domain.ids import SessionId

_log = logging.getLogger("runtime_worker.mcp")

#: 제어 평면의 갱신 경로. **자격증명 id 가 없다.**
#:
#: 워커는 서버 이름만 알고 제어 평면이 세션의 볼트 범위 안에서 찾는다 —
#: 워커 DB 역할은 `credentials` 를 아예 못 읽으므로 id 를 알 길도 없고,
#: 알면 그것으로 할 수 있는 일이 늘어난다 (D5).
VALIDATE_PATH = "/api/v1/sessions/{session_id}/mcp/{server_name}/refresh"
#: 갱신 요청 타임아웃. **툴 호출 하나를 막고 있는 경로다.**
VALIDATE_TIMEOUT = 15.0


@dataclass(frozen=True, slots=True)
class Prepared:
    """이 세션의 MCP 상태. **왜 비었는지도 들고 있다.**"""

    toolset: McpToolset | None = None
    allowed: bool = True
    #: 못 닿은 서버. 운영자가 봐야 한다.
    unreachable: tuple[tuple[str, str], ...] = ()

    @property
    def executors(self) -> dict[str, Any]:
        return dict(self.toolset.executors) if self.toolset else {}

    @property
    def schemas(self) -> dict[str, Any]:
        return dict(self.toolset.schemas) if self.toolset else {}


@dataclass
class ControlPlaneRefresh:
    """401 → 제어 평면에 갱신을 맡긴다.

    **워커가 직접 갱신하지 않는다** (D5 · `ADR-0009`). 여기서 하는
    일은 "갱신해 달라"고 말하고 **다시 시도해도 되는지**를 듣는 것뿐이다.

    세션별로 묶어 쓴다 (`for_session`) — 제어 평면이 그 세션의 볼트
    범위 안에서만 찾기 때문이다.
    """

    client: httpx.AsyncClient
    base_url: str
    api_key: str

    def for_session(self, session_id: SessionId) -> Callable[[str], Awaitable[bool]]:
        """이 세션에 묶인 `on_unauthorized`."""

        async def refresh(server_name: str) -> bool:
            return await self.refresh(session_id, server_name)

        return refresh

    async def refresh(self, session_id: SessionId, server_name: str) -> bool:
        url = self.base_url.rstrip("/") + VALIDATE_PATH.format(
            session_id=session_id, server_name=server_name
        )
        try:
            response = await self.client.post(
                url,
                json={"force": True},
                headers={"x-api-key": self.api_key},
                timeout=VALIDATE_TIMEOUT,
            )
        except Exception as exc:
            _log.warning("MCP 갱신 요청 실패 (%s): %s", server_name, exc)
            return False

        if response.status_code != 200:
            _log.warning("MCP 갱신이 %d 로 끝났다 (%s)", response.status_code, server_name)
            return False

        body = response.json()
        if body.get("outcome") == "not_found":
            # **자격증명 없이 도는 공개 MCP 서버다.** 401 은 다른
            # 문제이고, 갱신해 봐야 고쳐지지 않는다.
            _log.info("MCP 서버 %s 에 묶인 OAuth 자격증명이 없다", server_name)
            return False
        if not body.get("retryable"):
            # **영구 실패면 재시도하지 않는다.** 계속 돌면 토큰
            # 엔드포인트를 두드리다 레이트 리밋에 걸린다.
            _log.warning("MCP 갱신 영구 실패 (%s): %s", server_name, body.get("reason"))
            return False
        return True


@dataclass
class McpToolProvider:
    """세션 하나의 MCP 툴. **세션당 한 번 묻고 캐시한다.**

    매 턴 `tools/list` 를 치면 원격 서버가 턴 수만큼 요청을 받는다 —
    그리고 그 왕복이 **첫 토큰까지의 시간**에 그대로 더해진다.
    """

    client: httpx.AsyncClient
    #: `networking.allow_mcp_servers` 를 읽는 함수. 조립이 넣는다.
    allow_mcp_for: Any
    refresh: ControlPlaneRefresh | None = None
    _cache: dict[str, Prepared] = field(default_factory=dict)

    async def prepare(self, session_id: SessionId, agent: AgentDefinition) -> Prepared:
        cached = self._cache.get(session_id)
        if cached is not None:
            return cached

        if not agent.mcp_servers:
            prepared = Prepared(allowed=True)
            self._cache[session_id] = prepared
            return prepared

        allowed = await self.allow_mcp_for(session_id)
        if not allowed:
            # **환경이 금지했다.** 툴을 하나도 등록하지 않는다 —
            # 보여 주면 모델이 열 수 없는 문을 계속 두드린다.
            _log.info("세션 %s 의 환경이 MCP 를 금지한다", session_id)
            prepared = Prepared(allowed=False)
            self._cache[session_id] = prepared
            return prepared

        from ma_connectors.mcp import build_mcp_toolset

        on_unauthorized = self.refresh.for_session(session_id) if self.refresh is not None else None
        toolset = await build_mcp_toolset(
            agent.mcp_servers, self.client, on_unauthorized=on_unauthorized
        )
        for name, why in toolset.unreachable:
            _log.warning("MCP 서버 %s: %s", name, why)
        prepared = Prepared(toolset=toolset, allowed=True, unreachable=toolset.unreachable)
        self._cache[session_id] = prepared
        return prepared

    def forget(self, session_id: SessionId) -> None:
        """세션이 끝났다. **안 비우면 긴 워커가 계속 쥐고 있는다.**"""
        self._cache.pop(session_id, None)


__all__ = [
    "VALIDATE_PATH",
    "VALIDATE_TIMEOUT",
    "ControlPlaneRefresh",
    "McpToolProvider",
    "Prepared",
]
