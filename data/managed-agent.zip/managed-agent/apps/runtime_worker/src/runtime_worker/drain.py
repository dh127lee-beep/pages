"""우아한 종료 — drain.

`plan/08-infrastructure.md` §3 · `ADR-0003`.

```
SIGTERM  →  drain 시작       새 claim 중지. 진행 중인 턴은 완주
         →  진행 중 0        프로세스 종료
         →  유예 초과        k8s 가 SIGKILL → lease 만료 경로로 복구
```

**두 경로 모두 정상이다.** drain 은 흔한 경우(배포·스케일인)를 빠르게 끝내고,
lease 만료는 드문 경우(크래시·노드 소실)를 덮는다. drain 이 실패해도 데이터는
안전하다 — 그것이 D3 를 둔 이유다.
"""

from __future__ import annotations

import logging
import signal
from collections.abc import Sequence
from typing import TYPE_CHECKING

import anyio

if TYPE_CHECKING:
    from runtime_worker.worker import Worker

_log = logging.getLogger("runtime_worker.drain")


async def watch_signals(workers: Sequence[Worker], grace_seconds: float) -> None:
    """SIGTERM·SIGINT 를 기다렸다가 drain 한다.

    **유예를 넘기면 그냥 돌아온다.** 여기서 강제로 죽이지 않는다 — k8s 가
    SIGKILL 을 보낼 것이고, 그 경로가 lease 만료로 이미 덮여 있다. 우리가
    먼저 죽이면 "진행 중인 턴을 우리가 버렸다"가 되어 복구 경로가 하나 더
    늘어난다.
    """
    with anyio.open_signal_receiver(signal.SIGTERM, signal.SIGINT) as signals:
        async for sig in signals:
            _log.info("%s 수신 — drain 시작", signal.Signals(sig).name)
            for w in workers:
                w.drain()
            await wait_drained(workers, grace_seconds)
            return


async def wait_drained(workers: Sequence[Worker], grace_seconds: float) -> bool:
    """워커 루프가 전부 돌아오기를 기다린다. 끝났으면 True.

    **폴링하지 않는다** — 각 워커가 `done` 이벤트를 세운다.
    """
    with anyio.move_on_after(grace_seconds) as scope:
        for w in workers:
            await w.done.wait()
    if scope.cancel_called:
        busy = sum(1 for w in workers if w.is_busy)
        _log.warning(
            "drain 유예 %.0fs 초과 — %d개가 아직 돌고 있다. SIGKILL 후 lease 만료로 복구된다",
            grace_seconds,
            busy,
        )
        return False
    _log.info("drain 완료 — 진행 중인 턴 없음")
    return True


__all__ = ["wait_drained", "watch_signals"]
