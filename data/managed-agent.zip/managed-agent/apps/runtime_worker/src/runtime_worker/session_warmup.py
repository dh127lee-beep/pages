"""세션 웜업 — 워크스페이스를 채우고 `turn_stopping` 을 건다.

`plan/02-architecture.md` §9 · `plan/08-infrastructure.md` §6 ·
`T-0501` · `T-0502`.

**이 파일이 T-0501 과 T-0502 가 만나는 자리다.** 둘 다 "세션이 시작할 때
무언가를 마운트하고 턴이 끝날 때 되돌린다"이고, 마운트할 디렉터리가
생기는 곳이 여기다.

```
웜업                                   턴 종료 (turn_stopping, idle 직전)
────                                  ──────────────────────────────────
스냅샷 복원                             ① 메모리 디프 → fence 재검증 → CAS
memories  → /mnt/memory/<slug>  (rw)    ② outputs/ → 수거
files     → /mnt/files/<name>   (ro)    ③ 워크스페이스 → 스냅샷
skills    → /mnt/skills/<slug>  (ro)    (스킬은 되돌리지 않는다)
```

**훅 순서가 의미를 갖는다.** 메모리가 먼저다 — 셋 중 가장 중요하고
(다음 세션이 읽는다), `SerialHooks` 는 앞이 터져도 뒤를 돌리지만 그
반대는 "스냅샷은 됐는데 메모리가 안 됐다"를 만든다. 스냅샷이 마지막인
이유는 그것이 **앞 둘의 결과까지 담아야** 하기 때문이다.

워커는 이 모듈을 **호출만 한다** — `Worker` 는 무엇이 마운트되는지
모른다. 그래야 크래시 테스트가 웜업 없이 돌 수 있다.
"""

from __future__ import annotations

import logging
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any

from ma_harness.hooks import HookSet
from ma_harness.memory_sync import MemorySync, Mounted, materialize
from ma_harness.memory_sync import install as install_memory_sync
from ma_store._results import ListQuery

if TYPE_CHECKING:
    from ma_application.files import FilesUseCases
    from ma_domain.agents import AgentDefinition
    from ma_domain.clock import Clock, IdGenerator
    from ma_domain.executions import ExecutionFence
    from ma_domain.skills import MountedSkill
    from ma_harness.file_mount import MountedFile
    from ma_store.memory import MemoryDocumentStore, MemoryStoreStore
    from ma_store.skills import SkillStore

    from runtime_worker.workspace import SessionWorkspace

_log = logging.getLogger("runtime_worker.session_warmup")

#: 한 세션에 마운트할 메모리 스토어 수 상한.
MAX_STORES = 20

#: 마운트할 업로드 파일 수 상한.
MAX_FILES = 200


@dataclass(frozen=True, slots=True)
class WarmSession:
    """웜업 결과. **프롬프트 접두사가 여기서 나온다** (D12b)."""

    workspace: SessionWorkspace
    hooks: HookSet
    memory_mounts: tuple[Mounted, ...] = ()
    file_mounts: tuple[MountedFile, ...] = ()
    skill_mounts: tuple[MountedSkill, ...] = ()
    #: 스킬 카탈로그. **프롬프트 접두사에 인라인된다** (D12b).
    skill_catalog: str = ""
    restored_files: int = 0

    def prompt_hint(self) -> str:
        """마운트 안내. **매 턴 같은 문자열이어야 한다** — 캐시 접두사다."""
        from ma_harness.file_mount import prompt_hint as files_hint
        from ma_harness.memory_sync import prompt_hint as memory_hint

        # **순서가 고정이다.** 섞이면 접두사가 흔들리고 캐시가 miss 다.
        parts = [
            self.skill_catalog,
            memory_hint(self.memory_mounts),
            files_hint(self.file_mounts),
        ]
        return "\n\n".join(p for p in parts if p)


@dataclass
class SessionWarmup:
    """세션 하나를 준비한다. 워커가 턴 직전에 부른다.

    Store 와 유스케이스를 **조립이 넣어 준다** — 이 모듈이 DB 를 직접
    열면 테스트가 DB 없이 돌 수 없다.
    """

    root: Path
    memory_stores: MemoryStoreStore
    memory_docs: MemoryDocumentStore
    files: FilesUseCases
    clock: Clock
    ids: IdGenerator
    #: 스킬 스토어. 없으면 스킬을 마운트하지 않는다 — **스킬 없이도
    #: 세션은 돈다** (M5 는 켜지 않아도 MVP 가 동작한다).
    skills: SkillStore | None = None
    #: 스냅샷을 쓸 것인가. 끄면 워크스페이스가 턴마다 빈 채로 시작한다.
    snapshots: bool = True
    #: 조립이 넣는 fence 검증. 없으면 항상 통과한다 (개발·테스트).
    fence_check: Callable[[Any], Awaitable[bool]] | None = None
    _warmed: dict[str, WarmSession] = field(default_factory=dict)

    async def warm(
        self, fence: ExecutionFence, agent: AgentDefinition | None = None
    ) -> WarmSession:
        """**세션당 한 번.** 같은 세션의 두 번째 턴은 캐시를 쓴다.

        두 번 돌리면 디프의 기준선이 턴 중간에 새로 잡히고, 그러면 그
        턴에 에이전트가 쓴 것이 "바뀐 것이 없다"로 보인다.
        """
        scope = fence.scope
        cached = self._warmed.get(scope.session_id)
        if cached is not None:
            return cached

        from runtime_worker.workspace import provision

        workspace = await provision(self.root, scope.session_id)
        restored = await self._restore(workspace, scope)
        memory_mounts = await self._mount_memory(workspace, scope)
        file_mounts = await self._mount_files(workspace, scope)
        skill_mounts, catalog = await self._mount_skills(workspace, scope, agent)

        hooks = HookSet()
        self._install_hooks(hooks, workspace, scope, memory_mounts)

        warm = WarmSession(
            workspace=workspace,
            hooks=hooks,
            memory_mounts=memory_mounts,
            file_mounts=file_mounts,
            skill_mounts=skill_mounts,
            skill_catalog=catalog,
            restored_files=restored,
        )
        self._warmed[scope.session_id] = warm
        return warm

    def forget(self, session_id: str) -> None:
        """세션이 끝났다. **캐시를 비운다** — 안 비우면 워커가 도는 동안
        모든 세션의 기준선이 메모리에 쌓인다."""
        self._warmed.pop(session_id, None)

    # ── 웜업 단계 ────────────────────────────────────────
    async def _restore(self, workspace: SessionWorkspace, scope: Any) -> int:
        if not self.snapshots:
            return 0
        from runtime_worker.snapshot import UnsafeArchive, unpack_async

        archive = await self.files.restore_snapshot(scope.workspace_id, scope.session_id)
        if archive is None:
            return 0
        try:
            return await unpack_async(archive, workspace.root)
        except (UnsafeArchive, OSError, ValueError) as exc:
            # **세션을 깨뜨리지 않는다.** 복원 실패는 "중간 파일이
            # 없다"일 뿐이고, 진실(DB + 오브젝트 스토어)은 멀쩡하다.
            _log.warning(
                "스냅샷 복원 실패 — 빈 워크스페이스로 간다 session=%s: %s",
                scope.session_id,
                exc,
            )
            return 0

    async def _mount_memory(self, workspace: SessionWorkspace, scope: Any) -> tuple[Mounted, ...]:
        page = await self.memory_stores.list_stores(
            ListQuery(workspace_id=scope.workspace_id, limit=MAX_STORES)
        )
        mounts: list[Mounted] = []
        for store in page.items:
            mounts.append(
                await materialize(
                    self.memory_docs,
                    workspace_id=scope.workspace_id,
                    store_id=store.id,
                    slug=store.slug,
                    mount_path=store.mount_path,
                    # **쓰기 가능하다** — 턴 종료에 CAS 로 되돌린다 (D10).
                    writable=True,
                    write_file=workspace.write_text,
                )
            )
        return tuple(mounts)

    async def _mount_files(
        self, workspace: SessionWorkspace, scope: Any
    ) -> tuple[MountedFile, ...]:
        from ma_harness.file_mount import mount_uploads

        page = await self.files.list_files(scope.workspace_id, limit=MAX_FILES)
        return await mount_uploads(
            page.items,
            read_blob=self.files.blob.get,
            write_file=workspace.write_bytes,
        )

    async def _mount_skills(
        self, workspace: SessionWorkspace, scope: Any, agent: AgentDefinition | None
    ) -> tuple[tuple[MountedSkill, ...], str]:
        """에이전트가 **부착한 것만** 마운트한다.

        워크스페이스의 모든 스킬을 붙이면 카탈로그가 부서 전체 목록이
        되고, 프롬프트가 스킬 수에 비례해 늘어난다 — 점진적 공개의
        반대다.
        """
        if self.skills is None or agent is None or not agent.skills:
            return (), ""

        from ma_harness.skills_mount import catalog_for, mount_skills

        records = await self.skills.find_many(scope.workspace_id, tuple(agent.skills))
        mounts = await mount_skills(records, write_file=workspace.write_text)
        return mounts, catalog_for(records)

    # ── 훅 ───────────────────────────────────────────────
    def _install_hooks(
        self,
        hooks: HookSet,
        workspace: SessionWorkspace,
        scope: Any,
        memory_mounts: tuple[Mounted, ...],
    ) -> None:
        """**순서대로 건다**: 메모리 → 산출물 → 스냅샷."""
        from ma_harness.file_mount import OutputCollector
        from ma_harness.file_mount import install as install_outputs

        install_memory_sync(
            hooks,
            MemorySync(
                docs=self.memory_docs,
                workspace_id=scope.workspace_id,
                session_id=scope.session_id,
                # **fence 를 쓰기 직전에 다시 본다** — 디프를 계산하는
                # 동안 소유권이 넘어갔을 수 있다 (D3).
                fence_ok=lambda: self._fence_ok(scope),
                now=self.clock.now,
                next_id=lambda: self.ids.next("memory"),
            ),
            memory_mounts,
            # `Mounted` → 마운트 경로. `install` 의 계약은 마운트를
            # 받지만 워크스페이스는 경로만 알면 된다.
            lambda m: workspace.read_mount(m.mount_path),
        )

        async def record(path: str, content: bytes, generation: int) -> None:
            from ma_application.files import RecordOutput

            await self.files.record_output(
                RecordOutput(
                    workspace_id=scope.workspace_id,
                    session_id=scope.session_id,
                    path=path,
                    content=content,
                    generation=generation,
                )
            )

        install_outputs(
            hooks,
            OutputCollector(
                workspace_id=scope.workspace_id,
                session_id=scope.session_id,
                list_dir=workspace.list_dir,
                read_file=workspace.read_bytes,
                record=record,
            ),
        )

        if self.snapshots:
            hooks.turn_stopping.add(self._snapshotter(workspace, scope))

    def _snapshotter(self, workspace: SessionWorkspace, scope: Any) -> Any:
        from ma_application.files import SaveSnapshot, SnapshotRefused

        from runtime_worker.snapshot import pack_async

        async def save(payload: Any) -> None:
            archive = await pack_async(workspace.root)
            res = await self.files.save_snapshot(
                SaveSnapshot(
                    workspace_id=scope.workspace_id,
                    session_id=scope.session_id,
                    generation=payload.fence.generation,
                    archive=archive,
                )
            )
            if isinstance(res, SnapshotRefused):
                # **좀비일 수 있다.** 같은 세대를 두 워커가 쓰려 했다.
                _log.warning(
                    "같은 세대의 스냅샷이 이미 있다 session=%s gen=%d",
                    scope.session_id,
                    res.generation,
                )

        return save

    async def _fence_ok(self, scope: Any) -> bool:
        """**지금도 우리가 소유자인가.**

        기본 구현은 항상 True 다 — 실제 검증은 `HarnessRuntime` 이
        `append` 에서 하고, 동기화는 Store 를 직접 부르므로 그 경로를
        타지 않는다. 조립이 `fence_check` 를 주입해 덮는다.
        """
        if self.fence_check is None:
            return True
        return bool(await self.fence_check(scope))


__all__ = ["MAX_FILES", "MAX_STORES", "SessionWarmup", "WarmSession"]
