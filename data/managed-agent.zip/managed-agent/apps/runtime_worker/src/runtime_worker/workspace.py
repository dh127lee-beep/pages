"""세션 워크스페이스 — **영속 상태가 아니다** (`plan/08` §6).

`plan/08-infrastructure.md` §6 · `ADR-0008` ·
`task/M4-productization/T-0502-files-outputs.md`.

k8s 에서는 `emptyDir` 이고 개발 머신에서는 설정된 루트 아래 디렉터리다.
어느 쪽이든 **진실은 DB + 오브젝트 스토어에 있고** 여기는 사본이다:

```
세션 웜업                              턴 종료
─────────                             ───────
memories    → /mnt/memory/<slug>  (rw)   디프 → CAS write
files       → /mnt/files/<name>   (ro)   —
스냅샷      → 워크스페이스 복원           outputs/ → 수거
```

**경로 해석은 `ma_sandbox.paths` 만 쓴다** (`ADR-0008`). 이 모듈은 그것을
감싸 비동기 `read`/`write`/`list` 로 바꿀 뿐이고, 판정 로직이 하나도
없다 — 두 벌이 되는 순간 둘 중 느슨한 쪽이 실질 경계가 된다.

마운트 경로(`/mnt/...`)는 **워크스페이스 루트 기준 상대 경로로 접는다.**
개발 머신에 진짜 `/mnt` 를 만들 수는 없고, 샌드박스 안에서 보이는 이름과
호스트의 위치는 원래 다른 것이다.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from pathlib import Path

import anyio
from ma_sandbox.paths import PathEscape, resolve_in_workspace

_log = logging.getLogger("runtime_worker.workspace")

#: 샌드박스에서 보이는 마운트 접두사 → 워크스페이스 루트 아래의 자리.
#:
#: `/mnt/memory/legal` 은 호스트에서 `<root>/.mnt/memory/legal` 이다.
#: 점으로 시작하는 이유: 에이전트가 `glob` 로 작업 파일을 훑을 때 마운트
#: 사본이 섞이지 않게 한다.
MOUNT_PREFIX = "/mnt/"
MOUNT_DIR = ".mnt"


class OutsideWorkspace(Exception):
    """경계 밖. **워커를 죽이지 않는다** — 호출자가 건너뛴다."""


def to_relative(path: str) -> str:
    """`/mnt/memory/legal/a.md` → `.mnt/memory/legal/a.md`.

    마운트가 아닌 절대 경로는 **거부한다** — 워크스페이스 밖이다.
    """
    if path.startswith(MOUNT_PREFIX):
        return f"{MOUNT_DIR}/{path[len(MOUNT_PREFIX) :]}"
    if path.startswith("/"):
        raise OutsideWorkspace(f"워크스페이스 밖 절대 경로: {path!r}")
    return path


@dataclass
class SessionWorkspace:
    """한 세션의 디렉터리. **모든 파일 접근이 여기를 지난다.**"""

    root: Path

    def _resolve(self, path: str) -> Path:
        try:
            return resolve_in_workspace(self.root, to_relative(path))
        except PathEscape as exc:
            # 이유를 로그로만 남긴다 — 호출자에게 자세히 주면 탐색을 돕는다.
            _log.warning("워크스페이스 경계 밖 path=%r reason=%s", path, exc.reason)
            raise OutsideWorkspace(path) from exc

    async def write_bytes(self, path: str, content: bytes) -> None:
        target = self._resolve(path)
        await anyio.to_thread.run_sync(lambda: target.parent.mkdir(parents=True, exist_ok=True))
        await anyio.to_thread.run_sync(target.write_bytes, content)

    async def write_text(self, path: str, content: str) -> None:
        await self.write_bytes(path, content.encode("utf-8"))

    async def read_bytes(self, path: str) -> bytes:
        return await anyio.to_thread.run_sync(self._resolve(path).read_bytes)

    async def read_text(self, path: str) -> str:
        """**깨진 UTF-8 을 바꿔 넣는다** (`errors="replace"`).

        에이전트가 메모리 디렉터리에 바이너리를 쓸 수 있고, 거기서
        `UnicodeDecodeError` 가 나면 **턴 종료 동기화 전체가 멈춘다** —
        그 파일 하나 때문에 나머지 메모가 저장되지 않는다.
        """
        raw = await self.read_bytes(path)
        return raw.decode("utf-8", errors="replace")

    async def list_dir(self, prefix: str) -> tuple[str, ...]:
        """`prefix` 아래 **파일만**, 워크스페이스 기준 상대 경로로.

        심링크가 밖을 가리키면 `resolve_in_workspace` 가 잡는다 — 여기서
        다시 판정하지 않고 **한 번 더 통과시켜** 거른다.
        """
        base = self._resolve(prefix)

        def _walk() -> list[str]:
            if not base.is_dir():
                return []
            out: list[str] = []
            for p in sorted(base.rglob("*")):
                if not p.is_file():
                    continue
                try:
                    relative = str(p.relative_to(self.root.resolve(strict=True)))
                except (OSError, ValueError):  # pragma: no cover
                    continue
                out.append(relative)
            return out

        found = await anyio.to_thread.run_sync(_walk)
        kept: list[str] = []
        for relative in found:
            try:
                self._resolve(relative)
            except OutsideWorkspace:
                # 심링크가 밖을 가리킨다 — 수거하면 호스트 파일이 나간다.
                continue
            kept.append(relative)
        return tuple(kept)

    async def read_mount(self, mount_path: str) -> dict[str, str]:
        """마운트 디렉터리 전체를 `상대경로 → 내용` 으로.

        메모리 동기화의 디프가 이것을 받는다 (`memory_sync.diff`).
        """
        prefix = to_relative(mount_path)
        out: dict[str, str] = {}
        for relative in await self.list_dir(mount_path):
            # `.mnt/memory/legal/a.md` → `a.md`
            out[relative[len(prefix) + 1 :]] = await self.read_text(relative)
        return out


async def provision(root: Path, session_id: str) -> SessionWorkspace:
    """세션 디렉터리를 만든다.

    `resolve_in_workspace` 가 **루트의 존재를 요구하므로**(`strict=True`)
    여기서 먼저 만든다. 없는 루트를 기준으로 검사하면 `is_relative_to`
    가 의미 없는 문자열 비교가 된다.
    """
    target = root / session_id
    await anyio.to_thread.run_sync(lambda: target.mkdir(parents=True, exist_ok=True))
    return SessionWorkspace(root=target)


__all__ = [
    "MOUNT_DIR",
    "MOUNT_PREFIX",
    "OutsideWorkspace",
    "SessionWorkspace",
    "provision",
    "to_relative",
]
