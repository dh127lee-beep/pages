"""워커 루프 — claim → 호스팅 → settle.

`plan/02-architecture.md` §3 §8 · `plan/08-infrastructure.md` §3.

**워커는 "실행을 가진 주체"가 아니다.** claim 한 lane 의 호스트일 뿐이고,
권한은 DB 에 있다 (D3). 그래서 이 루프에 상태가 거의 없다 — 죽으면 lease 가
만료되고 다른 워커가 이어받는다.

세 가지가 이 파일의 전부다.

1. **claim 폴링.** 알림(`LISTEN/NOTIFY`)은 지연을 줄이는 최적화이고, 폴링이
   정확성을 책임진다. 알림을 전부 놓쳐도 폴링 주기 안에 집는다 (`IMPL-0012`).
2. **drain.** 새 claim 을 멈추고 진행 중인 것만 끝낸 뒤 종료한다.
3. **settle 은 호스트가 한다.** 워커는 결과를 상태로 번역할 뿐이다.
"""

from __future__ import annotations

import logging
import os
import socket
from dataclasses import dataclass, field
from datetime import timedelta
from typing import TYPE_CHECKING, Any
from uuid import uuid4

import anyio
from ma_domain.executions import (
    DEFAULT_HEARTBEAT,
    DEFAULT_LEASE_TTL,
    ExecutionFenceLost,
    ExecutionState,
)
from ma_domain.ids import WorkerId
from ma_domain.sessions import StopReason
from ma_harness.execution_host import SessionExecutionHost, TurnContext
from ma_harness.hooks import HookSet
from ma_harness.ports import HarnessContext
from ma_harness.registry import build_tools
from ma_store.executions import ClaimExecution

if TYPE_CHECKING:
    from ma_domain.clock import Clock, IdGenerator
    from ma_domain.executions import ExecutionRecord, ExecutionScope
    from ma_harness.ports import Harness

_log = logging.getLogger("runtime_worker")

#: 할 일이 없을 때의 폴링 주기. 근거는 `IMPL-0012`.
IDLE_POLL = 1.0

#: `stop_reason` → execution 최종 상태. **정상 완료는 `completed` 다.**
_SETTLE: dict[StopReason, ExecutionState] = {
    StopReason.END_TURN: ExecutionState.COMPLETED,
    StopReason.REQUIRES_ACTION: ExecutionState.COMPLETED,
    StopReason.MAX_TOKENS: ExecutionState.COMPLETED,
    StopReason.BUDGET_REACHED: ExecutionState.COMPLETED,
    StopReason.INTERRUPTED: ExecutionState.CANCELLED,
    StopReason.ERROR: ExecutionState.FAILED,
}


@dataclass
class WorkerStats:
    claimed: int = 0
    completed: int = 0
    failed: int = 0
    fence_lost: int = 0


@dataclass
class Worker:
    """claim 루프 하나. 프로세스당 여러 개를 돌릴 수 있다."""

    deps: object  # WorkerDeps — 순환 import 를 피해 느슨하게 받는다
    harness: Harness
    clock: Clock
    ids: IdGenerator
    worker_id: WorkerId = field(default_factory=lambda: WorkerId(f"wkr_{uuid4().hex[:12]}"))
    lease_ttl: timedelta = DEFAULT_LEASE_TTL
    heartbeat: timedelta = DEFAULT_HEARTBEAT
    idle_poll: float = IDLE_POLL
    #: 세션 웜업 (`SessionWarmup`). **없으면 마운트도 훅도 없다** —
    #: 크래시·동시성 테스트가 워크스페이스 없이 돌 수 있어야 한다.
    warmup: Any = None
    #: `ma_observability.Metrics`. 없으면 **아무것도 세지 않는다** —
    #: 관측이 없어도 턴은 돌아야 한다.
    metrics: Any = None
    #: `runtime_worker.mcp.McpToolProvider`. **없으면 MCP 툴이
    #: 등록되지 않는다** — 에이전트가 MCP 서버를 붙여도 돌지 않는다
    #: (T-0601). 조립이 프록시를 지나는 클라이언트와 함께 꽂는다.
    mcp: Any = None
    stats: WorkerStats = field(default_factory=WorkerStats)

    #: `drain()` 이 세운다. 새 claim 을 멈추되 진행 중인 것은 끝낸다.
    _draining: bool = False
    _busy: bool = False
    #: drain 신호. 유휴 대기 중이면 즉시 깨운다.
    _drain_signal: anyio.Event = field(default_factory=anyio.Event)
    #: 루프가 돌아왔다. `drain.py` 가 이것을 기다린다 — 폴링하지 않는다.
    done: anyio.Event = field(default_factory=anyio.Event)

    @property
    def is_draining(self) -> bool:
        return self._draining

    @property
    def is_busy(self) -> bool:
        return self._busy

    def drain(self) -> None:
        """**새 claim 만 멈춘다.** 진행 중인 턴은 완주한다.

        k8s 가 SIGTERM 을 보내고 `terminationGracePeriodSeconds` 를 기다리는
        동안 이것이 돈다. 유예를 넘기면 SIGKILL 이고, 그때는 lease 만료
        경로로 복구된다 — **두 경로 모두 테스트한다** (T-0207).
        """
        self._draining = True
        self._drain_signal.set()

    async def run_forever(self) -> None:
        """drain 되고 진행 중인 것이 끝나면 돌아온다."""
        try:
            while not self._draining:
                if await self.run_once():
                    continue
                # 할 일이 없다 — 폴링 주기만큼 쉬되 **drain 신호에 즉시 깨어난다**.
                with anyio.move_on_after(self.idle_poll):
                    await self._drain_signal.wait()
        finally:
            _log.info("worker %s 루프 종료", self.worker_id)
            self.done.set()

    async def run_once(self) -> bool:
        """하나 집어서 돌린다. 집을 것이 없으면 False.

        **drain 중이면 집지 않는다.**
        """
        if self._draining:
            return False

        deps = self.deps
        claimed = await deps.executions.claim(  # type: ignore[attr-defined]
            ClaimExecution(
                owner=self.worker_id,
                now=self.clock.now(),
                lease_ttl=self.lease_ttl,
                attempt_id=uuid4(),
                workspace_id=deps.workspace_id,  # type: ignore[attr-defined]
            )
        )
        if claimed is None:
            return False

        self.stats.claimed += 1
        if self.metrics is not None:
            # queued → running 까지의 지연. **큐 대시보드의 핵심 패널이다.**
            delay = (self.clock.now() - claimed.execution.created_at).total_seconds()
            self.metrics.claimed(
                claimed.execution.scope.workspace_id, delay_seconds=max(delay, 0.0)
            )
        self._busy = True
        try:
            await self._host(claimed.execution, claimed.fence)
        finally:
            self._busy = False
        return True

    async def _host(self, execution: ExecutionRecord, fence: object) -> None:
        deps = self.deps
        host = SessionExecutionHost(
            deps.executions,  # type: ignore[attr-defined]
            self.clock,
            self.worker_id,
            lease_ttl=self.lease_ttl,
            heartbeat=self.heartbeat,
        )

        seen: dict[str, object] = {}

        async def body(ctx: TurnContext) -> ExecutionState:
            """**settle 할 상태를 돌려준다.** 호스트가 그것으로 한 번만 settle 한다."""
            started = self.clock.now()
            result = await self._run_turn(ctx, execution.scope)
            seen["duration"] = (self.clock.now() - started).total_seconds()
            stop = getattr(result, "stop_reason", None)
            seen["stop_reason"] = stop.value if stop else "없음"
            seen["steps"] = getattr(result, "steps", 0)
            if stop is None:  # pragma: no cover — 하네스는 항상 stop_reason 을 준다
                return ExecutionState.FAILED
            return _SETTLE.get(stop, ExecutionState.COMPLETED)

        try:
            turn = await host.host(execution, fence, body)  # type: ignore[arg-type]
        except ExecutionFenceLost:
            # 소유권을 잃었다. **아무것도 쓰지 않는다** — 다음 워커의 턴이다.
            self.stats.fence_lost += 1
            # **lease 만료 알람이 보는 숫자다.** 여기서 안 올리면
            # "워커가 죽고 있다"를 아무도 모른다.
            self._count_lease_lost(execution)
            _log.warning(
                "worker %s fence 상실 execution=%s", self.worker_id, execution.execution_id
            )
            return

        if turn.fence_lost or not turn.settled:
            self.stats.fence_lost += 1
            self._count_lease_lost(execution)
            return
        if turn.state is ExecutionState.FAILED:
            self.stats.failed += 1
        else:
            self.stats.completed += 1

        if self.metrics is not None and turn.state is not None:
            ws = execution.scope.workspace_id
            self.metrics.settled(ws, state=turn.state.value)
            self.metrics.turn_finished(
                ws,
                stop_reason=str(seen.get("stop_reason", "없음")),
                seconds=float(seen.get("duration", 0.0)),  # type: ignore[arg-type]
                errored=turn.state is ExecutionState.FAILED,
            )

        _log.info(
            "turn done worker=%s execution=%s state=%s stop_reason=%s steps=%s",
            self.worker_id,
            execution.execution_id,
            turn.state.value if turn.state else "없음",
            seen.get("stop_reason", "없음"),
            seen.get("steps", 0),
        )

    def _count_lease_lost(self, execution: ExecutionRecord) -> None:
        if self.metrics is not None:
            self.metrics.lease_expired(execution.scope.workspace_id)

    async def _run_turn(self, ctx: TurnContext, scope: ExecutionScope) -> object:
        """fence 를 쥔 상태에서 하네스를 돌린다.

        **제어 평면의 trace 를 이어받는다** — outbox 행에 실려 온
        `traceparent` 로 span 을 연다. 비어 있으면 새 trace 다 (워커가
        "앞이 없다"고 멈추면 큐가 밀린다).
        """
        from ma_observability.trace import restore

        with restore(
            dict(ctx.execution.trace_context),
            "worker.turn",
            **{
                "awp.session_id": scope.session_id,
                "awp.lane_id": scope.lane_id,
                "awp.generation": ctx.fence.generation,
            },
        ):
            return await self._hosted_turn(ctx, scope)

    async def _hosted_turn(self, ctx: TurnContext, scope: ExecutionScope) -> object:
        deps = self.deps
        resolved = await deps.resolve_model(scope.session_id)  # type: ignore[attr-defined]
        agent = await deps.load_agent(scope.session_id)  # type: ignore[attr-defined]

        from ma_application.models import is_peak

        from runtime_worker.runtime import SqlHarnessRuntime

        runtime = SqlHarnessRuntime(
            events=deps.events,  # type: ignore[attr-defined]
            pending=deps.pending,  # type: ignore[attr-defined]
            executions=deps.executions,  # type: ignore[attr-defined]
            sessions=deps.sessions,  # type: ignore[attr-defined]
            realtime=deps.realtime,  # type: ignore[attr-defined]
            execution_id=ctx.execution.execution_id,
            # **집계 행을 쓴다.** 없으면 비용 대시보드가 빈 채로 돈다
            # (T-0504 — 이 구멍을 거기서 발견했다).
            usage=deps.usage,  # type: ignore[attr-defined]
            model_card_id=resolved.card.id,
            wire_model=resolved.card.wire_model,
            agent_id=agent_id_of(ctx.execution),
            # **지금 판단해서 박는다.** peak 창이 바뀌어도 과거 집계가
            # 소급해 재해석되지 않는다 (`list_cost_cents` 와 같은 이유).
            off_peak=not is_peak(resolved.card, self.clock.now()),
            metrics=self.metrics,
        )

        # **웜업은 턴 직전에 돈다.** 세션당 한 번이고, 두 번째 턴은
        # 캐시를 쓴다 — 매 턴 기준선을 새로 잡으면 그 턴에 에이전트가
        # 쓴 것이 "바뀐 것이 없다"로 보인다 (T-0501).
        # **MCP 툴을 준비한다.** 환경이 금지하면 하나도 안 꽂힌다.
        mcp_executors: dict[str, Any] = {}
        mcp_schemas: dict[str, Any] = {}
        allow_mcp = True
        if self.mcp is not None:
            prepared = await self.mcp.prepare(scope.session_id, agent)
            mcp_executors = prepared.executors
            mcp_schemas = prepared.schemas
            allow_mcp = prepared.allowed

        hooks = HookSet()
        if self.warmup is not None:
            # **에이전트를 넘긴다** — 부착한 스킬만 마운트한다 (T-0602).
            warm = await self.warmup.warm(ctx.fence, agent)
            hooks = warm.hooks

        return await self.harness.run(
            HarnessContext(
                fence=ctx.fence,
                agent=agent,
                card=resolved.card,
                model=deps.model,  # type: ignore[attr-defined]
                tools=build_tools(
                    agent,
                    # **실행기를 꽂지 않으면 MCP 툴이 영영 승인 대기다.**
                    executors=mcp_executors,
                    schemas=mcp_schemas,
                    allow_mcp=allow_mcp,
                ),
                runtime=runtime,
                hooks=hooks,
                clock=self.clock,
                ids=self.ids,
                effort=resolved.effort,
            )
        )


def agent_id_of(execution: object) -> str | None:
    """실행 행에서 에이전트 id. **없으면 None 이다** — 집계가 그 행을
    "에이전트 불명"으로 세고, 그것이 사실이다."""
    return getattr(execution, "agent_id", None)


def instance_label() -> tuple[str, int]:
    """`worker_instances` 에 남길 식별. **권한이 아니라 관측이다.**"""
    return socket.gethostname(), os.getpid()


__all__ = ["IDLE_POLL", "Worker", "WorkerStats", "instance_label"]
