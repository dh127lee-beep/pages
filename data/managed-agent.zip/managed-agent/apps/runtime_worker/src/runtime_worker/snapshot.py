"""워크스페이스 스냅샷 — `tar.zst` (`plan/08` §6).

`plan/08-infrastructure.md` §6 · `task/M4-productization/T-0502-files-outputs.md`.

**`emptyDir` 은 Pod 와 함께 사라진다.** 진실은 DB + 오브젝트 스토어에
있고, 워크스페이스는 사본이다 — 그래도 에이전트가 턴 사이에 만든 중간
파일(압축 해제한 자료, 빌드 산출물)은 어디에도 없다. 스냅샷이 그것을
잇는다.

> **키에 generation 이 들어간다** (`ma_domain.files.snapshot_key`).
> 같은 세션의 두 세대가 같은 키를 쓰면 좀비 워커가 새 소유자의 스냅샷을
> 덮고, 복원하면 **옛날 워크스페이스가 돌아온다** (D3).

압축을 푸는 쪽이 위험하다. tar 는 `../` 과 절대 경로와 심링크를 담을 수
있고, 그대로 풀면 호스트 어디에나 쓸 수 있다 — 우리가 만든 아카이브만
푼다는 가정에 기대지 않고 **경계를 다시 본다.**
"""

from __future__ import annotations

import io
import logging
import tarfile
from pathlib import Path

import anyio
import zstandard
from ma_sandbox.paths import PathEscape, resolve_in_workspace

_log = logging.getLogger("runtime_worker.snapshot")

#: 압축 수준. 3 은 zstd 기본값이고, 워크스페이스는 대개 텍스트라
#: 더 올려도 이득이 작고 턴 종료 지연만 늘어난다.
LEVEL = 3

#: 압축 해제 상한. **압축 폭탄 방어** — 4KB 가 10GB 로 펴질 수 있다.
MAX_UNPACKED_BYTES = 2 * 1024 * 1024 * 1024

#: 아카이브에 담을 파일 수 상한.
MAX_MEMBERS = 50_000


class UnsafeArchive(Exception):
    """아카이브가 워크스페이스 밖을 가리킨다."""


def pack(root: Path) -> bytes:
    """워크스페이스를 `tar.zst` 로. **심링크는 따라가지 않는다.**

    따라가면 워크스페이스 안의 심링크가 가리키는 **호스트 파일**이
    아카이브에 담기고, 그것이 오브젝트 스토어로 나간다.
    """
    buffer = io.BytesIO()
    with tarfile.open(fileobj=buffer, mode="w") as tar:
        count = 0
        for path in sorted(root.rglob("*")):
            if path.is_symlink() or not path.is_file():
                continue
            count += 1
            if count > MAX_MEMBERS:
                _log.warning("스냅샷 멤버가 %d개를 넘는다 — 잘라서 담는다", MAX_MEMBERS)
                break
            tar.add(path, arcname=str(path.relative_to(root)), recursive=False)
    return zstandard.ZstdCompressor(level=LEVEL).compress(buffer.getvalue())


def unpack(archive: bytes, root: Path, *, max_bytes: int = MAX_UNPACKED_BYTES) -> int:
    """`tar.zst` 를 워크스페이스에 푼다. 푼 파일 수를 돌려준다.

    **멤버마다 경계를 다시 본다.** 우리가 만든 아카이브만 푼다는 가정에
    기대지 않는다 — 오브젝트 스토어의 객체가 바뀌었을 수도 있고, 그
    가정이 틀린 날 임의 경로 쓰기가 된다.
    """
    raw = _decompress_capped(archive, max_bytes)
    written = 0
    total = 0
    with tarfile.open(fileobj=io.BytesIO(raw), mode="r") as tar:
        for member in tar.getmembers():
            if not member.isfile():
                # 심링크·디바이스·하드링크를 **만들지 않는다.** 심링크
                # 하나면 다음 쓰기가 호스트 파일로 간다.
                continue
            try:
                target = resolve_in_workspace(root, member.name)
            except PathEscape:
                _log.warning("스냅샷 멤버가 경계 밖이다 — 건너뛴다 name=%r", member.name)
                continue
            total += member.size
            if total > max_bytes:
                raise UnsafeArchive(f"압축 해제가 {max_bytes:,}바이트를 넘는다")
            source = tar.extractfile(member)
            if source is None:  # pragma: no cover — isfile() 이 보장한다
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(source.read())
            written += 1
    return written


def _decompress_capped(archive: bytes, cap: int) -> bytes:
    """상한을 두고 푼다. **압축 폭탄 방어.**

    `ZstdDecompressor.decompress(max_output_size=...)` 를 쓰지 않는 이유:
    그 인자는 프레임에 **크기가 적혀 있지 않을 때만** 쓰인다. 우리
    압축기는 크기를 적으므로 상한이 **조용히 무시된다** — 측정해서
    확인했다 (`IMPL-0026`).

    그래서 스트림으로 읽으며 직접 센다. `cap + 1` 바이트를 읽어
    넘치는지 보는 방식이라, 폭탄이어도 메모리에 `cap` 이상 올라오지
    않는다.
    """
    reader = zstandard.ZstdDecompressor().stream_reader(io.BytesIO(archive))
    raw = reader.read(cap + 1)
    if len(raw) > cap:
        raise UnsafeArchive(f"압축 해제가 {cap:,}바이트를 넘는다")
    return raw


async def pack_async(root: Path) -> bytes:
    """**스레드에서 돈다.** 압축이 이벤트 루프를 멈추면 SSE 하트비트가
    끊긴다 (`plan/04` §5)."""
    return await anyio.to_thread.run_sync(pack, root)


async def unpack_async(archive: bytes, root: Path) -> int:
    return await anyio.to_thread.run_sync(unpack, archive, root)


__all__ = [
    "LEVEL",
    "MAX_MEMBERS",
    "MAX_UNPACKED_BYTES",
    "UnsafeArchive",
    "pack",
    "pack_async",
    "unpack",
    "unpack_async",
]
