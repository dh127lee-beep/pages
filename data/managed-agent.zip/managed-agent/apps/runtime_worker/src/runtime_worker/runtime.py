"""`HarnessRuntime` 의 SQL 구현 — **fence 검증이 여기 한 곳에만 있다**.

`plan/02-architecture.md` §3 §8 · `plan/06-harness-and-model.md` §4.

하네스가 Store 를 직접 쥐면 fence 를 빼먹을 수 있다. 이 좁은 창구를 통하면
검증이 한 번만 있고, 그 한 번을 크래시 테스트가 지킨다.

**이벤트는 broadcast 전에 내구적으로 쓴다** (§8 공통 규칙). 역순이면 SSE 로
나간 것이 DB 에 없는 상황이 생기고, 사용자가 본 것이 사라진다. 그래서
`append` 는 `events.append` → `realtime.publish` 순서다.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from ma_application.realtime import Wake
from ma_domain.events import SessionEvent
from ma_domain.executions import ExecutionFence, ExecutionFenceLost
from ma_domain.ids import ModelCardId
from ma_harness.ports import StreamFrame
from ma_store.events import PromoteEvent, ReadEvents
from ma_store.sessions import AccrueSessionUsage

if TYPE_CHECKING:
    from ma_application.realtime import RealtimePort
    from ma_domain.ids import ExecutionId
    from ma_domain.models import TokenUsage
    from ma_store.events import PendingEventStore, SessionEventStore
    from ma_store.executions import ExecutionStore
    from ma_store.governance import UsageStore
    from ma_store.sessions import SessionStore


@dataclass
class SqlHarnessRuntime:
    """한 턴 동안 하네스가 바깥에 할 수 있는 일 전부."""

    events: SessionEventStore
    pending: PendingEventStore
    executions: ExecutionStore
    sessions: SessionStore
    realtime: RealtimePort
    execution_id: ExecutionId
    #: 사용량 적립 (`usage_events`). **없으면 비용 대시보드가 빈다.**
    #:
    #: 세션 카운터(`sessions.accrue_usage`)와 **둘 다** 쓴다: 전자는
    #: "이 세션이 상한에 닿았는가"(핫 경로의 한 행), 후자는 "부서가
    #: 무엇에 썼는가"(집계·감사). 하나로 합치면 집계 질의가 세션
    #: 테이블을 스캔하게 된다.
    usage: UsageStore | None = None
    #: 적립에 필요한 맥락. 턴마다 같으므로 생성자가 받는다.
    model_card_id: str = ""
    wire_model: str = ""
    agent_id: str | None = None
    #: 이 턴이 off-peak 인가. 카드의 `PeakWindow` 로 조립이 판단한다.
    off_peak: bool = False
    #: `ma_observability.Metrics`. 없으면 세지 않는다 — 관측이 없어도
    #: 턴은 돌아야 한다.
    metrics: Any = None

    async def _assert_fence(self, fence: ExecutionFence) -> None:
        """**모든 쓰기 앞에 선다.** 좀비는 여기서 막힌다.

        읽기에는 걸지 않는다 — 읽기는 아무것도 바꾸지 않으므로 소유권이
        없어도 해롭지 않고, 매번 왕복을 추가할 이유가 없다.
        """
        current = await self.executions.current_generation(fence.scope)
        if current is None:
            # running 이 하나도 없다 = 이 실행은 이미 settle 됐다.
            raise ExecutionFenceLost(expected=fence.generation, actual=-1)
        fence.assert_current(current)

    async def drain_pending(self, fence: ExecutionFence) -> tuple[SessionEvent, ...]:
        await self._assert_fence(fence)
        out: list[SessionEvent] = []
        for p in await self.pending.peek(
            fence.scope.workspace_id, fence.scope.session_id, fence.scope.lane_id
        ):
            promoted = await self.events.promote(
                PromoteEvent(
                    workspace_id=fence.scope.workspace_id,
                    session_id=fence.scope.session_id,
                    event_id=p.id,
                    generation=fence.generation,
                    now=p.enqueued_at,
                )
            )
            if promoted is not None:
                out.append(promoted)
        if out:
            await self._wake(fence, out[-1].seq)
        return tuple(out)

    async def read_history(self, fence: ExecutionFence) -> tuple[SessionEvent, ...]:
        return await self.events.read(
            ReadEvents(
                workspace_id=fence.scope.workspace_id,
                session_id=fence.scope.session_id,
                limit=100_000,
            )
        )

    async def append(self, fence: ExecutionFence, event: SessionEvent) -> SessionEvent:
        """**내구적으로 쓰고 나서 알린다.** 역순이면 본 것이 사라진다 (§8)."""
        await self._assert_fence(fence)
        stored = await self.events.append(event, generation=fence.generation)
        await self._wake(fence, stored.seq)
        return stored

    async def emit(self, fence: ExecutionFence, frame: StreamFrame) -> None:
        """스트림 전용 프레임. **영속되지 않는다.**

        지금은 알림만 보낸다 — 구독자가 DB 를 다시 읽으므로 영속되지 않는
        프레임은 전달되지 않는다. 토큰 단위 스트리밍은 M4 의 콘솔 작업에서
        별도 경로(세션 stream row)로 붙인다. **지금 거짓으로 붙이지 않는다.**
        """
        return

    async def accrue(self, fence: ExecutionFence, usage: TokenUsage, cost_cents: int) -> None:
        await self._assert_fence(fence)
        await self.sessions.accrue_usage(
            AccrueSessionUsage(
                workspace_id=fence.scope.workspace_id,
                id=fence.scope.session_id,
                usage=usage,
                cost_cents=cost_cents,
                now=fence.expires_at,
            )
        )
        if self.usage is None:
            return
        # **집계용 행.** 세션 카운터만 쓰면 "부서가 이번 달에 얼마나
        # 썼는가"를 셀 수 없고, 비용 대시보드가 빈 채로 돈다.
        from decimal import Decimal

        from ma_domain.governance import UsageEvent

        await self.usage.record(
            UsageEvent(
                workspace_id=fence.scope.workspace_id,
                session_id=fence.scope.session_id,
                model_card_id=ModelCardId(self.model_card_id),
                wire_model=self.wire_model,
                usage=usage,
                list_cost_cents=Decimal(cost_cents),
                created_at=fence.expires_at,
                agent_id=self.agent_id,
                off_peak=self.off_peak,
            )
        )
        if self.metrics is not None:
            # **캐시 적중률이 여기서 나온다** — 1순위 알람이 보는 숫자다.
            self.metrics.record_usage(
                fence.scope.workspace_id,
                model_card=self.model_card_id,
                hit_tokens=usage.input_cache_hit,
                miss_tokens=usage.input_cache_miss,
                output_tokens=usage.output,
                cost_cents=float(cost_cents),
                off_peak=self.off_peak,
            )

    async def is_interrupted(self, fence: ExecutionFence) -> bool:
        rec = await self.executions.find(fence.scope, self.execution_id)
        return rec is not None and rec.is_interrupted

    async def _wake(self, fence: ExecutionFence, up_to_seq: int | None) -> None:
        """알림 실패는 **턴을 깨지 않는다** — 구독자가 폴링으로도 따라잡는다."""
        try:
            await self.realtime.publish(
                Wake(
                    workspace_id=fence.scope.workspace_id,
                    session_id=fence.scope.session_id,
                    up_to_seq=up_to_seq,
                )
            )
        except Exception:
            return


__all__ = ["SqlHarnessRuntime"]
