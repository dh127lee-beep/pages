"""AWP · 실행 평면 — claim → fence → 하네스 → settle"""
