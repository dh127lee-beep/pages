"""환경변수 → `WorkerConfig`. **환경변수를 읽는 유일한 파일.**

`plan/09-codebase.md` §4.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from datetime import timedelta

from ma_domain.executions import DEFAULT_HEARTBEAT, DEFAULT_LEASE_TTL

#: 이 값이면 직접 모델 키 경로를 거부한다.
PRODUCTION = "production"


class ConfigError(Exception):
    def __init__(self, problems: tuple[str, ...]) -> None:
        super().__init__("설정 오류 " + str(len(problems)) + "건:\n  - " + "\n  - ".join(problems))
        self.problems = problems


@dataclass(frozen=True, slots=True)
class WorkerConfig:
    database_url: str
    #: 이 워커가 맡을 워크스페이스. `None` 이면 전부 — 단일 테넌트 배포용.
    workspace_id: str | None = None
    #: 프로세스당 동시 lane 수. **lane 수가 병렬성을 정한다** (D3).
    concurrency: int = 4
    lease_ttl: timedelta = DEFAULT_LEASE_TTL
    heartbeat: timedelta = DEFAULT_HEARTBEAT
    idle_poll_seconds: float = 1.0
    #: `terminationGracePeriodSeconds` 와 맞춘다 (`plan/08` §3).
    drain_timeout_seconds: float = 600.0
    #: egress 프록시 주소. **있으면 모델 호출이 그쪽을 지난다**
    #: (`plan/07` §6.3) — 프록시가 키를 주입하므로 워커는 키를 모른다.
    egress_proxy_url: str | None = None
    #: 모델 API 키 **직접 경로**. 개발 전용이다.
    #:
    #: `AWP_ENV=production` 에서 이 값이 있으면 **기동을 거부한다.** D5 는
    #: "자격증명이 샌드박스 주소 공간에 없다"인데, 워커는 샌드박스를
    #: 호스팅하는 프로세스다 — 여기 키가 있으면 "유출할 토큰이 없다"가
    #: "옆방에 있다"가 된다 (`ADR-0009`).
    model_api_key: str | None = None
    #: 제어 평면 주소. **MCP OAuth 갱신을 맡기는 곳이다** (T-0601).
    #:
    #: 없으면 MCP 툴은 등록되지만 **401 이 나도 갱신이 안 된다** —
    #: 워커가 직접 갱신할 수는 없다 (D5 · `ADR-0009`: 갱신 토큰은
    #: access token 보다 센 권한이고, 루트 시크릿은 제어 평면에만 있다).
    control_plane_url: str | None = None
    #: 제어 평면을 부를 때 쓰는 키. **operator 권한이면 충분하다.**
    control_plane_api_key: str | None = None
    #: 세션 워크스페이스 루트. k8s 에서는 `emptyDir` 마운트 지점이고,
    #: 개발 머신에서는 그냥 디렉터리다 (`plan/08` §6).
    #:
    #: **영속 볼륨이 아니다.** 진실은 DB + 오브젝트 스토어에 있고, Pod 가
    #: 죽으면 스냅샷에서 복원한다.
    workspace_root: str = "/var/lib/awp/sessions"
    #: 오브젝트 스토어 버킷. 비면 **로컬 백엔드** (개발 전용).
    blob_bucket: str | None = None
    blob_endpoint: str | None = None
    blob_region: str | None = None
    blob_local_root: str = ".awp-blobs"
    log_level: str = "INFO"

    @property
    def model_goes_through_proxy(self) -> bool:
        return self.egress_proxy_url is not None


def load_config(env: Mapping[str, str]) -> WorkerConfig:
    problems: list[str] = []

    database_url = env.get("AWP_DATABASE_URL", "").strip()
    if not database_url:
        problems.append("AWP_DATABASE_URL 이 필요하다")

    def positive_int(key: str, default: int) -> int:
        raw = env.get(key, str(default))
        try:
            value = int(raw)
        except ValueError:
            problems.append(f"{key} 가 정수가 아니다: {raw!r}")
            return default
        if value < 1:
            problems.append(f"{key} 는 1 이상이어야 한다: {value}")
            return default
        return value

    def positive_float(key: str, default: float) -> float:
        raw = env.get(key, str(default))
        try:
            value = float(raw)
        except ValueError:
            problems.append(f"{key} 가 수가 아니다: {raw!r}")
            return default
        if value <= 0:
            problems.append(f"{key} 는 0보다 커야 한다: {value}")
            return default
        return value

    # ── D5: 워커는 모델 키를 들지 않는다 (T-0402) ──────
    #
    # 프로덕션에서 직접 경로를 쓰면 **기동을 거부한다.** 경고로 두면
    # 읽히지 않고, 키를 든 채로 도는 것을 알아챌 방법이 없다 —
    # `ma_sandbox_local` 이 격리 없이 뜨는 것을 거부하는 것과 같은 이유다.
    proxy_url = env.get("AWP_EGRESS_PROXY_URL", "").strip() or None
    model_key = env.get("AWP_MODEL_API_KEY") or None
    is_production = env.get("AWP_ENV", "").strip().lower() == PRODUCTION

    if is_production and model_key:
        problems.append(
            "AWP_ENV=production 에서 AWP_MODEL_API_KEY 를 쓸 수 없다 — "
            "egress 프록시가 주입한다 (AWP_EGRESS_PROXY_URL)"
        )
    if is_production and not proxy_url:
        problems.append("AWP_ENV=production 에는 AWP_EGRESS_PROXY_URL 이 필요하다")
    if proxy_url and model_key:
        problems.append(
            "AWP_EGRESS_PROXY_URL 과 AWP_MODEL_API_KEY 를 함께 쓸 수 없다 — "
            "둘 다 있으면 어느 쪽이 쓰이는지 설정만 보고 알 수 없다"
        )

    concurrency = positive_int("AWP_WORKER_CONCURRENCY", 4)
    lease = positive_int("AWP_LEASE_TTL_SECONDS", int(DEFAULT_LEASE_TTL.total_seconds()))
    beat = positive_int("AWP_HEARTBEAT_SECONDS", int(DEFAULT_HEARTBEAT.total_seconds()))
    idle = positive_float("AWP_IDLE_POLL_SECONDS", 1.0)
    drain = positive_float("AWP_DRAIN_TIMEOUT_SECONDS", 600.0)

    if beat >= lease:
        # 하트비트가 TTL 보다 길면 **자기 lease 가 만료되는 것을 못 막는다**.
        problems.append(f"하트비트({beat}s)는 lease TTL({lease}s)보다 짧아야 한다")
    elif beat * 2 > lease:
        # 한 번 놓쳐도 다음이 남아야 한다 (`ADR-0003`).
        problems.append(
            f"하트비트({beat}s)는 lease TTL({lease}s)의 절반 이하여야 한다 "
            "— 한 번 놓치면 lease 를 잃는다"
        )

    # MCP 갱신 경로. **반쪽이면 거부한다** — 주소만 있고 키가 없으면
    # 갱신 요청이 전부 401 로 돌아오고, 그 실패가 "MCP 서버가
    # 이상하다"로 보인다.
    cp_url = env.get("AWP_CONTROL_PLANE_URL", "").strip() or None
    cp_key = env.get("AWP_WORKER_API_KEY", "").strip() or None
    if bool(cp_url) != bool(cp_key):
        problems.append(
            "AWP_CONTROL_PLANE_URL 과 AWP_WORKER_API_KEY 는 함께 있어야 한다 — "
            "한쪽만 있으면 MCP OAuth 갱신이 조용히 실패한다"
        )

    level = env.get("AWP_LOG_LEVEL", "INFO").upper()
    if level not in {"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"}:
        problems.append(f"모르는 AWP_LOG_LEVEL: {level!r}")

    if problems:
        raise ConfigError(tuple(problems))

    return WorkerConfig(
        database_url=database_url,
        workspace_id=env.get("AWP_WORKSPACE_ID") or None,
        concurrency=concurrency,
        lease_ttl=timedelta(seconds=lease),
        heartbeat=timedelta(seconds=beat),
        idle_poll_seconds=idle,
        drain_timeout_seconds=drain,
        egress_proxy_url=proxy_url,
        control_plane_url=cp_url,
        control_plane_api_key=cp_key,
        model_api_key=model_key,
        workspace_root=env.get("AWP_WORKSPACE_ROOT", "/var/lib/awp/sessions"),
        blob_bucket=env.get("AWP_BLOB_BUCKET") or None,
        blob_endpoint=env.get("AWP_BLOB_ENDPOINT") or None,
        blob_region=env.get("AWP_BLOB_REGION") or None,
        blob_local_root=env.get("AWP_BLOB_LOCAL_ROOT", ".awp-blobs"),
        log_level=level,
    )


__all__ = ["ConfigError", "WorkerConfig", "load_config"]
