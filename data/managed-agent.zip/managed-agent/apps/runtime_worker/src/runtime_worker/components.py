"""어떤 구현을 쓸지 고른다. **교체 지점이 여기 하나다.**

`plan/09-codebase.md` §4 · `plan/06-harness-and-model.md` §1.

모델 어댑터는 `ProviderKind` 로 고른다 — **카드가 provider 를 선언하고**
여기서는 그 선언을 구현으로 바꾼다. 코드에 모델 ID 가 없는 것과 같은 이유로,
여기에도 특정 provider 의 기본값이 박히지 않는다.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

import httpx
from ma_adapters_runtime.realtime_pg import InProcessRealtime, PgRealtime
from ma_domain.clock import Clock, IdGenerator
from ma_model_deepseek.adapter import DeepSeekOfficialAdapter
from ma_model_openai_compat.adapter import OpenAICompatibleAdapter
from ma_platform.capabilities import SystemClock, UlidGenerator
from ma_sql.asyncpg_client import create_pool

if TYPE_CHECKING:
    import asyncpg
    from ma_application.realtime import RealtimePort
    from ma_harness.model_port import ModelPort

    from runtime_worker.config import WorkerConfig


@dataclass
class WorkerOverrides:
    """테스트와 다른 배포 프리셋이 갈아끼우는 것. `None` 은 기본 구현."""

    clock: Clock | None = None
    ids: IdGenerator | None = None
    model: ModelPort | None = None
    realtime: RealtimePort | None = None
    pool: Any | None = None


@dataclass
class WorkerComponents:
    cfg: WorkerConfig
    pool: asyncpg.Pool
    model: ModelPort
    realtime: RealtimePort
    clock: Clock
    ids: IdGenerator
    _closers: list[Any]

    async def aclose(self) -> None:
        """**역순 정리.** 먼저 연 것을 나중에 닫는다."""
        for close in reversed(self._closers):
            await close()


def _dsn(url: str) -> str:
    return url.replace("postgresql+psycopg://", "postgresql://")


async def default_components(
    cfg: WorkerConfig, overrides: WorkerOverrides | None = None
) -> WorkerComponents:
    o = overrides or WorkerOverrides()
    closers: list[Any] = []

    pool = o.pool
    if pool is None:
        pool = await create_pool(_dsn(cfg.database_url), min_size=2, max_size=20)
        closers.append(pool.close)

    model = o.model
    if model is None:
        client = model_client(cfg)
        closers.append(client.aclose)
        # 기본은 DeepSeek 공식 어댑터다. **카드가 다른 provider 를 선언하면**
        # 그 카드의 `base_url` 을 그대로 쓰므로 OpenAI 호환 게이트웨이도
        # 같은 코드로 간다 (`plan/06` §1).
        model = DeepSeekOfficialAdapter(client, api_key=_direct_key(cfg))
        closers.append(_noop)

    realtime = o.realtime
    if realtime is None:
        pg = PgRealtime(_dsn(cfg.database_url))
        await pg.start()
        closers.append(pg.stop)
        realtime = pg

    clock = o.clock or SystemClock()
    return WorkerComponents(
        cfg=cfg,
        pool=pool,
        model=model,
        realtime=realtime,
        clock=clock,
        ids=o.ids or UlidGenerator(clock),
        _closers=closers,
    )


def model_client(cfg: WorkerConfig) -> httpx.AsyncClient:
    """모델 호출용 HTTP 클라이언트.

    **프록시가 설정돼 있으면 그쪽을 지난다** (`plan/07` §6.3). 그러면:

    - 모델 API 키가 워커 프로세스에 **없어도 된다** (프록시가 주입)
    - 모든 모델 호출이 `credential_events` 에 남아 감사된다
    - provider 엔드포인트 변경이 프록시 설정 하나로 끝난다
    """
    timeout = httpx.Timeout(300.0, connect=10.0)
    if cfg.egress_proxy_url is None:
        return httpx.AsyncClient(timeout=timeout)
    return httpx.AsyncClient(timeout=timeout, proxy=cfg.egress_proxy_url)


def _direct_key(cfg: WorkerConfig) -> str | None:
    """**프록시를 쓰면 키를 어댑터에 주지 않는다.**

    줘도 프록시가 덮어쓰지만(`ma_egress.inject` 가 기존 `Authorization`
    을 지운다), 애초에 주지 않는 편이 낫다 — 주면 그 값이 어댑터 객체에
    남고, 그 객체가 예외 추적에 실릴 수 있다.
    """
    return None if cfg.model_goes_through_proxy else cfg.model_api_key


async def _noop() -> None:
    return


def openai_compatible(cfg: WorkerConfig, client: httpx.AsyncClient) -> OpenAICompatibleAdapter:
    """사내 게이트웨이·vLLM 용. `components` 를 바꾸지 않고 override 로 넣는다."""
    return OpenAICompatibleAdapter(client, api_key=_direct_key(cfg))


__all__ = [
    "InProcessRealtime",
    "WorkerComponents",
    "WorkerOverrides",
    "default_components",
    "model_client",
    "openai_compatible",
]
