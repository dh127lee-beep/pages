"""워커 조립 — Store·모델·하네스를 묶는다.

`plan/09-codebase.md` §4.

`WorkerDeps` 가 워커 루프가 바깥에 닿는 전부다. 테스트는 이것을 통째로
가짜로 바꿔 끼운다 — 그래서 크래시 테스트가 진짜 DB + 가짜 모델로 돈다.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from ma_application.models import ModelResolver, ResolvedModel, ResolveModel
from ma_domain.agents import AgentDefinition
from ma_domain.ids import AgentId, EnvironmentId, SessionId, WorkspaceId
from ma_sql.asyncpg_client import AsyncpgClient
from ma_store.agents import FindAgentVersion
from ma_store.sessions import FindSession
from ma_store_sql.agents import SqlAgentStore
from ma_store_sql.environments import SqlEnvironmentStore
from ma_store_sql.events import SqlPendingEventStore, SqlSessionEventStore
from ma_store_sql.executions import SqlExecutionStore
from ma_store_sql.governance import SqlUsageStore
from ma_store_sql.models import SqlModelCardStore
from ma_store_sql.sessions import SqlSessionStore

if TYPE_CHECKING:
    import asyncpg
    from ma_application.realtime import RealtimePort
    from ma_harness.model_port import ModelPort


_log = logging.getLogger("runtime_worker.assembly")


class SessionNotRunnable(Exception):
    """세션이나 에이전트를 찾을 수 없다 — 이 실행은 돌 수 없다.

    **예외인 이유**: 복구할 수 없고, 턴을 `failed` 로 settle 해야 한다.
    discriminated union 으로 돌려주면 호출자가 무시할 수 있다.
    """


@dataclass
class WorkerDeps:
    """워커가 바깥에 닿는 **전부**. 테스트는 이것을 바꿔 끼운다."""

    pool: asyncpg.Pool
    model: ModelPort
    realtime: RealtimePort
    workspace_id: WorkspaceId | None = None
    _cache: dict[str, Any] = field(default_factory=dict)

    @property
    def _sql(self) -> AsyncpgClient:
        return AsyncpgClient(self.pool)

    @property
    def executions(self) -> SqlExecutionStore:
        return SqlExecutionStore(self._sql)

    @property
    def events(self) -> SqlSessionEventStore:
        return SqlSessionEventStore(self._sql)

    @property
    def pending(self) -> SqlPendingEventStore:
        return SqlPendingEventStore(self._sql)

    @property
    def sessions(self) -> SqlSessionStore:
        return SqlSessionStore(self._sql)

    @property
    def agents(self) -> SqlAgentStore:
        return SqlAgentStore(self._sql)

    @property
    def cards(self) -> SqlModelCardStore:
        return SqlModelCardStore(self._sql)

    @property
    def usage(self) -> SqlUsageStore:
        """`usage_events` 적립. **워커는 INSERT 만 한다** —
        `0007_budgets` 의 GRANT 가 예산 수정을 막는다."""
        return SqlUsageStore(self._sql)

    @property
    def environments(self) -> SqlEnvironmentStore:
        return SqlEnvironmentStore(self._sql)

    async def allow_mcp_for(self, session_id: SessionId) -> bool:
        """세션의 환경이 MCP 서버를 허용하는가 (T-0601).

        **세션이 핀한 환경 버전을 읽는다.** 현재 버전이 아니다 —
        운영자가 환경을 넓히는 동안 진행 중인 세션의 경계가 바뀌면
        그 세션이 무엇을 할 수 있었는지 재현할 수 없다.

        읽지 못하면 **금지로 본다.** "모르겠으니 허용"은 네트워크
        정책에서 가장 비싼 기본값이다.
        """
        from ma_store.environments import FindEnvironmentVersion

        session = await self._session(session_id)
        rec = await self.environments.find_version(
            FindEnvironmentVersion(
                workspace_id=session.workspace_id,
                id=EnvironmentId(session.environment_id),
                version=session.environment_version,
            )
        )
        if rec is None:
            return False
        return bool(rec.config.networking.allow_mcp_servers)

    async def load_agent(self, session_id: SessionId) -> AgentDefinition:
        """세션이 **핀한 버전**을 읽는다. 현재 버전이 아니다.

        운영자가 에이전트를 고치는 동안 진행 중인 세션의 행동이 바뀌면 그
        세션의 이벤트 로그를 재현할 수 없다.
        """
        session = await self._session(session_id)
        rec = await self.agents.find_version(
            FindAgentVersion(session.workspace_id, AgentId(session.agent_id), session.agent_version)
        )
        if rec is None:
            raise SessionNotRunnable(
                f"에이전트 {session.agent_id} v{session.agent_version} 를 찾을 수 없다"
            )
        return rec.definition

    async def resolve_model(self, session_id: SessionId) -> ResolvedModel:
        """결정 순서 5단계 (D12). 세션 오버라이드가 가장 세다."""
        session = await self._session(session_id)
        agent = await self.load_agent(session_id)
        got = await ModelResolver(cards=self.cards).resolve(
            ResolveModel(
                workspace_id=session.workspace_id,
                override=session.config_override,
                agent=agent,
            )
        )
        if not isinstance(got, ResolvedModel):
            raise SessionNotRunnable(f"모델을 정할 수 없다: {got!r}")
        return got

    async def _session(self, session_id: SessionId) -> Any:
        cached = self._cache.get(session_id)
        if cached is not None:
            return cached
        ws = self.workspace_id or await self._workspace_of(session_id)
        rec = await self.sessions.find(FindSession(workspace_id=ws, id=session_id))
        if rec is None:
            raise SessionNotRunnable(f"세션 {session_id} 를 찾을 수 없다")
        self._cache[session_id] = rec
        return rec

    async def _workspace_of(self, session_id: SessionId) -> WorkspaceId:
        """전역 워커는 실행 행에서 워크스페이스를 알아낸다.

        `session_executions` 가 이미 그것을 들고 있으므로 별도 조회가 필요 없다 —
        다만 여기서는 세션 테이블을 직접 본다(워커가 lane 을 claim 하기 전에
        부를 수도 있으므로).
        """
        async with self.pool.acquire() as conn:
            row = await conn.fetchrow(
                "SELECT workspace_id FROM sessions WHERE id = $1 AND deleted_at IS NULL",
                session_id,
            )
        if row is None:
            raise SessionNotRunnable(f"세션 {session_id} 를 찾을 수 없다")
        return WorkspaceId(row["workspace_id"])


async def register_instance(
    pool: asyncpg.Pool, worker_id: str, hostname: str, pid: int, now: Any
) -> None:
    """`worker_instances` 에 자기를 알린다. **권한이 아니라 관측이다.**

    실패해도 claim 은 돌아야 하므로 예외를 삼킨다 — 등록이 안 됐다고 세션이
    멈추면, 관측 테이블이 가용성을 떨어뜨리는 셈이다.
    """
    try:
        async with pool.acquire() as conn:
            await conn.execute(
                """
                INSERT INTO worker_instances
                  (id, hostname, pid, state, started_at, heartbeat_at)
                VALUES ($1,$2,$3,'running',$4,$4)
                ON CONFLICT (id) DO UPDATE SET
                  state='running', heartbeat_at=EXCLUDED.heartbeat_at
                """,
                worker_id,
                hostname,
                pid,
                now,
            )
    except Exception:
        _log.warning("worker_instances 등록 실패 (무시한다) worker=%s", worker_id)


async def mark_instance(pool: asyncpg.Pool, worker_id: str, state: str, now: Any) -> None:
    try:
        async with pool.acquire() as conn:
            await conn.execute(
                "UPDATE worker_instances SET state=$2, heartbeat_at=$3, "
                "stopped_at = CASE WHEN $2 = 'stopped' THEN $3 ELSE stopped_at END "
                "WHERE id=$1",
                worker_id,
                state,
                now,
            )
    except Exception:
        _log.warning("worker_instances 갱신 실패 (무시한다) worker=%s", worker_id)


__all__ = [
    "SessionNotRunnable",
    "WorkerDeps",
    "mark_instance",
    "register_instance",
]
