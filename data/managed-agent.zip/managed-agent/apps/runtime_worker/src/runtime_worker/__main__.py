"""`config → components → assembly → run`.

`plan/09-codebase.md` §4.
"""

from __future__ import annotations

import logging
import os
import sys

import anyio

from runtime_worker.run import run_workers


async def main() -> None:
    from runtime_worker.config import ConfigError, load_config

    try:
        cfg = load_config(os.environ)  # awp-env-ok — 환경을 읽는 유일한 지점
    except ConfigError as err:
        print(err, file=sys.stderr)  # noqa: T201 — 기동 실패는 stderr 로
        raise SystemExit(2) from err

    logging.basicConfig(level=cfg.log_level)
    await run_workers(cfg)


if __name__ == "__main__":
    anyio.run(main)
