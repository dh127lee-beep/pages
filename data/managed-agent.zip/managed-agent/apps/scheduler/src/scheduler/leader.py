"""리더 선출 — `pg_try_advisory_lock` (T-0603).

`plan/08-infrastructure.md` §9.

values.yaml 이 `replicas: 2` 에 "하나만 리더다"라고 적어 두었으므로,
**그 약속을 지키는 코드가 있어야 한다.** 없으면 둘 다 돌고, 겹친 잡이
같은 배포를 두 번 발화한다.

왜 advisory lock 인가:

| 후보 | 왜 아닌가 |
|---|---|
| k8s Lease | RBAC 추가가 필요하고, DB 가 죽으면 잡도 못 도는데 리더만 살아 있다 |
| 테이블 행 + CAS | 리더가 죽으면 TTL 이 지날 때까지 아무도 안 돈다 |
| advisory lock | **연결이 끊기면 즉시 풀린다** — Pod 가 죽으면 다음 Pod 가 바로 집는다 |

락은 **전용 연결**이 든다. 풀에서 빌려 쓰면 반납할 때 풀리고, 그
순간부터 둘 다 리더다.
"""

from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from collections.abc import AsyncIterator

_log = logging.getLogger("scheduler.leader")

#: 이 락 하나가 스케줄러 전체를 덮는다. 잡별로 쪼개지 않는 이유:
#: 잡들이 같은 행을 건드리고(파티션과 보존이 둘 다 이벤트 테이블을
#: 본다), 쪼개면 그 사이의 순서를 아무도 보장하지 않는다.
LOCK_KEY = 0x41575053  # "AWPS"


class Leadership:
    """리더인지 아닌지. **매 주기마다 다시 묻는다.**

    한 번 집었다고 영원히 리더라고 믿으면, 연결이 끊겼다 붙은 뒤에도
    리더라고 생각한다 — 그 사이 다른 Pod 가 집었는데도.
    """

    def __init__(self, conn: Any, *, key: int = LOCK_KEY) -> None:
        self._conn = conn
        self._key = key
        self._held = False

    @property
    def held(self) -> bool:
        return self._held

    async def acquire(self) -> bool:
        """집어 본다. **블로킹하지 않는다** — 못 집으면 이번 주기는 쉰다."""
        if self._held:
            # 이미 들고 있다. 연결이 살아 있는지만 확인한다 — 끊겼으면
            # 락도 같이 풀렸고, 우리는 그것을 모른 채 돌고 있다.
            try:
                await self._conn.fetchval("SELECT 1")
            except Exception as exc:
                _log.warning("리더 연결이 끊겼다: %s", exc)
                self._held = False
                return False
            return True

        got = await self._conn.fetchval("SELECT pg_try_advisory_lock($1)", self._key)
        self._held = bool(got)
        if self._held:
            _log.info("리더가 됐다 (key=%#x)", self._key)
        return self._held

    async def release(self) -> None:
        if not self._held:
            return
        try:
            await self._conn.fetchval("SELECT pg_advisory_unlock($1)", self._key)
        except Exception as exc:  # pragma: no cover — 끊긴 연결은 어차피 락을 푼다
            # 연결이 끊겼으면 락은 서버 쪽에서 이미 풀렸다. 여기서
            # 터뜨리면 **정상 종료가 실패로 보인다.**
            _log.debug("락 해제 실패 (이미 풀렸을 것이다): %s", exc)
        self._held = False
        _log.info("리더를 내려놨다")


@asynccontextmanager
async def leadership(pool: Any, *, key: int = LOCK_KEY) -> AsyncIterator[Leadership]:
    """**전용 연결**을 하나 잡아 락을 든다.

    `pool.acquire()` 로 빌려 쓰면 반납할 때 세션이 끝나 락이 풀린다.
    그 순간부터 둘 다 리더다 — 그래서 풀 밖에서 하나를 들고 있는다.
    """
    conn = await pool.acquire()
    lead = Leadership(conn, key=key)
    try:
        yield lead
    finally:
        await lead.release()
        await pool.release(conn)


__all__ = ["LOCK_KEY", "Leadership", "leadership"]
