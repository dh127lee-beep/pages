"""발화된 실행 → 세션 (T-0603).

`plan/04-api.md` §3 · `plan/06-harness-and-model.md` §5.4.

배포가 발화하면 **세션 하나가 생기고 초기 이벤트가 들어간다.** 워커는
그 뒤를 평소와 똑같이 처리한다 — 배포용 실행 경로가 따로 없다. 따로
두면 배포로 돌 때만 나는 버그가 생긴다.

예산은 **실행별 상한**이 세션 예산으로 그대로 간다. 배포는 사람이 안
보므로 이 상한이 유일한 제동이다.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from ma_application.session_events import (
    EventsAccepted,
    InboundEvent,
    SendEvents,
)
from ma_domain.events import PRIMARY_THREAD, EventType
from ma_domain.ids import EnvironmentId, SessionId
from ma_domain.sessions import SessionBudget, SessionRecord, SessionStatus
from ma_domain.workspaces import Role
from ma_store.sessions import InsertSession

if TYPE_CHECKING:
    from ma_application.session_events import SessionEventsUseCases
    from ma_domain.clock import Clock, IdGenerator
    from ma_domain.deployments import Deployment, DeploymentRun
    from ma_store.sessions import SessionStore

#: 배포에 환경이 없으면 쓰는 값. 세션 생성에는 환경이 필수다.
DEFAULT_ENVIRONMENT = "env_default"


class LaunchFailed(RuntimeError):
    """세션을 못 만들었다. 잡이 이것을 **실행 실패로 기록한다.**"""


@dataclass
class DeploymentSessionLauncher:
    """`SessionLauncher` 구현. **API 와 같은 모양으로 세션을 만든다.**"""

    sessions: SessionStore
    events: SessionEventsUseCases
    clock: Clock
    ids: IdGenerator

    async def launch(self, deployment: Deployment, run: DeploymentRun) -> SessionId:
        now = self.clock.now()
        session_id = SessionId(self.ids.next("session"))
        await self.sessions.insert(
            InsertSession(
                record=SessionRecord(
                    id=session_id,
                    workspace_id=deployment.workspace_id,
                    agent_id=deployment.agent_id,
                    # **배포가 핀한 버전이다.** 현재 버전이 아니다 — 누가
                    # 에이전트를 고쳐도 새벽 3시 배포는 어제 것을 돌린다.
                    agent_version=deployment.agent_version,
                    environment_id=deployment.environment_id or EnvironmentId(DEFAULT_ENVIRONMENT),
                    environment_version=1,
                    status=SessionStatus.IDLE,
                    revision=0,
                    created_by=f"deployment:{deployment.id}",
                    created_at=now,
                    updated_at=now,
                    budget=(
                        SessionBudget(limit_cents=deployment.budget_cents)
                        if deployment.budget_cents is not None
                        else None
                    ),
                )
            )
        )

        inbound = _inbound(deployment)
        if not inbound:
            # **초기 이벤트가 없으면 세션이 안 돈다.** 워커는 들어온
            # 이벤트가 있어야 턴을 시작한다 — 빈 세션을 만들어 두고
            # "돌렸다"고 하면 거짓말이다.
            raise LaunchFailed(f"배포 {deployment.id} 에 초기 이벤트가 없다")

        res = await self.events.send(
            SendEvents(
                workspace_id=deployment.workspace_id,
                session_id=session_id,
                events=inbound,
                # **실행 id 를 멱등키로 쓴다.** 잡이 재시도해도 같은
                # 실행은 같은 이벤트를 두 번 넣지 않는다.
                idempotency_key=f"deployment-run:{run.id}",
                actor_role=Role.OPERATOR,
            )
        )
        if not isinstance(res, EventsAccepted):
            raise LaunchFailed(f"초기 이벤트가 거부됐다: {res!r}")
        return session_id


def _inbound(deployment: Deployment) -> tuple[InboundEvent, ...]:
    """저장된 초기 이벤트를 `InboundEvent` 로 푼다.

    **모르는 타입은 건너뛰지 않고 터뜨린다.** 조용히 빼면 세션이
    절반만 들어간 채로 돌고, 그 결과를 사람이 믿는다.
    """
    out: list[InboundEvent] = []
    for raw in deployment.initial_events:
        item: dict[str, Any] = dict(raw)
        kind = item.get("type")
        if not isinstance(kind, str):
            raise LaunchFailed(f"초기 이벤트에 type 이 없다: {item!r}")
        try:
            event_type = EventType(kind)
        except ValueError as exc:
            raise LaunchFailed(f"모르는 초기 이벤트 타입: {kind!r}") from exc
        payload = item.get("payload") or {}
        if not isinstance(payload, dict):
            raise LaunchFailed(f"초기 이벤트 payload 가 객체가 아니다: {payload!r}")
        out.append(
            InboundEvent(
                type=event_type,
                payload=tuple(sorted(payload.items())),
                thread_id=PRIMARY_THREAD,
            )
        )
    return tuple(out)


__all__ = ["DEFAULT_ENVIRONMENT", "DeploymentSessionLauncher", "LaunchFailed"]
