"""`config → components → assembly → run`.

`plan/09-codebase.md` §4.

helm 의 `args: ["-m", "scheduler"]` 가 여기로 들어온다.
"""

from __future__ import annotations

import logging
import os
import sys
from typing import Any

import anyio

_log = logging.getLogger("scheduler")


async def main() -> None:
    from scheduler.config import ConfigError, load_config

    try:
        cfg = load_config(os.environ)  # awp-env-ok — 환경을 읽는 유일한 지점
    except ConfigError as err:
        print(err, file=sys.stderr)  # noqa: T201 — 기동 실패는 stderr 로
        raise SystemExit(2) from err

    logging.basicConfig(level=cfg.log_level)
    await run(cfg)


async def run(cfg: Any) -> None:
    import asyncpg
    from ma_application.deployments import DeploymentsUseCases
    from ma_application.models import ModelResolver
    from ma_application.session_events import SessionEventsUseCases
    from ma_platform.capabilities import SystemClock, UlidGenerator
    from ma_sql.asyncpg_client import AsyncpgClient
    from ma_store_sql.agents import SqlAgentStore
    from ma_store_sql.deployments import SqlDeploymentStore
    from ma_store_sql.environment_work import SqlEnvironmentWorkStore
    from ma_store_sql.events import SqlPendingEventStore, SqlSessionEventStore
    from ma_store_sql.models import SqlModelCardStore
    from ma_store_sql.sessions import SqlSessionStore

    from scheduler.launcher import DeploymentSessionLauncher
    from scheduler.runner import build_jobs, run_scheduler

    dsn = cfg.database_url.replace("postgresql+psycopg://", "postgresql://")
    pool = await asyncpg.create_pool(dsn, min_size=2, max_size=8)
    if pool is None:  # pragma: no cover — asyncpg 는 None 을 주지 않는다
        raise SystemExit("DB 풀을 만들지 못했다")

    try:
        sql = AsyncpgClient(pool)
        clock = SystemClock()
        ids = UlidGenerator(clock)
        sessions = SqlSessionStore(sql)

        deployments = DeploymentsUseCases(
            deployments=SqlDeploymentStore(sql),
            agents=SqlAgentStore(sql),
            # peak 창을 **카드에서** 읽는 길. 코드에 박지 않는다 (D12).
            resolver=ModelResolver(cards=SqlModelCardStore(sql)),
            clock=clock,
            ids=ids,
        )
        launcher = DeploymentSessionLauncher(
            sessions=sessions,
            events=SessionEventsUseCases(
                events=SqlSessionEventStore(sql),
                pending_events=SqlPendingEventStore(sql),
                sessions=sessions,
                clock=clock,
            ),
            clock=clock,
            ids=ids,
        )

        # **웹훅과 샘플러는 아직 안 꽂는다.** 전자는 루트 시크릿을
        # 요구하고(D5 — 제어 평면만 안다), 후자는 OTLP 설정을 요구한다.
        # 꽂지 않은 것을 꽂은 척하지 않는다 — `Jobs` 가 `None` 을 건너뛴다.
        # **self_hosted 일 회수.** cipher 가 필요하지만 **복호화를 하지
        # 않는다** — 회수는 시크릿을 `NULL` 로 지우기만 한다. 루트
        # 시크릿이 없으면 빈 것으로 만들고, 그래도 회수는 돈다.
        work = SqlEnvironmentWorkStore(sql, _reclaim_only_cipher())

        jobs = build_jobs(
            cfg, pool, deployments=deployments, launcher=launcher, work=work, clock=clock
        )
        _log.info("스케줄러 기동 (tick=%.1fs)", cfg.tick_seconds)
        await run_scheduler(cfg, jobs, pool)
    finally:
        await pool.close()


def _reclaim_only_cipher() -> Any:
    """회수 전용 cipher.

    `SqlEnvironmentWorkStore` 가 생성자에 cipher 를 요구하지만
    `reclaim_stale` 은 **봉인도 복호화도 하지 않는다** — 시크릿을
    `NULL` 로 지울 뿐이다. 스케줄러에 루트 시크릿을 주면 D5 가
    조용히 약해지므로(`ADR-0009` 와 같은 이유), 쓰이지 않는 값을 준다.
    """
    from ma_governance.cipher import CredentialCipher

    return CredentialCipher(root=b"scheduler-never-seals-or-opens-work-secrets")


if __name__ == "__main__":
    anyio.run(main)
