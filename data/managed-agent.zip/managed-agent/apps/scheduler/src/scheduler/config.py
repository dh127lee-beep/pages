"""환경변수 → `SchedulerConfig`. **환경변수를 읽는 유일한 파일.**

`plan/09-codebase.md` §4.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass


class ConfigError(Exception):
    def __init__(self, problems: tuple[str, ...]) -> None:
        super().__init__("설정 오류 " + str(len(problems)) + "건:\n  - " + "\n  - ".join(problems))
        self.problems = problems


@dataclass(frozen=True, slots=True)
class SchedulerConfig:
    database_url: str
    #: 틱 간격. **잡 주기의 최대공약수여야 한다** — 1분 cron 을 맞추려면
    #: 틱이 그보다 촘촘해야 하고, 30초면 발화가 최대 30초 늦는다.
    tick_seconds: float = 15.0
    #: 보존 파티션을 **실제로 지우는가**. 기본은 아니다 — 지우는 것은
    #: 되돌릴 수 없고, 운영자가 켜는 것이 옳다.
    retention_drop: bool = False
    log_level: str = "INFO"


def _positive(env: Mapping[str, str], key: str, default: float, problems: list[str]) -> float:
    raw = env.get(key, "").strip()
    if not raw:
        return default
    try:
        got = float(raw)
    except ValueError:
        problems.append(f"{key} 가 숫자가 아니다: {raw!r}")
        return default
    if got <= 0:
        problems.append(f"{key} 는 양수여야 한다: {got}")
        return default
    return got


def load_config(env: Mapping[str, str]) -> SchedulerConfig:
    problems: list[str] = []

    database_url = env.get("AWP_DATABASE_URL", "").strip()
    if not database_url:
        problems.append("AWP_DATABASE_URL 이 필요하다")

    tick = _positive(env, "AWP_SCHEDULER_TICK_SECONDS", 15.0, problems)
    drop = env.get("AWP_RETENTION_DROP", "").strip().lower() in {"1", "true", "yes"}

    if problems:
        raise ConfigError(tuple(problems))

    return SchedulerConfig(
        database_url=database_url,
        tick_seconds=tick,
        retention_drop=drop,
        log_level=env.get("AWP_LOG_LEVEL", "INFO").strip() or "INFO",
    )


__all__ = ["ConfigError", "SchedulerConfig", "load_config"]
