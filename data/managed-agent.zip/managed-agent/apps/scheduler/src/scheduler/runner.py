"""스케줄러 루프 — **리더 하나가 모든 잡을 돈다** (T-0603).

`plan/08-infrastructure.md` §9.

helm 이 `python -m scheduler` 로 띄우는 것이 이 루프다. 잡들을 주기별로
돌리고, 리더가 아니면 **아무것도 하지 않는다.**

설계가 단순한 것이 의도다. cron 라이브러리도, 작업 큐도 쓰지 않는다 —
잡이 여섯 개이고 가장 짧은 주기가 15초다. 복잡도를 들일 자리가 아니다.

| 잡 | 주기 | 안 돌면 |
|---|---|---|
| `partitions` | 1시간 | **월초 자정에 INSERT 가 실패한다** |
| `retention` | 6시간 | 오래된 데이터가 쌓인다 (급하지 않다) |
| `gc` | 5분 | orphan 샌드박스가 자원을 먹는다 |
| `sampler` | 30초 | 게이지 패널이 빈다 |
| `webhooks` | 30초 | 승인 알림이 사람에게 안 닿는다 |
| `deployments` | 15초 | **예약된 배포가 늦게 돈다** |
| `work_reclaim` | 30초 | 죽은 self_hosted 워커의 일이 영원히 `claimed` 다 |

`partitions` 를 매일이 아니라 매시간 도는 이유: 멱등하고 싸다
(`to_regclass` 조회 몇 번). 매일 돌면 그 한 번이 실패했을 때 다음
기회가 24시간 뒤다.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

import anyio

from scheduler.jobs.deployments import fire_due_deployments
from scheduler.jobs.gc import collect_orphans
from scheduler.jobs.partitions import ensure_partitions
from scheduler.jobs.retention import apply_retention
from scheduler.jobs.sampler import sample_gauges
from scheduler.jobs.webhooks import drain_webhooks
from scheduler.jobs.work_reclaim import reclaim_work
from scheduler.leader import leadership

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable

    from scheduler.config import SchedulerConfig

_log = logging.getLogger("scheduler.runner")

#: 잡별 주기(초).
PERIODS: dict[str, float] = {
    "deployments": 15.0,
    "work_reclaim": 30.0,
    "sampler": 30.0,
    "webhooks": 30.0,
    "gc": 300.0,
    "partitions": 3600.0,
    "retention": 21600.0,
}


@dataclass
class Tick:
    """마지막으로 돈 시각을 들고, **때가 됐는지** 판단한다.

    벽시계가 아니라 단조 시계를 쓴다 — NTP 가 시계를 뒤로 돌리면
    벽시계 기준으로는 영영 때가 안 온다.
    """

    periods: dict[str, float]
    _last: dict[str, float] = field(default_factory=dict, init=False)

    def due(self, name: str, at: float) -> bool:
        last = self._last.get(name)
        if last is None or at - last >= self.periods[name]:
            self._last[name] = at
            return True
        return False


@dataclass
class Jobs:
    """돌릴 잡들. **조립이 꽂는다** — 루프는 무엇이 꽂혔는지 모른다.

    `None` 인 잡은 **건너뛴다.** 전부 꽂지 않아도 도는 것이 의도다:
    웹훅 발신자 없이 띄운 개발 스케줄러가 기동 자체를 실패하면 안 된다.
    """

    deployments: Callable[[], Awaitable[Any]] | None = None
    work_reclaim: Callable[[], Awaitable[Any]] | None = None
    sampler: Callable[[], Awaitable[Any]] | None = None
    webhooks: Callable[[], Awaitable[Any]] | None = None
    gc: Callable[[], Awaitable[Any]] | None = None
    partitions: Callable[[], Awaitable[Any]] | None = None
    retention: Callable[[], Awaitable[Any]] | None = None

    def get(self, name: str) -> Callable[[], Awaitable[Any]] | None:
        return getattr(self, name, None)


async def run_once(jobs: Jobs, tick: Tick, at: float) -> tuple[str, ...]:
    """때가 된 잡을 **순서대로** 돈다.

    동시에 안 돌리는 이유: 같은 풀을 쓰고, `partitions` 와 `retention`
    이 같은 테이블의 DDL 을 건드린다. 순서대로 돌면 그 경합이 없다.

    **한 잡의 예외가 나머지를 막지 않는다.** 잡들이 자기 안에서도
    잡지만, 그것이 빠진 잡이 하나 생겨도 루프는 살아 있어야 한다.
    """
    ran: list[str] = []
    for name in PERIODS:
        job = jobs.get(name)
        if job is None or not tick.due(name, at):
            continue
        try:
            await job()
        except Exception as exc:
            _log.warning("잡 %s 실패: %s", name, exc)
        ran.append(name)
    return tuple(ran)


async def run_scheduler(cfg: SchedulerConfig, jobs: Jobs, pool: Any) -> None:
    """리더를 잡고 루프를 돈다. **취소될 때까지.**

    리더가 아니면 틱마다 다시 집어 본다 — 현재 리더 Pod 가 죽으면
    연결이 끊기면서 락이 풀리고, 다음 틱에 우리가 집는다.
    """
    tick = Tick(periods=PERIODS)
    async with leadership(pool) as lead:
        while True:
            if await lead.acquire():
                await run_once(jobs, tick, anyio.current_time())
            await anyio.sleep(cfg.tick_seconds)


def build_jobs(
    cfg: SchedulerConfig,
    pool: Any,
    *,
    deployments: Any = None,
    launcher: Any = None,
    work: Any = None,
    clock: Any = None,
    webhook_sender: Any = None,
    metrics: Any = None,
) -> Jobs:
    """설정 → 돌릴 잡들. **없는 것은 안 꽂는다.**"""
    return Jobs(
        deployments=(
            (lambda: fire_due_deployments(deployments, launcher))
            if deployments is not None and launcher is not None
            else None
        ),
        work_reclaim=(
            (lambda: reclaim_work(work, clock.now()))
            if work is not None and clock is not None
            else None
        ),
        sampler=(lambda: sample_gauges(pool, metrics)) if metrics is not None else None,
        webhooks=((lambda: drain_webhooks(webhook_sender)) if webhook_sender is not None else None),
        gc=lambda: collect_orphans(pool),
        partitions=lambda: ensure_partitions(pool),
        retention=lambda: apply_retention(pool, drop=cfg.retention_drop),
    )


__all__ = ["PERIODS", "Jobs", "Tick", "build_jobs", "run_once", "run_scheduler"]
