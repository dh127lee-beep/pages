"""웹훅 전송 잡 (T-0604).

`plan/04-api.md` §3.8 · `plan/08-infrastructure.md` §9.

**스케줄러가 보낸다.** 세션이 끝나는 경로에서 보내면 수신 측이 느릴
때 턴이 느려지고, 워커가 시크릿을 볼 이유도 없다 (D5) — 유스케이스는
큐에 넣기만 하고 이 잡이 비운다.

리더 선출이 이미 여기 있어 **한 프로세스만 보낸다.** 여럿이 보내면
같은 전송을 중복으로 치고, 수신 측이 멱등하더라도 트래픽이 배로 는다.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ma_adapters_runtime.webhook import DrainReport, WebhookSender

_log = logging.getLogger("scheduler.jobs.webhooks")

#: 한 주기에 보낼 수. 넘으면 다음 주기에.
#:
#: 50인 이유: 30초 주기에 50건이면 초당 1.7건이고, 한 건이 최대
#: 10초(타임아웃)이므로 최악에도 주기 안에 끝난다 — 겹쳐 돌면
#: 같은 전송을 두 번 친다.
BATCH = 50


@dataclass(frozen=True, slots=True)
class WebhookJobResult:
    sent: int = 0
    retried: int = 0
    dead: int = 0
    disabled: int = 0
    failed: str = ""

    @property
    def ok(self) -> bool:
        return not self.failed


async def drain_webhooks(sender: WebhookSender) -> WebhookJobResult:
    """전송 큐를 한 번 비운다.

    **잡을 죽이지 않는다.** 한 번 실패해도 다음 주기에 다시 돈다 —
    여기서 예외를 올리면 스케줄러 루프의 다른 잡까지 멈춘다.
    """
    try:
        report: DrainReport = await sender.drain()
    except Exception as exc:
        _log.warning("웹훅 전송 주기 실패: %s", exc)
        return WebhookJobResult(failed=f"{type(exc).__name__}: {exc}")

    if report.dead:
        # **DLQ 로 간 것이 있다.** 알람이 이것을 본다.
        _log.warning("웹훅 %d건이 DLQ 로 갔다", report.dead)
    if report.disabled:
        _log.warning("410 Gone 으로 엔드포인트 %d개를 껐다", report.disabled)

    return WebhookJobResult(
        sent=report.sent,
        retried=report.retried,
        dead=report.dead,
        disabled=report.disabled,
    )


__all__ = ["BATCH", "WebhookJobResult", "drain_webhooks"]
