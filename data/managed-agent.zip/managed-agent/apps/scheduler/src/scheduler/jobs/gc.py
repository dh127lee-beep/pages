"""GC — orphan 샌드박스와 만료 스냅샷.

`plan/08-infrastructure.md` §9 (알람 7) · `plan/05-database.md` §3 G11.

> **orphan 이 쌓이면 정리 경로가 고장난 것이다.** 알람이 그것을 보고,
> 이 잡이 그것을 막는다.

워커가 죽으면 lease 가 만료되고 다른 워커가 이어받지만, **죽은 워커가
띄워 둔 샌드박스는 아무도 모른다.** `runtime_orphans` 가 그 목록이고,
이 잡이 주기적으로 비운다.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import asyncpg

_log = logging.getLogger("scheduler.jobs.gc")

#: 한 번에 처리할 수. **전부 하지 않는다** — 한 번에 수천 건을 지우면
#: 그 트랜잭션이 길어지고 다른 쓰기를 막는다.
BATCH = 100


@dataclass(frozen=True, slots=True)
class GcResult:
    orphans_seen: int = 0
    orphans_cleared: int = 0
    #: 남은 수. **알람이 보는 숫자다.**
    orphans_remaining: int = 0


async def collect_orphans(
    pool: asyncpg.Pool, *, now: datetime | None = None, batch: int = BATCH
) -> GcResult:
    """정리된 orphan 을 표시한다.

    **실제 샌드박스 종료는 하지 않는다** — 그것은 노드의 일이고,
    스케줄러는 노드에 닿지 않는다. 여기서는 "이미 사라진 것"을
    장부에서 지운다: Pod 가 죽으면 그 안의 샌드박스도 죽었다.
    """
    at = now or datetime.now(UTC)
    async with pool.acquire() as conn:
        try:
            seen = await conn.fetchval(
                "SELECT count(*) FROM runtime_orphans WHERE cleared_at IS NULL"
            )
        except Exception as exc:
            # 테이블이 없을 수 있다 (M6 에서 채워진다). **잡을 죽이지
            # 않는다** — 다른 잡이 같은 루프에서 돈다.
            _log.warning("runtime_orphans 를 읽지 못했다: %s", exc)
            return GcResult()

        cleared = await conn.fetchval(
            """
            WITH picked AS (
              SELECT id FROM runtime_orphans
              WHERE cleared_at IS NULL
              ORDER BY detected_at
              LIMIT $2
            )
            UPDATE runtime_orphans SET cleared_at = $1
            WHERE id IN (SELECT id FROM picked)
            RETURNING 1
            """,
            at,
            batch,
        )
        remaining = await conn.fetchval(
            "SELECT count(*) FROM runtime_orphans WHERE cleared_at IS NULL"
        )

    return GcResult(
        orphans_seen=int(seen or 0),
        orphans_cleared=int(cleared or 0),
        orphans_remaining=int(remaining or 0),
    )


__all__ = ["BATCH", "GcResult", "collect_orphans"]
