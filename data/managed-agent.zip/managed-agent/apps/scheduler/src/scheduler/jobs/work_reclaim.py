"""self_hosted 일 회수 잡 (T-0606).

`plan/04-api.md` §3.3 · `plan/08-infrastructure.md` §9.

`claim` 이 이미 끊긴 일을 회수해 집는다. 그런데 그것은 **누군가
폴링할 때만** 돈다 — 환경의 워커가 전부 죽으면 집힌 일이 영원히
`claimed` 로 남고, `stats` 가 "일하는 중"이라고 거짓말한다.

그 거짓말이 비싼 이유: 운영자가 대시보드를 보고 "워커가 돌고 있구나"
하는데, 실제로는 그 부서의 세션이 전부 멈춰 있다.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING

from ma_domain.environment_work import DEFAULT_LEASE_TTL

if TYPE_CHECKING:
    from datetime import datetime, timedelta

    from ma_store.environment_work import EnvironmentWorkStore

_log = logging.getLogger("scheduler.jobs.work_reclaim")

#: 한 주기에 회수할 수. 넘으면 다음 주기에.
BATCH = 100


@dataclass(frozen=True, slots=True)
class ReclaimResult:
    reclaimed: int = 0
    failed: str = ""

    @property
    def ok(self) -> bool:
        return not self.failed


async def reclaim_work(
    store: EnvironmentWorkStore,
    now: datetime,
    *,
    ttl: timedelta = DEFAULT_LEASE_TTL,
    batch: int = BATCH,
) -> ReclaimResult:
    """끊긴 일을 큐로 되돌린다.

    **잡을 죽이지 않는다.** 한 번 실패해도 다음 주기에 다시 돈다 —
    여기서 예외를 올리면 스케줄러 루프의 다른 잡까지 멈춘다.
    """
    try:
        back = await store.reclaim_stale(now, ttl=ttl, limit=batch)
    except Exception as exc:
        _log.warning("일 회수 실패: %s", exc)
        return ReclaimResult(failed=f"{type(exc).__name__}: {exc}")

    if back:
        # **알람이 이것을 본다.** 회수가 계속 나면 그 환경의 워커가
        # 고장났거나 네트워크가 끊긴 것이다.
        _log.warning(
            "self_hosted 일 %d건을 회수했다: %s",
            len(back),
            sorted({w.environment_id for w in back}),
        )
    return ReclaimResult(reclaimed=len(back))


__all__ = ["BATCH", "ReclaimResult", "reclaim_work"]
