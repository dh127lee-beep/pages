"""보존 — 오래된 파티션과 만료 스냅샷을 지운다.

`plan/05-database.md` §6 · `plan/08-infrastructure.md` §6.

> **보존은 플랫폼이 정하고 부서가 줄일 수 없다** (`plan/05` §6).
> 부서가 줄일 수 있으면 "불리한 기록을 짧게 두는" 길이 생긴다.

**지우는 것은 명시적으로 켰을 때만 한다.** 기본은 보고만 하고
지우지 않는다 — 감사 데이터를 실수로 지우는 경로를 만들지 않는다.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import TYPE_CHECKING

from scheduler.jobs.partitions import PARTITIONED

if TYPE_CHECKING:
    import asyncpg

_log = logging.getLogger("scheduler.jobs.retention")

#: 기본 보존. **법무·보안 합의 전의 잠정값이다** (Q5).
RETENTION_MONTHS = 36


@dataclass(frozen=True, slots=True)
class RetentionResult:
    #: 지웠거나(실행) 지울(드라이런) 파티션.
    expired: tuple[str, ...] = ()
    dropped: tuple[str, ...] = ()

    @property
    def dry_run(self) -> bool:
        return bool(self.expired) and not self.dropped


def _cutoff(now: datetime, months: int) -> str:
    total = now.year * 12 + (now.month - 1) - months
    return f"{total // 12:04d}_{total % 12 + 1:02d}"


async def apply_retention(
    pool: asyncpg.Pool,
    *,
    now: datetime | None = None,
    months: int = RETENTION_MONTHS,
    drop: bool = False,
) -> RetentionResult:
    """보존 기간을 넘긴 파티션을 찾는다. `drop=True` 여야 **지운다.**"""
    at = now or datetime.now(UTC)
    cutoff = _cutoff(at, months)
    expired: list[str] = []
    dropped: list[str] = []

    async with pool.acquire() as conn:
        for table in PARTITIONED:
            rows = await conn.fetch(
                "SELECT tablename FROM pg_tables "
                "WHERE schemaname='public' AND tablename LIKE $1 ORDER BY tablename",
                f"{table}\\_%",
            )
            for row in rows:
                name = str(row["tablename"])
                suffix = name[len(table) + 1 :]
                # `2024_01` 모양만 본다 — 다른 접미사는 우리 것이 아니다.
                if len(suffix) != 7 or suffix[4] != "_":
                    continue
                if suffix >= cutoff:
                    continue
                expired.append(name)
                if drop:
                    await conn.execute(f"DROP TABLE IF EXISTS {name}")
                    dropped.append(name)

    if expired and not drop:
        _log.info(
            "보존 기간을 넘긴 파티션 %d개 (지우지 않았다 — drop=True 필요): %s",
            len(expired),
            ", ".join(expired),
        )
    return RetentionResult(expired=tuple(expired), dropped=tuple(dropped))


__all__ = ["RETENTION_MONTHS", "RetentionResult", "apply_retention"]
