"""월 파티션 선행 생성. `plan/05-database.md` §6.

> **없으면 INSERT 가 실패하고, 그 실패는 월이 바뀌는 자정에 일어난다**
> — 아무도 보고 있지 않을 때다.

그래서 기본이 3개월치다. 한 달을 놓쳐도 두 달이 남는다.

`tools/ensure_partitions.py` 와 **같은 SQL 을 쓴다.** 두 벌을 만들면
수동 실행과 스케줄러가 다른 것을 만들고, 그 차이는 월초에 드러난다.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import asyncpg

_log = logging.getLogger("scheduler.jobs.partitions")

#: 파티션을 가진 테이블. `tools/ensure_partitions.py` 와 같아야 한다.
PARTITIONED = ("audit_log", "usage_events")

#: 앞서 만드는 개월 수.
MONTHS_AHEAD = 3


@dataclass(frozen=True, slots=True)
class PartitionResult:
    created: tuple[str, ...] = ()
    existing: tuple[str, ...] = ()
    failed: tuple[str, ...] = ()

    @property
    def ok(self) -> bool:
        return not self.failed


def month_bounds(start: datetime, count: int) -> list[tuple[str, str, str]]:
    """`(이름, 시작, 끝)` 을 `count` 개월치.

    **UTC 로 자른다.** 로컬 시각으로 자르면 배포 지역에 따라 경계가
    달라지고, 같은 행이 다른 파티션에 들어간다.
    """
    out: list[tuple[str, str, str]] = []
    year, month = start.year, start.month
    for _ in range(count):
        nxt_year, nxt_month = (year + 1, 1) if month == 12 else (year, month + 1)
        out.append(
            (
                f"{year:04d}_{month:02d}",
                f"{year:04d}-{month:02d}-01",
                f"{nxt_year:04d}-{nxt_month:02d}-01",
            )
        )
        year, month = nxt_year, nxt_month
    return out


async def ensure_partitions(
    pool: asyncpg.Pool, *, now: datetime | None = None, months: int = MONTHS_AHEAD
) -> PartitionResult:
    """이번 달부터 `months` 개월치를 만든다. **멱등하다.**

    한 테이블이 실패해도 **나머지를 계속 만든다** — 하나 때문에
    전부 못 만들면 그 달에 쓰기가 멈춘다.
    """
    at = now or datetime.now(UTC)
    created: list[str] = []
    existing: list[str] = []
    failed: list[str] = []

    async with pool.acquire() as conn:
        for table in PARTITIONED:
            for suffix, start, end in month_bounds(at, months):
                name = f"{table}_{suffix}"
                # **명령 태그로는 구분할 수 없다.** `CREATE TABLE IF NOT
                # EXISTS` 는 건너뛸 때도 `CREATE TABLE` 을 돌려준다 —
                # 먼저 물어봐야 "만들었다"와 "있었다"가 갈린다.
                already = await conn.fetchval("SELECT to_regclass($1)", name)
                if already is not None:
                    existing.append(name)
                    continue
                try:
                    await conn.execute(
                        f"CREATE TABLE IF NOT EXISTS {name} PARTITION OF {table} "
                        f"FOR VALUES FROM ('{start}') TO ('{end}')"
                    )
                except Exception as exc:
                    _log.error("파티션 생성 실패 %s: %s", name, exc)
                    failed.append(name)
                    continue
                created.append(name)

    if failed:
        _log.error("파티션 %d개를 만들지 못했다 — 월초에 쓰기가 멈춘다", len(failed))
    return PartitionResult(created=tuple(created), existing=tuple(existing), failed=tuple(failed))


__all__ = ["MONTHS_AHEAD", "PARTITIONED", "PartitionResult", "ensure_partitions", "month_bounds"]
