"""게이지 샘플러 — **대시보드가 비지 않게 한다.**

`plan/08-infrastructure.md` §9 · `IMPL-0029`.

메트릭은 두 종류다:

| | 누가 올리나 | 예 |
|---|---|---|
| 사건 (counter·histogram) | **일어난 곳**에서 | 턴 종료, claim, 사용량 |
| 상태 (gauge) | **주기적으로 재서** | 큐 깊이, 세션 분포, orphan |

상태 쪽을 아무도 재지 않으면 그 패널은 영원히 빈다. 빈 패널은
"문제가 없다"처럼 보이고, 그것이 관측에서 가장 나쁜 실패다.

**스케줄러가 재는 이유**: 워커는 자기 lane 만 알고, 제어 평면은 요청이
와야 돈다. "지금 큐에 몇 개인가"는 **아무 요청과도 무관한 사실**이라
주기 잡이 맞다. 리더 선출이 이미 여기 있어 한 프로세스만 잰다 —
여럿이 재면 같은 gauge 를 서로 덮는다.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import asyncpg
    from ma_observability.metrics import Metrics

_log = logging.getLogger("scheduler.jobs.sampler")

#: 한 번에 볼 워크스페이스 수. `LabelBudget` 과 같은 이유로 상한을 둔다.
MAX_WORKSPACES = 200


@dataclass(frozen=True, slots=True)
class SampleResult:
    workspaces: int = 0
    queued: int = 0
    orphans: int = 0
    failed: tuple[str, ...] = field(default=())

    @property
    def ok(self) -> bool:
        return not self.failed


async def sample_gauges(
    pool: asyncpg.Pool, metrics: Metrics, *, now: datetime | None = None
) -> SampleResult:
    """상태 메트릭을 한 바퀴 잰다.

    **하나가 실패해도 나머지를 잰다.** 한 질의가 느려서 전부 비면
    대시보드가 통째로 빈다 — 부분적으로 채워진 쪽이 낫다.
    """
    at = now or datetime.now(UTC)
    failed: list[str] = []
    queued_total = 0
    orphans_total = 0
    workspaces: set[str] = set()

    async with pool.acquire() as conn:
        # ── 세션 상태 분포 ──
        try:
            rows = await conn.fetch(
                "SELECT workspace_id, status, count(*) AS n FROM sessions "
                "WHERE deleted_at IS NULL GROUP BY workspace_id, status"
            )
            per_ws: dict[str, dict[str, int]] = {}
            for row in rows:
                ws = str(row["workspace_id"])
                per_ws.setdefault(ws, {})[str(row["status"])] = int(row["n"])
            for ws, counts in list(per_ws.items())[:MAX_WORKSPACES]:
                workspaces.add(ws)
                metrics.set_session_counts(ws, counts)
        except Exception as exc:
            _log.warning("세션 분포를 재지 못했다: %s", exc)
            failed.append("session_status")

        # ── 큐 깊이 ──
        try:
            rows = await conn.fetch(
                "SELECT workspace_id, count(*) AS n FROM session_executions "
                "WHERE state = 'queued' GROUP BY workspace_id"
            )
            depths = {str(r["workspace_id"]): int(r["n"]) for r in rows}
            # **0 도 올린다.** 안 올리면 큐가 비었을 때 시계열이 끊기고,
            # 그래프에 구멍이 "장애"처럼 보인다.
            for ws in workspaces | set(depths):
                depth = depths.get(ws, 0)
                queued_total += depth
                metrics.set_queue_depth(ws, depth)
        except Exception as exc:
            _log.warning("큐 깊이를 재지 못했다: %s", exc)
            failed.append("execution_queue_depth")

        # ── 승인 체류 ──
        try:
            rows = await conn.fetch(
                """
                SELECT workspace_id,
                       max(
                         EXTRACT(EPOCH FROM ($1::timestamptz - requested_at))
                         / NULLIF(EXTRACT(EPOCH FROM (expires_at - requested_at)), 0)
                       ) AS ratio
                FROM approvals
                WHERE state = 'pending' AND expires_at IS NOT NULL
                GROUP BY workspace_id
                """,
                at,
            )
            aged = {str(r["workspace_id"]): float(r["ratio"] or 0) for r in rows}
            for ws in workspaces | set(aged):
                metrics.set_oldest_approval_age(ws, ratio=aged.get(ws, 0.0))
        except Exception as exc:
            _log.warning("승인 체류를 재지 못했다: %s", exc)
            failed.append("approval_age_ratio")

        # ── orphan ──
        try:
            orphans_total = int(
                await conn.fetchval("SELECT count(*) FROM runtime_orphans WHERE cleared_at IS NULL")
                or 0
            )
            for ws in workspaces:
                metrics.set_orphans(ws, orphans_total)
        except Exception as exc:
            # 테이블이 M6 에서 채워진다 — **없어도 잡이 죽지 않는다.**
            _log.debug("runtime_orphans 를 읽지 못했다: %s", exc)

    return SampleResult(
        workspaces=len(workspaces),
        queued=queued_total,
        orphans=orphans_total,
        failed=tuple(failed),
    )


__all__ = ["MAX_WORKSPACES", "SampleResult", "sample_gauges"]
