"""배포 발화 잡 (T-0603).

`plan/06-harness-and-model.md` §5.4 · `plan/08-infrastructure.md` §9.

**리더 하나만 발화한다.** 여럿이 돌면 같은 일일 리포트가 두 번 간다 —
`claim_fire` 의 멱등 키가 마지막 방어선이지만, 거기까지 가기 전에
리더 선출이 막는 것이 옳다.

잡이 하는 일은 **집어서 넘기는 것까지**다. 세션을 만들어 돌리는 것은
`SessionLauncher` 가 하고, 그 실패는 **실행 실패로 기록된다** — 안
기록하면 "발화는 했는데 아무 일도 없었다"가 된다.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING, Protocol

from ma_application.deployments import AlreadyRan, Deferred, Fired, Skipped
from ma_domain.deployments import RunState

if TYPE_CHECKING:
    from ma_application.deployments import DeploymentsUseCases
    from ma_domain.deployments import Deployment, DeploymentRun
    from ma_domain.ids import SessionId

_log = logging.getLogger("scheduler.jobs.deployments")

#: 한 주기에 발화할 수. 넘으면 다음 주기에.
#:
#: 50인 이유: 1분 주기에 50건이면, cron 최소 단위가 1분이므로
#: **같은 분에 51번째 배포가 있으면 1분 늦는다.** 그 지연이 문제가
#: 되는 규모면 배치가 아니라 샤딩이 답이다.
BATCH = 50


class SessionLauncher(Protocol):
    """발화된 실행을 실제 세션으로 만든다.

    잡이 이것을 **직접 하지 않는 이유**: 세션 생성은 환경·예산·초기
    이벤트를 엮는 일이고, 그것은 이미 control plane 쪽에 있다. 잡이
    복제하면 두 경로가 갈라진다.
    """

    async def launch(self, deployment: Deployment, run: DeploymentRun) -> SessionId: ...


@dataclass(frozen=True, slots=True)
class DeploymentJobResult:
    fired: int = 0
    deferred: int = 0
    skipped: int = 0
    duplicate: int = 0
    launch_failed: int = 0
    failed: str = ""

    @property
    def ok(self) -> bool:
        return not self.failed


async def fire_due_deployments(
    uc: DeploymentsUseCases, launcher: SessionLauncher, *, batch: int = BATCH
) -> DeploymentJobResult:
    """발화할 때가 된 배포를 한 바퀴 돈다.

    **잡을 죽이지 않는다.** 한 배포가 터져도 나머지는 돈다 — 여기서
    예외를 올리면 스케줄러 루프의 다른 잡까지 멈춘다.
    """
    try:
        due = await uc.due(limit=batch)
    except Exception as exc:
        _log.warning("배포 조회 실패: %s", exc)
        return DeploymentJobResult(failed=f"{type(exc).__name__}: {exc}")

    fired = deferred = skipped = duplicate = launch_failed = 0
    for deployment in due:
        try:
            res = await uc.fire(deployment)
        except Exception as exc:
            # **한 배포의 고장이 나머지를 막지 않는다.**
            _log.warning("배포 %s 발화 실패: %s", deployment.id, exc)
            launch_failed += 1
            continue

        match res:
            case Fired():
                fired += 1
                if not await _launch(uc, launcher, res):
                    launch_failed += 1
            case Deferred(fire_at=at, reason=why):
                deferred += 1
                _log.info("배포 %s 를 %s 로 미뤘다 (%s)", deployment.id, at.isoformat(), why)
            case Skipped(reason=why):
                skipped += 1
                _log.info("배포 %s 를 건너뛰었다 (%s)", deployment.id, why)
            case AlreadyRan():
                # **정상이다** — 리더 교체 중에 겹쳐 집었을 뿐이다.
                duplicate += 1
            case _:
                _log.warning("배포 %s 가 사라졌다", deployment.id)
                launch_failed += 1

    return DeploymentJobResult(
        fired=fired,
        deferred=deferred,
        skipped=skipped,
        duplicate=duplicate,
        launch_failed=launch_failed,
    )


async def _launch(uc: DeploymentsUseCases, launcher: SessionLauncher, res: Fired) -> bool:
    """세션을 만든다. **실패하면 실행을 실패로 닫는다.**

    안 닫으면 그 실행이 `running` 으로 영원히 남고, 겹침 검사가
    그것을 보고 **다음 발화를 전부 건너뛴다** — 배포가 조용히 죽는다.
    """
    try:
        session_id = await launcher.launch(res.deployment, res.run)
    except Exception as exc:
        _log.warning("배포 %s 세션 생성 실패: %s", res.deployment.id, exc)
        await uc.finish(
            res.deployment.workspace_id,
            res.run.id,
            state=RunState.FAILED,
            error=f"세션 생성 실패: {type(exc).__name__}: {exc}",
        )
        return False

    if res.shift.moved:
        _log.info("배포 %s 를 off-peak 로 %s 밀어 돌린다", res.deployment.id, res.shift.shifted_by)
    await uc.attach_session(res.deployment.workspace_id, res.run.id, session_id)
    return True


__all__ = [
    "BATCH",
    "DeploymentJobResult",
    "SessionLauncher",
    "fire_due_deployments",
]
