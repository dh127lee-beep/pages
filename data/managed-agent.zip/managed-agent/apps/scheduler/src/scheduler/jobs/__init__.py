"""스케줄러 잡. **하나가 실패해도 나머지는 돈다.**

`plan/08-infrastructure.md` §9 · `plan/05-database.md` §6.

| 잡 | 주기 | 안 돌면 |
|---|---|---|
| `partitions` | 매일 | **월초 자정에 INSERT 가 실패한다** |
| `retention` | 매일 | 오래된 데이터가 쌓인다 (급하지 않다) |
| `gc` | 5분 | orphan 샌드박스가 자원을 먹는다 |
| `sampler` | 30초 | **게이지 패널이 영원히 빈다** |
| `webhooks` | 30초 | 승인 알림이 사람에게 안 닿는다 |
| `deployments` | 1분 | **예약된 배포가 안 돈다** — cron 최소 단위가 1분이다 |
| `work_reclaim` | 30초 | 죽은 self_hosted 워커의 일이 영원히 `claimed` 로 남는다 |

`partitions` 가 가장 급하다 — 다른 둘은 늦어도 손해가 선형이지만,
파티션은 **없는 순간 쓰기가 멈춘다.**
"""

from scheduler.jobs.deployments import fire_due_deployments
from scheduler.jobs.gc import collect_orphans
from scheduler.jobs.partitions import ensure_partitions
from scheduler.jobs.retention import apply_retention
from scheduler.jobs.sampler import sample_gauges
from scheduler.jobs.webhooks import drain_webhooks
from scheduler.jobs.work_reclaim import reclaim_work

__all__ = [
    "apply_retention",
    "collect_orphans",
    "drain_webhooks",
    "ensure_partitions",
    "fire_due_deployments",
    "reclaim_work",
    "sample_gauges",
]
