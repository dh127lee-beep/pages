---
title: Add Session Resource
url: https://platform.claude.com/docs/en/api/beta/sessions/resources/add
---

# Add Session Resource

**POST** `/v1/sessions/{session_id}/resources`

Add Session Resource

## Path parameters

- `session_id: string`

## Headers

- `"anthropic-version": optional string`

- `"anthropic-beta": optional array of AnthropicBeta`

  Optional header to specify the beta version(s) you want to use. (전체 enum 목록 생략 — Managed Agents는 `managed-agents-2026-04-01`, Dreams는 `dreaming-2026-04-21`, Tunnels는 `mcp-tunnels-2026-06-22`)

- `"anthropic-workspace-id": optional string`

  Optional header to select the Workspace for this request. The value is a Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).

  Only needed for credentials that can act on more than one Workspace. A credential that belongs to a specific Workspace may omit it; if sent, it must match that Workspace.

## Body parameters

- `file_id: string`

  ID of a previously uploaded file.

  minLength: 1, maxLength: 128

- `type: "file"`

- `mount_path: optional string or null`

  Mount path in the container. Defaults to `/mnt/session/uploads/<file_id>`.

  minLength: 1, maxLength: 4096

## Returns

- `BetaManagedAgentsFileResource object`

  - `type: "file"`

  - `id: string`

  - `created_at: string`

    A timestamp in RFC 3339 format

    format: date-time

  - `file_id: string`

  - `mount_path: string`

  - `updated_at: string`

    A timestamp in RFC 3339 format

    format: date-time

## Example

```bash
curl https://api.anthropic.com/v1/sessions/$SESSION_ID/resources \
    -H 'Content-Type: application/json' \
    -H 'anthropic-version: 2023-06-01' \
    -H 'anthropic-beta: managed-agents-2026-04-01' \
    -H "X-Api-Key: $ANTHROPIC_API_KEY" \
    -d '{
          "file_id": "file_011CNha8iCJcU1wXNR6q4V8w",
          "type": "file",
          "mount_path": "/uploads/receipt.pdf"
        }'
```

### Response (200)

```json
{
  "id": "sesrsc_011CZkZBJq5dWxk9fVLNcPht",
  "created_at": "2026-03-15T10:00:00Z",
  "file_id": "file_011CNha8iCJcU1wXNR6q4V8w",
  "mount_path": "/uploads/receipt.pdf",
  "type": "file",
  "updated_at": "2026-03-15T10:00:00Z"
}
```
