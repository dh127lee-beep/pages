---
title: Update Session Resource
url: https://platform.claude.com/docs/en/api/beta/sessions/resources/update
---

# Update Session Resource

**POST** `/v1/sessions/{session_id}/resources/{resource_id}`

Update Session Resource

## Path parameters

- `session_id: string`

- `resource_id: string`

## Headers

- `"anthropic-version": optional string`

- `"anthropic-beta": optional array of AnthropicBeta`

  Optional header to specify the beta version(s) you want to use. (전체 enum 목록 생략 — Managed Agents는 `managed-agents-2026-04-01`, Dreams는 `dreaming-2026-04-21`, Tunnels는 `mcp-tunnels-2026-06-22`)

- `"anthropic-workspace-id": optional string`

  Optional header to select the Workspace for this request. The value is a Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).

  Only needed for credentials that can act on more than one Workspace. A credential that belongs to a specific Workspace may omit it; if sent, it must match that Workspace.

## Body parameters

- `authorization_token: string`

  New authorization token for the resource. Currently only `github_repository` resources support token rotation.

  minLength: 1, maxLength: 4096

## Returns

- `BetaManagedAgentsGitHubRepositoryResource object`

  - `type: "github_repository"`

  - `id: string`

  - `created_at: string`

    A timestamp in RFC 3339 format

    format: date-time

  - `mount_path: string`

  - `updated_at: string`

    A timestamp in RFC 3339 format

    format: date-time

  - `url: string`

  - `checkout: optional BetaManagedAgentsBranchCheckout or BetaManagedAgentsCommitCheckout or null`

    - `BetaManagedAgentsBranchCheckout object`

      - `type: "branch"`

      - `name: string`

        Branch name to check out.

        minLength: 1, maxLength: 255

    - `BetaManagedAgentsCommitCheckout object`

      - `type: "commit"`

      - `sha: string`

        Full commit SHA to check out.

        minLength: 7, maxLength: 64

- `BetaManagedAgentsFileResource object`

  - `type: "file"`

  - `id: string`

  - `created_at: string`

    A timestamp in RFC 3339 format

    format: date-time

  - `file_id: string`

  - `mount_path: string`

  - `updated_at: string`

    A timestamp in RFC 3339 format

    format: date-time

- `BetaManagedAgentsMemoryStoreResource object`

  A memory store attached to an agent session.

  - `type: "memory_store"`

  - `memory_store_id: string`

    The memory store ID (memstore_...). Must belong to the caller's organization and workspace.

  - `access: optional "read_write" or "read_only" or null`

    Access mode for the mounted store. Defaults to `read_write`. `read_only` mounts the store as a read-only filesystem.

    - `"read_write"`

    - `"read_only"`

  - `description: optional string`

    Description of the memory store, snapshotted at attach time. Rendered into the agent's system prompt. Empty string when the store has no description.

  - `instructions: optional string or null`

    Per-attachment guidance for the agent on how to use this store. Rendered into the memory section of the system prompt. Max 4096 chars.

    maxLength: 4096

  - `mount_path: optional string or null`

    Filesystem path where the store is mounted in the session container, e.g. /mnt/memory/user-preferences. Derived from the store's name. Output-only.

  - `name: optional string or null`

    Display name of the memory store, snapshotted at attach time. Later edits to the store's name do not propagate to this resource.

## Example

```bash
curl https://api.anthropic.com/v1/sessions/$SESSION_ID/resources/$RESOURCE_ID \
    -H 'Content-Type: application/json' \
    -H 'anthropic-version: 2023-06-01' \
    -H 'anthropic-beta: managed-agents-2026-04-01' \
    -H "X-Api-Key: $ANTHROPIC_API_KEY" \
    -d '{
          "authorization_token": "ghp_exampletoken"
        }'
```

### Response (200)

```json
{
  "id": "sesrsc_011CZkZCKr6eXym1gWMPdQiu",
  "created_at": "2026-03-15T10:00:00Z",
  "mount_path": "/workspace/example-repo",
  "type": "github_repository",
  "updated_at": "2026-03-15T10:00:00Z",
  "url": "https://github.com/example-org/example-repo",
  "checkout": {
    "name": "main",
    "type": "branch"
  }
}
```
