# Sessions — Domain types

원문: https://platform.claude.com/docs/en/api/beta/sessions



### Beta Managed Agents Advisor Params

- `BetaManagedAgentsAdvisorParams object`

  Platform advisor roster entry: a model the session's primary thread may consult mid-turn. At most one per roster; the entry occupies the roster name `anthropic.advisor`.

  - `type: "advisor"`

  - `model: string`

    A Claude model id. The model must be permitted as an advisor for this agent's model.

    minLength: 1, maxLength: 256

### Beta Managed Agents Agent Message Preview

- `BetaManagedAgentsAgentMessagePreview object`

  - `type: "agent.message"`

  - `id: string`

    The id the buffered agent.message will carry if it is emitted. Matches the event_id on this preview's event_delta events.

### Beta Managed Agents Agent Params

- `BetaManagedAgentsAgentParams object`

  Specification for an Agent. Provide a specific `version` or use the short-form `agent="agent_id"` for the most recent version

  - `type: "agent"`

  - `id: string`

    The `agent` ID.

    minLength: 1, maxLength: 128

  - `version: optional number`

    The specific `agent` version to use. Omit to use the latest version. Must be at least 1 if specified.

    format: int32

### Beta Managed Agents Agent Thinking Preview

- `BetaManagedAgentsAgentThinkingPreview object`

  - `type: "agent.thinking"`

  - `id: string`

    The id the buffered agent.thinking will carry if it is emitted. Start-only — no event_delta events follow.

### Beta Managed Agents Agent With Overrides Params

- `BetaManagedAgentsAgentWithOverridesParams object`

  Reference to an `agent` plus optional configuration overrides. Each provided field replaces the agent's value for the caller's use; the agent resource is unchanged.

  - `type: "agent_with_overrides"`

  - `id: string`

    The `agent` ID.

    minLength: 1, maxLength: 128

  - `mcp_servers: optional array of BetaManagedAgentsURLMCPServerParams`

    Replacement MCP server list. Full replacement: the provided array becomes the MCP servers. Send an empty array to clear; omit to preserve the agent's servers.

    - `type: "url"`

    - `name: string`

      Unique name for this server, referenced by mcp_toolset configurations. 1-255 characters.

      minLength: 1, maxLength: 255

    - `url: string`

      Endpoint URL for the MCP server.

      maxLength: 2048

  - `model: optional BetaManagedAgentsModel or BetaManagedAgentsModelConfigParams`

    Replacement model. Accepts the model string, e.g. `claude-opus-5-5`, or a `model_config` object. Omit to use the agent's model.

    - `BetaManagedAgentsModel = "claude-haiku-5-5" or "claude-sonnet-5-5" or "claude-opus-5-5" or 14 more or string`

      The model that will power your agent.

      See [models](https://docs.anthropic.com/en/docs/models-overview) for additional details and options.

      - `"claude-haiku-5-5"`

        Fastest model for high-volume, real-time tasks

      - `"claude-sonnet-5-5"`

        Efficient model for coding and agents

      - `"claude-opus-5-5"`

        Powerful intelligence for coding, knowledge work, and long-running agents

      - `"claude-fable-5-1"`

        Frontier intelligence for ambitious tasks across coding, scientific discovery, and enterprise workflows

      - `"claude-sonnet-5"`

        Efficient model for coding and agents

      - `"claude-fable-5"`

        Next generation of intelligence for the hardest knowledge work and coding problems

      - `"claude-opus-5"`

        Powerful intelligence for long-running agents and coding

      - `"claude-opus-4-8"`

        Powerful intelligence for long-running agents and coding

      - `"claude-opus-4-7"`

        Powerful intelligence for long-running agents and coding

      - `"claude-opus-4-6"`

        Powerful intelligence for long-running agents and coding

      - `"claude-sonnet-4-6"`

        Best combination of speed and intelligence

      - `"claude-haiku-4-5"`

      - `"claude-haiku-4-5-20251001"`

      - `"claude-opus-4-5"`

        Powerful intelligence for long-running agents and coding

      - `"claude-opus-4-5-20251101"`

        Powerful intelligence for long-running agents and coding

      - `"claude-sonnet-4-5"`

        **Deprecated**: Will reach end-of-life on November 30, 2026. Please migrate to claude-sonnet-5-5. Visit https://docs.anthropic.com/en/docs/resources/model-deprecations for more information.

        High-performance model for agents and coding

      - `"claude-sonnet-4-5-20250929"`

        **Deprecated**: Will reach end-of-life on November 30, 2026. Please migrate to claude-sonnet-5-5. Visit https://docs.anthropic.com/en/docs/resources/model-deprecations for more information.

        High-performance model for agents and coding

      - `string`

    - `BetaManagedAgentsModelConfigParams object`

      An object that defines additional configuration control over model use

      - `id: BetaManagedAgentsModel`

        The model that will power your agent.

        See [models](https://docs.anthropic.com/en/docs/models-overview) for additional details and options.

      - `effort: optional "low" or "medium" or "high" or 2 more or BetaManagedAgentsEffortLow or BetaManagedAgentsEffortMedium or 3 more or null`

        How hard Claude works on each inference call. Accepts a bare level string (`"high"`) or `{"type": "high"}`. On create, omitting it resolves the per-model default; on update, omitting it leaves the stored value unchanged.

        - `"low"`

          Low effort. Favors latency over reasoning depth.

        - `"medium"`

          Medium effort. Balances latency and reasoning depth.

        - `"high"`

          High effort. Favors reasoning depth.

        - `"xhigh"`

          Extra-high effort. Not all models accept this level.

        - `"max"`

          Maximum effort. Favors reasoning depth over latency.

        - `BetaManagedAgentsEffortLow object`

          Low effort. Favors latency over reasoning depth.

          - `type: "low"`

        - `BetaManagedAgentsEffortMedium object`

          Medium effort. Balances latency and reasoning depth.

          - `type: "medium"`

        - `BetaManagedAgentsEffortHigh object`

          High effort. Favors reasoning depth.

          - `type: "high"`

        - `BetaManagedAgentsEffortXhigh object`

          Extra-high effort. Not all models accept this level.

          - `type: "xhigh"`

        - `BetaManagedAgentsEffortMax object`

          Maximum effort. Favors reasoning depth over latency.

          - `type: "max"`

      - `inference_geo: optional string or null`

        Geographic region for model inference. When unset, requests fall through to the workspace's default_inference_geo. On update, `model` is whole-object replacement — omitting inference_geo clears it.

      - `speed: optional "standard" or "fast" or null`

        Inference speed mode. Defaults to `standard`.

        - `"standard"`

        - `"fast"`

  - `skills: optional array of BetaManagedAgentsSkillParams`

    Replacement skill list. Full replacement: the provided array becomes the skills. Send an empty array to clear; omit to preserve the agent's skills.

    - `BetaManagedAgentsAnthropicSkillParams object`

      An Anthropic-managed skill.

      - `type: "anthropic"`

      - `skill_id: string`

        Identifier of the Anthropic skill (e.g., "xlsx").

        minLength: 1, maxLength: 64

      - `version: optional string or null`

        Version to pin. Defaults to latest if omitted.

        minLength: 1, maxLength: 64

    - `BetaManagedAgentsCustomSkillParams object`

      A user-created custom skill.

      - `type: "custom"`

      - `skill_id: string`

        Tagged ID of the custom skill (e.g., "skill_01XJ5...").

        minLength: 1, maxLength: 64

      - `version: optional string or null`

        Version to pin. Defaults to latest if omitted.

        minLength: 1, maxLength: 64

  - `system: optional string or null`

    Replacement system prompt. Up to 100,000 characters. Set to null to clear the agent's system prompt; omit to preserve it.

    maxLength: 100000

  - `tools: optional array of BetaManagedAgentsAgentToolset20260401Params or BetaManagedAgentsMCPToolsetParams or BetaManagedAgentsCustomToolParams`

    Replacement tool list. Full replacement: the provided array becomes the tool configuration. Send an empty array to clear; omit to preserve the agent's tools.

    - `BetaManagedAgentsAgentToolset20260401Params object`

      Configuration for built-in agent tools. Use this to enable or disable groups of tools available to the agent.

      - `type: "agent_toolset_20260401"`

      - `configs: optional array of BetaManagedAgentsAgentToolConfigParams`

        Per-tool configuration overrides.

        - `BetaManagedAgentsBashToolConfigParams object`

          Configuration override for the bash tool.

          - `type: optional "bash"`

          - `name: "bash"`

            Must be "bash".

          - `enabled: optional boolean or null`

            Whether this tool is enabled and available to Claude. Overrides the default_config setting.

          - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

            Permission policy for this tool. Controls whether tool calls are auto-approved or require confirmation.

            - `BetaManagedAgentsAlwaysAllowPolicy object`

              Tool calls are automatically approved without user confirmation.

              - `type: "always_allow"`

            - `BetaManagedAgentsAlwaysAskPolicy object`

              Tool calls require user confirmation before execution.

              - `type: "always_ask"`

            - `BetaManagedAgentsAutoPolicy object`

              The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

              - `type: "auto"`

        - `BetaManagedAgentsEditToolConfigParams object`

          Configuration override for the edit tool.

          - `type: optional "edit"`

          - `name: "edit"`

            Must be "edit".

          - `enabled: optional boolean or null`

            Whether this tool is enabled and available to Claude. Overrides the default_config setting.

          - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

            Permission policy for this tool. Controls whether tool calls are auto-approved or require confirmation.

            - `BetaManagedAgentsAlwaysAllowPolicy object`

              Tool calls are automatically approved without user confirmation.

            - `BetaManagedAgentsAlwaysAskPolicy object`

              Tool calls require user confirmation before execution.

            - `BetaManagedAgentsAutoPolicy object`

              The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

        - `BetaManagedAgentsReadToolConfigParams object`

          Configuration override for the read tool.

          - `type: optional "read"`

          - `name: "read"`

            Must be "read".

          - `enabled: optional boolean or null`

            Whether this tool is enabled and available to Claude. Overrides the default_config setting.

          - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

            Permission policy for this tool. Controls whether tool calls are auto-approved or require confirmation.

            - `BetaManagedAgentsAlwaysAllowPolicy object`

              Tool calls are automatically approved without user confirmation.

            - `BetaManagedAgentsAlwaysAskPolicy object`

              Tool calls require user confirmation before execution.

            - `BetaManagedAgentsAutoPolicy object`

              The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

        - `BetaManagedAgentsWriteToolConfigParams object`

          Configuration override for the write tool.

          - `type: optional "write"`

          - `name: "write"`

            Must be "write".

          - `enabled: optional boolean or null`

            Whether this tool is enabled and available to Claude. Overrides the default_config setting.

          - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

            Permission policy for this tool. Controls whether tool calls are auto-approved or require confirmation.

            - `BetaManagedAgentsAlwaysAllowPolicy object`

              Tool calls are automatically approved without user confirmation.

            - `BetaManagedAgentsAlwaysAskPolicy object`

              Tool calls require user confirmation before execution.

            - `BetaManagedAgentsAutoPolicy object`

              The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

        - `BetaManagedAgentsGlobToolConfigParams object`

          Configuration override for the glob tool.

          - `type: optional "glob"`

          - `name: "glob"`

            Must be "glob".

          - `enabled: optional boolean or null`

            Whether this tool is enabled and available to Claude. Overrides the default_config setting.

          - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

            Permission policy for this tool. Controls whether tool calls are auto-approved or require confirmation.

            - `BetaManagedAgentsAlwaysAllowPolicy object`

              Tool calls are automatically approved without user confirmation.

            - `BetaManagedAgentsAlwaysAskPolicy object`

              Tool calls require user confirmation before execution.

            - `BetaManagedAgentsAutoPolicy object`

              The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

        - `BetaManagedAgentsGrepToolConfigParams object`

          Configuration override for the grep tool.

          - `type: optional "grep"`

          - `name: "grep"`

            Must be "grep".

          - `enabled: optional boolean or null`

            Whether this tool is enabled and available to Claude. Overrides the default_config setting.

          - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

            Permission policy for this tool. Controls whether tool calls are auto-approved or require confirmation.

            - `BetaManagedAgentsAlwaysAllowPolicy object`

              Tool calls are automatically approved without user confirmation.

            - `BetaManagedAgentsAlwaysAskPolicy object`

              Tool calls require user confirmation before execution.

            - `BetaManagedAgentsAutoPolicy object`

              The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

        - `BetaManagedAgentsWebFetchToolConfigParams object`

          Configuration override for the web_fetch tool.

          - `type: optional "web_fetch"`

          - `name: "web_fetch"`

            Must be "web_fetch".

          - `allowed_domains: optional array of string`

            Only fetch URLs whose host is one of these domains or a subdomain of one. Each entry is a plain hostname like "docs.example.com" (no scheme, port, or path). At most 64 entries; an empty list is rejected (omit the field instead). Cannot be combined with blocked_domains.

          - `blocked_domains: optional array of string`

            Never fetch URLs whose host is one of these domains or a subdomain of one. Each entry is a plain hostname like "ads.example.com" (no scheme, port, or path). At most 64 entries; an empty list is rejected (omit the field instead). Cannot be combined with allowed_domains.

          - `enabled: optional boolean or null`

            Whether this tool is enabled and available to Claude. Overrides the default_config setting.

          - `max_content_tokens: optional number or null`

            Maximum number of tokens of fetched text content to include in context per call. Does not apply to binary content such as PDFs.

            format: int32

          - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

            Permission policy for this tool. Controls whether tool calls are auto-approved or require confirmation.

            - `BetaManagedAgentsAlwaysAllowPolicy object`

              Tool calls are automatically approved without user confirmation.

            - `BetaManagedAgentsAlwaysAskPolicy object`

              Tool calls require user confirmation before execution.

            - `BetaManagedAgentsAutoPolicy object`

              The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

          - `url_sources: optional BetaManagedAgentsWebFetchURLSourcesParams or null`

            Which sources contribute URLs the tool may fetch. Omit to allow every source.

            - `client_tool_results: optional BetaManagedAgentsWebFetchURLSourceToolFilterParams or null`

              Which custom tools' results contribute URLs that may be fetched: "all" (the default), "none", or an only or except list. Each name in a list must be a custom tool in the same tools array.

              - `BetaManagedAgentsWebFetchURLSourceShorthand = "all" or "none"`

                String form of a url_sources value that has no field other than its type: "all" means {"type": "all"} and "none" means {"type": "none"}.

                - `"all"`

                - `"none"`

              - `BetaManagedAgentsWebFetchURLSourceToolFilter = BetaManagedAgentsWebFetchURLSourceAll or BetaManagedAgentsWebFetchURLSourceNone or BetaManagedAgentsWebFetchURLSourceOnly or BetaManagedAgentsWebFetchURLSourceExcept`

                Which tools' results contribute URLs that may be fetched.

                - `BetaManagedAgentsWebFetchURLSourceAll object`

                  Every URL from this source may be fetched. This is the default.

                  - `type: "all"`

                - `BetaManagedAgentsWebFetchURLSourceNone object`

                  This source contributes no URLs that may be fetched.

                  - `type: "none"`

                - `BetaManagedAgentsWebFetchURLSourceOnly object`

                  Only the named tools' results contribute URLs that may be fetched.

                  - `type: "only"`

                  - `tools: array of BetaManagedAgentsWebFetchURLSourceToolReference`

                    The tools whose results contribute. Between 1 and 128 entries, each with a different name. An empty list is rejected; use "none" to allow no tool's results.

                    - `type: "tool_reference"`

                      Must be "tool_reference".

                    - `name: string`

                      Name of the tool. Compared exactly, so upper and lower case letters are different.

                      minLength: 1, maxLength: 128

                - `BetaManagedAgentsWebFetchURLSourceExcept object`

                  Every tool's results contribute URLs that may be fetched, except the named tools' results.

                  - `type: "except"`

                  - `tools: array of BetaManagedAgentsWebFetchURLSourceToolReference`

                    The tools whose results do not contribute. Between 1 and 128 entries, each with a different name. An empty list is rejected; use "all" to leave out no tool's results.

                    - `type: "tool_reference"`

                      Must be "tool_reference".

                    - `name: string`

                      Name of the tool. Compared exactly, so upper and lower case letters are different.

                      minLength: 1, maxLength: 128

            - `server_tool_results: optional BetaManagedAgentsWebFetchURLSourceToolFilterParams or null`

              Which of the web_search and web_fetch tools' results contribute URLs that may be fetched: "all" (the default), "none", or an only or except list. Each name in a list must be "web_search" or "web_fetch".

            - `user_input: optional BetaManagedAgentsWebFetchURLSourceUserInputParams or null`

              Whether URLs in the text of user messages may be fetched: "all" (the default) or "none".

              - `BetaManagedAgentsWebFetchURLSourceShorthand = "all" or "none"`

                String form of a url_sources value that has no field other than its type: "all" means {"type": "all"} and "none" means {"type": "none"}.

              - `BetaManagedAgentsWebFetchURLSourceUserInput = BetaManagedAgentsWebFetchURLSourceAll or BetaManagedAgentsWebFetchURLSourceNone`

                Whether URLs in the text of user messages may be fetched.

                - `BetaManagedAgentsWebFetchURLSourceAll object`

                  Every URL from this source may be fetched. This is the default.

                - `BetaManagedAgentsWebFetchURLSourceNone object`

                  This source contributes no URLs that may be fetched.

        - `BetaManagedAgentsWebSearchToolConfigParams object`

          Configuration override for the web_search tool.

          - `type: optional "web_search"`

          - `name: "web_search"`

            Must be "web_search".

          - `allowed_domains: optional array of string`

            Only return search results whose host is one of these domains or a subdomain of one. Each entry is a plain hostname like "docs.example.com" (no scheme or port; an optional path suffix is accepted). At most 64 entries; an empty list is rejected (omit the field instead). Cannot be combined with blocked_domains.

          - `blocked_domains: optional array of string`

            Never return search results whose host is one of these domains or a subdomain of one. Each entry is a plain hostname like "ads.example.com" (no scheme or port; an optional path suffix is accepted). At most 64 entries; an empty list is rejected (omit the field instead). Cannot be combined with allowed_domains.

          - `enabled: optional boolean or null`

            Whether this tool is enabled and available to Claude. Overrides the default_config setting.

          - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

            Permission policy for this tool. Controls whether tool calls are auto-approved or require confirmation.

            - `BetaManagedAgentsAlwaysAllowPolicy object`

              Tool calls are automatically approved without user confirmation.

            - `BetaManagedAgentsAlwaysAskPolicy object`

              Tool calls require user confirmation before execution.

            - `BetaManagedAgentsAutoPolicy object`

              The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

          - `user_location: optional BetaManagedAgentsUserLocation or null`

            Approximate user location for search result localization.

            - `type: "approximate"`

              Location precision. Only "approximate" is supported.

            - `city: optional string or null`

              City name.

              minLength: 1, maxLength: 255

            - `country: optional string or null`

              Two-letter ISO 3166-1 country code, uppercase.

            - `region: optional string or null`

              Region or state name.

              minLength: 1, maxLength: 255

            - `timezone: optional string or null`

              IANA timezone identifier, e.g. "America/Los_Angeles".

              minLength: 1, maxLength: 255

      - `default_config: optional BetaManagedAgentsAgentToolsetDefaultConfigParams or null`

        Default configuration applied to all tools in this set.

        - `enabled: optional boolean or null`

          Whether tools are enabled and available to Claude by default. Defaults to true if not specified.

        - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

          Default permission policy for tools. Controls whether tool calls are auto-approved or require confirmation.

          - `BetaManagedAgentsAlwaysAllowPolicy object`

            Tool calls are automatically approved without user confirmation.

          - `BetaManagedAgentsAlwaysAskPolicy object`

            Tool calls require user confirmation before execution.

          - `BetaManagedAgentsAutoPolicy object`

            The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

    - `BetaManagedAgentsMCPToolsetParams object`

      Configuration for tools from an MCP server defined in `mcp_servers`.

      - `type: "mcp_toolset"`

      - `mcp_server_name: string`

        Name of the MCP server. Must match a server name from the mcp_servers array. 1-255 characters.

        minLength: 1, maxLength: 255

      - `configs: optional array of BetaManagedAgentsMCPToolConfigParams`

        Per-tool configuration overrides.

        - `name: string`

          Name of the MCP tool to configure. 1-128 characters.

          minLength: 1, maxLength: 128

        - `enabled: optional boolean or null`

          Whether this tool is enabled. Overrides the `default_config` setting.

        - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

          Permission policy for this tool. Overrides the `default_config` setting.

          - `BetaManagedAgentsAlwaysAllowPolicy object`

            Tool calls are automatically approved without user confirmation.

          - `BetaManagedAgentsAlwaysAskPolicy object`

            Tool calls require user confirmation before execution.

          - `BetaManagedAgentsAutoPolicy object`

            The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

      - `default_config: optional BetaManagedAgentsMCPToolsetDefaultConfigParams or null`

        Default configuration for all tools from this server.

        - `enabled: optional boolean or null`

          Whether tools are enabled by default. Defaults to true if not specified.

        - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

          Default permission policy for tools from this server.

          - `BetaManagedAgentsAlwaysAllowPolicy object`

            Tool calls are automatically approved without user confirmation.

          - `BetaManagedAgentsAlwaysAskPolicy object`

            Tool calls require user confirmation before execution.

          - `BetaManagedAgentsAutoPolicy object`

            The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

    - `BetaManagedAgentsCustomToolParams object`

      A custom tool that is executed by the API client rather than the agent. When the agent calls this tool, an `agent.custom_tool_use` event is emitted and the session goes idle, waiting for the client to provide the result via a `user.custom_tool_result` event.

      - `type: "custom"`

      - `description: string`

        Description of what the tool does, shown to the agent to help it decide when to use the tool.

        minLength: 1

      - `input_schema: BetaManagedAgentsCustomToolInputSchema`

        JSON Schema defining the expected input parameters for the tool.

        - `type: "object"`

        - `properties: optional map[unknown] or null`

        - `required: optional array of string or null`

      - `name: string`

        Unique name for the tool. 1-128 characters; letters, digits, underscores, and hyphens.

        minLength: 1, maxLength: 128

  - `version: optional number`

    The specific `agent` version to use. Omit to use the latest version.

    format: int32

### Beta Managed Agents Branch Checkout

- `BetaManagedAgentsBranchCheckout object`

  - `type: "branch"`

  - `name: string`

    Branch name to check out.

    minLength: 1, maxLength: 255

### Beta Managed Agents Budget Limit

- `BetaManagedAgentsBudgetLimit object`

  A hard spend ceiling. The session stops issuing new model requests once the tracked list cost reaches `max_list_cost`.

  - `type: "limit"`

  - `max_list_cost: BetaMonetaryAmount`

    Maximum list cost the session may accrue. List price is used regardless of any negotiated discount, so the cap fires at or before the actual charge.

    - `amount: string`

      Amount in minor units of the currency, as an integer decimal string with no leading zeros: "2500" is $25.00 and "50" is fifty cents. A string rather than a number so no float rounding is ever applied.

    - `currency: BetaCurrency`

      Uppercase ISO-4217 currency code. `USD` is the only currency currently supported; the accepted set is closed and grows only when a new currency is priced.

### Beta Managed Agents Cache Creation Usage

- `BetaManagedAgentsCacheCreationUsage object`

  Prompt-cache creation token usage broken down by cache lifetime.

  - `ephemeral_1h_input_tokens: optional number`

    Tokens used to create 1-hour ephemeral cache entries.

    format: int32

  - `ephemeral_5m_input_tokens: optional number`

    Tokens used to create 5-minute ephemeral cache entries.

    format: int32

### Beta Managed Agents Commit Checkout

- `BetaManagedAgentsCommitCheckout object`

  - `type: "commit"`

  - `sha: string`

    Full commit SHA to check out.

    minLength: 7, maxLength: 64

### Beta Managed Agents Deleted Session

- `BetaManagedAgentsDeletedSession object`

  Confirmation that a `session` has been permanently deleted.

  - `type: "session_deleted"`

  - `id: string`

### Beta Managed Agents Delta Content

- `BetaManagedAgentsDeltaContent object`

  - `type: "content_delta"`

  - `content: BetaManagedAgentsTextBlock`

    A partial element of the content array at index, typed like the element itself — the same shape the buffered agent.message carries in content.

    - `type: "text"`

    - `text: string`

      The text content.

      minLength: 1

  - `index: optional number`

    Which entry in the previewed event's content array this fragment lands in. Insert content as that entry when the index is new; append to the existing entry otherwise.

### Beta Managed Agents Delta Event

- `BetaManagedAgentsDeltaEvent object`

  An incremental update to an event that is still being streamed. Deltas are best-effort and may stop early; when the buffered event with id == event_id is produced it carries the complete content. A model request that ends early (an error or interrupt) produces no buffered event — its terminal span.model_request_end closes the preview. Only sent on stream connections that opt in via event_deltas; never appears in event history.

  - `type: "event_delta"`

  - `delta: BetaManagedAgentsDeltaContent`

    One fragment of the previewed event. The delta type is named for the previewed event's field it streams into: agent.message events stream content_delta fragments, each a partial element of the content array.

    - `type: "content_delta"`

    - `content: BetaManagedAgentsTextBlock`

      A partial element of the content array at index, typed like the element itself — the same shape the buffered agent.message carries in content.

      - `type: "text"`

      - `text: string`

        The text content.

        minLength: 1

    - `index: optional number`

      Which entry in the previewed event's content array this fragment lands in. Insert content as that entry when the index is new; append to the existing entry otherwise.

  - `event_id: string`

    The id of the event being previewed. Matches event.id on the corresponding event_start and the buffered event that reconciles the preview.

### Beta Managed Agents Delta Type

- `BetaManagedAgentsDeltaType = "agent.message" or "agent.thinking"`

  - `"agent.message"`

  - `"agent.thinking"`

### Beta Managed Agents File Resource Params

- `BetaManagedAgentsFileResourceParams object`

  Mount a file uploaded via the Files API into the session.

  - `type: "file"`

  - `file_id: string`

    ID of a previously uploaded file.

    minLength: 1, maxLength: 128

  - `mount_path: optional string or null`

    Mount path in the container. Defaults to `/mnt/session/uploads/<file_id>`.

    minLength: 1, maxLength: 4096

### Beta Managed Agents GitHub Repository Resource Params

- `BetaManagedAgentsGitHubRepositoryResourceParams object`

  Mount a GitHub repository into the session's container.

  - `type: "github_repository"`

  - `url: string`

    Github URL of the repository

    minLength: 1, maxLength: 2048

  - `authorization_token: optional string`

    GitHub authorization token used to clone the repository. Required for private repositories; optional for public ones.

    minLength: 1, maxLength: 4096

  - `checkout: optional BetaManagedAgentsBranchCheckout or BetaManagedAgentsCommitCheckout or null`

    Branch or commit to check out. Defaults to the repository's default branch.

    - `BetaManagedAgentsBranchCheckout object`

      - `type: "branch"`

      - `name: string`

        Branch name to check out.

        minLength: 1, maxLength: 255

    - `BetaManagedAgentsCommitCheckout object`

      - `type: "commit"`

      - `sha: string`

        Full commit SHA to check out.

        minLength: 7, maxLength: 64

  - `mount_path: optional string or null`

    Mount path in the container. Defaults to `/workspace/<repo-name>`.

    minLength: 1, maxLength: 4096

### Beta Managed Agents Memory Store Resource Param

- `BetaManagedAgentsMemoryStoreResourceParam object`

  Parameters for attaching a memory store to an agent session.

  - `type: "memory_store"`

  - `memory_store_id: string`

    The memory store ID (memstore_...). Must belong to the caller's organization and workspace.

  - `access: optional "read_write" or "read_only" or null`

    Access mode for the mounted store. Defaults to read_write. read_only mounts the store as a read-only filesystem.

    - `"read_write"`

    - `"read_only"`

  - `instructions: optional string or null`

    Per-attachment guidance for the agent on how to use this store. Rendered into the memory section of the system prompt. Max 4096 chars.

    maxLength: 4096

### Beta Managed Agents Multiagent

- `BetaManagedAgentsMultiagent = BetaManagedAgentsMultiagentCoordinator or BetaManagedAgentsMultiagent20261001`

  Resolved multiagent orchestration configuration as returned in API responses.

  - `BetaManagedAgentsMultiagentCoordinator object`

    Resolved coordinator topology with a concrete agent roster.

    - `type: "coordinator"`

    - `agents: array of BetaManagedAgentsAgentReference or BetaManagedAgentsAdvisor`

      Agents the coordinator may spawn as session threads, each resolved to a specific version.

      - `BetaManagedAgentsAgentReference object`

        A resolved agent reference with a concrete version.

        - `type: "agent"`

        - `id: string`

        - `version: number`

          format: int32

      - `BetaManagedAgentsAdvisor object`

        Platform advisor roster entry: a model the session's primary thread may consult mid-turn.

        - `type: "advisor"`

        - `model: string`

          The advisor model id.

  - `BetaManagedAgentsMultiagent20261001 object`

    Resolved multiagent configuration with three members, each enabled or disabled on its own.

    - `type: "multiagent_20261001"`

    - `advisor: BetaManagedAgentsMultiagentAdvisor`

      Whether the session's primary thread can consult an advisor model.

      - `BetaManagedAgentsMultiagentAdvisorEnabled object`

        The session's primary thread can consult `model` mid-turn.

        - `type: "enabled"`

        - `model: string`

          The advisor model id.

      - `BetaManagedAgentsMultiagentAdvisorDisabled object`

        The agent has no advisor.

        - `type: "disabled"`

    - `subagents: BetaManagedAgentsMultiagentSubagents`

      Whether the agent can spawn session threads.

      - `BetaManagedAgentsMultiagentSubagentsEnabled object`

        The agent can spawn session threads.

        - `type: "enabled"`

        - `inline_agents: BetaManagedAgentsMultiagentInlineAgents`

          Whether the agent can define inline agents, which are not saved, when it spawns session threads.

          - `BetaManagedAgentsMultiagentInlineAgentsEnabled object`

            The agent can define inline agents.

            - `type: "enabled"`

          - `BetaManagedAgentsMultiagentInlineAgentsDisabled object`

            The agent cannot define inline agents.

            - `type: "disabled"`

        - `predefined_agents: array of BetaManagedAgentsAgentReference`

          Predefined agents, which are saved agents that this agent can spawn as session threads, each resolved to a specific version.

          - `type: "agent"`

          - `id: string`

          - `version: number`

            format: int32

      - `BetaManagedAgentsMultiagentSubagentsDisabled object`

        The agent cannot spawn session threads.

        - `type: "disabled"`

    - `workflows: BetaManagedAgentsMultiagentWorkflows`

      Whether the agent can start workflow runs.

      - `BetaManagedAgentsMultiagentWorkflowsEnabled object`

        The agent can start workflow runs.

        - `type: "enabled"`

        - `inline_agents: BetaManagedAgentsMultiagentInlineAgents`

          Whether a run's plan can define inline agents, which are not saved.

        - `predefined_agents: array of BetaManagedAgentsAgentReference`

          Predefined agents, which are saved agents that a run's plan can use, each resolved to a specific version.

          - `type: "agent"`

          - `id: string`

          - `version: number`

            format: int32

      - `BetaManagedAgentsMultiagentWorkflowsDisabled object`

        The agent cannot start workflow runs.

        - `type: "disabled"`

### Beta Managed Agents Multiagent Params

- `BetaManagedAgentsMultiagentParams = BetaManagedAgentsMultiagentCoordinatorParams or BetaManagedAgentsMultiagent20261001Params`

  Multiagent orchestration configuration.

  - `BetaManagedAgentsMultiagentCoordinatorParams object`

    A coordinator topology: the session's primary thread orchestrates work by spawning session threads, each running an agent drawn from the `agents` roster.

    - `type: "coordinator"`

    - `agents: array of BetaManagedAgentsMultiagentRosterEntryParams`

      Agents the coordinator may spawn as session threads. 1–20 entries. Each entry is an agent ID string, a versioned `{"type":"agent","id","version"}` reference, or `{"type":"self"}` to allow recursive self-invocation. Entries must reference distinct agents (after resolving `self` and string forms); at most one `self`. Referenced agents must exist, must not be archived, and must not themselves have `multiagent` set (depth limit 1).

      - `string`

      - `BetaManagedAgentsAgentParams object`

        Specification for an Agent. Provide a specific `version` or use the short-form `agent="agent_id"` for the most recent version

        - `type: "agent"`

        - `id: string`

          The `agent` ID.

          minLength: 1, maxLength: 128

        - `version: optional number`

          The specific `agent` version to use. Omit to use the latest version. Must be at least 1 if specified.

          format: int32

      - `BetaManagedAgentsMultiagentSelfParams object`

        Sentinel roster entry meaning "the agent that owns this configuration". Resolved server-side to a concrete agent reference.

        - `type: "self"`

      - `BetaManagedAgentsAdvisorParams object`

        Platform advisor roster entry: a model the session's primary thread may consult mid-turn. At most one per roster; the entry occupies the roster name `anthropic.advisor`.

        - `type: "advisor"`

        - `model: string`

          A Claude model id. The model must be permitted as an advisor for this agent's model.

          minLength: 1, maxLength: 256

  - `BetaManagedAgentsMultiagent20261001Params object`

    Multiagent configuration with three members, each enabled or disabled on its own. On an update, if the agent's stored `multiagent` also has type `multiagent_20261001`, this configuration is merged into the stored one, level by level, instead of replacing it. A key that the update omits keeps its stored value. A key sent as null takes its default, on create as well, so `"workflows": null` enables workflows. An object sent with a `type` other than the stored one replaces the stored object, and the keys that it omits take their defaults. A `predefined_agents` list that is sent replaces the stored list. Every object that is sent needs its `type`, and an enabled `advisor` needs its `model`. Other validation applies to the merged result.

    - `type: "multiagent_20261001"`

    - `advisor: optional BetaManagedAgentsMultiagentAdvisorParams or null`

      Whether the session's primary thread can consult an advisor model. Defaults to disabled.

      - `BetaManagedAgentsMultiagentAdvisorEnabledParams object`

        The session's primary thread can consult `model` mid-turn.

        - `type: "enabled"`

        - `model: string`

          A Claude model id. The model must be permitted as an advisor for this agent's model.

          minLength: 1, maxLength: 256

      - `BetaManagedAgentsMultiagentAdvisorDisabledParams object`

        The agent has no advisor.

        - `type: "disabled"`

    - `subagents: optional BetaManagedAgentsMultiagentSubagentsParams or null`

      Whether the agent can spawn session threads. Defaults to enabled.

      - `BetaManagedAgentsMultiagentSubagentsEnabledParams object`

        The agent can spawn session threads. Each thread runs a predefined agent, which is a saved agent in `predefined_agents`, or an inline agent, which the agent defines when it spawns the thread and which is not saved. If `inline_agents` is disabled, `predefined_agents` must name at least one agent.

        - `type: "enabled"`

        - `inline_agents: optional BetaManagedAgentsMultiagentInlineAgentsParams or null`

          Whether the agent can define inline agents when it spawns session threads. Defaults to enabled.

          - `BetaManagedAgentsMultiagentInlineAgentsEnabledParams object`

            The agent can define inline agents.

            - `type: "enabled"`

          - `BetaManagedAgentsMultiagentInlineAgentsDisabledParams object`

            The agent cannot define inline agents.

            - `type: "disabled"`

        - `predefined_agents: optional array of BetaManagedAgentsMultiagentPredefinedAgentParams or null`

          Predefined agents that this agent can spawn as session threads. At most 20. Defaults to null. Null and an empty list both mean no predefined agents. This list is separate from `workflows.predefined_agents`, and an agent in one list is not added to the other.

          - `string`

          - `BetaManagedAgentsAgentParams object`

            Specification for an Agent. Provide a specific `version` or use the short-form `agent="agent_id"` for the most recent version

          - `BetaManagedAgentsMultiagentSelfParams object`

            Sentinel roster entry meaning "the agent that owns this configuration". Resolved server-side to a concrete agent reference.

      - `BetaManagedAgentsMultiagentSubagentsDisabledParams object`

        The agent cannot spawn session threads.

        - `type: "disabled"`

    - `workflows: optional BetaManagedAgentsMultiagentWorkflowsParams or null`

      Whether the agent can start workflow runs. Defaults to enabled.

      - `BetaManagedAgentsMultiagentWorkflowsEnabledParams object`

        The agent can start workflow runs. Each run follows a plan, a program that the agent writes. A plan can use predefined agents, which are the saved agents in `predefined_agents`, and inline agents, which it defines itself and which are not saved. If `inline_agents` is disabled, `predefined_agents` must name at least one agent.

        - `type: "enabled"`

        - `inline_agents: optional BetaManagedAgentsMultiagentInlineAgentsParams or null`

          Whether a run's plan can define inline agents. Defaults to enabled.

        - `predefined_agents: optional array of BetaManagedAgentsMultiagentPredefinedAgentParams or null`

          Predefined agents that a run's plan can use. At most 20. Defaults to null. Null and an empty list both mean no predefined agents. This list is separate from `subagents.predefined_agents`, and an agent in one list is not added to the other.

          - `string`

          - `BetaManagedAgentsAgentParams object`

            Specification for an Agent. Provide a specific `version` or use the short-form `agent="agent_id"` for the most recent version

          - `BetaManagedAgentsMultiagentSelfParams object`

            Sentinel roster entry meaning "the agent that owns this configuration". Resolved server-side to a concrete agent reference.

      - `BetaManagedAgentsMultiagentWorkflowsDisabledParams object`

        The agent cannot start workflow runs.

        - `type: "disabled"`

### Beta Managed Agents Multiagent Roster Entry Params

- `BetaManagedAgentsMultiagentRosterEntryParams = string or BetaManagedAgentsAgentParams or BetaManagedAgentsMultiagentSelfParams or BetaManagedAgentsAdvisorParams`

  An entry in a multiagent roster: an agent ID string, a versioned agent reference, or `self`.

  - `string`

  - `BetaManagedAgentsAgentParams object`

    Specification for an Agent. Provide a specific `version` or use the short-form `agent="agent_id"` for the most recent version

    - `type: "agent"`

    - `id: string`

      The `agent` ID.

      minLength: 1, maxLength: 128

    - `version: optional number`

      The specific `agent` version to use. Omit to use the latest version. Must be at least 1 if specified.

      format: int32

  - `BetaManagedAgentsMultiagentSelfParams object`

    Sentinel roster entry meaning "the agent that owns this configuration". Resolved server-side to a concrete agent reference.

    - `type: "self"`

  - `BetaManagedAgentsAdvisorParams object`

    Platform advisor roster entry: a model the session's primary thread may consult mid-turn. At most one per roster; the entry occupies the roster name `anthropic.advisor`.

    - `type: "advisor"`

    - `model: string`

      A Claude model id. The model must be permitted as an advisor for this agent's model.

      minLength: 1, maxLength: 256

### Beta Managed Agents Outcome Evaluation Resource

- `BetaManagedAgentsOutcomeEvaluationResource object`

  Evaluation state for a single outcome defined via a `define_outcome` event.

  - `type: "outcome_evaluation"`

  - `completed_at: string or null`

    When the outcome reached a terminal result. Null while `pending`/`running`/`evaluating`.

    format: date-time

  - `description: string`

    What the agent should produce.

  - `explanation: string or null`

    Grader's verdict text from the most recent evaluation. For `satisfied`, explains why criteria are met; for `needs_revision` (intermediate), what's missing; for `failed`, why unrecoverable.

  - `iteration: number`

    0-indexed revision cycle the outcome is currently on.

    format: int32

  - `outcome_id: string`

    Server-generated outc_ ID for this outcome.

  - `result: string`

    Current evaluation state. `pending` before the agent begins work; `running` while producing or revising; `evaluating` while the grader scores; `satisfied`/`max_iterations_reached`/`failed`/`interrupted` are terminal.

### Beta Managed Agents Server Tool Usage

- `BetaManagedAgentsServerToolUsage object`

  Cumulative count of server-executed tool invocations, broken down by tool.

  - `web_fetch_requests: optional number`

    Number of server-executed web fetch requests.

    format: int32

  - `web_search_requests: optional number`

    Number of server-executed web search requests.

    format: int32

### Beta Managed Agents Session

- `BetaManagedAgentsSession object`

  A Managed Agents `session`.

  - `type: "session"`

  - `id: string`

  - `agent: BetaManagedAgentsSessionAgent`

    Resolved `agent` definition for a `session`. Snapshot of the `agent` at `session` creation time.

    - `type: "agent"`

    - `id: string`

    - `description: string or null`

    - `mcp_servers: array of BetaManagedAgentsMCPServerURLDefinition`

      - `type: "url"`

      - `name: string`

      - `url: string`

    - `model: BetaManagedAgentsModelConfig`

      Model identifier and configuration.

      - `id: BetaManagedAgentsModel`

        The model that will power your agent.

        See [models](https://docs.anthropic.com/en/docs/models-overview) for additional details and options.

        - `"claude-haiku-5-5"`

          Fastest model for high-volume, real-time tasks

        - `"claude-sonnet-5-5"`

          Efficient model for coding and agents

        - `"claude-opus-5-5"`

          Powerful intelligence for coding, knowledge work, and long-running agents

        - `"claude-fable-5-1"`

          Frontier intelligence for ambitious tasks across coding, scientific discovery, and enterprise workflows

        - `"claude-sonnet-5"`

          Efficient model for coding and agents

        - `"claude-fable-5"`

          Next generation of intelligence for the hardest knowledge work and coding problems

        - `"claude-opus-5"`

          Powerful intelligence for long-running agents and coding

        - `"claude-opus-4-8"`

          Powerful intelligence for long-running agents and coding

        - `"claude-opus-4-7"`

          Powerful intelligence for long-running agents and coding

        - `"claude-opus-4-6"`

          Powerful intelligence for long-running agents and coding

        - `"claude-sonnet-4-6"`

          Best combination of speed and intelligence

        - `"claude-haiku-4-5"`

        - `"claude-haiku-4-5-20251001"`

        - `"claude-opus-4-5"`

          Powerful intelligence for long-running agents and coding

        - `"claude-opus-4-5-20251101"`

          Powerful intelligence for long-running agents and coding

        - `"claude-sonnet-4-5"`

          **Deprecated**: Will reach end-of-life on November 30, 2026. Please migrate to claude-sonnet-5-5. Visit https://docs.anthropic.com/en/docs/resources/model-deprecations for more information.

          High-performance model for agents and coding

        - `"claude-sonnet-4-5-20250929"`

          **Deprecated**: Will reach end-of-life on November 30, 2026. Please migrate to claude-sonnet-5-5. Visit https://docs.anthropic.com/en/docs/resources/model-deprecations for more information.

          High-performance model for agents and coding

        - `string`

      - `effort: optional BetaManagedAgentsEffortLow or BetaManagedAgentsEffortMedium or BetaManagedAgentsEffortHigh or 2 more`

        How hard Claude works on each inference call. One of `low`, `medium`, `high`, `xhigh`, `max`. Always present; resolved to the per-model default at save time when not supplied.

        - `BetaManagedAgentsEffortLow object`

          Low effort. Favors latency over reasoning depth.

          - `type: "low"`

        - `BetaManagedAgentsEffortMedium object`

          Medium effort. Balances latency and reasoning depth.

          - `type: "medium"`

        - `BetaManagedAgentsEffortHigh object`

          High effort. Favors reasoning depth.

          - `type: "high"`

        - `BetaManagedAgentsEffortXhigh object`

          Extra-high effort. Not all models accept this level.

          - `type: "xhigh"`

        - `BetaManagedAgentsEffortMax object`

          Maximum effort. Favors reasoning depth over latency.

          - `type: "max"`

      - `inference_geo: optional string`

        Geographic region for model inference. When unset, requests fall through to the workspace's default_inference_geo.

      - `speed: optional "standard" or "fast"`

        Inference speed mode. `fast` provides significantly faster output token generation at premium pricing. Defaults to `standard`. Not all models support `fast`; invalid combinations are rejected at create time.

        - `"standard"`

        - `"fast"`

    - `multiagent: BetaManagedAgentsSessionMultiagent or null`

      Resolved multiagent orchestration configuration. Null when the agent is single-threaded.

      - `BetaManagedAgentsSessionMultiagentCoordinator object`

        Resolved coordinator topology with full agent definitions for each roster member.

        - `type: "coordinator"`

        - `agents: array of BetaManagedAgentsSessionThreadAgent or BetaManagedAgentsAdvisor`

          Full `agent` definitions the coordinator may spawn as session threads.

          - `BetaManagedAgentsSessionThreadAgent object`

            Resolved `agent` definition for a single `session_thread`. Snapshot of the agent at thread creation time. The multiagent roster is not repeated here; read it from `Session.agent`.

            - `type: "agent"`

            - `id: string`

            - `description: string or null`

            - `mcp_servers: array of BetaManagedAgentsMCPServerURLDefinition`

              - `type: "url"`

              - `name: string`

              - `url: string`

            - `model: BetaManagedAgentsModelConfig`

              Model identifier and configuration.

            - `name: string`

            - `skills: array of BetaManagedAgentsAnthropicSkill or BetaManagedAgentsCustomSkill`

              - `BetaManagedAgentsAnthropicSkill object`

                A resolved Anthropic-managed skill.

                - `type: "anthropic"`

                - `skill_id: string`

                - `version: string`

              - `BetaManagedAgentsCustomSkill object`

                A resolved user-created custom skill.

                - `type: "custom"`

                - `skill_id: string`

                - `version: string`

            - `system: string or null`

            - `tools: array of BetaManagedAgentsAgentToolset20260401 or BetaManagedAgentsMCPToolset or BetaManagedAgentsCustomTool`

              - `BetaManagedAgentsAgentToolset20260401 object`

                - `type: "agent_toolset_20260401"`

                - `configs: array of BetaManagedAgentsAgentToolConfig`

                  - `BetaManagedAgentsBashToolConfig object`

                    Configuration for the bash tool.

                    - `type: "bash"`

                    - `enabled: boolean`

                    - `name: "bash"`

                    - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                      Permission policy for tool execution.

                      - `BetaManagedAgentsAlwaysAllowPolicy object`

                        Tool calls are automatically approved without user confirmation.

                        - `type: "always_allow"`

                      - `BetaManagedAgentsAlwaysAskPolicy object`

                        Tool calls require user confirmation before execution.

                        - `type: "always_ask"`

                      - `BetaManagedAgentsAutoPolicy object`

                        The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

                        - `type: "auto"`

                  - `BetaManagedAgentsEditToolConfig object`

                    Configuration for the edit tool.

                    - `type: "edit"`

                    - `enabled: boolean`

                    - `name: "edit"`

                    - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                      Permission policy for tool execution.

                      - `BetaManagedAgentsAlwaysAllowPolicy object`

                        Tool calls are automatically approved without user confirmation.

                      - `BetaManagedAgentsAlwaysAskPolicy object`

                        Tool calls require user confirmation before execution.

                      - `BetaManagedAgentsAutoPolicy object`

                        The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

                  - `BetaManagedAgentsReadToolConfig object`

                    Configuration for the read tool.

                    - `type: "read"`

                    - `enabled: boolean`

                    - `name: "read"`

                    - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                      Permission policy for tool execution.

                      - `BetaManagedAgentsAlwaysAllowPolicy object`

                        Tool calls are automatically approved without user confirmation.

                      - `BetaManagedAgentsAlwaysAskPolicy object`

                        Tool calls require user confirmation before execution.

                      - `BetaManagedAgentsAutoPolicy object`

                        The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

                  - `BetaManagedAgentsWriteToolConfig object`

                    Configuration for the write tool.

                    - `type: "write"`

                    - `enabled: boolean`

                    - `name: "write"`

                    - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                      Permission policy for tool execution.

                      - `BetaManagedAgentsAlwaysAllowPolicy object`

                        Tool calls are automatically approved without user confirmation.

                      - `BetaManagedAgentsAlwaysAskPolicy object`

                        Tool calls require user confirmation before execution.

                      - `BetaManagedAgentsAutoPolicy object`

                        The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

                  - `BetaManagedAgentsGlobToolConfig object`

                    Configuration for the glob tool.

                    - `type: "glob"`

                    - `enabled: boolean`

                    - `name: "glob"`

                    - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                      Permission policy for tool execution.

                      - `BetaManagedAgentsAlwaysAllowPolicy object`

                        Tool calls are automatically approved without user confirmation.

                      - `BetaManagedAgentsAlwaysAskPolicy object`

                        Tool calls require user confirmation before execution.

                      - `BetaManagedAgentsAutoPolicy object`

                        The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

                  - `BetaManagedAgentsGrepToolConfig object`

                    Configuration for the grep tool.

                    - `type: "grep"`

                    - `enabled: boolean`

                    - `name: "grep"`

                    - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                      Permission policy for tool execution.

                      - `BetaManagedAgentsAlwaysAllowPolicy object`

                        Tool calls are automatically approved without user confirmation.

                      - `BetaManagedAgentsAlwaysAskPolicy object`

                        Tool calls require user confirmation before execution.

                      - `BetaManagedAgentsAutoPolicy object`

                        The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

                  - `BetaManagedAgentsWebFetchToolConfig object`

                    Configuration for the web_fetch tool.

                    - `type: "web_fetch"`

                    - `enabled: boolean`

                    - `name: "web_fetch"`

                    - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                      Permission policy for tool execution.

                      - `BetaManagedAgentsAlwaysAllowPolicy object`

                        Tool calls are automatically approved without user confirmation.

                      - `BetaManagedAgentsAlwaysAskPolicy object`

                        Tool calls require user confirmation before execution.

                      - `BetaManagedAgentsAutoPolicy object`

                        The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

                    - `url_sources: BetaManagedAgentsWebFetchURLSources or null`

                      Which sources contribute URLs the tool may fetch, always in the object form. Null when not set, which allows every source.

                      - `client_tool_results: BetaManagedAgentsWebFetchURLSourceToolFilter or null`

                        Which custom tools' results contribute URLs that may be fetched. Null when not set, which allows every custom tool's results.

                        - `BetaManagedAgentsWebFetchURLSourceAll object`

                          Every URL from this source may be fetched. This is the default.

                          - `type: "all"`

                        - `BetaManagedAgentsWebFetchURLSourceNone object`

                          This source contributes no URLs that may be fetched.

                          - `type: "none"`

                        - `BetaManagedAgentsWebFetchURLSourceOnly object`

                          Only the named tools' results contribute URLs that may be fetched.

                          - `type: "only"`

                          - `tools: array of BetaManagedAgentsWebFetchURLSourceToolReference`

                            The tools whose results contribute. Between 1 and 128 entries, each with a different name. An empty list is rejected; use "none" to allow no tool's results.

                            - `type: "tool_reference"`

                              Must be "tool_reference".

                            - `name: string`

                              Name of the tool. Compared exactly, so upper and lower case letters are different.

                              minLength: 1, maxLength: 128

                        - `BetaManagedAgentsWebFetchURLSourceExcept object`

                          Every tool's results contribute URLs that may be fetched, except the named tools' results.

                          - `type: "except"`

                          - `tools: array of BetaManagedAgentsWebFetchURLSourceToolReference`

                            The tools whose results do not contribute. Between 1 and 128 entries, each with a different name. An empty list is rejected; use "all" to leave out no tool's results.

                            - `type: "tool_reference"`

                              Must be "tool_reference".

                            - `name: string`

                              Name of the tool. Compared exactly, so upper and lower case letters are different.

                              minLength: 1, maxLength: 128

                      - `server_tool_results: BetaManagedAgentsWebFetchURLSourceToolFilter or null`

                        Which of the web_search and web_fetch tools' results contribute URLs that may be fetched. Null when not set, which allows both.

                      - `user_input: BetaManagedAgentsWebFetchURLSourceUserInput or null`

                        Whether URLs in the text of user messages may be fetched. Null when not set, which allows them.

                        - `BetaManagedAgentsWebFetchURLSourceAll object`

                          Every URL from this source may be fetched. This is the default.

                        - `BetaManagedAgentsWebFetchURLSourceNone object`

                          This source contributes no URLs that may be fetched.

                    - `allowed_domains: optional array of string`

                    - `blocked_domains: optional array of string`

                    - `max_content_tokens: optional number or null`

                      format: int32

                  - `BetaManagedAgentsWebSearchToolConfig object`

                    Configuration for the web_search tool.

                    - `type: "web_search"`

                    - `enabled: boolean`

                    - `name: "web_search"`

                    - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                      Permission policy for tool execution.

                      - `BetaManagedAgentsAlwaysAllowPolicy object`

                        Tool calls are automatically approved without user confirmation.

                      - `BetaManagedAgentsAlwaysAskPolicy object`

                        Tool calls require user confirmation before execution.

                      - `BetaManagedAgentsAutoPolicy object`

                        The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

                    - `allowed_domains: optional array of string`

                    - `blocked_domains: optional array of string`

                    - `user_location: optional BetaManagedAgentsUserLocation or null`

                      Approximate user location for search result localization.

                      - `type: "approximate"`

                        Location precision. Only "approximate" is supported.

                      - `city: optional string or null`

                        City name.

                        minLength: 1, maxLength: 255

                      - `country: optional string or null`

                        Two-letter ISO 3166-1 country code, uppercase.

                      - `region: optional string or null`

                        Region or state name.

                        minLength: 1, maxLength: 255

                      - `timezone: optional string or null`

                        IANA timezone identifier, e.g. "America/Los_Angeles".

                        minLength: 1, maxLength: 255

                - `default_config: BetaManagedAgentsAgentToolsetDefaultConfig`

                  Resolved default configuration for agent tools.

                  - `enabled: boolean`

                  - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                    Permission policy for tool execution.

                    - `BetaManagedAgentsAlwaysAllowPolicy object`

                      Tool calls are automatically approved without user confirmation.

                    - `BetaManagedAgentsAlwaysAskPolicy object`

                      Tool calls require user confirmation before execution.

                    - `BetaManagedAgentsAutoPolicy object`

                      The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

              - `BetaManagedAgentsMCPToolset object`

                - `type: "mcp_toolset"`

                - `configs: array of BetaManagedAgentsMCPToolConfig`

                  - `enabled: boolean`

                  - `name: string`

                  - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                    Permission policy for tool execution.

                    - `BetaManagedAgentsAlwaysAllowPolicy object`

                      Tool calls are automatically approved without user confirmation.

                    - `BetaManagedAgentsAlwaysAskPolicy object`

                      Tool calls require user confirmation before execution.

                    - `BetaManagedAgentsAutoPolicy object`

                      The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

                - `default_config: BetaManagedAgentsMCPToolsetDefaultConfig`

                  Resolved default configuration for all tools from an MCP server.

                  - `enabled: boolean`

                  - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                    Permission policy for tool execution.

                    - `BetaManagedAgentsAlwaysAllowPolicy object`

                      Tool calls are automatically approved without user confirmation.

                    - `BetaManagedAgentsAlwaysAskPolicy object`

                      Tool calls require user confirmation before execution.

                    - `BetaManagedAgentsAutoPolicy object`

                      The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

                - `mcp_server_name: string`

              - `BetaManagedAgentsCustomTool object`

                A custom tool as returned in API responses.

                - `type: "custom"`

                - `description: string`

                - `input_schema: BetaManagedAgentsCustomToolInputSchema`

                  JSON Schema for custom tool input parameters.

                  - `type: "object"`

                  - `properties: optional map[unknown] or null`

                  - `required: optional array of string or null`

                - `name: string`

            - `version: number`

              format: int32

          - `BetaManagedAgentsAdvisor object`

            Platform advisor roster entry: a model the session's primary thread may consult mid-turn.

            - `type: "advisor"`

            - `model: string`

              The advisor model id.

      - `BetaManagedAgentsSessionMultiagent20261001 object`

        Resolved multiagent configuration with three members, as copied to the `session` at creation.

        - `type: "multiagent_20261001"`

        - `advisor: BetaManagedAgentsMultiagentAdvisor`

          Whether the session's primary thread can consult an advisor model.

          - `BetaManagedAgentsMultiagentAdvisorEnabled object`

            The session's primary thread can consult `model` mid-turn.

            - `type: "enabled"`

            - `model: string`

              The advisor model id.

          - `BetaManagedAgentsMultiagentAdvisorDisabled object`

            The agent has no advisor.

            - `type: "disabled"`

        - `subagents: BetaManagedAgentsSessionMultiagentSubagents`

          Whether the agent can spawn session threads.

          - `BetaManagedAgentsSessionMultiagentSubagentsEnabled object`

            The agent can spawn session threads.

            - `type: "enabled"`

            - `inline_agents: BetaManagedAgentsMultiagentInlineAgents`

              Whether the agent can define inline agents, which are not saved, when it spawns session threads.

              - `BetaManagedAgentsMultiagentInlineAgentsEnabled object`

                The agent can define inline agents.

                - `type: "enabled"`

              - `BetaManagedAgentsMultiagentInlineAgentsDisabled object`

                The agent cannot define inline agents.

                - `type: "disabled"`

            - `predefined_agents: array of BetaManagedAgentsSessionThreadAgent`

              Full `agent` definitions of the predefined agents, which are saved agents that this agent can spawn as session threads.

              - `type: "agent"`

              - `id: string`

              - `description: string or null`

              - `mcp_servers: array of BetaManagedAgentsMCPServerURLDefinition`

              - `model: BetaManagedAgentsModelConfig`

                Model identifier and configuration.

              - `name: string`

              - `skills: array of BetaManagedAgentsAnthropicSkill or BetaManagedAgentsCustomSkill`

              - `system: string or null`

              - `tools: array of BetaManagedAgentsAgentToolset20260401 or BetaManagedAgentsMCPToolset or BetaManagedAgentsCustomTool`

              - `version: number`

                format: int32

          - `BetaManagedAgentsMultiagentSubagentsDisabled object`

            The agent cannot spawn session threads.

            - `type: "disabled"`

        - `workflows: BetaManagedAgentsSessionMultiagentWorkflows`

          Whether the agent can start workflow runs.

          - `BetaManagedAgentsSessionMultiagentWorkflowsEnabled object`

            The agent can start workflow runs.

            - `type: "enabled"`

            - `inline_agents: BetaManagedAgentsMultiagentInlineAgents`

              Whether a run's plan can define inline agents, which are not saved.

            - `predefined_agents: array of BetaManagedAgentsSessionThreadAgent`

              Full `agent` definitions of the predefined agents, which are saved agents that a run's plan can use.

              - `type: "agent"`

              - `id: string`

              - `description: string or null`

              - `mcp_servers: array of BetaManagedAgentsMCPServerURLDefinition`

              - `model: BetaManagedAgentsModelConfig`

                Model identifier and configuration.

              - `name: string`

              - `skills: array of BetaManagedAgentsAnthropicSkill or BetaManagedAgentsCustomSkill`

              - `system: string or null`

              - `tools: array of BetaManagedAgentsAgentToolset20260401 or BetaManagedAgentsMCPToolset or BetaManagedAgentsCustomTool`

              - `version: number`

                format: int32

          - `BetaManagedAgentsMultiagentWorkflowsDisabled object`

            The agent cannot start workflow runs.

            - `type: "disabled"`

    - `name: string`

    - `skills: array of BetaManagedAgentsAnthropicSkill or BetaManagedAgentsCustomSkill`

      - `BetaManagedAgentsAnthropicSkill object`

        A resolved Anthropic-managed skill.

      - `BetaManagedAgentsCustomSkill object`

        A resolved user-created custom skill.

    - `system: string or null`

    - `tools: array of BetaManagedAgentsAgentToolset20260401 or BetaManagedAgentsMCPToolset or BetaManagedAgentsCustomTool`

      - `BetaManagedAgentsAgentToolset20260401 object`

      - `BetaManagedAgentsMCPToolset object`

      - `BetaManagedAgentsCustomTool object`

        A custom tool as returned in API responses.

    - `version: number`

      format: int32

  - `archived_at: string or null`

    When the session was archived. Null if not archived.

    format: date-time

  - `budget: BetaManagedAgentsBudgetLimit or null`

    The session's enforced spend ceiling, or null when no budget is set.

    - `type: "limit"`

    - `max_list_cost: BetaMonetaryAmount`

      Maximum list cost the session may accrue. List price is used regardless of any negotiated discount, so the cap fires at or before the actual charge.

      - `amount: string`

        Amount in minor units of the currency, as an integer decimal string with no leading zeros: "2500" is $25.00 and "50" is fifty cents. A string rather than a number so no float rounding is ever applied.

      - `currency: BetaCurrency`

        Uppercase ISO-4217 currency code. `USD` is the only currency currently supported; the accepted set is closed and grows only when a new currency is priced.

  - `created_at: string`

    A timestamp in RFC 3339 format

    format: date-time

  - `environment_id: string`

  - `metadata: map[string]`

  - `outcome_evaluations: array of BetaManagedAgentsOutcomeEvaluationResource`

    Per-outcome evaluation state. One entry per `define_outcome` event sent to the session.

    - `type: "outcome_evaluation"`

    - `completed_at: string or null`

      When the outcome reached a terminal result. Null while `pending`/`running`/`evaluating`.

      format: date-time

    - `description: string`

      What the agent should produce.

    - `explanation: string or null`

      Grader's verdict text from the most recent evaluation. For `satisfied`, explains why criteria are met; for `needs_revision` (intermediate), what's missing; for `failed`, why unrecoverable.

    - `iteration: number`

      0-indexed revision cycle the outcome is currently on.

      format: int32

    - `outcome_id: string`

      Server-generated outc_ ID for this outcome.

    - `result: string`

      Current evaluation state. `pending` before the agent begins work; `running` while producing or revising; `evaluating` while the grader scores; `satisfied`/`max_iterations_reached`/`failed`/`interrupted` are terminal.

  - `resources: array of BetaManagedAgentsSessionResource`

    - `BetaManagedAgentsGitHubRepositoryResource object`

      - `type: "github_repository"`

      - `id: string`

      - `created_at: string`

        A timestamp in RFC 3339 format

        format: date-time

      - `mount_path: string`

      - `updated_at: string`

        A timestamp in RFC 3339 format

        format: date-time

      - `url: string`

      - `checkout: optional BetaManagedAgentsBranchCheckout or BetaManagedAgentsCommitCheckout or null`

        - `BetaManagedAgentsBranchCheckout object`

          - `type: "branch"`

          - `name: string`

            Branch name to check out.

            minLength: 1, maxLength: 255

        - `BetaManagedAgentsCommitCheckout object`

          - `type: "commit"`

          - `sha: string`

            Full commit SHA to check out.

            minLength: 7, maxLength: 64

    - `BetaManagedAgentsFileResource object`

      - `type: "file"`

      - `id: string`

      - `created_at: string`

        A timestamp in RFC 3339 format

        format: date-time

      - `file_id: string`

      - `mount_path: string`

      - `updated_at: string`

        A timestamp in RFC 3339 format

        format: date-time

    - `BetaManagedAgentsMemoryStoreResource object`

      A memory store attached to an agent session.

      - `type: "memory_store"`

      - `memory_store_id: string`

        The memory store ID (memstore_...). Must belong to the caller's organization and workspace.

      - `access: optional "read_write" or "read_only" or null`

        Access mode for the mounted store. Defaults to `read_write`. `read_only` mounts the store as a read-only filesystem.

        - `"read_write"`

        - `"read_only"`

      - `description: optional string`

        Description of the memory store, snapshotted at attach time. Rendered into the agent's system prompt. Empty string when the store has no description.

      - `instructions: optional string or null`

        Per-attachment guidance for the agent on how to use this store. Rendered into the memory section of the system prompt. Max 4096 chars.

        maxLength: 4096

      - `mount_path: optional string or null`

        Filesystem path where the store is mounted in the session container, e.g. /mnt/memory/user-preferences. Derived from the store's name. Output-only.

      - `name: optional string or null`

        Display name of the memory store, snapshotted at attach time. Later edits to the store's name do not propagate to this resource.

  - `stats: BetaManagedAgentsSessionStats`

    Timing statistics for the session.

    - `active_seconds: optional number`

      Cumulative time in seconds the session spent in `running` status. Excludes idle time.

      format: double

    - `duration_seconds: optional number`

      Elapsed time since session creation in seconds. For terminated sessions, frozen at the final update.

      format: double

  - `status: "rescheduling" or "running" or "idle" or "terminated"`

    - `"rescheduling"`

      Transient error occurred, retrying automatically.

    - `"running"`

      Agent is actively executing.

    - `"idle"`

      Agent is waiting for input, including user messages or tool confirmations. Sessions start in idle.

    - `"terminated"`

      Session has ended, either due to an error or completion.

  - `title: string or null`

  - `updated_at: string`

    A timestamp in RFC 3339 format

    format: date-time

  - `usage: BetaManagedAgentsSessionUsage`

    Cumulative token usage for the session.

    - `active_seconds: optional number`

      Cumulative time in seconds during which the session had at least one thread in running status. Overlapping activity from concurrent threads is counted once, unlike `stats.active_seconds`, which sums each thread's own active time. This is the duration the session's runtime cost is priced on.

      format: double

    - `cache_creation: optional BetaManagedAgentsCacheCreationUsage`

      Tokens used to create prompt cache entries, broken down by cache TTL.

      - `ephemeral_1h_input_tokens: optional number`

        Tokens used to create 1-hour ephemeral cache entries.

        format: int32

      - `ephemeral_5m_input_tokens: optional number`

        Tokens used to create 5-minute ephemeral cache entries.

        format: int32

    - `cache_read_input_tokens: optional number`

      Total tokens read from prompt cache.

      format: int32

    - `input_tokens: optional number`

      Total input tokens consumed across all turns.

      format: int32

    - `list_cost: optional BetaMonetaryAmount or null`

      Cumulative list cost of the session across all turns, priced at public list rates. Absent until cost tracking is available for the session.

    - `output_tokens: optional number`

      Total output tokens generated across all turns.

      format: int32

    - `server_tool_use: optional BetaManagedAgentsServerToolUsage or null`

      Cumulative server-executed tool usage across all turns. Absent until server-tool tracking is available for the session.

      - `web_fetch_requests: optional number`

        Number of server-executed web fetch requests.

        format: int32

      - `web_search_requests: optional number`

        Number of server-executed web search requests.

        format: int32

  - `vault_ids: array of string`

    Vault IDs attached to the session at creation. Empty when no vaults were supplied.

  - `deployment_id: optional string or null`

    Deployment ID when the session was created from a deployment reference. Null otherwise.

### Beta Managed Agents Session Agent

- `BetaManagedAgentsSessionAgent object`

  Resolved `agent` definition for a `session`. Snapshot of the `agent` at `session` creation time.

  - `type: "agent"`

  - `id: string`

  - `description: string or null`

  - `mcp_servers: array of BetaManagedAgentsMCPServerURLDefinition`

    - `type: "url"`

    - `name: string`

    - `url: string`

  - `model: BetaManagedAgentsModelConfig`

    Model identifier and configuration.

    - `id: BetaManagedAgentsModel`

      The model that will power your agent.

      See [models](https://docs.anthropic.com/en/docs/models-overview) for additional details and options.

      - `"claude-haiku-5-5"`

        Fastest model for high-volume, real-time tasks

      - `"claude-sonnet-5-5"`

        Efficient model for coding and agents

      - `"claude-opus-5-5"`

        Powerful intelligence for coding, knowledge work, and long-running agents

      - `"claude-fable-5-1"`

        Frontier intelligence for ambitious tasks across coding, scientific discovery, and enterprise workflows

      - `"claude-sonnet-5"`

        Efficient model for coding and agents

      - `"claude-fable-5"`

        Next generation of intelligence for the hardest knowledge work and coding problems

      - `"claude-opus-5"`

        Powerful intelligence for long-running agents and coding

      - `"claude-opus-4-8"`

        Powerful intelligence for long-running agents and coding

      - `"claude-opus-4-7"`

        Powerful intelligence for long-running agents and coding

      - `"claude-opus-4-6"`

        Powerful intelligence for long-running agents and coding

      - `"claude-sonnet-4-6"`

        Best combination of speed and intelligence

      - `"claude-haiku-4-5"`

      - `"claude-haiku-4-5-20251001"`

      - `"claude-opus-4-5"`

        Powerful intelligence for long-running agents and coding

      - `"claude-opus-4-5-20251101"`

        Powerful intelligence for long-running agents and coding

      - `"claude-sonnet-4-5"`

        **Deprecated**: Will reach end-of-life on November 30, 2026. Please migrate to claude-sonnet-5-5. Visit https://docs.anthropic.com/en/docs/resources/model-deprecations for more information.

        High-performance model for agents and coding

      - `"claude-sonnet-4-5-20250929"`

        **Deprecated**: Will reach end-of-life on November 30, 2026. Please migrate to claude-sonnet-5-5. Visit https://docs.anthropic.com/en/docs/resources/model-deprecations for more information.

        High-performance model for agents and coding

      - `string`

    - `effort: optional BetaManagedAgentsEffortLow or BetaManagedAgentsEffortMedium or BetaManagedAgentsEffortHigh or 2 more`

      How hard Claude works on each inference call. One of `low`, `medium`, `high`, `xhigh`, `max`. Always present; resolved to the per-model default at save time when not supplied.

      - `BetaManagedAgentsEffortLow object`

        Low effort. Favors latency over reasoning depth.

        - `type: "low"`

      - `BetaManagedAgentsEffortMedium object`

        Medium effort. Balances latency and reasoning depth.

        - `type: "medium"`

      - `BetaManagedAgentsEffortHigh object`

        High effort. Favors reasoning depth.

        - `type: "high"`

      - `BetaManagedAgentsEffortXhigh object`

        Extra-high effort. Not all models accept this level.

        - `type: "xhigh"`

      - `BetaManagedAgentsEffortMax object`

        Maximum effort. Favors reasoning depth over latency.

        - `type: "max"`

    - `inference_geo: optional string`

      Geographic region for model inference. When unset, requests fall through to the workspace's default_inference_geo.

    - `speed: optional "standard" or "fast"`

      Inference speed mode. `fast` provides significantly faster output token generation at premium pricing. Defaults to `standard`. Not all models support `fast`; invalid combinations are rejected at create time.

      - `"standard"`

      - `"fast"`

  - `multiagent: BetaManagedAgentsSessionMultiagent or null`

    Resolved multiagent orchestration configuration. Null when the agent is single-threaded.

    - `BetaManagedAgentsSessionMultiagentCoordinator object`

      Resolved coordinator topology with full agent definitions for each roster member.

      - `type: "coordinator"`

      - `agents: array of BetaManagedAgentsSessionThreadAgent or BetaManagedAgentsAdvisor`

        Full `agent` definitions the coordinator may spawn as session threads.

        - `BetaManagedAgentsSessionThreadAgent object`

          Resolved `agent` definition for a single `session_thread`. Snapshot of the agent at thread creation time. The multiagent roster is not repeated here; read it from `Session.agent`.

          - `type: "agent"`

          - `id: string`

          - `description: string or null`

          - `mcp_servers: array of BetaManagedAgentsMCPServerURLDefinition`

            - `type: "url"`

            - `name: string`

            - `url: string`

          - `model: BetaManagedAgentsModelConfig`

            Model identifier and configuration.

          - `name: string`

          - `skills: array of BetaManagedAgentsAnthropicSkill or BetaManagedAgentsCustomSkill`

            - `BetaManagedAgentsAnthropicSkill object`

              A resolved Anthropic-managed skill.

              - `type: "anthropic"`

              - `skill_id: string`

              - `version: string`

            - `BetaManagedAgentsCustomSkill object`

              A resolved user-created custom skill.

              - `type: "custom"`

              - `skill_id: string`

              - `version: string`

          - `system: string or null`

          - `tools: array of BetaManagedAgentsAgentToolset20260401 or BetaManagedAgentsMCPToolset or BetaManagedAgentsCustomTool`

            - `BetaManagedAgentsAgentToolset20260401 object`

              - `type: "agent_toolset_20260401"`

              - `configs: array of BetaManagedAgentsAgentToolConfig`

                - `BetaManagedAgentsBashToolConfig object`

                  Configuration for the bash tool.

                  - `type: "bash"`

                  - `enabled: boolean`

                  - `name: "bash"`

                  - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                    Permission policy for tool execution.

                    - `BetaManagedAgentsAlwaysAllowPolicy object`

                      Tool calls are automatically approved without user confirmation.

                      - `type: "always_allow"`

                    - `BetaManagedAgentsAlwaysAskPolicy object`

                      Tool calls require user confirmation before execution.

                      - `type: "always_ask"`

                    - `BetaManagedAgentsAutoPolicy object`

                      The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

                      - `type: "auto"`

                - `BetaManagedAgentsEditToolConfig object`

                  Configuration for the edit tool.

                  - `type: "edit"`

                  - `enabled: boolean`

                  - `name: "edit"`

                  - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                    Permission policy for tool execution.

                    - `BetaManagedAgentsAlwaysAllowPolicy object`

                      Tool calls are automatically approved without user confirmation.

                    - `BetaManagedAgentsAlwaysAskPolicy object`

                      Tool calls require user confirmation before execution.

                    - `BetaManagedAgentsAutoPolicy object`

                      The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

                - `BetaManagedAgentsReadToolConfig object`

                  Configuration for the read tool.

                  - `type: "read"`

                  - `enabled: boolean`

                  - `name: "read"`

                  - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                    Permission policy for tool execution.

                    - `BetaManagedAgentsAlwaysAllowPolicy object`

                      Tool calls are automatically approved without user confirmation.

                    - `BetaManagedAgentsAlwaysAskPolicy object`

                      Tool calls require user confirmation before execution.

                    - `BetaManagedAgentsAutoPolicy object`

                      The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

                - `BetaManagedAgentsWriteToolConfig object`

                  Configuration for the write tool.

                  - `type: "write"`

                  - `enabled: boolean`

                  - `name: "write"`

                  - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                    Permission policy for tool execution.

                    - `BetaManagedAgentsAlwaysAllowPolicy object`

                      Tool calls are automatically approved without user confirmation.

                    - `BetaManagedAgentsAlwaysAskPolicy object`

                      Tool calls require user confirmation before execution.

                    - `BetaManagedAgentsAutoPolicy object`

                      The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

                - `BetaManagedAgentsGlobToolConfig object`

                  Configuration for the glob tool.

                  - `type: "glob"`

                  - `enabled: boolean`

                  - `name: "glob"`

                  - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                    Permission policy for tool execution.

                    - `BetaManagedAgentsAlwaysAllowPolicy object`

                      Tool calls are automatically approved without user confirmation.

                    - `BetaManagedAgentsAlwaysAskPolicy object`

                      Tool calls require user confirmation before execution.

                    - `BetaManagedAgentsAutoPolicy object`

                      The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

                - `BetaManagedAgentsGrepToolConfig object`

                  Configuration for the grep tool.

                  - `type: "grep"`

                  - `enabled: boolean`

                  - `name: "grep"`

                  - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                    Permission policy for tool execution.

                    - `BetaManagedAgentsAlwaysAllowPolicy object`

                      Tool calls are automatically approved without user confirmation.

                    - `BetaManagedAgentsAlwaysAskPolicy object`

                      Tool calls require user confirmation before execution.

                    - `BetaManagedAgentsAutoPolicy object`

                      The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

                - `BetaManagedAgentsWebFetchToolConfig object`

                  Configuration for the web_fetch tool.

                  - `type: "web_fetch"`

                  - `enabled: boolean`

                  - `name: "web_fetch"`

                  - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                    Permission policy for tool execution.

                    - `BetaManagedAgentsAlwaysAllowPolicy object`

                      Tool calls are automatically approved without user confirmation.

                    - `BetaManagedAgentsAlwaysAskPolicy object`

                      Tool calls require user confirmation before execution.

                    - `BetaManagedAgentsAutoPolicy object`

                      The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

                  - `url_sources: BetaManagedAgentsWebFetchURLSources or null`

                    Which sources contribute URLs the tool may fetch, always in the object form. Null when not set, which allows every source.

                    - `client_tool_results: BetaManagedAgentsWebFetchURLSourceToolFilter or null`

                      Which custom tools' results contribute URLs that may be fetched. Null when not set, which allows every custom tool's results.

                      - `BetaManagedAgentsWebFetchURLSourceAll object`

                        Every URL from this source may be fetched. This is the default.

                        - `type: "all"`

                      - `BetaManagedAgentsWebFetchURLSourceNone object`

                        This source contributes no URLs that may be fetched.

                        - `type: "none"`

                      - `BetaManagedAgentsWebFetchURLSourceOnly object`

                        Only the named tools' results contribute URLs that may be fetched.

                        - `type: "only"`

                        - `tools: array of BetaManagedAgentsWebFetchURLSourceToolReference`

                          The tools whose results contribute. Between 1 and 128 entries, each with a different name. An empty list is rejected; use "none" to allow no tool's results.

                          - `type: "tool_reference"`

                            Must be "tool_reference".

                          - `name: string`

                            Name of the tool. Compared exactly, so upper and lower case letters are different.

                            minLength: 1, maxLength: 128

                      - `BetaManagedAgentsWebFetchURLSourceExcept object`

                        Every tool's results contribute URLs that may be fetched, except the named tools' results.

                        - `type: "except"`

                        - `tools: array of BetaManagedAgentsWebFetchURLSourceToolReference`

                          The tools whose results do not contribute. Between 1 and 128 entries, each with a different name. An empty list is rejected; use "all" to leave out no tool's results.

                          - `type: "tool_reference"`

                            Must be "tool_reference".

                          - `name: string`

                            Name of the tool. Compared exactly, so upper and lower case letters are different.

                            minLength: 1, maxLength: 128

                    - `server_tool_results: BetaManagedAgentsWebFetchURLSourceToolFilter or null`

                      Which of the web_search and web_fetch tools' results contribute URLs that may be fetched. Null when not set, which allows both.

                    - `user_input: BetaManagedAgentsWebFetchURLSourceUserInput or null`

                      Whether URLs in the text of user messages may be fetched. Null when not set, which allows them.

                      - `BetaManagedAgentsWebFetchURLSourceAll object`

                        Every URL from this source may be fetched. This is the default.

                      - `BetaManagedAgentsWebFetchURLSourceNone object`

                        This source contributes no URLs that may be fetched.

                  - `allowed_domains: optional array of string`

                  - `blocked_domains: optional array of string`

                  - `max_content_tokens: optional number or null`

                    format: int32

                - `BetaManagedAgentsWebSearchToolConfig object`

                  Configuration for the web_search tool.

                  - `type: "web_search"`

                  - `enabled: boolean`

                  - `name: "web_search"`

                  - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                    Permission policy for tool execution.

                    - `BetaManagedAgentsAlwaysAllowPolicy object`

                      Tool calls are automatically approved without user confirmation.

                    - `BetaManagedAgentsAlwaysAskPolicy object`

                      Tool calls require user confirmation before execution.

                    - `BetaManagedAgentsAutoPolicy object`

                      The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

                  - `allowed_domains: optional array of string`

                  - `blocked_domains: optional array of string`

                  - `user_location: optional BetaManagedAgentsUserLocation or null`

                    Approximate user location for search result localization.

                    - `type: "approximate"`

                      Location precision. Only "approximate" is supported.

                    - `city: optional string or null`

                      City name.

                      minLength: 1, maxLength: 255

                    - `country: optional string or null`

                      Two-letter ISO 3166-1 country code, uppercase.

                    - `region: optional string or null`

                      Region or state name.

                      minLength: 1, maxLength: 255

                    - `timezone: optional string or null`

                      IANA timezone identifier, e.g. "America/Los_Angeles".

                      minLength: 1, maxLength: 255

              - `default_config: BetaManagedAgentsAgentToolsetDefaultConfig`

                Resolved default configuration for agent tools.

                - `enabled: boolean`

                - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                  Permission policy for tool execution.

                  - `BetaManagedAgentsAlwaysAllowPolicy object`

                    Tool calls are automatically approved without user confirmation.

                  - `BetaManagedAgentsAlwaysAskPolicy object`

                    Tool calls require user confirmation before execution.

                  - `BetaManagedAgentsAutoPolicy object`

                    The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

            - `BetaManagedAgentsMCPToolset object`

              - `type: "mcp_toolset"`

              - `configs: array of BetaManagedAgentsMCPToolConfig`

                - `enabled: boolean`

                - `name: string`

                - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                  Permission policy for tool execution.

                  - `BetaManagedAgentsAlwaysAllowPolicy object`

                    Tool calls are automatically approved without user confirmation.

                  - `BetaManagedAgentsAlwaysAskPolicy object`

                    Tool calls require user confirmation before execution.

                  - `BetaManagedAgentsAutoPolicy object`

                    The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

              - `default_config: BetaManagedAgentsMCPToolsetDefaultConfig`

                Resolved default configuration for all tools from an MCP server.

                - `enabled: boolean`

                - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                  Permission policy for tool execution.

                  - `BetaManagedAgentsAlwaysAllowPolicy object`

                    Tool calls are automatically approved without user confirmation.

                  - `BetaManagedAgentsAlwaysAskPolicy object`

                    Tool calls require user confirmation before execution.

                  - `BetaManagedAgentsAutoPolicy object`

                    The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

              - `mcp_server_name: string`

            - `BetaManagedAgentsCustomTool object`

              A custom tool as returned in API responses.

              - `type: "custom"`

              - `description: string`

              - `input_schema: BetaManagedAgentsCustomToolInputSchema`

                JSON Schema for custom tool input parameters.

                - `type: "object"`

                - `properties: optional map[unknown] or null`

                - `required: optional array of string or null`

              - `name: string`

          - `version: number`

            format: int32

        - `BetaManagedAgentsAdvisor object`

          Platform advisor roster entry: a model the session's primary thread may consult mid-turn.

          - `type: "advisor"`

          - `model: string`

            The advisor model id.

    - `BetaManagedAgentsSessionMultiagent20261001 object`

      Resolved multiagent configuration with three members, as copied to the `session` at creation.

      - `type: "multiagent_20261001"`

      - `advisor: BetaManagedAgentsMultiagentAdvisor`

        Whether the session's primary thread can consult an advisor model.

        - `BetaManagedAgentsMultiagentAdvisorEnabled object`

          The session's primary thread can consult `model` mid-turn.

          - `type: "enabled"`

          - `model: string`

            The advisor model id.

        - `BetaManagedAgentsMultiagentAdvisorDisabled object`

          The agent has no advisor.

          - `type: "disabled"`

      - `subagents: BetaManagedAgentsSessionMultiagentSubagents`

        Whether the agent can spawn session threads.

        - `BetaManagedAgentsSessionMultiagentSubagentsEnabled object`

          The agent can spawn session threads.

          - `type: "enabled"`

          - `inline_agents: BetaManagedAgentsMultiagentInlineAgents`

            Whether the agent can define inline agents, which are not saved, when it spawns session threads.

            - `BetaManagedAgentsMultiagentInlineAgentsEnabled object`

              The agent can define inline agents.

              - `type: "enabled"`

            - `BetaManagedAgentsMultiagentInlineAgentsDisabled object`

              The agent cannot define inline agents.

              - `type: "disabled"`

          - `predefined_agents: array of BetaManagedAgentsSessionThreadAgent`

            Full `agent` definitions of the predefined agents, which are saved agents that this agent can spawn as session threads.

            - `type: "agent"`

            - `id: string`

            - `description: string or null`

            - `mcp_servers: array of BetaManagedAgentsMCPServerURLDefinition`

            - `model: BetaManagedAgentsModelConfig`

              Model identifier and configuration.

            - `name: string`

            - `skills: array of BetaManagedAgentsAnthropicSkill or BetaManagedAgentsCustomSkill`

            - `system: string or null`

            - `tools: array of BetaManagedAgentsAgentToolset20260401 or BetaManagedAgentsMCPToolset or BetaManagedAgentsCustomTool`

            - `version: number`

              format: int32

        - `BetaManagedAgentsMultiagentSubagentsDisabled object`

          The agent cannot spawn session threads.

          - `type: "disabled"`

      - `workflows: BetaManagedAgentsSessionMultiagentWorkflows`

        Whether the agent can start workflow runs.

        - `BetaManagedAgentsSessionMultiagentWorkflowsEnabled object`

          The agent can start workflow runs.

          - `type: "enabled"`

          - `inline_agents: BetaManagedAgentsMultiagentInlineAgents`

            Whether a run's plan can define inline agents, which are not saved.

          - `predefined_agents: array of BetaManagedAgentsSessionThreadAgent`

            Full `agent` definitions of the predefined agents, which are saved agents that a run's plan can use.

            - `type: "agent"`

            - `id: string`

            - `description: string or null`

            - `mcp_servers: array of BetaManagedAgentsMCPServerURLDefinition`

            - `model: BetaManagedAgentsModelConfig`

              Model identifier and configuration.

            - `name: string`

            - `skills: array of BetaManagedAgentsAnthropicSkill or BetaManagedAgentsCustomSkill`

            - `system: string or null`

            - `tools: array of BetaManagedAgentsAgentToolset20260401 or BetaManagedAgentsMCPToolset or BetaManagedAgentsCustomTool`

            - `version: number`

              format: int32

        - `BetaManagedAgentsMultiagentWorkflowsDisabled object`

          The agent cannot start workflow runs.

          - `type: "disabled"`

  - `name: string`

  - `skills: array of BetaManagedAgentsAnthropicSkill or BetaManagedAgentsCustomSkill`

    - `BetaManagedAgentsAnthropicSkill object`

      A resolved Anthropic-managed skill.

    - `BetaManagedAgentsCustomSkill object`

      A resolved user-created custom skill.

  - `system: string or null`

  - `tools: array of BetaManagedAgentsAgentToolset20260401 or BetaManagedAgentsMCPToolset or BetaManagedAgentsCustomTool`

    - `BetaManagedAgentsAgentToolset20260401 object`

    - `BetaManagedAgentsMCPToolset object`

    - `BetaManagedAgentsCustomTool object`

      A custom tool as returned in API responses.

  - `version: number`

    format: int32

### Beta Managed Agents Session Agent Update

- `BetaManagedAgentsSessionAgentUpdate object`

  Mid-session agent configuration update. Only `tools` and `mcp_servers` are updatable. Full replacement: the provided array becomes the new value. To preserve existing entries, GET the session, modify the array, and POST it back.

  - `mcp_servers: optional array of BetaManagedAgentsURLMCPServerParams`

    Replacement MCP server list. Full replacement: the provided array becomes the new value. Send an empty array to clear; omit to preserve.

    - `type: "url"`

    - `name: string`

      Unique name for this server, referenced by mcp_toolset configurations. 1-255 characters.

      minLength: 1, maxLength: 255

    - `url: string`

      Endpoint URL for the MCP server.

      maxLength: 2048

  - `tools: optional array of BetaManagedAgentsAgentToolset20260401Params or BetaManagedAgentsMCPToolsetParams or BetaManagedAgentsCustomToolParams`

    Replacement tool list. Full replacement: the provided array becomes the new value. Send an empty array to clear; omit to preserve.

    - `BetaManagedAgentsAgentToolset20260401Params object`

      Configuration for built-in agent tools. Use this to enable or disable groups of tools available to the agent.

      - `type: "agent_toolset_20260401"`

      - `configs: optional array of BetaManagedAgentsAgentToolConfigParams`

        Per-tool configuration overrides.

        - `BetaManagedAgentsBashToolConfigParams object`

          Configuration override for the bash tool.

          - `type: optional "bash"`

          - `name: "bash"`

            Must be "bash".

          - `enabled: optional boolean or null`

            Whether this tool is enabled and available to Claude. Overrides the default_config setting.

          - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

            Permission policy for this tool. Controls whether tool calls are auto-approved or require confirmation.

            - `BetaManagedAgentsAlwaysAllowPolicy object`

              Tool calls are automatically approved without user confirmation.

              - `type: "always_allow"`

            - `BetaManagedAgentsAlwaysAskPolicy object`

              Tool calls require user confirmation before execution.

              - `type: "always_ask"`

            - `BetaManagedAgentsAutoPolicy object`

              The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

              - `type: "auto"`

        - `BetaManagedAgentsEditToolConfigParams object`

          Configuration override for the edit tool.

          - `type: optional "edit"`

          - `name: "edit"`

            Must be "edit".

          - `enabled: optional boolean or null`

            Whether this tool is enabled and available to Claude. Overrides the default_config setting.

          - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

            Permission policy for this tool. Controls whether tool calls are auto-approved or require confirmation.

            - `BetaManagedAgentsAlwaysAllowPolicy object`

              Tool calls are automatically approved without user confirmation.

            - `BetaManagedAgentsAlwaysAskPolicy object`

              Tool calls require user confirmation before execution.

            - `BetaManagedAgentsAutoPolicy object`

              The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

        - `BetaManagedAgentsReadToolConfigParams object`

          Configuration override for the read tool.

          - `type: optional "read"`

          - `name: "read"`

            Must be "read".

          - `enabled: optional boolean or null`

            Whether this tool is enabled and available to Claude. Overrides the default_config setting.

          - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

            Permission policy for this tool. Controls whether tool calls are auto-approved or require confirmation.

            - `BetaManagedAgentsAlwaysAllowPolicy object`

              Tool calls are automatically approved without user confirmation.

            - `BetaManagedAgentsAlwaysAskPolicy object`

              Tool calls require user confirmation before execution.

            - `BetaManagedAgentsAutoPolicy object`

              The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

        - `BetaManagedAgentsWriteToolConfigParams object`

          Configuration override for the write tool.

          - `type: optional "write"`

          - `name: "write"`

            Must be "write".

          - `enabled: optional boolean or null`

            Whether this tool is enabled and available to Claude. Overrides the default_config setting.

          - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

            Permission policy for this tool. Controls whether tool calls are auto-approved or require confirmation.

            - `BetaManagedAgentsAlwaysAllowPolicy object`

              Tool calls are automatically approved without user confirmation.

            - `BetaManagedAgentsAlwaysAskPolicy object`

              Tool calls require user confirmation before execution.

            - `BetaManagedAgentsAutoPolicy object`

              The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

        - `BetaManagedAgentsGlobToolConfigParams object`

          Configuration override for the glob tool.

          - `type: optional "glob"`

          - `name: "glob"`

            Must be "glob".

          - `enabled: optional boolean or null`

            Whether this tool is enabled and available to Claude. Overrides the default_config setting.

          - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

            Permission policy for this tool. Controls whether tool calls are auto-approved or require confirmation.

            - `BetaManagedAgentsAlwaysAllowPolicy object`

              Tool calls are automatically approved without user confirmation.

            - `BetaManagedAgentsAlwaysAskPolicy object`

              Tool calls require user confirmation before execution.

            - `BetaManagedAgentsAutoPolicy object`

              The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

        - `BetaManagedAgentsGrepToolConfigParams object`

          Configuration override for the grep tool.

          - `type: optional "grep"`

          - `name: "grep"`

            Must be "grep".

          - `enabled: optional boolean or null`

            Whether this tool is enabled and available to Claude. Overrides the default_config setting.

          - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

            Permission policy for this tool. Controls whether tool calls are auto-approved or require confirmation.

            - `BetaManagedAgentsAlwaysAllowPolicy object`

              Tool calls are automatically approved without user confirmation.

            - `BetaManagedAgentsAlwaysAskPolicy object`

              Tool calls require user confirmation before execution.

            - `BetaManagedAgentsAutoPolicy object`

              The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

        - `BetaManagedAgentsWebFetchToolConfigParams object`

          Configuration override for the web_fetch tool.

          - `type: optional "web_fetch"`

          - `name: "web_fetch"`

            Must be "web_fetch".

          - `allowed_domains: optional array of string`

            Only fetch URLs whose host is one of these domains or a subdomain of one. Each entry is a plain hostname like "docs.example.com" (no scheme, port, or path). At most 64 entries; an empty list is rejected (omit the field instead). Cannot be combined with blocked_domains.

          - `blocked_domains: optional array of string`

            Never fetch URLs whose host is one of these domains or a subdomain of one. Each entry is a plain hostname like "ads.example.com" (no scheme, port, or path). At most 64 entries; an empty list is rejected (omit the field instead). Cannot be combined with allowed_domains.

          - `enabled: optional boolean or null`

            Whether this tool is enabled and available to Claude. Overrides the default_config setting.

          - `max_content_tokens: optional number or null`

            Maximum number of tokens of fetched text content to include in context per call. Does not apply to binary content such as PDFs.

            format: int32

          - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

            Permission policy for this tool. Controls whether tool calls are auto-approved or require confirmation.

            - `BetaManagedAgentsAlwaysAllowPolicy object`

              Tool calls are automatically approved without user confirmation.

            - `BetaManagedAgentsAlwaysAskPolicy object`

              Tool calls require user confirmation before execution.

            - `BetaManagedAgentsAutoPolicy object`

              The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

          - `url_sources: optional BetaManagedAgentsWebFetchURLSourcesParams or null`

            Which sources contribute URLs the tool may fetch. Omit to allow every source.

            - `client_tool_results: optional BetaManagedAgentsWebFetchURLSourceToolFilterParams or null`

              Which custom tools' results contribute URLs that may be fetched: "all" (the default), "none", or an only or except list. Each name in a list must be a custom tool in the same tools array.

              - `BetaManagedAgentsWebFetchURLSourceShorthand = "all" or "none"`

                String form of a url_sources value that has no field other than its type: "all" means {"type": "all"} and "none" means {"type": "none"}.

                - `"all"`

                - `"none"`

              - `BetaManagedAgentsWebFetchURLSourceToolFilter = BetaManagedAgentsWebFetchURLSourceAll or BetaManagedAgentsWebFetchURLSourceNone or BetaManagedAgentsWebFetchURLSourceOnly or BetaManagedAgentsWebFetchURLSourceExcept`

                Which tools' results contribute URLs that may be fetched.

                - `BetaManagedAgentsWebFetchURLSourceAll object`

                  Every URL from this source may be fetched. This is the default.

                  - `type: "all"`

                - `BetaManagedAgentsWebFetchURLSourceNone object`

                  This source contributes no URLs that may be fetched.

                  - `type: "none"`

                - `BetaManagedAgentsWebFetchURLSourceOnly object`

                  Only the named tools' results contribute URLs that may be fetched.

                  - `type: "only"`

                  - `tools: array of BetaManagedAgentsWebFetchURLSourceToolReference`

                    The tools whose results contribute. Between 1 and 128 entries, each with a different name. An empty list is rejected; use "none" to allow no tool's results.

                    - `type: "tool_reference"`

                      Must be "tool_reference".

                    - `name: string`

                      Name of the tool. Compared exactly, so upper and lower case letters are different.

                      minLength: 1, maxLength: 128

                - `BetaManagedAgentsWebFetchURLSourceExcept object`

                  Every tool's results contribute URLs that may be fetched, except the named tools' results.

                  - `type: "except"`

                  - `tools: array of BetaManagedAgentsWebFetchURLSourceToolReference`

                    The tools whose results do not contribute. Between 1 and 128 entries, each with a different name. An empty list is rejected; use "all" to leave out no tool's results.

                    - `type: "tool_reference"`

                      Must be "tool_reference".

                    - `name: string`

                      Name of the tool. Compared exactly, so upper and lower case letters are different.

                      minLength: 1, maxLength: 128

            - `server_tool_results: optional BetaManagedAgentsWebFetchURLSourceToolFilterParams or null`

              Which of the web_search and web_fetch tools' results contribute URLs that may be fetched: "all" (the default), "none", or an only or except list. Each name in a list must be "web_search" or "web_fetch".

            - `user_input: optional BetaManagedAgentsWebFetchURLSourceUserInputParams or null`

              Whether URLs in the text of user messages may be fetched: "all" (the default) or "none".

              - `BetaManagedAgentsWebFetchURLSourceShorthand = "all" or "none"`

                String form of a url_sources value that has no field other than its type: "all" means {"type": "all"} and "none" means {"type": "none"}.

              - `BetaManagedAgentsWebFetchURLSourceUserInput = BetaManagedAgentsWebFetchURLSourceAll or BetaManagedAgentsWebFetchURLSourceNone`

                Whether URLs in the text of user messages may be fetched.

                - `BetaManagedAgentsWebFetchURLSourceAll object`

                  Every URL from this source may be fetched. This is the default.

                - `BetaManagedAgentsWebFetchURLSourceNone object`

                  This source contributes no URLs that may be fetched.

        - `BetaManagedAgentsWebSearchToolConfigParams object`

          Configuration override for the web_search tool.

          - `type: optional "web_search"`

          - `name: "web_search"`

            Must be "web_search".

          - `allowed_domains: optional array of string`

            Only return search results whose host is one of these domains or a subdomain of one. Each entry is a plain hostname like "docs.example.com" (no scheme or port; an optional path suffix is accepted). At most 64 entries; an empty list is rejected (omit the field instead). Cannot be combined with blocked_domains.

          - `blocked_domains: optional array of string`

            Never return search results whose host is one of these domains or a subdomain of one. Each entry is a plain hostname like "ads.example.com" (no scheme or port; an optional path suffix is accepted). At most 64 entries; an empty list is rejected (omit the field instead). Cannot be combined with allowed_domains.

          - `enabled: optional boolean or null`

            Whether this tool is enabled and available to Claude. Overrides the default_config setting.

          - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

            Permission policy for this tool. Controls whether tool calls are auto-approved or require confirmation.

            - `BetaManagedAgentsAlwaysAllowPolicy object`

              Tool calls are automatically approved without user confirmation.

            - `BetaManagedAgentsAlwaysAskPolicy object`

              Tool calls require user confirmation before execution.

            - `BetaManagedAgentsAutoPolicy object`

              The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

          - `user_location: optional BetaManagedAgentsUserLocation or null`

            Approximate user location for search result localization.

            - `type: "approximate"`

              Location precision. Only "approximate" is supported.

            - `city: optional string or null`

              City name.

              minLength: 1, maxLength: 255

            - `country: optional string or null`

              Two-letter ISO 3166-1 country code, uppercase.

            - `region: optional string or null`

              Region or state name.

              minLength: 1, maxLength: 255

            - `timezone: optional string or null`

              IANA timezone identifier, e.g. "America/Los_Angeles".

              minLength: 1, maxLength: 255

      - `default_config: optional BetaManagedAgentsAgentToolsetDefaultConfigParams or null`

        Default configuration applied to all tools in this set.

        - `enabled: optional boolean or null`

          Whether tools are enabled and available to Claude by default. Defaults to true if not specified.

        - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

          Default permission policy for tools. Controls whether tool calls are auto-approved or require confirmation.

          - `BetaManagedAgentsAlwaysAllowPolicy object`

            Tool calls are automatically approved without user confirmation.

          - `BetaManagedAgentsAlwaysAskPolicy object`

            Tool calls require user confirmation before execution.

          - `BetaManagedAgentsAutoPolicy object`

            The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

    - `BetaManagedAgentsMCPToolsetParams object`

      Configuration for tools from an MCP server defined in `mcp_servers`.

      - `type: "mcp_toolset"`

      - `mcp_server_name: string`

        Name of the MCP server. Must match a server name from the mcp_servers array. 1-255 characters.

        minLength: 1, maxLength: 255

      - `configs: optional array of BetaManagedAgentsMCPToolConfigParams`

        Per-tool configuration overrides.

        - `name: string`

          Name of the MCP tool to configure. 1-128 characters.

          minLength: 1, maxLength: 128

        - `enabled: optional boolean or null`

          Whether this tool is enabled. Overrides the `default_config` setting.

        - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

          Permission policy for this tool. Overrides the `default_config` setting.

          - `BetaManagedAgentsAlwaysAllowPolicy object`

            Tool calls are automatically approved without user confirmation.

          - `BetaManagedAgentsAlwaysAskPolicy object`

            Tool calls require user confirmation before execution.

          - `BetaManagedAgentsAutoPolicy object`

            The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

      - `default_config: optional BetaManagedAgentsMCPToolsetDefaultConfigParams or null`

        Default configuration for all tools from this server.

        - `enabled: optional boolean or null`

          Whether tools are enabled by default. Defaults to true if not specified.

        - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

          Default permission policy for tools from this server.

          - `BetaManagedAgentsAlwaysAllowPolicy object`

            Tool calls are automatically approved without user confirmation.

          - `BetaManagedAgentsAlwaysAskPolicy object`

            Tool calls require user confirmation before execution.

          - `BetaManagedAgentsAutoPolicy object`

            The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

    - `BetaManagedAgentsCustomToolParams object`

      A custom tool that is executed by the API client rather than the agent. When the agent calls this tool, an `agent.custom_tool_use` event is emitted and the session goes idle, waiting for the client to provide the result via a `user.custom_tool_result` event.

      - `type: "custom"`

      - `description: string`

        Description of what the tool does, shown to the agent to help it decide when to use the tool.

        minLength: 1

      - `input_schema: BetaManagedAgentsCustomToolInputSchema`

        JSON Schema defining the expected input parameters for the tool.

        - `type: "object"`

        - `properties: optional map[unknown] or null`

        - `required: optional array of string or null`

      - `name: string`

        Unique name for the tool. 1-128 characters; letters, digits, underscores, and hyphens.

        minLength: 1, maxLength: 128

### Beta Managed Agents Session Multiagent

- `BetaManagedAgentsSessionMultiagent = BetaManagedAgentsSessionMultiagentCoordinator or BetaManagedAgentsSessionMultiagent20261001`

  Resolved multiagent orchestration configuration as returned on a `session`.

  - `BetaManagedAgentsSessionMultiagentCoordinator object`

    Resolved coordinator topology with full agent definitions for each roster member.

    - `type: "coordinator"`

    - `agents: array of BetaManagedAgentsSessionThreadAgent or BetaManagedAgentsAdvisor`

      Full `agent` definitions the coordinator may spawn as session threads.

      - `BetaManagedAgentsSessionThreadAgent object`

        Resolved `agent` definition for a single `session_thread`. Snapshot of the agent at thread creation time. The multiagent roster is not repeated here; read it from `Session.agent`.

        - `type: "agent"`

        - `id: string`

        - `description: string or null`

        - `mcp_servers: array of BetaManagedAgentsMCPServerURLDefinition`

          - `type: "url"`

          - `name: string`

          - `url: string`

        - `model: BetaManagedAgentsModelConfig`

          Model identifier and configuration.

          - `id: BetaManagedAgentsModel`

            The model that will power your agent.

            See [models](https://docs.anthropic.com/en/docs/models-overview) for additional details and options.

            - `"claude-haiku-5-5"`

              Fastest model for high-volume, real-time tasks

            - `"claude-sonnet-5-5"`

              Efficient model for coding and agents

            - `"claude-opus-5-5"`

              Powerful intelligence for coding, knowledge work, and long-running agents

            - `"claude-fable-5-1"`

              Frontier intelligence for ambitious tasks across coding, scientific discovery, and enterprise workflows

            - `"claude-sonnet-5"`

              Efficient model for coding and agents

            - `"claude-fable-5"`

              Next generation of intelligence for the hardest knowledge work and coding problems

            - `"claude-opus-5"`

              Powerful intelligence for long-running agents and coding

            - `"claude-opus-4-8"`

              Powerful intelligence for long-running agents and coding

            - `"claude-opus-4-7"`

              Powerful intelligence for long-running agents and coding

            - `"claude-opus-4-6"`

              Powerful intelligence for long-running agents and coding

            - `"claude-sonnet-4-6"`

              Best combination of speed and intelligence

            - `"claude-haiku-4-5"`

            - `"claude-haiku-4-5-20251001"`

            - `"claude-opus-4-5"`

              Powerful intelligence for long-running agents and coding

            - `"claude-opus-4-5-20251101"`

              Powerful intelligence for long-running agents and coding

            - `"claude-sonnet-4-5"`

              **Deprecated**: Will reach end-of-life on November 30, 2026. Please migrate to claude-sonnet-5-5. Visit https://docs.anthropic.com/en/docs/resources/model-deprecations for more information.

              High-performance model for agents and coding

            - `"claude-sonnet-4-5-20250929"`

              **Deprecated**: Will reach end-of-life on November 30, 2026. Please migrate to claude-sonnet-5-5. Visit https://docs.anthropic.com/en/docs/resources/model-deprecations for more information.

              High-performance model for agents and coding

            - `string`

          - `effort: optional BetaManagedAgentsEffortLow or BetaManagedAgentsEffortMedium or BetaManagedAgentsEffortHigh or 2 more`

            How hard Claude works on each inference call. One of `low`, `medium`, `high`, `xhigh`, `max`. Always present; resolved to the per-model default at save time when not supplied.

            - `BetaManagedAgentsEffortLow object`

              Low effort. Favors latency over reasoning depth.

              - `type: "low"`

            - `BetaManagedAgentsEffortMedium object`

              Medium effort. Balances latency and reasoning depth.

              - `type: "medium"`

            - `BetaManagedAgentsEffortHigh object`

              High effort. Favors reasoning depth.

              - `type: "high"`

            - `BetaManagedAgentsEffortXhigh object`

              Extra-high effort. Not all models accept this level.

              - `type: "xhigh"`

            - `BetaManagedAgentsEffortMax object`

              Maximum effort. Favors reasoning depth over latency.

              - `type: "max"`

          - `inference_geo: optional string`

            Geographic region for model inference. When unset, requests fall through to the workspace's default_inference_geo.

          - `speed: optional "standard" or "fast"`

            Inference speed mode. `fast` provides significantly faster output token generation at premium pricing. Defaults to `standard`. Not all models support `fast`; invalid combinations are rejected at create time.

            - `"standard"`

            - `"fast"`

        - `name: string`

        - `skills: array of BetaManagedAgentsAnthropicSkill or BetaManagedAgentsCustomSkill`

          - `BetaManagedAgentsAnthropicSkill object`

            A resolved Anthropic-managed skill.

            - `type: "anthropic"`

            - `skill_id: string`

            - `version: string`

          - `BetaManagedAgentsCustomSkill object`

            A resolved user-created custom skill.

            - `type: "custom"`

            - `skill_id: string`

            - `version: string`

        - `system: string or null`

        - `tools: array of BetaManagedAgentsAgentToolset20260401 or BetaManagedAgentsMCPToolset or BetaManagedAgentsCustomTool`

          - `BetaManagedAgentsAgentToolset20260401 object`

            - `type: "agent_toolset_20260401"`

            - `configs: array of BetaManagedAgentsAgentToolConfig`

              - `BetaManagedAgentsBashToolConfig object`

                Configuration for the bash tool.

                - `type: "bash"`

                - `enabled: boolean`

                - `name: "bash"`

                - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                  Permission policy for tool execution.

                  - `BetaManagedAgentsAlwaysAllowPolicy object`

                    Tool calls are automatically approved without user confirmation.

                    - `type: "always_allow"`

                  - `BetaManagedAgentsAlwaysAskPolicy object`

                    Tool calls require user confirmation before execution.

                    - `type: "always_ask"`

                  - `BetaManagedAgentsAutoPolicy object`

                    The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

                    - `type: "auto"`

              - `BetaManagedAgentsEditToolConfig object`

                Configuration for the edit tool.

                - `type: "edit"`

                - `enabled: boolean`

                - `name: "edit"`

                - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                  Permission policy for tool execution.

                  - `BetaManagedAgentsAlwaysAllowPolicy object`

                    Tool calls are automatically approved without user confirmation.

                  - `BetaManagedAgentsAlwaysAskPolicy object`

                    Tool calls require user confirmation before execution.

                  - `BetaManagedAgentsAutoPolicy object`

                    The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

              - `BetaManagedAgentsReadToolConfig object`

                Configuration for the read tool.

                - `type: "read"`

                - `enabled: boolean`

                - `name: "read"`

                - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                  Permission policy for tool execution.

                  - `BetaManagedAgentsAlwaysAllowPolicy object`

                    Tool calls are automatically approved without user confirmation.

                  - `BetaManagedAgentsAlwaysAskPolicy object`

                    Tool calls require user confirmation before execution.

                  - `BetaManagedAgentsAutoPolicy object`

                    The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

              - `BetaManagedAgentsWriteToolConfig object`

                Configuration for the write tool.

                - `type: "write"`

                - `enabled: boolean`

                - `name: "write"`

                - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                  Permission policy for tool execution.

                  - `BetaManagedAgentsAlwaysAllowPolicy object`

                    Tool calls are automatically approved without user confirmation.

                  - `BetaManagedAgentsAlwaysAskPolicy object`

                    Tool calls require user confirmation before execution.

                  - `BetaManagedAgentsAutoPolicy object`

                    The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

              - `BetaManagedAgentsGlobToolConfig object`

                Configuration for the glob tool.

                - `type: "glob"`

                - `enabled: boolean`

                - `name: "glob"`

                - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                  Permission policy for tool execution.

                  - `BetaManagedAgentsAlwaysAllowPolicy object`

                    Tool calls are automatically approved without user confirmation.

                  - `BetaManagedAgentsAlwaysAskPolicy object`

                    Tool calls require user confirmation before execution.

                  - `BetaManagedAgentsAutoPolicy object`

                    The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

              - `BetaManagedAgentsGrepToolConfig object`

                Configuration for the grep tool.

                - `type: "grep"`

                - `enabled: boolean`

                - `name: "grep"`

                - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                  Permission policy for tool execution.

                  - `BetaManagedAgentsAlwaysAllowPolicy object`

                    Tool calls are automatically approved without user confirmation.

                  - `BetaManagedAgentsAlwaysAskPolicy object`

                    Tool calls require user confirmation before execution.

                  - `BetaManagedAgentsAutoPolicy object`

                    The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

              - `BetaManagedAgentsWebFetchToolConfig object`

                Configuration for the web_fetch tool.

                - `type: "web_fetch"`

                - `enabled: boolean`

                - `name: "web_fetch"`

                - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                  Permission policy for tool execution.

                  - `BetaManagedAgentsAlwaysAllowPolicy object`

                    Tool calls are automatically approved without user confirmation.

                  - `BetaManagedAgentsAlwaysAskPolicy object`

                    Tool calls require user confirmation before execution.

                  - `BetaManagedAgentsAutoPolicy object`

                    The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

                - `url_sources: BetaManagedAgentsWebFetchURLSources or null`

                  Which sources contribute URLs the tool may fetch, always in the object form. Null when not set, which allows every source.

                  - `client_tool_results: BetaManagedAgentsWebFetchURLSourceToolFilter or null`

                    Which custom tools' results contribute URLs that may be fetched. Null when not set, which allows every custom tool's results.

                    - `BetaManagedAgentsWebFetchURLSourceAll object`

                      Every URL from this source may be fetched. This is the default.

                      - `type: "all"`

                    - `BetaManagedAgentsWebFetchURLSourceNone object`

                      This source contributes no URLs that may be fetched.

                      - `type: "none"`

                    - `BetaManagedAgentsWebFetchURLSourceOnly object`

                      Only the named tools' results contribute URLs that may be fetched.

                      - `type: "only"`

                      - `tools: array of BetaManagedAgentsWebFetchURLSourceToolReference`

                        The tools whose results contribute. Between 1 and 128 entries, each with a different name. An empty list is rejected; use "none" to allow no tool's results.

                        - `type: "tool_reference"`

                          Must be "tool_reference".

                        - `name: string`

                          Name of the tool. Compared exactly, so upper and lower case letters are different.

                          minLength: 1, maxLength: 128

                    - `BetaManagedAgentsWebFetchURLSourceExcept object`

                      Every tool's results contribute URLs that may be fetched, except the named tools' results.

                      - `type: "except"`

                      - `tools: array of BetaManagedAgentsWebFetchURLSourceToolReference`

                        The tools whose results do not contribute. Between 1 and 128 entries, each with a different name. An empty list is rejected; use "all" to leave out no tool's results.

                        - `type: "tool_reference"`

                          Must be "tool_reference".

                        - `name: string`

                          Name of the tool. Compared exactly, so upper and lower case letters are different.

                          minLength: 1, maxLength: 128

                  - `server_tool_results: BetaManagedAgentsWebFetchURLSourceToolFilter or null`

                    Which of the web_search and web_fetch tools' results contribute URLs that may be fetched. Null when not set, which allows both.

                  - `user_input: BetaManagedAgentsWebFetchURLSourceUserInput or null`

                    Whether URLs in the text of user messages may be fetched. Null when not set, which allows them.

                    - `BetaManagedAgentsWebFetchURLSourceAll object`

                      Every URL from this source may be fetched. This is the default.

                    - `BetaManagedAgentsWebFetchURLSourceNone object`

                      This source contributes no URLs that may be fetched.

                - `allowed_domains: optional array of string`

                - `blocked_domains: optional array of string`

                - `max_content_tokens: optional number or null`

                  format: int32

              - `BetaManagedAgentsWebSearchToolConfig object`

                Configuration for the web_search tool.

                - `type: "web_search"`

                - `enabled: boolean`

                - `name: "web_search"`

                - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                  Permission policy for tool execution.

                  - `BetaManagedAgentsAlwaysAllowPolicy object`

                    Tool calls are automatically approved without user confirmation.

                  - `BetaManagedAgentsAlwaysAskPolicy object`

                    Tool calls require user confirmation before execution.

                  - `BetaManagedAgentsAutoPolicy object`

                    The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

                - `allowed_domains: optional array of string`

                - `blocked_domains: optional array of string`

                - `user_location: optional BetaManagedAgentsUserLocation or null`

                  Approximate user location for search result localization.

                  - `type: "approximate"`

                    Location precision. Only "approximate" is supported.

                  - `city: optional string or null`

                    City name.

                    minLength: 1, maxLength: 255

                  - `country: optional string or null`

                    Two-letter ISO 3166-1 country code, uppercase.

                  - `region: optional string or null`

                    Region or state name.

                    minLength: 1, maxLength: 255

                  - `timezone: optional string or null`

                    IANA timezone identifier, e.g. "America/Los_Angeles".

                    minLength: 1, maxLength: 255

            - `default_config: BetaManagedAgentsAgentToolsetDefaultConfig`

              Resolved default configuration for agent tools.

              - `enabled: boolean`

              - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                Permission policy for tool execution.

                - `BetaManagedAgentsAlwaysAllowPolicy object`

                  Tool calls are automatically approved without user confirmation.

                - `BetaManagedAgentsAlwaysAskPolicy object`

                  Tool calls require user confirmation before execution.

                - `BetaManagedAgentsAutoPolicy object`

                  The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

          - `BetaManagedAgentsMCPToolset object`

            - `type: "mcp_toolset"`

            - `configs: array of BetaManagedAgentsMCPToolConfig`

              - `enabled: boolean`

              - `name: string`

              - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                Permission policy for tool execution.

                - `BetaManagedAgentsAlwaysAllowPolicy object`

                  Tool calls are automatically approved without user confirmation.

                - `BetaManagedAgentsAlwaysAskPolicy object`

                  Tool calls require user confirmation before execution.

                - `BetaManagedAgentsAutoPolicy object`

                  The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

            - `default_config: BetaManagedAgentsMCPToolsetDefaultConfig`

              Resolved default configuration for all tools from an MCP server.

              - `enabled: boolean`

              - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                Permission policy for tool execution.

                - `BetaManagedAgentsAlwaysAllowPolicy object`

                  Tool calls are automatically approved without user confirmation.

                - `BetaManagedAgentsAlwaysAskPolicy object`

                  Tool calls require user confirmation before execution.

                - `BetaManagedAgentsAutoPolicy object`

                  The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

            - `mcp_server_name: string`

          - `BetaManagedAgentsCustomTool object`

            A custom tool as returned in API responses.

            - `type: "custom"`

            - `description: string`

            - `input_schema: BetaManagedAgentsCustomToolInputSchema`

              JSON Schema for custom tool input parameters.

              - `type: "object"`

              - `properties: optional map[unknown] or null`

              - `required: optional array of string or null`

            - `name: string`

        - `version: number`

          format: int32

      - `BetaManagedAgentsAdvisor object`

        Platform advisor roster entry: a model the session's primary thread may consult mid-turn.

        - `type: "advisor"`

        - `model: string`

          The advisor model id.

  - `BetaManagedAgentsSessionMultiagent20261001 object`

    Resolved multiagent configuration with three members, as copied to the `session` at creation.

    - `type: "multiagent_20261001"`

    - `advisor: BetaManagedAgentsMultiagentAdvisor`

      Whether the session's primary thread can consult an advisor model.

      - `BetaManagedAgentsMultiagentAdvisorEnabled object`

        The session's primary thread can consult `model` mid-turn.

        - `type: "enabled"`

        - `model: string`

          The advisor model id.

      - `BetaManagedAgentsMultiagentAdvisorDisabled object`

        The agent has no advisor.

        - `type: "disabled"`

    - `subagents: BetaManagedAgentsSessionMultiagentSubagents`

      Whether the agent can spawn session threads.

      - `BetaManagedAgentsSessionMultiagentSubagentsEnabled object`

        The agent can spawn session threads.

        - `type: "enabled"`

        - `inline_agents: BetaManagedAgentsMultiagentInlineAgents`

          Whether the agent can define inline agents, which are not saved, when it spawns session threads.

          - `BetaManagedAgentsMultiagentInlineAgentsEnabled object`

            The agent can define inline agents.

            - `type: "enabled"`

          - `BetaManagedAgentsMultiagentInlineAgentsDisabled object`

            The agent cannot define inline agents.

            - `type: "disabled"`

        - `predefined_agents: array of BetaManagedAgentsSessionThreadAgent`

          Full `agent` definitions of the predefined agents, which are saved agents that this agent can spawn as session threads.

          - `type: "agent"`

          - `id: string`

          - `description: string or null`

          - `mcp_servers: array of BetaManagedAgentsMCPServerURLDefinition`

          - `model: BetaManagedAgentsModelConfig`

            Model identifier and configuration.

          - `name: string`

          - `skills: array of BetaManagedAgentsAnthropicSkill or BetaManagedAgentsCustomSkill`

          - `system: string or null`

          - `tools: array of BetaManagedAgentsAgentToolset20260401 or BetaManagedAgentsMCPToolset or BetaManagedAgentsCustomTool`

          - `version: number`

            format: int32

      - `BetaManagedAgentsMultiagentSubagentsDisabled object`

        The agent cannot spawn session threads.

        - `type: "disabled"`

    - `workflows: BetaManagedAgentsSessionMultiagentWorkflows`

      Whether the agent can start workflow runs.

      - `BetaManagedAgentsSessionMultiagentWorkflowsEnabled object`

        The agent can start workflow runs.

        - `type: "enabled"`

        - `inline_agents: BetaManagedAgentsMultiagentInlineAgents`

          Whether a run's plan can define inline agents, which are not saved.

        - `predefined_agents: array of BetaManagedAgentsSessionThreadAgent`

          Full `agent` definitions of the predefined agents, which are saved agents that a run's plan can use.

          - `type: "agent"`

          - `id: string`

          - `description: string or null`

          - `mcp_servers: array of BetaManagedAgentsMCPServerURLDefinition`

          - `model: BetaManagedAgentsModelConfig`

            Model identifier and configuration.

          - `name: string`

          - `skills: array of BetaManagedAgentsAnthropicSkill or BetaManagedAgentsCustomSkill`

          - `system: string or null`

          - `tools: array of BetaManagedAgentsAgentToolset20260401 or BetaManagedAgentsMCPToolset or BetaManagedAgentsCustomTool`

          - `version: number`

            format: int32

      - `BetaManagedAgentsMultiagentWorkflowsDisabled object`

        The agent cannot start workflow runs.

        - `type: "disabled"`

### Beta Managed Agents Session Multiagent Coordinator

- `BetaManagedAgentsSessionMultiagentCoordinator object`

  Resolved coordinator topology with full agent definitions for each roster member.

  - `type: "coordinator"`

  - `agents: array of BetaManagedAgentsSessionThreadAgent or BetaManagedAgentsAdvisor`

    Full `agent` definitions the coordinator may spawn as session threads.

    - `BetaManagedAgentsSessionThreadAgent object`

      Resolved `agent` definition for a single `session_thread`. Snapshot of the agent at thread creation time. The multiagent roster is not repeated here; read it from `Session.agent`.

      - `type: "agent"`

      - `id: string`

      - `description: string or null`

      - `mcp_servers: array of BetaManagedAgentsMCPServerURLDefinition`

        - `type: "url"`

        - `name: string`

        - `url: string`

      - `model: BetaManagedAgentsModelConfig`

        Model identifier and configuration.

        - `id: BetaManagedAgentsModel`

          The model that will power your agent.

          See [models](https://docs.anthropic.com/en/docs/models-overview) for additional details and options.

          - `"claude-haiku-5-5"`

            Fastest model for high-volume, real-time tasks

          - `"claude-sonnet-5-5"`

            Efficient model for coding and agents

          - `"claude-opus-5-5"`

            Powerful intelligence for coding, knowledge work, and long-running agents

          - `"claude-fable-5-1"`

            Frontier intelligence for ambitious tasks across coding, scientific discovery, and enterprise workflows

          - `"claude-sonnet-5"`

            Efficient model for coding and agents

          - `"claude-fable-5"`

            Next generation of intelligence for the hardest knowledge work and coding problems

          - `"claude-opus-5"`

            Powerful intelligence for long-running agents and coding

          - `"claude-opus-4-8"`

            Powerful intelligence for long-running agents and coding

          - `"claude-opus-4-7"`

            Powerful intelligence for long-running agents and coding

          - `"claude-opus-4-6"`

            Powerful intelligence for long-running agents and coding

          - `"claude-sonnet-4-6"`

            Best combination of speed and intelligence

          - `"claude-haiku-4-5"`

          - `"claude-haiku-4-5-20251001"`

          - `"claude-opus-4-5"`

            Powerful intelligence for long-running agents and coding

          - `"claude-opus-4-5-20251101"`

            Powerful intelligence for long-running agents and coding

          - `"claude-sonnet-4-5"`

            **Deprecated**: Will reach end-of-life on November 30, 2026. Please migrate to claude-sonnet-5-5. Visit https://docs.anthropic.com/en/docs/resources/model-deprecations for more information.

            High-performance model for agents and coding

          - `"claude-sonnet-4-5-20250929"`

            **Deprecated**: Will reach end-of-life on November 30, 2026. Please migrate to claude-sonnet-5-5. Visit https://docs.anthropic.com/en/docs/resources/model-deprecations for more information.

            High-performance model for agents and coding

          - `string`

        - `effort: optional BetaManagedAgentsEffortLow or BetaManagedAgentsEffortMedium or BetaManagedAgentsEffortHigh or 2 more`

          How hard Claude works on each inference call. One of `low`, `medium`, `high`, `xhigh`, `max`. Always present; resolved to the per-model default at save time when not supplied.

          - `BetaManagedAgentsEffortLow object`

            Low effort. Favors latency over reasoning depth.

            - `type: "low"`

          - `BetaManagedAgentsEffortMedium object`

            Medium effort. Balances latency and reasoning depth.

            - `type: "medium"`

          - `BetaManagedAgentsEffortHigh object`

            High effort. Favors reasoning depth.

            - `type: "high"`

          - `BetaManagedAgentsEffortXhigh object`

            Extra-high effort. Not all models accept this level.

            - `type: "xhigh"`

          - `BetaManagedAgentsEffortMax object`

            Maximum effort. Favors reasoning depth over latency.

            - `type: "max"`

        - `inference_geo: optional string`

          Geographic region for model inference. When unset, requests fall through to the workspace's default_inference_geo.

        - `speed: optional "standard" or "fast"`

          Inference speed mode. `fast` provides significantly faster output token generation at premium pricing. Defaults to `standard`. Not all models support `fast`; invalid combinations are rejected at create time.

          - `"standard"`

          - `"fast"`

      - `name: string`

      - `skills: array of BetaManagedAgentsAnthropicSkill or BetaManagedAgentsCustomSkill`

        - `BetaManagedAgentsAnthropicSkill object`

          A resolved Anthropic-managed skill.

          - `type: "anthropic"`

          - `skill_id: string`

          - `version: string`

        - `BetaManagedAgentsCustomSkill object`

          A resolved user-created custom skill.

          - `type: "custom"`

          - `skill_id: string`

          - `version: string`

      - `system: string or null`

      - `tools: array of BetaManagedAgentsAgentToolset20260401 or BetaManagedAgentsMCPToolset or BetaManagedAgentsCustomTool`

        - `BetaManagedAgentsAgentToolset20260401 object`

          - `type: "agent_toolset_20260401"`

          - `configs: array of BetaManagedAgentsAgentToolConfig`

            - `BetaManagedAgentsBashToolConfig object`

              Configuration for the bash tool.

              - `type: "bash"`

              - `enabled: boolean`

              - `name: "bash"`

              - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                Permission policy for tool execution.

                - `BetaManagedAgentsAlwaysAllowPolicy object`

                  Tool calls are automatically approved without user confirmation.

                  - `type: "always_allow"`

                - `BetaManagedAgentsAlwaysAskPolicy object`

                  Tool calls require user confirmation before execution.

                  - `type: "always_ask"`

                - `BetaManagedAgentsAutoPolicy object`

                  The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

                  - `type: "auto"`

            - `BetaManagedAgentsEditToolConfig object`

              Configuration for the edit tool.

              - `type: "edit"`

              - `enabled: boolean`

              - `name: "edit"`

              - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                Permission policy for tool execution.

                - `BetaManagedAgentsAlwaysAllowPolicy object`

                  Tool calls are automatically approved without user confirmation.

                - `BetaManagedAgentsAlwaysAskPolicy object`

                  Tool calls require user confirmation before execution.

                - `BetaManagedAgentsAutoPolicy object`

                  The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

            - `BetaManagedAgentsReadToolConfig object`

              Configuration for the read tool.

              - `type: "read"`

              - `enabled: boolean`

              - `name: "read"`

              - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                Permission policy for tool execution.

                - `BetaManagedAgentsAlwaysAllowPolicy object`

                  Tool calls are automatically approved without user confirmation.

                - `BetaManagedAgentsAlwaysAskPolicy object`

                  Tool calls require user confirmation before execution.

                - `BetaManagedAgentsAutoPolicy object`

                  The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

            - `BetaManagedAgentsWriteToolConfig object`

              Configuration for the write tool.

              - `type: "write"`

              - `enabled: boolean`

              - `name: "write"`

              - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                Permission policy for tool execution.

                - `BetaManagedAgentsAlwaysAllowPolicy object`

                  Tool calls are automatically approved without user confirmation.

                - `BetaManagedAgentsAlwaysAskPolicy object`

                  Tool calls require user confirmation before execution.

                - `BetaManagedAgentsAutoPolicy object`

                  The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

            - `BetaManagedAgentsGlobToolConfig object`

              Configuration for the glob tool.

              - `type: "glob"`

              - `enabled: boolean`

              - `name: "glob"`

              - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                Permission policy for tool execution.

                - `BetaManagedAgentsAlwaysAllowPolicy object`

                  Tool calls are automatically approved without user confirmation.

                - `BetaManagedAgentsAlwaysAskPolicy object`

                  Tool calls require user confirmation before execution.

                - `BetaManagedAgentsAutoPolicy object`

                  The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

            - `BetaManagedAgentsGrepToolConfig object`

              Configuration for the grep tool.

              - `type: "grep"`

              - `enabled: boolean`

              - `name: "grep"`

              - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                Permission policy for tool execution.

                - `BetaManagedAgentsAlwaysAllowPolicy object`

                  Tool calls are automatically approved without user confirmation.

                - `BetaManagedAgentsAlwaysAskPolicy object`

                  Tool calls require user confirmation before execution.

                - `BetaManagedAgentsAutoPolicy object`

                  The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

            - `BetaManagedAgentsWebFetchToolConfig object`

              Configuration for the web_fetch tool.

              - `type: "web_fetch"`

              - `enabled: boolean`

              - `name: "web_fetch"`

              - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                Permission policy for tool execution.

                - `BetaManagedAgentsAlwaysAllowPolicy object`

                  Tool calls are automatically approved without user confirmation.

                - `BetaManagedAgentsAlwaysAskPolicy object`

                  Tool calls require user confirmation before execution.

                - `BetaManagedAgentsAutoPolicy object`

                  The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

              - `url_sources: BetaManagedAgentsWebFetchURLSources or null`

                Which sources contribute URLs the tool may fetch, always in the object form. Null when not set, which allows every source.

                - `client_tool_results: BetaManagedAgentsWebFetchURLSourceToolFilter or null`

                  Which custom tools' results contribute URLs that may be fetched. Null when not set, which allows every custom tool's results.

                  - `BetaManagedAgentsWebFetchURLSourceAll object`

                    Every URL from this source may be fetched. This is the default.

                    - `type: "all"`

                  - `BetaManagedAgentsWebFetchURLSourceNone object`

                    This source contributes no URLs that may be fetched.

                    - `type: "none"`

                  - `BetaManagedAgentsWebFetchURLSourceOnly object`

                    Only the named tools' results contribute URLs that may be fetched.

                    - `type: "only"`

                    - `tools: array of BetaManagedAgentsWebFetchURLSourceToolReference`

                      The tools whose results contribute. Between 1 and 128 entries, each with a different name. An empty list is rejected; use "none" to allow no tool's results.

                      - `type: "tool_reference"`

                        Must be "tool_reference".

                      - `name: string`

                        Name of the tool. Compared exactly, so upper and lower case letters are different.

                        minLength: 1, maxLength: 128

                  - `BetaManagedAgentsWebFetchURLSourceExcept object`

                    Every tool's results contribute URLs that may be fetched, except the named tools' results.

                    - `type: "except"`

                    - `tools: array of BetaManagedAgentsWebFetchURLSourceToolReference`

                      The tools whose results do not contribute. Between 1 and 128 entries, each with a different name. An empty list is rejected; use "all" to leave out no tool's results.

                      - `type: "tool_reference"`

                        Must be "tool_reference".

                      - `name: string`

                        Name of the tool. Compared exactly, so upper and lower case letters are different.

                        minLength: 1, maxLength: 128

                - `server_tool_results: BetaManagedAgentsWebFetchURLSourceToolFilter or null`

                  Which of the web_search and web_fetch tools' results contribute URLs that may be fetched. Null when not set, which allows both.

                - `user_input: BetaManagedAgentsWebFetchURLSourceUserInput or null`

                  Whether URLs in the text of user messages may be fetched. Null when not set, which allows them.

                  - `BetaManagedAgentsWebFetchURLSourceAll object`

                    Every URL from this source may be fetched. This is the default.

                  - `BetaManagedAgentsWebFetchURLSourceNone object`

                    This source contributes no URLs that may be fetched.

              - `allowed_domains: optional array of string`

              - `blocked_domains: optional array of string`

              - `max_content_tokens: optional number or null`

                format: int32

            - `BetaManagedAgentsWebSearchToolConfig object`

              Configuration for the web_search tool.

              - `type: "web_search"`

              - `enabled: boolean`

              - `name: "web_search"`

              - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                Permission policy for tool execution.

                - `BetaManagedAgentsAlwaysAllowPolicy object`

                  Tool calls are automatically approved without user confirmation.

                - `BetaManagedAgentsAlwaysAskPolicy object`

                  Tool calls require user confirmation before execution.

                - `BetaManagedAgentsAutoPolicy object`

                  The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

              - `allowed_domains: optional array of string`

              - `blocked_domains: optional array of string`

              - `user_location: optional BetaManagedAgentsUserLocation or null`

                Approximate user location for search result localization.

                - `type: "approximate"`

                  Location precision. Only "approximate" is supported.

                - `city: optional string or null`

                  City name.

                  minLength: 1, maxLength: 255

                - `country: optional string or null`

                  Two-letter ISO 3166-1 country code, uppercase.

                - `region: optional string or null`

                  Region or state name.

                  minLength: 1, maxLength: 255

                - `timezone: optional string or null`

                  IANA timezone identifier, e.g. "America/Los_Angeles".

                  minLength: 1, maxLength: 255

          - `default_config: BetaManagedAgentsAgentToolsetDefaultConfig`

            Resolved default configuration for agent tools.

            - `enabled: boolean`

            - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

              Permission policy for tool execution.

              - `BetaManagedAgentsAlwaysAllowPolicy object`

                Tool calls are automatically approved without user confirmation.

              - `BetaManagedAgentsAlwaysAskPolicy object`

                Tool calls require user confirmation before execution.

              - `BetaManagedAgentsAutoPolicy object`

                The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

        - `BetaManagedAgentsMCPToolset object`

          - `type: "mcp_toolset"`

          - `configs: array of BetaManagedAgentsMCPToolConfig`

            - `enabled: boolean`

            - `name: string`

            - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

              Permission policy for tool execution.

              - `BetaManagedAgentsAlwaysAllowPolicy object`

                Tool calls are automatically approved without user confirmation.

              - `BetaManagedAgentsAlwaysAskPolicy object`

                Tool calls require user confirmation before execution.

              - `BetaManagedAgentsAutoPolicy object`

                The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

          - `default_config: BetaManagedAgentsMCPToolsetDefaultConfig`

            Resolved default configuration for all tools from an MCP server.

            - `enabled: boolean`

            - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

              Permission policy for tool execution.

              - `BetaManagedAgentsAlwaysAllowPolicy object`

                Tool calls are automatically approved without user confirmation.

              - `BetaManagedAgentsAlwaysAskPolicy object`

                Tool calls require user confirmation before execution.

              - `BetaManagedAgentsAutoPolicy object`

                The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

          - `mcp_server_name: string`

        - `BetaManagedAgentsCustomTool object`

          A custom tool as returned in API responses.

          - `type: "custom"`

          - `description: string`

          - `input_schema: BetaManagedAgentsCustomToolInputSchema`

            JSON Schema for custom tool input parameters.

            - `type: "object"`

            - `properties: optional map[unknown] or null`

            - `required: optional array of string or null`

          - `name: string`

      - `version: number`

        format: int32

    - `BetaManagedAgentsAdvisor object`

      Platform advisor roster entry: a model the session's primary thread may consult mid-turn.

      - `type: "advisor"`

      - `model: string`

        The advisor model id.

### Beta Managed Agents Session Multiagent Subagents

- `BetaManagedAgentsSessionMultiagentSubagents = BetaManagedAgentsSessionMultiagentSubagentsEnabled or BetaManagedAgentsMultiagentSubagentsDisabled`

  Whether the agent can spawn session threads.

  - `BetaManagedAgentsSessionMultiagentSubagentsEnabled object`

    The agent can spawn session threads.

    - `type: "enabled"`

    - `inline_agents: BetaManagedAgentsMultiagentInlineAgents`

      Whether the agent can define inline agents, which are not saved, when it spawns session threads.

      - `BetaManagedAgentsMultiagentInlineAgentsEnabled object`

        The agent can define inline agents.

        - `type: "enabled"`

      - `BetaManagedAgentsMultiagentInlineAgentsDisabled object`

        The agent cannot define inline agents.

        - `type: "disabled"`

    - `predefined_agents: array of BetaManagedAgentsSessionThreadAgent`

      Full `agent` definitions of the predefined agents, which are saved agents that this agent can spawn as session threads.

      - `type: "agent"`

      - `id: string`

      - `description: string or null`

      - `mcp_servers: array of BetaManagedAgentsMCPServerURLDefinition`

        - `type: "url"`

        - `name: string`

        - `url: string`

      - `model: BetaManagedAgentsModelConfig`

        Model identifier and configuration.

        - `id: BetaManagedAgentsModel`

          The model that will power your agent.

          See [models](https://docs.anthropic.com/en/docs/models-overview) for additional details and options.

          - `"claude-haiku-5-5"`

            Fastest model for high-volume, real-time tasks

          - `"claude-sonnet-5-5"`

            Efficient model for coding and agents

          - `"claude-opus-5-5"`

            Powerful intelligence for coding, knowledge work, and long-running agents

          - `"claude-fable-5-1"`

            Frontier intelligence for ambitious tasks across coding, scientific discovery, and enterprise workflows

          - `"claude-sonnet-5"`

            Efficient model for coding and agents

          - `"claude-fable-5"`

            Next generation of intelligence for the hardest knowledge work and coding problems

          - `"claude-opus-5"`

            Powerful intelligence for long-running agents and coding

          - `"claude-opus-4-8"`

            Powerful intelligence for long-running agents and coding

          - `"claude-opus-4-7"`

            Powerful intelligence for long-running agents and coding

          - `"claude-opus-4-6"`

            Powerful intelligence for long-running agents and coding

          - `"claude-sonnet-4-6"`

            Best combination of speed and intelligence

          - `"claude-haiku-4-5"`

          - `"claude-haiku-4-5-20251001"`

          - `"claude-opus-4-5"`

            Powerful intelligence for long-running agents and coding

          - `"claude-opus-4-5-20251101"`

            Powerful intelligence for long-running agents and coding

          - `"claude-sonnet-4-5"`

            **Deprecated**: Will reach end-of-life on November 30, 2026. Please migrate to claude-sonnet-5-5. Visit https://docs.anthropic.com/en/docs/resources/model-deprecations for more information.

            High-performance model for agents and coding

          - `"claude-sonnet-4-5-20250929"`

            **Deprecated**: Will reach end-of-life on November 30, 2026. Please migrate to claude-sonnet-5-5. Visit https://docs.anthropic.com/en/docs/resources/model-deprecations for more information.

            High-performance model for agents and coding

          - `string`

        - `effort: optional BetaManagedAgentsEffortLow or BetaManagedAgentsEffortMedium or BetaManagedAgentsEffortHigh or 2 more`

          How hard Claude works on each inference call. One of `low`, `medium`, `high`, `xhigh`, `max`. Always present; resolved to the per-model default at save time when not supplied.

          - `BetaManagedAgentsEffortLow object`

            Low effort. Favors latency over reasoning depth.

            - `type: "low"`

          - `BetaManagedAgentsEffortMedium object`

            Medium effort. Balances latency and reasoning depth.

            - `type: "medium"`

          - `BetaManagedAgentsEffortHigh object`

            High effort. Favors reasoning depth.

            - `type: "high"`

          - `BetaManagedAgentsEffortXhigh object`

            Extra-high effort. Not all models accept this level.

            - `type: "xhigh"`

          - `BetaManagedAgentsEffortMax object`

            Maximum effort. Favors reasoning depth over latency.

            - `type: "max"`

        - `inference_geo: optional string`

          Geographic region for model inference. When unset, requests fall through to the workspace's default_inference_geo.

        - `speed: optional "standard" or "fast"`

          Inference speed mode. `fast` provides significantly faster output token generation at premium pricing. Defaults to `standard`. Not all models support `fast`; invalid combinations are rejected at create time.

          - `"standard"`

          - `"fast"`

      - `name: string`

      - `skills: array of BetaManagedAgentsAnthropicSkill or BetaManagedAgentsCustomSkill`

        - `BetaManagedAgentsAnthropicSkill object`

          A resolved Anthropic-managed skill.

          - `type: "anthropic"`

          - `skill_id: string`

          - `version: string`

        - `BetaManagedAgentsCustomSkill object`

          A resolved user-created custom skill.

          - `type: "custom"`

          - `skill_id: string`

          - `version: string`

      - `system: string or null`

      - `tools: array of BetaManagedAgentsAgentToolset20260401 or BetaManagedAgentsMCPToolset or BetaManagedAgentsCustomTool`

        - `BetaManagedAgentsAgentToolset20260401 object`

          - `type: "agent_toolset_20260401"`

          - `configs: array of BetaManagedAgentsAgentToolConfig`

            - `BetaManagedAgentsBashToolConfig object`

              Configuration for the bash tool.

              - `type: "bash"`

              - `enabled: boolean`

              - `name: "bash"`

              - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                Permission policy for tool execution.

                - `BetaManagedAgentsAlwaysAllowPolicy object`

                  Tool calls are automatically approved without user confirmation.

                  - `type: "always_allow"`

                - `BetaManagedAgentsAlwaysAskPolicy object`

                  Tool calls require user confirmation before execution.

                  - `type: "always_ask"`

                - `BetaManagedAgentsAutoPolicy object`

                  The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

                  - `type: "auto"`

            - `BetaManagedAgentsEditToolConfig object`

              Configuration for the edit tool.

              - `type: "edit"`

              - `enabled: boolean`

              - `name: "edit"`

              - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                Permission policy for tool execution.

                - `BetaManagedAgentsAlwaysAllowPolicy object`

                  Tool calls are automatically approved without user confirmation.

                - `BetaManagedAgentsAlwaysAskPolicy object`

                  Tool calls require user confirmation before execution.

                - `BetaManagedAgentsAutoPolicy object`

                  The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

            - `BetaManagedAgentsReadToolConfig object`

              Configuration for the read tool.

              - `type: "read"`

              - `enabled: boolean`

              - `name: "read"`

              - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                Permission policy for tool execution.

                - `BetaManagedAgentsAlwaysAllowPolicy object`

                  Tool calls are automatically approved without user confirmation.

                - `BetaManagedAgentsAlwaysAskPolicy object`

                  Tool calls require user confirmation before execution.

                - `BetaManagedAgentsAutoPolicy object`

                  The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

            - `BetaManagedAgentsWriteToolConfig object`

              Configuration for the write tool.

              - `type: "write"`

              - `enabled: boolean`

              - `name: "write"`

              - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                Permission policy for tool execution.

                - `BetaManagedAgentsAlwaysAllowPolicy object`

                  Tool calls are automatically approved without user confirmation.

                - `BetaManagedAgentsAlwaysAskPolicy object`

                  Tool calls require user confirmation before execution.

                - `BetaManagedAgentsAutoPolicy object`

                  The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

            - `BetaManagedAgentsGlobToolConfig object`

              Configuration for the glob tool.

              - `type: "glob"`

              - `enabled: boolean`

              - `name: "glob"`

              - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                Permission policy for tool execution.

                - `BetaManagedAgentsAlwaysAllowPolicy object`

                  Tool calls are automatically approved without user confirmation.

                - `BetaManagedAgentsAlwaysAskPolicy object`

                  Tool calls require user confirmation before execution.

                - `BetaManagedAgentsAutoPolicy object`

                  The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

            - `BetaManagedAgentsGrepToolConfig object`

              Configuration for the grep tool.

              - `type: "grep"`

              - `enabled: boolean`

              - `name: "grep"`

              - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                Permission policy for tool execution.

                - `BetaManagedAgentsAlwaysAllowPolicy object`

                  Tool calls are automatically approved without user confirmation.

                - `BetaManagedAgentsAlwaysAskPolicy object`

                  Tool calls require user confirmation before execution.

                - `BetaManagedAgentsAutoPolicy object`

                  The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

            - `BetaManagedAgentsWebFetchToolConfig object`

              Configuration for the web_fetch tool.

              - `type: "web_fetch"`

              - `enabled: boolean`

              - `name: "web_fetch"`

              - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                Permission policy for tool execution.

                - `BetaManagedAgentsAlwaysAllowPolicy object`

                  Tool calls are automatically approved without user confirmation.

                - `BetaManagedAgentsAlwaysAskPolicy object`

                  Tool calls require user confirmation before execution.

                - `BetaManagedAgentsAutoPolicy object`

                  The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

              - `url_sources: BetaManagedAgentsWebFetchURLSources or null`

                Which sources contribute URLs the tool may fetch, always in the object form. Null when not set, which allows every source.

                - `client_tool_results: BetaManagedAgentsWebFetchURLSourceToolFilter or null`

                  Which custom tools' results contribute URLs that may be fetched. Null when not set, which allows every custom tool's results.

                  - `BetaManagedAgentsWebFetchURLSourceAll object`

                    Every URL from this source may be fetched. This is the default.

                    - `type: "all"`

                  - `BetaManagedAgentsWebFetchURLSourceNone object`

                    This source contributes no URLs that may be fetched.

                    - `type: "none"`

                  - `BetaManagedAgentsWebFetchURLSourceOnly object`

                    Only the named tools' results contribute URLs that may be fetched.

                    - `type: "only"`

                    - `tools: array of BetaManagedAgentsWebFetchURLSourceToolReference`

                      The tools whose results contribute. Between 1 and 128 entries, each with a different name. An empty list is rejected; use "none" to allow no tool's results.

                      - `type: "tool_reference"`

                        Must be "tool_reference".

                      - `name: string`

                        Name of the tool. Compared exactly, so upper and lower case letters are different.

                        minLength: 1, maxLength: 128

                  - `BetaManagedAgentsWebFetchURLSourceExcept object`

                    Every tool's results contribute URLs that may be fetched, except the named tools' results.

                    - `type: "except"`

                    - `tools: array of BetaManagedAgentsWebFetchURLSourceToolReference`

                      The tools whose results do not contribute. Between 1 and 128 entries, each with a different name. An empty list is rejected; use "all" to leave out no tool's results.

                      - `type: "tool_reference"`

                        Must be "tool_reference".

                      - `name: string`

                        Name of the tool. Compared exactly, so upper and lower case letters are different.

                        minLength: 1, maxLength: 128

                - `server_tool_results: BetaManagedAgentsWebFetchURLSourceToolFilter or null`

                  Which of the web_search and web_fetch tools' results contribute URLs that may be fetched. Null when not set, which allows both.

                - `user_input: BetaManagedAgentsWebFetchURLSourceUserInput or null`

                  Whether URLs in the text of user messages may be fetched. Null when not set, which allows them.

                  - `BetaManagedAgentsWebFetchURLSourceAll object`

                    Every URL from this source may be fetched. This is the default.

                  - `BetaManagedAgentsWebFetchURLSourceNone object`

                    This source contributes no URLs that may be fetched.

              - `allowed_domains: optional array of string`

              - `blocked_domains: optional array of string`

              - `max_content_tokens: optional number or null`

                format: int32

            - `BetaManagedAgentsWebSearchToolConfig object`

              Configuration for the web_search tool.

              - `type: "web_search"`

              - `enabled: boolean`

              - `name: "web_search"`

              - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                Permission policy for tool execution.

                - `BetaManagedAgentsAlwaysAllowPolicy object`

                  Tool calls are automatically approved without user confirmation.

                - `BetaManagedAgentsAlwaysAskPolicy object`

                  Tool calls require user confirmation before execution.

                - `BetaManagedAgentsAutoPolicy object`

                  The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

              - `allowed_domains: optional array of string`

              - `blocked_domains: optional array of string`

              - `user_location: optional BetaManagedAgentsUserLocation or null`

                Approximate user location for search result localization.

                - `type: "approximate"`

                  Location precision. Only "approximate" is supported.

                - `city: optional string or null`

                  City name.

                  minLength: 1, maxLength: 255

                - `country: optional string or null`

                  Two-letter ISO 3166-1 country code, uppercase.

                - `region: optional string or null`

                  Region or state name.

                  minLength: 1, maxLength: 255

                - `timezone: optional string or null`

                  IANA timezone identifier, e.g. "America/Los_Angeles".

                  minLength: 1, maxLength: 255

          - `default_config: BetaManagedAgentsAgentToolsetDefaultConfig`

            Resolved default configuration for agent tools.

            - `enabled: boolean`

            - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

              Permission policy for tool execution.

              - `BetaManagedAgentsAlwaysAllowPolicy object`

                Tool calls are automatically approved without user confirmation.

              - `BetaManagedAgentsAlwaysAskPolicy object`

                Tool calls require user confirmation before execution.

              - `BetaManagedAgentsAutoPolicy object`

                The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

        - `BetaManagedAgentsMCPToolset object`

          - `type: "mcp_toolset"`

          - `configs: array of BetaManagedAgentsMCPToolConfig`

            - `enabled: boolean`

            - `name: string`

            - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

              Permission policy for tool execution.

              - `BetaManagedAgentsAlwaysAllowPolicy object`

                Tool calls are automatically approved without user confirmation.

              - `BetaManagedAgentsAlwaysAskPolicy object`

                Tool calls require user confirmation before execution.

              - `BetaManagedAgentsAutoPolicy object`

                The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

          - `default_config: BetaManagedAgentsMCPToolsetDefaultConfig`

            Resolved default configuration for all tools from an MCP server.

            - `enabled: boolean`

            - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

              Permission policy for tool execution.

              - `BetaManagedAgentsAlwaysAllowPolicy object`

                Tool calls are automatically approved without user confirmation.

              - `BetaManagedAgentsAlwaysAskPolicy object`

                Tool calls require user confirmation before execution.

              - `BetaManagedAgentsAutoPolicy object`

                The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

          - `mcp_server_name: string`

        - `BetaManagedAgentsCustomTool object`

          A custom tool as returned in API responses.

          - `type: "custom"`

          - `description: string`

          - `input_schema: BetaManagedAgentsCustomToolInputSchema`

            JSON Schema for custom tool input parameters.

            - `type: "object"`

            - `properties: optional map[unknown] or null`

            - `required: optional array of string or null`

          - `name: string`

      - `version: number`

        format: int32

  - `BetaManagedAgentsMultiagentSubagentsDisabled object`

    The agent cannot spawn session threads.

    - `type: "disabled"`

### Beta Managed Agents Session Multiagent Subagents Enabled

- `BetaManagedAgentsSessionMultiagentSubagentsEnabled object`

  The agent can spawn session threads.

  - `type: "enabled"`

  - `inline_agents: BetaManagedAgentsMultiagentInlineAgents`

    Whether the agent can define inline agents, which are not saved, when it spawns session threads.

    - `BetaManagedAgentsMultiagentInlineAgentsEnabled object`

      The agent can define inline agents.

      - `type: "enabled"`

    - `BetaManagedAgentsMultiagentInlineAgentsDisabled object`

      The agent cannot define inline agents.

      - `type: "disabled"`

  - `predefined_agents: array of BetaManagedAgentsSessionThreadAgent`

    Full `agent` definitions of the predefined agents, which are saved agents that this agent can spawn as session threads.

    - `type: "agent"`

    - `id: string`

    - `description: string or null`

    - `mcp_servers: array of BetaManagedAgentsMCPServerURLDefinition`

      - `type: "url"`

      - `name: string`

      - `url: string`

    - `model: BetaManagedAgentsModelConfig`

      Model identifier and configuration.

      - `id: BetaManagedAgentsModel`

        The model that will power your agent.

        See [models](https://docs.anthropic.com/en/docs/models-overview) for additional details and options.

        - `"claude-haiku-5-5"`

          Fastest model for high-volume, real-time tasks

        - `"claude-sonnet-5-5"`

          Efficient model for coding and agents

        - `"claude-opus-5-5"`

          Powerful intelligence for coding, knowledge work, and long-running agents

        - `"claude-fable-5-1"`

          Frontier intelligence for ambitious tasks across coding, scientific discovery, and enterprise workflows

        - `"claude-sonnet-5"`

          Efficient model for coding and agents

        - `"claude-fable-5"`

          Next generation of intelligence for the hardest knowledge work and coding problems

        - `"claude-opus-5"`

          Powerful intelligence for long-running agents and coding

        - `"claude-opus-4-8"`

          Powerful intelligence for long-running agents and coding

        - `"claude-opus-4-7"`

          Powerful intelligence for long-running agents and coding

        - `"claude-opus-4-6"`

          Powerful intelligence for long-running agents and coding

        - `"claude-sonnet-4-6"`

          Best combination of speed and intelligence

        - `"claude-haiku-4-5"`

        - `"claude-haiku-4-5-20251001"`

        - `"claude-opus-4-5"`

          Powerful intelligence for long-running agents and coding

        - `"claude-opus-4-5-20251101"`

          Powerful intelligence for long-running agents and coding

        - `"claude-sonnet-4-5"`

          **Deprecated**: Will reach end-of-life on November 30, 2026. Please migrate to claude-sonnet-5-5. Visit https://docs.anthropic.com/en/docs/resources/model-deprecations for more information.

          High-performance model for agents and coding

        - `"claude-sonnet-4-5-20250929"`

          **Deprecated**: Will reach end-of-life on November 30, 2026. Please migrate to claude-sonnet-5-5. Visit https://docs.anthropic.com/en/docs/resources/model-deprecations for more information.

          High-performance model for agents and coding

        - `string`

      - `effort: optional BetaManagedAgentsEffortLow or BetaManagedAgentsEffortMedium or BetaManagedAgentsEffortHigh or 2 more`

        How hard Claude works on each inference call. One of `low`, `medium`, `high`, `xhigh`, `max`. Always present; resolved to the per-model default at save time when not supplied.

        - `BetaManagedAgentsEffortLow object`

          Low effort. Favors latency over reasoning depth.

          - `type: "low"`

        - `BetaManagedAgentsEffortMedium object`

          Medium effort. Balances latency and reasoning depth.

          - `type: "medium"`

        - `BetaManagedAgentsEffortHigh object`

          High effort. Favors reasoning depth.

          - `type: "high"`

        - `BetaManagedAgentsEffortXhigh object`

          Extra-high effort. Not all models accept this level.

          - `type: "xhigh"`

        - `BetaManagedAgentsEffortMax object`

          Maximum effort. Favors reasoning depth over latency.

          - `type: "max"`

      - `inference_geo: optional string`

        Geographic region for model inference. When unset, requests fall through to the workspace's default_inference_geo.

      - `speed: optional "standard" or "fast"`

        Inference speed mode. `fast` provides significantly faster output token generation at premium pricing. Defaults to `standard`. Not all models support `fast`; invalid combinations are rejected at create time.

        - `"standard"`

        - `"fast"`

    - `name: string`

    - `skills: array of BetaManagedAgentsAnthropicSkill or BetaManagedAgentsCustomSkill`

      - `BetaManagedAgentsAnthropicSkill object`

        A resolved Anthropic-managed skill.

        - `type: "anthropic"`

        - `skill_id: string`

        - `version: string`

      - `BetaManagedAgentsCustomSkill object`

        A resolved user-created custom skill.

        - `type: "custom"`

        - `skill_id: string`

        - `version: string`

    - `system: string or null`

    - `tools: array of BetaManagedAgentsAgentToolset20260401 or BetaManagedAgentsMCPToolset or BetaManagedAgentsCustomTool`

      - `BetaManagedAgentsAgentToolset20260401 object`

        - `type: "agent_toolset_20260401"`

        - `configs: array of BetaManagedAgentsAgentToolConfig`

          - `BetaManagedAgentsBashToolConfig object`

            Configuration for the bash tool.

            - `type: "bash"`

            - `enabled: boolean`

            - `name: "bash"`

            - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

              Permission policy for tool execution.

              - `BetaManagedAgentsAlwaysAllowPolicy object`

                Tool calls are automatically approved without user confirmation.

                - `type: "always_allow"`

              - `BetaManagedAgentsAlwaysAskPolicy object`

                Tool calls require user confirmation before execution.

                - `type: "always_ask"`

              - `BetaManagedAgentsAutoPolicy object`

                The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

                - `type: "auto"`

          - `BetaManagedAgentsEditToolConfig object`

            Configuration for the edit tool.

            - `type: "edit"`

            - `enabled: boolean`

            - `name: "edit"`

            - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

              Permission policy for tool execution.

              - `BetaManagedAgentsAlwaysAllowPolicy object`

                Tool calls are automatically approved without user confirmation.

              - `BetaManagedAgentsAlwaysAskPolicy object`

                Tool calls require user confirmation before execution.

              - `BetaManagedAgentsAutoPolicy object`

                The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

          - `BetaManagedAgentsReadToolConfig object`

            Configuration for the read tool.

            - `type: "read"`

            - `enabled: boolean`

            - `name: "read"`

            - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

              Permission policy for tool execution.

              - `BetaManagedAgentsAlwaysAllowPolicy object`

                Tool calls are automatically approved without user confirmation.

              - `BetaManagedAgentsAlwaysAskPolicy object`

                Tool calls require user confirmation before execution.

              - `BetaManagedAgentsAutoPolicy object`

                The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

          - `BetaManagedAgentsWriteToolConfig object`

            Configuration for the write tool.

            - `type: "write"`

            - `enabled: boolean`

            - `name: "write"`

            - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

              Permission policy for tool execution.

              - `BetaManagedAgentsAlwaysAllowPolicy object`

                Tool calls are automatically approved without user confirmation.

              - `BetaManagedAgentsAlwaysAskPolicy object`

                Tool calls require user confirmation before execution.

              - `BetaManagedAgentsAutoPolicy object`

                The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

          - `BetaManagedAgentsGlobToolConfig object`

            Configuration for the glob tool.

            - `type: "glob"`

            - `enabled: boolean`

            - `name: "glob"`

            - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

              Permission policy for tool execution.

              - `BetaManagedAgentsAlwaysAllowPolicy object`

                Tool calls are automatically approved without user confirmation.

              - `BetaManagedAgentsAlwaysAskPolicy object`

                Tool calls require user confirmation before execution.

              - `BetaManagedAgentsAutoPolicy object`

                The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

          - `BetaManagedAgentsGrepToolConfig object`

            Configuration for the grep tool.

            - `type: "grep"`

            - `enabled: boolean`

            - `name: "grep"`

            - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

              Permission policy for tool execution.

              - `BetaManagedAgentsAlwaysAllowPolicy object`

                Tool calls are automatically approved without user confirmation.

              - `BetaManagedAgentsAlwaysAskPolicy object`

                Tool calls require user confirmation before execution.

              - `BetaManagedAgentsAutoPolicy object`

                The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

          - `BetaManagedAgentsWebFetchToolConfig object`

            Configuration for the web_fetch tool.

            - `type: "web_fetch"`

            - `enabled: boolean`

            - `name: "web_fetch"`

            - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

              Permission policy for tool execution.

              - `BetaManagedAgentsAlwaysAllowPolicy object`

                Tool calls are automatically approved without user confirmation.

              - `BetaManagedAgentsAlwaysAskPolicy object`

                Tool calls require user confirmation before execution.

              - `BetaManagedAgentsAutoPolicy object`

                The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

            - `url_sources: BetaManagedAgentsWebFetchURLSources or null`

              Which sources contribute URLs the tool may fetch, always in the object form. Null when not set, which allows every source.

              - `client_tool_results: BetaManagedAgentsWebFetchURLSourceToolFilter or null`

                Which custom tools' results contribute URLs that may be fetched. Null when not set, which allows every custom tool's results.

                - `BetaManagedAgentsWebFetchURLSourceAll object`

                  Every URL from this source may be fetched. This is the default.

                  - `type: "all"`

                - `BetaManagedAgentsWebFetchURLSourceNone object`

                  This source contributes no URLs that may be fetched.

                  - `type: "none"`

                - `BetaManagedAgentsWebFetchURLSourceOnly object`

                  Only the named tools' results contribute URLs that may be fetched.

                  - `type: "only"`

                  - `tools: array of BetaManagedAgentsWebFetchURLSourceToolReference`

                    The tools whose results contribute. Between 1 and 128 entries, each with a different name. An empty list is rejected; use "none" to allow no tool's results.

                    - `type: "tool_reference"`

                      Must be "tool_reference".

                    - `name: string`

                      Name of the tool. Compared exactly, so upper and lower case letters are different.

                      minLength: 1, maxLength: 128

                - `BetaManagedAgentsWebFetchURLSourceExcept object`

                  Every tool's results contribute URLs that may be fetched, except the named tools' results.

                  - `type: "except"`

                  - `tools: array of BetaManagedAgentsWebFetchURLSourceToolReference`

                    The tools whose results do not contribute. Between 1 and 128 entries, each with a different name. An empty list is rejected; use "all" to leave out no tool's results.

                    - `type: "tool_reference"`

                      Must be "tool_reference".

                    - `name: string`

                      Name of the tool. Compared exactly, so upper and lower case letters are different.

                      minLength: 1, maxLength: 128

              - `server_tool_results: BetaManagedAgentsWebFetchURLSourceToolFilter or null`

                Which of the web_search and web_fetch tools' results contribute URLs that may be fetched. Null when not set, which allows both.

              - `user_input: BetaManagedAgentsWebFetchURLSourceUserInput or null`

                Whether URLs in the text of user messages may be fetched. Null when not set, which allows them.

                - `BetaManagedAgentsWebFetchURLSourceAll object`

                  Every URL from this source may be fetched. This is the default.

                - `BetaManagedAgentsWebFetchURLSourceNone object`

                  This source contributes no URLs that may be fetched.

            - `allowed_domains: optional array of string`

            - `blocked_domains: optional array of string`

            - `max_content_tokens: optional number or null`

              format: int32

          - `BetaManagedAgentsWebSearchToolConfig object`

            Configuration for the web_search tool.

            - `type: "web_search"`

            - `enabled: boolean`

            - `name: "web_search"`

            - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

              Permission policy for tool execution.

              - `BetaManagedAgentsAlwaysAllowPolicy object`

                Tool calls are automatically approved without user confirmation.

              - `BetaManagedAgentsAlwaysAskPolicy object`

                Tool calls require user confirmation before execution.

              - `BetaManagedAgentsAutoPolicy object`

                The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

            - `allowed_domains: optional array of string`

            - `blocked_domains: optional array of string`

            - `user_location: optional BetaManagedAgentsUserLocation or null`

              Approximate user location for search result localization.

              - `type: "approximate"`

                Location precision. Only "approximate" is supported.

              - `city: optional string or null`

                City name.

                minLength: 1, maxLength: 255

              - `country: optional string or null`

                Two-letter ISO 3166-1 country code, uppercase.

              - `region: optional string or null`

                Region or state name.

                minLength: 1, maxLength: 255

              - `timezone: optional string or null`

                IANA timezone identifier, e.g. "America/Los_Angeles".

                minLength: 1, maxLength: 255

        - `default_config: BetaManagedAgentsAgentToolsetDefaultConfig`

          Resolved default configuration for agent tools.

          - `enabled: boolean`

          - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

            Permission policy for tool execution.

            - `BetaManagedAgentsAlwaysAllowPolicy object`

              Tool calls are automatically approved without user confirmation.

            - `BetaManagedAgentsAlwaysAskPolicy object`

              Tool calls require user confirmation before execution.

            - `BetaManagedAgentsAutoPolicy object`

              The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

      - `BetaManagedAgentsMCPToolset object`

        - `type: "mcp_toolset"`

        - `configs: array of BetaManagedAgentsMCPToolConfig`

          - `enabled: boolean`

          - `name: string`

          - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

            Permission policy for tool execution.

            - `BetaManagedAgentsAlwaysAllowPolicy object`

              Tool calls are automatically approved without user confirmation.

            - `BetaManagedAgentsAlwaysAskPolicy object`

              Tool calls require user confirmation before execution.

            - `BetaManagedAgentsAutoPolicy object`

              The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

        - `default_config: BetaManagedAgentsMCPToolsetDefaultConfig`

          Resolved default configuration for all tools from an MCP server.

          - `enabled: boolean`

          - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

            Permission policy for tool execution.

            - `BetaManagedAgentsAlwaysAllowPolicy object`

              Tool calls are automatically approved without user confirmation.

            - `BetaManagedAgentsAlwaysAskPolicy object`

              Tool calls require user confirmation before execution.

            - `BetaManagedAgentsAutoPolicy object`

              The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

        - `mcp_server_name: string`

      - `BetaManagedAgentsCustomTool object`

        A custom tool as returned in API responses.

        - `type: "custom"`

        - `description: string`

        - `input_schema: BetaManagedAgentsCustomToolInputSchema`

          JSON Schema for custom tool input parameters.

          - `type: "object"`

          - `properties: optional map[unknown] or null`

          - `required: optional array of string or null`

        - `name: string`

    - `version: number`

      format: int32

### Beta Managed Agents Session Multiagent Workflows

- `BetaManagedAgentsSessionMultiagentWorkflows = BetaManagedAgentsSessionMultiagentWorkflowsEnabled or BetaManagedAgentsMultiagentWorkflowsDisabled`

  Whether the agent can start workflow runs.

  - `BetaManagedAgentsSessionMultiagentWorkflowsEnabled object`

    The agent can start workflow runs.

    - `type: "enabled"`

    - `inline_agents: BetaManagedAgentsMultiagentInlineAgents`

      Whether a run's plan can define inline agents, which are not saved.

      - `BetaManagedAgentsMultiagentInlineAgentsEnabled object`

        The agent can define inline agents.

        - `type: "enabled"`

      - `BetaManagedAgentsMultiagentInlineAgentsDisabled object`

        The agent cannot define inline agents.

        - `type: "disabled"`

    - `predefined_agents: array of BetaManagedAgentsSessionThreadAgent`

      Full `agent` definitions of the predefined agents, which are saved agents that a run's plan can use.

      - `type: "agent"`

      - `id: string`

      - `description: string or null`

      - `mcp_servers: array of BetaManagedAgentsMCPServerURLDefinition`

        - `type: "url"`

        - `name: string`

        - `url: string`

      - `model: BetaManagedAgentsModelConfig`

        Model identifier and configuration.

        - `id: BetaManagedAgentsModel`

          The model that will power your agent.

          See [models](https://docs.anthropic.com/en/docs/models-overview) for additional details and options.

          - `"claude-haiku-5-5"`

            Fastest model for high-volume, real-time tasks

          - `"claude-sonnet-5-5"`

            Efficient model for coding and agents

          - `"claude-opus-5-5"`

            Powerful intelligence for coding, knowledge work, and long-running agents

          - `"claude-fable-5-1"`

            Frontier intelligence for ambitious tasks across coding, scientific discovery, and enterprise workflows

          - `"claude-sonnet-5"`

            Efficient model for coding and agents

          - `"claude-fable-5"`

            Next generation of intelligence for the hardest knowledge work and coding problems

          - `"claude-opus-5"`

            Powerful intelligence for long-running agents and coding

          - `"claude-opus-4-8"`

            Powerful intelligence for long-running agents and coding

          - `"claude-opus-4-7"`

            Powerful intelligence for long-running agents and coding

          - `"claude-opus-4-6"`

            Powerful intelligence for long-running agents and coding

          - `"claude-sonnet-4-6"`

            Best combination of speed and intelligence

          - `"claude-haiku-4-5"`

          - `"claude-haiku-4-5-20251001"`

          - `"claude-opus-4-5"`

            Powerful intelligence for long-running agents and coding

          - `"claude-opus-4-5-20251101"`

            Powerful intelligence for long-running agents and coding

          - `"claude-sonnet-4-5"`

            **Deprecated**: Will reach end-of-life on November 30, 2026. Please migrate to claude-sonnet-5-5. Visit https://docs.anthropic.com/en/docs/resources/model-deprecations for more information.

            High-performance model for agents and coding

          - `"claude-sonnet-4-5-20250929"`

            **Deprecated**: Will reach end-of-life on November 30, 2026. Please migrate to claude-sonnet-5-5. Visit https://docs.anthropic.com/en/docs/resources/model-deprecations for more information.

            High-performance model for agents and coding

          - `string`

        - `effort: optional BetaManagedAgentsEffortLow or BetaManagedAgentsEffortMedium or BetaManagedAgentsEffortHigh or 2 more`

          How hard Claude works on each inference call. One of `low`, `medium`, `high`, `xhigh`, `max`. Always present; resolved to the per-model default at save time when not supplied.

          - `BetaManagedAgentsEffortLow object`

            Low effort. Favors latency over reasoning depth.

            - `type: "low"`

          - `BetaManagedAgentsEffortMedium object`

            Medium effort. Balances latency and reasoning depth.

            - `type: "medium"`

          - `BetaManagedAgentsEffortHigh object`

            High effort. Favors reasoning depth.

            - `type: "high"`

          - `BetaManagedAgentsEffortXhigh object`

            Extra-high effort. Not all models accept this level.

            - `type: "xhigh"`

          - `BetaManagedAgentsEffortMax object`

            Maximum effort. Favors reasoning depth over latency.

            - `type: "max"`

        - `inference_geo: optional string`

          Geographic region for model inference. When unset, requests fall through to the workspace's default_inference_geo.

        - `speed: optional "standard" or "fast"`

          Inference speed mode. `fast` provides significantly faster output token generation at premium pricing. Defaults to `standard`. Not all models support `fast`; invalid combinations are rejected at create time.

          - `"standard"`

          - `"fast"`

      - `name: string`

      - `skills: array of BetaManagedAgentsAnthropicSkill or BetaManagedAgentsCustomSkill`

        - `BetaManagedAgentsAnthropicSkill object`

          A resolved Anthropic-managed skill.

          - `type: "anthropic"`

          - `skill_id: string`

          - `version: string`

        - `BetaManagedAgentsCustomSkill object`

          A resolved user-created custom skill.

          - `type: "custom"`

          - `skill_id: string`

          - `version: string`

      - `system: string or null`

      - `tools: array of BetaManagedAgentsAgentToolset20260401 or BetaManagedAgentsMCPToolset or BetaManagedAgentsCustomTool`

        - `BetaManagedAgentsAgentToolset20260401 object`

          - `type: "agent_toolset_20260401"`

          - `configs: array of BetaManagedAgentsAgentToolConfig`

            - `BetaManagedAgentsBashToolConfig object`

              Configuration for the bash tool.

              - `type: "bash"`

              - `enabled: boolean`

              - `name: "bash"`

              - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                Permission policy for tool execution.

                - `BetaManagedAgentsAlwaysAllowPolicy object`

                  Tool calls are automatically approved without user confirmation.

                  - `type: "always_allow"`

                - `BetaManagedAgentsAlwaysAskPolicy object`

                  Tool calls require user confirmation before execution.

                  - `type: "always_ask"`

                - `BetaManagedAgentsAutoPolicy object`

                  The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

                  - `type: "auto"`

            - `BetaManagedAgentsEditToolConfig object`

              Configuration for the edit tool.

              - `type: "edit"`

              - `enabled: boolean`

              - `name: "edit"`

              - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                Permission policy for tool execution.

                - `BetaManagedAgentsAlwaysAllowPolicy object`

                  Tool calls are automatically approved without user confirmation.

                - `BetaManagedAgentsAlwaysAskPolicy object`

                  Tool calls require user confirmation before execution.

                - `BetaManagedAgentsAutoPolicy object`

                  The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

            - `BetaManagedAgentsReadToolConfig object`

              Configuration for the read tool.

              - `type: "read"`

              - `enabled: boolean`

              - `name: "read"`

              - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                Permission policy for tool execution.

                - `BetaManagedAgentsAlwaysAllowPolicy object`

                  Tool calls are automatically approved without user confirmation.

                - `BetaManagedAgentsAlwaysAskPolicy object`

                  Tool calls require user confirmation before execution.

                - `BetaManagedAgentsAutoPolicy object`

                  The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

            - `BetaManagedAgentsWriteToolConfig object`

              Configuration for the write tool.

              - `type: "write"`

              - `enabled: boolean`

              - `name: "write"`

              - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                Permission policy for tool execution.

                - `BetaManagedAgentsAlwaysAllowPolicy object`

                  Tool calls are automatically approved without user confirmation.

                - `BetaManagedAgentsAlwaysAskPolicy object`

                  Tool calls require user confirmation before execution.

                - `BetaManagedAgentsAutoPolicy object`

                  The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

            - `BetaManagedAgentsGlobToolConfig object`

              Configuration for the glob tool.

              - `type: "glob"`

              - `enabled: boolean`

              - `name: "glob"`

              - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                Permission policy for tool execution.

                - `BetaManagedAgentsAlwaysAllowPolicy object`

                  Tool calls are automatically approved without user confirmation.

                - `BetaManagedAgentsAlwaysAskPolicy object`

                  Tool calls require user confirmation before execution.

                - `BetaManagedAgentsAutoPolicy object`

                  The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

            - `BetaManagedAgentsGrepToolConfig object`

              Configuration for the grep tool.

              - `type: "grep"`

              - `enabled: boolean`

              - `name: "grep"`

              - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                Permission policy for tool execution.

                - `BetaManagedAgentsAlwaysAllowPolicy object`

                  Tool calls are automatically approved without user confirmation.

                - `BetaManagedAgentsAlwaysAskPolicy object`

                  Tool calls require user confirmation before execution.

                - `BetaManagedAgentsAutoPolicy object`

                  The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

            - `BetaManagedAgentsWebFetchToolConfig object`

              Configuration for the web_fetch tool.

              - `type: "web_fetch"`

              - `enabled: boolean`

              - `name: "web_fetch"`

              - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                Permission policy for tool execution.

                - `BetaManagedAgentsAlwaysAllowPolicy object`

                  Tool calls are automatically approved without user confirmation.

                - `BetaManagedAgentsAlwaysAskPolicy object`

                  Tool calls require user confirmation before execution.

                - `BetaManagedAgentsAutoPolicy object`

                  The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

              - `url_sources: BetaManagedAgentsWebFetchURLSources or null`

                Which sources contribute URLs the tool may fetch, always in the object form. Null when not set, which allows every source.

                - `client_tool_results: BetaManagedAgentsWebFetchURLSourceToolFilter or null`

                  Which custom tools' results contribute URLs that may be fetched. Null when not set, which allows every custom tool's results.

                  - `BetaManagedAgentsWebFetchURLSourceAll object`

                    Every URL from this source may be fetched. This is the default.

                    - `type: "all"`

                  - `BetaManagedAgentsWebFetchURLSourceNone object`

                    This source contributes no URLs that may be fetched.

                    - `type: "none"`

                  - `BetaManagedAgentsWebFetchURLSourceOnly object`

                    Only the named tools' results contribute URLs that may be fetched.

                    - `type: "only"`

                    - `tools: array of BetaManagedAgentsWebFetchURLSourceToolReference`

                      The tools whose results contribute. Between 1 and 128 entries, each with a different name. An empty list is rejected; use "none" to allow no tool's results.

                      - `type: "tool_reference"`

                        Must be "tool_reference".

                      - `name: string`

                        Name of the tool. Compared exactly, so upper and lower case letters are different.

                        minLength: 1, maxLength: 128

                  - `BetaManagedAgentsWebFetchURLSourceExcept object`

                    Every tool's results contribute URLs that may be fetched, except the named tools' results.

                    - `type: "except"`

                    - `tools: array of BetaManagedAgentsWebFetchURLSourceToolReference`

                      The tools whose results do not contribute. Between 1 and 128 entries, each with a different name. An empty list is rejected; use "all" to leave out no tool's results.

                      - `type: "tool_reference"`

                        Must be "tool_reference".

                      - `name: string`

                        Name of the tool. Compared exactly, so upper and lower case letters are different.

                        minLength: 1, maxLength: 128

                - `server_tool_results: BetaManagedAgentsWebFetchURLSourceToolFilter or null`

                  Which of the web_search and web_fetch tools' results contribute URLs that may be fetched. Null when not set, which allows both.

                - `user_input: BetaManagedAgentsWebFetchURLSourceUserInput or null`

                  Whether URLs in the text of user messages may be fetched. Null when not set, which allows them.

                  - `BetaManagedAgentsWebFetchURLSourceAll object`

                    Every URL from this source may be fetched. This is the default.

                  - `BetaManagedAgentsWebFetchURLSourceNone object`

                    This source contributes no URLs that may be fetched.

              - `allowed_domains: optional array of string`

              - `blocked_domains: optional array of string`

              - `max_content_tokens: optional number or null`

                format: int32

            - `BetaManagedAgentsWebSearchToolConfig object`

              Configuration for the web_search tool.

              - `type: "web_search"`

              - `enabled: boolean`

              - `name: "web_search"`

              - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                Permission policy for tool execution.

                - `BetaManagedAgentsAlwaysAllowPolicy object`

                  Tool calls are automatically approved without user confirmation.

                - `BetaManagedAgentsAlwaysAskPolicy object`

                  Tool calls require user confirmation before execution.

                - `BetaManagedAgentsAutoPolicy object`

                  The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

              - `allowed_domains: optional array of string`

              - `blocked_domains: optional array of string`

              - `user_location: optional BetaManagedAgentsUserLocation or null`

                Approximate user location for search result localization.

                - `type: "approximate"`

                  Location precision. Only "approximate" is supported.

                - `city: optional string or null`

                  City name.

                  minLength: 1, maxLength: 255

                - `country: optional string or null`

                  Two-letter ISO 3166-1 country code, uppercase.

                - `region: optional string or null`

                  Region or state name.

                  minLength: 1, maxLength: 255

                - `timezone: optional string or null`

                  IANA timezone identifier, e.g. "America/Los_Angeles".

                  minLength: 1, maxLength: 255

          - `default_config: BetaManagedAgentsAgentToolsetDefaultConfig`

            Resolved default configuration for agent tools.

            - `enabled: boolean`

            - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

              Permission policy for tool execution.

              - `BetaManagedAgentsAlwaysAllowPolicy object`

                Tool calls are automatically approved without user confirmation.

              - `BetaManagedAgentsAlwaysAskPolicy object`

                Tool calls require user confirmation before execution.

              - `BetaManagedAgentsAutoPolicy object`

                The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

        - `BetaManagedAgentsMCPToolset object`

          - `type: "mcp_toolset"`

          - `configs: array of BetaManagedAgentsMCPToolConfig`

            - `enabled: boolean`

            - `name: string`

            - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

              Permission policy for tool execution.

              - `BetaManagedAgentsAlwaysAllowPolicy object`

                Tool calls are automatically approved without user confirmation.

              - `BetaManagedAgentsAlwaysAskPolicy object`

                Tool calls require user confirmation before execution.

              - `BetaManagedAgentsAutoPolicy object`

                The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

          - `default_config: BetaManagedAgentsMCPToolsetDefaultConfig`

            Resolved default configuration for all tools from an MCP server.

            - `enabled: boolean`

            - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

              Permission policy for tool execution.

              - `BetaManagedAgentsAlwaysAllowPolicy object`

                Tool calls are automatically approved without user confirmation.

              - `BetaManagedAgentsAlwaysAskPolicy object`

                Tool calls require user confirmation before execution.

              - `BetaManagedAgentsAutoPolicy object`

                The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

          - `mcp_server_name: string`

        - `BetaManagedAgentsCustomTool object`

          A custom tool as returned in API responses.

          - `type: "custom"`

          - `description: string`

          - `input_schema: BetaManagedAgentsCustomToolInputSchema`

            JSON Schema for custom tool input parameters.

            - `type: "object"`

            - `properties: optional map[unknown] or null`

            - `required: optional array of string or null`

          - `name: string`

      - `version: number`

        format: int32

  - `BetaManagedAgentsMultiagentWorkflowsDisabled object`

    The agent cannot start workflow runs.

    - `type: "disabled"`

### Beta Managed Agents Session Multiagent Workflows Enabled

- `BetaManagedAgentsSessionMultiagentWorkflowsEnabled object`

  The agent can start workflow runs.

  - `type: "enabled"`

  - `inline_agents: BetaManagedAgentsMultiagentInlineAgents`

    Whether a run's plan can define inline agents, which are not saved.

    - `BetaManagedAgentsMultiagentInlineAgentsEnabled object`

      The agent can define inline agents.

      - `type: "enabled"`

    - `BetaManagedAgentsMultiagentInlineAgentsDisabled object`

      The agent cannot define inline agents.

      - `type: "disabled"`

  - `predefined_agents: array of BetaManagedAgentsSessionThreadAgent`

    Full `agent` definitions of the predefined agents, which are saved agents that a run's plan can use.

    - `type: "agent"`

    - `id: string`

    - `description: string or null`

    - `mcp_servers: array of BetaManagedAgentsMCPServerURLDefinition`

      - `type: "url"`

      - `name: string`

      - `url: string`

    - `model: BetaManagedAgentsModelConfig`

      Model identifier and configuration.

      - `id: BetaManagedAgentsModel`

        The model that will power your agent.

        See [models](https://docs.anthropic.com/en/docs/models-overview) for additional details and options.

        - `"claude-haiku-5-5"`

          Fastest model for high-volume, real-time tasks

        - `"claude-sonnet-5-5"`

          Efficient model for coding and agents

        - `"claude-opus-5-5"`

          Powerful intelligence for coding, knowledge work, and long-running agents

        - `"claude-fable-5-1"`

          Frontier intelligence for ambitious tasks across coding, scientific discovery, and enterprise workflows

        - `"claude-sonnet-5"`

          Efficient model for coding and agents

        - `"claude-fable-5"`

          Next generation of intelligence for the hardest knowledge work and coding problems

        - `"claude-opus-5"`

          Powerful intelligence for long-running agents and coding

        - `"claude-opus-4-8"`

          Powerful intelligence for long-running agents and coding

        - `"claude-opus-4-7"`

          Powerful intelligence for long-running agents and coding

        - `"claude-opus-4-6"`

          Powerful intelligence for long-running agents and coding

        - `"claude-sonnet-4-6"`

          Best combination of speed and intelligence

        - `"claude-haiku-4-5"`

        - `"claude-haiku-4-5-20251001"`

        - `"claude-opus-4-5"`

          Powerful intelligence for long-running agents and coding

        - `"claude-opus-4-5-20251101"`

          Powerful intelligence for long-running agents and coding

        - `"claude-sonnet-4-5"`

          **Deprecated**: Will reach end-of-life on November 30, 2026. Please migrate to claude-sonnet-5-5. Visit https://docs.anthropic.com/en/docs/resources/model-deprecations for more information.

          High-performance model for agents and coding

        - `"claude-sonnet-4-5-20250929"`

          **Deprecated**: Will reach end-of-life on November 30, 2026. Please migrate to claude-sonnet-5-5. Visit https://docs.anthropic.com/en/docs/resources/model-deprecations for more information.

          High-performance model for agents and coding

        - `string`

      - `effort: optional BetaManagedAgentsEffortLow or BetaManagedAgentsEffortMedium or BetaManagedAgentsEffortHigh or 2 more`

        How hard Claude works on each inference call. One of `low`, `medium`, `high`, `xhigh`, `max`. Always present; resolved to the per-model default at save time when not supplied.

        - `BetaManagedAgentsEffortLow object`

          Low effort. Favors latency over reasoning depth.

          - `type: "low"`

        - `BetaManagedAgentsEffortMedium object`

          Medium effort. Balances latency and reasoning depth.

          - `type: "medium"`

        - `BetaManagedAgentsEffortHigh object`

          High effort. Favors reasoning depth.

          - `type: "high"`

        - `BetaManagedAgentsEffortXhigh object`

          Extra-high effort. Not all models accept this level.

          - `type: "xhigh"`

        - `BetaManagedAgentsEffortMax object`

          Maximum effort. Favors reasoning depth over latency.

          - `type: "max"`

      - `inference_geo: optional string`

        Geographic region for model inference. When unset, requests fall through to the workspace's default_inference_geo.

      - `speed: optional "standard" or "fast"`

        Inference speed mode. `fast` provides significantly faster output token generation at premium pricing. Defaults to `standard`. Not all models support `fast`; invalid combinations are rejected at create time.

        - `"standard"`

        - `"fast"`

    - `name: string`

    - `skills: array of BetaManagedAgentsAnthropicSkill or BetaManagedAgentsCustomSkill`

      - `BetaManagedAgentsAnthropicSkill object`

        A resolved Anthropic-managed skill.

        - `type: "anthropic"`

        - `skill_id: string`

        - `version: string`

      - `BetaManagedAgentsCustomSkill object`

        A resolved user-created custom skill.

        - `type: "custom"`

        - `skill_id: string`

        - `version: string`

    - `system: string or null`

    - `tools: array of BetaManagedAgentsAgentToolset20260401 or BetaManagedAgentsMCPToolset or BetaManagedAgentsCustomTool`

      - `BetaManagedAgentsAgentToolset20260401 object`

        - `type: "agent_toolset_20260401"`

        - `configs: array of BetaManagedAgentsAgentToolConfig`

          - `BetaManagedAgentsBashToolConfig object`

            Configuration for the bash tool.

            - `type: "bash"`

            - `enabled: boolean`

            - `name: "bash"`

            - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

              Permission policy for tool execution.

              - `BetaManagedAgentsAlwaysAllowPolicy object`

                Tool calls are automatically approved without user confirmation.

                - `type: "always_allow"`

              - `BetaManagedAgentsAlwaysAskPolicy object`

                Tool calls require user confirmation before execution.

                - `type: "always_ask"`

              - `BetaManagedAgentsAutoPolicy object`

                The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

                - `type: "auto"`

          - `BetaManagedAgentsEditToolConfig object`

            Configuration for the edit tool.

            - `type: "edit"`

            - `enabled: boolean`

            - `name: "edit"`

            - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

              Permission policy for tool execution.

              - `BetaManagedAgentsAlwaysAllowPolicy object`

                Tool calls are automatically approved without user confirmation.

              - `BetaManagedAgentsAlwaysAskPolicy object`

                Tool calls require user confirmation before execution.

              - `BetaManagedAgentsAutoPolicy object`

                The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

          - `BetaManagedAgentsReadToolConfig object`

            Configuration for the read tool.

            - `type: "read"`

            - `enabled: boolean`

            - `name: "read"`

            - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

              Permission policy for tool execution.

              - `BetaManagedAgentsAlwaysAllowPolicy object`

                Tool calls are automatically approved without user confirmation.

              - `BetaManagedAgentsAlwaysAskPolicy object`

                Tool calls require user confirmation before execution.

              - `BetaManagedAgentsAutoPolicy object`

                The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

          - `BetaManagedAgentsWriteToolConfig object`

            Configuration for the write tool.

            - `type: "write"`

            - `enabled: boolean`

            - `name: "write"`

            - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

              Permission policy for tool execution.

              - `BetaManagedAgentsAlwaysAllowPolicy object`

                Tool calls are automatically approved without user confirmation.

              - `BetaManagedAgentsAlwaysAskPolicy object`

                Tool calls require user confirmation before execution.

              - `BetaManagedAgentsAutoPolicy object`

                The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

          - `BetaManagedAgentsGlobToolConfig object`

            Configuration for the glob tool.

            - `type: "glob"`

            - `enabled: boolean`

            - `name: "glob"`

            - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

              Permission policy for tool execution.

              - `BetaManagedAgentsAlwaysAllowPolicy object`

                Tool calls are automatically approved without user confirmation.

              - `BetaManagedAgentsAlwaysAskPolicy object`

                Tool calls require user confirmation before execution.

              - `BetaManagedAgentsAutoPolicy object`

                The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

          - `BetaManagedAgentsGrepToolConfig object`

            Configuration for the grep tool.

            - `type: "grep"`

            - `enabled: boolean`

            - `name: "grep"`

            - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

              Permission policy for tool execution.

              - `BetaManagedAgentsAlwaysAllowPolicy object`

                Tool calls are automatically approved without user confirmation.

              - `BetaManagedAgentsAlwaysAskPolicy object`

                Tool calls require user confirmation before execution.

              - `BetaManagedAgentsAutoPolicy object`

                The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

          - `BetaManagedAgentsWebFetchToolConfig object`

            Configuration for the web_fetch tool.

            - `type: "web_fetch"`

            - `enabled: boolean`

            - `name: "web_fetch"`

            - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

              Permission policy for tool execution.

              - `BetaManagedAgentsAlwaysAllowPolicy object`

                Tool calls are automatically approved without user confirmation.

              - `BetaManagedAgentsAlwaysAskPolicy object`

                Tool calls require user confirmation before execution.

              - `BetaManagedAgentsAutoPolicy object`

                The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

            - `url_sources: BetaManagedAgentsWebFetchURLSources or null`

              Which sources contribute URLs the tool may fetch, always in the object form. Null when not set, which allows every source.

              - `client_tool_results: BetaManagedAgentsWebFetchURLSourceToolFilter or null`

                Which custom tools' results contribute URLs that may be fetched. Null when not set, which allows every custom tool's results.

                - `BetaManagedAgentsWebFetchURLSourceAll object`

                  Every URL from this source may be fetched. This is the default.

                  - `type: "all"`

                - `BetaManagedAgentsWebFetchURLSourceNone object`

                  This source contributes no URLs that may be fetched.

                  - `type: "none"`

                - `BetaManagedAgentsWebFetchURLSourceOnly object`

                  Only the named tools' results contribute URLs that may be fetched.

                  - `type: "only"`

                  - `tools: array of BetaManagedAgentsWebFetchURLSourceToolReference`

                    The tools whose results contribute. Between 1 and 128 entries, each with a different name. An empty list is rejected; use "none" to allow no tool's results.

                    - `type: "tool_reference"`

                      Must be "tool_reference".

                    - `name: string`

                      Name of the tool. Compared exactly, so upper and lower case letters are different.

                      minLength: 1, maxLength: 128

                - `BetaManagedAgentsWebFetchURLSourceExcept object`

                  Every tool's results contribute URLs that may be fetched, except the named tools' results.

                  - `type: "except"`

                  - `tools: array of BetaManagedAgentsWebFetchURLSourceToolReference`

                    The tools whose results do not contribute. Between 1 and 128 entries, each with a different name. An empty list is rejected; use "all" to leave out no tool's results.

                    - `type: "tool_reference"`

                      Must be "tool_reference".

                    - `name: string`

                      Name of the tool. Compared exactly, so upper and lower case letters are different.

                      minLength: 1, maxLength: 128

              - `server_tool_results: BetaManagedAgentsWebFetchURLSourceToolFilter or null`

                Which of the web_search and web_fetch tools' results contribute URLs that may be fetched. Null when not set, which allows both.

              - `user_input: BetaManagedAgentsWebFetchURLSourceUserInput or null`

                Whether URLs in the text of user messages may be fetched. Null when not set, which allows them.

                - `BetaManagedAgentsWebFetchURLSourceAll object`

                  Every URL from this source may be fetched. This is the default.

                - `BetaManagedAgentsWebFetchURLSourceNone object`

                  This source contributes no URLs that may be fetched.

            - `allowed_domains: optional array of string`

            - `blocked_domains: optional array of string`

            - `max_content_tokens: optional number or null`

              format: int32

          - `BetaManagedAgentsWebSearchToolConfig object`

            Configuration for the web_search tool.

            - `type: "web_search"`

            - `enabled: boolean`

            - `name: "web_search"`

            - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

              Permission policy for tool execution.

              - `BetaManagedAgentsAlwaysAllowPolicy object`

                Tool calls are automatically approved without user confirmation.

              - `BetaManagedAgentsAlwaysAskPolicy object`

                Tool calls require user confirmation before execution.

              - `BetaManagedAgentsAutoPolicy object`

                The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

            - `allowed_domains: optional array of string`

            - `blocked_domains: optional array of string`

            - `user_location: optional BetaManagedAgentsUserLocation or null`

              Approximate user location for search result localization.

              - `type: "approximate"`

                Location precision. Only "approximate" is supported.

              - `city: optional string or null`

                City name.

                minLength: 1, maxLength: 255

              - `country: optional string or null`

                Two-letter ISO 3166-1 country code, uppercase.

              - `region: optional string or null`

                Region or state name.

                minLength: 1, maxLength: 255

              - `timezone: optional string or null`

                IANA timezone identifier, e.g. "America/Los_Angeles".

                minLength: 1, maxLength: 255

        - `default_config: BetaManagedAgentsAgentToolsetDefaultConfig`

          Resolved default configuration for agent tools.

          - `enabled: boolean`

          - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

            Permission policy for tool execution.

            - `BetaManagedAgentsAlwaysAllowPolicy object`

              Tool calls are automatically approved without user confirmation.

            - `BetaManagedAgentsAlwaysAskPolicy object`

              Tool calls require user confirmation before execution.

            - `BetaManagedAgentsAutoPolicy object`

              The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

      - `BetaManagedAgentsMCPToolset object`

        - `type: "mcp_toolset"`

        - `configs: array of BetaManagedAgentsMCPToolConfig`

          - `enabled: boolean`

          - `name: string`

          - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

            Permission policy for tool execution.

            - `BetaManagedAgentsAlwaysAllowPolicy object`

              Tool calls are automatically approved without user confirmation.

            - `BetaManagedAgentsAlwaysAskPolicy object`

              Tool calls require user confirmation before execution.

            - `BetaManagedAgentsAutoPolicy object`

              The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

        - `default_config: BetaManagedAgentsMCPToolsetDefaultConfig`

          Resolved default configuration for all tools from an MCP server.

          - `enabled: boolean`

          - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

            Permission policy for tool execution.

            - `BetaManagedAgentsAlwaysAllowPolicy object`

              Tool calls are automatically approved without user confirmation.

            - `BetaManagedAgentsAlwaysAskPolicy object`

              Tool calls require user confirmation before execution.

            - `BetaManagedAgentsAutoPolicy object`

              The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

        - `mcp_server_name: string`

      - `BetaManagedAgentsCustomTool object`

        A custom tool as returned in API responses.

        - `type: "custom"`

        - `description: string`

        - `input_schema: BetaManagedAgentsCustomToolInputSchema`

          JSON Schema for custom tool input parameters.

          - `type: "object"`

          - `properties: optional map[unknown] or null`

          - `required: optional array of string or null`

        - `name: string`

    - `version: number`

      format: int32

### Beta Managed Agents Session Multiagent20261001

- `BetaManagedAgentsSessionMultiagent20261001 object`

  Resolved multiagent configuration with three members, as copied to the `session` at creation.

  - `type: "multiagent_20261001"`

  - `advisor: BetaManagedAgentsMultiagentAdvisor`

    Whether the session's primary thread can consult an advisor model.

    - `BetaManagedAgentsMultiagentAdvisorEnabled object`

      The session's primary thread can consult `model` mid-turn.

      - `type: "enabled"`

      - `model: string`

        The advisor model id.

    - `BetaManagedAgentsMultiagentAdvisorDisabled object`

      The agent has no advisor.

      - `type: "disabled"`

  - `subagents: BetaManagedAgentsSessionMultiagentSubagents`

    Whether the agent can spawn session threads.

    - `BetaManagedAgentsSessionMultiagentSubagentsEnabled object`

      The agent can spawn session threads.

      - `type: "enabled"`

      - `inline_agents: BetaManagedAgentsMultiagentInlineAgents`

        Whether the agent can define inline agents, which are not saved, when it spawns session threads.

        - `BetaManagedAgentsMultiagentInlineAgentsEnabled object`

          The agent can define inline agents.

          - `type: "enabled"`

        - `BetaManagedAgentsMultiagentInlineAgentsDisabled object`

          The agent cannot define inline agents.

          - `type: "disabled"`

      - `predefined_agents: array of BetaManagedAgentsSessionThreadAgent`

        Full `agent` definitions of the predefined agents, which are saved agents that this agent can spawn as session threads.

        - `type: "agent"`

        - `id: string`

        - `description: string or null`

        - `mcp_servers: array of BetaManagedAgentsMCPServerURLDefinition`

          - `type: "url"`

          - `name: string`

          - `url: string`

        - `model: BetaManagedAgentsModelConfig`

          Model identifier and configuration.

          - `id: BetaManagedAgentsModel`

            The model that will power your agent.

            See [models](https://docs.anthropic.com/en/docs/models-overview) for additional details and options.

            - `"claude-haiku-5-5"`

              Fastest model for high-volume, real-time tasks

            - `"claude-sonnet-5-5"`

              Efficient model for coding and agents

            - `"claude-opus-5-5"`

              Powerful intelligence for coding, knowledge work, and long-running agents

            - `"claude-fable-5-1"`

              Frontier intelligence for ambitious tasks across coding, scientific discovery, and enterprise workflows

            - `"claude-sonnet-5"`

              Efficient model for coding and agents

            - `"claude-fable-5"`

              Next generation of intelligence for the hardest knowledge work and coding problems

            - `"claude-opus-5"`

              Powerful intelligence for long-running agents and coding

            - `"claude-opus-4-8"`

              Powerful intelligence for long-running agents and coding

            - `"claude-opus-4-7"`

              Powerful intelligence for long-running agents and coding

            - `"claude-opus-4-6"`

              Powerful intelligence for long-running agents and coding

            - `"claude-sonnet-4-6"`

              Best combination of speed and intelligence

            - `"claude-haiku-4-5"`

            - `"claude-haiku-4-5-20251001"`

            - `"claude-opus-4-5"`

              Powerful intelligence for long-running agents and coding

            - `"claude-opus-4-5-20251101"`

              Powerful intelligence for long-running agents and coding

            - `"claude-sonnet-4-5"`

              **Deprecated**: Will reach end-of-life on November 30, 2026. Please migrate to claude-sonnet-5-5. Visit https://docs.anthropic.com/en/docs/resources/model-deprecations for more information.

              High-performance model for agents and coding

            - `"claude-sonnet-4-5-20250929"`

              **Deprecated**: Will reach end-of-life on November 30, 2026. Please migrate to claude-sonnet-5-5. Visit https://docs.anthropic.com/en/docs/resources/model-deprecations for more information.

              High-performance model for agents and coding

            - `string`

          - `effort: optional BetaManagedAgentsEffortLow or BetaManagedAgentsEffortMedium or BetaManagedAgentsEffortHigh or 2 more`

            How hard Claude works on each inference call. One of `low`, `medium`, `high`, `xhigh`, `max`. Always present; resolved to the per-model default at save time when not supplied.

            - `BetaManagedAgentsEffortLow object`

              Low effort. Favors latency over reasoning depth.

              - `type: "low"`

            - `BetaManagedAgentsEffortMedium object`

              Medium effort. Balances latency and reasoning depth.

              - `type: "medium"`

            - `BetaManagedAgentsEffortHigh object`

              High effort. Favors reasoning depth.

              - `type: "high"`

            - `BetaManagedAgentsEffortXhigh object`

              Extra-high effort. Not all models accept this level.

              - `type: "xhigh"`

            - `BetaManagedAgentsEffortMax object`

              Maximum effort. Favors reasoning depth over latency.

              - `type: "max"`

          - `inference_geo: optional string`

            Geographic region for model inference. When unset, requests fall through to the workspace's default_inference_geo.

          - `speed: optional "standard" or "fast"`

            Inference speed mode. `fast` provides significantly faster output token generation at premium pricing. Defaults to `standard`. Not all models support `fast`; invalid combinations are rejected at create time.

            - `"standard"`

            - `"fast"`

        - `name: string`

        - `skills: array of BetaManagedAgentsAnthropicSkill or BetaManagedAgentsCustomSkill`

          - `BetaManagedAgentsAnthropicSkill object`

            A resolved Anthropic-managed skill.

            - `type: "anthropic"`

            - `skill_id: string`

            - `version: string`

          - `BetaManagedAgentsCustomSkill object`

            A resolved user-created custom skill.

            - `type: "custom"`

            - `skill_id: string`

            - `version: string`

        - `system: string or null`

        - `tools: array of BetaManagedAgentsAgentToolset20260401 or BetaManagedAgentsMCPToolset or BetaManagedAgentsCustomTool`

          - `BetaManagedAgentsAgentToolset20260401 object`

            - `type: "agent_toolset_20260401"`

            - `configs: array of BetaManagedAgentsAgentToolConfig`

              - `BetaManagedAgentsBashToolConfig object`

                Configuration for the bash tool.

                - `type: "bash"`

                - `enabled: boolean`

                - `name: "bash"`

                - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                  Permission policy for tool execution.

                  - `BetaManagedAgentsAlwaysAllowPolicy object`

                    Tool calls are automatically approved without user confirmation.

                    - `type: "always_allow"`

                  - `BetaManagedAgentsAlwaysAskPolicy object`

                    Tool calls require user confirmation before execution.

                    - `type: "always_ask"`

                  - `BetaManagedAgentsAutoPolicy object`

                    The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

                    - `type: "auto"`

              - `BetaManagedAgentsEditToolConfig object`

                Configuration for the edit tool.

                - `type: "edit"`

                - `enabled: boolean`

                - `name: "edit"`

                - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                  Permission policy for tool execution.

                  - `BetaManagedAgentsAlwaysAllowPolicy object`

                    Tool calls are automatically approved without user confirmation.

                  - `BetaManagedAgentsAlwaysAskPolicy object`

                    Tool calls require user confirmation before execution.

                  - `BetaManagedAgentsAutoPolicy object`

                    The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

              - `BetaManagedAgentsReadToolConfig object`

                Configuration for the read tool.

                - `type: "read"`

                - `enabled: boolean`

                - `name: "read"`

                - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                  Permission policy for tool execution.

                  - `BetaManagedAgentsAlwaysAllowPolicy object`

                    Tool calls are automatically approved without user confirmation.

                  - `BetaManagedAgentsAlwaysAskPolicy object`

                    Tool calls require user confirmation before execution.

                  - `BetaManagedAgentsAutoPolicy object`

                    The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

              - `BetaManagedAgentsWriteToolConfig object`

                Configuration for the write tool.

                - `type: "write"`

                - `enabled: boolean`

                - `name: "write"`

                - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                  Permission policy for tool execution.

                  - `BetaManagedAgentsAlwaysAllowPolicy object`

                    Tool calls are automatically approved without user confirmation.

                  - `BetaManagedAgentsAlwaysAskPolicy object`

                    Tool calls require user confirmation before execution.

                  - `BetaManagedAgentsAutoPolicy object`

                    The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

              - `BetaManagedAgentsGlobToolConfig object`

                Configuration for the glob tool.

                - `type: "glob"`

                - `enabled: boolean`

                - `name: "glob"`

                - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                  Permission policy for tool execution.

                  - `BetaManagedAgentsAlwaysAllowPolicy object`

                    Tool calls are automatically approved without user confirmation.

                  - `BetaManagedAgentsAlwaysAskPolicy object`

                    Tool calls require user confirmation before execution.

                  - `BetaManagedAgentsAutoPolicy object`

                    The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

              - `BetaManagedAgentsGrepToolConfig object`

                Configuration for the grep tool.

                - `type: "grep"`

                - `enabled: boolean`

                - `name: "grep"`

                - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                  Permission policy for tool execution.

                  - `BetaManagedAgentsAlwaysAllowPolicy object`

                    Tool calls are automatically approved without user confirmation.

                  - `BetaManagedAgentsAlwaysAskPolicy object`

                    Tool calls require user confirmation before execution.

                  - `BetaManagedAgentsAutoPolicy object`

                    The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

              - `BetaManagedAgentsWebFetchToolConfig object`

                Configuration for the web_fetch tool.

                - `type: "web_fetch"`

                - `enabled: boolean`

                - `name: "web_fetch"`

                - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                  Permission policy for tool execution.

                  - `BetaManagedAgentsAlwaysAllowPolicy object`

                    Tool calls are automatically approved without user confirmation.

                  - `BetaManagedAgentsAlwaysAskPolicy object`

                    Tool calls require user confirmation before execution.

                  - `BetaManagedAgentsAutoPolicy object`

                    The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

                - `url_sources: BetaManagedAgentsWebFetchURLSources or null`

                  Which sources contribute URLs the tool may fetch, always in the object form. Null when not set, which allows every source.

                  - `client_tool_results: BetaManagedAgentsWebFetchURLSourceToolFilter or null`

                    Which custom tools' results contribute URLs that may be fetched. Null when not set, which allows every custom tool's results.

                    - `BetaManagedAgentsWebFetchURLSourceAll object`

                      Every URL from this source may be fetched. This is the default.

                      - `type: "all"`

                    - `BetaManagedAgentsWebFetchURLSourceNone object`

                      This source contributes no URLs that may be fetched.

                      - `type: "none"`

                    - `BetaManagedAgentsWebFetchURLSourceOnly object`

                      Only the named tools' results contribute URLs that may be fetched.

                      - `type: "only"`

                      - `tools: array of BetaManagedAgentsWebFetchURLSourceToolReference`

                        The tools whose results contribute. Between 1 and 128 entries, each with a different name. An empty list is rejected; use "none" to allow no tool's results.

                        - `type: "tool_reference"`

                          Must be "tool_reference".

                        - `name: string`

                          Name of the tool. Compared exactly, so upper and lower case letters are different.

                          minLength: 1, maxLength: 128

                    - `BetaManagedAgentsWebFetchURLSourceExcept object`

                      Every tool's results contribute URLs that may be fetched, except the named tools' results.

                      - `type: "except"`

                      - `tools: array of BetaManagedAgentsWebFetchURLSourceToolReference`

                        The tools whose results do not contribute. Between 1 and 128 entries, each with a different name. An empty list is rejected; use "all" to leave out no tool's results.

                        - `type: "tool_reference"`

                          Must be "tool_reference".

                        - `name: string`

                          Name of the tool. Compared exactly, so upper and lower case letters are different.

                          minLength: 1, maxLength: 128

                  - `server_tool_results: BetaManagedAgentsWebFetchURLSourceToolFilter or null`

                    Which of the web_search and web_fetch tools' results contribute URLs that may be fetched. Null when not set, which allows both.

                  - `user_input: BetaManagedAgentsWebFetchURLSourceUserInput or null`

                    Whether URLs in the text of user messages may be fetched. Null when not set, which allows them.

                    - `BetaManagedAgentsWebFetchURLSourceAll object`

                      Every URL from this source may be fetched. This is the default.

                    - `BetaManagedAgentsWebFetchURLSourceNone object`

                      This source contributes no URLs that may be fetched.

                - `allowed_domains: optional array of string`

                - `blocked_domains: optional array of string`

                - `max_content_tokens: optional number or null`

                  format: int32

              - `BetaManagedAgentsWebSearchToolConfig object`

                Configuration for the web_search tool.

                - `type: "web_search"`

                - `enabled: boolean`

                - `name: "web_search"`

                - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                  Permission policy for tool execution.

                  - `BetaManagedAgentsAlwaysAllowPolicy object`

                    Tool calls are automatically approved without user confirmation.

                  - `BetaManagedAgentsAlwaysAskPolicy object`

                    Tool calls require user confirmation before execution.

                  - `BetaManagedAgentsAutoPolicy object`

                    The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

                - `allowed_domains: optional array of string`

                - `blocked_domains: optional array of string`

                - `user_location: optional BetaManagedAgentsUserLocation or null`

                  Approximate user location for search result localization.

                  - `type: "approximate"`

                    Location precision. Only "approximate" is supported.

                  - `city: optional string or null`

                    City name.

                    minLength: 1, maxLength: 255

                  - `country: optional string or null`

                    Two-letter ISO 3166-1 country code, uppercase.

                  - `region: optional string or null`

                    Region or state name.

                    minLength: 1, maxLength: 255

                  - `timezone: optional string or null`

                    IANA timezone identifier, e.g. "America/Los_Angeles".

                    minLength: 1, maxLength: 255

            - `default_config: BetaManagedAgentsAgentToolsetDefaultConfig`

              Resolved default configuration for agent tools.

              - `enabled: boolean`

              - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                Permission policy for tool execution.

                - `BetaManagedAgentsAlwaysAllowPolicy object`

                  Tool calls are automatically approved without user confirmation.

                - `BetaManagedAgentsAlwaysAskPolicy object`

                  Tool calls require user confirmation before execution.

                - `BetaManagedAgentsAutoPolicy object`

                  The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

          - `BetaManagedAgentsMCPToolset object`

            - `type: "mcp_toolset"`

            - `configs: array of BetaManagedAgentsMCPToolConfig`

              - `enabled: boolean`

              - `name: string`

              - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                Permission policy for tool execution.

                - `BetaManagedAgentsAlwaysAllowPolicy object`

                  Tool calls are automatically approved without user confirmation.

                - `BetaManagedAgentsAlwaysAskPolicy object`

                  Tool calls require user confirmation before execution.

                - `BetaManagedAgentsAutoPolicy object`

                  The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

            - `default_config: BetaManagedAgentsMCPToolsetDefaultConfig`

              Resolved default configuration for all tools from an MCP server.

              - `enabled: boolean`

              - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                Permission policy for tool execution.

                - `BetaManagedAgentsAlwaysAllowPolicy object`

                  Tool calls are automatically approved without user confirmation.

                - `BetaManagedAgentsAlwaysAskPolicy object`

                  Tool calls require user confirmation before execution.

                - `BetaManagedAgentsAutoPolicy object`

                  The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

            - `mcp_server_name: string`

          - `BetaManagedAgentsCustomTool object`

            A custom tool as returned in API responses.

            - `type: "custom"`

            - `description: string`

            - `input_schema: BetaManagedAgentsCustomToolInputSchema`

              JSON Schema for custom tool input parameters.

              - `type: "object"`

              - `properties: optional map[unknown] or null`

              - `required: optional array of string or null`

            - `name: string`

        - `version: number`

          format: int32

    - `BetaManagedAgentsMultiagentSubagentsDisabled object`

      The agent cannot spawn session threads.

      - `type: "disabled"`

  - `workflows: BetaManagedAgentsSessionMultiagentWorkflows`

    Whether the agent can start workflow runs.

    - `BetaManagedAgentsSessionMultiagentWorkflowsEnabled object`

      The agent can start workflow runs.

      - `type: "enabled"`

      - `inline_agents: BetaManagedAgentsMultiagentInlineAgents`

        Whether a run's plan can define inline agents, which are not saved.

      - `predefined_agents: array of BetaManagedAgentsSessionThreadAgent`

        Full `agent` definitions of the predefined agents, which are saved agents that a run's plan can use.

        - `type: "agent"`

        - `id: string`

        - `description: string or null`

        - `mcp_servers: array of BetaManagedAgentsMCPServerURLDefinition`

        - `model: BetaManagedAgentsModelConfig`

          Model identifier and configuration.

        - `name: string`

        - `skills: array of BetaManagedAgentsAnthropicSkill or BetaManagedAgentsCustomSkill`

        - `system: string or null`

        - `tools: array of BetaManagedAgentsAgentToolset20260401 or BetaManagedAgentsMCPToolset or BetaManagedAgentsCustomTool`

        - `version: number`

          format: int32

    - `BetaManagedAgentsMultiagentWorkflowsDisabled object`

      The agent cannot start workflow runs.

      - `type: "disabled"`

### Beta Managed Agents Session Stats

- `BetaManagedAgentsSessionStats object`

  Timing statistics for a session.

  - `active_seconds: optional number`

    Cumulative time in seconds the session spent in `running` status. Excludes idle time.

    format: double

  - `duration_seconds: optional number`

    Elapsed time since session creation in seconds. For terminated sessions, frozen at the final update.

    format: double

### Beta Managed Agents Session Updated Event

- `BetaManagedAgentsSessionUpdatedEvent object`

  Emitted when an UpdateSession request changed at least one field. Carries only the fields that changed; absent fields were not part of the update. The new configuration applies from the next turn.

  - `type: "session.updated"`

  - `id: string`

    Unique identifier for this event.

  - `processed_at: string`

    Timestamp when the update was applied.

    format: date-time

  - `agent: optional BetaManagedAgentsSessionAgent or null`

    The session's effective agent configuration after the update. Present only when the update changed `agent` (tools or mcp_servers); when present it is the full materialised snapshot, not a diff.

    - `type: "agent"`

    - `id: string`

    - `description: string or null`

    - `mcp_servers: array of BetaManagedAgentsMCPServerURLDefinition`

      - `type: "url"`

      - `name: string`

      - `url: string`

    - `model: BetaManagedAgentsModelConfig`

      Model identifier and configuration.

      - `id: BetaManagedAgentsModel`

        The model that will power your agent.

        See [models](https://docs.anthropic.com/en/docs/models-overview) for additional details and options.

        - `"claude-haiku-5-5"`

          Fastest model for high-volume, real-time tasks

        - `"claude-sonnet-5-5"`

          Efficient model for coding and agents

        - `"claude-opus-5-5"`

          Powerful intelligence for coding, knowledge work, and long-running agents

        - `"claude-fable-5-1"`

          Frontier intelligence for ambitious tasks across coding, scientific discovery, and enterprise workflows

        - `"claude-sonnet-5"`

          Efficient model for coding and agents

        - `"claude-fable-5"`

          Next generation of intelligence for the hardest knowledge work and coding problems

        - `"claude-opus-5"`

          Powerful intelligence for long-running agents and coding

        - `"claude-opus-4-8"`

          Powerful intelligence for long-running agents and coding

        - `"claude-opus-4-7"`

          Powerful intelligence for long-running agents and coding

        - `"claude-opus-4-6"`

          Powerful intelligence for long-running agents and coding

        - `"claude-sonnet-4-6"`

          Best combination of speed and intelligence

        - `"claude-haiku-4-5"`

        - `"claude-haiku-4-5-20251001"`

        - `"claude-opus-4-5"`

          Powerful intelligence for long-running agents and coding

        - `"claude-opus-4-5-20251101"`

          Powerful intelligence for long-running agents and coding

        - `"claude-sonnet-4-5"`

          **Deprecated**: Will reach end-of-life on November 30, 2026. Please migrate to claude-sonnet-5-5. Visit https://docs.anthropic.com/en/docs/resources/model-deprecations for more information.

          High-performance model for agents and coding

        - `"claude-sonnet-4-5-20250929"`

          **Deprecated**: Will reach end-of-life on November 30, 2026. Please migrate to claude-sonnet-5-5. Visit https://docs.anthropic.com/en/docs/resources/model-deprecations for more information.

          High-performance model for agents and coding

        - `string`

      - `effort: optional BetaManagedAgentsEffortLow or BetaManagedAgentsEffortMedium or BetaManagedAgentsEffortHigh or 2 more`

        How hard Claude works on each inference call. One of `low`, `medium`, `high`, `xhigh`, `max`. Always present; resolved to the per-model default at save time when not supplied.

        - `BetaManagedAgentsEffortLow object`

          Low effort. Favors latency over reasoning depth.

          - `type: "low"`

        - `BetaManagedAgentsEffortMedium object`

          Medium effort. Balances latency and reasoning depth.

          - `type: "medium"`

        - `BetaManagedAgentsEffortHigh object`

          High effort. Favors reasoning depth.

          - `type: "high"`

        - `BetaManagedAgentsEffortXhigh object`

          Extra-high effort. Not all models accept this level.

          - `type: "xhigh"`

        - `BetaManagedAgentsEffortMax object`

          Maximum effort. Favors reasoning depth over latency.

          - `type: "max"`

      - `inference_geo: optional string`

        Geographic region for model inference. When unset, requests fall through to the workspace's default_inference_geo.

      - `speed: optional "standard" or "fast"`

        Inference speed mode. `fast` provides significantly faster output token generation at premium pricing. Defaults to `standard`. Not all models support `fast`; invalid combinations are rejected at create time.

        - `"standard"`

        - `"fast"`

    - `multiagent: BetaManagedAgentsSessionMultiagent or null`

      Resolved multiagent orchestration configuration. Null when the agent is single-threaded.

      - `BetaManagedAgentsSessionMultiagentCoordinator object`

        Resolved coordinator topology with full agent definitions for each roster member.

        - `type: "coordinator"`

        - `agents: array of BetaManagedAgentsSessionThreadAgent or BetaManagedAgentsAdvisor`

          Full `agent` definitions the coordinator may spawn as session threads.

          - `BetaManagedAgentsSessionThreadAgent object`

            Resolved `agent` definition for a single `session_thread`. Snapshot of the agent at thread creation time. The multiagent roster is not repeated here; read it from `Session.agent`.

            - `type: "agent"`

            - `id: string`

            - `description: string or null`

            - `mcp_servers: array of BetaManagedAgentsMCPServerURLDefinition`

              - `type: "url"`

              - `name: string`

              - `url: string`

            - `model: BetaManagedAgentsModelConfig`

              Model identifier and configuration.

            - `name: string`

            - `skills: array of BetaManagedAgentsAnthropicSkill or BetaManagedAgentsCustomSkill`

              - `BetaManagedAgentsAnthropicSkill object`

                A resolved Anthropic-managed skill.

                - `type: "anthropic"`

                - `skill_id: string`

                - `version: string`

              - `BetaManagedAgentsCustomSkill object`

                A resolved user-created custom skill.

                - `type: "custom"`

                - `skill_id: string`

                - `version: string`

            - `system: string or null`

            - `tools: array of BetaManagedAgentsAgentToolset20260401 or BetaManagedAgentsMCPToolset or BetaManagedAgentsCustomTool`

              - `BetaManagedAgentsAgentToolset20260401 object`

                - `type: "agent_toolset_20260401"`

                - `configs: array of BetaManagedAgentsAgentToolConfig`

                  - `BetaManagedAgentsBashToolConfig object`

                    Configuration for the bash tool.

                    - `type: "bash"`

                    - `enabled: boolean`

                    - `name: "bash"`

                    - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                      Permission policy for tool execution.

                      - `BetaManagedAgentsAlwaysAllowPolicy object`

                        Tool calls are automatically approved without user confirmation.

                        - `type: "always_allow"`

                      - `BetaManagedAgentsAlwaysAskPolicy object`

                        Tool calls require user confirmation before execution.

                        - `type: "always_ask"`

                      - `BetaManagedAgentsAutoPolicy object`

                        The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

                        - `type: "auto"`

                  - `BetaManagedAgentsEditToolConfig object`

                    Configuration for the edit tool.

                    - `type: "edit"`

                    - `enabled: boolean`

                    - `name: "edit"`

                    - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                      Permission policy for tool execution.

                      - `BetaManagedAgentsAlwaysAllowPolicy object`

                        Tool calls are automatically approved without user confirmation.

                      - `BetaManagedAgentsAlwaysAskPolicy object`

                        Tool calls require user confirmation before execution.

                      - `BetaManagedAgentsAutoPolicy object`

                        The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

                  - `BetaManagedAgentsReadToolConfig object`

                    Configuration for the read tool.

                    - `type: "read"`

                    - `enabled: boolean`

                    - `name: "read"`

                    - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                      Permission policy for tool execution.

                      - `BetaManagedAgentsAlwaysAllowPolicy object`

                        Tool calls are automatically approved without user confirmation.

                      - `BetaManagedAgentsAlwaysAskPolicy object`

                        Tool calls require user confirmation before execution.

                      - `BetaManagedAgentsAutoPolicy object`

                        The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

                  - `BetaManagedAgentsWriteToolConfig object`

                    Configuration for the write tool.

                    - `type: "write"`

                    - `enabled: boolean`

                    - `name: "write"`

                    - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                      Permission policy for tool execution.

                      - `BetaManagedAgentsAlwaysAllowPolicy object`

                        Tool calls are automatically approved without user confirmation.

                      - `BetaManagedAgentsAlwaysAskPolicy object`

                        Tool calls require user confirmation before execution.

                      - `BetaManagedAgentsAutoPolicy object`

                        The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

                  - `BetaManagedAgentsGlobToolConfig object`

                    Configuration for the glob tool.

                    - `type: "glob"`

                    - `enabled: boolean`

                    - `name: "glob"`

                    - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                      Permission policy for tool execution.

                      - `BetaManagedAgentsAlwaysAllowPolicy object`

                        Tool calls are automatically approved without user confirmation.

                      - `BetaManagedAgentsAlwaysAskPolicy object`

                        Tool calls require user confirmation before execution.

                      - `BetaManagedAgentsAutoPolicy object`

                        The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

                  - `BetaManagedAgentsGrepToolConfig object`

                    Configuration for the grep tool.

                    - `type: "grep"`

                    - `enabled: boolean`

                    - `name: "grep"`

                    - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                      Permission policy for tool execution.

                      - `BetaManagedAgentsAlwaysAllowPolicy object`

                        Tool calls are automatically approved without user confirmation.

                      - `BetaManagedAgentsAlwaysAskPolicy object`

                        Tool calls require user confirmation before execution.

                      - `BetaManagedAgentsAutoPolicy object`

                        The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

                  - `BetaManagedAgentsWebFetchToolConfig object`

                    Configuration for the web_fetch tool.

                    - `type: "web_fetch"`

                    - `enabled: boolean`

                    - `name: "web_fetch"`

                    - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                      Permission policy for tool execution.

                      - `BetaManagedAgentsAlwaysAllowPolicy object`

                        Tool calls are automatically approved without user confirmation.

                      - `BetaManagedAgentsAlwaysAskPolicy object`

                        Tool calls require user confirmation before execution.

                      - `BetaManagedAgentsAutoPolicy object`

                        The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

                    - `url_sources: BetaManagedAgentsWebFetchURLSources or null`

                      Which sources contribute URLs the tool may fetch, always in the object form. Null when not set, which allows every source.

                      - `client_tool_results: BetaManagedAgentsWebFetchURLSourceToolFilter or null`

                        Which custom tools' results contribute URLs that may be fetched. Null when not set, which allows every custom tool's results.

                        - `BetaManagedAgentsWebFetchURLSourceAll object`

                          Every URL from this source may be fetched. This is the default.

                          - `type: "all"`

                        - `BetaManagedAgentsWebFetchURLSourceNone object`

                          This source contributes no URLs that may be fetched.

                          - `type: "none"`

                        - `BetaManagedAgentsWebFetchURLSourceOnly object`

                          Only the named tools' results contribute URLs that may be fetched.

                          - `type: "only"`

                          - `tools: array of BetaManagedAgentsWebFetchURLSourceToolReference`

                            The tools whose results contribute. Between 1 and 128 entries, each with a different name. An empty list is rejected; use "none" to allow no tool's results.

                            - `type: "tool_reference"`

                              Must be "tool_reference".

                            - `name: string`

                              Name of the tool. Compared exactly, so upper and lower case letters are different.

                              minLength: 1, maxLength: 128

                        - `BetaManagedAgentsWebFetchURLSourceExcept object`

                          Every tool's results contribute URLs that may be fetched, except the named tools' results.

                          - `type: "except"`

                          - `tools: array of BetaManagedAgentsWebFetchURLSourceToolReference`

                            The tools whose results do not contribute. Between 1 and 128 entries, each with a different name. An empty list is rejected; use "all" to leave out no tool's results.

                            - `type: "tool_reference"`

                              Must be "tool_reference".

                            - `name: string`

                              Name of the tool. Compared exactly, so upper and lower case letters are different.

                              minLength: 1, maxLength: 128

                      - `server_tool_results: BetaManagedAgentsWebFetchURLSourceToolFilter or null`

                        Which of the web_search and web_fetch tools' results contribute URLs that may be fetched. Null when not set, which allows both.

                      - `user_input: BetaManagedAgentsWebFetchURLSourceUserInput or null`

                        Whether URLs in the text of user messages may be fetched. Null when not set, which allows them.

                        - `BetaManagedAgentsWebFetchURLSourceAll object`

                          Every URL from this source may be fetched. This is the default.

                        - `BetaManagedAgentsWebFetchURLSourceNone object`

                          This source contributes no URLs that may be fetched.

                    - `allowed_domains: optional array of string`

                    - `blocked_domains: optional array of string`

                    - `max_content_tokens: optional number or null`

                      format: int32

                  - `BetaManagedAgentsWebSearchToolConfig object`

                    Configuration for the web_search tool.

                    - `type: "web_search"`

                    - `enabled: boolean`

                    - `name: "web_search"`

                    - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                      Permission policy for tool execution.

                      - `BetaManagedAgentsAlwaysAllowPolicy object`

                        Tool calls are automatically approved without user confirmation.

                      - `BetaManagedAgentsAlwaysAskPolicy object`

                        Tool calls require user confirmation before execution.

                      - `BetaManagedAgentsAutoPolicy object`

                        The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

                    - `allowed_domains: optional array of string`

                    - `blocked_domains: optional array of string`

                    - `user_location: optional BetaManagedAgentsUserLocation or null`

                      Approximate user location for search result localization.

                      - `type: "approximate"`

                        Location precision. Only "approximate" is supported.

                      - `city: optional string or null`

                        City name.

                        minLength: 1, maxLength: 255

                      - `country: optional string or null`

                        Two-letter ISO 3166-1 country code, uppercase.

                      - `region: optional string or null`

                        Region or state name.

                        minLength: 1, maxLength: 255

                      - `timezone: optional string or null`

                        IANA timezone identifier, e.g. "America/Los_Angeles".

                        minLength: 1, maxLength: 255

                - `default_config: BetaManagedAgentsAgentToolsetDefaultConfig`

                  Resolved default configuration for agent tools.

                  - `enabled: boolean`

                  - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                    Permission policy for tool execution.

                    - `BetaManagedAgentsAlwaysAllowPolicy object`

                      Tool calls are automatically approved without user confirmation.

                    - `BetaManagedAgentsAlwaysAskPolicy object`

                      Tool calls require user confirmation before execution.

                    - `BetaManagedAgentsAutoPolicy object`

                      The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

              - `BetaManagedAgentsMCPToolset object`

                - `type: "mcp_toolset"`

                - `configs: array of BetaManagedAgentsMCPToolConfig`

                  - `enabled: boolean`

                  - `name: string`

                  - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                    Permission policy for tool execution.

                    - `BetaManagedAgentsAlwaysAllowPolicy object`

                      Tool calls are automatically approved without user confirmation.

                    - `BetaManagedAgentsAlwaysAskPolicy object`

                      Tool calls require user confirmation before execution.

                    - `BetaManagedAgentsAutoPolicy object`

                      The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

                - `default_config: BetaManagedAgentsMCPToolsetDefaultConfig`

                  Resolved default configuration for all tools from an MCP server.

                  - `enabled: boolean`

                  - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

                    Permission policy for tool execution.

                    - `BetaManagedAgentsAlwaysAllowPolicy object`

                      Tool calls are automatically approved without user confirmation.

                    - `BetaManagedAgentsAlwaysAskPolicy object`

                      Tool calls require user confirmation before execution.

                    - `BetaManagedAgentsAutoPolicy object`

                      The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

                - `mcp_server_name: string`

              - `BetaManagedAgentsCustomTool object`

                A custom tool as returned in API responses.

                - `type: "custom"`

                - `description: string`

                - `input_schema: BetaManagedAgentsCustomToolInputSchema`

                  JSON Schema for custom tool input parameters.

                  - `type: "object"`

                  - `properties: optional map[unknown] or null`

                  - `required: optional array of string or null`

                - `name: string`

            - `version: number`

              format: int32

          - `BetaManagedAgentsAdvisor object`

            Platform advisor roster entry: a model the session's primary thread may consult mid-turn.

            - `type: "advisor"`

            - `model: string`

              The advisor model id.

      - `BetaManagedAgentsSessionMultiagent20261001 object`

        Resolved multiagent configuration with three members, as copied to the `session` at creation.

        - `type: "multiagent_20261001"`

        - `advisor: BetaManagedAgentsMultiagentAdvisor`

          Whether the session's primary thread can consult an advisor model.

          - `BetaManagedAgentsMultiagentAdvisorEnabled object`

            The session's primary thread can consult `model` mid-turn.

            - `type: "enabled"`

            - `model: string`

              The advisor model id.

          - `BetaManagedAgentsMultiagentAdvisorDisabled object`

            The agent has no advisor.

            - `type: "disabled"`

        - `subagents: BetaManagedAgentsSessionMultiagentSubagents`

          Whether the agent can spawn session threads.

          - `BetaManagedAgentsSessionMultiagentSubagentsEnabled object`

            The agent can spawn session threads.

            - `type: "enabled"`

            - `inline_agents: BetaManagedAgentsMultiagentInlineAgents`

              Whether the agent can define inline agents, which are not saved, when it spawns session threads.

              - `BetaManagedAgentsMultiagentInlineAgentsEnabled object`

                The agent can define inline agents.

                - `type: "enabled"`

              - `BetaManagedAgentsMultiagentInlineAgentsDisabled object`

                The agent cannot define inline agents.

                - `type: "disabled"`

            - `predefined_agents: array of BetaManagedAgentsSessionThreadAgent`

              Full `agent` definitions of the predefined agents, which are saved agents that this agent can spawn as session threads.

              - `type: "agent"`

              - `id: string`

              - `description: string or null`

              - `mcp_servers: array of BetaManagedAgentsMCPServerURLDefinition`

              - `model: BetaManagedAgentsModelConfig`

                Model identifier and configuration.

              - `name: string`

              - `skills: array of BetaManagedAgentsAnthropicSkill or BetaManagedAgentsCustomSkill`

              - `system: string or null`

              - `tools: array of BetaManagedAgentsAgentToolset20260401 or BetaManagedAgentsMCPToolset or BetaManagedAgentsCustomTool`

              - `version: number`

                format: int32

          - `BetaManagedAgentsMultiagentSubagentsDisabled object`

            The agent cannot spawn session threads.

            - `type: "disabled"`

        - `workflows: BetaManagedAgentsSessionMultiagentWorkflows`

          Whether the agent can start workflow runs.

          - `BetaManagedAgentsSessionMultiagentWorkflowsEnabled object`

            The agent can start workflow runs.

            - `type: "enabled"`

            - `inline_agents: BetaManagedAgentsMultiagentInlineAgents`

              Whether a run's plan can define inline agents, which are not saved.

            - `predefined_agents: array of BetaManagedAgentsSessionThreadAgent`

              Full `agent` definitions of the predefined agents, which are saved agents that a run's plan can use.

              - `type: "agent"`

              - `id: string`

              - `description: string or null`

              - `mcp_servers: array of BetaManagedAgentsMCPServerURLDefinition`

              - `model: BetaManagedAgentsModelConfig`

                Model identifier and configuration.

              - `name: string`

              - `skills: array of BetaManagedAgentsAnthropicSkill or BetaManagedAgentsCustomSkill`

              - `system: string or null`

              - `tools: array of BetaManagedAgentsAgentToolset20260401 or BetaManagedAgentsMCPToolset or BetaManagedAgentsCustomTool`

              - `version: number`

                format: int32

          - `BetaManagedAgentsMultiagentWorkflowsDisabled object`

            The agent cannot start workflow runs.

            - `type: "disabled"`

    - `name: string`

    - `skills: array of BetaManagedAgentsAnthropicSkill or BetaManagedAgentsCustomSkill`

      - `BetaManagedAgentsAnthropicSkill object`

        A resolved Anthropic-managed skill.

      - `BetaManagedAgentsCustomSkill object`

        A resolved user-created custom skill.

    - `system: string or null`

    - `tools: array of BetaManagedAgentsAgentToolset20260401 or BetaManagedAgentsMCPToolset or BetaManagedAgentsCustomTool`

      - `BetaManagedAgentsAgentToolset20260401 object`

      - `BetaManagedAgentsMCPToolset object`

      - `BetaManagedAgentsCustomTool object`

        A custom tool as returned in API responses.

    - `version: number`

      format: int32

  - `budget: optional BetaManagedAgentsBudgetLimit or null`

    The session's budget after the update: the new budget when set or replaced, or null when the update removed it. Present only when the update changed the budget.

    - `type: "limit"`

    - `max_list_cost: BetaMonetaryAmount`

      Maximum list cost the session may accrue. List price is used regardless of any negotiated discount, so the cap fires at or before the actual charge.

      - `amount: string`

        Amount in minor units of the currency, as an integer decimal string with no leading zeros: "2500" is $25.00 and "50" is fifty cents. A string rather than a number so no float rounding is ever applied.

      - `currency: BetaCurrency`

        Uppercase ISO-4217 currency code. `USD` is the only currency currently supported; the accepted set is closed and grows only when a new currency is priced.

  - `metadata: optional map[string]`

    The session's full metadata bag after the update. Present when the update set non-empty metadata; absent when metadata was unchanged or cleared to empty.

  - `title: optional string or null`

    The session's new title. Present only when the update changed it.

### Beta Managed Agents Session Usage

- `BetaManagedAgentsSessionUsage object`

  Cumulative token usage for a session across all turns.

  - `active_seconds: optional number`

    Cumulative time in seconds during which the session had at least one thread in running status. Overlapping activity from concurrent threads is counted once, unlike `stats.active_seconds`, which sums each thread's own active time. This is the duration the session's runtime cost is priced on.

    format: double

  - `cache_creation: optional BetaManagedAgentsCacheCreationUsage`

    Tokens used to create prompt cache entries, broken down by cache TTL.

    - `ephemeral_1h_input_tokens: optional number`

      Tokens used to create 1-hour ephemeral cache entries.

      format: int32

    - `ephemeral_5m_input_tokens: optional number`

      Tokens used to create 5-minute ephemeral cache entries.

      format: int32

  - `cache_read_input_tokens: optional number`

    Total tokens read from prompt cache.

    format: int32

  - `input_tokens: optional number`

    Total input tokens consumed across all turns.

    format: int32

  - `list_cost: optional BetaMonetaryAmount or null`

    Cumulative list cost of the session across all turns, priced at public list rates. Absent until cost tracking is available for the session.

    - `amount: string`

      Amount in minor units of the currency, as an integer decimal string with no leading zeros: "2500" is $25.00 and "50" is fifty cents. A string rather than a number so no float rounding is ever applied.

    - `currency: BetaCurrency`

      Uppercase ISO-4217 currency code. `USD` is the only currency currently supported; the accepted set is closed and grows only when a new currency is priced.

  - `output_tokens: optional number`

    Total output tokens generated across all turns.

    format: int32

  - `server_tool_use: optional BetaManagedAgentsServerToolUsage or null`

    Cumulative server-executed tool usage across all turns. Absent until server-tool tracking is available for the session.

    - `web_fetch_requests: optional number`

      Number of server-executed web fetch requests.

      format: int32

    - `web_search_requests: optional number`

      Number of server-executed web search requests.

      format: int32

### Beta Managed Agents Session Usage Event

- `BetaManagedAgentsSessionUsageEvent object`

  Periodic snapshot of the session's cumulative usage and tracked list cost.

  - `type: "session.usage"`

  - `id: string`

    Unique identifier for this event.

  - `processed_at: string`

    Timestamp when the snapshot was taken.

    format: date-time

  - `usage: BetaManagedAgentsSessionUsageSnapshot`

    The session's cumulative usage at the snapshot time.

    - `active_seconds: optional number`

      Cumulative time in seconds during which the session had at least one thread in running status. Overlapping activity from concurrent threads is counted once. This is the duration the session's runtime cost is priced on.

      format: double

    - `cache_creation: optional BetaManagedAgentsCacheCreationUsage`

      Tokens used to create prompt cache entries, broken down by cache TTL.

      - `ephemeral_1h_input_tokens: optional number`

        Tokens used to create 1-hour ephemeral cache entries.

        format: int32

      - `ephemeral_5m_input_tokens: optional number`

        Tokens used to create 5-minute ephemeral cache entries.

        format: int32

    - `cache_read_input_tokens: optional number`

      Total tokens read from prompt cache.

      format: int32

    - `input_tokens: optional number`

      Total input tokens consumed across all turns.

      format: int32

    - `list_cost: optional BetaMonetaryAmount`

      Cumulative list cost of the session across all turns, priced at public list rates.

      - `amount: string`

        Amount in minor units of the currency, as an integer decimal string with no leading zeros: "2500" is $25.00 and "50" is fifty cents. A string rather than a number so no float rounding is ever applied.

      - `currency: BetaCurrency`

        Uppercase ISO-4217 currency code. `USD` is the only currency currently supported; the accepted set is closed and grows only when a new currency is priced.

    - `output_tokens: optional number`

      Total output tokens generated across all turns.

      format: int32

    - `server_tool_use: optional BetaManagedAgentsServerToolUsage`

      Cumulative server-executed tool usage across all turns.

      - `web_fetch_requests: optional number`

        Number of server-executed web fetch requests.

        format: int32

      - `web_search_requests: optional number`

        Number of server-executed web search requests.

        format: int32

  - `budget: optional BetaManagedAgentsBudgetLimit or null`

    The session's configured budget at the snapshot time, or null when the session has no budget.

    - `type: "limit"`

    - `max_list_cost: BetaMonetaryAmount`

      Maximum list cost the session may accrue. List price is used regardless of any negotiated discount, so the cap fires at or before the actual charge.

### Beta Managed Agents Start Event

- `BetaManagedAgentsStartEvent object`

  Opens a preview of a buffered event. Carries the previewed event's type and id only. Followed by zero or more event_delta events with the same event id, normally concluded by the buffered event carrying that id. If the producing model request ends without that event (an error or interrupt mid-stream), its terminal span.model_request_end closes the preview. Only sent on stream connections that opt in via event_deltas; never appears in event history.

  - `type: "event_start"`

  - `event: BetaManagedAgentsStartEventPreview`

    The previewed event's type and id. The event type determines which delta types the preview's event_delta events carry: agent.message events stream content_delta fragments; agent.thinking previews are start-only — no deltas follow, and the buffered agent.thinking with the same id concludes them.

    - `BetaManagedAgentsAgentMessagePreview object`

      - `type: "agent.message"`

      - `id: string`

        The id the buffered agent.message will carry if it is emitted. Matches the event_id on this preview's event_delta events.

    - `BetaManagedAgentsAgentThinkingPreview object`

      - `type: "agent.thinking"`

      - `id: string`

        The id the buffered agent.thinking will carry if it is emitted. Start-only — no event_delta events follow.

### Beta Managed Agents Start Event Preview

- `BetaManagedAgentsStartEventPreview = BetaManagedAgentsAgentMessagePreview or BetaManagedAgentsAgentThinkingPreview`

  - `BetaManagedAgentsAgentMessagePreview object`

    - `type: "agent.message"`

    - `id: string`

      The id the buffered agent.message will carry if it is emitted. Matches the event_id on this preview's event_delta events.

  - `BetaManagedAgentsAgentThinkingPreview object`

    - `type: "agent.thinking"`

    - `id: string`

      The id the buffered agent.thinking will carry if it is emitted. Start-only — no event_delta events follow.

### Beta Managed Agents System Content Block

- `BetaManagedAgentsSystemContentBlock object`

  Content block in a mid-conversation system message. Text-only.

  - `type: "text"`

  - `text: string`

    The text content.

    minLength: 1

### Beta Managed Agents System Message Event

- `BetaManagedAgentsSystemMessageEvent object`

  A mid-conversation system message event. Carries system-role content that is appended to the session as a `role: "system"` turn.

  - `type: "system.message"`

  - `id: string`

    Unique identifier for this event.

  - `content: array of BetaManagedAgentsSystemContentBlock`

    System content blocks. Text-only.

    - `type: "text"`

    - `text: string`

      The text content.

      minLength: 1

  - `processed_at: optional string or null`

    Timestamp when this system message was processed.

    format: date-time

### Beta Managed Agents User Tool Result Event

- `BetaManagedAgentsUserToolResultEvent object`

  Event sent by the client providing the result of an agent-toolset tool execution. Only valid on `self_hosted` environments, where sandbox-routed tools are executed by the client rather than the server.

  - `type: "user.tool_result"`

  - `id: string`

    Unique identifier for this event.

  - `tool_use_id: string`

    The id of the `agent.tool_use` event this result corresponds to, which can be found in the last `session.status_idle` [event's](https://platform.claude.com/docs/en/api/beta/sessions/events/list?sdk_languages=http#beta_managed_agents_session_requires_action.event_ids) `stop_reason.event_ids` field.

  - `content: optional array of BetaManagedAgentsTextBlock or BetaManagedAgentsImageBlock or BetaManagedAgentsDocumentBlock or BetaManagedAgentsSearchResultBlock`

    The result content returned by the tool.

    - `BetaManagedAgentsTextBlock object`

      Regular text content.

      - `type: "text"`

      - `text: string`

        The text content.

        minLength: 1

    - `BetaManagedAgentsImageBlock object`

      Image content specified directly as base64 data or as a reference via a URL.

      - `type: "image"`

      - `source: BetaManagedAgentsBase64ImageSource or BetaManagedAgentsURLImageSource or BetaManagedAgentsFileImageSource`

        The source of the image data.

        - `BetaManagedAgentsBase64ImageSource object`

          Base64-encoded image data.

          - `type: "base64"`

          - `data: string`

            Base64-encoded image data.

            minLength: 1

          - `media_type: string`

            MIME type of the image (e.g., "image/png", "image/jpeg", "image/gif", "image/webp").

            minLength: 1

        - `BetaManagedAgentsURLImageSource object`

          Image referenced by URL.

          - `type: "url"`

          - `url: string`

            URL of the image to fetch.

            minLength: 1

        - `BetaManagedAgentsFileImageSource object`

          Image referenced by file ID.

          - `type: "file"`

          - `file_id: string`

            ID of a previously uploaded file.

            minLength: 1

    - `BetaManagedAgentsDocumentBlock object`

      Document content, either specified directly as base64 data, as text, or as a reference via a URL.

      - `type: "document"`

      - `source: BetaManagedAgentsBase64DocumentSource or BetaManagedAgentsPlainTextDocumentSource or BetaManagedAgentsURLDocumentSource or BetaManagedAgentsFileDocumentSource`

        The source of the document data.

        - `BetaManagedAgentsBase64DocumentSource object`

          Base64-encoded document data.

          - `type: "base64"`

          - `data: string`

            Base64-encoded document data.

            minLength: 1

          - `media_type: string`

            MIME type of the document (e.g., "application/pdf").

            minLength: 1

        - `BetaManagedAgentsPlainTextDocumentSource object`

          Plain text document content.

          - `type: "text"`

          - `data: string`

            The plain text content.

            minLength: 1

          - `media_type: "text/plain"`

            MIME type of the text content. Must be "text/plain".

        - `BetaManagedAgentsURLDocumentSource object`

          Document referenced by URL.

          - `type: "url"`

          - `url: string`

            URL of the document to fetch.

            minLength: 1

        - `BetaManagedAgentsFileDocumentSource object`

          Document referenced by file ID.

          - `type: "file"`

          - `file_id: string`

            ID of a previously uploaded file.

            minLength: 1

      - `context: optional string or null`

        Additional context about the document for the model.

      - `title: optional string or null`

        The title of the document.

    - `BetaManagedAgentsSearchResultBlock object`

      A block containing a web search result.

      - `type: "search_result"`

      - `citations: BetaManagedAgentsSearchResultCitations`

        Citation settings for this search result.

        - `enabled: boolean`

          Whether citations are enabled for this search result.

      - `content: array of BetaManagedAgentsSearchResultContent`

        Array of text content blocks from the search result.

        - `type: "text"`

        - `text: string`

          The text content.

          minLength: 1

      - `source: string`

        The URL source of the search result.

        minLength: 1

      - `title: string`

        The title of the search result.

        minLength: 1

  - `is_error: optional boolean or null`

    Whether the tool execution resulted in an error.

  - `processed_at: optional string or null`

    Timestamp when this result was processed.

    format: date-time

  - `session_thread_id: optional string or null`

    Set by the server to the subagent thread this result was routed to. Omitted when it was routed to the primary thread.

