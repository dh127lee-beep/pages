# Deployment Runs — Domain types

원문: https://platform.claude.com/docs/en/api/beta/deployment_runs



### Beta Managed Agents Agent Archived Run Error

- `BetaManagedAgentsAgentArchivedRunError object`

  The deployment's agent was archived.

  - `type: "agent_archived_error"`

  - `message: string`

    Human-readable error description.

### Beta Managed Agents Deployment Run

- `BetaManagedAgentsDeploymentRun object`

  A persistent, append-only record of a single deployment execution. Records session creation success or failure — no session lifecycle tracking.

  - `type: "deployment_run"`

  - `id: string`

    Unique identifier for this run (`drun_...`).

  - `agent: BetaManagedAgentsAgentReference`

    Snapshot of the agent at fire time. Always fully resolved — deployments pin agent + version.

    - `type: "agent"`

    - `id: string`

    - `version: number`

      format: int32

  - `created_at: string`

    Time this run record was persisted.

    format: date-time

  - `deployment_id: string`

    ID of the deployment that produced this run.

  - `error: BetaManagedAgentsEnvironmentArchivedRunError or BetaManagedAgentsAgentArchivedRunError or BetaManagedAgentsEnvironmentNotFoundRunError or 13 more or null`

    Populated on creation failure. Null on success. Exactly one of `session_id` or `error` is non-null.

    - `BetaManagedAgentsEnvironmentArchivedRunError object`

      The deployment's environment was archived.

      - `type: "environment_archived_error"`

      - `message: string`

        Human-readable error description.

    - `BetaManagedAgentsAgentArchivedRunError object`

      The deployment's agent was archived.

      - `type: "agent_archived_error"`

      - `message: string`

        Human-readable error description.

    - `BetaManagedAgentsEnvironmentNotFoundRunError object`

      The deployment's environment no longer exists.

      - `type: "environment_not_found_error"`

      - `message: string`

        Human-readable error description.

    - `BetaManagedAgentsVaultNotFoundRunError object`

      A vault referenced by the deployment no longer exists.

      - `type: "vault_not_found_error"`

      - `message: string`

        Human-readable error description.

    - `BetaManagedAgentsVaultArchivedRunError object`

      A vault referenced by the deployment is archived.

      - `type: "vault_archived_error"`

      - `message: string`

        Human-readable error description.

    - `BetaManagedAgentsFileNotFoundRunError object`

      A file resource referenced by the deployment no longer exists.

      - `type: "file_not_found_error"`

      - `message: string`

        Human-readable error description.

    - `BetaManagedAgentsMemoryStoreArchivedRunError object`

      A memory store referenced by the deployment is archived.

      - `type: "memory_store_archived_error"`

      - `message: string`

        Human-readable error description.

    - `BetaManagedAgentsSkillNotFoundRunError object`

      A skill referenced by the deployment's agent no longer exists.

      - `type: "skill_not_found_error"`

      - `message: string`

        Human-readable error description.

    - `BetaManagedAgentsSessionResourceNotFoundRunError object`

      A referenced resource no longer exists and its kind was not reported.

      - `type: "session_resource_not_found_error"`

      - `message: string`

        Human-readable error description.

    - `BetaManagedAgentsWorkspaceArchivedRunError object`

      The deployment's workspace was archived.

      - `type: "workspace_archived_error"`

      - `message: string`

        Human-readable error description.

    - `BetaManagedAgentsOrganizationDisabledRunError object`

      The deployment's organization is disabled.

      - `type: "organization_disabled_error"`

      - `message: string`

        Human-readable error description.

    - `BetaManagedAgentsSessionRateLimitedRunError object`

      Session creation was rejected due to rate limiting. The schedule keeps firing; subsequent runs may succeed.

      - `type: "session_rate_limited_error"`

      - `message: string`

        Human-readable error description.

    - `BetaManagedAgentsSessionCreationRejectedRunError object`

      The session create request was rejected with a non-retryable validation error.

      - `type: "session_creation_rejected_error"`

      - `message: string`

        Human-readable error description.

    - `BetaManagedAgentsUnknownRunError object`

      An unknown or unexpected error caused the run to fail. A fallback variant; clients that do not recognize a new error type can match on message alone.

      - `type: "unknown_error"`

      - `message: string`

        Human-readable error description.

    - `BetaManagedAgentsSelfHostedResourcesUnsupportedRunError object`

      The deployment configures resources, but its environment is self-hosted and cannot mount them.

      - `type: "self_hosted_resources_unsupported_error"`

      - `message: string`

        Human-readable error description.

    - `BetaManagedAgentsMCPEgressBlockedRunError object`

      An MCP server host used by the deployment's agent is blocked by the environment's network policy.

      - `type: "mcp_egress_blocked_error"`

      - `message: string`

        Human-readable error description.

  - `session_id: string or null`

    Populated on success. Null on creation failure. Exactly one of `session_id` or `error` is non-null.

  - `trigger_context: BetaManagedAgentsTriggerContext`

    What triggered this run and trigger-specific metadata.

    - `BetaManagedAgentsScheduleTriggerContext object`

      The run was fired by the deployment's cron schedule.

      - `type: "schedule"`

      - `scheduled_at: string`

        The UTC instant at which the cron expression matched in the configured timezone, before jitter is applied. At most one run is recorded per (`deployment_id`, `scheduled_at`) pair.

        format: date-time

    - `BetaManagedAgentsManualTriggerContext object`

      The run was started manually by creating a session directly against the deployment.

      - `type: "manual"`

### Beta Managed Agents Environment Archived Run Error

- `BetaManagedAgentsEnvironmentArchivedRunError object`

  The deployment's environment was archived.

  - `type: "environment_archived_error"`

  - `message: string`

    Human-readable error description.

### Beta Managed Agents Environment Not Found Run Error

- `BetaManagedAgentsEnvironmentNotFoundRunError object`

  The deployment's environment no longer exists.

  - `type: "environment_not_found_error"`

  - `message: string`

    Human-readable error description.

### Beta Managed Agents File Not Found Run Error

- `BetaManagedAgentsFileNotFoundRunError object`

  A file resource referenced by the deployment no longer exists.

  - `type: "file_not_found_error"`

  - `message: string`

    Human-readable error description.

### Beta Managed Agents Manual Trigger Context

- `BetaManagedAgentsManualTriggerContext object`

  The run was started manually by creating a session directly against the deployment.

  - `type: "manual"`

### Beta Managed Agents MCP Egress Blocked Run Error

- `BetaManagedAgentsMCPEgressBlockedRunError object`

  An MCP server host used by the deployment's agent is blocked by the environment's network policy.

  - `type: "mcp_egress_blocked_error"`

  - `message: string`

    Human-readable error description.

### Beta Managed Agents Memory Store Archived Run Error

- `BetaManagedAgentsMemoryStoreArchivedRunError object`

  A memory store referenced by the deployment is archived.

  - `type: "memory_store_archived_error"`

  - `message: string`

    Human-readable error description.

### Beta Managed Agents Organization Disabled Run Error

- `BetaManagedAgentsOrganizationDisabledRunError object`

  The deployment's organization is disabled.

  - `type: "organization_disabled_error"`

  - `message: string`

    Human-readable error description.

### Beta Managed Agents Schedule Trigger Context

- `BetaManagedAgentsScheduleTriggerContext object`

  The run was fired by the deployment's cron schedule.

  - `type: "schedule"`

  - `scheduled_at: string`

    The UTC instant at which the cron expression matched in the configured timezone, before jitter is applied. At most one run is recorded per (`deployment_id`, `scheduled_at`) pair.

    format: date-time

### Beta Managed Agents Self Hosted Resources Unsupported Run Error

- `BetaManagedAgentsSelfHostedResourcesUnsupportedRunError object`

  The deployment configures resources, but its environment is self-hosted and cannot mount them.

  - `type: "self_hosted_resources_unsupported_error"`

  - `message: string`

    Human-readable error description.

### Beta Managed Agents Session Creation Rejected Run Error

- `BetaManagedAgentsSessionCreationRejectedRunError object`

  The session create request was rejected with a non-retryable validation error.

  - `type: "session_creation_rejected_error"`

  - `message: string`

    Human-readable error description.

### Beta Managed Agents Session Rate Limited Run Error

- `BetaManagedAgentsSessionRateLimitedRunError object`

  Session creation was rejected due to rate limiting. The schedule keeps firing; subsequent runs may succeed.

  - `type: "session_rate_limited_error"`

  - `message: string`

    Human-readable error description.

### Beta Managed Agents Session Resource Not Found Run Error

- `BetaManagedAgentsSessionResourceNotFoundRunError object`

  A referenced resource no longer exists and its kind was not reported.

  - `type: "session_resource_not_found_error"`

  - `message: string`

    Human-readable error description.

### Beta Managed Agents Skill Not Found Run Error

- `BetaManagedAgentsSkillNotFoundRunError object`

  A skill referenced by the deployment's agent no longer exists.

  - `type: "skill_not_found_error"`

  - `message: string`

    Human-readable error description.

### Beta Managed Agents Trigger Context

- `BetaManagedAgentsTriggerContext = BetaManagedAgentsScheduleTriggerContext or BetaManagedAgentsManualTriggerContext`

  Describes what triggered a deployment run, with trigger-specific metadata.

  - `BetaManagedAgentsScheduleTriggerContext object`

    The run was fired by the deployment's cron schedule.

    - `type: "schedule"`

    - `scheduled_at: string`

      The UTC instant at which the cron expression matched in the configured timezone, before jitter is applied. At most one run is recorded per (`deployment_id`, `scheduled_at`) pair.

      format: date-time

  - `BetaManagedAgentsManualTriggerContext object`

    The run was started manually by creating a session directly against the deployment.

    - `type: "manual"`

### Beta Managed Agents Trigger Type

- `BetaManagedAgentsTriggerType = "schedule" or "manual"`

  What triggered a deployment run.

  - `"schedule"`

    The run was fired by the deployment's cron schedule.

  - `"manual"`

    The run was started manually by creating a session directly against the deployment.

### Beta Managed Agents Unknown Run Error

- `BetaManagedAgentsUnknownRunError object`

  An unknown or unexpected error caused the run to fail. A fallback variant; clients that do not recognize a new error type can match on message alone.

  - `type: "unknown_error"`

  - `message: string`

    Human-readable error description.

### Beta Managed Agents Vault Archived Run Error

- `BetaManagedAgentsVaultArchivedRunError object`

  A vault referenced by the deployment is archived.

  - `type: "vault_archived_error"`

  - `message: string`

    Human-readable error description.

### Beta Managed Agents Vault Not Found Run Error

- `BetaManagedAgentsVaultNotFoundRunError object`

  A vault referenced by the deployment no longer exists.

  - `type: "vault_not_found_error"`

  - `message: string`

    Human-readable error description.

### Beta Managed Agents Workspace Archived Run Error

- `BetaManagedAgentsWorkspaceArchivedRunError object`

  The deployment's workspace was archived.

  - `type: "workspace_archived_error"`

  - `message: string`

    Human-readable error description.
