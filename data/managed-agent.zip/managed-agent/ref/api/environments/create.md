---
title: Create Environment
url: https://platform.claude.com/docs/en/api/beta/environments/create
---

# Create Environment

**POST** `/v1/environments`

Create a new environment with the specified configuration.

## Headers

- `"anthropic-version": optional string`

  The version of the Claude API you want to use.

  Read more about versioning and our version history [here](https://platform.claude.com/docs/en/api/versioning?sdk_languages=http).

- `"anthropic-beta": optional array of AnthropicBeta`

  Optional header to specify the beta version(s) you want to use. (전체 enum 목록 생략 — Managed Agents는 `managed-agents-2026-04-01`, Dreams는 `dreaming-2026-04-21`, Tunnels는 `mcp-tunnels-2026-06-22`)

- `"anthropic-workspace-id": optional string`

  Optional header to select the Workspace for this request. The value is a Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).

  Only needed for credentials that can act on more than one Workspace. A credential that belongs to a specific Workspace may omit it; if sent, it must match that Workspace.

## Body parameters

- `name: string`

  Human-readable name for the environment

  minLength: 1, maxLength: 256

- `config: optional BetaCloudConfigParams or BetaSelfHostedConfigParams or null`

  Environment configuration

  - `BetaCloudConfigParams object`

    Request params for `cloud` environment configuration.

    Fields default to null; on update, omitted fields preserve the
    existing value.

    - `type: "cloud"`

      Environment type

    - `networking: optional BetaUnrestrictedNetwork or BetaLimitedNetworkParams or null`

      Network configuration policy. Omit on update to preserve the existing value.

      - `BetaUnrestrictedNetwork object`

        Unrestricted network access.

        - `type: "unrestricted"`

          Network policy type

      - `BetaLimitedNetworkParams object`

        Limited network request params.

        Fields default to null; on update, omitted fields preserve the
        existing value.

        - `type: "limited"`

          Network policy type

        - `allow_mcp_servers: optional boolean or null`

          Permits outbound access to MCP server endpoints configured on the agent, beyond those listed in the `allowed_hosts` array. Defaults to `false`.

        - `allow_package_managers: optional boolean or null`

          Permits outbound access to public package registries (PyPI, npm, etc.) beyond those listed in the `allowed_hosts` array. Defaults to `false` on creation. Must be `true` when `packages` are specified.

        - `allowed_hosts: optional array of string or null`

          Specifies domains the container can reach.

    - `packages: optional BetaPackagesParams or null`

      Package manager configuration. Under `limited` networking, requires `networking.allow_package_managers` to be `true`. Omit on update to preserve the existing value.

      - `type: optional "packages"`

        Package configuration type

        default: packages

      - `apt: optional array of string or null`

        Ubuntu/Debian packages to install

      - `cargo: optional array of string or null`

        Rust packages to install

      - `gem: optional array of string or null`

        Ruby packages to install

      - `go: optional array of string or null`

        Go packages to install

      - `npm: optional array of string or null`

        Node.js packages to install

      - `pip: optional array of string or null`

        Python packages to install

  - `BetaSelfHostedConfigParams object`

    Request params for `self_hosted` environment configuration.

    - `type: "self_hosted"`

      Environment type

- `description: optional string or null`

  Optional description of the environment

  maxLength: 1024

- `metadata: optional map[string]`

  User-provided metadata key-value pairs

- `scope: optional "organization" or "account" or null`

  The visibility scope for this environment. 'organization' makes the environment visible to all accounts. 'account' restricts visibility to the owning account only. API organizations support only 'organization'; 'account' is rejected. If not specified, defaults based on organization type.

  - `"organization"`

  - `"account"`

## Returns

- `BetaEnvironment object`

  Unified Environment resource for both cloud and self-hosted environments.

  - `type: "environment"`

    The type of object (always 'environment')

    default: environment

  - `id: string`

    Environment identifier (e.g., 'env_...')

  - `archived_at: string or null`

    RFC 3339 timestamp when environment was archived, or null if not archived

  - `config: BetaCloudConfig or BetaSelfHostedConfig`

    Environment configuration (either Anthropic Cloud or self-hosted)

    - `BetaCloudConfig object`

      `cloud` environment configuration.

      - `type: "cloud"`

        Environment type

      - `networking: BetaUnrestrictedNetwork or BetaLimitedNetwork`

        Network configuration policy.

        - `BetaUnrestrictedNetwork object`

          Unrestricted network access.

          - `type: "unrestricted"`

            Network policy type

        - `BetaLimitedNetwork object`

          Limited network access.

          - `type: "limited"`

            Network policy type

          - `allow_mcp_servers: boolean`

            Permits outbound access to MCP server endpoints configured on the agent, beyond those listed in the `allowed_hosts` array.

          - `allow_package_managers: boolean`

            Permits outbound access to public package registries (PyPI, npm, etc.) beyond those listed in the `allowed_hosts` array.

          - `allowed_hosts: array of string`

            Specifies domains the container can reach.

      - `packages: BetaPackages`

        Package manager configuration.

        - `type: optional "packages"`

          Package configuration type

          default: packages

        - `apt: array of string`

          Ubuntu/Debian packages to install

        - `cargo: array of string`

          Rust packages to install

        - `gem: array of string`

          Ruby packages to install

        - `go: array of string`

          Go packages to install

        - `npm: array of string`

          Node.js packages to install

        - `pip: array of string`

          Python packages to install

    - `BetaSelfHostedConfig object`

      Configuration for self-hosted environments.

      - `type: "self_hosted"`

        Environment type

  - `created_at: string`

    RFC 3339 timestamp when environment was created

  - `description: string or null`

    User-provided description for the environment; null when unset

  - `metadata: map[string]`

    User-provided metadata key-value pairs

  - `name: string`

    Human-readable name for the environment

  - `updated_at: string`

    RFC 3339 timestamp when environment was last updated

  - `scope: optional "organization" or "account"`

    The visibility scope for this environment. 'organization' means visible to all accounts. 'account' means visible only to the owning account.

    - `"organization"`

    - `"account"`

## Example

```bash
curl https://api.anthropic.com/v1/environments \
    -H 'Content-Type: application/json' \
    -H 'anthropic-version: 2023-06-01' \
    -H 'anthropic-beta: managed-agents-2026-04-01' \
    -H "X-Api-Key: $ANTHROPIC_API_KEY" \
    -d '{
          "name": "python-data-analysis",
          "config": {
            "type": "cloud",
            "networking": {
              "type": "limited",
              "allow_package_managers": true,
              "allowed_hosts": [
                "api.example.com"
              ]
            },
            "packages": {
              "pip": [
                "pandas",
                "numpy"
              ]
            }
          },
          "description": "Python environment with data-analysis packages."
        }'
```

### Response (200)

```json
{
  "id": "env_011CZkZ9X2dpNyB7HsEFoRfW",
  "archived_at": null,
  "config": {
    "networking": {
      "allow_mcp_servers": false,
      "allow_package_managers": true,
      "allowed_hosts": [
        "api.example.com"
      ],
      "type": "limited"
    },
    "packages": {
      "apt": [
        "string"
      ],
      "cargo": [
        "string"
      ],
      "gem": [
        "string"
      ],
      "go": [
        "string"
      ],
      "npm": [
        "string"
      ],
      "pip": [
        "pandas",
        "numpy"
      ],
      "type": "packages"
    },
    "type": "cloud"
  },
  "created_at": "2026-03-15T10:00:00Z",
  "description": "Python environment with data-analysis packages.",
  "metadata": {},
  "name": "python-data-analysis",
  "type": "environment",
  "updated_at": "2026-03-15T10:00:00Z",
  "scope": "organization"
}
```
