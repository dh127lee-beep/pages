# Work — Domain types

원문: https://platform.claude.com/docs/en/api/beta/environments/work



### Beta Self Hosted Work

- `BetaSelfHostedWork object`

  Work resource representing a unit of work in a self-hosted environment.

  Work items are queued when sessions are created or when long-dormant sessions
  receive new messages. The environment worker polls for work to execute in a
  self-hosted sandbox.

  - `type: "work"`

    The type of object (always 'work')

    default: work

  - `id: string`

    Work identifier (e.g., 'work_...')

  - `acknowledged_at: string or null`

    RFC 3339 timestamp when the work item was acknowledged and assigned to a self-hosted sandbox

  - `created_at: string`

    RFC 3339 timestamp when work was created

  - `data: BetaSessionWorkData`

    The actual work to be performed

    - `type: "session"`

      Type of work data

    - `id: string`

      Session identifier (e.g., 'session_...')

  - `environment_id: string`

    Environment identifier this work belongs to (e.g., `env_...`)

  - `latest_heartbeat_at: string or null`

    RFC 3339 timestamp of the most recent heartbeat

  - `metadata: map[string]`

    User-provided metadata key-value pairs associated with this work item

  - `secret: string or null`

    Credential payload used by the environment worker to execute this work item. May be populated when polling for work; null on all other retrieval paths.

  - `started_at: string or null`

    RFC 3339 timestamp when work execution started

  - `state: "queued" or "starting" or "active" or 2 more`

    Current state of the work item

    - `"queued"`

    - `"starting"`

    - `"active"`

    - `"stopping"`

    - `"stopped"`

  - `stop_requested_at: string or null`

    RFC 3339 timestamp when stop was requested

  - `stopped_at: string or null`

    RFC 3339 timestamp when work execution stopped

### Beta Self Hosted Work Heartbeat Response

- `BetaSelfHostedWorkHeartbeatResponse object`

  Response after recording a heartbeat for a work item.

  - `type: "work_heartbeat"`

    The type of response

    default: work_heartbeat

  - `last_heartbeat: string`

    RFC 3339 timestamp of the actual heartbeat from DB

  - `lease_extended: boolean`

    Whether the heartbeat succeeded in extending the lease

  - `state: "queued" or "starting" or "active" or 2 more`

    Current state of the work item (active/stopping/stopped)

    - `"queued"`

    - `"starting"`

    - `"active"`

    - `"stopping"`

    - `"stopped"`

  - `ttl_seconds: number`

    Effective TTL applied to the lease

### Beta Self Hosted Work List Response

- `BetaSelfHostedWorkListResponse object`

  Response when listing work items with cursor-based pagination.

  - `data: array of BetaSelfHostedWork`

    List of work items

    - `type: "work"`

      The type of object (always 'work')

      default: work

    - `id: string`

      Work identifier (e.g., 'work_...')

    - `acknowledged_at: string or null`

      RFC 3339 timestamp when the work item was acknowledged and assigned to a self-hosted sandbox

    - `created_at: string`

      RFC 3339 timestamp when work was created

    - `data: BetaSessionWorkData`

      The actual work to be performed

      - `type: "session"`

        Type of work data

      - `id: string`

        Session identifier (e.g., 'session_...')

    - `environment_id: string`

      Environment identifier this work belongs to (e.g., `env_...`)

    - `latest_heartbeat_at: string or null`

      RFC 3339 timestamp of the most recent heartbeat

    - `metadata: map[string]`

      User-provided metadata key-value pairs associated with this work item

    - `secret: string or null`

      Credential payload used by the environment worker to execute this work item. May be populated when polling for work; null on all other retrieval paths.

    - `started_at: string or null`

      RFC 3339 timestamp when work execution started

    - `state: "queued" or "starting" or "active" or 2 more`

      Current state of the work item

      - `"queued"`

      - `"starting"`

      - `"active"`

      - `"stopping"`

      - `"stopped"`

    - `stop_requested_at: string or null`

      RFC 3339 timestamp when stop was requested

    - `stopped_at: string or null`

      RFC 3339 timestamp when work execution stopped

  - `next_page: string or null`

    Opaque cursor for fetching the next page of results

### Beta Self Hosted Work Queue Stats

- `BetaSelfHostedWorkQueueStats object`

  Statistics about the work queue for an environment.

  Uses Redis Stream consumer group metrics for O(1) queries.

  - `type: "work_queue_stats"`

    The type of object

    default: work_queue_stats

  - `depth: number`

    Number of work items waiting to be picked up (lag from consumer group)

  - `oldest_queued_at: string or null`

    RFC 3339 timestamp of oldest item in the work stream (includes both queued and pending items), null if stream empty

  - `pending: number`

    Number of work items being processed (polled but not acknowledged)

    default: 0

  - `workers_polling: number or null`

    Number of workers that have polled for work in the last 30 seconds. Requires worker_id to be sent with poll requests.

### Beta Self Hosted Work Stop Request

- `BetaSelfHostedWorkStopRequest object`

  Request to stop a work item.

  - `force: optional boolean`

    If true, immediately stop work without graceful shutdown

    default: false

### Beta Self Hosted Work Update Request

- `BetaSelfHostedWorkUpdateRequest object`

  Request to update work item metadata.

  - `metadata: map[string]`

    Metadata patch. Set a key to a string to upsert it, or to null to delete it. Omit the field to preserve existing metadata.

### Beta Session Work Data

- `BetaSessionWorkData object`

  Work data for session work items.

  This resource type is used when work represents a session that needs to be executed
  in a self-hosted environment.

  - `type: "session"`

    Type of work data

  - `id: string`

    Session identifier (e.g., 'session_...')
