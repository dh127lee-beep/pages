# Certificates — Domain types

원문: https://platform.claude.com/docs/en/api/beta/tunnels/certificates



### Beta Tunnel Certificate

- `BetaTunnelCertificate object`

  A CA certificate attached to a tunnel.

  - `type: "tunnel_certificate"`

  - `id: string`

    Unique identifier for the certificate, prefixed with `tcrt_`.

  - `archived_at: string or null`

    RFC 3339 datetime string indicating when the certificate was archived. Null if it is still in the trusted set.

    format: date-time

  - `created_at: string`

    RFC 3339 datetime string indicating when the certificate was registered.

    format: date-time

  - `expires_at: string or null`

    RFC 3339 datetime string indicating when the certificate expires, or `null` if it does not expire.

    format: date-time

  - `fingerprint: string`

    Lowercase hex SHA-256 fingerprint of the certificate's DER encoding.

  - `tunnel_id: string`

    ID of the tunnel the certificate is registered against.
