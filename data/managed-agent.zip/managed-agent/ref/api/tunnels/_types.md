# Tunnels — Domain types

원문: https://platform.claude.com/docs/en/api/beta/tunnels



### Beta Tunnel

- `BetaTunnel object`

  An MCP tunnel.

  - `type: "tunnel"`

  - `id: string`

    Unique identifier for the tunnel, prefixed with `tnl_`.

  - `archived_at: string or null`

    RFC 3339 datetime string indicating when the tunnel was archived. Null if it is not archived.

    format: date-time

  - `created_at: string`

    RFC 3339 datetime string indicating when the tunnel was created.

    format: date-time

  - `display_name: string or null`

    Human-readable name for the tunnel (1-255 characters). Null if unset.

  - `domain: string`

    Anthropic-assigned hostname for the tunnel. MCP server URLs whose host is a subdomain of this value are routed through the tunnel. Globally unique and never reused, even after the tunnel is archived.

### Beta Tunnel Token

- `BetaTunnelToken object`

  A tunnel's connector token.

  - `type: "tunnel_token"`

  - `id: string`

    Stable identifier for the current token value. Changes when the token is rotated.

  - `tunnel_token: string`

    The connector token used to run the tunnel. Treat as a credential.

