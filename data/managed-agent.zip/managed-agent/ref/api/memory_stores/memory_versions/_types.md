# Memory Versions — Domain types

원문: https://platform.claude.com/docs/en/api/beta/memory_stores/memory_versions



### Beta Managed Agents Actor

- `BetaManagedAgentsActor = BetaManagedAgentsSessionActor or BetaManagedAgentsAPIActor or BetaManagedAgentsUserActor or BetaManagedAgentsServiceAccountActor`

  Identifies who performed an operation. Recorded when the operation happens and not updated afterwards, so the ID may refer to a user, service account, API key, or session that has since been deleted.

  - `BetaManagedAgentsSessionActor object`

    An agent acting during a session, for example through the session's mounted filesystem. It names the session itself, not the user or API key that started the session.

    - `type: "session_actor"`

    - `session_id: string`

      ID of the session (a `sesn_...` value). Look up the session via [Retrieve a session](https://platform.claude.com/docs/en/api/beta/sessions/retrieve?sdk_languages=http) for further provenance.

      minLength: 1

  - `BetaManagedAgentsAPIActor object`

    A direct caller of the public API, identified by the API key that authenticated the request.

    - `type: "api_actor"`

    - `api_key_id: string`

      ID of the API key (an `apikey_...` value). This identifies the key, not the secret.

      minLength: 1

  - `BetaManagedAgentsUserActor object`

    A human user, for example acting through the Anthropic Console.

    - `type: "user_actor"`

    - `user_id: string`

      ID of the user (a `user_...` value).

      minLength: 1

  - `BetaManagedAgentsServiceAccountActor object`

    A workload authenticated as a service account, for example via Workload Identity Federation.

    - `type: "service_account_actor"`

    - `service_account_id: string`

      ID of the service account (a `svac_...` value).

      minLength: 1

### Beta Managed Agents API Actor

- `BetaManagedAgentsAPIActor object`

  A direct caller of the public API, identified by the API key that authenticated the request.

  - `type: "api_actor"`

  - `api_key_id: string`

    ID of the API key (an `apikey_...` value). This identifies the key, not the secret.

    minLength: 1

### Beta Managed Agents Memory Version

- `BetaManagedAgentsMemoryVersion object`

  A `memory_version` object: one immutable, attributed row in a memory's append-only history. Every non-no-op mutation to a memory produces a new version. Versions belong to the store (not the individual memory) and are not deleted with the memory; each version is retained for at least the version retention period after it was written, unless the store itself is deleted. Retrieving a redacted version returns 200 with `content`, `path`, `content_size_bytes`, and `content_sha256` set to `null`; branch on `redacted_at`, not HTTP status.

  - `type: "memory_version"`

  - `id: string`

    Unique identifier for this version (a `memver_...` value).

  - `created_at: string`

    When this version was written, in RFC 3339 format.

    format: date-time

  - `memory_id: string`

    ID of the memory this version snapshots (a `mem_...` value). Remains valid after the memory is deleted; pass it as `memory_id` to [List memory versions](https://platform.claude.com/docs/en/api/beta/memory_stores/memory_versions/list?sdk_languages=http) to retrieve the memory's retained versions, including the `deleted` row while the lineage is retained.

  - `memory_store_id: string`

    ID of the memory store this version belongs to (a `memstore_...` value).

  - `operation: BetaManagedAgentsMemoryVersionOperation`

    The kind of mutation this version records: `created`, `modified`, or `deleted`.

    - `"created"`

      The memory was created. The first version in any memory's lineage.

    - `"modified"`

      The memory's `content`, `path`, or both were changed via update. Writes the agent makes through the filesystem mount also appear as `modified`.

    - `"deleted"`

      The memory was deleted. The `content`, `content_size_bytes`, and `content_sha256` fields are `null` on this version. The preceding version, while it is retained, records the deleted content's size and hash.

  - `content: optional string or null`

    The memory's UTF-8 text content as of this version. `null` when `view=basic`, when `operation` is `deleted`, or when `redacted_at` is set.

  - `content_sha256: optional string or null`

    Lowercase hex SHA-256 digest of `content` as of this version (64 characters). `null` when `redacted_at` is set or `operation` is `deleted`. Populated regardless of `view` otherwise.

  - `content_size_bytes: optional number or null`

    Size of `content` in bytes as of this version. `null` when `redacted_at` is set or `operation` is `deleted`. Populated regardless of `view` otherwise.

    format: int32

  - `created_by: optional BetaManagedAgentsActor`

    Who performed this write: one of `session_actor`, `api_actor`, `user_actor`, or `service_account_actor`; `null` when no writer is recorded. Captured at write time and preserved through redaction. A `session_actor` is an agent writing through the store's mounted filesystem at `/mnt/memory/`. The API key that created that session is not recorded on agent writes, so attribution names who made the write, not who is ultimately responsible; look up session provenance via the [Sessions API](https://platform.claude.com/docs/en/api/beta/sessions/retrieve?sdk_languages=http).

    - `BetaManagedAgentsSessionActor object`

      An agent acting during a session, for example through the session's mounted filesystem. It names the session itself, not the user or API key that started the session.

      - `type: "session_actor"`

      - `session_id: string`

        ID of the session (a `sesn_...` value). Look up the session via [Retrieve a session](https://platform.claude.com/docs/en/api/beta/sessions/retrieve?sdk_languages=http) for further provenance.

        minLength: 1

    - `BetaManagedAgentsAPIActor object`

      A direct caller of the public API, identified by the API key that authenticated the request.

      - `type: "api_actor"`

      - `api_key_id: string`

        ID of the API key (an `apikey_...` value). This identifies the key, not the secret.

        minLength: 1

    - `BetaManagedAgentsUserActor object`

      A human user, for example acting through the Anthropic Console.

      - `type: "user_actor"`

      - `user_id: string`

        ID of the user (a `user_...` value).

        minLength: 1

    - `BetaManagedAgentsServiceAccountActor object`

      A workload authenticated as a service account, for example via Workload Identity Federation.

      - `type: "service_account_actor"`

      - `service_account_id: string`

        ID of the service account (a `svac_...` value).

        minLength: 1

  - `path: optional string or null`

    The memory's path at the time of this write. `null` if and only if `redacted_at` is set.

  - `redacted_at: optional string or null`

    When this version was redacted, in RFC 3339 format, or `null` if it has not been redacted. When set, `content`, `path`, `content_size_bytes`, and `content_sha256` are all `null`. See [Redact a memory version](https://platform.claude.com/docs/en/api/beta/memory_stores/memory_versions/redact?sdk_languages=http).

    format: date-time

  - `redacted_by: optional BetaManagedAgentsActor`

    Who redacted this version, or `null` if it has not been redacted. In practice always an `api_actor`, `user_actor`, or `service_account_actor` (agents do not have a redact capability).

### Beta Managed Agents Memory Version Operation

- `BetaManagedAgentsMemoryVersionOperation = "created" or "modified" or "deleted"`

  The kind of mutation a `memory_version` records. Every non-no-op mutation to a memory appends exactly one version row with one of these values.

  - `"created"`

    The memory was created. The first version in any memory's lineage.

  - `"modified"`

    The memory's `content`, `path`, or both were changed via update. Writes the agent makes through the filesystem mount also appear as `modified`.

  - `"deleted"`

    The memory was deleted. The `content`, `content_size_bytes`, and `content_sha256` fields are `null` on this version. The preceding version, while it is retained, records the deleted content's size and hash.

### Beta Managed Agents Service Account Actor

- `BetaManagedAgentsServiceAccountActor object`

  A workload authenticated as a service account, for example via Workload Identity Federation.

  - `type: "service_account_actor"`

  - `service_account_id: string`

    ID of the service account (a `svac_...` value).

    minLength: 1

### Beta Managed Agents Session Actor

- `BetaManagedAgentsSessionActor object`

  An agent acting during a session, for example through the session's mounted filesystem. It names the session itself, not the user or API key that started the session.

  - `type: "session_actor"`

  - `session_id: string`

    ID of the session (a `sesn_...` value). Look up the session via [Retrieve a session](https://platform.claude.com/docs/en/api/beta/sessions/retrieve?sdk_languages=http) for further provenance.

    minLength: 1

### Beta Managed Agents User Actor

- `BetaManagedAgentsUserActor object`

  A human user, for example acting through the Anthropic Console.

  - `type: "user_actor"`

  - `user_id: string`

    ID of the user (a `user_...` value).

    minLength: 1
