---
title: List memory versions
url: https://platform.claude.com/docs/en/api/beta/memory_stores/memory_versions/list
---

# List memory versions

**GET** `/v1/memory_stores/{memory_store_id}/memory_versions`

List memory versions

## Path parameters

- `memory_store_id: string`

  The ID of the memory store whose version history to list (`memstore_...`).

## Query parameters

- `api_key_id: optional string`

  Return only versions written with the API key that has this ID.

- `"created_at[gte]": optional string`

  Return versions created at or after this time (inclusive).

  format: date-time

- `"created_at[lte]": optional string`

  Return versions created at or before this time (inclusive).

  format: date-time

- `limit: optional number`

  The maximum number of versions to return per page. Defaults to 20.

  format: int32

- `memory_id: optional string`

  Return only versions of the memory with this ID (`mem_...`).

  The filter still works after the memory is deleted. The results then include the version whose `operation` is `deleted`.

- `operation: optional BetaManagedAgentsMemoryVersionOperation`

  Return only versions that record this kind of change.

  - `"created"`

    The memory was created. The first version in any memory's lineage.

  - `"modified"`

    The memory's `content`, `path`, or both were changed via update. Writes the agent makes through the filesystem mount also appear as `modified`.

  - `"deleted"`

    The memory was deleted. The `content`, `content_size_bytes`, and `content_sha256` fields are `null` on this version. The preceding version, while it is retained, records the deleted content's size and hash.

- `page: optional string`

  The `next_page` value from a previous response, to get the next page. Omit it to get the first page.

- `service_account_id: optional string`

  Return only versions written by the service account with this ID (`svac_...`).

- `session_id: optional string`

  Return only versions written by the session with this ID.

- `view: optional BetaManagedAgentsMemoryView`

  Selects which projection of a `memory` or `memory_version` the server returns. `basic` returns the object with `content` set to `null`; `full` populates `content`. When omitted, the default is endpoint-specific: retrieve operations default to `full`; list, create, and update operations default to `basic`. Listing with `view=full` caps `limit` at 20.

  - `"basic"`

    Return the object with `content` set to `null`. The `content_size_bytes` and `content_sha256` fields remain populated, so sync clients can diff without fetching content.

  - `"full"`

    Return the object with `content` populated. On list endpoints, `view=full` caps `limit` at 20.

## Headers

- `"anthropic-version": optional string`

- `"anthropic-beta": optional array of AnthropicBeta`

  Optional header to specify the beta version(s) you want to use. (전체 enum 목록 생략 — Managed Agents는 `managed-agents-2026-04-01`, Dreams는 `dreaming-2026-04-21`, Tunnels는 `mcp-tunnels-2026-06-22`)

- `"anthropic-workspace-id": optional string`

  Optional header to select the Workspace for this request. The value is a Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).

  Only needed for credentials that can act on more than one Workspace. A credential that belongs to a specific Workspace may omit it; if sent, it must match that Workspace.

## Returns

- `data: optional array of BetaManagedAgentsMemoryVersion`

  One page of `memory_version` objects, ordered by `created_at` descending (newest first), with `id` as tiebreak.

  - `type: "memory_version"`

  - `id: string`

    Unique identifier for this version (a `memver_...` value).

  - `created_at: string`

    When this version was written, in RFC 3339 format.

    format: date-time

  - `memory_id: string`

    ID of the memory this version snapshots (a `mem_...` value). Remains valid after the memory is deleted; pass it as `memory_id` to [List memory versions](https://platform.claude.com/docs/en/api/beta/memory_stores/memory_versions/list?sdk_languages=http) to retrieve the memory's retained versions, including the `deleted` row while the lineage is retained.

  - `memory_store_id: string`

    ID of the memory store this version belongs to (a `memstore_...` value).

  - `operation: BetaManagedAgentsMemoryVersionOperation`

    The kind of mutation this version records: `created`, `modified`, or `deleted`.

    - `"created"`

      The memory was created. The first version in any memory's lineage.

    - `"modified"`

      The memory's `content`, `path`, or both were changed via update. Writes the agent makes through the filesystem mount also appear as `modified`.

    - `"deleted"`

      The memory was deleted. The `content`, `content_size_bytes`, and `content_sha256` fields are `null` on this version. The preceding version, while it is retained, records the deleted content's size and hash.

  - `content: optional string or null`

    The memory's UTF-8 text content as of this version. `null` when `view=basic`, when `operation` is `deleted`, or when `redacted_at` is set.

  - `content_sha256: optional string or null`

    Lowercase hex SHA-256 digest of `content` as of this version (64 characters). `null` when `redacted_at` is set or `operation` is `deleted`. Populated regardless of `view` otherwise.

  - `content_size_bytes: optional number or null`

    Size of `content` in bytes as of this version. `null` when `redacted_at` is set or `operation` is `deleted`. Populated regardless of `view` otherwise.

    format: int32

  - `created_by: optional BetaManagedAgentsActor`

    Who performed this write: one of `session_actor`, `api_actor`, `user_actor`, or `service_account_actor`; `null` when no writer is recorded. Captured at write time and preserved through redaction. A `session_actor` is an agent writing through the store's mounted filesystem at `/mnt/memory/`. The API key that created that session is not recorded on agent writes, so attribution names who made the write, not who is ultimately responsible; look up session provenance via the [Sessions API](https://platform.claude.com/docs/en/api/beta/sessions/retrieve?sdk_languages=http).

    - `BetaManagedAgentsSessionActor object`

      An agent acting during a session, for example through the session's mounted filesystem. It names the session itself, not the user or API key that started the session.

      - `type: "session_actor"`

      - `session_id: string`

        ID of the session (a `sesn_...` value). Look up the session via [Retrieve a session](https://platform.claude.com/docs/en/api/beta/sessions/retrieve?sdk_languages=http) for further provenance.

        minLength: 1

    - `BetaManagedAgentsAPIActor object`

      A direct caller of the public API, identified by the API key that authenticated the request.

      - `type: "api_actor"`

      - `api_key_id: string`

        ID of the API key (an `apikey_...` value). This identifies the key, not the secret.

        minLength: 1

    - `BetaManagedAgentsUserActor object`

      A human user, for example acting through the Anthropic Console.

      - `type: "user_actor"`

      - `user_id: string`

        ID of the user (a `user_...` value).

        minLength: 1

    - `BetaManagedAgentsServiceAccountActor object`

      A workload authenticated as a service account, for example via Workload Identity Federation.

      - `type: "service_account_actor"`

      - `service_account_id: string`

        ID of the service account (a `svac_...` value).

        minLength: 1

  - `path: optional string or null`

    The memory's path at the time of this write. `null` if and only if `redacted_at` is set.

  - `redacted_at: optional string or null`

    When this version was redacted, in RFC 3339 format, or `null` if it has not been redacted. When set, `content`, `path`, `content_size_bytes`, and `content_sha256` are all `null`. See [Redact a memory version](https://platform.claude.com/docs/en/api/beta/memory_stores/memory_versions/redact?sdk_languages=http).

    format: date-time

  - `redacted_by: optional BetaManagedAgentsActor`

    Who redacted this version, or `null` if it has not been redacted. In practice always an `api_actor`, `user_actor`, or `service_account_actor` (agents do not have a redact capability).

- `next_page: optional string or null`

  Opaque cursor for the next page (a `page_...` value), or `null` if there are no more results. Pass as `page` on the next request.

## Example

```bash
curl https://api.anthropic.com/v1/memory_stores/$MEMORY_STORE_ID/memory_versions \
    -H 'anthropic-version: 2023-06-01' \
    -H 'anthropic-beta: agent-memory-2026-07-22' \
    -H "X-Api-Key: $ANTHROPIC_API_KEY"
```

### Response (200)

```json
{
  "data": [
    {
      "id": "memver_011CZkZBJq5dWxk9fVLNcPht",
      "created_at": "2026-03-15T10:00:00Z",
      "memory_id": "mem_011CZkZ9X2dpNyB6YbtxvB6e",
      "memory_store_id": "memstore_01Wf3kQ8tZxB2mVr7HcJ4aNd",
      "operation": "created",
      "type": "memory_version",
      "content": null,
      "content_sha256": "ba7936d94c84d948a2232088f78228f175df6a8353b2d5bc9228eee5794a0024",
      "content_size_bytes": 28,
      "created_by": {
        "session_id": "sesn_011CZkZAtmR3yMPDzynEDxu7",
        "type": "session_actor"
      },
      "path": "/preferences/formatting.md",
      "redacted_at": null,
      "redacted_by": {
        "session_id": "x",
        "type": "session_actor"
      }
    }
  ],
  "next_page": "page_MjAyNS0wNS0xNFQwMDowMDowMFo="
}
```
