# Memories — Domain types

원문: https://platform.claude.com/docs/en/api/beta/memory_stores/memories



### Beta Managed Agents Conflict Error

- `BetaManagedAgentsConflictError object`

  - `type: "conflict_error"`

  - `message: optional string`

### Beta Managed Agents Content Sha256 Precondition

- `BetaManagedAgentsContentSha256Precondition object`

  Optimistic-concurrency precondition: the update applies only if the memory's stored `content_sha256` equals the supplied value. On mismatch, the request returns `memory_precondition_failed_error` (HTTP 409); re-read the memory and retry against the fresh state. If the precondition fails but the stored state already exactly matches the requested `content` and `path`, the server returns 200 instead of 409.

  - `type: "content_sha256"`

  - `content_sha256: optional string`

    Expected `content_sha256` of the stored memory (64 lowercase hexadecimal characters). Typically the `content_sha256` returned by a prior read or list call. Because the server applies no content normalization, clients can also compute this locally as the SHA-256 of the UTF-8 content bytes.

### Beta Managed Agents Deleted Memory

- `BetaManagedAgentsDeletedMemory object`

  Tombstone returned by [Delete a memory](https://platform.claude.com/docs/en/api/beta/memory_stores/memories/delete?sdk_languages=http). Deleting a memory does not erase its version history: its versions remain listable via [List memory versions](https://platform.claude.com/docs/en/api/beta/memory_stores/memory_versions/list?sdk_languages=http) while they are retained (each version is kept for at least the version retention period after it was written, unless the store itself is deleted).

  - `type: "memory_deleted"`

  - `id: string`

    ID of the deleted memory (a `mem_...` value).

### Beta Managed Agents Error

- `BetaManagedAgentsError = BetaInvalidRequestError or BetaAuthenticationError or BetaBillingError or 9 more`

  - `BetaInvalidRequestError object`

    - `type: "invalid_request_error"`

      default: invalid_request_error

    - `message: string`

      default: Invalid request

  - `BetaAuthenticationError object`

    - `type: "authentication_error"`

      default: authentication_error

    - `message: string`

      default: Authentication error

  - `BetaBillingError object`

    - `type: "billing_error"`

      default: billing_error

    - `message: string`

      default: Billing error

  - `BetaPermissionError object`

    - `type: "permission_error"`

      default: permission_error

    - `message: string`

      default: Permission denied

  - `BetaNotFoundError object`

    - `type: "not_found_error"`

      default: not_found_error

    - `message: string`

      default: Not found

  - `BetaRateLimitError object`

    - `type: "rate_limit_error"`

      default: rate_limit_error

    - `message: string`

      default: Rate limited

  - `BetaGatewayTimeoutError object`

    - `type: "timeout_error"`

      default: timeout_error

    - `message: string`

      default: Request timeout

  - `BetaAPIError object`

    - `type: "api_error"`

      default: api_error

    - `message: string`

      default: Internal server error

  - `BetaOverloadedError object`

    - `type: "overloaded_error"`

      default: overloaded_error

    - `message: string`

      default: Overloaded

  - `BetaManagedAgentsMemoryPreconditionFailedError object`

    The error returned with HTTP status 409 when a request's precondition doesn't hold for the memory's current state, such as `precondition` on an update or `expected_content_sha256` on a delete.

    The error doesn't include the memory's current state. Retrieve the memory to see its current content and `content_sha256` before you retry.

    See the [memory guide](https://platform.claude.com/docs/en/managed-agents/memory?sdk_languages=http#safe-content-edits-optimistic-concurrency) to learn more about safe content edits with content hash preconditions.

    - `type: "memory_precondition_failed_error"`

    - `message: optional string`

      A human-readable explanation of why the precondition failed.

  - `BetaManagedAgentsMemoryPathConflictError object`

    The error returned with HTTP status 409 when a create or rename targets a path that another memory uses, or a path that overlaps another memory's path.

    Two paths overlap when one is an ancestor of the other, such as `/notes` and `/notes/todo.md`. To free the path, rename or delete the memory that `conflicting_memory_id` references, then retry. To change that memory instead of creating a new one, update it.

    - `type: "memory_path_conflict_error"`

    - `conflicting_memory_id: optional string`

      The ID of the memory that blocked the write (`mem_...`), or an empty string if that memory can't be identified.

      Retry the request when it is empty.

    - `conflicting_path: optional string`

      The path that blocked the write: the requested path, or the path of a memory that is an ancestor or descendant of it.

    - `message: optional string`

      A human-readable explanation of the conflict. To handle the error in code, use `conflicting_path` and `conflicting_memory_id` instead.

  - `BetaManagedAgentsConflictError object`

    - `type: "conflict_error"`

    - `message: optional string`

### Beta Managed Agents Memory

- `BetaManagedAgentsMemory object`

  A `memory` object: a single text document at a hierarchical path inside a memory store. The `content` field is populated when `view=full` and `null` when `view=basic`; the `content_size_bytes` and `content_sha256` fields are always populated so sync clients can diff without fetching content. Memories are addressed by their `mem_...` ID; the path is the create key and can be changed via update.

  - `type: "memory"`

  - `id: string`

    Unique identifier for this memory (a `mem_...` value). Stable across renames; use this ID, not the path, to read, update, or delete the memory.

  - `content_sha256: string`

    Lowercase hex SHA-256 digest of the UTF-8 `content` bytes (64 characters). The server applies no normalization, so clients can compute the same hash locally for staleness checks and as the value for a `content_sha256` precondition on update. Always populated, regardless of `view`.

  - `content_size_bytes: number`

    Size of `content` in bytes (the UTF-8 plaintext length). Always populated, regardless of `view`.

    format: int32

  - `created_at: string`

    When this memory was created, in RFC 3339 format.

    format: date-time

  - `memory_store_id: string`

    ID of the memory store this memory belongs to (a `memstore_...` value).

  - `memory_version_id: string`

    ID of the `memory_version` representing this memory's current content (a `memver_...` value). This is the authoritative head pointer; `memory_version` objects do not carry an `is_latest` flag, so compare against this field instead. Enumerate the history via [List memory versions](https://platform.claude.com/docs/en/api/beta/memory_stores/memory_versions/list?sdk_languages=http).

  - `path: string`

    Hierarchical path of the memory within the store, e.g. `/projects/foo/notes.md`. Always starts with `/`. Paths are case-sensitive and unique within a store. Maximum 1,024 bytes.

  - `updated_at: string`

    When this memory was last modified, in RFC 3339 format. Use this as a cheap freshness signal; for who made the change, look up the head version's `created_by` via [List memory versions](https://platform.claude.com/docs/en/api/beta/memory_stores/memory_versions/list?sdk_languages=http).

    format: date-time

  - `content: optional string or null`

    The memory's UTF-8 text content. Populated when `view=full`; `null` when `view=basic`. Maximum 100 kB (102,400 bytes).

### Beta Managed Agents Memory List Item

- `BetaManagedAgentsMemoryListItem = BetaManagedAgentsMemory or BetaManagedAgentsMemoryPrefix`

  One item in a [List memories](https://platform.claude.com/docs/en/api/beta/memory_stores/memories/list?sdk_languages=http) response: either a `memory` object or, when `depth` is set, a `memory_prefix` rollup marker.

  - `BetaManagedAgentsMemory object`

    A `memory` object: a single text document at a hierarchical path inside a memory store. The `content` field is populated when `view=full` and `null` when `view=basic`; the `content_size_bytes` and `content_sha256` fields are always populated so sync clients can diff without fetching content. Memories are addressed by their `mem_...` ID; the path is the create key and can be changed via update.

    - `type: "memory"`

    - `id: string`

      Unique identifier for this memory (a `mem_...` value). Stable across renames; use this ID, not the path, to read, update, or delete the memory.

    - `content_sha256: string`

      Lowercase hex SHA-256 digest of the UTF-8 `content` bytes (64 characters). The server applies no normalization, so clients can compute the same hash locally for staleness checks and as the value for a `content_sha256` precondition on update. Always populated, regardless of `view`.

    - `content_size_bytes: number`

      Size of `content` in bytes (the UTF-8 plaintext length). Always populated, regardless of `view`.

      format: int32

    - `created_at: string`

      When this memory was created, in RFC 3339 format.

      format: date-time

    - `memory_store_id: string`

      ID of the memory store this memory belongs to (a `memstore_...` value).

    - `memory_version_id: string`

      ID of the `memory_version` representing this memory's current content (a `memver_...` value). This is the authoritative head pointer; `memory_version` objects do not carry an `is_latest` flag, so compare against this field instead. Enumerate the history via [List memory versions](https://platform.claude.com/docs/en/api/beta/memory_stores/memory_versions/list?sdk_languages=http).

    - `path: string`

      Hierarchical path of the memory within the store, e.g. `/projects/foo/notes.md`. Always starts with `/`. Paths are case-sensitive and unique within a store. Maximum 1,024 bytes.

    - `updated_at: string`

      When this memory was last modified, in RFC 3339 format. Use this as a cheap freshness signal; for who made the change, look up the head version's `created_by` via [List memory versions](https://platform.claude.com/docs/en/api/beta/memory_stores/memory_versions/list?sdk_languages=http).

      format: date-time

    - `content: optional string or null`

      The memory's UTF-8 text content. Populated when `view=full`; `null` when `view=basic`. Maximum 100 kB (102,400 bytes).

  - `BetaManagedAgentsMemoryPrefix object`

    A rolled-up directory marker returned by [List memories](https://platform.claude.com/docs/en/api/beta/memory_stores/memories/list?sdk_languages=http) when `depth` is set. Indicates that one or more memories exist deeper than the requested depth under this prefix. This is a list-time rollup, not a stored resource; it has no ID and no lifecycle. Each prefix counts toward the page `limit` and interleaves with `memory` items in path order.

    - `type: "memory_prefix"`

    - `path: string`

      The rolled-up path prefix, including a trailing `/` (e.g. `/projects/foo/`). Pass this value as `path_prefix` on a subsequent list call to drill into the directory.

### Beta Managed Agents Memory Path Conflict Error

- `BetaManagedAgentsMemoryPathConflictError object`

  The error returned with HTTP status 409 when a create or rename targets a path that another memory uses, or a path that overlaps another memory's path.

  Two paths overlap when one is an ancestor of the other, such as `/notes` and `/notes/todo.md`. To free the path, rename or delete the memory that `conflicting_memory_id` references, then retry. To change that memory instead of creating a new one, update it.

  - `type: "memory_path_conflict_error"`

  - `conflicting_memory_id: optional string`

    The ID of the memory that blocked the write (`mem_...`), or an empty string if that memory can't be identified.

    Retry the request when it is empty.

  - `conflicting_path: optional string`

    The path that blocked the write: the requested path, or the path of a memory that is an ancestor or descendant of it.

  - `message: optional string`

    A human-readable explanation of the conflict. To handle the error in code, use `conflicting_path` and `conflicting_memory_id` instead.

### Beta Managed Agents Memory Precondition Failed Error

- `BetaManagedAgentsMemoryPreconditionFailedError object`

  The error returned with HTTP status 409 when a request's precondition doesn't hold for the memory's current state, such as `precondition` on an update or `expected_content_sha256` on a delete.

  The error doesn't include the memory's current state. Retrieve the memory to see its current content and `content_sha256` before you retry.

  See the [memory guide](https://platform.claude.com/docs/en/managed-agents/memory?sdk_languages=http#safe-content-edits-optimistic-concurrency) to learn more about safe content edits with content hash preconditions.

  - `type: "memory_precondition_failed_error"`

  - `message: optional string`

    A human-readable explanation of why the precondition failed.

### Beta Managed Agents Memory Prefix

- `BetaManagedAgentsMemoryPrefix object`

  A rolled-up directory marker returned by [List memories](https://platform.claude.com/docs/en/api/beta/memory_stores/memories/list?sdk_languages=http) when `depth` is set. Indicates that one or more memories exist deeper than the requested depth under this prefix. This is a list-time rollup, not a stored resource; it has no ID and no lifecycle. Each prefix counts toward the page `limit` and interleaves with `memory` items in path order.

  - `type: "memory_prefix"`

  - `path: string`

    The rolled-up path prefix, including a trailing `/` (e.g. `/projects/foo/`). Pass this value as `path_prefix` on a subsequent list call to drill into the directory.

### Beta Managed Agents Memory View

- `BetaManagedAgentsMemoryView = "basic" or "full"`

  Selects which projection of a `memory` or `memory_version` the server returns. `basic` returns the object with `content` set to `null`; `full` populates `content`. When omitted, the default is endpoint-specific: retrieve operations default to `full`; list, create, and update operations default to `basic`. Listing with `view=full` caps `limit` at 20.

  - `"basic"`

    Return the object with `content` set to `null`. The `content_size_bytes` and `content_sha256` fields remain populated, so sync clients can diff without fetching content.

  - `"full"`

    Return the object with `content` populated. On list endpoints, `view=full` caps `limit` at 20.

### Beta Managed Agents Precondition

- `BetaManagedAgentsPrecondition object`

  Optional condition that must hold for an update to apply. When omitted, the update is unconditional. Asserts the current state of the memory being updated. When an update changes `path`, the precondition still refers to the memory's current content, not the destination path. Currently the only supported variant is `content_sha256`.

  - `type: "content_sha256"`

  - `content_sha256: optional string`

    Expected `content_sha256` of the stored memory (64 lowercase hexadecimal characters). Typically the `content_sha256` returned by a prior read or list call. Because the server applies no content normalization, clients can also compute this locally as the SHA-256 of the UTF-8 content bytes.
