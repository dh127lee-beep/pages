# Dreams — Domain types

원문: https://platform.claude.com/docs/en/api/beta/dreams



### Beta Dream

- `BetaDream object`

  An asynchronous job that reads a memory store and past sessions, then writes a reorganized version of that memory store.

  By default the dream writes its result to a new memory store and doesn't change the input memory store. With `output_behavior` set to `update_existing`, it writes its result into the input memory store instead.

  The Dreams API is in research preview: the request and response shapes are volatile and may change without the deprecation period that applies to generally-available endpoints.

  See the [Dreams guide](https://platform.claude.com/docs/en/managed-agents/dreams?sdk_languages=http#how-it-works) for what a dream reads and produces.

  - `type: "dream"`

  - `id: string`

    The unique ID of the dream (`drm_...`).

  - `archived_at: string or null`

    When the dream was archived, in RFC 3339, or `null` if it hasn't been archived.

    format: date-time

  - `created_at: string`

    When the dream was created, in RFC 3339.

    Lists of dreams are sorted by this time, newest first.

    format: date-time

  - `ended_at: string or null`

    When the dream reached `completed`, `failed`, or `canceled`, in RFC 3339, or `null` if it is still `pending` or `running`.

    format: date-time

  - `error: BetaDreamError or null`

    Why the dream failed, or `null` if `status` isn't `failed`.

    - `type: string`

      A code for why the dream failed, such as `timeout` or `internal_error`.

      The [Dreams guide](https://platform.claude.com/docs/en/managed-agents/dreams?sdk_languages=http#errors) lists common error codes and when they occur.

    - `message: string`

      A human-readable explanation of why the dream failed.

  - `inputs: array of BetaDreamInput`

    The sources that the dream reads, from the request that created it.

    - `BetaDreamMemoryStoreInput object`

      The memory store that a dream reads, given as an entry in `inputs`.

      With `output_behavior` set to `update_existing`, the dream writes its result into this memory store. Otherwise the dream doesn't change it.

      - `type: "memory_store"`

      - `memory_store_id: string`

        The ID of the memory store for the dream to read (`memstore_...`).

        The memory store must be in the same workspace as the dream and must not be archived.

        minLength: 1

    - `BetaDreamSessionsInput object`

      The sessions that a dream reads, given as an entry in `inputs`.

      - `type: "sessions"`

      - `session_ids: array of string`

        The IDs of the sessions whose transcripts the dream reads (`sesn_...`).

        Give 1 to 100 IDs, with no duplicates. Each session must be in the same workspace as the dream. Responses list the IDs in sorted order.

        The [limits table in the Dreams guide](https://platform.claude.com/docs/en/managed-agents/dreams?sdk_languages=http#limits) lists all the limits on a dream.

  - `instructions: string or null`

    The guidance given when the dream was created, or `null` if none was given.

  - `model: BetaDreamModelConfig`

    The model that runs a dream, from the request that created it.

    The dream uses this model for all of its work. The response always gives the model as an object, even if the request gave only a model ID.

    - `id: string`

      The ID of the model that runs the dream, as given in the request that created it.

      minLength: 1, maxLength: 256

    - `speed: optional "standard" or "fast"`

      How fast the model generates output for the dream. Always `standard`.

      - `"standard"`

      - `"fast"`

  - `output_behavior: BetaOutputBehavior`

    Where the dream writes its result, as set in the request that created the dream. If that request left out `output_behavior`, the dream used the `create_new` behavior.

    - `BetaOutputBehaviorCreateNew object`

      Write the result to a new memory store that starts as a copy of the input memory store. This is the default.

      The new memory store is in the same workspace as the dream. The dream doesn't change the input memory store.

      - `type: "create_new"`

    - `BetaOutputBehaviorUpdateExisting object`

      Write the result into the input memory store instead of a new memory store.

      The credential must be allowed to write memory stores, or the request returns a 403 error. While another `update_existing` dream on the same memory store hasn't fully stopped, the request returns a 409 error.

      - `type: "update_existing"`

      - `memory_store_id: string`

        The ID of the memory store for the dream to write its result to (`memstore_...`). It must be the memory store in the `memory_store` entry of `inputs`.

        minLength: 1

  - `outputs: array of BetaDreamOutput`

    The memory store that holds the dream's result, as a one-item array, or an empty array until the dream records that memory store.

    The array is empty while the dream is `pending` and for a short time after it starts `running`. It can stay empty if the dream fails or is canceled before then. The memory store holds the complete result only once `status` is `completed`.

    See the [Dreams guide](https://platform.claude.com/docs/en/managed-agents/dreams?sdk_languages=http#use-the-output) for how to review and use the result.

    - `type: "memory_store"`

    - `memory_store_id: string`

      The ID of the memory store that the dream writes its result to (`memstore_...`).

      With `output_behavior` set to `create_new`, this is a new memory store. With `update_existing`, it is the input memory store.

  - `session_id: string or null`

    The ID of the session that runs the dream (`sesn_...`), or `null` if that session hasn't started.

    Stream that session's events to follow what the dream reads and writes.

    See the [Dreams guide](https://platform.claude.com/docs/en/managed-agents/dreams?sdk_languages=http#watch-the-pipeline-run) for how to watch a running dream.

  - `status: BetaDreamStatus`

    Where a dream is in its lifecycle.

    `completed`, `failed`, and `canceled` are final: once a dream has one of these statuses, its status doesn't change again.

    See the [Dreams guide](https://platform.claude.com/docs/en/managed-agents/dreams?sdk_languages=http#lifecycle) for what each status means.

    - `"pending"`

      The dream is waiting to start and hasn't read its inputs yet.

      `outputs` is empty and every `usage` count is zero.

    - `"running"`

      The dream is reading its inputs and writing its result.

      `usage` updates while the dream has this status.

    - `"completed"`

      The dream finished and its output memory store holds the complete result.

    - `"failed"`

      The dream stopped with an error, which `error` describes.

      If `outputs` references a memory store, that memory store keeps what the dream wrote before it stopped.

    - `"canceled"`

      A cancel request stopped the dream before it reached `completed` or `failed`.

      If `outputs` references a memory store, that memory store keeps what the dream wrote. `usage` can keep changing after the cancel.

  - `usage: BetaDreamUsage`

    The dream's token counts, which stop changing once its `status` is `completed` or `failed`. After a cancel, they can keep changing.

    - `cache_creation_input_tokens: number`

      The dream's input tokens that were written to the prompt cache, for both the 5-minute and 1-hour cache durations.

      format: int32

    - `cache_read_input_tokens: number`

      The dream's input tokens that were read from the prompt cache.

      format: int32

    - `input_tokens: number`

      The dream's input tokens that weren't read from or written to the prompt cache.

      format: int32

    - `output_tokens: number`

      The tokens that the model generated for the dream.

      format: int32

### Beta Dream Error

- `BetaDreamError object`

  Failure detail for a Dream whose `status` is `failed`.

  - `type: string`

    A code for why the dream failed, such as `timeout` or `internal_error`.

    The [Dreams guide](https://platform.claude.com/docs/en/managed-agents/dreams?sdk_languages=http#errors) lists common error codes and when they occur.

  - `message: string`

    A human-readable explanation of why the dream failed.

### Beta Dream Input

- `BetaDreamInput = BetaDreamMemoryStoreInput or BetaDreamSessionsInput`

  A source that a dream reads, such as a memory store or a set of sessions.

  - `BetaDreamMemoryStoreInput object`

    The memory store that a dream reads, given as an entry in `inputs`.

    With `output_behavior` set to `update_existing`, the dream writes its result into this memory store. Otherwise the dream doesn't change it.

    - `type: "memory_store"`

    - `memory_store_id: string`

      The ID of the memory store for the dream to read (`memstore_...`).

      The memory store must be in the same workspace as the dream and must not be archived.

      minLength: 1

  - `BetaDreamSessionsInput object`

    The sessions that a dream reads, given as an entry in `inputs`.

    - `type: "sessions"`

    - `session_ids: array of string`

      The IDs of the sessions whose transcripts the dream reads (`sesn_...`).

      Give 1 to 100 IDs, with no duplicates. Each session must be in the same workspace as the dream. Responses list the IDs in sorted order.

      The [limits table in the Dreams guide](https://platform.claude.com/docs/en/managed-agents/dreams?sdk_languages=http#limits) lists all the limits on a dream.

### Beta Dream Memory Store Input

- `BetaDreamMemoryStoreInput object`

  The memory store that a dream reads, given as an entry in `inputs`.

  With `output_behavior` set to `update_existing`, the dream writes its result into this memory store. Otherwise the dream doesn't change it.

  - `type: "memory_store"`

  - `memory_store_id: string`

    The ID of the memory store for the dream to read (`memstore_...`).

    The memory store must be in the same workspace as the dream and must not be archived.

    minLength: 1

### Beta Dream Memory Store Output

- `BetaDreamMemoryStoreOutput object`

  The memory store that holds a dream's result, as an entry in `outputs`.

  - `type: "memory_store"`

  - `memory_store_id: string`

    The ID of the memory store that the dream writes its result to (`memstore_...`).

    With `output_behavior` set to `create_new`, this is a new memory store. With `update_existing`, it is the input memory store.

### Beta Dream Model Config

- `BetaDreamModelConfig object`

  The model that runs a dream, from the request that created it.

  The dream uses this model for all of its work. The response always gives the model as an object, even if the request gave only a model ID.

  - `id: string`

    The ID of the model that runs the dream, as given in the request that created it.

    minLength: 1, maxLength: 256

  - `speed: optional "standard" or "fast"`

    How fast the model generates output for the dream. Always `standard`.

    - `"standard"`

    - `"fast"`

### Beta Dream Model Config Param

- `BetaDreamModelConfigParam object`

  The object form of `model` in a request to create a dream.

  - `id: string`

    The ID of the model to run the dream with.

    The ID can be 1 to 256 characters long.

    The [limits table in the Dreams guide](https://platform.claude.com/docs/en/managed-agents/dreams?sdk_languages=http#limits) lists the supported models.

    minLength: 1, maxLength: 256

  - `speed: optional "standard" or "fast" or null`

    How fast the model generates output for the dream. Defaults to `standard`.

    Dreams accept only `standard`.

    - `"standard"`

    - `"fast"`

### Beta Dream Output

- `BetaDreamOutput object`

  An entry in a dream's `outputs` that references the memory store holding its result.

  - `type: "memory_store"`

  - `memory_store_id: string`

    The ID of the memory store that the dream writes its result to (`memstore_...`).

    With `output_behavior` set to `create_new`, this is a new memory store. With `update_existing`, it is the input memory store.

### Beta Dream Sessions Input

- `BetaDreamSessionsInput object`

  The sessions that a dream reads, given as an entry in `inputs`.

  - `type: "sessions"`

  - `session_ids: array of string`

    The IDs of the sessions whose transcripts the dream reads (`sesn_...`).

    Give 1 to 100 IDs, with no duplicates. Each session must be in the same workspace as the dream. Responses list the IDs in sorted order.

    The [limits table in the Dreams guide](https://platform.claude.com/docs/en/managed-agents/dreams?sdk_languages=http#limits) lists all the limits on a dream.

### Beta Dream Status

- `BetaDreamStatus = "pending" or "running" or "completed" or 2 more`

  Where a dream is in its lifecycle.

  `completed`, `failed`, and `canceled` are final: once a dream has one of these statuses, its status doesn't change again.

  See the [Dreams guide](https://platform.claude.com/docs/en/managed-agents/dreams?sdk_languages=http#lifecycle) for what each status means.

  - `"pending"`

    The dream is waiting to start and hasn't read its inputs yet.

    `outputs` is empty and every `usage` count is zero.

  - `"running"`

    The dream is reading its inputs and writing its result.

    `usage` updates while the dream has this status.

  - `"completed"`

    The dream finished and its output memory store holds the complete result.

  - `"failed"`

    The dream stopped with an error, which `error` describes.

    If `outputs` references a memory store, that memory store keeps what the dream wrote before it stopped.

  - `"canceled"`

    A cancel request stopped the dream before it reached `completed` or `failed`.

    If `outputs` references a memory store, that memory store keeps what the dream wrote. `usage` can keep changing after the cancel.

### Beta Dream Usage

- `BetaDreamUsage object`

  The tokens that a dream has used so far.

  The counts are zero while the dream is `pending` and update while it is `running`. They can keep changing after a cancel.

  See the [Dreams guide](https://platform.claude.com/docs/en/managed-agents/dreams?sdk_languages=http#billing) for how dreams are billed. See the [prompt caching guide](https://platform.claude.com/docs/en/build-with-claude/prompt-caching?sdk_languages=http#tracking-cache-performance) for how the input token counts add up.

  - `cache_creation_input_tokens: number`

    The dream's input tokens that were written to the prompt cache, for both the 5-minute and 1-hour cache durations.

    format: int32

  - `cache_read_input_tokens: number`

    The dream's input tokens that were read from the prompt cache.

    format: int32

  - `input_tokens: number`

    The dream's input tokens that weren't read from or written to the prompt cache.

    format: int32

  - `output_tokens: number`

    The tokens that the model generated for the dream.

    format: int32

### Beta Dreaming Error

- `BetaDreamingError = BetaInvalidRequestError or BetaAuthenticationError or BetaBillingError or 7 more`

  - `BetaInvalidRequestError object`

    - `type: "invalid_request_error"`

      default: invalid_request_error

    - `message: string`

      default: Invalid request

  - `BetaAuthenticationError object`

    - `type: "authentication_error"`

      default: authentication_error

    - `message: string`

      default: Authentication error

  - `BetaBillingError object`

    - `type: "billing_error"`

      default: billing_error

    - `message: string`

      default: Billing error

  - `BetaPermissionError object`

    - `type: "permission_error"`

      default: permission_error

    - `message: string`

      default: Permission denied

  - `BetaNotFoundError object`

    - `type: "not_found_error"`

      default: not_found_error

    - `message: string`

      default: Not found

  - `BetaRateLimitError object`

    - `type: "rate_limit_error"`

      default: rate_limit_error

    - `message: string`

      default: Rate limited

  - `BetaGatewayTimeoutError object`

    - `type: "timeout_error"`

      default: timeout_error

    - `message: string`

      default: Request timeout

  - `BetaAPIError object`

    - `type: "api_error"`

      default: api_error

    - `message: string`

      default: Internal server error

  - `BetaOverloadedError object`

    - `type: "overloaded_error"`

      default: overloaded_error

    - `message: string`

      default: Overloaded

  - `BetaTargetStoreHeldError object`

    Returned with status 409 when a request to create a dream sets `output_behavior` to `update_existing` and another dream that writes into the same memory store hasn't fully stopped.

    The other dream is `pending` or `running`, or it has just stopped and is still finishing its last writes. `message` gives the ID of the other dream when the server can identify it. If that dream has already reached `completed`, `failed`, or `canceled`, retry after a short wait. Otherwise, wait for the other dream to end or cancel it, then retry. The response sets the `x-should-retry` header to `false`.

    - `type: "conflict_error"`

    - `message: optional string`

      A human-readable explanation of why the memory store can't be used yet, with the ID of the dream that is using it when the server can identify it.

### Beta Output Behavior

- `BetaOutputBehavior = BetaOutputBehaviorCreateNew or BetaOutputBehaviorUpdateExisting`

  Which memory store a dream writes its result to. Defaults to `create_new` when left out of a create request.

  - `BetaOutputBehaviorCreateNew object`

    Write the result to a new memory store that starts as a copy of the input memory store. This is the default.

    The new memory store is in the same workspace as the dream. The dream doesn't change the input memory store.

    - `type: "create_new"`

  - `BetaOutputBehaviorUpdateExisting object`

    Write the result into the input memory store instead of a new memory store.

    The credential must be allowed to write memory stores, or the request returns a 403 error. While another `update_existing` dream on the same memory store hasn't fully stopped, the request returns a 409 error.

    - `type: "update_existing"`

    - `memory_store_id: string`

      The ID of the memory store for the dream to write its result to (`memstore_...`). It must be the memory store in the `memory_store` entry of `inputs`.

      minLength: 1

### Beta Output Behavior Create New

- `BetaOutputBehaviorCreateNew object`

  Write the result to a new memory store that starts as a copy of the input memory store. This is the default.

  The new memory store is in the same workspace as the dream. The dream doesn't change the input memory store.

  - `type: "create_new"`

### Beta Output Behavior Update Existing

- `BetaOutputBehaviorUpdateExisting object`

  Write the result into the input memory store instead of a new memory store.

  The credential must be allowed to write memory stores, or the request returns a 403 error. While another `update_existing` dream on the same memory store hasn't fully stopped, the request returns a 409 error.

  - `type: "update_existing"`

  - `memory_store_id: string`

    The ID of the memory store for the dream to write its result to (`memstore_...`). It must be the memory store in the `memory_store` entry of `inputs`.

    minLength: 1

### Beta Target Store Held Error

- `BetaTargetStoreHeldError object`

  Returned with status 409 when a request to create a dream sets `output_behavior` to `update_existing` and another dream that writes into the same memory store hasn't fully stopped.

  The other dream is `pending` or `running`, or it has just stopped and is still finishing its last writes. `message` gives the ID of the other dream when the server can identify it. If that dream has already reached `completed`, `failed`, or `canceled`, retry after a short wait. Otherwise, wait for the other dream to end or cancel it, then retry. The response sets the `x-should-retry` header to `false`.

  - `type: "conflict_error"`

  - `message: optional string`

    A human-readable explanation of why the memory store can't be used yet, with the ID of the dream that is using it when the server can identify it.
