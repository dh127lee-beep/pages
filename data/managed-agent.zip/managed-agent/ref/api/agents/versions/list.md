---
title: List Agent Versions
url: https://platform.claude.com/docs/en/api/beta/agents/versions/list
---

# List Agent Versions

**GET** `/v1/agents/{agent_id}/versions`

List Agent Versions

## Path parameters

- `agent_id: string`

  Agent ID to list versions for.

## Query parameters

- `limit: optional number`

  Maximum results per page. Default 20, maximum 100.

  format: int32

- `page: optional string`

  Opaque pagination cursor.

## Headers

- `"anthropic-version": optional string`

- `"anthropic-beta": optional array of AnthropicBeta`

  Optional header to specify the beta version(s) you want to use. (전체 enum 목록 생략 — Managed Agents는 `managed-agents-2026-04-01`, Dreams는 `dreaming-2026-04-21`, Tunnels는 `mcp-tunnels-2026-06-22`)

- `"anthropic-workspace-id": optional string`

  Optional header to select the Workspace for this request. The value is a Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).

  Only needed for credentials that can act on more than one Workspace. A credential that belongs to a specific Workspace may omit it; if sent, it must match that Workspace.

## Returns

- `data: array of BetaManagedAgentsAgent`

  Agent versions.

  - `type: "agent"`

  - `id: string`

  - `archived_at: string or null`

    When the agent was archived. Null if not archived.

    format: date-time

  - `created_at: string`

    A timestamp in RFC 3339 format

    format: date-time

  - `description: string or null`

  - `mcp_servers: array of BetaManagedAgentsMCPServerURLDefinition`

    - `type: "url"`

    - `name: string`

    - `url: string`

  - `metadata: map[string]`

  - `model: BetaManagedAgentsModelConfig`

    Model identifier and configuration.

    - `id: BetaManagedAgentsModel`

      The model that will power your agent.

      See [models](https://docs.anthropic.com/en/docs/models-overview) for additional details and options.

      - `"claude-haiku-5-5"`

        Fastest model for high-volume, real-time tasks

      - `"claude-sonnet-5-5"`

        Efficient model for coding and agents

      - `"claude-opus-5-5"`

        Powerful intelligence for coding, knowledge work, and long-running agents

      - `"claude-fable-5-1"`

        Frontier intelligence for ambitious tasks across coding, scientific discovery, and enterprise workflows

      - `"claude-sonnet-5"`

        Efficient model for coding and agents

      - `"claude-fable-5"`

        Next generation of intelligence for the hardest knowledge work and coding problems

      - `"claude-opus-5"`

        Powerful intelligence for long-running agents and coding

      - `"claude-opus-4-8"`

        Powerful intelligence for long-running agents and coding

      - `"claude-opus-4-7"`

        Powerful intelligence for long-running agents and coding

      - `"claude-opus-4-6"`

        Powerful intelligence for long-running agents and coding

      - `"claude-sonnet-4-6"`

        Best combination of speed and intelligence

      - `"claude-haiku-4-5"`

      - `"claude-haiku-4-5-20251001"`

      - `"claude-opus-4-5"`

        Powerful intelligence for long-running agents and coding

      - `"claude-opus-4-5-20251101"`

        Powerful intelligence for long-running agents and coding

      - `"claude-sonnet-4-5"`

        **Deprecated**: Will reach end-of-life on November 30, 2026. Please migrate to claude-sonnet-5-5. Visit https://docs.anthropic.com/en/docs/resources/model-deprecations for more information.

        High-performance model for agents and coding

      - `"claude-sonnet-4-5-20250929"`

        **Deprecated**: Will reach end-of-life on November 30, 2026. Please migrate to claude-sonnet-5-5. Visit https://docs.anthropic.com/en/docs/resources/model-deprecations for more information.

        High-performance model for agents and coding

      - `string`

    - `effort: optional BetaManagedAgentsEffortLow or BetaManagedAgentsEffortMedium or BetaManagedAgentsEffortHigh or 2 more`

      How hard Claude works on each inference call. One of `low`, `medium`, `high`, `xhigh`, `max`. Always present; resolved to the per-model default at save time when not supplied.

      - `BetaManagedAgentsEffortLow object`

        Low effort. Favors latency over reasoning depth.

        - `type: "low"`

      - `BetaManagedAgentsEffortMedium object`

        Medium effort. Balances latency and reasoning depth.

        - `type: "medium"`

      - `BetaManagedAgentsEffortHigh object`

        High effort. Favors reasoning depth.

        - `type: "high"`

      - `BetaManagedAgentsEffortXhigh object`

        Extra-high effort. Not all models accept this level.

        - `type: "xhigh"`

      - `BetaManagedAgentsEffortMax object`

        Maximum effort. Favors reasoning depth over latency.

        - `type: "max"`

    - `inference_geo: optional string`

      Geographic region for model inference. When unset, requests fall through to the workspace's default_inference_geo.

    - `speed: optional "standard" or "fast"`

      Inference speed mode. `fast` provides significantly faster output token generation at premium pricing. Defaults to `standard`. Not all models support `fast`; invalid combinations are rejected at create time.

      - `"standard"`

      - `"fast"`

  - `multiagent: BetaManagedAgentsMultiagent or null`

    Multiagent orchestration configuration. Null when the agent is single-threaded.

    - `BetaManagedAgentsMultiagentCoordinator object`

      Resolved coordinator topology with a concrete agent roster.

      - `type: "coordinator"`

      - `agents: array of BetaManagedAgentsAgentReference or BetaManagedAgentsAdvisor`

        Agents the coordinator may spawn as session threads, each resolved to a specific version.

        - `BetaManagedAgentsAgentReference object`

          A resolved agent reference with a concrete version.

          - `type: "agent"`

          - `id: string`

          - `version: number`

            format: int32

        - `BetaManagedAgentsAdvisor object`

          Platform advisor roster entry: a model the session's primary thread may consult mid-turn.

          - `type: "advisor"`

          - `model: string`

            The advisor model id.

    - `BetaManagedAgentsMultiagent20261001 object`

      Resolved multiagent configuration with three members, each enabled or disabled on its own.

      - `type: "multiagent_20261001"`

      - `advisor: BetaManagedAgentsMultiagentAdvisor`

        Whether the session's primary thread can consult an advisor model.

        - `BetaManagedAgentsMultiagentAdvisorEnabled object`

          The session's primary thread can consult `model` mid-turn.

          - `type: "enabled"`

          - `model: string`

            The advisor model id.

        - `BetaManagedAgentsMultiagentAdvisorDisabled object`

          The agent has no advisor.

          - `type: "disabled"`

      - `subagents: BetaManagedAgentsMultiagentSubagents`

        Whether the agent can spawn session threads.

        - `BetaManagedAgentsMultiagentSubagentsEnabled object`

          The agent can spawn session threads.

          - `type: "enabled"`

          - `inline_agents: BetaManagedAgentsMultiagentInlineAgents`

            Whether the agent can define inline agents, which are not saved, when it spawns session threads.

            - `BetaManagedAgentsMultiagentInlineAgentsEnabled object`

              The agent can define inline agents.

              - `type: "enabled"`

            - `BetaManagedAgentsMultiagentInlineAgentsDisabled object`

              The agent cannot define inline agents.

              - `type: "disabled"`

          - `predefined_agents: array of BetaManagedAgentsAgentReference`

            Predefined agents, which are saved agents that this agent can spawn as session threads, each resolved to a specific version.

            - `type: "agent"`

            - `id: string`

            - `version: number`

              format: int32

        - `BetaManagedAgentsMultiagentSubagentsDisabled object`

          The agent cannot spawn session threads.

          - `type: "disabled"`

      - `workflows: BetaManagedAgentsMultiagentWorkflows`

        Whether the agent can start workflow runs.

        - `BetaManagedAgentsMultiagentWorkflowsEnabled object`

          The agent can start workflow runs.

          - `type: "enabled"`

          - `inline_agents: BetaManagedAgentsMultiagentInlineAgents`

            Whether a run's plan can define inline agents, which are not saved.

          - `predefined_agents: array of BetaManagedAgentsAgentReference`

            Predefined agents, which are saved agents that a run's plan can use, each resolved to a specific version.

            - `type: "agent"`

            - `id: string`

            - `version: number`

              format: int32

        - `BetaManagedAgentsMultiagentWorkflowsDisabled object`

          The agent cannot start workflow runs.

          - `type: "disabled"`

  - `name: string`

  - `skills: array of BetaManagedAgentsAnthropicSkill or BetaManagedAgentsCustomSkill`

    - `BetaManagedAgentsAnthropicSkill object`

      A resolved Anthropic-managed skill.

      - `type: "anthropic"`

      - `skill_id: string`

      - `version: string`

    - `BetaManagedAgentsCustomSkill object`

      A resolved user-created custom skill.

      - `type: "custom"`

      - `skill_id: string`

      - `version: string`

  - `system: string or null`

  - `tools: array of BetaManagedAgentsAgentToolset20260401 or BetaManagedAgentsMCPToolset or BetaManagedAgentsCustomTool`

    - `BetaManagedAgentsAgentToolset20260401 object`

      - `type: "agent_toolset_20260401"`

      - `configs: array of BetaManagedAgentsAgentToolConfig`

        - `BetaManagedAgentsBashToolConfig object`

          Configuration for the bash tool.

          - `type: "bash"`

          - `enabled: boolean`

          - `name: "bash"`

          - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

            Permission policy for tool execution.

            - `BetaManagedAgentsAlwaysAllowPolicy object`

              Tool calls are automatically approved without user confirmation.

              - `type: "always_allow"`

            - `BetaManagedAgentsAlwaysAskPolicy object`

              Tool calls require user confirmation before execution.

              - `type: "always_ask"`

            - `BetaManagedAgentsAutoPolicy object`

              The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

              - `type: "auto"`

        - `BetaManagedAgentsEditToolConfig object`

          Configuration for the edit tool.

          - `type: "edit"`

          - `enabled: boolean`

          - `name: "edit"`

          - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

            Permission policy for tool execution.

            - `BetaManagedAgentsAlwaysAllowPolicy object`

              Tool calls are automatically approved without user confirmation.

            - `BetaManagedAgentsAlwaysAskPolicy object`

              Tool calls require user confirmation before execution.

            - `BetaManagedAgentsAutoPolicy object`

              The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

        - `BetaManagedAgentsReadToolConfig object`

          Configuration for the read tool.

          - `type: "read"`

          - `enabled: boolean`

          - `name: "read"`

          - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

            Permission policy for tool execution.

            - `BetaManagedAgentsAlwaysAllowPolicy object`

              Tool calls are automatically approved without user confirmation.

            - `BetaManagedAgentsAlwaysAskPolicy object`

              Tool calls require user confirmation before execution.

            - `BetaManagedAgentsAutoPolicy object`

              The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

        - `BetaManagedAgentsWriteToolConfig object`

          Configuration for the write tool.

          - `type: "write"`

          - `enabled: boolean`

          - `name: "write"`

          - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

            Permission policy for tool execution.

            - `BetaManagedAgentsAlwaysAllowPolicy object`

              Tool calls are automatically approved without user confirmation.

            - `BetaManagedAgentsAlwaysAskPolicy object`

              Tool calls require user confirmation before execution.

            - `BetaManagedAgentsAutoPolicy object`

              The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

        - `BetaManagedAgentsGlobToolConfig object`

          Configuration for the glob tool.

          - `type: "glob"`

          - `enabled: boolean`

          - `name: "glob"`

          - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

            Permission policy for tool execution.

            - `BetaManagedAgentsAlwaysAllowPolicy object`

              Tool calls are automatically approved without user confirmation.

            - `BetaManagedAgentsAlwaysAskPolicy object`

              Tool calls require user confirmation before execution.

            - `BetaManagedAgentsAutoPolicy object`

              The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

        - `BetaManagedAgentsGrepToolConfig object`

          Configuration for the grep tool.

          - `type: "grep"`

          - `enabled: boolean`

          - `name: "grep"`

          - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

            Permission policy for tool execution.

            - `BetaManagedAgentsAlwaysAllowPolicy object`

              Tool calls are automatically approved without user confirmation.

            - `BetaManagedAgentsAlwaysAskPolicy object`

              Tool calls require user confirmation before execution.

            - `BetaManagedAgentsAutoPolicy object`

              The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

        - `BetaManagedAgentsWebFetchToolConfig object`

          Configuration for the web_fetch tool.

          - `type: "web_fetch"`

          - `enabled: boolean`

          - `name: "web_fetch"`

          - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

            Permission policy for tool execution.

            - `BetaManagedAgentsAlwaysAllowPolicy object`

              Tool calls are automatically approved without user confirmation.

            - `BetaManagedAgentsAlwaysAskPolicy object`

              Tool calls require user confirmation before execution.

            - `BetaManagedAgentsAutoPolicy object`

              The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

          - `url_sources: BetaManagedAgentsWebFetchURLSources or null`

            Which sources contribute URLs the tool may fetch, always in the object form. Null when not set, which allows every source.

            - `client_tool_results: BetaManagedAgentsWebFetchURLSourceToolFilter or null`

              Which custom tools' results contribute URLs that may be fetched. Null when not set, which allows every custom tool's results.

              - `BetaManagedAgentsWebFetchURLSourceAll object`

                Every URL from this source may be fetched. This is the default.

                - `type: "all"`

              - `BetaManagedAgentsWebFetchURLSourceNone object`

                This source contributes no URLs that may be fetched.

                - `type: "none"`

              - `BetaManagedAgentsWebFetchURLSourceOnly object`

                Only the named tools' results contribute URLs that may be fetched.

                - `type: "only"`

                - `tools: array of BetaManagedAgentsWebFetchURLSourceToolReference`

                  The tools whose results contribute. Between 1 and 128 entries, each with a different name. An empty list is rejected; use "none" to allow no tool's results.

                  - `type: "tool_reference"`

                    Must be "tool_reference".

                  - `name: string`

                    Name of the tool. Compared exactly, so upper and lower case letters are different.

                    minLength: 1, maxLength: 128

              - `BetaManagedAgentsWebFetchURLSourceExcept object`

                Every tool's results contribute URLs that may be fetched, except the named tools' results.

                - `type: "except"`

                - `tools: array of BetaManagedAgentsWebFetchURLSourceToolReference`

                  The tools whose results do not contribute. Between 1 and 128 entries, each with a different name. An empty list is rejected; use "all" to leave out no tool's results.

                  - `type: "tool_reference"`

                    Must be "tool_reference".

                  - `name: string`

                    Name of the tool. Compared exactly, so upper and lower case letters are different.

                    minLength: 1, maxLength: 128

            - `server_tool_results: BetaManagedAgentsWebFetchURLSourceToolFilter or null`

              Which of the web_search and web_fetch tools' results contribute URLs that may be fetched. Null when not set, which allows both.

            - `user_input: BetaManagedAgentsWebFetchURLSourceUserInput or null`

              Whether URLs in the text of user messages may be fetched. Null when not set, which allows them.

              - `BetaManagedAgentsWebFetchURLSourceAll object`

                Every URL from this source may be fetched. This is the default.

              - `BetaManagedAgentsWebFetchURLSourceNone object`

                This source contributes no URLs that may be fetched.

          - `allowed_domains: optional array of string`

          - `blocked_domains: optional array of string`

          - `max_content_tokens: optional number or null`

            format: int32

        - `BetaManagedAgentsWebSearchToolConfig object`

          Configuration for the web_search tool.

          - `type: "web_search"`

          - `enabled: boolean`

          - `name: "web_search"`

          - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

            Permission policy for tool execution.

            - `BetaManagedAgentsAlwaysAllowPolicy object`

              Tool calls are automatically approved without user confirmation.

            - `BetaManagedAgentsAlwaysAskPolicy object`

              Tool calls require user confirmation before execution.

            - `BetaManagedAgentsAutoPolicy object`

              The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

          - `allowed_domains: optional array of string`

          - `blocked_domains: optional array of string`

          - `user_location: optional BetaManagedAgentsUserLocation or null`

            Approximate user location for search result localization.

            - `type: "approximate"`

              Location precision. Only "approximate" is supported.

            - `city: optional string or null`

              City name.

              minLength: 1, maxLength: 255

            - `country: optional string or null`

              Two-letter ISO 3166-1 country code, uppercase.

            - `region: optional string or null`

              Region or state name.

              minLength: 1, maxLength: 255

            - `timezone: optional string or null`

              IANA timezone identifier, e.g. "America/Los_Angeles".

              minLength: 1, maxLength: 255

      - `default_config: BetaManagedAgentsAgentToolsetDefaultConfig`

        Resolved default configuration for agent tools.

        - `enabled: boolean`

        - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

          Permission policy for tool execution.

          - `BetaManagedAgentsAlwaysAllowPolicy object`

            Tool calls are automatically approved without user confirmation.

          - `BetaManagedAgentsAlwaysAskPolicy object`

            Tool calls require user confirmation before execution.

          - `BetaManagedAgentsAutoPolicy object`

            The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

    - `BetaManagedAgentsMCPToolset object`

      - `type: "mcp_toolset"`

      - `configs: array of BetaManagedAgentsMCPToolConfig`

        - `enabled: boolean`

        - `name: string`

        - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

          Permission policy for tool execution.

          - `BetaManagedAgentsAlwaysAllowPolicy object`

            Tool calls are automatically approved without user confirmation.

          - `BetaManagedAgentsAlwaysAskPolicy object`

            Tool calls require user confirmation before execution.

          - `BetaManagedAgentsAutoPolicy object`

            The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

      - `default_config: BetaManagedAgentsMCPToolsetDefaultConfig`

        Resolved default configuration for all tools from an MCP server.

        - `enabled: boolean`

        - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

          Permission policy for tool execution.

          - `BetaManagedAgentsAlwaysAllowPolicy object`

            Tool calls are automatically approved without user confirmation.

          - `BetaManagedAgentsAlwaysAskPolicy object`

            Tool calls require user confirmation before execution.

          - `BetaManagedAgentsAutoPolicy object`

            The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

      - `mcp_server_name: string`

    - `BetaManagedAgentsCustomTool object`

      A custom tool as returned in API responses.

      - `type: "custom"`

      - `description: string`

      - `input_schema: BetaManagedAgentsCustomToolInputSchema`

        JSON Schema for custom tool input parameters.

        - `type: "object"`

        - `properties: optional map[unknown] or null`

        - `required: optional array of string or null`

      - `name: string`

  - `updated_at: string`

    A timestamp in RFC 3339 format

    format: date-time

  - `version: number`

    The agent's current version. Starts at 1 and increments when the agent is modified.

    format: int32

- `next_page: optional string or null`

  Opaque cursor for the next page. Null when no more results.

## Example

```bash
curl https://api.anthropic.com/v1/agents/$AGENT_ID/versions \
    -H 'anthropic-version: 2023-06-01' \
    -H 'anthropic-beta: managed-agents-2026-04-01' \
    -H "X-Api-Key: $ANTHROPIC_API_KEY"
```

### Response (200)

```json
{
  "data": [
    {
      "id": "agent_011CZkYpogX7uDKUyvBTophP",
      "archived_at": null,
      "created_at": "2026-03-15T10:00:00Z",
      "description": "A general-purpose starter agent.",
      "mcp_servers": [
        {
          "name": "example-mcp",
          "type": "url",
          "url": "https://example-server.modelcontextprotocol.io/sse"
        }
      ],
      "metadata": {
        "foo": "bar"
      },
      "model": {
        "id": "claude-opus-5-5",
        "effort": {
          "type": "low"
        },
        "inference_geo": "inference_geo",
        "speed": "standard"
      },
      "multiagent": {
        "advisor": {
          "type": "disabled"
        },
        "subagents": {
          "inline_agents": {
            "type": "enabled"
          },
          "predefined_agents": [
            {
              "id": "agent_011CZkYqphY8vELVzwCUpqiQ",
              "type": "agent",
              "version": 1
            }
          ],
          "type": "enabled"
        },
        "type": "multiagent_20261001",
        "workflows": {
          "inline_agents": {
            "type": "enabled"
          },
          "predefined_agents": [
            {
              "id": "agent_011CZkYqphY8vELVzwCUpqiQ",
              "type": "agent",
              "version": 1
            }
          ],
          "type": "enabled"
        }
      },
      "name": "My First Agent",
      "skills": [
        {
          "skill_id": "xlsx",
          "type": "anthropic",
          "version": "1"
        },
        {
          "skill_id": "skill_011CZkZFNu9hAbo3jZPRgTmx",
          "type": "custom",
          "version": "2"
        }
      ],
      "system": "You are a general-purpose agent that can research, write code, run commands, and use connected tools to complete the user's task end to end.",
      "tools": [
        {
          "configs": [
            {
              "enabled": true,
              "name": "bash",
              "permission_policy": {
                "type": "always_allow"
              },
              "type": "bash"
            }
          ],
          "default_config": {
            "enabled": true,
            "permission_policy": {
              "type": "always_ask"
            }
          },
          "type": "agent_toolset_20260401"
        }
      ],
      "type": "agent",
      "updated_at": "2026-03-15T10:00:00Z",
      "version": 1
    }
  ],
  "next_page": "next_page"
}
```
