---
title: Create Agent
url: https://platform.claude.com/docs/en/api/beta/agents/create
---

# Create Agent

**POST** `/v1/agents`

Create Agent

## Headers

- `"anthropic-version": optional string`

- `"anthropic-beta": optional array of AnthropicBeta`

  Optional header to specify the beta version(s) you want to use. (전체 enum 목록 생략 — Managed Agents는 `managed-agents-2026-04-01`, Dreams는 `dreaming-2026-04-21`, Tunnels는 `mcp-tunnels-2026-06-22`)

- `"anthropic-workspace-id": optional string`

  Optional header to select the Workspace for this request. The value is a Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).

  Only needed for credentials that can act on more than one Workspace. A credential that belongs to a specific Workspace may omit it; if sent, it must match that Workspace.

## Body parameters

- `model: BetaManagedAgentsModel or BetaManagedAgentsModelConfigParams`

  Model identifier. Accepts the [model string](https://platform.claude.com/docs/en/about-claude/models/overview?sdk_languages=http#latest-models-comparison), e.g. `claude-opus-5-5`, or a `model_config` object for additional configuration control

  - `BetaManagedAgentsModel = "claude-haiku-5-5" or "claude-sonnet-5-5" or "claude-opus-5-5" or 14 more or string`

    The model that will power your agent.

    See [models](https://docs.anthropic.com/en/docs/models-overview) for additional details and options.

    - `"claude-haiku-5-5"`

      Fastest model for high-volume, real-time tasks

    - `"claude-sonnet-5-5"`

      Efficient model for coding and agents

    - `"claude-opus-5-5"`

      Powerful intelligence for coding, knowledge work, and long-running agents

    - `"claude-fable-5-1"`

      Frontier intelligence for ambitious tasks across coding, scientific discovery, and enterprise workflows

    - `"claude-sonnet-5"`

      Efficient model for coding and agents

    - `"claude-fable-5"`

      Next generation of intelligence for the hardest knowledge work and coding problems

    - `"claude-opus-5"`

      Powerful intelligence for long-running agents and coding

    - `"claude-opus-4-8"`

      Powerful intelligence for long-running agents and coding

    - `"claude-opus-4-7"`

      Powerful intelligence for long-running agents and coding

    - `"claude-opus-4-6"`

      Powerful intelligence for long-running agents and coding

    - `"claude-sonnet-4-6"`

      Best combination of speed and intelligence

    - `"claude-haiku-4-5"`

    - `"claude-haiku-4-5-20251001"`

    - `"claude-opus-4-5"`

      Powerful intelligence for long-running agents and coding

    - `"claude-opus-4-5-20251101"`

      Powerful intelligence for long-running agents and coding

    - `"claude-sonnet-4-5"`

      **Deprecated**: Will reach end-of-life on November 30, 2026. Please migrate to claude-sonnet-5-5. Visit https://docs.anthropic.com/en/docs/resources/model-deprecations for more information.

      High-performance model for agents and coding

    - `"claude-sonnet-4-5-20250929"`

      **Deprecated**: Will reach end-of-life on November 30, 2026. Please migrate to claude-sonnet-5-5. Visit https://docs.anthropic.com/en/docs/resources/model-deprecations for more information.

      High-performance model for agents and coding

    - `string`

  - `BetaManagedAgentsModelConfigParams object`

    An object that defines additional configuration control over model use

    - `id: BetaManagedAgentsModel`

      The model that will power your agent.

      See [models](https://docs.anthropic.com/en/docs/models-overview) for additional details and options.

    - `effort: optional "low" or "medium" or "high" or 2 more or BetaManagedAgentsEffortLow or BetaManagedAgentsEffortMedium or 3 more or null`

      How hard Claude works on each inference call. Accepts a bare level string (`"high"`) or `{"type": "high"}`. On create, omitting it resolves the per-model default; on update, omitting it leaves the stored value unchanged.

      - `"low"`

        Low effort. Favors latency over reasoning depth.

      - `"medium"`

        Medium effort. Balances latency and reasoning depth.

      - `"high"`

        High effort. Favors reasoning depth.

      - `"xhigh"`

        Extra-high effort. Not all models accept this level.

      - `"max"`

        Maximum effort. Favors reasoning depth over latency.

      - `BetaManagedAgentsEffortLow object`

        Low effort. Favors latency over reasoning depth.

        - `type: "low"`

      - `BetaManagedAgentsEffortMedium object`

        Medium effort. Balances latency and reasoning depth.

        - `type: "medium"`

      - `BetaManagedAgentsEffortHigh object`

        High effort. Favors reasoning depth.

        - `type: "high"`

      - `BetaManagedAgentsEffortXhigh object`

        Extra-high effort. Not all models accept this level.

        - `type: "xhigh"`

      - `BetaManagedAgentsEffortMax object`

        Maximum effort. Favors reasoning depth over latency.

        - `type: "max"`

    - `inference_geo: optional string or null`

      Geographic region for model inference. When unset, requests fall through to the workspace's default_inference_geo. On update, `model` is whole-object replacement — omitting inference_geo clears it.

    - `speed: optional "standard" or "fast" or null`

      Inference speed mode. Defaults to `standard`.

      - `"standard"`

      - `"fast"`

- `name: string`

  Human-readable name for the agent.

  minLength: 1, maxLength: 256

- `description: optional string or null`

  Description of what the agent does.

  maxLength: 2048

- `mcp_servers: optional array of BetaManagedAgentsURLMCPServerParams`

  MCP servers this agent connects to. Maximum 20. Names must be unique within the array. Every server must be referenced by an `mcp_toolset` in `tools`; unreferenced servers are rejected. See the [MCP connector guide](https://platform.claude.com/docs/en/managed-agents/mcp-connector?sdk_languages=http).

  - `type: "url"`

  - `name: string`

    Unique name for this server, referenced by mcp_toolset configurations. 1-255 characters.

    minLength: 1, maxLength: 255

  - `url: string`

    Endpoint URL for the MCP server.

    maxLength: 2048

- `metadata: optional map[string]`

  Arbitrary key-value metadata. Maximum 16 pairs, keys up to 64 chars, values up to 512 chars.

- `multiagent: optional BetaManagedAgentsMultiagentParams or null`

  Multiagent orchestration configuration.

  - `BetaManagedAgentsMultiagentCoordinatorParams object`

    A coordinator topology: the session's primary thread orchestrates work by spawning session threads, each running an agent drawn from the `agents` roster.

    - `type: "coordinator"`

    - `agents: array of BetaManagedAgentsMultiagentRosterEntryParams`

      Agents the coordinator may spawn as session threads. 1–20 entries. Each entry is an agent ID string, a versioned `{"type":"agent","id","version"}` reference, or `{"type":"self"}` to allow recursive self-invocation. Entries must reference distinct agents (after resolving `self` and string forms); at most one `self`. Referenced agents must exist, must not be archived, and must not themselves have `multiagent` set (depth limit 1).

      - `string`

      - `BetaManagedAgentsAgentParams object`

        Specification for an Agent. Provide a specific `version` or use the short-form `agent="agent_id"` for the most recent version

        - `type: "agent"`

        - `id: string`

          The `agent` ID.

          minLength: 1, maxLength: 128

        - `version: optional number`

          The specific `agent` version to use. Omit to use the latest version. Must be at least 1 if specified.

          format: int32

      - `BetaManagedAgentsMultiagentSelfParams object`

        Sentinel roster entry meaning "the agent that owns this configuration". Resolved server-side to a concrete agent reference.

        - `type: "self"`

      - `BetaManagedAgentsAdvisorParams object`

        Platform advisor roster entry: a model the session's primary thread may consult mid-turn. At most one per roster; the entry occupies the roster name `anthropic.advisor`.

        - `type: "advisor"`

        - `model: string`

          A Claude model id. The model must be permitted as an advisor for this agent's model.

          minLength: 1, maxLength: 256

  - `BetaManagedAgentsMultiagent20261001Params object`

    Multiagent configuration with three members, each enabled or disabled on its own. On an update, if the agent's stored `multiagent` also has type `multiagent_20261001`, this configuration is merged into the stored one, level by level, instead of replacing it. A key that the update omits keeps its stored value. A key sent as null takes its default, on create as well, so `"workflows": null` enables workflows. An object sent with a `type` other than the stored one replaces the stored object, and the keys that it omits take their defaults. A `predefined_agents` list that is sent replaces the stored list. Every object that is sent needs its `type`, and an enabled `advisor` needs its `model`. Other validation applies to the merged result.

    - `type: "multiagent_20261001"`

    - `advisor: optional BetaManagedAgentsMultiagentAdvisorParams or null`

      Whether the session's primary thread can consult an advisor model. Defaults to disabled.

      - `BetaManagedAgentsMultiagentAdvisorEnabledParams object`

        The session's primary thread can consult `model` mid-turn.

        - `type: "enabled"`

        - `model: string`

          A Claude model id. The model must be permitted as an advisor for this agent's model.

          minLength: 1, maxLength: 256

      - `BetaManagedAgentsMultiagentAdvisorDisabledParams object`

        The agent has no advisor.

        - `type: "disabled"`

    - `subagents: optional BetaManagedAgentsMultiagentSubagentsParams or null`

      Whether the agent can spawn session threads. Defaults to enabled.

      - `BetaManagedAgentsMultiagentSubagentsEnabledParams object`

        The agent can spawn session threads. Each thread runs a predefined agent, which is a saved agent in `predefined_agents`, or an inline agent, which the agent defines when it spawns the thread and which is not saved. If `inline_agents` is disabled, `predefined_agents` must name at least one agent.

        - `type: "enabled"`

        - `inline_agents: optional BetaManagedAgentsMultiagentInlineAgentsParams or null`

          Whether the agent can define inline agents when it spawns session threads. Defaults to enabled.

          - `BetaManagedAgentsMultiagentInlineAgentsEnabledParams object`

            The agent can define inline agents.

            - `type: "enabled"`

          - `BetaManagedAgentsMultiagentInlineAgentsDisabledParams object`

            The agent cannot define inline agents.

            - `type: "disabled"`

        - `predefined_agents: optional array of BetaManagedAgentsMultiagentPredefinedAgentParams or null`

          Predefined agents that this agent can spawn as session threads. At most 20. Defaults to null. Null and an empty list both mean no predefined agents. This list is separate from `workflows.predefined_agents`, and an agent in one list is not added to the other.

          - `string`

          - `BetaManagedAgentsAgentParams object`

            Specification for an Agent. Provide a specific `version` or use the short-form `agent="agent_id"` for the most recent version

          - `BetaManagedAgentsMultiagentSelfParams object`

            Sentinel roster entry meaning "the agent that owns this configuration". Resolved server-side to a concrete agent reference.

      - `BetaManagedAgentsMultiagentSubagentsDisabledParams object`

        The agent cannot spawn session threads.

        - `type: "disabled"`

    - `workflows: optional BetaManagedAgentsMultiagentWorkflowsParams or null`

      Whether the agent can start workflow runs. Defaults to enabled.

      - `BetaManagedAgentsMultiagentWorkflowsEnabledParams object`

        The agent can start workflow runs. Each run follows a plan, a program that the agent writes. A plan can use predefined agents, which are the saved agents in `predefined_agents`, and inline agents, which it defines itself and which are not saved. If `inline_agents` is disabled, `predefined_agents` must name at least one agent.

        - `type: "enabled"`

        - `inline_agents: optional BetaManagedAgentsMultiagentInlineAgentsParams or null`

          Whether a run's plan can define inline agents. Defaults to enabled.

        - `predefined_agents: optional array of BetaManagedAgentsMultiagentPredefinedAgentParams or null`

          Predefined agents that a run's plan can use. At most 20. Defaults to null. Null and an empty list both mean no predefined agents. This list is separate from `subagents.predefined_agents`, and an agent in one list is not added to the other.

          - `string`

          - `BetaManagedAgentsAgentParams object`

            Specification for an Agent. Provide a specific `version` or use the short-form `agent="agent_id"` for the most recent version

          - `BetaManagedAgentsMultiagentSelfParams object`

            Sentinel roster entry meaning "the agent that owns this configuration". Resolved server-side to a concrete agent reference.

      - `BetaManagedAgentsMultiagentWorkflowsDisabledParams object`

        The agent cannot start workflow runs.

        - `type: "disabled"`

- `skills: optional array of BetaManagedAgentsSkillParams`

  Skills available to the agent.

  - `BetaManagedAgentsAnthropicSkillParams object`

    An Anthropic-managed skill.

    - `type: "anthropic"`

    - `skill_id: string`

      Identifier of the Anthropic skill (e.g., "xlsx").

      minLength: 1, maxLength: 64

    - `version: optional string or null`

      Version to pin. Defaults to latest if omitted.

      minLength: 1, maxLength: 64

  - `BetaManagedAgentsCustomSkillParams object`

    A user-created custom skill.

    - `type: "custom"`

    - `skill_id: string`

      Tagged ID of the custom skill (e.g., "skill_01XJ5...").

      minLength: 1, maxLength: 64

    - `version: optional string or null`

      Version to pin. Defaults to latest if omitted.

      minLength: 1, maxLength: 64

- `system: optional string or null`

  System prompt for the agent.

  maxLength: 100000

- `tools: optional array of BetaManagedAgentsAgentToolset20260401Params or BetaManagedAgentsMCPToolsetParams or BetaManagedAgentsCustomToolParams`

  Tool configurations available to the agent. Maximum of 256 tools across all toolsets allowed.

  - `BetaManagedAgentsAgentToolset20260401Params object`

    Configuration for built-in agent tools. Use this to enable or disable groups of tools available to the agent.

    - `type: "agent_toolset_20260401"`

    - `configs: optional array of BetaManagedAgentsAgentToolConfigParams`

      Per-tool configuration overrides.

      - `BetaManagedAgentsBashToolConfigParams object`

        Configuration override for the bash tool.

        - `type: optional "bash"`

        - `name: "bash"`

          Must be "bash".

        - `enabled: optional boolean or null`

          Whether this tool is enabled and available to Claude. Overrides the default_config setting.

        - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

          Permission policy for this tool. Controls whether tool calls are auto-approved or require confirmation.

          - `BetaManagedAgentsAlwaysAllowPolicy object`

            Tool calls are automatically approved without user confirmation.

            - `type: "always_allow"`

          - `BetaManagedAgentsAlwaysAskPolicy object`

            Tool calls require user confirmation before execution.

            - `type: "always_ask"`

          - `BetaManagedAgentsAutoPolicy object`

            The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

            - `type: "auto"`

      - `BetaManagedAgentsEditToolConfigParams object`

        Configuration override for the edit tool.

        - `type: optional "edit"`

        - `name: "edit"`

          Must be "edit".

        - `enabled: optional boolean or null`

          Whether this tool is enabled and available to Claude. Overrides the default_config setting.

        - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

          Permission policy for this tool. Controls whether tool calls are auto-approved or require confirmation.

          - `BetaManagedAgentsAlwaysAllowPolicy object`

            Tool calls are automatically approved without user confirmation.

          - `BetaManagedAgentsAlwaysAskPolicy object`

            Tool calls require user confirmation before execution.

          - `BetaManagedAgentsAutoPolicy object`

            The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

      - `BetaManagedAgentsReadToolConfigParams object`

        Configuration override for the read tool.

        - `type: optional "read"`

        - `name: "read"`

          Must be "read".

        - `enabled: optional boolean or null`

          Whether this tool is enabled and available to Claude. Overrides the default_config setting.

        - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

          Permission policy for this tool. Controls whether tool calls are auto-approved or require confirmation.

          - `BetaManagedAgentsAlwaysAllowPolicy object`

            Tool calls are automatically approved without user confirmation.

          - `BetaManagedAgentsAlwaysAskPolicy object`

            Tool calls require user confirmation before execution.

          - `BetaManagedAgentsAutoPolicy object`

            The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

      - `BetaManagedAgentsWriteToolConfigParams object`

        Configuration override for the write tool.

        - `type: optional "write"`

        - `name: "write"`

          Must be "write".

        - `enabled: optional boolean or null`

          Whether this tool is enabled and available to Claude. Overrides the default_config setting.

        - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

          Permission policy for this tool. Controls whether tool calls are auto-approved or require confirmation.

          - `BetaManagedAgentsAlwaysAllowPolicy object`

            Tool calls are automatically approved without user confirmation.

          - `BetaManagedAgentsAlwaysAskPolicy object`

            Tool calls require user confirmation before execution.

          - `BetaManagedAgentsAutoPolicy object`

            The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

      - `BetaManagedAgentsGlobToolConfigParams object`

        Configuration override for the glob tool.

        - `type: optional "glob"`

        - `name: "glob"`

          Must be "glob".

        - `enabled: optional boolean or null`

          Whether this tool is enabled and available to Claude. Overrides the default_config setting.

        - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

          Permission policy for this tool. Controls whether tool calls are auto-approved or require confirmation.

          - `BetaManagedAgentsAlwaysAllowPolicy object`

            Tool calls are automatically approved without user confirmation.

          - `BetaManagedAgentsAlwaysAskPolicy object`

            Tool calls require user confirmation before execution.

          - `BetaManagedAgentsAutoPolicy object`

            The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

      - `BetaManagedAgentsGrepToolConfigParams object`

        Configuration override for the grep tool.

        - `type: optional "grep"`

        - `name: "grep"`

          Must be "grep".

        - `enabled: optional boolean or null`

          Whether this tool is enabled and available to Claude. Overrides the default_config setting.

        - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

          Permission policy for this tool. Controls whether tool calls are auto-approved or require confirmation.

          - `BetaManagedAgentsAlwaysAllowPolicy object`

            Tool calls are automatically approved without user confirmation.

          - `BetaManagedAgentsAlwaysAskPolicy object`

            Tool calls require user confirmation before execution.

          - `BetaManagedAgentsAutoPolicy object`

            The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

      - `BetaManagedAgentsWebFetchToolConfigParams object`

        Configuration override for the web_fetch tool.

        - `type: optional "web_fetch"`

        - `name: "web_fetch"`

          Must be "web_fetch".

        - `allowed_domains: optional array of string`

          Only fetch URLs whose host is one of these domains or a subdomain of one. Each entry is a plain hostname like "docs.example.com" (no scheme, port, or path). At most 64 entries; an empty list is rejected (omit the field instead). Cannot be combined with blocked_domains.

        - `blocked_domains: optional array of string`

          Never fetch URLs whose host is one of these domains or a subdomain of one. Each entry is a plain hostname like "ads.example.com" (no scheme, port, or path). At most 64 entries; an empty list is rejected (omit the field instead). Cannot be combined with allowed_domains.

        - `enabled: optional boolean or null`

          Whether this tool is enabled and available to Claude. Overrides the default_config setting.

        - `max_content_tokens: optional number or null`

          Maximum number of tokens of fetched text content to include in context per call. Does not apply to binary content such as PDFs.

          format: int32

        - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

          Permission policy for this tool. Controls whether tool calls are auto-approved or require confirmation.

          - `BetaManagedAgentsAlwaysAllowPolicy object`

            Tool calls are automatically approved without user confirmation.

          - `BetaManagedAgentsAlwaysAskPolicy object`

            Tool calls require user confirmation before execution.

          - `BetaManagedAgentsAutoPolicy object`

            The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

        - `url_sources: optional BetaManagedAgentsWebFetchURLSourcesParams or null`

          Which sources contribute URLs the tool may fetch. Omit to allow every source.

          - `client_tool_results: optional BetaManagedAgentsWebFetchURLSourceToolFilterParams or null`

            Which custom tools' results contribute URLs that may be fetched: "all" (the default), "none", or an only or except list. Each name in a list must be a custom tool in the same tools array.

            - `BetaManagedAgentsWebFetchURLSourceShorthand = "all" or "none"`

              String form of a url_sources value that has no field other than its type: "all" means {"type": "all"} and "none" means {"type": "none"}.

              - `"all"`

              - `"none"`

            - `BetaManagedAgentsWebFetchURLSourceToolFilter = BetaManagedAgentsWebFetchURLSourceAll or BetaManagedAgentsWebFetchURLSourceNone or BetaManagedAgentsWebFetchURLSourceOnly or BetaManagedAgentsWebFetchURLSourceExcept`

              Which tools' results contribute URLs that may be fetched.

              - `BetaManagedAgentsWebFetchURLSourceAll object`

                Every URL from this source may be fetched. This is the default.

                - `type: "all"`

              - `BetaManagedAgentsWebFetchURLSourceNone object`

                This source contributes no URLs that may be fetched.

                - `type: "none"`

              - `BetaManagedAgentsWebFetchURLSourceOnly object`

                Only the named tools' results contribute URLs that may be fetched.

                - `type: "only"`

                - `tools: array of BetaManagedAgentsWebFetchURLSourceToolReference`

                  The tools whose results contribute. Between 1 and 128 entries, each with a different name. An empty list is rejected; use "none" to allow no tool's results.

                  - `type: "tool_reference"`

                    Must be "tool_reference".

                  - `name: string`

                    Name of the tool. Compared exactly, so upper and lower case letters are different.

                    minLength: 1, maxLength: 128

              - `BetaManagedAgentsWebFetchURLSourceExcept object`

                Every tool's results contribute URLs that may be fetched, except the named tools' results.

                - `type: "except"`

                - `tools: array of BetaManagedAgentsWebFetchURLSourceToolReference`

                  The tools whose results do not contribute. Between 1 and 128 entries, each with a different name. An empty list is rejected; use "all" to leave out no tool's results.

                  - `type: "tool_reference"`

                    Must be "tool_reference".

                  - `name: string`

                    Name of the tool. Compared exactly, so upper and lower case letters are different.

                    minLength: 1, maxLength: 128

          - `server_tool_results: optional BetaManagedAgentsWebFetchURLSourceToolFilterParams or null`

            Which of the web_search and web_fetch tools' results contribute URLs that may be fetched: "all" (the default), "none", or an only or except list. Each name in a list must be "web_search" or "web_fetch".

          - `user_input: optional BetaManagedAgentsWebFetchURLSourceUserInputParams or null`

            Whether URLs in the text of user messages may be fetched: "all" (the default) or "none".

            - `BetaManagedAgentsWebFetchURLSourceShorthand = "all" or "none"`

              String form of a url_sources value that has no field other than its type: "all" means {"type": "all"} and "none" means {"type": "none"}.

            - `BetaManagedAgentsWebFetchURLSourceUserInput = BetaManagedAgentsWebFetchURLSourceAll or BetaManagedAgentsWebFetchURLSourceNone`

              Whether URLs in the text of user messages may be fetched.

              - `BetaManagedAgentsWebFetchURLSourceAll object`

                Every URL from this source may be fetched. This is the default.

              - `BetaManagedAgentsWebFetchURLSourceNone object`

                This source contributes no URLs that may be fetched.

      - `BetaManagedAgentsWebSearchToolConfigParams object`

        Configuration override for the web_search tool.

        - `type: optional "web_search"`

        - `name: "web_search"`

          Must be "web_search".

        - `allowed_domains: optional array of string`

          Only return search results whose host is one of these domains or a subdomain of one. Each entry is a plain hostname like "docs.example.com" (no scheme or port; an optional path suffix is accepted). At most 64 entries; an empty list is rejected (omit the field instead). Cannot be combined with blocked_domains.

        - `blocked_domains: optional array of string`

          Never return search results whose host is one of these domains or a subdomain of one. Each entry is a plain hostname like "ads.example.com" (no scheme or port; an optional path suffix is accepted). At most 64 entries; an empty list is rejected (omit the field instead). Cannot be combined with allowed_domains.

        - `enabled: optional boolean or null`

          Whether this tool is enabled and available to Claude. Overrides the default_config setting.

        - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

          Permission policy for this tool. Controls whether tool calls are auto-approved or require confirmation.

          - `BetaManagedAgentsAlwaysAllowPolicy object`

            Tool calls are automatically approved without user confirmation.

          - `BetaManagedAgentsAlwaysAskPolicy object`

            Tool calls require user confirmation before execution.

          - `BetaManagedAgentsAutoPolicy object`

            The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

        - `user_location: optional BetaManagedAgentsUserLocation or null`

          Approximate user location for search result localization.

          - `type: "approximate"`

            Location precision. Only "approximate" is supported.

          - `city: optional string or null`

            City name.

            minLength: 1, maxLength: 255

          - `country: optional string or null`

            Two-letter ISO 3166-1 country code, uppercase.

          - `region: optional string or null`

            Region or state name.

            minLength: 1, maxLength: 255

          - `timezone: optional string or null`

            IANA timezone identifier, e.g. "America/Los_Angeles".

            minLength: 1, maxLength: 255

    - `default_config: optional BetaManagedAgentsAgentToolsetDefaultConfigParams or null`

      Default configuration applied to all tools in this set.

      - `enabled: optional boolean or null`

        Whether tools are enabled and available to Claude by default. Defaults to true if not specified.

      - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

        Default permission policy for tools. Controls whether tool calls are auto-approved or require confirmation.

        - `BetaManagedAgentsAlwaysAllowPolicy object`

          Tool calls are automatically approved without user confirmation.

        - `BetaManagedAgentsAlwaysAskPolicy object`

          Tool calls require user confirmation before execution.

        - `BetaManagedAgentsAutoPolicy object`

          The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

  - `BetaManagedAgentsMCPToolsetParams object`

    Configuration for tools from an MCP server defined in `mcp_servers`.

    - `type: "mcp_toolset"`

    - `mcp_server_name: string`

      Name of the MCP server. Must match a server name from the mcp_servers array. 1-255 characters.

      minLength: 1, maxLength: 255

    - `configs: optional array of BetaManagedAgentsMCPToolConfigParams`

      Per-tool configuration overrides.

      - `name: string`

        Name of the MCP tool to configure. 1-128 characters.

        minLength: 1, maxLength: 128

      - `enabled: optional boolean or null`

        Whether this tool is enabled. Overrides the `default_config` setting.

      - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

        Permission policy for this tool. Overrides the `default_config` setting.

        - `BetaManagedAgentsAlwaysAllowPolicy object`

          Tool calls are automatically approved without user confirmation.

        - `BetaManagedAgentsAlwaysAskPolicy object`

          Tool calls require user confirmation before execution.

        - `BetaManagedAgentsAutoPolicy object`

          The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

    - `default_config: optional BetaManagedAgentsMCPToolsetDefaultConfigParams or null`

      Default configuration for all tools from this server.

      - `enabled: optional boolean or null`

        Whether tools are enabled by default. Defaults to true if not specified.

      - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

        Default permission policy for tools from this server.

        - `BetaManagedAgentsAlwaysAllowPolicy object`

          Tool calls are automatically approved without user confirmation.

        - `BetaManagedAgentsAlwaysAskPolicy object`

          Tool calls require user confirmation before execution.

        - `BetaManagedAgentsAutoPolicy object`

          The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

  - `BetaManagedAgentsCustomToolParams object`

    A custom tool that is executed by the API client rather than the agent. When the agent calls this tool, an `agent.custom_tool_use` event is emitted and the session goes idle, waiting for the client to provide the result via a `user.custom_tool_result` event.

    - `type: "custom"`

    - `description: string`

      Description of what the tool does, shown to the agent to help it decide when to use the tool.

      minLength: 1

    - `input_schema: BetaManagedAgentsCustomToolInputSchema`

      JSON Schema defining the expected input parameters for the tool.

      - `type: "object"`

      - `properties: optional map[unknown] or null`

      - `required: optional array of string or null`

    - `name: string`

      Unique name for the tool. 1-128 characters; letters, digits, underscores, and hyphens.

      minLength: 1, maxLength: 128

## Returns

- `BetaManagedAgentsAgent object`

  A Managed Agents `agent`.

  - `type: "agent"`

  - `id: string`

  - `archived_at: string or null`

    When the agent was archived. Null if not archived.

    format: date-time

  - `created_at: string`

    A timestamp in RFC 3339 format

    format: date-time

  - `description: string or null`

  - `mcp_servers: array of BetaManagedAgentsMCPServerURLDefinition`

    - `type: "url"`

    - `name: string`

    - `url: string`

  - `metadata: map[string]`

  - `model: BetaManagedAgentsModelConfig`

    Model identifier and configuration.

    - `id: BetaManagedAgentsModel`

      The model that will power your agent.

      See [models](https://docs.anthropic.com/en/docs/models-overview) for additional details and options.

      - `"claude-haiku-5-5"`

        Fastest model for high-volume, real-time tasks

      - `"claude-sonnet-5-5"`

        Efficient model for coding and agents

      - `"claude-opus-5-5"`

        Powerful intelligence for coding, knowledge work, and long-running agents

      - `"claude-fable-5-1"`

        Frontier intelligence for ambitious tasks across coding, scientific discovery, and enterprise workflows

      - `"claude-sonnet-5"`

        Efficient model for coding and agents

      - `"claude-fable-5"`

        Next generation of intelligence for the hardest knowledge work and coding problems

      - `"claude-opus-5"`

        Powerful intelligence for long-running agents and coding

      - `"claude-opus-4-8"`

        Powerful intelligence for long-running agents and coding

      - `"claude-opus-4-7"`

        Powerful intelligence for long-running agents and coding

      - `"claude-opus-4-6"`

        Powerful intelligence for long-running agents and coding

      - `"claude-sonnet-4-6"`

        Best combination of speed and intelligence

      - `"claude-haiku-4-5"`

      - `"claude-haiku-4-5-20251001"`

      - `"claude-opus-4-5"`

        Powerful intelligence for long-running agents and coding

      - `"claude-opus-4-5-20251101"`

        Powerful intelligence for long-running agents and coding

      - `"claude-sonnet-4-5"`

        **Deprecated**: Will reach end-of-life on November 30, 2026. Please migrate to claude-sonnet-5-5. Visit https://docs.anthropic.com/en/docs/resources/model-deprecations for more information.

        High-performance model for agents and coding

      - `"claude-sonnet-4-5-20250929"`

        **Deprecated**: Will reach end-of-life on November 30, 2026. Please migrate to claude-sonnet-5-5. Visit https://docs.anthropic.com/en/docs/resources/model-deprecations for more information.

        High-performance model for agents and coding

      - `string`

    - `effort: optional BetaManagedAgentsEffortLow or BetaManagedAgentsEffortMedium or BetaManagedAgentsEffortHigh or 2 more`

      How hard Claude works on each inference call. One of `low`, `medium`, `high`, `xhigh`, `max`. Always present; resolved to the per-model default at save time when not supplied.

      - `BetaManagedAgentsEffortLow object`

        Low effort. Favors latency over reasoning depth.

        - `type: "low"`

      - `BetaManagedAgentsEffortMedium object`

        Medium effort. Balances latency and reasoning depth.

        - `type: "medium"`

      - `BetaManagedAgentsEffortHigh object`

        High effort. Favors reasoning depth.

        - `type: "high"`

      - `BetaManagedAgentsEffortXhigh object`

        Extra-high effort. Not all models accept this level.

        - `type: "xhigh"`

      - `BetaManagedAgentsEffortMax object`

        Maximum effort. Favors reasoning depth over latency.

        - `type: "max"`

    - `inference_geo: optional string`

      Geographic region for model inference. When unset, requests fall through to the workspace's default_inference_geo.

    - `speed: optional "standard" or "fast"`

      Inference speed mode. `fast` provides significantly faster output token generation at premium pricing. Defaults to `standard`. Not all models support `fast`; invalid combinations are rejected at create time.

      - `"standard"`

      - `"fast"`

  - `multiagent: BetaManagedAgentsMultiagent or null`

    Multiagent orchestration configuration. Null when the agent is single-threaded.

    - `BetaManagedAgentsMultiagentCoordinator object`

      Resolved coordinator topology with a concrete agent roster.

      - `type: "coordinator"`

      - `agents: array of BetaManagedAgentsAgentReference or BetaManagedAgentsAdvisor`

        Agents the coordinator may spawn as session threads, each resolved to a specific version.

        - `BetaManagedAgentsAgentReference object`

          A resolved agent reference with a concrete version.

          - `type: "agent"`

          - `id: string`

          - `version: number`

            format: int32

        - `BetaManagedAgentsAdvisor object`

          Platform advisor roster entry: a model the session's primary thread may consult mid-turn.

          - `type: "advisor"`

          - `model: string`

            The advisor model id.

    - `BetaManagedAgentsMultiagent20261001 object`

      Resolved multiagent configuration with three members, each enabled or disabled on its own.

      - `type: "multiagent_20261001"`

      - `advisor: BetaManagedAgentsMultiagentAdvisor`

        Whether the session's primary thread can consult an advisor model.

        - `BetaManagedAgentsMultiagentAdvisorEnabled object`

          The session's primary thread can consult `model` mid-turn.

          - `type: "enabled"`

          - `model: string`

            The advisor model id.

        - `BetaManagedAgentsMultiagentAdvisorDisabled object`

          The agent has no advisor.

          - `type: "disabled"`

      - `subagents: BetaManagedAgentsMultiagentSubagents`

        Whether the agent can spawn session threads.

        - `BetaManagedAgentsMultiagentSubagentsEnabled object`

          The agent can spawn session threads.

          - `type: "enabled"`

          - `inline_agents: BetaManagedAgentsMultiagentInlineAgents`

            Whether the agent can define inline agents, which are not saved, when it spawns session threads.

            - `BetaManagedAgentsMultiagentInlineAgentsEnabled object`

              The agent can define inline agents.

              - `type: "enabled"`

            - `BetaManagedAgentsMultiagentInlineAgentsDisabled object`

              The agent cannot define inline agents.

              - `type: "disabled"`

          - `predefined_agents: array of BetaManagedAgentsAgentReference`

            Predefined agents, which are saved agents that this agent can spawn as session threads, each resolved to a specific version.

            - `type: "agent"`

            - `id: string`

            - `version: number`

              format: int32

        - `BetaManagedAgentsMultiagentSubagentsDisabled object`

          The agent cannot spawn session threads.

          - `type: "disabled"`

      - `workflows: BetaManagedAgentsMultiagentWorkflows`

        Whether the agent can start workflow runs.

        - `BetaManagedAgentsMultiagentWorkflowsEnabled object`

          The agent can start workflow runs.

          - `type: "enabled"`

          - `inline_agents: BetaManagedAgentsMultiagentInlineAgents`

            Whether a run's plan can define inline agents, which are not saved.

          - `predefined_agents: array of BetaManagedAgentsAgentReference`

            Predefined agents, which are saved agents that a run's plan can use, each resolved to a specific version.

            - `type: "agent"`

            - `id: string`

            - `version: number`

              format: int32

        - `BetaManagedAgentsMultiagentWorkflowsDisabled object`

          The agent cannot start workflow runs.

          - `type: "disabled"`

  - `name: string`

  - `skills: array of BetaManagedAgentsAnthropicSkill or BetaManagedAgentsCustomSkill`

    - `BetaManagedAgentsAnthropicSkill object`

      A resolved Anthropic-managed skill.

      - `type: "anthropic"`

      - `skill_id: string`

      - `version: string`

    - `BetaManagedAgentsCustomSkill object`

      A resolved user-created custom skill.

      - `type: "custom"`

      - `skill_id: string`

      - `version: string`

  - `system: string or null`

  - `tools: array of BetaManagedAgentsAgentToolset20260401 or BetaManagedAgentsMCPToolset or BetaManagedAgentsCustomTool`

    - `BetaManagedAgentsAgentToolset20260401 object`

      - `type: "agent_toolset_20260401"`

      - `configs: array of BetaManagedAgentsAgentToolConfig`

        - `BetaManagedAgentsBashToolConfig object`

          Configuration for the bash tool.

          - `type: "bash"`

          - `enabled: boolean`

          - `name: "bash"`

          - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

            Permission policy for tool execution.

            - `BetaManagedAgentsAlwaysAllowPolicy object`

              Tool calls are automatically approved without user confirmation.

              - `type: "always_allow"`

            - `BetaManagedAgentsAlwaysAskPolicy object`

              Tool calls require user confirmation before execution.

              - `type: "always_ask"`

            - `BetaManagedAgentsAutoPolicy object`

              The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

              - `type: "auto"`

        - `BetaManagedAgentsEditToolConfig object`

          Configuration for the edit tool.

          - `type: "edit"`

          - `enabled: boolean`

          - `name: "edit"`

          - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

            Permission policy for tool execution.

            - `BetaManagedAgentsAlwaysAllowPolicy object`

              Tool calls are automatically approved without user confirmation.

            - `BetaManagedAgentsAlwaysAskPolicy object`

              Tool calls require user confirmation before execution.

            - `BetaManagedAgentsAutoPolicy object`

              The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

        - `BetaManagedAgentsReadToolConfig object`

          Configuration for the read tool.

          - `type: "read"`

          - `enabled: boolean`

          - `name: "read"`

          - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

            Permission policy for tool execution.

            - `BetaManagedAgentsAlwaysAllowPolicy object`

              Tool calls are automatically approved without user confirmation.

            - `BetaManagedAgentsAlwaysAskPolicy object`

              Tool calls require user confirmation before execution.

            - `BetaManagedAgentsAutoPolicy object`

              The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

        - `BetaManagedAgentsWriteToolConfig object`

          Configuration for the write tool.

          - `type: "write"`

          - `enabled: boolean`

          - `name: "write"`

          - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

            Permission policy for tool execution.

            - `BetaManagedAgentsAlwaysAllowPolicy object`

              Tool calls are automatically approved without user confirmation.

            - `BetaManagedAgentsAlwaysAskPolicy object`

              Tool calls require user confirmation before execution.

            - `BetaManagedAgentsAutoPolicy object`

              The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

        - `BetaManagedAgentsGlobToolConfig object`

          Configuration for the glob tool.

          - `type: "glob"`

          - `enabled: boolean`

          - `name: "glob"`

          - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

            Permission policy for tool execution.

            - `BetaManagedAgentsAlwaysAllowPolicy object`

              Tool calls are automatically approved without user confirmation.

            - `BetaManagedAgentsAlwaysAskPolicy object`

              Tool calls require user confirmation before execution.

            - `BetaManagedAgentsAutoPolicy object`

              The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

        - `BetaManagedAgentsGrepToolConfig object`

          Configuration for the grep tool.

          - `type: "grep"`

          - `enabled: boolean`

          - `name: "grep"`

          - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

            Permission policy for tool execution.

            - `BetaManagedAgentsAlwaysAllowPolicy object`

              Tool calls are automatically approved without user confirmation.

            - `BetaManagedAgentsAlwaysAskPolicy object`

              Tool calls require user confirmation before execution.

            - `BetaManagedAgentsAutoPolicy object`

              The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

        - `BetaManagedAgentsWebFetchToolConfig object`

          Configuration for the web_fetch tool.

          - `type: "web_fetch"`

          - `enabled: boolean`

          - `name: "web_fetch"`

          - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

            Permission policy for tool execution.

            - `BetaManagedAgentsAlwaysAllowPolicy object`

              Tool calls are automatically approved without user confirmation.

            - `BetaManagedAgentsAlwaysAskPolicy object`

              Tool calls require user confirmation before execution.

            - `BetaManagedAgentsAutoPolicy object`

              The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

          - `url_sources: BetaManagedAgentsWebFetchURLSources or null`

            Which sources contribute URLs the tool may fetch, always in the object form. Null when not set, which allows every source.

            - `client_tool_results: BetaManagedAgentsWebFetchURLSourceToolFilter or null`

              Which custom tools' results contribute URLs that may be fetched. Null when not set, which allows every custom tool's results.

              - `BetaManagedAgentsWebFetchURLSourceAll object`

                Every URL from this source may be fetched. This is the default.

                - `type: "all"`

              - `BetaManagedAgentsWebFetchURLSourceNone object`

                This source contributes no URLs that may be fetched.

                - `type: "none"`

              - `BetaManagedAgentsWebFetchURLSourceOnly object`

                Only the named tools' results contribute URLs that may be fetched.

                - `type: "only"`

                - `tools: array of BetaManagedAgentsWebFetchURLSourceToolReference`

                  The tools whose results contribute. Between 1 and 128 entries, each with a different name. An empty list is rejected; use "none" to allow no tool's results.

                  - `type: "tool_reference"`

                    Must be "tool_reference".

                  - `name: string`

                    Name of the tool. Compared exactly, so upper and lower case letters are different.

                    minLength: 1, maxLength: 128

              - `BetaManagedAgentsWebFetchURLSourceExcept object`

                Every tool's results contribute URLs that may be fetched, except the named tools' results.

                - `type: "except"`

                - `tools: array of BetaManagedAgentsWebFetchURLSourceToolReference`

                  The tools whose results do not contribute. Between 1 and 128 entries, each with a different name. An empty list is rejected; use "all" to leave out no tool's results.

                  - `type: "tool_reference"`

                    Must be "tool_reference".

                  - `name: string`

                    Name of the tool. Compared exactly, so upper and lower case letters are different.

                    minLength: 1, maxLength: 128

            - `server_tool_results: BetaManagedAgentsWebFetchURLSourceToolFilter or null`

              Which of the web_search and web_fetch tools' results contribute URLs that may be fetched. Null when not set, which allows both.

            - `user_input: BetaManagedAgentsWebFetchURLSourceUserInput or null`

              Whether URLs in the text of user messages may be fetched. Null when not set, which allows them.

              - `BetaManagedAgentsWebFetchURLSourceAll object`

                Every URL from this source may be fetched. This is the default.

              - `BetaManagedAgentsWebFetchURLSourceNone object`

                This source contributes no URLs that may be fetched.

          - `allowed_domains: optional array of string`

          - `blocked_domains: optional array of string`

          - `max_content_tokens: optional number or null`

            format: int32

        - `BetaManagedAgentsWebSearchToolConfig object`

          Configuration for the web_search tool.

          - `type: "web_search"`

          - `enabled: boolean`

          - `name: "web_search"`

          - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

            Permission policy for tool execution.

            - `BetaManagedAgentsAlwaysAllowPolicy object`

              Tool calls are automatically approved without user confirmation.

            - `BetaManagedAgentsAlwaysAskPolicy object`

              Tool calls require user confirmation before execution.

            - `BetaManagedAgentsAutoPolicy object`

              The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

          - `allowed_domains: optional array of string`

          - `blocked_domains: optional array of string`

          - `user_location: optional BetaManagedAgentsUserLocation or null`

            Approximate user location for search result localization.

            - `type: "approximate"`

              Location precision. Only "approximate" is supported.

            - `city: optional string or null`

              City name.

              minLength: 1, maxLength: 255

            - `country: optional string or null`

              Two-letter ISO 3166-1 country code, uppercase.

            - `region: optional string or null`

              Region or state name.

              minLength: 1, maxLength: 255

            - `timezone: optional string or null`

              IANA timezone identifier, e.g. "America/Los_Angeles".

              minLength: 1, maxLength: 255

      - `default_config: BetaManagedAgentsAgentToolsetDefaultConfig`

        Resolved default configuration for agent tools.

        - `enabled: boolean`

        - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

          Permission policy for tool execution.

          - `BetaManagedAgentsAlwaysAllowPolicy object`

            Tool calls are automatically approved without user confirmation.

          - `BetaManagedAgentsAlwaysAskPolicy object`

            Tool calls require user confirmation before execution.

          - `BetaManagedAgentsAutoPolicy object`

            The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

    - `BetaManagedAgentsMCPToolset object`

      - `type: "mcp_toolset"`

      - `configs: array of BetaManagedAgentsMCPToolConfig`

        - `enabled: boolean`

        - `name: string`

        - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

          Permission policy for tool execution.

          - `BetaManagedAgentsAlwaysAllowPolicy object`

            Tool calls are automatically approved without user confirmation.

          - `BetaManagedAgentsAlwaysAskPolicy object`

            Tool calls require user confirmation before execution.

          - `BetaManagedAgentsAutoPolicy object`

            The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

      - `default_config: BetaManagedAgentsMCPToolsetDefaultConfig`

        Resolved default configuration for all tools from an MCP server.

        - `enabled: boolean`

        - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

          Permission policy for tool execution.

          - `BetaManagedAgentsAlwaysAllowPolicy object`

            Tool calls are automatically approved without user confirmation.

          - `BetaManagedAgentsAlwaysAskPolicy object`

            Tool calls require user confirmation before execution.

          - `BetaManagedAgentsAutoPolicy object`

            The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

      - `mcp_server_name: string`

    - `BetaManagedAgentsCustomTool object`

      A custom tool as returned in API responses.

      - `type: "custom"`

      - `description: string`

      - `input_schema: BetaManagedAgentsCustomToolInputSchema`

        JSON Schema for custom tool input parameters.

        - `type: "object"`

        - `properties: optional map[unknown] or null`

        - `required: optional array of string or null`

      - `name: string`

  - `updated_at: string`

    A timestamp in RFC 3339 format

    format: date-time

  - `version: number`

    The agent's current version. Starts at 1 and increments when the agent is modified.

    format: int32

## Example

```bash
curl https://api.anthropic.com/v1/agents \
    -H 'Content-Type: application/json' \
    -H 'anthropic-version: 2023-06-01' \
    -H 'anthropic-beta: managed-agents-2026-04-01' \
    -H "X-Api-Key: $ANTHROPIC_API_KEY" \
    -d '{
          "model": "claude-opus-5-5",
          "name": "My First Agent",
          "description": "A general-purpose starter agent.",
          "metadata": {
            "foo": "bar"
          },
          "system": "You are a general-purpose agent that can research, write code, run commands, and use connected tools to complete the user'\''s task end to end.",
          "tools": [
            {
              "type": "agent_toolset_20260401"
            }
          ]
        }'
```

### Response (200)

```json
{
  "id": "agent_011CZkYpogX7uDKUyvBTophP",
  "archived_at": null,
  "created_at": "2026-03-15T10:00:00Z",
  "description": "A general-purpose starter agent.",
  "mcp_servers": [
    {
      "name": "example-mcp",
      "type": "url",
      "url": "https://example-server.modelcontextprotocol.io/sse"
    }
  ],
  "metadata": {
    "foo": "bar"
  },
  "model": {
    "id": "claude-opus-5-5",
    "effort": {
      "type": "low"
    },
    "inference_geo": "inference_geo",
    "speed": "standard"
  },
  "multiagent": {
    "advisor": {
      "type": "disabled"
    },
    "subagents": {
      "inline_agents": {
        "type": "enabled"
      },
      "predefined_agents": [
        {
          "id": "agent_011CZkYqphY8vELVzwCUpqiQ",
          "type": "agent",
          "version": 1
        }
      ],
      "type": "enabled"
    },
    "type": "multiagent_20261001",
    "workflows": {
      "inline_agents": {
        "type": "enabled"
      },
      "predefined_agents": [
        {
          "id": "agent_011CZkYqphY8vELVzwCUpqiQ",
          "type": "agent",
          "version": 1
        }
      ],
      "type": "enabled"
    }
  },
  "name": "My First Agent",
  "skills": [
    {
      "skill_id": "xlsx",
      "type": "anthropic",
      "version": "1"
    },
    {
      "skill_id": "skill_011CZkZFNu9hAbo3jZPRgTmx",
      "type": "custom",
      "version": "2"
    }
  ],
  "system": "You are a general-purpose agent that can research, write code, run commands, and use connected tools to complete the user's task end to end.",
  "tools": [
    {
      "configs": [
        {
          "enabled": true,
          "name": "bash",
          "permission_policy": {
            "type": "always_allow"
          },
          "type": "bash"
        }
      ],
      "default_config": {
        "enabled": true,
        "permission_policy": {
          "type": "always_ask"
        }
      },
      "type": "agent_toolset_20260401"
    }
  ],
  "type": "agent",
  "updated_at": "2026-03-15T10:00:00Z",
  "version": 1
}
```
