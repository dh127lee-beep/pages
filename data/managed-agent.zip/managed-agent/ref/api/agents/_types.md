# Agents — Domain types

원문: https://platform.claude.com/docs/en/api/beta/agents



### Beta Managed Agents Advisor

- `BetaManagedAgentsAdvisor object`

  Platform advisor roster entry: a model the session's primary thread may consult mid-turn.

  - `type: "advisor"`

  - `model: string`

    The advisor model id.

### Beta Managed Agents Agent

- `BetaManagedAgentsAgent object`

  A Managed Agents `agent`.

  - `type: "agent"`

  - `id: string`

  - `archived_at: string or null`

    When the agent was archived. Null if not archived.

    format: date-time

  - `created_at: string`

    A timestamp in RFC 3339 format

    format: date-time

  - `description: string or null`

  - `mcp_servers: array of BetaManagedAgentsMCPServerURLDefinition`

    - `type: "url"`

    - `name: string`

    - `url: string`

  - `metadata: map[string]`

  - `model: BetaManagedAgentsModelConfig`

    Model identifier and configuration.

    - `id: BetaManagedAgentsModel`

      The model that will power your agent.

      See [models](https://docs.anthropic.com/en/docs/models-overview) for additional details and options.

      - `"claude-haiku-5-5"`

        Fastest model for high-volume, real-time tasks

      - `"claude-sonnet-5-5"`

        Efficient model for coding and agents

      - `"claude-opus-5-5"`

        Powerful intelligence for coding, knowledge work, and long-running agents

      - `"claude-fable-5-1"`

        Frontier intelligence for ambitious tasks across coding, scientific discovery, and enterprise workflows

      - `"claude-sonnet-5"`

        Efficient model for coding and agents

      - `"claude-fable-5"`

        Next generation of intelligence for the hardest knowledge work and coding problems

      - `"claude-opus-5"`

        Powerful intelligence for long-running agents and coding

      - `"claude-opus-4-8"`

        Powerful intelligence for long-running agents and coding

      - `"claude-opus-4-7"`

        Powerful intelligence for long-running agents and coding

      - `"claude-opus-4-6"`

        Powerful intelligence for long-running agents and coding

      - `"claude-sonnet-4-6"`

        Best combination of speed and intelligence

      - `"claude-haiku-4-5"`

      - `"claude-haiku-4-5-20251001"`

      - `"claude-opus-4-5"`

        Powerful intelligence for long-running agents and coding

      - `"claude-opus-4-5-20251101"`

        Powerful intelligence for long-running agents and coding

      - `"claude-sonnet-4-5"`

        **Deprecated**: Will reach end-of-life on November 30, 2026. Please migrate to claude-sonnet-5-5. Visit https://docs.anthropic.com/en/docs/resources/model-deprecations for more information.

        High-performance model for agents and coding

      - `"claude-sonnet-4-5-20250929"`

        **Deprecated**: Will reach end-of-life on November 30, 2026. Please migrate to claude-sonnet-5-5. Visit https://docs.anthropic.com/en/docs/resources/model-deprecations for more information.

        High-performance model for agents and coding

      - `string`

    - `effort: optional BetaManagedAgentsEffortLow or BetaManagedAgentsEffortMedium or BetaManagedAgentsEffortHigh or 2 more`

      How hard Claude works on each inference call. One of `low`, `medium`, `high`, `xhigh`, `max`. Always present; resolved to the per-model default at save time when not supplied.

      - `BetaManagedAgentsEffortLow object`

        Low effort. Favors latency over reasoning depth.

        - `type: "low"`

      - `BetaManagedAgentsEffortMedium object`

        Medium effort. Balances latency and reasoning depth.

        - `type: "medium"`

      - `BetaManagedAgentsEffortHigh object`

        High effort. Favors reasoning depth.

        - `type: "high"`

      - `BetaManagedAgentsEffortXhigh object`

        Extra-high effort. Not all models accept this level.

        - `type: "xhigh"`

      - `BetaManagedAgentsEffortMax object`

        Maximum effort. Favors reasoning depth over latency.

        - `type: "max"`

    - `inference_geo: optional string`

      Geographic region for model inference. When unset, requests fall through to the workspace's default_inference_geo.

    - `speed: optional "standard" or "fast"`

      Inference speed mode. `fast` provides significantly faster output token generation at premium pricing. Defaults to `standard`. Not all models support `fast`; invalid combinations are rejected at create time.

      - `"standard"`

      - `"fast"`

  - `multiagent: BetaManagedAgentsMultiagent or null`

    Multiagent orchestration configuration. Null when the agent is single-threaded.

    - `BetaManagedAgentsMultiagentCoordinator object`

      Resolved coordinator topology with a concrete agent roster.

      - `type: "coordinator"`

      - `agents: array of BetaManagedAgentsAgentReference or BetaManagedAgentsAdvisor`

        Agents the coordinator may spawn as session threads, each resolved to a specific version.

        - `BetaManagedAgentsAgentReference object`

          A resolved agent reference with a concrete version.

          - `type: "agent"`

          - `id: string`

          - `version: number`

            format: int32

        - `BetaManagedAgentsAdvisor object`

          Platform advisor roster entry: a model the session's primary thread may consult mid-turn.

          - `type: "advisor"`

          - `model: string`

            The advisor model id.

    - `BetaManagedAgentsMultiagent20261001 object`

      Resolved multiagent configuration with three members, each enabled or disabled on its own.

      - `type: "multiagent_20261001"`

      - `advisor: BetaManagedAgentsMultiagentAdvisor`

        Whether the session's primary thread can consult an advisor model.

        - `BetaManagedAgentsMultiagentAdvisorEnabled object`

          The session's primary thread can consult `model` mid-turn.

          - `type: "enabled"`

          - `model: string`

            The advisor model id.

        - `BetaManagedAgentsMultiagentAdvisorDisabled object`

          The agent has no advisor.

          - `type: "disabled"`

      - `subagents: BetaManagedAgentsMultiagentSubagents`

        Whether the agent can spawn session threads.

        - `BetaManagedAgentsMultiagentSubagentsEnabled object`

          The agent can spawn session threads.

          - `type: "enabled"`

          - `inline_agents: BetaManagedAgentsMultiagentInlineAgents`

            Whether the agent can define inline agents, which are not saved, when it spawns session threads.

            - `BetaManagedAgentsMultiagentInlineAgentsEnabled object`

              The agent can define inline agents.

              - `type: "enabled"`

            - `BetaManagedAgentsMultiagentInlineAgentsDisabled object`

              The agent cannot define inline agents.

              - `type: "disabled"`

          - `predefined_agents: array of BetaManagedAgentsAgentReference`

            Predefined agents, which are saved agents that this agent can spawn as session threads, each resolved to a specific version.

            - `type: "agent"`

            - `id: string`

            - `version: number`

              format: int32

        - `BetaManagedAgentsMultiagentSubagentsDisabled object`

          The agent cannot spawn session threads.

          - `type: "disabled"`

      - `workflows: BetaManagedAgentsMultiagentWorkflows`

        Whether the agent can start workflow runs.

        - `BetaManagedAgentsMultiagentWorkflowsEnabled object`

          The agent can start workflow runs.

          - `type: "enabled"`

          - `inline_agents: BetaManagedAgentsMultiagentInlineAgents`

            Whether a run's plan can define inline agents, which are not saved.

          - `predefined_agents: array of BetaManagedAgentsAgentReference`

            Predefined agents, which are saved agents that a run's plan can use, each resolved to a specific version.

            - `type: "agent"`

            - `id: string`

            - `version: number`

              format: int32

        - `BetaManagedAgentsMultiagentWorkflowsDisabled object`

          The agent cannot start workflow runs.

          - `type: "disabled"`

  - `name: string`

  - `skills: array of BetaManagedAgentsAnthropicSkill or BetaManagedAgentsCustomSkill`

    - `BetaManagedAgentsAnthropicSkill object`

      A resolved Anthropic-managed skill.

      - `type: "anthropic"`

      - `skill_id: string`

      - `version: string`

    - `BetaManagedAgentsCustomSkill object`

      A resolved user-created custom skill.

      - `type: "custom"`

      - `skill_id: string`

      - `version: string`

  - `system: string or null`

  - `tools: array of BetaManagedAgentsAgentToolset20260401 or BetaManagedAgentsMCPToolset or BetaManagedAgentsCustomTool`

    - `BetaManagedAgentsAgentToolset20260401 object`

      - `type: "agent_toolset_20260401"`

      - `configs: array of BetaManagedAgentsAgentToolConfig`

        - `BetaManagedAgentsBashToolConfig object`

          Configuration for the bash tool.

          - `type: "bash"`

          - `enabled: boolean`

          - `name: "bash"`

          - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

            Permission policy for tool execution.

            - `BetaManagedAgentsAlwaysAllowPolicy object`

              Tool calls are automatically approved without user confirmation.

              - `type: "always_allow"`

            - `BetaManagedAgentsAlwaysAskPolicy object`

              Tool calls require user confirmation before execution.

              - `type: "always_ask"`

            - `BetaManagedAgentsAutoPolicy object`

              The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

              - `type: "auto"`

        - `BetaManagedAgentsEditToolConfig object`

          Configuration for the edit tool.

          - `type: "edit"`

          - `enabled: boolean`

          - `name: "edit"`

          - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

            Permission policy for tool execution.

            - `BetaManagedAgentsAlwaysAllowPolicy object`

              Tool calls are automatically approved without user confirmation.

            - `BetaManagedAgentsAlwaysAskPolicy object`

              Tool calls require user confirmation before execution.

            - `BetaManagedAgentsAutoPolicy object`

              The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

        - `BetaManagedAgentsReadToolConfig object`

          Configuration for the read tool.

          - `type: "read"`

          - `enabled: boolean`

          - `name: "read"`

          - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

            Permission policy for tool execution.

            - `BetaManagedAgentsAlwaysAllowPolicy object`

              Tool calls are automatically approved without user confirmation.

            - `BetaManagedAgentsAlwaysAskPolicy object`

              Tool calls require user confirmation before execution.

            - `BetaManagedAgentsAutoPolicy object`

              The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

        - `BetaManagedAgentsWriteToolConfig object`

          Configuration for the write tool.

          - `type: "write"`

          - `enabled: boolean`

          - `name: "write"`

          - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

            Permission policy for tool execution.

            - `BetaManagedAgentsAlwaysAllowPolicy object`

              Tool calls are automatically approved without user confirmation.

            - `BetaManagedAgentsAlwaysAskPolicy object`

              Tool calls require user confirmation before execution.

            - `BetaManagedAgentsAutoPolicy object`

              The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

        - `BetaManagedAgentsGlobToolConfig object`

          Configuration for the glob tool.

          - `type: "glob"`

          - `enabled: boolean`

          - `name: "glob"`

          - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

            Permission policy for tool execution.

            - `BetaManagedAgentsAlwaysAllowPolicy object`

              Tool calls are automatically approved without user confirmation.

            - `BetaManagedAgentsAlwaysAskPolicy object`

              Tool calls require user confirmation before execution.

            - `BetaManagedAgentsAutoPolicy object`

              The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

        - `BetaManagedAgentsGrepToolConfig object`

          Configuration for the grep tool.

          - `type: "grep"`

          - `enabled: boolean`

          - `name: "grep"`

          - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

            Permission policy for tool execution.

            - `BetaManagedAgentsAlwaysAllowPolicy object`

              Tool calls are automatically approved without user confirmation.

            - `BetaManagedAgentsAlwaysAskPolicy object`

              Tool calls require user confirmation before execution.

            - `BetaManagedAgentsAutoPolicy object`

              The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

        - `BetaManagedAgentsWebFetchToolConfig object`

          Configuration for the web_fetch tool.

          - `type: "web_fetch"`

          - `enabled: boolean`

          - `name: "web_fetch"`

          - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

            Permission policy for tool execution.

            - `BetaManagedAgentsAlwaysAllowPolicy object`

              Tool calls are automatically approved without user confirmation.

            - `BetaManagedAgentsAlwaysAskPolicy object`

              Tool calls require user confirmation before execution.

            - `BetaManagedAgentsAutoPolicy object`

              The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

          - `url_sources: BetaManagedAgentsWebFetchURLSources or null`

            Which sources contribute URLs the tool may fetch, always in the object form. Null when not set, which allows every source.

            - `client_tool_results: BetaManagedAgentsWebFetchURLSourceToolFilter or null`

              Which custom tools' results contribute URLs that may be fetched. Null when not set, which allows every custom tool's results.

              - `BetaManagedAgentsWebFetchURLSourceAll object`

                Every URL from this source may be fetched. This is the default.

                - `type: "all"`

              - `BetaManagedAgentsWebFetchURLSourceNone object`

                This source contributes no URLs that may be fetched.

                - `type: "none"`

              - `BetaManagedAgentsWebFetchURLSourceOnly object`

                Only the named tools' results contribute URLs that may be fetched.

                - `type: "only"`

                - `tools: array of BetaManagedAgentsWebFetchURLSourceToolReference`

                  The tools whose results contribute. Between 1 and 128 entries, each with a different name. An empty list is rejected; use "none" to allow no tool's results.

                  - `type: "tool_reference"`

                    Must be "tool_reference".

                  - `name: string`

                    Name of the tool. Compared exactly, so upper and lower case letters are different.

                    minLength: 1, maxLength: 128

              - `BetaManagedAgentsWebFetchURLSourceExcept object`

                Every tool's results contribute URLs that may be fetched, except the named tools' results.

                - `type: "except"`

                - `tools: array of BetaManagedAgentsWebFetchURLSourceToolReference`

                  The tools whose results do not contribute. Between 1 and 128 entries, each with a different name. An empty list is rejected; use "all" to leave out no tool's results.

                  - `type: "tool_reference"`

                    Must be "tool_reference".

                  - `name: string`

                    Name of the tool. Compared exactly, so upper and lower case letters are different.

                    minLength: 1, maxLength: 128

            - `server_tool_results: BetaManagedAgentsWebFetchURLSourceToolFilter or null`

              Which of the web_search and web_fetch tools' results contribute URLs that may be fetched. Null when not set, which allows both.

            - `user_input: BetaManagedAgentsWebFetchURLSourceUserInput or null`

              Whether URLs in the text of user messages may be fetched. Null when not set, which allows them.

              - `BetaManagedAgentsWebFetchURLSourceAll object`

                Every URL from this source may be fetched. This is the default.

              - `BetaManagedAgentsWebFetchURLSourceNone object`

                This source contributes no URLs that may be fetched.

          - `allowed_domains: optional array of string`

          - `blocked_domains: optional array of string`

          - `max_content_tokens: optional number or null`

            format: int32

        - `BetaManagedAgentsWebSearchToolConfig object`

          Configuration for the web_search tool.

          - `type: "web_search"`

          - `enabled: boolean`

          - `name: "web_search"`

          - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

            Permission policy for tool execution.

            - `BetaManagedAgentsAlwaysAllowPolicy object`

              Tool calls are automatically approved without user confirmation.

            - `BetaManagedAgentsAlwaysAskPolicy object`

              Tool calls require user confirmation before execution.

            - `BetaManagedAgentsAutoPolicy object`

              The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

          - `allowed_domains: optional array of string`

          - `blocked_domains: optional array of string`

          - `user_location: optional BetaManagedAgentsUserLocation or null`

            Approximate user location for search result localization.

            - `type: "approximate"`

              Location precision. Only "approximate" is supported.

            - `city: optional string or null`

              City name.

              minLength: 1, maxLength: 255

            - `country: optional string or null`

              Two-letter ISO 3166-1 country code, uppercase.

            - `region: optional string or null`

              Region or state name.

              minLength: 1, maxLength: 255

            - `timezone: optional string or null`

              IANA timezone identifier, e.g. "America/Los_Angeles".

              minLength: 1, maxLength: 255

      - `default_config: BetaManagedAgentsAgentToolsetDefaultConfig`

        Resolved default configuration for agent tools.

        - `enabled: boolean`

        - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

          Permission policy for tool execution.

          - `BetaManagedAgentsAlwaysAllowPolicy object`

            Tool calls are automatically approved without user confirmation.

          - `BetaManagedAgentsAlwaysAskPolicy object`

            Tool calls require user confirmation before execution.

          - `BetaManagedAgentsAutoPolicy object`

            The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

    - `BetaManagedAgentsMCPToolset object`

      - `type: "mcp_toolset"`

      - `configs: array of BetaManagedAgentsMCPToolConfig`

        - `enabled: boolean`

        - `name: string`

        - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

          Permission policy for tool execution.

          - `BetaManagedAgentsAlwaysAllowPolicy object`

            Tool calls are automatically approved without user confirmation.

          - `BetaManagedAgentsAlwaysAskPolicy object`

            Tool calls require user confirmation before execution.

          - `BetaManagedAgentsAutoPolicy object`

            The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

      - `default_config: BetaManagedAgentsMCPToolsetDefaultConfig`

        Resolved default configuration for all tools from an MCP server.

        - `enabled: boolean`

        - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

          Permission policy for tool execution.

          - `BetaManagedAgentsAlwaysAllowPolicy object`

            Tool calls are automatically approved without user confirmation.

          - `BetaManagedAgentsAlwaysAskPolicy object`

            Tool calls require user confirmation before execution.

          - `BetaManagedAgentsAutoPolicy object`

            The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

      - `mcp_server_name: string`

    - `BetaManagedAgentsCustomTool object`

      A custom tool as returned in API responses.

      - `type: "custom"`

      - `description: string`

      - `input_schema: BetaManagedAgentsCustomToolInputSchema`

        JSON Schema for custom tool input parameters.

        - `type: "object"`

        - `properties: optional map[unknown] or null`

        - `required: optional array of string or null`

      - `name: string`

  - `updated_at: string`

    A timestamp in RFC 3339 format

    format: date-time

  - `version: number`

    The agent's current version. Starts at 1 and increments when the agent is modified.

    format: int32

### Beta Managed Agents Agent Reference

- `BetaManagedAgentsAgentReference object`

  A resolved agent reference with a concrete version.

  - `type: "agent"`

  - `id: string`

  - `version: number`

    format: int32

### Beta Managed Agents Agent Tool Config

- `BetaManagedAgentsAgentToolConfig = BetaManagedAgentsBashToolConfig or BetaManagedAgentsEditToolConfig or BetaManagedAgentsReadToolConfig or 5 more`

  Configuration for a specific agent tool.

  - `BetaManagedAgentsBashToolConfig object`

    Configuration for the bash tool.

    - `type: "bash"`

    - `enabled: boolean`

    - `name: "bash"`

    - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

      Permission policy for tool execution.

      - `BetaManagedAgentsAlwaysAllowPolicy object`

        Tool calls are automatically approved without user confirmation.

        - `type: "always_allow"`

      - `BetaManagedAgentsAlwaysAskPolicy object`

        Tool calls require user confirmation before execution.

        - `type: "always_ask"`

      - `BetaManagedAgentsAutoPolicy object`

        The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

        - `type: "auto"`

  - `BetaManagedAgentsEditToolConfig object`

    Configuration for the edit tool.

    - `type: "edit"`

    - `enabled: boolean`

    - `name: "edit"`

    - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

      Permission policy for tool execution.

      - `BetaManagedAgentsAlwaysAllowPolicy object`

        Tool calls are automatically approved without user confirmation.

      - `BetaManagedAgentsAlwaysAskPolicy object`

        Tool calls require user confirmation before execution.

      - `BetaManagedAgentsAutoPolicy object`

        The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

  - `BetaManagedAgentsReadToolConfig object`

    Configuration for the read tool.

    - `type: "read"`

    - `enabled: boolean`

    - `name: "read"`

    - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

      Permission policy for tool execution.

      - `BetaManagedAgentsAlwaysAllowPolicy object`

        Tool calls are automatically approved without user confirmation.

      - `BetaManagedAgentsAlwaysAskPolicy object`

        Tool calls require user confirmation before execution.

      - `BetaManagedAgentsAutoPolicy object`

        The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

  - `BetaManagedAgentsWriteToolConfig object`

    Configuration for the write tool.

    - `type: "write"`

    - `enabled: boolean`

    - `name: "write"`

    - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

      Permission policy for tool execution.

      - `BetaManagedAgentsAlwaysAllowPolicy object`

        Tool calls are automatically approved without user confirmation.

      - `BetaManagedAgentsAlwaysAskPolicy object`

        Tool calls require user confirmation before execution.

      - `BetaManagedAgentsAutoPolicy object`

        The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

  - `BetaManagedAgentsGlobToolConfig object`

    Configuration for the glob tool.

    - `type: "glob"`

    - `enabled: boolean`

    - `name: "glob"`

    - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

      Permission policy for tool execution.

      - `BetaManagedAgentsAlwaysAllowPolicy object`

        Tool calls are automatically approved without user confirmation.

      - `BetaManagedAgentsAlwaysAskPolicy object`

        Tool calls require user confirmation before execution.

      - `BetaManagedAgentsAutoPolicy object`

        The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

  - `BetaManagedAgentsGrepToolConfig object`

    Configuration for the grep tool.

    - `type: "grep"`

    - `enabled: boolean`

    - `name: "grep"`

    - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

      Permission policy for tool execution.

      - `BetaManagedAgentsAlwaysAllowPolicy object`

        Tool calls are automatically approved without user confirmation.

      - `BetaManagedAgentsAlwaysAskPolicy object`

        Tool calls require user confirmation before execution.

      - `BetaManagedAgentsAutoPolicy object`

        The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

  - `BetaManagedAgentsWebFetchToolConfig object`

    Configuration for the web_fetch tool.

    - `type: "web_fetch"`

    - `enabled: boolean`

    - `name: "web_fetch"`

    - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

      Permission policy for tool execution.

      - `BetaManagedAgentsAlwaysAllowPolicy object`

        Tool calls are automatically approved without user confirmation.

      - `BetaManagedAgentsAlwaysAskPolicy object`

        Tool calls require user confirmation before execution.

      - `BetaManagedAgentsAutoPolicy object`

        The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

    - `url_sources: BetaManagedAgentsWebFetchURLSources or null`

      Which sources contribute URLs the tool may fetch, always in the object form. Null when not set, which allows every source.

      - `client_tool_results: BetaManagedAgentsWebFetchURLSourceToolFilter or null`

        Which custom tools' results contribute URLs that may be fetched. Null when not set, which allows every custom tool's results.

        - `BetaManagedAgentsWebFetchURLSourceAll object`

          Every URL from this source may be fetched. This is the default.

          - `type: "all"`

        - `BetaManagedAgentsWebFetchURLSourceNone object`

          This source contributes no URLs that may be fetched.

          - `type: "none"`

        - `BetaManagedAgentsWebFetchURLSourceOnly object`

          Only the named tools' results contribute URLs that may be fetched.

          - `type: "only"`

          - `tools: array of BetaManagedAgentsWebFetchURLSourceToolReference`

            The tools whose results contribute. Between 1 and 128 entries, each with a different name. An empty list is rejected; use "none" to allow no tool's results.

            - `type: "tool_reference"`

              Must be "tool_reference".

            - `name: string`

              Name of the tool. Compared exactly, so upper and lower case letters are different.

              minLength: 1, maxLength: 128

        - `BetaManagedAgentsWebFetchURLSourceExcept object`

          Every tool's results contribute URLs that may be fetched, except the named tools' results.

          - `type: "except"`

          - `tools: array of BetaManagedAgentsWebFetchURLSourceToolReference`

            The tools whose results do not contribute. Between 1 and 128 entries, each with a different name. An empty list is rejected; use "all" to leave out no tool's results.

            - `type: "tool_reference"`

              Must be "tool_reference".

            - `name: string`

              Name of the tool. Compared exactly, so upper and lower case letters are different.

              minLength: 1, maxLength: 128

      - `server_tool_results: BetaManagedAgentsWebFetchURLSourceToolFilter or null`

        Which of the web_search and web_fetch tools' results contribute URLs that may be fetched. Null when not set, which allows both.

      - `user_input: BetaManagedAgentsWebFetchURLSourceUserInput or null`

        Whether URLs in the text of user messages may be fetched. Null when not set, which allows them.

        - `BetaManagedAgentsWebFetchURLSourceAll object`

          Every URL from this source may be fetched. This is the default.

        - `BetaManagedAgentsWebFetchURLSourceNone object`

          This source contributes no URLs that may be fetched.

    - `allowed_domains: optional array of string`

    - `blocked_domains: optional array of string`

    - `max_content_tokens: optional number or null`

      format: int32

  - `BetaManagedAgentsWebSearchToolConfig object`

    Configuration for the web_search tool.

    - `type: "web_search"`

    - `enabled: boolean`

    - `name: "web_search"`

    - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

      Permission policy for tool execution.

      - `BetaManagedAgentsAlwaysAllowPolicy object`

        Tool calls are automatically approved without user confirmation.

      - `BetaManagedAgentsAlwaysAskPolicy object`

        Tool calls require user confirmation before execution.

      - `BetaManagedAgentsAutoPolicy object`

        The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

    - `allowed_domains: optional array of string`

    - `blocked_domains: optional array of string`

    - `user_location: optional BetaManagedAgentsUserLocation or null`

      Approximate user location for search result localization.

      - `type: "approximate"`

        Location precision. Only "approximate" is supported.

      - `city: optional string or null`

        City name.

        minLength: 1, maxLength: 255

      - `country: optional string or null`

        Two-letter ISO 3166-1 country code, uppercase.

      - `region: optional string or null`

        Region or state name.

        minLength: 1, maxLength: 255

      - `timezone: optional string or null`

        IANA timezone identifier, e.g. "America/Los_Angeles".

        minLength: 1, maxLength: 255

### Beta Managed Agents Agent Tool Config Params

- `BetaManagedAgentsAgentToolConfigParams = BetaManagedAgentsBashToolConfigParams or BetaManagedAgentsEditToolConfigParams or BetaManagedAgentsReadToolConfigParams or 5 more`

  Configuration override for a specific tool within a toolset.

  - `BetaManagedAgentsBashToolConfigParams object`

    Configuration override for the bash tool.

    - `type: optional "bash"`

    - `name: "bash"`

      Must be "bash".

    - `enabled: optional boolean or null`

      Whether this tool is enabled and available to Claude. Overrides the default_config setting.

    - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

      Permission policy for this tool. Controls whether tool calls are auto-approved or require confirmation.

      - `BetaManagedAgentsAlwaysAllowPolicy object`

        Tool calls are automatically approved without user confirmation.

        - `type: "always_allow"`

      - `BetaManagedAgentsAlwaysAskPolicy object`

        Tool calls require user confirmation before execution.

        - `type: "always_ask"`

      - `BetaManagedAgentsAutoPolicy object`

        The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

        - `type: "auto"`

  - `BetaManagedAgentsEditToolConfigParams object`

    Configuration override for the edit tool.

    - `type: optional "edit"`

    - `name: "edit"`

      Must be "edit".

    - `enabled: optional boolean or null`

      Whether this tool is enabled and available to Claude. Overrides the default_config setting.

    - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

      Permission policy for this tool. Controls whether tool calls are auto-approved or require confirmation.

      - `BetaManagedAgentsAlwaysAllowPolicy object`

        Tool calls are automatically approved without user confirmation.

      - `BetaManagedAgentsAlwaysAskPolicy object`

        Tool calls require user confirmation before execution.

      - `BetaManagedAgentsAutoPolicy object`

        The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

  - `BetaManagedAgentsReadToolConfigParams object`

    Configuration override for the read tool.

    - `type: optional "read"`

    - `name: "read"`

      Must be "read".

    - `enabled: optional boolean or null`

      Whether this tool is enabled and available to Claude. Overrides the default_config setting.

    - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

      Permission policy for this tool. Controls whether tool calls are auto-approved or require confirmation.

      - `BetaManagedAgentsAlwaysAllowPolicy object`

        Tool calls are automatically approved without user confirmation.

      - `BetaManagedAgentsAlwaysAskPolicy object`

        Tool calls require user confirmation before execution.

      - `BetaManagedAgentsAutoPolicy object`

        The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

  - `BetaManagedAgentsWriteToolConfigParams object`

    Configuration override for the write tool.

    - `type: optional "write"`

    - `name: "write"`

      Must be "write".

    - `enabled: optional boolean or null`

      Whether this tool is enabled and available to Claude. Overrides the default_config setting.

    - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

      Permission policy for this tool. Controls whether tool calls are auto-approved or require confirmation.

      - `BetaManagedAgentsAlwaysAllowPolicy object`

        Tool calls are automatically approved without user confirmation.

      - `BetaManagedAgentsAlwaysAskPolicy object`

        Tool calls require user confirmation before execution.

      - `BetaManagedAgentsAutoPolicy object`

        The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

  - `BetaManagedAgentsGlobToolConfigParams object`

    Configuration override for the glob tool.

    - `type: optional "glob"`

    - `name: "glob"`

      Must be "glob".

    - `enabled: optional boolean or null`

      Whether this tool is enabled and available to Claude. Overrides the default_config setting.

    - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

      Permission policy for this tool. Controls whether tool calls are auto-approved or require confirmation.

      - `BetaManagedAgentsAlwaysAllowPolicy object`

        Tool calls are automatically approved without user confirmation.

      - `BetaManagedAgentsAlwaysAskPolicy object`

        Tool calls require user confirmation before execution.

      - `BetaManagedAgentsAutoPolicy object`

        The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

  - `BetaManagedAgentsGrepToolConfigParams object`

    Configuration override for the grep tool.

    - `type: optional "grep"`

    - `name: "grep"`

      Must be "grep".

    - `enabled: optional boolean or null`

      Whether this tool is enabled and available to Claude. Overrides the default_config setting.

    - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

      Permission policy for this tool. Controls whether tool calls are auto-approved or require confirmation.

      - `BetaManagedAgentsAlwaysAllowPolicy object`

        Tool calls are automatically approved without user confirmation.

      - `BetaManagedAgentsAlwaysAskPolicy object`

        Tool calls require user confirmation before execution.

      - `BetaManagedAgentsAutoPolicy object`

        The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

  - `BetaManagedAgentsWebFetchToolConfigParams object`

    Configuration override for the web_fetch tool.

    - `type: optional "web_fetch"`

    - `name: "web_fetch"`

      Must be "web_fetch".

    - `allowed_domains: optional array of string`

      Only fetch URLs whose host is one of these domains or a subdomain of one. Each entry is a plain hostname like "docs.example.com" (no scheme, port, or path). At most 64 entries; an empty list is rejected (omit the field instead). Cannot be combined with blocked_domains.

    - `blocked_domains: optional array of string`

      Never fetch URLs whose host is one of these domains or a subdomain of one. Each entry is a plain hostname like "ads.example.com" (no scheme, port, or path). At most 64 entries; an empty list is rejected (omit the field instead). Cannot be combined with allowed_domains.

    - `enabled: optional boolean or null`

      Whether this tool is enabled and available to Claude. Overrides the default_config setting.

    - `max_content_tokens: optional number or null`

      Maximum number of tokens of fetched text content to include in context per call. Does not apply to binary content such as PDFs.

      format: int32

    - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

      Permission policy for this tool. Controls whether tool calls are auto-approved or require confirmation.

      - `BetaManagedAgentsAlwaysAllowPolicy object`

        Tool calls are automatically approved without user confirmation.

      - `BetaManagedAgentsAlwaysAskPolicy object`

        Tool calls require user confirmation before execution.

      - `BetaManagedAgentsAutoPolicy object`

        The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

    - `url_sources: optional BetaManagedAgentsWebFetchURLSourcesParams or null`

      Which sources contribute URLs the tool may fetch. Omit to allow every source.

      - `client_tool_results: optional BetaManagedAgentsWebFetchURLSourceToolFilterParams or null`

        Which custom tools' results contribute URLs that may be fetched: "all" (the default), "none", or an only or except list. Each name in a list must be a custom tool in the same tools array.

        - `BetaManagedAgentsWebFetchURLSourceShorthand = "all" or "none"`

          String form of a url_sources value that has no field other than its type: "all" means {"type": "all"} and "none" means {"type": "none"}.

          - `"all"`

          - `"none"`

        - `BetaManagedAgentsWebFetchURLSourceToolFilter = BetaManagedAgentsWebFetchURLSourceAll or BetaManagedAgentsWebFetchURLSourceNone or BetaManagedAgentsWebFetchURLSourceOnly or BetaManagedAgentsWebFetchURLSourceExcept`

          Which tools' results contribute URLs that may be fetched.

          - `BetaManagedAgentsWebFetchURLSourceAll object`

            Every URL from this source may be fetched. This is the default.

            - `type: "all"`

          - `BetaManagedAgentsWebFetchURLSourceNone object`

            This source contributes no URLs that may be fetched.

            - `type: "none"`

          - `BetaManagedAgentsWebFetchURLSourceOnly object`

            Only the named tools' results contribute URLs that may be fetched.

            - `type: "only"`

            - `tools: array of BetaManagedAgentsWebFetchURLSourceToolReference`

              The tools whose results contribute. Between 1 and 128 entries, each with a different name. An empty list is rejected; use "none" to allow no tool's results.

              - `type: "tool_reference"`

                Must be "tool_reference".

              - `name: string`

                Name of the tool. Compared exactly, so upper and lower case letters are different.

                minLength: 1, maxLength: 128

          - `BetaManagedAgentsWebFetchURLSourceExcept object`

            Every tool's results contribute URLs that may be fetched, except the named tools' results.

            - `type: "except"`

            - `tools: array of BetaManagedAgentsWebFetchURLSourceToolReference`

              The tools whose results do not contribute. Between 1 and 128 entries, each with a different name. An empty list is rejected; use "all" to leave out no tool's results.

              - `type: "tool_reference"`

                Must be "tool_reference".

              - `name: string`

                Name of the tool. Compared exactly, so upper and lower case letters are different.

                minLength: 1, maxLength: 128

      - `server_tool_results: optional BetaManagedAgentsWebFetchURLSourceToolFilterParams or null`

        Which of the web_search and web_fetch tools' results contribute URLs that may be fetched: "all" (the default), "none", or an only or except list. Each name in a list must be "web_search" or "web_fetch".

      - `user_input: optional BetaManagedAgentsWebFetchURLSourceUserInputParams or null`

        Whether URLs in the text of user messages may be fetched: "all" (the default) or "none".

        - `BetaManagedAgentsWebFetchURLSourceShorthand = "all" or "none"`

          String form of a url_sources value that has no field other than its type: "all" means {"type": "all"} and "none" means {"type": "none"}.

        - `BetaManagedAgentsWebFetchURLSourceUserInput = BetaManagedAgentsWebFetchURLSourceAll or BetaManagedAgentsWebFetchURLSourceNone`

          Whether URLs in the text of user messages may be fetched.

          - `BetaManagedAgentsWebFetchURLSourceAll object`

            Every URL from this source may be fetched. This is the default.

          - `BetaManagedAgentsWebFetchURLSourceNone object`

            This source contributes no URLs that may be fetched.

  - `BetaManagedAgentsWebSearchToolConfigParams object`

    Configuration override for the web_search tool.

    - `type: optional "web_search"`

    - `name: "web_search"`

      Must be "web_search".

    - `allowed_domains: optional array of string`

      Only return search results whose host is one of these domains or a subdomain of one. Each entry is a plain hostname like "docs.example.com" (no scheme or port; an optional path suffix is accepted). At most 64 entries; an empty list is rejected (omit the field instead). Cannot be combined with blocked_domains.

    - `blocked_domains: optional array of string`

      Never return search results whose host is one of these domains or a subdomain of one. Each entry is a plain hostname like "ads.example.com" (no scheme or port; an optional path suffix is accepted). At most 64 entries; an empty list is rejected (omit the field instead). Cannot be combined with allowed_domains.

    - `enabled: optional boolean or null`

      Whether this tool is enabled and available to Claude. Overrides the default_config setting.

    - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

      Permission policy for this tool. Controls whether tool calls are auto-approved or require confirmation.

      - `BetaManagedAgentsAlwaysAllowPolicy object`

        Tool calls are automatically approved without user confirmation.

      - `BetaManagedAgentsAlwaysAskPolicy object`

        Tool calls require user confirmation before execution.

      - `BetaManagedAgentsAutoPolicy object`

        The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

    - `user_location: optional BetaManagedAgentsUserLocation or null`

      Approximate user location for search result localization.

      - `type: "approximate"`

        Location precision. Only "approximate" is supported.

      - `city: optional string or null`

        City name.

        minLength: 1, maxLength: 255

      - `country: optional string or null`

        Two-letter ISO 3166-1 country code, uppercase.

      - `region: optional string or null`

        Region or state name.

        minLength: 1, maxLength: 255

      - `timezone: optional string or null`

        IANA timezone identifier, e.g. "America/Los_Angeles".

        minLength: 1, maxLength: 255

### Beta Managed Agents Agent Toolset Default Config

- `BetaManagedAgentsAgentToolsetDefaultConfig object`

  Resolved default configuration for agent tools.

  - `enabled: boolean`

  - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

    Permission policy for tool execution.

    - `BetaManagedAgentsAlwaysAllowPolicy object`

      Tool calls are automatically approved without user confirmation.

      - `type: "always_allow"`

    - `BetaManagedAgentsAlwaysAskPolicy object`

      Tool calls require user confirmation before execution.

      - `type: "always_ask"`

    - `BetaManagedAgentsAutoPolicy object`

      The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

      - `type: "auto"`

### Beta Managed Agents Agent Toolset Default Config Params

- `BetaManagedAgentsAgentToolsetDefaultConfigParams object`

  Default configuration for all tools in a toolset.

  - `enabled: optional boolean or null`

    Whether tools are enabled and available to Claude by default. Defaults to true if not specified.

  - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

    Default permission policy for tools. Controls whether tool calls are auto-approved or require confirmation.

    - `BetaManagedAgentsAlwaysAllowPolicy object`

      Tool calls are automatically approved without user confirmation.

      - `type: "always_allow"`

    - `BetaManagedAgentsAlwaysAskPolicy object`

      Tool calls require user confirmation before execution.

      - `type: "always_ask"`

    - `BetaManagedAgentsAutoPolicy object`

      The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

      - `type: "auto"`

### Beta Managed Agents Agent Toolset20260401

- `BetaManagedAgentsAgentToolset20260401 object`

  - `type: "agent_toolset_20260401"`

  - `configs: array of BetaManagedAgentsAgentToolConfig`

    - `BetaManagedAgentsBashToolConfig object`

      Configuration for the bash tool.

      - `type: "bash"`

      - `enabled: boolean`

      - `name: "bash"`

      - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

        Permission policy for tool execution.

        - `BetaManagedAgentsAlwaysAllowPolicy object`

          Tool calls are automatically approved without user confirmation.

          - `type: "always_allow"`

        - `BetaManagedAgentsAlwaysAskPolicy object`

          Tool calls require user confirmation before execution.

          - `type: "always_ask"`

        - `BetaManagedAgentsAutoPolicy object`

          The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

          - `type: "auto"`

    - `BetaManagedAgentsEditToolConfig object`

      Configuration for the edit tool.

      - `type: "edit"`

      - `enabled: boolean`

      - `name: "edit"`

      - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

        Permission policy for tool execution.

        - `BetaManagedAgentsAlwaysAllowPolicy object`

          Tool calls are automatically approved without user confirmation.

        - `BetaManagedAgentsAlwaysAskPolicy object`

          Tool calls require user confirmation before execution.

        - `BetaManagedAgentsAutoPolicy object`

          The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

    - `BetaManagedAgentsReadToolConfig object`

      Configuration for the read tool.

      - `type: "read"`

      - `enabled: boolean`

      - `name: "read"`

      - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

        Permission policy for tool execution.

        - `BetaManagedAgentsAlwaysAllowPolicy object`

          Tool calls are automatically approved without user confirmation.

        - `BetaManagedAgentsAlwaysAskPolicy object`

          Tool calls require user confirmation before execution.

        - `BetaManagedAgentsAutoPolicy object`

          The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

    - `BetaManagedAgentsWriteToolConfig object`

      Configuration for the write tool.

      - `type: "write"`

      - `enabled: boolean`

      - `name: "write"`

      - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

        Permission policy for tool execution.

        - `BetaManagedAgentsAlwaysAllowPolicy object`

          Tool calls are automatically approved without user confirmation.

        - `BetaManagedAgentsAlwaysAskPolicy object`

          Tool calls require user confirmation before execution.

        - `BetaManagedAgentsAutoPolicy object`

          The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

    - `BetaManagedAgentsGlobToolConfig object`

      Configuration for the glob tool.

      - `type: "glob"`

      - `enabled: boolean`

      - `name: "glob"`

      - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

        Permission policy for tool execution.

        - `BetaManagedAgentsAlwaysAllowPolicy object`

          Tool calls are automatically approved without user confirmation.

        - `BetaManagedAgentsAlwaysAskPolicy object`

          Tool calls require user confirmation before execution.

        - `BetaManagedAgentsAutoPolicy object`

          The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

    - `BetaManagedAgentsGrepToolConfig object`

      Configuration for the grep tool.

      - `type: "grep"`

      - `enabled: boolean`

      - `name: "grep"`

      - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

        Permission policy for tool execution.

        - `BetaManagedAgentsAlwaysAllowPolicy object`

          Tool calls are automatically approved without user confirmation.

        - `BetaManagedAgentsAlwaysAskPolicy object`

          Tool calls require user confirmation before execution.

        - `BetaManagedAgentsAutoPolicy object`

          The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

    - `BetaManagedAgentsWebFetchToolConfig object`

      Configuration for the web_fetch tool.

      - `type: "web_fetch"`

      - `enabled: boolean`

      - `name: "web_fetch"`

      - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

        Permission policy for tool execution.

        - `BetaManagedAgentsAlwaysAllowPolicy object`

          Tool calls are automatically approved without user confirmation.

        - `BetaManagedAgentsAlwaysAskPolicy object`

          Tool calls require user confirmation before execution.

        - `BetaManagedAgentsAutoPolicy object`

          The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

      - `url_sources: BetaManagedAgentsWebFetchURLSources or null`

        Which sources contribute URLs the tool may fetch, always in the object form. Null when not set, which allows every source.

        - `client_tool_results: BetaManagedAgentsWebFetchURLSourceToolFilter or null`

          Which custom tools' results contribute URLs that may be fetched. Null when not set, which allows every custom tool's results.

          - `BetaManagedAgentsWebFetchURLSourceAll object`

            Every URL from this source may be fetched. This is the default.

            - `type: "all"`

          - `BetaManagedAgentsWebFetchURLSourceNone object`

            This source contributes no URLs that may be fetched.

            - `type: "none"`

          - `BetaManagedAgentsWebFetchURLSourceOnly object`

            Only the named tools' results contribute URLs that may be fetched.

            - `type: "only"`

            - `tools: array of BetaManagedAgentsWebFetchURLSourceToolReference`

              The tools whose results contribute. Between 1 and 128 entries, each with a different name. An empty list is rejected; use "none" to allow no tool's results.

              - `type: "tool_reference"`

                Must be "tool_reference".

              - `name: string`

                Name of the tool. Compared exactly, so upper and lower case letters are different.

                minLength: 1, maxLength: 128

          - `BetaManagedAgentsWebFetchURLSourceExcept object`

            Every tool's results contribute URLs that may be fetched, except the named tools' results.

            - `type: "except"`

            - `tools: array of BetaManagedAgentsWebFetchURLSourceToolReference`

              The tools whose results do not contribute. Between 1 and 128 entries, each with a different name. An empty list is rejected; use "all" to leave out no tool's results.

              - `type: "tool_reference"`

                Must be "tool_reference".

              - `name: string`

                Name of the tool. Compared exactly, so upper and lower case letters are different.

                minLength: 1, maxLength: 128

        - `server_tool_results: BetaManagedAgentsWebFetchURLSourceToolFilter or null`

          Which of the web_search and web_fetch tools' results contribute URLs that may be fetched. Null when not set, which allows both.

        - `user_input: BetaManagedAgentsWebFetchURLSourceUserInput or null`

          Whether URLs in the text of user messages may be fetched. Null when not set, which allows them.

          - `BetaManagedAgentsWebFetchURLSourceAll object`

            Every URL from this source may be fetched. This is the default.

          - `BetaManagedAgentsWebFetchURLSourceNone object`

            This source contributes no URLs that may be fetched.

      - `allowed_domains: optional array of string`

      - `blocked_domains: optional array of string`

      - `max_content_tokens: optional number or null`

        format: int32

    - `BetaManagedAgentsWebSearchToolConfig object`

      Configuration for the web_search tool.

      - `type: "web_search"`

      - `enabled: boolean`

      - `name: "web_search"`

      - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

        Permission policy for tool execution.

        - `BetaManagedAgentsAlwaysAllowPolicy object`

          Tool calls are automatically approved without user confirmation.

        - `BetaManagedAgentsAlwaysAskPolicy object`

          Tool calls require user confirmation before execution.

        - `BetaManagedAgentsAutoPolicy object`

          The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

      - `allowed_domains: optional array of string`

      - `blocked_domains: optional array of string`

      - `user_location: optional BetaManagedAgentsUserLocation or null`

        Approximate user location for search result localization.

        - `type: "approximate"`

          Location precision. Only "approximate" is supported.

        - `city: optional string or null`

          City name.

          minLength: 1, maxLength: 255

        - `country: optional string or null`

          Two-letter ISO 3166-1 country code, uppercase.

        - `region: optional string or null`

          Region or state name.

          minLength: 1, maxLength: 255

        - `timezone: optional string or null`

          IANA timezone identifier, e.g. "America/Los_Angeles".

          minLength: 1, maxLength: 255

  - `default_config: BetaManagedAgentsAgentToolsetDefaultConfig`

    Resolved default configuration for agent tools.

    - `enabled: boolean`

    - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

      Permission policy for tool execution.

      - `BetaManagedAgentsAlwaysAllowPolicy object`

        Tool calls are automatically approved without user confirmation.

      - `BetaManagedAgentsAlwaysAskPolicy object`

        Tool calls require user confirmation before execution.

      - `BetaManagedAgentsAutoPolicy object`

        The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

### Beta Managed Agents Agent Toolset20260401 Bash Input

- `BetaManagedAgentsAgentToolset20260401BashInput object`

  Input payload for the `bash` tool of the
  `agent_toolset_20260401` toolset. All fields are optional;
  a normal invocation supplies `command`, while `restart=true`
  (with no `command`) reboots the runner-side bash session.

  - `command: optional string`

    Shell command to execute. Omit only when `restart` is true.

  - `restart: optional boolean`

    When true, restart the persistent bash session instead of
    running a command. Subsequent calls without `restart` will
    run against the fresh session.

  - `timeout_ms: optional number`

    Per-call timeout in milliseconds. Defaults to the
    runner-wide tool timeout when omitted or zero.

    minimum: 0

### Beta Managed Agents Agent Toolset20260401 Edit Input

- `BetaManagedAgentsAgentToolset20260401EditInput object`

  Input payload for the `edit` tool. Performs a string
  replacement in the named file; by default `old_string` must
  occur exactly once.

  - `file_path: string`

    Path of the file to edit.

  - `new_string: string`

    Replacement text.

  - `old_string: string`

    Substring to find and replace.

  - `replace_all: optional boolean`

    When true, replace every occurrence of `old_string`
    instead of requiring a unique match.

### Beta Managed Agents Agent Toolset20260401 Glob Input

- `BetaManagedAgentsAgentToolset20260401GlobInput object`

  Input payload for the `glob` tool. Returns paths matching a
  doublestar glob pattern, newest first.

  - `pattern: string`

    Doublestar glob pattern (e.g. `**/*.go`). Absolute patterns
    are only permitted when the runner is configured to allow
    them.

  - `path: optional string`

    Optional directory root to search under. Defaults to the
    runner's working directory.

### Beta Managed Agents Agent Toolset20260401 Grep Input

- `BetaManagedAgentsAgentToolset20260401GrepInput object`

  Input payload for the `grep` tool. Searches file contents for
  a regular expression, returning matching lines.

  - `pattern: string`

    Regular expression to search for.

  - `path: optional string`

    Optional directory root to search under. Defaults to the
    runner's working directory.

### Beta Managed Agents Agent Toolset20260401 Params

- `BetaManagedAgentsAgentToolset20260401Params object`

  Configuration for built-in agent tools. Use this to enable or disable groups of tools available to the agent.

  - `type: "agent_toolset_20260401"`

  - `configs: optional array of BetaManagedAgentsAgentToolConfigParams`

    Per-tool configuration overrides.

    - `BetaManagedAgentsBashToolConfigParams object`

      Configuration override for the bash tool.

      - `type: optional "bash"`

      - `name: "bash"`

        Must be "bash".

      - `enabled: optional boolean or null`

        Whether this tool is enabled and available to Claude. Overrides the default_config setting.

      - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

        Permission policy for this tool. Controls whether tool calls are auto-approved or require confirmation.

        - `BetaManagedAgentsAlwaysAllowPolicy object`

          Tool calls are automatically approved without user confirmation.

          - `type: "always_allow"`

        - `BetaManagedAgentsAlwaysAskPolicy object`

          Tool calls require user confirmation before execution.

          - `type: "always_ask"`

        - `BetaManagedAgentsAutoPolicy object`

          The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

          - `type: "auto"`

    - `BetaManagedAgentsEditToolConfigParams object`

      Configuration override for the edit tool.

      - `type: optional "edit"`

      - `name: "edit"`

        Must be "edit".

      - `enabled: optional boolean or null`

        Whether this tool is enabled and available to Claude. Overrides the default_config setting.

      - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

        Permission policy for this tool. Controls whether tool calls are auto-approved or require confirmation.

        - `BetaManagedAgentsAlwaysAllowPolicy object`

          Tool calls are automatically approved without user confirmation.

        - `BetaManagedAgentsAlwaysAskPolicy object`

          Tool calls require user confirmation before execution.

        - `BetaManagedAgentsAutoPolicy object`

          The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

    - `BetaManagedAgentsReadToolConfigParams object`

      Configuration override for the read tool.

      - `type: optional "read"`

      - `name: "read"`

        Must be "read".

      - `enabled: optional boolean or null`

        Whether this tool is enabled and available to Claude. Overrides the default_config setting.

      - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

        Permission policy for this tool. Controls whether tool calls are auto-approved or require confirmation.

        - `BetaManagedAgentsAlwaysAllowPolicy object`

          Tool calls are automatically approved without user confirmation.

        - `BetaManagedAgentsAlwaysAskPolicy object`

          Tool calls require user confirmation before execution.

        - `BetaManagedAgentsAutoPolicy object`

          The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

    - `BetaManagedAgentsWriteToolConfigParams object`

      Configuration override for the write tool.

      - `type: optional "write"`

      - `name: "write"`

        Must be "write".

      - `enabled: optional boolean or null`

        Whether this tool is enabled and available to Claude. Overrides the default_config setting.

      - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

        Permission policy for this tool. Controls whether tool calls are auto-approved or require confirmation.

        - `BetaManagedAgentsAlwaysAllowPolicy object`

          Tool calls are automatically approved without user confirmation.

        - `BetaManagedAgentsAlwaysAskPolicy object`

          Tool calls require user confirmation before execution.

        - `BetaManagedAgentsAutoPolicy object`

          The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

    - `BetaManagedAgentsGlobToolConfigParams object`

      Configuration override for the glob tool.

      - `type: optional "glob"`

      - `name: "glob"`

        Must be "glob".

      - `enabled: optional boolean or null`

        Whether this tool is enabled and available to Claude. Overrides the default_config setting.

      - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

        Permission policy for this tool. Controls whether tool calls are auto-approved or require confirmation.

        - `BetaManagedAgentsAlwaysAllowPolicy object`

          Tool calls are automatically approved without user confirmation.

        - `BetaManagedAgentsAlwaysAskPolicy object`

          Tool calls require user confirmation before execution.

        - `BetaManagedAgentsAutoPolicy object`

          The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

    - `BetaManagedAgentsGrepToolConfigParams object`

      Configuration override for the grep tool.

      - `type: optional "grep"`

      - `name: "grep"`

        Must be "grep".

      - `enabled: optional boolean or null`

        Whether this tool is enabled and available to Claude. Overrides the default_config setting.

      - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

        Permission policy for this tool. Controls whether tool calls are auto-approved or require confirmation.

        - `BetaManagedAgentsAlwaysAllowPolicy object`

          Tool calls are automatically approved without user confirmation.

        - `BetaManagedAgentsAlwaysAskPolicy object`

          Tool calls require user confirmation before execution.

        - `BetaManagedAgentsAutoPolicy object`

          The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

    - `BetaManagedAgentsWebFetchToolConfigParams object`

      Configuration override for the web_fetch tool.

      - `type: optional "web_fetch"`

      - `name: "web_fetch"`

        Must be "web_fetch".

      - `allowed_domains: optional array of string`

        Only fetch URLs whose host is one of these domains or a subdomain of one. Each entry is a plain hostname like "docs.example.com" (no scheme, port, or path). At most 64 entries; an empty list is rejected (omit the field instead). Cannot be combined with blocked_domains.

      - `blocked_domains: optional array of string`

        Never fetch URLs whose host is one of these domains or a subdomain of one. Each entry is a plain hostname like "ads.example.com" (no scheme, port, or path). At most 64 entries; an empty list is rejected (omit the field instead). Cannot be combined with allowed_domains.

      - `enabled: optional boolean or null`

        Whether this tool is enabled and available to Claude. Overrides the default_config setting.

      - `max_content_tokens: optional number or null`

        Maximum number of tokens of fetched text content to include in context per call. Does not apply to binary content such as PDFs.

        format: int32

      - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

        Permission policy for this tool. Controls whether tool calls are auto-approved or require confirmation.

        - `BetaManagedAgentsAlwaysAllowPolicy object`

          Tool calls are automatically approved without user confirmation.

        - `BetaManagedAgentsAlwaysAskPolicy object`

          Tool calls require user confirmation before execution.

        - `BetaManagedAgentsAutoPolicy object`

          The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

      - `url_sources: optional BetaManagedAgentsWebFetchURLSourcesParams or null`

        Which sources contribute URLs the tool may fetch. Omit to allow every source.

        - `client_tool_results: optional BetaManagedAgentsWebFetchURLSourceToolFilterParams or null`

          Which custom tools' results contribute URLs that may be fetched: "all" (the default), "none", or an only or except list. Each name in a list must be a custom tool in the same tools array.

          - `BetaManagedAgentsWebFetchURLSourceShorthand = "all" or "none"`

            String form of a url_sources value that has no field other than its type: "all" means {"type": "all"} and "none" means {"type": "none"}.

            - `"all"`

            - `"none"`

          - `BetaManagedAgentsWebFetchURLSourceToolFilter = BetaManagedAgentsWebFetchURLSourceAll or BetaManagedAgentsWebFetchURLSourceNone or BetaManagedAgentsWebFetchURLSourceOnly or BetaManagedAgentsWebFetchURLSourceExcept`

            Which tools' results contribute URLs that may be fetched.

            - `BetaManagedAgentsWebFetchURLSourceAll object`

              Every URL from this source may be fetched. This is the default.

              - `type: "all"`

            - `BetaManagedAgentsWebFetchURLSourceNone object`

              This source contributes no URLs that may be fetched.

              - `type: "none"`

            - `BetaManagedAgentsWebFetchURLSourceOnly object`

              Only the named tools' results contribute URLs that may be fetched.

              - `type: "only"`

              - `tools: array of BetaManagedAgentsWebFetchURLSourceToolReference`

                The tools whose results contribute. Between 1 and 128 entries, each with a different name. An empty list is rejected; use "none" to allow no tool's results.

                - `type: "tool_reference"`

                  Must be "tool_reference".

                - `name: string`

                  Name of the tool. Compared exactly, so upper and lower case letters are different.

                  minLength: 1, maxLength: 128

            - `BetaManagedAgentsWebFetchURLSourceExcept object`

              Every tool's results contribute URLs that may be fetched, except the named tools' results.

              - `type: "except"`

              - `tools: array of BetaManagedAgentsWebFetchURLSourceToolReference`

                The tools whose results do not contribute. Between 1 and 128 entries, each with a different name. An empty list is rejected; use "all" to leave out no tool's results.

                - `type: "tool_reference"`

                  Must be "tool_reference".

                - `name: string`

                  Name of the tool. Compared exactly, so upper and lower case letters are different.

                  minLength: 1, maxLength: 128

        - `server_tool_results: optional BetaManagedAgentsWebFetchURLSourceToolFilterParams or null`

          Which of the web_search and web_fetch tools' results contribute URLs that may be fetched: "all" (the default), "none", or an only or except list. Each name in a list must be "web_search" or "web_fetch".

        - `user_input: optional BetaManagedAgentsWebFetchURLSourceUserInputParams or null`

          Whether URLs in the text of user messages may be fetched: "all" (the default) or "none".

          - `BetaManagedAgentsWebFetchURLSourceShorthand = "all" or "none"`

            String form of a url_sources value that has no field other than its type: "all" means {"type": "all"} and "none" means {"type": "none"}.

          - `BetaManagedAgentsWebFetchURLSourceUserInput = BetaManagedAgentsWebFetchURLSourceAll or BetaManagedAgentsWebFetchURLSourceNone`

            Whether URLs in the text of user messages may be fetched.

            - `BetaManagedAgentsWebFetchURLSourceAll object`

              Every URL from this source may be fetched. This is the default.

            - `BetaManagedAgentsWebFetchURLSourceNone object`

              This source contributes no URLs that may be fetched.

    - `BetaManagedAgentsWebSearchToolConfigParams object`

      Configuration override for the web_search tool.

      - `type: optional "web_search"`

      - `name: "web_search"`

        Must be "web_search".

      - `allowed_domains: optional array of string`

        Only return search results whose host is one of these domains or a subdomain of one. Each entry is a plain hostname like "docs.example.com" (no scheme or port; an optional path suffix is accepted). At most 64 entries; an empty list is rejected (omit the field instead). Cannot be combined with blocked_domains.

      - `blocked_domains: optional array of string`

        Never return search results whose host is one of these domains or a subdomain of one. Each entry is a plain hostname like "ads.example.com" (no scheme or port; an optional path suffix is accepted). At most 64 entries; an empty list is rejected (omit the field instead). Cannot be combined with allowed_domains.

      - `enabled: optional boolean or null`

        Whether this tool is enabled and available to Claude. Overrides the default_config setting.

      - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

        Permission policy for this tool. Controls whether tool calls are auto-approved or require confirmation.

        - `BetaManagedAgentsAlwaysAllowPolicy object`

          Tool calls are automatically approved without user confirmation.

        - `BetaManagedAgentsAlwaysAskPolicy object`

          Tool calls require user confirmation before execution.

        - `BetaManagedAgentsAutoPolicy object`

          The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

      - `user_location: optional BetaManagedAgentsUserLocation or null`

        Approximate user location for search result localization.

        - `type: "approximate"`

          Location precision. Only "approximate" is supported.

        - `city: optional string or null`

          City name.

          minLength: 1, maxLength: 255

        - `country: optional string or null`

          Two-letter ISO 3166-1 country code, uppercase.

        - `region: optional string or null`

          Region or state name.

          minLength: 1, maxLength: 255

        - `timezone: optional string or null`

          IANA timezone identifier, e.g. "America/Los_Angeles".

          minLength: 1, maxLength: 255

  - `default_config: optional BetaManagedAgentsAgentToolsetDefaultConfigParams or null`

    Default configuration applied to all tools in this set.

    - `enabled: optional boolean or null`

      Whether tools are enabled and available to Claude by default. Defaults to true if not specified.

    - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

      Default permission policy for tools. Controls whether tool calls are auto-approved or require confirmation.

      - `BetaManagedAgentsAlwaysAllowPolicy object`

        Tool calls are automatically approved without user confirmation.

      - `BetaManagedAgentsAlwaysAskPolicy object`

        Tool calls require user confirmation before execution.

      - `BetaManagedAgentsAutoPolicy object`

        The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

### Beta Managed Agents Agent Toolset20260401 Read Input

- `BetaManagedAgentsAgentToolset20260401ReadInput object`

  Input payload for the `read` tool. Reads file contents
  relative to the runner's working directory (or absolute when
  the runner permits).

  - `file_path: string`

    Path of the file to read.

  - `view_range: optional array of number`

    Optional `[start_line, end_line]` 1-indexed inclusive
    range. When omitted the entire file is returned.
    `end_line` of 0 or negative means "to end of file".

    minItems: 2, maxItems: 2

### Beta Managed Agents Agent Toolset20260401 Write Input

- `BetaManagedAgentsAgentToolset20260401WriteInput object`

  Input payload for the `write` tool. Writes (overwriting) the
  entire file contents.

  - `content: string`

    Full file contents to write.

  - `file_path: string`

    Path of the file to write.

### Beta Managed Agents Always Allow Policy

- `BetaManagedAgentsAlwaysAllowPolicy object`

  Tool calls are automatically approved without user confirmation.

  - `type: "always_allow"`

### Beta Managed Agents Always Ask Policy

- `BetaManagedAgentsAlwaysAskPolicy object`

  Tool calls require user confirmation before execution.

  - `type: "always_ask"`

### Beta Managed Agents Anthropic Skill

- `BetaManagedAgentsAnthropicSkill object`

  A resolved Anthropic-managed skill.

  - `type: "anthropic"`

  - `skill_id: string`

  - `version: string`

### Beta Managed Agents Anthropic Skill Params

- `BetaManagedAgentsAnthropicSkillParams object`

  An Anthropic-managed skill.

  - `type: "anthropic"`

  - `skill_id: string`

    Identifier of the Anthropic skill (e.g., "xlsx").

    minLength: 1, maxLength: 64

  - `version: optional string or null`

    Version to pin. Defaults to latest if omitted.

    minLength: 1, maxLength: 64

### Beta Managed Agents Auto Policy

- `BetaManagedAgentsAutoPolicy object`

  The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

  - `type: "auto"`

### Beta Managed Agents Bash Tool Config

- `BetaManagedAgentsBashToolConfig object`

  Configuration for the bash tool.

  - `type: "bash"`

  - `enabled: boolean`

  - `name: "bash"`

  - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

    Permission policy for tool execution.

    - `BetaManagedAgentsAlwaysAllowPolicy object`

      Tool calls are automatically approved without user confirmation.

      - `type: "always_allow"`

    - `BetaManagedAgentsAlwaysAskPolicy object`

      Tool calls require user confirmation before execution.

      - `type: "always_ask"`

    - `BetaManagedAgentsAutoPolicy object`

      The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

      - `type: "auto"`

### Beta Managed Agents Bash Tool Config Params

- `BetaManagedAgentsBashToolConfigParams object`

  Configuration override for the bash tool.

  - `type: optional "bash"`

  - `name: "bash"`

    Must be "bash".

  - `enabled: optional boolean or null`

    Whether this tool is enabled and available to Claude. Overrides the default_config setting.

  - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

    Permission policy for this tool. Controls whether tool calls are auto-approved or require confirmation.

    - `BetaManagedAgentsAlwaysAllowPolicy object`

      Tool calls are automatically approved without user confirmation.

      - `type: "always_allow"`

    - `BetaManagedAgentsAlwaysAskPolicy object`

      Tool calls require user confirmation before execution.

      - `type: "always_ask"`

    - `BetaManagedAgentsAutoPolicy object`

      The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

      - `type: "auto"`

### Beta Managed Agents Custom Skill

- `BetaManagedAgentsCustomSkill object`

  A resolved user-created custom skill.

  - `type: "custom"`

  - `skill_id: string`

  - `version: string`

### Beta Managed Agents Custom Skill Params

- `BetaManagedAgentsCustomSkillParams object`

  A user-created custom skill.

  - `type: "custom"`

  - `skill_id: string`

    Tagged ID of the custom skill (e.g., "skill_01XJ5...").

    minLength: 1, maxLength: 64

  - `version: optional string or null`

    Version to pin. Defaults to latest if omitted.

    minLength: 1, maxLength: 64

### Beta Managed Agents Custom Tool

- `BetaManagedAgentsCustomTool object`

  A custom tool as returned in API responses.

  - `type: "custom"`

  - `description: string`

  - `input_schema: BetaManagedAgentsCustomToolInputSchema`

    JSON Schema for custom tool input parameters.

    - `type: "object"`

    - `properties: optional map[unknown] or null`

    - `required: optional array of string or null`

  - `name: string`

### Beta Managed Agents Custom Tool Input Schema

- `BetaManagedAgentsCustomToolInputSchema object`

  JSON Schema for custom tool input parameters.

  - `type: "object"`

  - `properties: optional map[unknown] or null`

  - `required: optional array of string or null`

### Beta Managed Agents Custom Tool Params

- `BetaManagedAgentsCustomToolParams object`

  A custom tool that is executed by the API client rather than the agent. When the agent calls this tool, an `agent.custom_tool_use` event is emitted and the session goes idle, waiting for the client to provide the result via a `user.custom_tool_result` event.

  - `type: "custom"`

  - `description: string`

    Description of what the tool does, shown to the agent to help it decide when to use the tool.

    minLength: 1

  - `input_schema: BetaManagedAgentsCustomToolInputSchema`

    JSON Schema defining the expected input parameters for the tool.

    - `type: "object"`

    - `properties: optional map[unknown] or null`

    - `required: optional array of string or null`

  - `name: string`

    Unique name for the tool. 1-128 characters; letters, digits, underscores, and hyphens.

    minLength: 1, maxLength: 128

### Beta Managed Agents Edit Tool Config

- `BetaManagedAgentsEditToolConfig object`

  Configuration for the edit tool.

  - `type: "edit"`

  - `enabled: boolean`

  - `name: "edit"`

  - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

    Permission policy for tool execution.

    - `BetaManagedAgentsAlwaysAllowPolicy object`

      Tool calls are automatically approved without user confirmation.

      - `type: "always_allow"`

    - `BetaManagedAgentsAlwaysAskPolicy object`

      Tool calls require user confirmation before execution.

      - `type: "always_ask"`

    - `BetaManagedAgentsAutoPolicy object`

      The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

      - `type: "auto"`

### Beta Managed Agents Edit Tool Config Params

- `BetaManagedAgentsEditToolConfigParams object`

  Configuration override for the edit tool.

  - `type: optional "edit"`

  - `name: "edit"`

    Must be "edit".

  - `enabled: optional boolean or null`

    Whether this tool is enabled and available to Claude. Overrides the default_config setting.

  - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

    Permission policy for this tool. Controls whether tool calls are auto-approved or require confirmation.

    - `BetaManagedAgentsAlwaysAllowPolicy object`

      Tool calls are automatically approved without user confirmation.

      - `type: "always_allow"`

    - `BetaManagedAgentsAlwaysAskPolicy object`

      Tool calls require user confirmation before execution.

      - `type: "always_ask"`

    - `BetaManagedAgentsAutoPolicy object`

      The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

      - `type: "auto"`

### Beta Managed Agents Effort High

- `BetaManagedAgentsEffortHigh object`

  High effort. Favors reasoning depth.

  - `type: "high"`

### Beta Managed Agents Effort Low

- `BetaManagedAgentsEffortLow object`

  Low effort. Favors latency over reasoning depth.

  - `type: "low"`

### Beta Managed Agents Effort Max

- `BetaManagedAgentsEffortMax object`

  Maximum effort. Favors reasoning depth over latency.

  - `type: "max"`

### Beta Managed Agents Effort Medium

- `BetaManagedAgentsEffortMedium object`

  Medium effort. Balances latency and reasoning depth.

  - `type: "medium"`

### Beta Managed Agents Effort Xhigh

- `BetaManagedAgentsEffortXhigh object`

  Extra-high effort. Not all models accept this level.

  - `type: "xhigh"`

### Beta Managed Agents Glob Tool Config

- `BetaManagedAgentsGlobToolConfig object`

  Configuration for the glob tool.

  - `type: "glob"`

  - `enabled: boolean`

  - `name: "glob"`

  - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

    Permission policy for tool execution.

    - `BetaManagedAgentsAlwaysAllowPolicy object`

      Tool calls are automatically approved without user confirmation.

      - `type: "always_allow"`

    - `BetaManagedAgentsAlwaysAskPolicy object`

      Tool calls require user confirmation before execution.

      - `type: "always_ask"`

    - `BetaManagedAgentsAutoPolicy object`

      The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

      - `type: "auto"`

### Beta Managed Agents Glob Tool Config Params

- `BetaManagedAgentsGlobToolConfigParams object`

  Configuration override for the glob tool.

  - `type: optional "glob"`

  - `name: "glob"`

    Must be "glob".

  - `enabled: optional boolean or null`

    Whether this tool is enabled and available to Claude. Overrides the default_config setting.

  - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

    Permission policy for this tool. Controls whether tool calls are auto-approved or require confirmation.

    - `BetaManagedAgentsAlwaysAllowPolicy object`

      Tool calls are automatically approved without user confirmation.

      - `type: "always_allow"`

    - `BetaManagedAgentsAlwaysAskPolicy object`

      Tool calls require user confirmation before execution.

      - `type: "always_ask"`

    - `BetaManagedAgentsAutoPolicy object`

      The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

      - `type: "auto"`

### Beta Managed Agents Grep Tool Config

- `BetaManagedAgentsGrepToolConfig object`

  Configuration for the grep tool.

  - `type: "grep"`

  - `enabled: boolean`

  - `name: "grep"`

  - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

    Permission policy for tool execution.

    - `BetaManagedAgentsAlwaysAllowPolicy object`

      Tool calls are automatically approved without user confirmation.

      - `type: "always_allow"`

    - `BetaManagedAgentsAlwaysAskPolicy object`

      Tool calls require user confirmation before execution.

      - `type: "always_ask"`

    - `BetaManagedAgentsAutoPolicy object`

      The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

      - `type: "auto"`

### Beta Managed Agents Grep Tool Config Params

- `BetaManagedAgentsGrepToolConfigParams object`

  Configuration override for the grep tool.

  - `type: optional "grep"`

  - `name: "grep"`

    Must be "grep".

  - `enabled: optional boolean or null`

    Whether this tool is enabled and available to Claude. Overrides the default_config setting.

  - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

    Permission policy for this tool. Controls whether tool calls are auto-approved or require confirmation.

    - `BetaManagedAgentsAlwaysAllowPolicy object`

      Tool calls are automatically approved without user confirmation.

      - `type: "always_allow"`

    - `BetaManagedAgentsAlwaysAskPolicy object`

      Tool calls require user confirmation before execution.

      - `type: "always_ask"`

    - `BetaManagedAgentsAutoPolicy object`

      The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

      - `type: "auto"`

### Beta Managed Agents MCP Server URL Definition

- `BetaManagedAgentsMCPServerURLDefinition object`

  URL-based MCP server connection as returned in API responses.

  - `type: "url"`

  - `name: string`

  - `url: string`

### Beta Managed Agents MCP Tool Config

- `BetaManagedAgentsMCPToolConfig object`

  Resolved configuration for a specific MCP tool.

  - `enabled: boolean`

  - `name: string`

  - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

    Permission policy for tool execution.

    - `BetaManagedAgentsAlwaysAllowPolicy object`

      Tool calls are automatically approved without user confirmation.

      - `type: "always_allow"`

    - `BetaManagedAgentsAlwaysAskPolicy object`

      Tool calls require user confirmation before execution.

      - `type: "always_ask"`

    - `BetaManagedAgentsAutoPolicy object`

      The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

      - `type: "auto"`

### Beta Managed Agents MCP Tool Config Params

- `BetaManagedAgentsMCPToolConfigParams object`

  Configuration override for a specific MCP tool.

  - `name: string`

    Name of the MCP tool to configure. 1-128 characters.

    minLength: 1, maxLength: 128

  - `enabled: optional boolean or null`

    Whether this tool is enabled. Overrides the `default_config` setting.

  - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

    Permission policy for this tool. Overrides the `default_config` setting.

    - `BetaManagedAgentsAlwaysAllowPolicy object`

      Tool calls are automatically approved without user confirmation.

      - `type: "always_allow"`

    - `BetaManagedAgentsAlwaysAskPolicy object`

      Tool calls require user confirmation before execution.

      - `type: "always_ask"`

    - `BetaManagedAgentsAutoPolicy object`

      The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

      - `type: "auto"`

### Beta Managed Agents MCP Toolset

- `BetaManagedAgentsMCPToolset object`

  - `type: "mcp_toolset"`

  - `configs: array of BetaManagedAgentsMCPToolConfig`

    - `enabled: boolean`

    - `name: string`

    - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

      Permission policy for tool execution.

      - `BetaManagedAgentsAlwaysAllowPolicy object`

        Tool calls are automatically approved without user confirmation.

        - `type: "always_allow"`

      - `BetaManagedAgentsAlwaysAskPolicy object`

        Tool calls require user confirmation before execution.

        - `type: "always_ask"`

      - `BetaManagedAgentsAutoPolicy object`

        The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

        - `type: "auto"`

  - `default_config: BetaManagedAgentsMCPToolsetDefaultConfig`

    Resolved default configuration for all tools from an MCP server.

    - `enabled: boolean`

    - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

      Permission policy for tool execution.

      - `BetaManagedAgentsAlwaysAllowPolicy object`

        Tool calls are automatically approved without user confirmation.

      - `BetaManagedAgentsAlwaysAskPolicy object`

        Tool calls require user confirmation before execution.

      - `BetaManagedAgentsAutoPolicy object`

        The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

  - `mcp_server_name: string`

### Beta Managed Agents MCP Toolset Default Config

- `BetaManagedAgentsMCPToolsetDefaultConfig object`

  Resolved default configuration for all tools from an MCP server.

  - `enabled: boolean`

  - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

    Permission policy for tool execution.

    - `BetaManagedAgentsAlwaysAllowPolicy object`

      Tool calls are automatically approved without user confirmation.

      - `type: "always_allow"`

    - `BetaManagedAgentsAlwaysAskPolicy object`

      Tool calls require user confirmation before execution.

      - `type: "always_ask"`

    - `BetaManagedAgentsAutoPolicy object`

      The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

      - `type: "auto"`

### Beta Managed Agents MCP Toolset Default Config Params

- `BetaManagedAgentsMCPToolsetDefaultConfigParams object`

  Default configuration for all tools from an MCP server.

  - `enabled: optional boolean or null`

    Whether tools are enabled by default. Defaults to true if not specified.

  - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

    Default permission policy for tools from this server.

    - `BetaManagedAgentsAlwaysAllowPolicy object`

      Tool calls are automatically approved without user confirmation.

      - `type: "always_allow"`

    - `BetaManagedAgentsAlwaysAskPolicy object`

      Tool calls require user confirmation before execution.

      - `type: "always_ask"`

    - `BetaManagedAgentsAutoPolicy object`

      The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

      - `type: "auto"`

### Beta Managed Agents MCP Toolset Params

- `BetaManagedAgentsMCPToolsetParams object`

  Configuration for tools from an MCP server defined in `mcp_servers`.

  - `type: "mcp_toolset"`

  - `mcp_server_name: string`

    Name of the MCP server. Must match a server name from the mcp_servers array. 1-255 characters.

    minLength: 1, maxLength: 255

  - `configs: optional array of BetaManagedAgentsMCPToolConfigParams`

    Per-tool configuration overrides.

    - `name: string`

      Name of the MCP tool to configure. 1-128 characters.

      minLength: 1, maxLength: 128

    - `enabled: optional boolean or null`

      Whether this tool is enabled. Overrides the `default_config` setting.

    - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

      Permission policy for this tool. Overrides the `default_config` setting.

      - `BetaManagedAgentsAlwaysAllowPolicy object`

        Tool calls are automatically approved without user confirmation.

        - `type: "always_allow"`

      - `BetaManagedAgentsAlwaysAskPolicy object`

        Tool calls require user confirmation before execution.

        - `type: "always_ask"`

      - `BetaManagedAgentsAutoPolicy object`

        The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

        - `type: "auto"`

  - `default_config: optional BetaManagedAgentsMCPToolsetDefaultConfigParams or null`

    Default configuration for all tools from this server.

    - `enabled: optional boolean or null`

      Whether tools are enabled by default. Defaults to true if not specified.

    - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

      Default permission policy for tools from this server.

      - `BetaManagedAgentsAlwaysAllowPolicy object`

        Tool calls are automatically approved without user confirmation.

      - `BetaManagedAgentsAlwaysAskPolicy object`

        Tool calls require user confirmation before execution.

      - `BetaManagedAgentsAutoPolicy object`

        The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

### Beta Managed Agents Model

- `BetaManagedAgentsModel = "claude-haiku-5-5" or "claude-sonnet-5-5" or "claude-opus-5-5" or 14 more or string`

  The model that will power your agent.

  See [models](https://docs.anthropic.com/en/docs/models-overview) for additional details and options.

  - `"claude-haiku-5-5"`

    Fastest model for high-volume, real-time tasks

  - `"claude-sonnet-5-5"`

    Efficient model for coding and agents

  - `"claude-opus-5-5"`

    Powerful intelligence for coding, knowledge work, and long-running agents

  - `"claude-fable-5-1"`

    Frontier intelligence for ambitious tasks across coding, scientific discovery, and enterprise workflows

  - `"claude-sonnet-5"`

    Efficient model for coding and agents

  - `"claude-fable-5"`

    Next generation of intelligence for the hardest knowledge work and coding problems

  - `"claude-opus-5"`

    Powerful intelligence for long-running agents and coding

  - `"claude-opus-4-8"`

    Powerful intelligence for long-running agents and coding

  - `"claude-opus-4-7"`

    Powerful intelligence for long-running agents and coding

  - `"claude-opus-4-6"`

    Powerful intelligence for long-running agents and coding

  - `"claude-sonnet-4-6"`

    Best combination of speed and intelligence

  - `"claude-haiku-4-5"`

  - `"claude-haiku-4-5-20251001"`

  - `"claude-opus-4-5"`

    Powerful intelligence for long-running agents and coding

  - `"claude-opus-4-5-20251101"`

    Powerful intelligence for long-running agents and coding

  - `"claude-sonnet-4-5"`

    **Deprecated**: Will reach end-of-life on November 30, 2026. Please migrate to claude-sonnet-5-5. Visit https://docs.anthropic.com/en/docs/resources/model-deprecations for more information.

    High-performance model for agents and coding

  - `"claude-sonnet-4-5-20250929"`

    **Deprecated**: Will reach end-of-life on November 30, 2026. Please migrate to claude-sonnet-5-5. Visit https://docs.anthropic.com/en/docs/resources/model-deprecations for more information.

    High-performance model for agents and coding

  - `string`

### Beta Managed Agents Model Config

- `BetaManagedAgentsModelConfig object`

  Model identifier and configuration.

  - `id: BetaManagedAgentsModel`

    The model that will power your agent.

    See [models](https://docs.anthropic.com/en/docs/models-overview) for additional details and options.

    - `"claude-haiku-5-5"`

      Fastest model for high-volume, real-time tasks

    - `"claude-sonnet-5-5"`

      Efficient model for coding and agents

    - `"claude-opus-5-5"`

      Powerful intelligence for coding, knowledge work, and long-running agents

    - `"claude-fable-5-1"`

      Frontier intelligence for ambitious tasks across coding, scientific discovery, and enterprise workflows

    - `"claude-sonnet-5"`

      Efficient model for coding and agents

    - `"claude-fable-5"`

      Next generation of intelligence for the hardest knowledge work and coding problems

    - `"claude-opus-5"`

      Powerful intelligence for long-running agents and coding

    - `"claude-opus-4-8"`

      Powerful intelligence for long-running agents and coding

    - `"claude-opus-4-7"`

      Powerful intelligence for long-running agents and coding

    - `"claude-opus-4-6"`

      Powerful intelligence for long-running agents and coding

    - `"claude-sonnet-4-6"`

      Best combination of speed and intelligence

    - `"claude-haiku-4-5"`

    - `"claude-haiku-4-5-20251001"`

    - `"claude-opus-4-5"`

      Powerful intelligence for long-running agents and coding

    - `"claude-opus-4-5-20251101"`

      Powerful intelligence for long-running agents and coding

    - `"claude-sonnet-4-5"`

      **Deprecated**: Will reach end-of-life on November 30, 2026. Please migrate to claude-sonnet-5-5. Visit https://docs.anthropic.com/en/docs/resources/model-deprecations for more information.

      High-performance model for agents and coding

    - `"claude-sonnet-4-5-20250929"`

      **Deprecated**: Will reach end-of-life on November 30, 2026. Please migrate to claude-sonnet-5-5. Visit https://docs.anthropic.com/en/docs/resources/model-deprecations for more information.

      High-performance model for agents and coding

    - `string`

  - `effort: optional BetaManagedAgentsEffortLow or BetaManagedAgentsEffortMedium or BetaManagedAgentsEffortHigh or 2 more`

    How hard Claude works on each inference call. One of `low`, `medium`, `high`, `xhigh`, `max`. Always present; resolved to the per-model default at save time when not supplied.

    - `BetaManagedAgentsEffortLow object`

      Low effort. Favors latency over reasoning depth.

      - `type: "low"`

    - `BetaManagedAgentsEffortMedium object`

      Medium effort. Balances latency and reasoning depth.

      - `type: "medium"`

    - `BetaManagedAgentsEffortHigh object`

      High effort. Favors reasoning depth.

      - `type: "high"`

    - `BetaManagedAgentsEffortXhigh object`

      Extra-high effort. Not all models accept this level.

      - `type: "xhigh"`

    - `BetaManagedAgentsEffortMax object`

      Maximum effort. Favors reasoning depth over latency.

      - `type: "max"`

  - `inference_geo: optional string`

    Geographic region for model inference. When unset, requests fall through to the workspace's default_inference_geo.

  - `speed: optional "standard" or "fast"`

    Inference speed mode. `fast` provides significantly faster output token generation at premium pricing. Defaults to `standard`. Not all models support `fast`; invalid combinations are rejected at create time.

    - `"standard"`

    - `"fast"`

### Beta Managed Agents Model Config Params

- `BetaManagedAgentsModelConfigParams object`

  An object that defines additional configuration control over model use

  - `id: BetaManagedAgentsModel`

    The model that will power your agent.

    See [models](https://docs.anthropic.com/en/docs/models-overview) for additional details and options.

    - `"claude-haiku-5-5"`

      Fastest model for high-volume, real-time tasks

    - `"claude-sonnet-5-5"`

      Efficient model for coding and agents

    - `"claude-opus-5-5"`

      Powerful intelligence for coding, knowledge work, and long-running agents

    - `"claude-fable-5-1"`

      Frontier intelligence for ambitious tasks across coding, scientific discovery, and enterprise workflows

    - `"claude-sonnet-5"`

      Efficient model for coding and agents

    - `"claude-fable-5"`

      Next generation of intelligence for the hardest knowledge work and coding problems

    - `"claude-opus-5"`

      Powerful intelligence for long-running agents and coding

    - `"claude-opus-4-8"`

      Powerful intelligence for long-running agents and coding

    - `"claude-opus-4-7"`

      Powerful intelligence for long-running agents and coding

    - `"claude-opus-4-6"`

      Powerful intelligence for long-running agents and coding

    - `"claude-sonnet-4-6"`

      Best combination of speed and intelligence

    - `"claude-haiku-4-5"`

    - `"claude-haiku-4-5-20251001"`

    - `"claude-opus-4-5"`

      Powerful intelligence for long-running agents and coding

    - `"claude-opus-4-5-20251101"`

      Powerful intelligence for long-running agents and coding

    - `"claude-sonnet-4-5"`

      **Deprecated**: Will reach end-of-life on November 30, 2026. Please migrate to claude-sonnet-5-5. Visit https://docs.anthropic.com/en/docs/resources/model-deprecations for more information.

      High-performance model for agents and coding

    - `"claude-sonnet-4-5-20250929"`

      **Deprecated**: Will reach end-of-life on November 30, 2026. Please migrate to claude-sonnet-5-5. Visit https://docs.anthropic.com/en/docs/resources/model-deprecations for more information.

      High-performance model for agents and coding

    - `string`

  - `effort: optional "low" or "medium" or "high" or 2 more or BetaManagedAgentsEffortLow or BetaManagedAgentsEffortMedium or 3 more or null`

    How hard Claude works on each inference call. Accepts a bare level string (`"high"`) or `{"type": "high"}`. On create, omitting it resolves the per-model default; on update, omitting it leaves the stored value unchanged.

    - `"low"`

      Low effort. Favors latency over reasoning depth.

    - `"medium"`

      Medium effort. Balances latency and reasoning depth.

    - `"high"`

      High effort. Favors reasoning depth.

    - `"xhigh"`

      Extra-high effort. Not all models accept this level.

    - `"max"`

      Maximum effort. Favors reasoning depth over latency.

    - `BetaManagedAgentsEffortLow object`

      Low effort. Favors latency over reasoning depth.

      - `type: "low"`

    - `BetaManagedAgentsEffortMedium object`

      Medium effort. Balances latency and reasoning depth.

      - `type: "medium"`

    - `BetaManagedAgentsEffortHigh object`

      High effort. Favors reasoning depth.

      - `type: "high"`

    - `BetaManagedAgentsEffortXhigh object`

      Extra-high effort. Not all models accept this level.

      - `type: "xhigh"`

    - `BetaManagedAgentsEffortMax object`

      Maximum effort. Favors reasoning depth over latency.

      - `type: "max"`

  - `inference_geo: optional string or null`

    Geographic region for model inference. When unset, requests fall through to the workspace's default_inference_geo. On update, `model` is whole-object replacement — omitting inference_geo clears it.

  - `speed: optional "standard" or "fast" or null`

    Inference speed mode. Defaults to `standard`.

    - `"standard"`

    - `"fast"`

### Beta Managed Agents Multiagent Advisor

- `BetaManagedAgentsMultiagentAdvisor = BetaManagedAgentsMultiagentAdvisorEnabled or BetaManagedAgentsMultiagentAdvisorDisabled`

  Whether the session's primary thread can consult an advisor model.

  - `BetaManagedAgentsMultiagentAdvisorEnabled object`

    The session's primary thread can consult `model` mid-turn.

    - `type: "enabled"`

    - `model: string`

      The advisor model id.

  - `BetaManagedAgentsMultiagentAdvisorDisabled object`

    The agent has no advisor.

    - `type: "disabled"`

### Beta Managed Agents Multiagent Advisor Disabled

- `BetaManagedAgentsMultiagentAdvisorDisabled object`

  The agent has no advisor.

  - `type: "disabled"`

### Beta Managed Agents Multiagent Advisor Disabled Params

- `BetaManagedAgentsMultiagentAdvisorDisabledParams object`

  The agent has no advisor.

  - `type: "disabled"`

### Beta Managed Agents Multiagent Advisor Enabled

- `BetaManagedAgentsMultiagentAdvisorEnabled object`

  The session's primary thread can consult `model` mid-turn.

  - `type: "enabled"`

  - `model: string`

    The advisor model id.

### Beta Managed Agents Multiagent Advisor Enabled Params

- `BetaManagedAgentsMultiagentAdvisorEnabledParams object`

  The session's primary thread can consult `model` mid-turn.

  - `type: "enabled"`

  - `model: string`

    A Claude model id. The model must be permitted as an advisor for this agent's model.

    minLength: 1, maxLength: 256

### Beta Managed Agents Multiagent Advisor Params

- `BetaManagedAgentsMultiagentAdvisorParams = BetaManagedAgentsMultiagentAdvisorEnabledParams or BetaManagedAgentsMultiagentAdvisorDisabledParams`

  Whether the session's primary thread can consult an advisor model.

  - `BetaManagedAgentsMultiagentAdvisorEnabledParams object`

    The session's primary thread can consult `model` mid-turn.

    - `type: "enabled"`

    - `model: string`

      A Claude model id. The model must be permitted as an advisor for this agent's model.

      minLength: 1, maxLength: 256

  - `BetaManagedAgentsMultiagentAdvisorDisabledParams object`

    The agent has no advisor.

    - `type: "disabled"`

### Beta Managed Agents Multiagent Coordinator

- `BetaManagedAgentsMultiagentCoordinator object`

  Resolved coordinator topology with a concrete agent roster.

  - `type: "coordinator"`

  - `agents: array of BetaManagedAgentsAgentReference or BetaManagedAgentsAdvisor`

    Agents the coordinator may spawn as session threads, each resolved to a specific version.

    - `BetaManagedAgentsAgentReference object`

      A resolved agent reference with a concrete version.

      - `type: "agent"`

      - `id: string`

      - `version: number`

        format: int32

    - `BetaManagedAgentsAdvisor object`

      Platform advisor roster entry: a model the session's primary thread may consult mid-turn.

      - `type: "advisor"`

      - `model: string`

        The advisor model id.

### Beta Managed Agents Multiagent Coordinator Params

- `BetaManagedAgentsMultiagentCoordinatorParams object`

  A coordinator topology: the session's primary thread orchestrates work by spawning session threads, each running an agent drawn from the `agents` roster.

  - `type: "coordinator"`

  - `agents: array of BetaManagedAgentsMultiagentRosterEntryParams`

    Agents the coordinator may spawn as session threads. 1–20 entries. Each entry is an agent ID string, a versioned `{"type":"agent","id","version"}` reference, or `{"type":"self"}` to allow recursive self-invocation. Entries must reference distinct agents (after resolving `self` and string forms); at most one `self`. Referenced agents must exist, must not be archived, and must not themselves have `multiagent` set (depth limit 1).

    - `string`

    - `BetaManagedAgentsAgentParams object`

      Specification for an Agent. Provide a specific `version` or use the short-form `agent="agent_id"` for the most recent version

      - `type: "agent"`

      - `id: string`

        The `agent` ID.

        minLength: 1, maxLength: 128

      - `version: optional number`

        The specific `agent` version to use. Omit to use the latest version. Must be at least 1 if specified.

        format: int32

    - `BetaManagedAgentsMultiagentSelfParams object`

      Sentinel roster entry meaning "the agent that owns this configuration". Resolved server-side to a concrete agent reference.

      - `type: "self"`

    - `BetaManagedAgentsAdvisorParams object`

      Platform advisor roster entry: a model the session's primary thread may consult mid-turn. At most one per roster; the entry occupies the roster name `anthropic.advisor`.

      - `type: "advisor"`

      - `model: string`

        A Claude model id. The model must be permitted as an advisor for this agent's model.

        minLength: 1, maxLength: 256

### Beta Managed Agents Multiagent Inline Agents

- `BetaManagedAgentsMultiagentInlineAgents = BetaManagedAgentsMultiagentInlineAgentsEnabled or BetaManagedAgentsMultiagentInlineAgentsDisabled`

  Whether the agent can define inline agents. The agent defines an inline agent itself, in a workflow run's plan or when it spawns a session thread, and the inline agent is not saved.

  - `BetaManagedAgentsMultiagentInlineAgentsEnabled object`

    The agent can define inline agents.

    - `type: "enabled"`

  - `BetaManagedAgentsMultiagentInlineAgentsDisabled object`

    The agent cannot define inline agents.

    - `type: "disabled"`

### Beta Managed Agents Multiagent Inline Agents Disabled

- `BetaManagedAgentsMultiagentInlineAgentsDisabled object`

  The agent cannot define inline agents.

  - `type: "disabled"`

### Beta Managed Agents Multiagent Inline Agents Disabled Params

- `BetaManagedAgentsMultiagentInlineAgentsDisabledParams object`

  The agent cannot define inline agents.

  - `type: "disabled"`

### Beta Managed Agents Multiagent Inline Agents Enabled

- `BetaManagedAgentsMultiagentInlineAgentsEnabled object`

  The agent can define inline agents.

  - `type: "enabled"`

### Beta Managed Agents Multiagent Inline Agents Enabled Params

- `BetaManagedAgentsMultiagentInlineAgentsEnabledParams object`

  The agent can define inline agents.

  - `type: "enabled"`

### Beta Managed Agents Multiagent Inline Agents Params

- `BetaManagedAgentsMultiagentInlineAgentsParams = BetaManagedAgentsMultiagentInlineAgentsEnabledParams or BetaManagedAgentsMultiagentInlineAgentsDisabledParams`

  Whether the agent can define inline agents. The agent defines an inline agent itself, in a workflow run's plan or when it spawns a session thread, and the inline agent is not saved.

  - `BetaManagedAgentsMultiagentInlineAgentsEnabledParams object`

    The agent can define inline agents.

    - `type: "enabled"`

  - `BetaManagedAgentsMultiagentInlineAgentsDisabledParams object`

    The agent cannot define inline agents.

    - `type: "disabled"`

### Beta Managed Agents Multiagent Predefined Agent Params

- `BetaManagedAgentsMultiagentPredefinedAgentParams = string or BetaManagedAgentsAgentParams or BetaManagedAgentsMultiagentSelfParams`

  One agent in a `predefined_agents` list. It is an agent ID string, an `agent` reference with an optional `version`, or `self` for the agent that owns this configuration.

  - `string`

  - `BetaManagedAgentsAgentParams object`

    Specification for an Agent. Provide a specific `version` or use the short-form `agent="agent_id"` for the most recent version

    - `type: "agent"`

    - `id: string`

      The `agent` ID.

      minLength: 1, maxLength: 128

    - `version: optional number`

      The specific `agent` version to use. Omit to use the latest version. Must be at least 1 if specified.

      format: int32

  - `BetaManagedAgentsMultiagentSelfParams object`

    Sentinel roster entry meaning "the agent that owns this configuration". Resolved server-side to a concrete agent reference.

    - `type: "self"`

### Beta Managed Agents Multiagent Self Params

- `BetaManagedAgentsMultiagentSelfParams object`

  Sentinel roster entry meaning "the agent that owns this configuration". Resolved server-side to a concrete agent reference.

  - `type: "self"`

### Beta Managed Agents Multiagent Subagents

- `BetaManagedAgentsMultiagentSubagents = BetaManagedAgentsMultiagentSubagentsEnabled or BetaManagedAgentsMultiagentSubagentsDisabled`

  Whether the agent can spawn session threads.

  - `BetaManagedAgentsMultiagentSubagentsEnabled object`

    The agent can spawn session threads.

    - `type: "enabled"`

    - `inline_agents: BetaManagedAgentsMultiagentInlineAgents`

      Whether the agent can define inline agents, which are not saved, when it spawns session threads.

      - `BetaManagedAgentsMultiagentInlineAgentsEnabled object`

        The agent can define inline agents.

        - `type: "enabled"`

      - `BetaManagedAgentsMultiagentInlineAgentsDisabled object`

        The agent cannot define inline agents.

        - `type: "disabled"`

    - `predefined_agents: array of BetaManagedAgentsAgentReference`

      Predefined agents, which are saved agents that this agent can spawn as session threads, each resolved to a specific version.

      - `type: "agent"`

      - `id: string`

      - `version: number`

        format: int32

  - `BetaManagedAgentsMultiagentSubagentsDisabled object`

    The agent cannot spawn session threads.

    - `type: "disabled"`

### Beta Managed Agents Multiagent Subagents Disabled

- `BetaManagedAgentsMultiagentSubagentsDisabled object`

  The agent cannot spawn session threads.

  - `type: "disabled"`

### Beta Managed Agents Multiagent Subagents Disabled Params

- `BetaManagedAgentsMultiagentSubagentsDisabledParams object`

  The agent cannot spawn session threads.

  - `type: "disabled"`

### Beta Managed Agents Multiagent Subagents Enabled

- `BetaManagedAgentsMultiagentSubagentsEnabled object`

  The agent can spawn session threads.

  - `type: "enabled"`

  - `inline_agents: BetaManagedAgentsMultiagentInlineAgents`

    Whether the agent can define inline agents, which are not saved, when it spawns session threads.

    - `BetaManagedAgentsMultiagentInlineAgentsEnabled object`

      The agent can define inline agents.

      - `type: "enabled"`

    - `BetaManagedAgentsMultiagentInlineAgentsDisabled object`

      The agent cannot define inline agents.

      - `type: "disabled"`

  - `predefined_agents: array of BetaManagedAgentsAgentReference`

    Predefined agents, which are saved agents that this agent can spawn as session threads, each resolved to a specific version.

    - `type: "agent"`

    - `id: string`

    - `version: number`

      format: int32

### Beta Managed Agents Multiagent Subagents Enabled Params

- `BetaManagedAgentsMultiagentSubagentsEnabledParams object`

  The agent can spawn session threads. Each thread runs a predefined agent, which is a saved agent in `predefined_agents`, or an inline agent, which the agent defines when it spawns the thread and which is not saved. If `inline_agents` is disabled, `predefined_agents` must name at least one agent.

  - `type: "enabled"`

  - `inline_agents: optional BetaManagedAgentsMultiagentInlineAgentsParams or null`

    Whether the agent can define inline agents when it spawns session threads. Defaults to enabled.

    - `BetaManagedAgentsMultiagentInlineAgentsEnabledParams object`

      The agent can define inline agents.

      - `type: "enabled"`

    - `BetaManagedAgentsMultiagentInlineAgentsDisabledParams object`

      The agent cannot define inline agents.

      - `type: "disabled"`

  - `predefined_agents: optional array of BetaManagedAgentsMultiagentPredefinedAgentParams or null`

    Predefined agents that this agent can spawn as session threads. At most 20. Defaults to null. Null and an empty list both mean no predefined agents. This list is separate from `workflows.predefined_agents`, and an agent in one list is not added to the other.

    - `string`

    - `BetaManagedAgentsAgentParams object`

      Specification for an Agent. Provide a specific `version` or use the short-form `agent="agent_id"` for the most recent version

      - `type: "agent"`

      - `id: string`

        The `agent` ID.

        minLength: 1, maxLength: 128

      - `version: optional number`

        The specific `agent` version to use. Omit to use the latest version. Must be at least 1 if specified.

        format: int32

    - `BetaManagedAgentsMultiagentSelfParams object`

      Sentinel roster entry meaning "the agent that owns this configuration". Resolved server-side to a concrete agent reference.

      - `type: "self"`

### Beta Managed Agents Multiagent Subagents Params

- `BetaManagedAgentsMultiagentSubagentsParams = BetaManagedAgentsMultiagentSubagentsEnabledParams or BetaManagedAgentsMultiagentSubagentsDisabledParams`

  Whether the agent can spawn session threads.

  - `BetaManagedAgentsMultiagentSubagentsEnabledParams object`

    The agent can spawn session threads. Each thread runs a predefined agent, which is a saved agent in `predefined_agents`, or an inline agent, which the agent defines when it spawns the thread and which is not saved. If `inline_agents` is disabled, `predefined_agents` must name at least one agent.

    - `type: "enabled"`

    - `inline_agents: optional BetaManagedAgentsMultiagentInlineAgentsParams or null`

      Whether the agent can define inline agents when it spawns session threads. Defaults to enabled.

      - `BetaManagedAgentsMultiagentInlineAgentsEnabledParams object`

        The agent can define inline agents.

        - `type: "enabled"`

      - `BetaManagedAgentsMultiagentInlineAgentsDisabledParams object`

        The agent cannot define inline agents.

        - `type: "disabled"`

    - `predefined_agents: optional array of BetaManagedAgentsMultiagentPredefinedAgentParams or null`

      Predefined agents that this agent can spawn as session threads. At most 20. Defaults to null. Null and an empty list both mean no predefined agents. This list is separate from `workflows.predefined_agents`, and an agent in one list is not added to the other.

      - `string`

      - `BetaManagedAgentsAgentParams object`

        Specification for an Agent. Provide a specific `version` or use the short-form `agent="agent_id"` for the most recent version

        - `type: "agent"`

        - `id: string`

          The `agent` ID.

          minLength: 1, maxLength: 128

        - `version: optional number`

          The specific `agent` version to use. Omit to use the latest version. Must be at least 1 if specified.

          format: int32

      - `BetaManagedAgentsMultiagentSelfParams object`

        Sentinel roster entry meaning "the agent that owns this configuration". Resolved server-side to a concrete agent reference.

        - `type: "self"`

  - `BetaManagedAgentsMultiagentSubagentsDisabledParams object`

    The agent cannot spawn session threads.

    - `type: "disabled"`

### Beta Managed Agents Multiagent Workflows

- `BetaManagedAgentsMultiagentWorkflows = BetaManagedAgentsMultiagentWorkflowsEnabled or BetaManagedAgentsMultiagentWorkflowsDisabled`

  Whether the agent can start workflow runs.

  - `BetaManagedAgentsMultiagentWorkflowsEnabled object`

    The agent can start workflow runs.

    - `type: "enabled"`

    - `inline_agents: BetaManagedAgentsMultiagentInlineAgents`

      Whether a run's plan can define inline agents, which are not saved.

      - `BetaManagedAgentsMultiagentInlineAgentsEnabled object`

        The agent can define inline agents.

        - `type: "enabled"`

      - `BetaManagedAgentsMultiagentInlineAgentsDisabled object`

        The agent cannot define inline agents.

        - `type: "disabled"`

    - `predefined_agents: array of BetaManagedAgentsAgentReference`

      Predefined agents, which are saved agents that a run's plan can use, each resolved to a specific version.

      - `type: "agent"`

      - `id: string`

      - `version: number`

        format: int32

  - `BetaManagedAgentsMultiagentWorkflowsDisabled object`

    The agent cannot start workflow runs.

    - `type: "disabled"`

### Beta Managed Agents Multiagent Workflows Disabled

- `BetaManagedAgentsMultiagentWorkflowsDisabled object`

  The agent cannot start workflow runs.

  - `type: "disabled"`

### Beta Managed Agents Multiagent Workflows Disabled Params

- `BetaManagedAgentsMultiagentWorkflowsDisabledParams object`

  The agent cannot start workflow runs.

  - `type: "disabled"`

### Beta Managed Agents Multiagent Workflows Enabled

- `BetaManagedAgentsMultiagentWorkflowsEnabled object`

  The agent can start workflow runs.

  - `type: "enabled"`

  - `inline_agents: BetaManagedAgentsMultiagentInlineAgents`

    Whether a run's plan can define inline agents, which are not saved.

    - `BetaManagedAgentsMultiagentInlineAgentsEnabled object`

      The agent can define inline agents.

      - `type: "enabled"`

    - `BetaManagedAgentsMultiagentInlineAgentsDisabled object`

      The agent cannot define inline agents.

      - `type: "disabled"`

  - `predefined_agents: array of BetaManagedAgentsAgentReference`

    Predefined agents, which are saved agents that a run's plan can use, each resolved to a specific version.

    - `type: "agent"`

    - `id: string`

    - `version: number`

      format: int32

### Beta Managed Agents Multiagent Workflows Enabled Params

- `BetaManagedAgentsMultiagentWorkflowsEnabledParams object`

  The agent can start workflow runs. Each run follows a plan, a program that the agent writes. A plan can use predefined agents, which are the saved agents in `predefined_agents`, and inline agents, which it defines itself and which are not saved. If `inline_agents` is disabled, `predefined_agents` must name at least one agent.

  - `type: "enabled"`

  - `inline_agents: optional BetaManagedAgentsMultiagentInlineAgentsParams or null`

    Whether a run's plan can define inline agents. Defaults to enabled.

    - `BetaManagedAgentsMultiagentInlineAgentsEnabledParams object`

      The agent can define inline agents.

      - `type: "enabled"`

    - `BetaManagedAgentsMultiagentInlineAgentsDisabledParams object`

      The agent cannot define inline agents.

      - `type: "disabled"`

  - `predefined_agents: optional array of BetaManagedAgentsMultiagentPredefinedAgentParams or null`

    Predefined agents that a run's plan can use. At most 20. Defaults to null. Null and an empty list both mean no predefined agents. This list is separate from `subagents.predefined_agents`, and an agent in one list is not added to the other.

    - `string`

    - `BetaManagedAgentsAgentParams object`

      Specification for an Agent. Provide a specific `version` or use the short-form `agent="agent_id"` for the most recent version

      - `type: "agent"`

      - `id: string`

        The `agent` ID.

        minLength: 1, maxLength: 128

      - `version: optional number`

        The specific `agent` version to use. Omit to use the latest version. Must be at least 1 if specified.

        format: int32

    - `BetaManagedAgentsMultiagentSelfParams object`

      Sentinel roster entry meaning "the agent that owns this configuration". Resolved server-side to a concrete agent reference.

      - `type: "self"`

### Beta Managed Agents Multiagent Workflows Params

- `BetaManagedAgentsMultiagentWorkflowsParams = BetaManagedAgentsMultiagentWorkflowsEnabledParams or BetaManagedAgentsMultiagentWorkflowsDisabledParams`

  Whether the agent can start workflow runs.

  - `BetaManagedAgentsMultiagentWorkflowsEnabledParams object`

    The agent can start workflow runs. Each run follows a plan, a program that the agent writes. A plan can use predefined agents, which are the saved agents in `predefined_agents`, and inline agents, which it defines itself and which are not saved. If `inline_agents` is disabled, `predefined_agents` must name at least one agent.

    - `type: "enabled"`

    - `inline_agents: optional BetaManagedAgentsMultiagentInlineAgentsParams or null`

      Whether a run's plan can define inline agents. Defaults to enabled.

      - `BetaManagedAgentsMultiagentInlineAgentsEnabledParams object`

        The agent can define inline agents.

        - `type: "enabled"`

      - `BetaManagedAgentsMultiagentInlineAgentsDisabledParams object`

        The agent cannot define inline agents.

        - `type: "disabled"`

    - `predefined_agents: optional array of BetaManagedAgentsMultiagentPredefinedAgentParams or null`

      Predefined agents that a run's plan can use. At most 20. Defaults to null. Null and an empty list both mean no predefined agents. This list is separate from `subagents.predefined_agents`, and an agent in one list is not added to the other.

      - `string`

      - `BetaManagedAgentsAgentParams object`

        Specification for an Agent. Provide a specific `version` or use the short-form `agent="agent_id"` for the most recent version

        - `type: "agent"`

        - `id: string`

          The `agent` ID.

          minLength: 1, maxLength: 128

        - `version: optional number`

          The specific `agent` version to use. Omit to use the latest version. Must be at least 1 if specified.

          format: int32

      - `BetaManagedAgentsMultiagentSelfParams object`

        Sentinel roster entry meaning "the agent that owns this configuration". Resolved server-side to a concrete agent reference.

        - `type: "self"`

  - `BetaManagedAgentsMultiagentWorkflowsDisabledParams object`

    The agent cannot start workflow runs.

    - `type: "disabled"`

### Beta Managed Agents Multiagent20261001

- `BetaManagedAgentsMultiagent20261001 object`

  Resolved multiagent configuration with three members, each enabled or disabled on its own.

  - `type: "multiagent_20261001"`

  - `advisor: BetaManagedAgentsMultiagentAdvisor`

    Whether the session's primary thread can consult an advisor model.

    - `BetaManagedAgentsMultiagentAdvisorEnabled object`

      The session's primary thread can consult `model` mid-turn.

      - `type: "enabled"`

      - `model: string`

        The advisor model id.

    - `BetaManagedAgentsMultiagentAdvisorDisabled object`

      The agent has no advisor.

      - `type: "disabled"`

  - `subagents: BetaManagedAgentsMultiagentSubagents`

    Whether the agent can spawn session threads.

    - `BetaManagedAgentsMultiagentSubagentsEnabled object`

      The agent can spawn session threads.

      - `type: "enabled"`

      - `inline_agents: BetaManagedAgentsMultiagentInlineAgents`

        Whether the agent can define inline agents, which are not saved, when it spawns session threads.

        - `BetaManagedAgentsMultiagentInlineAgentsEnabled object`

          The agent can define inline agents.

          - `type: "enabled"`

        - `BetaManagedAgentsMultiagentInlineAgentsDisabled object`

          The agent cannot define inline agents.

          - `type: "disabled"`

      - `predefined_agents: array of BetaManagedAgentsAgentReference`

        Predefined agents, which are saved agents that this agent can spawn as session threads, each resolved to a specific version.

        - `type: "agent"`

        - `id: string`

        - `version: number`

          format: int32

    - `BetaManagedAgentsMultiagentSubagentsDisabled object`

      The agent cannot spawn session threads.

      - `type: "disabled"`

  - `workflows: BetaManagedAgentsMultiagentWorkflows`

    Whether the agent can start workflow runs.

    - `BetaManagedAgentsMultiagentWorkflowsEnabled object`

      The agent can start workflow runs.

      - `type: "enabled"`

      - `inline_agents: BetaManagedAgentsMultiagentInlineAgents`

        Whether a run's plan can define inline agents, which are not saved.

      - `predefined_agents: array of BetaManagedAgentsAgentReference`

        Predefined agents, which are saved agents that a run's plan can use, each resolved to a specific version.

        - `type: "agent"`

        - `id: string`

        - `version: number`

          format: int32

    - `BetaManagedAgentsMultiagentWorkflowsDisabled object`

      The agent cannot start workflow runs.

      - `type: "disabled"`

### Beta Managed Agents Multiagent20261001 Params

- `BetaManagedAgentsMultiagent20261001Params object`

  Multiagent configuration with three members, each enabled or disabled on its own. On an update, if the agent's stored `multiagent` also has type `multiagent_20261001`, this configuration is merged into the stored one, level by level, instead of replacing it. A key that the update omits keeps its stored value. A key sent as null takes its default, on create as well, so `"workflows": null` enables workflows. An object sent with a `type` other than the stored one replaces the stored object, and the keys that it omits take their defaults. A `predefined_agents` list that is sent replaces the stored list. Every object that is sent needs its `type`, and an enabled `advisor` needs its `model`. Other validation applies to the merged result.

  - `type: "multiagent_20261001"`

  - `advisor: optional BetaManagedAgentsMultiagentAdvisorParams or null`

    Whether the session's primary thread can consult an advisor model. Defaults to disabled.

    - `BetaManagedAgentsMultiagentAdvisorEnabledParams object`

      The session's primary thread can consult `model` mid-turn.

      - `type: "enabled"`

      - `model: string`

        A Claude model id. The model must be permitted as an advisor for this agent's model.

        minLength: 1, maxLength: 256

    - `BetaManagedAgentsMultiagentAdvisorDisabledParams object`

      The agent has no advisor.

      - `type: "disabled"`

  - `subagents: optional BetaManagedAgentsMultiagentSubagentsParams or null`

    Whether the agent can spawn session threads. Defaults to enabled.

    - `BetaManagedAgentsMultiagentSubagentsEnabledParams object`

      The agent can spawn session threads. Each thread runs a predefined agent, which is a saved agent in `predefined_agents`, or an inline agent, which the agent defines when it spawns the thread and which is not saved. If `inline_agents` is disabled, `predefined_agents` must name at least one agent.

      - `type: "enabled"`

      - `inline_agents: optional BetaManagedAgentsMultiagentInlineAgentsParams or null`

        Whether the agent can define inline agents when it spawns session threads. Defaults to enabled.

        - `BetaManagedAgentsMultiagentInlineAgentsEnabledParams object`

          The agent can define inline agents.

          - `type: "enabled"`

        - `BetaManagedAgentsMultiagentInlineAgentsDisabledParams object`

          The agent cannot define inline agents.

          - `type: "disabled"`

      - `predefined_agents: optional array of BetaManagedAgentsMultiagentPredefinedAgentParams or null`

        Predefined agents that this agent can spawn as session threads. At most 20. Defaults to null. Null and an empty list both mean no predefined agents. This list is separate from `workflows.predefined_agents`, and an agent in one list is not added to the other.

        - `string`

        - `BetaManagedAgentsAgentParams object`

          Specification for an Agent. Provide a specific `version` or use the short-form `agent="agent_id"` for the most recent version

          - `type: "agent"`

          - `id: string`

            The `agent` ID.

            minLength: 1, maxLength: 128

          - `version: optional number`

            The specific `agent` version to use. Omit to use the latest version. Must be at least 1 if specified.

            format: int32

        - `BetaManagedAgentsMultiagentSelfParams object`

          Sentinel roster entry meaning "the agent that owns this configuration". Resolved server-side to a concrete agent reference.

          - `type: "self"`

    - `BetaManagedAgentsMultiagentSubagentsDisabledParams object`

      The agent cannot spawn session threads.

      - `type: "disabled"`

  - `workflows: optional BetaManagedAgentsMultiagentWorkflowsParams or null`

    Whether the agent can start workflow runs. Defaults to enabled.

    - `BetaManagedAgentsMultiagentWorkflowsEnabledParams object`

      The agent can start workflow runs. Each run follows a plan, a program that the agent writes. A plan can use predefined agents, which are the saved agents in `predefined_agents`, and inline agents, which it defines itself and which are not saved. If `inline_agents` is disabled, `predefined_agents` must name at least one agent.

      - `type: "enabled"`

      - `inline_agents: optional BetaManagedAgentsMultiagentInlineAgentsParams or null`

        Whether a run's plan can define inline agents. Defaults to enabled.

      - `predefined_agents: optional array of BetaManagedAgentsMultiagentPredefinedAgentParams or null`

        Predefined agents that a run's plan can use. At most 20. Defaults to null. Null and an empty list both mean no predefined agents. This list is separate from `subagents.predefined_agents`, and an agent in one list is not added to the other.

        - `string`

        - `BetaManagedAgentsAgentParams object`

          Specification for an Agent. Provide a specific `version` or use the short-form `agent="agent_id"` for the most recent version

        - `BetaManagedAgentsMultiagentSelfParams object`

          Sentinel roster entry meaning "the agent that owns this configuration". Resolved server-side to a concrete agent reference.

    - `BetaManagedAgentsMultiagentWorkflowsDisabledParams object`

      The agent cannot start workflow runs.

      - `type: "disabled"`

### Beta Managed Agents Read Tool Config

- `BetaManagedAgentsReadToolConfig object`

  Configuration for the read tool.

  - `type: "read"`

  - `enabled: boolean`

  - `name: "read"`

  - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

    Permission policy for tool execution.

    - `BetaManagedAgentsAlwaysAllowPolicy object`

      Tool calls are automatically approved without user confirmation.

      - `type: "always_allow"`

    - `BetaManagedAgentsAlwaysAskPolicy object`

      Tool calls require user confirmation before execution.

      - `type: "always_ask"`

    - `BetaManagedAgentsAutoPolicy object`

      The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

      - `type: "auto"`

### Beta Managed Agents Read Tool Config Params

- `BetaManagedAgentsReadToolConfigParams object`

  Configuration override for the read tool.

  - `type: optional "read"`

  - `name: "read"`

    Must be "read".

  - `enabled: optional boolean or null`

    Whether this tool is enabled and available to Claude. Overrides the default_config setting.

  - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

    Permission policy for this tool. Controls whether tool calls are auto-approved or require confirmation.

    - `BetaManagedAgentsAlwaysAllowPolicy object`

      Tool calls are automatically approved without user confirmation.

      - `type: "always_allow"`

    - `BetaManagedAgentsAlwaysAskPolicy object`

      Tool calls require user confirmation before execution.

      - `type: "always_ask"`

    - `BetaManagedAgentsAutoPolicy object`

      The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

      - `type: "auto"`

### Beta Managed Agents Session Thread Agent

- `BetaManagedAgentsSessionThreadAgent object`

  Resolved `agent` definition for a single `session_thread`. Snapshot of the agent at thread creation time. The multiagent roster is not repeated here; read it from `Session.agent`.

  - `type: "agent"`

  - `id: string`

  - `description: string or null`

  - `mcp_servers: array of BetaManagedAgentsMCPServerURLDefinition`

    - `type: "url"`

    - `name: string`

    - `url: string`

  - `model: BetaManagedAgentsModelConfig`

    Model identifier and configuration.

    - `id: BetaManagedAgentsModel`

      The model that will power your agent.

      See [models](https://docs.anthropic.com/en/docs/models-overview) for additional details and options.

      - `"claude-haiku-5-5"`

        Fastest model for high-volume, real-time tasks

      - `"claude-sonnet-5-5"`

        Efficient model for coding and agents

      - `"claude-opus-5-5"`

        Powerful intelligence for coding, knowledge work, and long-running agents

      - `"claude-fable-5-1"`

        Frontier intelligence for ambitious tasks across coding, scientific discovery, and enterprise workflows

      - `"claude-sonnet-5"`

        Efficient model for coding and agents

      - `"claude-fable-5"`

        Next generation of intelligence for the hardest knowledge work and coding problems

      - `"claude-opus-5"`

        Powerful intelligence for long-running agents and coding

      - `"claude-opus-4-8"`

        Powerful intelligence for long-running agents and coding

      - `"claude-opus-4-7"`

        Powerful intelligence for long-running agents and coding

      - `"claude-opus-4-6"`

        Powerful intelligence for long-running agents and coding

      - `"claude-sonnet-4-6"`

        Best combination of speed and intelligence

      - `"claude-haiku-4-5"`

      - `"claude-haiku-4-5-20251001"`

      - `"claude-opus-4-5"`

        Powerful intelligence for long-running agents and coding

      - `"claude-opus-4-5-20251101"`

        Powerful intelligence for long-running agents and coding

      - `"claude-sonnet-4-5"`

        **Deprecated**: Will reach end-of-life on November 30, 2026. Please migrate to claude-sonnet-5-5. Visit https://docs.anthropic.com/en/docs/resources/model-deprecations for more information.

        High-performance model for agents and coding

      - `"claude-sonnet-4-5-20250929"`

        **Deprecated**: Will reach end-of-life on November 30, 2026. Please migrate to claude-sonnet-5-5. Visit https://docs.anthropic.com/en/docs/resources/model-deprecations for more information.

        High-performance model for agents and coding

      - `string`

    - `effort: optional BetaManagedAgentsEffortLow or BetaManagedAgentsEffortMedium or BetaManagedAgentsEffortHigh or 2 more`

      How hard Claude works on each inference call. One of `low`, `medium`, `high`, `xhigh`, `max`. Always present; resolved to the per-model default at save time when not supplied.

      - `BetaManagedAgentsEffortLow object`

        Low effort. Favors latency over reasoning depth.

        - `type: "low"`

      - `BetaManagedAgentsEffortMedium object`

        Medium effort. Balances latency and reasoning depth.

        - `type: "medium"`

      - `BetaManagedAgentsEffortHigh object`

        High effort. Favors reasoning depth.

        - `type: "high"`

      - `BetaManagedAgentsEffortXhigh object`

        Extra-high effort. Not all models accept this level.

        - `type: "xhigh"`

      - `BetaManagedAgentsEffortMax object`

        Maximum effort. Favors reasoning depth over latency.

        - `type: "max"`

    - `inference_geo: optional string`

      Geographic region for model inference. When unset, requests fall through to the workspace's default_inference_geo.

    - `speed: optional "standard" or "fast"`

      Inference speed mode. `fast` provides significantly faster output token generation at premium pricing. Defaults to `standard`. Not all models support `fast`; invalid combinations are rejected at create time.

      - `"standard"`

      - `"fast"`

  - `name: string`

  - `skills: array of BetaManagedAgentsAnthropicSkill or BetaManagedAgentsCustomSkill`

    - `BetaManagedAgentsAnthropicSkill object`

      A resolved Anthropic-managed skill.

      - `type: "anthropic"`

      - `skill_id: string`

      - `version: string`

    - `BetaManagedAgentsCustomSkill object`

      A resolved user-created custom skill.

      - `type: "custom"`

      - `skill_id: string`

      - `version: string`

  - `system: string or null`

  - `tools: array of BetaManagedAgentsAgentToolset20260401 or BetaManagedAgentsMCPToolset or BetaManagedAgentsCustomTool`

    - `BetaManagedAgentsAgentToolset20260401 object`

      - `type: "agent_toolset_20260401"`

      - `configs: array of BetaManagedAgentsAgentToolConfig`

        - `BetaManagedAgentsBashToolConfig object`

          Configuration for the bash tool.

          - `type: "bash"`

          - `enabled: boolean`

          - `name: "bash"`

          - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

            Permission policy for tool execution.

            - `BetaManagedAgentsAlwaysAllowPolicy object`

              Tool calls are automatically approved without user confirmation.

              - `type: "always_allow"`

            - `BetaManagedAgentsAlwaysAskPolicy object`

              Tool calls require user confirmation before execution.

              - `type: "always_ask"`

            - `BetaManagedAgentsAutoPolicy object`

              The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

              - `type: "auto"`

        - `BetaManagedAgentsEditToolConfig object`

          Configuration for the edit tool.

          - `type: "edit"`

          - `enabled: boolean`

          - `name: "edit"`

          - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

            Permission policy for tool execution.

            - `BetaManagedAgentsAlwaysAllowPolicy object`

              Tool calls are automatically approved without user confirmation.

            - `BetaManagedAgentsAlwaysAskPolicy object`

              Tool calls require user confirmation before execution.

            - `BetaManagedAgentsAutoPolicy object`

              The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

        - `BetaManagedAgentsReadToolConfig object`

          Configuration for the read tool.

          - `type: "read"`

          - `enabled: boolean`

          - `name: "read"`

          - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

            Permission policy for tool execution.

            - `BetaManagedAgentsAlwaysAllowPolicy object`

              Tool calls are automatically approved without user confirmation.

            - `BetaManagedAgentsAlwaysAskPolicy object`

              Tool calls require user confirmation before execution.

            - `BetaManagedAgentsAutoPolicy object`

              The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

        - `BetaManagedAgentsWriteToolConfig object`

          Configuration for the write tool.

          - `type: "write"`

          - `enabled: boolean`

          - `name: "write"`

          - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

            Permission policy for tool execution.

            - `BetaManagedAgentsAlwaysAllowPolicy object`

              Tool calls are automatically approved without user confirmation.

            - `BetaManagedAgentsAlwaysAskPolicy object`

              Tool calls require user confirmation before execution.

            - `BetaManagedAgentsAutoPolicy object`

              The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

        - `BetaManagedAgentsGlobToolConfig object`

          Configuration for the glob tool.

          - `type: "glob"`

          - `enabled: boolean`

          - `name: "glob"`

          - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

            Permission policy for tool execution.

            - `BetaManagedAgentsAlwaysAllowPolicy object`

              Tool calls are automatically approved without user confirmation.

            - `BetaManagedAgentsAlwaysAskPolicy object`

              Tool calls require user confirmation before execution.

            - `BetaManagedAgentsAutoPolicy object`

              The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

        - `BetaManagedAgentsGrepToolConfig object`

          Configuration for the grep tool.

          - `type: "grep"`

          - `enabled: boolean`

          - `name: "grep"`

          - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

            Permission policy for tool execution.

            - `BetaManagedAgentsAlwaysAllowPolicy object`

              Tool calls are automatically approved without user confirmation.

            - `BetaManagedAgentsAlwaysAskPolicy object`

              Tool calls require user confirmation before execution.

            - `BetaManagedAgentsAutoPolicy object`

              The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

        - `BetaManagedAgentsWebFetchToolConfig object`

          Configuration for the web_fetch tool.

          - `type: "web_fetch"`

          - `enabled: boolean`

          - `name: "web_fetch"`

          - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

            Permission policy for tool execution.

            - `BetaManagedAgentsAlwaysAllowPolicy object`

              Tool calls are automatically approved without user confirmation.

            - `BetaManagedAgentsAlwaysAskPolicy object`

              Tool calls require user confirmation before execution.

            - `BetaManagedAgentsAutoPolicy object`

              The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

          - `url_sources: BetaManagedAgentsWebFetchURLSources or null`

            Which sources contribute URLs the tool may fetch, always in the object form. Null when not set, which allows every source.

            - `client_tool_results: BetaManagedAgentsWebFetchURLSourceToolFilter or null`

              Which custom tools' results contribute URLs that may be fetched. Null when not set, which allows every custom tool's results.

              - `BetaManagedAgentsWebFetchURLSourceAll object`

                Every URL from this source may be fetched. This is the default.

                - `type: "all"`

              - `BetaManagedAgentsWebFetchURLSourceNone object`

                This source contributes no URLs that may be fetched.

                - `type: "none"`

              - `BetaManagedAgentsWebFetchURLSourceOnly object`

                Only the named tools' results contribute URLs that may be fetched.

                - `type: "only"`

                - `tools: array of BetaManagedAgentsWebFetchURLSourceToolReference`

                  The tools whose results contribute. Between 1 and 128 entries, each with a different name. An empty list is rejected; use "none" to allow no tool's results.

                  - `type: "tool_reference"`

                    Must be "tool_reference".

                  - `name: string`

                    Name of the tool. Compared exactly, so upper and lower case letters are different.

                    minLength: 1, maxLength: 128

              - `BetaManagedAgentsWebFetchURLSourceExcept object`

                Every tool's results contribute URLs that may be fetched, except the named tools' results.

                - `type: "except"`

                - `tools: array of BetaManagedAgentsWebFetchURLSourceToolReference`

                  The tools whose results do not contribute. Between 1 and 128 entries, each with a different name. An empty list is rejected; use "all" to leave out no tool's results.

                  - `type: "tool_reference"`

                    Must be "tool_reference".

                  - `name: string`

                    Name of the tool. Compared exactly, so upper and lower case letters are different.

                    minLength: 1, maxLength: 128

            - `server_tool_results: BetaManagedAgentsWebFetchURLSourceToolFilter or null`

              Which of the web_search and web_fetch tools' results contribute URLs that may be fetched. Null when not set, which allows both.

            - `user_input: BetaManagedAgentsWebFetchURLSourceUserInput or null`

              Whether URLs in the text of user messages may be fetched. Null when not set, which allows them.

              - `BetaManagedAgentsWebFetchURLSourceAll object`

                Every URL from this source may be fetched. This is the default.

              - `BetaManagedAgentsWebFetchURLSourceNone object`

                This source contributes no URLs that may be fetched.

          - `allowed_domains: optional array of string`

          - `blocked_domains: optional array of string`

          - `max_content_tokens: optional number or null`

            format: int32

        - `BetaManagedAgentsWebSearchToolConfig object`

          Configuration for the web_search tool.

          - `type: "web_search"`

          - `enabled: boolean`

          - `name: "web_search"`

          - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

            Permission policy for tool execution.

            - `BetaManagedAgentsAlwaysAllowPolicy object`

              Tool calls are automatically approved without user confirmation.

            - `BetaManagedAgentsAlwaysAskPolicy object`

              Tool calls require user confirmation before execution.

            - `BetaManagedAgentsAutoPolicy object`

              The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

          - `allowed_domains: optional array of string`

          - `blocked_domains: optional array of string`

          - `user_location: optional BetaManagedAgentsUserLocation or null`

            Approximate user location for search result localization.

            - `type: "approximate"`

              Location precision. Only "approximate" is supported.

            - `city: optional string or null`

              City name.

              minLength: 1, maxLength: 255

            - `country: optional string or null`

              Two-letter ISO 3166-1 country code, uppercase.

            - `region: optional string or null`

              Region or state name.

              minLength: 1, maxLength: 255

            - `timezone: optional string or null`

              IANA timezone identifier, e.g. "America/Los_Angeles".

              minLength: 1, maxLength: 255

      - `default_config: BetaManagedAgentsAgentToolsetDefaultConfig`

        Resolved default configuration for agent tools.

        - `enabled: boolean`

        - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

          Permission policy for tool execution.

          - `BetaManagedAgentsAlwaysAllowPolicy object`

            Tool calls are automatically approved without user confirmation.

          - `BetaManagedAgentsAlwaysAskPolicy object`

            Tool calls require user confirmation before execution.

          - `BetaManagedAgentsAutoPolicy object`

            The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

    - `BetaManagedAgentsMCPToolset object`

      - `type: "mcp_toolset"`

      - `configs: array of BetaManagedAgentsMCPToolConfig`

        - `enabled: boolean`

        - `name: string`

        - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

          Permission policy for tool execution.

          - `BetaManagedAgentsAlwaysAllowPolicy object`

            Tool calls are automatically approved without user confirmation.

          - `BetaManagedAgentsAlwaysAskPolicy object`

            Tool calls require user confirmation before execution.

          - `BetaManagedAgentsAutoPolicy object`

            The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

      - `default_config: BetaManagedAgentsMCPToolsetDefaultConfig`

        Resolved default configuration for all tools from an MCP server.

        - `enabled: boolean`

        - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

          Permission policy for tool execution.

          - `BetaManagedAgentsAlwaysAllowPolicy object`

            Tool calls are automatically approved without user confirmation.

          - `BetaManagedAgentsAlwaysAskPolicy object`

            Tool calls require user confirmation before execution.

          - `BetaManagedAgentsAutoPolicy object`

            The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

      - `mcp_server_name: string`

    - `BetaManagedAgentsCustomTool object`

      A custom tool as returned in API responses.

      - `type: "custom"`

      - `description: string`

      - `input_schema: BetaManagedAgentsCustomToolInputSchema`

        JSON Schema for custom tool input parameters.

        - `type: "object"`

        - `properties: optional map[unknown] or null`

        - `required: optional array of string or null`

      - `name: string`

  - `version: number`

    format: int32

### Beta Managed Agents Skill Params

- `BetaManagedAgentsSkillParams = BetaManagedAgentsAnthropicSkillParams or BetaManagedAgentsCustomSkillParams`

  Skill to load in the session container.

  - `BetaManagedAgentsAnthropicSkillParams object`

    An Anthropic-managed skill.

    - `type: "anthropic"`

    - `skill_id: string`

      Identifier of the Anthropic skill (e.g., "xlsx").

      minLength: 1, maxLength: 64

    - `version: optional string or null`

      Version to pin. Defaults to latest if omitted.

      minLength: 1, maxLength: 64

  - `BetaManagedAgentsCustomSkillParams object`

    A user-created custom skill.

    - `type: "custom"`

    - `skill_id: string`

      Tagged ID of the custom skill (e.g., "skill_01XJ5...").

      minLength: 1, maxLength: 64

    - `version: optional string or null`

      Version to pin. Defaults to latest if omitted.

      minLength: 1, maxLength: 64

### Beta Managed Agents URL MCP Server Params

- `BetaManagedAgentsURLMCPServerParams object`

  URL-based MCP server connection.

  - `type: "url"`

  - `name: string`

    Unique name for this server, referenced by mcp_toolset configurations. 1-255 characters.

    minLength: 1, maxLength: 255

  - `url: string`

    Endpoint URL for the MCP server.

    maxLength: 2048

### Beta Managed Agents User Location

- `BetaManagedAgentsUserLocation object`

  Approximate user location for search result localization.

  - `type: "approximate"`

    Location precision. Only "approximate" is supported.

  - `city: optional string or null`

    City name.

    minLength: 1, maxLength: 255

  - `country: optional string or null`

    Two-letter ISO 3166-1 country code, uppercase.

  - `region: optional string or null`

    Region or state name.

    minLength: 1, maxLength: 255

  - `timezone: optional string or null`

    IANA timezone identifier, e.g. "America/Los_Angeles".

    minLength: 1, maxLength: 255

### Beta Managed Agents Web Fetch Tool Config

- `BetaManagedAgentsWebFetchToolConfig object`

  Configuration for the web_fetch tool.

  - `type: "web_fetch"`

  - `enabled: boolean`

  - `name: "web_fetch"`

  - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

    Permission policy for tool execution.

    - `BetaManagedAgentsAlwaysAllowPolicy object`

      Tool calls are automatically approved without user confirmation.

      - `type: "always_allow"`

    - `BetaManagedAgentsAlwaysAskPolicy object`

      Tool calls require user confirmation before execution.

      - `type: "always_ask"`

    - `BetaManagedAgentsAutoPolicy object`

      The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

      - `type: "auto"`

  - `url_sources: BetaManagedAgentsWebFetchURLSources or null`

    Which sources contribute URLs the tool may fetch, always in the object form. Null when not set, which allows every source.

    - `client_tool_results: BetaManagedAgentsWebFetchURLSourceToolFilter or null`

      Which custom tools' results contribute URLs that may be fetched. Null when not set, which allows every custom tool's results.

      - `BetaManagedAgentsWebFetchURLSourceAll object`

        Every URL from this source may be fetched. This is the default.

        - `type: "all"`

      - `BetaManagedAgentsWebFetchURLSourceNone object`

        This source contributes no URLs that may be fetched.

        - `type: "none"`

      - `BetaManagedAgentsWebFetchURLSourceOnly object`

        Only the named tools' results contribute URLs that may be fetched.

        - `type: "only"`

        - `tools: array of BetaManagedAgentsWebFetchURLSourceToolReference`

          The tools whose results contribute. Between 1 and 128 entries, each with a different name. An empty list is rejected; use "none" to allow no tool's results.

          - `type: "tool_reference"`

            Must be "tool_reference".

          - `name: string`

            Name of the tool. Compared exactly, so upper and lower case letters are different.

            minLength: 1, maxLength: 128

      - `BetaManagedAgentsWebFetchURLSourceExcept object`

        Every tool's results contribute URLs that may be fetched, except the named tools' results.

        - `type: "except"`

        - `tools: array of BetaManagedAgentsWebFetchURLSourceToolReference`

          The tools whose results do not contribute. Between 1 and 128 entries, each with a different name. An empty list is rejected; use "all" to leave out no tool's results.

          - `type: "tool_reference"`

            Must be "tool_reference".

          - `name: string`

            Name of the tool. Compared exactly, so upper and lower case letters are different.

            minLength: 1, maxLength: 128

    - `server_tool_results: BetaManagedAgentsWebFetchURLSourceToolFilter or null`

      Which of the web_search and web_fetch tools' results contribute URLs that may be fetched. Null when not set, which allows both.

    - `user_input: BetaManagedAgentsWebFetchURLSourceUserInput or null`

      Whether URLs in the text of user messages may be fetched. Null when not set, which allows them.

      - `BetaManagedAgentsWebFetchURLSourceAll object`

        Every URL from this source may be fetched. This is the default.

      - `BetaManagedAgentsWebFetchURLSourceNone object`

        This source contributes no URLs that may be fetched.

  - `allowed_domains: optional array of string`

  - `blocked_domains: optional array of string`

  - `max_content_tokens: optional number or null`

    format: int32

### Beta Managed Agents Web Fetch Tool Config Params

- `BetaManagedAgentsWebFetchToolConfigParams object`

  Configuration override for the web_fetch tool.

  - `type: optional "web_fetch"`

  - `name: "web_fetch"`

    Must be "web_fetch".

  - `allowed_domains: optional array of string`

    Only fetch URLs whose host is one of these domains or a subdomain of one. Each entry is a plain hostname like "docs.example.com" (no scheme, port, or path). At most 64 entries; an empty list is rejected (omit the field instead). Cannot be combined with blocked_domains.

  - `blocked_domains: optional array of string`

    Never fetch URLs whose host is one of these domains or a subdomain of one. Each entry is a plain hostname like "ads.example.com" (no scheme, port, or path). At most 64 entries; an empty list is rejected (omit the field instead). Cannot be combined with allowed_domains.

  - `enabled: optional boolean or null`

    Whether this tool is enabled and available to Claude. Overrides the default_config setting.

  - `max_content_tokens: optional number or null`

    Maximum number of tokens of fetched text content to include in context per call. Does not apply to binary content such as PDFs.

    format: int32

  - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

    Permission policy for this tool. Controls whether tool calls are auto-approved or require confirmation.

    - `BetaManagedAgentsAlwaysAllowPolicy object`

      Tool calls are automatically approved without user confirmation.

      - `type: "always_allow"`

    - `BetaManagedAgentsAlwaysAskPolicy object`

      Tool calls require user confirmation before execution.

      - `type: "always_ask"`

    - `BetaManagedAgentsAutoPolicy object`

      The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

      - `type: "auto"`

  - `url_sources: optional BetaManagedAgentsWebFetchURLSourcesParams or null`

    Which sources contribute URLs the tool may fetch. Omit to allow every source.

    - `client_tool_results: optional BetaManagedAgentsWebFetchURLSourceToolFilterParams or null`

      Which custom tools' results contribute URLs that may be fetched: "all" (the default), "none", or an only or except list. Each name in a list must be a custom tool in the same tools array.

      - `BetaManagedAgentsWebFetchURLSourceShorthand = "all" or "none"`

        String form of a url_sources value that has no field other than its type: "all" means {"type": "all"} and "none" means {"type": "none"}.

        - `"all"`

        - `"none"`

      - `BetaManagedAgentsWebFetchURLSourceToolFilter = BetaManagedAgentsWebFetchURLSourceAll or BetaManagedAgentsWebFetchURLSourceNone or BetaManagedAgentsWebFetchURLSourceOnly or BetaManagedAgentsWebFetchURLSourceExcept`

        Which tools' results contribute URLs that may be fetched.

        - `BetaManagedAgentsWebFetchURLSourceAll object`

          Every URL from this source may be fetched. This is the default.

          - `type: "all"`

        - `BetaManagedAgentsWebFetchURLSourceNone object`

          This source contributes no URLs that may be fetched.

          - `type: "none"`

        - `BetaManagedAgentsWebFetchURLSourceOnly object`

          Only the named tools' results contribute URLs that may be fetched.

          - `type: "only"`

          - `tools: array of BetaManagedAgentsWebFetchURLSourceToolReference`

            The tools whose results contribute. Between 1 and 128 entries, each with a different name. An empty list is rejected; use "none" to allow no tool's results.

            - `type: "tool_reference"`

              Must be "tool_reference".

            - `name: string`

              Name of the tool. Compared exactly, so upper and lower case letters are different.

              minLength: 1, maxLength: 128

        - `BetaManagedAgentsWebFetchURLSourceExcept object`

          Every tool's results contribute URLs that may be fetched, except the named tools' results.

          - `type: "except"`

          - `tools: array of BetaManagedAgentsWebFetchURLSourceToolReference`

            The tools whose results do not contribute. Between 1 and 128 entries, each with a different name. An empty list is rejected; use "all" to leave out no tool's results.

            - `type: "tool_reference"`

              Must be "tool_reference".

            - `name: string`

              Name of the tool. Compared exactly, so upper and lower case letters are different.

              minLength: 1, maxLength: 128

    - `server_tool_results: optional BetaManagedAgentsWebFetchURLSourceToolFilterParams or null`

      Which of the web_search and web_fetch tools' results contribute URLs that may be fetched: "all" (the default), "none", or an only or except list. Each name in a list must be "web_search" or "web_fetch".

    - `user_input: optional BetaManagedAgentsWebFetchURLSourceUserInputParams or null`

      Whether URLs in the text of user messages may be fetched: "all" (the default) or "none".

      - `BetaManagedAgentsWebFetchURLSourceShorthand = "all" or "none"`

        String form of a url_sources value that has no field other than its type: "all" means {"type": "all"} and "none" means {"type": "none"}.

      - `BetaManagedAgentsWebFetchURLSourceUserInput = BetaManagedAgentsWebFetchURLSourceAll or BetaManagedAgentsWebFetchURLSourceNone`

        Whether URLs in the text of user messages may be fetched.

        - `BetaManagedAgentsWebFetchURLSourceAll object`

          Every URL from this source may be fetched. This is the default.

        - `BetaManagedAgentsWebFetchURLSourceNone object`

          This source contributes no URLs that may be fetched.

### Beta Managed Agents Web Fetch URL Source All

- `BetaManagedAgentsWebFetchURLSourceAll object`

  Every URL from this source may be fetched. This is the default.

  - `type: "all"`

### Beta Managed Agents Web Fetch URL Source Except

- `BetaManagedAgentsWebFetchURLSourceExcept object`

  Every tool's results contribute URLs that may be fetched, except the named tools' results.

  - `type: "except"`

  - `tools: array of BetaManagedAgentsWebFetchURLSourceToolReference`

    The tools whose results do not contribute. Between 1 and 128 entries, each with a different name. An empty list is rejected; use "all" to leave out no tool's results.

    - `type: "tool_reference"`

      Must be "tool_reference".

    - `name: string`

      Name of the tool. Compared exactly, so upper and lower case letters are different.

      minLength: 1, maxLength: 128

### Beta Managed Agents Web Fetch URL Source None

- `BetaManagedAgentsWebFetchURLSourceNone object`

  This source contributes no URLs that may be fetched.

  - `type: "none"`

### Beta Managed Agents Web Fetch URL Source Only

- `BetaManagedAgentsWebFetchURLSourceOnly object`

  Only the named tools' results contribute URLs that may be fetched.

  - `type: "only"`

  - `tools: array of BetaManagedAgentsWebFetchURLSourceToolReference`

    The tools whose results contribute. Between 1 and 128 entries, each with a different name. An empty list is rejected; use "none" to allow no tool's results.

    - `type: "tool_reference"`

      Must be "tool_reference".

    - `name: string`

      Name of the tool. Compared exactly, so upper and lower case letters are different.

      minLength: 1, maxLength: 128

### Beta Managed Agents Web Fetch URL Source Shorthand

- `BetaManagedAgentsWebFetchURLSourceShorthand = "all" or "none"`

  String form of a url_sources value that has no field other than its type: "all" means {"type": "all"} and "none" means {"type": "none"}.

  - `"all"`

  - `"none"`

### Beta Managed Agents Web Fetch URL Source Tool Filter

- `BetaManagedAgentsWebFetchURLSourceToolFilter = BetaManagedAgentsWebFetchURLSourceAll or BetaManagedAgentsWebFetchURLSourceNone or BetaManagedAgentsWebFetchURLSourceOnly or BetaManagedAgentsWebFetchURLSourceExcept`

  Which tools' results contribute URLs that may be fetched.

  - `BetaManagedAgentsWebFetchURLSourceAll object`

    Every URL from this source may be fetched. This is the default.

    - `type: "all"`

  - `BetaManagedAgentsWebFetchURLSourceNone object`

    This source contributes no URLs that may be fetched.

    - `type: "none"`

  - `BetaManagedAgentsWebFetchURLSourceOnly object`

    Only the named tools' results contribute URLs that may be fetched.

    - `type: "only"`

    - `tools: array of BetaManagedAgentsWebFetchURLSourceToolReference`

      The tools whose results contribute. Between 1 and 128 entries, each with a different name. An empty list is rejected; use "none" to allow no tool's results.

      - `type: "tool_reference"`

        Must be "tool_reference".

      - `name: string`

        Name of the tool. Compared exactly, so upper and lower case letters are different.

        minLength: 1, maxLength: 128

  - `BetaManagedAgentsWebFetchURLSourceExcept object`

    Every tool's results contribute URLs that may be fetched, except the named tools' results.

    - `type: "except"`

    - `tools: array of BetaManagedAgentsWebFetchURLSourceToolReference`

      The tools whose results do not contribute. Between 1 and 128 entries, each with a different name. An empty list is rejected; use "all" to leave out no tool's results.

      - `type: "tool_reference"`

        Must be "tool_reference".

      - `name: string`

        Name of the tool. Compared exactly, so upper and lower case letters are different.

        minLength: 1, maxLength: 128

### Beta Managed Agents Web Fetch URL Source Tool Filter Params

- `BetaManagedAgentsWebFetchURLSourceToolFilterParams = BetaManagedAgentsWebFetchURLSourceShorthand or BetaManagedAgentsWebFetchURLSourceToolFilter`

  Which tools' results contribute URLs that may be fetched. Accepts the string "all" or "none", or an object whose type is "all", "none", "only" or "except". Responses use the object form.

  - `BetaManagedAgentsWebFetchURLSourceShorthand = "all" or "none"`

    String form of a url_sources value that has no field other than its type: "all" means {"type": "all"} and "none" means {"type": "none"}.

    - `"all"`

    - `"none"`

  - `BetaManagedAgentsWebFetchURLSourceToolFilter = BetaManagedAgentsWebFetchURLSourceAll or BetaManagedAgentsWebFetchURLSourceNone or BetaManagedAgentsWebFetchURLSourceOnly or BetaManagedAgentsWebFetchURLSourceExcept`

    Which tools' results contribute URLs that may be fetched.

    - `BetaManagedAgentsWebFetchURLSourceAll object`

      Every URL from this source may be fetched. This is the default.

      - `type: "all"`

    - `BetaManagedAgentsWebFetchURLSourceNone object`

      This source contributes no URLs that may be fetched.

      - `type: "none"`

    - `BetaManagedAgentsWebFetchURLSourceOnly object`

      Only the named tools' results contribute URLs that may be fetched.

      - `type: "only"`

      - `tools: array of BetaManagedAgentsWebFetchURLSourceToolReference`

        The tools whose results contribute. Between 1 and 128 entries, each with a different name. An empty list is rejected; use "none" to allow no tool's results.

        - `type: "tool_reference"`

          Must be "tool_reference".

        - `name: string`

          Name of the tool. Compared exactly, so upper and lower case letters are different.

          minLength: 1, maxLength: 128

    - `BetaManagedAgentsWebFetchURLSourceExcept object`

      Every tool's results contribute URLs that may be fetched, except the named tools' results.

      - `type: "except"`

      - `tools: array of BetaManagedAgentsWebFetchURLSourceToolReference`

        The tools whose results do not contribute. Between 1 and 128 entries, each with a different name. An empty list is rejected; use "all" to leave out no tool's results.

        - `type: "tool_reference"`

          Must be "tool_reference".

        - `name: string`

          Name of the tool. Compared exactly, so upper and lower case letters are different.

          minLength: 1, maxLength: 128

### Beta Managed Agents Web Fetch URL Source Tool Reference

- `BetaManagedAgentsWebFetchURLSourceToolReference object`

  Names one tool in an only or except list.

  - `type: "tool_reference"`

    Must be "tool_reference".

  - `name: string`

    Name of the tool. Compared exactly, so upper and lower case letters are different.

    minLength: 1, maxLength: 128

### Beta Managed Agents Web Fetch URL Source User Input

- `BetaManagedAgentsWebFetchURLSourceUserInput = BetaManagedAgentsWebFetchURLSourceAll or BetaManagedAgentsWebFetchURLSourceNone`

  Whether URLs in the text of user messages may be fetched.

  - `BetaManagedAgentsWebFetchURLSourceAll object`

    Every URL from this source may be fetched. This is the default.

    - `type: "all"`

  - `BetaManagedAgentsWebFetchURLSourceNone object`

    This source contributes no URLs that may be fetched.

    - `type: "none"`

### Beta Managed Agents Web Fetch URL Source User Input Params

- `BetaManagedAgentsWebFetchURLSourceUserInputParams = BetaManagedAgentsWebFetchURLSourceShorthand or BetaManagedAgentsWebFetchURLSourceUserInput`

  Whether URLs in the text of user messages may be fetched. Accepts the string "all" or "none", or the object {"type": "all"} or {"type": "none"}. Responses use the object form.

  - `BetaManagedAgentsWebFetchURLSourceShorthand = "all" or "none"`

    String form of a url_sources value that has no field other than its type: "all" means {"type": "all"} and "none" means {"type": "none"}.

    - `"all"`

    - `"none"`

  - `BetaManagedAgentsWebFetchURLSourceUserInput = BetaManagedAgentsWebFetchURLSourceAll or BetaManagedAgentsWebFetchURLSourceNone`

    Whether URLs in the text of user messages may be fetched.

    - `BetaManagedAgentsWebFetchURLSourceAll object`

      Every URL from this source may be fetched. This is the default.

      - `type: "all"`

    - `BetaManagedAgentsWebFetchURLSourceNone object`

      This source contributes no URLs that may be fetched.

      - `type: "none"`

### Beta Managed Agents Web Fetch URL Sources

- `BetaManagedAgentsWebFetchURLSources object`

  Which sources contribute URLs the web_fetch tool may fetch. A key that is null was not set and allows every URL from that source.

  - `client_tool_results: BetaManagedAgentsWebFetchURLSourceToolFilter or null`

    Which custom tools' results contribute URLs that may be fetched. Null when not set, which allows every custom tool's results.

    - `BetaManagedAgentsWebFetchURLSourceAll object`

      Every URL from this source may be fetched. This is the default.

      - `type: "all"`

    - `BetaManagedAgentsWebFetchURLSourceNone object`

      This source contributes no URLs that may be fetched.

      - `type: "none"`

    - `BetaManagedAgentsWebFetchURLSourceOnly object`

      Only the named tools' results contribute URLs that may be fetched.

      - `type: "only"`

      - `tools: array of BetaManagedAgentsWebFetchURLSourceToolReference`

        The tools whose results contribute. Between 1 and 128 entries, each with a different name. An empty list is rejected; use "none" to allow no tool's results.

        - `type: "tool_reference"`

          Must be "tool_reference".

        - `name: string`

          Name of the tool. Compared exactly, so upper and lower case letters are different.

          minLength: 1, maxLength: 128

    - `BetaManagedAgentsWebFetchURLSourceExcept object`

      Every tool's results contribute URLs that may be fetched, except the named tools' results.

      - `type: "except"`

      - `tools: array of BetaManagedAgentsWebFetchURLSourceToolReference`

        The tools whose results do not contribute. Between 1 and 128 entries, each with a different name. An empty list is rejected; use "all" to leave out no tool's results.

        - `type: "tool_reference"`

          Must be "tool_reference".

        - `name: string`

          Name of the tool. Compared exactly, so upper and lower case letters are different.

          minLength: 1, maxLength: 128

  - `server_tool_results: BetaManagedAgentsWebFetchURLSourceToolFilter or null`

    Which of the web_search and web_fetch tools' results contribute URLs that may be fetched. Null when not set, which allows both.

  - `user_input: BetaManagedAgentsWebFetchURLSourceUserInput or null`

    Whether URLs in the text of user messages may be fetched. Null when not set, which allows them.

    - `BetaManagedAgentsWebFetchURLSourceAll object`

      Every URL from this source may be fetched. This is the default.

    - `BetaManagedAgentsWebFetchURLSourceNone object`

      This source contributes no URLs that may be fetched.

### Beta Managed Agents Web Fetch URL Sources Params

- `BetaManagedAgentsWebFetchURLSourcesParams object`

  Which sources contribute URLs the web_fetch tool may fetch. When web_fetch is limited to URLs the conversation has already shown the model (in a user message, a custom tool's result, or an earlier web_search or web_fetch result), each key narrows one of those sources and defaults to "all". Setting all three keys to "none" is rejected.

  - `client_tool_results: optional BetaManagedAgentsWebFetchURLSourceToolFilterParams or null`

    Which custom tools' results contribute URLs that may be fetched: "all" (the default), "none", or an only or except list. Each name in a list must be a custom tool in the same tools array.

    - `BetaManagedAgentsWebFetchURLSourceShorthand = "all" or "none"`

      String form of a url_sources value that has no field other than its type: "all" means {"type": "all"} and "none" means {"type": "none"}.

      - `"all"`

      - `"none"`

    - `BetaManagedAgentsWebFetchURLSourceToolFilter = BetaManagedAgentsWebFetchURLSourceAll or BetaManagedAgentsWebFetchURLSourceNone or BetaManagedAgentsWebFetchURLSourceOnly or BetaManagedAgentsWebFetchURLSourceExcept`

      Which tools' results contribute URLs that may be fetched.

      - `BetaManagedAgentsWebFetchURLSourceAll object`

        Every URL from this source may be fetched. This is the default.

        - `type: "all"`

      - `BetaManagedAgentsWebFetchURLSourceNone object`

        This source contributes no URLs that may be fetched.

        - `type: "none"`

      - `BetaManagedAgentsWebFetchURLSourceOnly object`

        Only the named tools' results contribute URLs that may be fetched.

        - `type: "only"`

        - `tools: array of BetaManagedAgentsWebFetchURLSourceToolReference`

          The tools whose results contribute. Between 1 and 128 entries, each with a different name. An empty list is rejected; use "none" to allow no tool's results.

          - `type: "tool_reference"`

            Must be "tool_reference".

          - `name: string`

            Name of the tool. Compared exactly, so upper and lower case letters are different.

            minLength: 1, maxLength: 128

      - `BetaManagedAgentsWebFetchURLSourceExcept object`

        Every tool's results contribute URLs that may be fetched, except the named tools' results.

        - `type: "except"`

        - `tools: array of BetaManagedAgentsWebFetchURLSourceToolReference`

          The tools whose results do not contribute. Between 1 and 128 entries, each with a different name. An empty list is rejected; use "all" to leave out no tool's results.

          - `type: "tool_reference"`

            Must be "tool_reference".

          - `name: string`

            Name of the tool. Compared exactly, so upper and lower case letters are different.

            minLength: 1, maxLength: 128

  - `server_tool_results: optional BetaManagedAgentsWebFetchURLSourceToolFilterParams or null`

    Which of the web_search and web_fetch tools' results contribute URLs that may be fetched: "all" (the default), "none", or an only or except list. Each name in a list must be "web_search" or "web_fetch".

  - `user_input: optional BetaManagedAgentsWebFetchURLSourceUserInputParams or null`

    Whether URLs in the text of user messages may be fetched: "all" (the default) or "none".

    - `BetaManagedAgentsWebFetchURLSourceShorthand = "all" or "none"`

      String form of a url_sources value that has no field other than its type: "all" means {"type": "all"} and "none" means {"type": "none"}.

    - `BetaManagedAgentsWebFetchURLSourceUserInput = BetaManagedAgentsWebFetchURLSourceAll or BetaManagedAgentsWebFetchURLSourceNone`

      Whether URLs in the text of user messages may be fetched.

      - `BetaManagedAgentsWebFetchURLSourceAll object`

        Every URL from this source may be fetched. This is the default.

      - `BetaManagedAgentsWebFetchURLSourceNone object`

        This source contributes no URLs that may be fetched.

### Beta Managed Agents Web Search Tool Config

- `BetaManagedAgentsWebSearchToolConfig object`

  Configuration for the web_search tool.

  - `type: "web_search"`

  - `enabled: boolean`

  - `name: "web_search"`

  - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

    Permission policy for tool execution.

    - `BetaManagedAgentsAlwaysAllowPolicy object`

      Tool calls are automatically approved without user confirmation.

      - `type: "always_allow"`

    - `BetaManagedAgentsAlwaysAskPolicy object`

      Tool calls require user confirmation before execution.

      - `type: "always_ask"`

    - `BetaManagedAgentsAutoPolicy object`

      The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

      - `type: "auto"`

  - `allowed_domains: optional array of string`

  - `blocked_domains: optional array of string`

  - `user_location: optional BetaManagedAgentsUserLocation or null`

    Approximate user location for search result localization.

    - `type: "approximate"`

      Location precision. Only "approximate" is supported.

    - `city: optional string or null`

      City name.

      minLength: 1, maxLength: 255

    - `country: optional string or null`

      Two-letter ISO 3166-1 country code, uppercase.

    - `region: optional string or null`

      Region or state name.

      minLength: 1, maxLength: 255

    - `timezone: optional string or null`

      IANA timezone identifier, e.g. "America/Los_Angeles".

      minLength: 1, maxLength: 255

### Beta Managed Agents Web Search Tool Config Params

- `BetaManagedAgentsWebSearchToolConfigParams object`

  Configuration override for the web_search tool.

  - `type: optional "web_search"`

  - `name: "web_search"`

    Must be "web_search".

  - `allowed_domains: optional array of string`

    Only return search results whose host is one of these domains or a subdomain of one. Each entry is a plain hostname like "docs.example.com" (no scheme or port; an optional path suffix is accepted). At most 64 entries; an empty list is rejected (omit the field instead). Cannot be combined with blocked_domains.

  - `blocked_domains: optional array of string`

    Never return search results whose host is one of these domains or a subdomain of one. Each entry is a plain hostname like "ads.example.com" (no scheme or port; an optional path suffix is accepted). At most 64 entries; an empty list is rejected (omit the field instead). Cannot be combined with allowed_domains.

  - `enabled: optional boolean or null`

    Whether this tool is enabled and available to Claude. Overrides the default_config setting.

  - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

    Permission policy for this tool. Controls whether tool calls are auto-approved or require confirmation.

    - `BetaManagedAgentsAlwaysAllowPolicy object`

      Tool calls are automatically approved without user confirmation.

      - `type: "always_allow"`

    - `BetaManagedAgentsAlwaysAskPolicy object`

      Tool calls require user confirmation before execution.

      - `type: "always_ask"`

    - `BetaManagedAgentsAutoPolicy object`

      The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

      - `type: "auto"`

  - `user_location: optional BetaManagedAgentsUserLocation or null`

    Approximate user location for search result localization.

    - `type: "approximate"`

      Location precision. Only "approximate" is supported.

    - `city: optional string or null`

      City name.

      minLength: 1, maxLength: 255

    - `country: optional string or null`

      Two-letter ISO 3166-1 country code, uppercase.

    - `region: optional string or null`

      Region or state name.

      minLength: 1, maxLength: 255

    - `timezone: optional string or null`

      IANA timezone identifier, e.g. "America/Los_Angeles".

      minLength: 1, maxLength: 255

### Beta Managed Agents Write Tool Config

- `BetaManagedAgentsWriteToolConfig object`

  Configuration for the write tool.

  - `type: "write"`

  - `enabled: boolean`

  - `name: "write"`

  - `permission_policy: BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy`

    Permission policy for tool execution.

    - `BetaManagedAgentsAlwaysAllowPolicy object`

      Tool calls are automatically approved without user confirmation.

      - `type: "always_allow"`

    - `BetaManagedAgentsAlwaysAskPolicy object`

      Tool calls require user confirmation before execution.

      - `type: "always_ask"`

    - `BetaManagedAgentsAutoPolicy object`

      The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

      - `type: "auto"`

### Beta Managed Agents Write Tool Config Params

- `BetaManagedAgentsWriteToolConfigParams object`

  Configuration override for the write tool.

  - `type: optional "write"`

  - `name: "write"`

    Must be "write".

  - `enabled: optional boolean or null`

    Whether this tool is enabled and available to Claude. Overrides the default_config setting.

  - `permission_policy: optional BetaManagedAgentsAlwaysAllowPolicy or BetaManagedAgentsAlwaysAskPolicy or BetaManagedAgentsAutoPolicy or null`

    Permission policy for this tool. Controls whether tool calls are auto-approved or require confirmation.

    - `BetaManagedAgentsAlwaysAllowPolicy object`

      Tool calls are automatically approved without user confirmation.

      - `type: "always_allow"`

    - `BetaManagedAgentsAlwaysAskPolicy object`

      Tool calls require user confirmation before execution.

      - `type: "always_ask"`

    - `BetaManagedAgentsAutoPolicy object`

      The server decides each tool call individually: it judges, from the tool, its input, and the session content so far, whether the call is safe to execute or high-risk, and evaluates it to allow when judged safe and to deny when judged high-risk. A call the server cannot reach a judgement on evaluates to ask.

      - `type: "auto"`

