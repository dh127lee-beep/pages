---
title: Create Credential
url: https://platform.claude.com/docs/en/api/beta/vaults/credentials/create
---

# Create Credential

**POST** `/v1/vaults/{vault_id}/credentials`

Create Credential

## Path parameters

- `vault_id: string`

  Identifier of the vault to create the credential in.

## Headers

- `"anthropic-version": optional string`

- `"anthropic-beta": optional array of AnthropicBeta`

  Optional header to specify the beta version(s) you want to use. (전체 enum 목록 생략 — Managed Agents는 `managed-agents-2026-04-01`, Dreams는 `dreaming-2026-04-21`, Tunnels는 `mcp-tunnels-2026-06-22`)

- `"anthropic-workspace-id": optional string`

  Optional header to select the Workspace for this request. The value is a Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).

  Only needed for credentials that can act on more than one Workspace. A credential that belongs to a specific Workspace may omit it; if sent, it must match that Workspace.

## Body parameters

- `auth: BetaManagedAgentsMCPOAuthCreateParams or BetaManagedAgentsStaticBearerCreateParams or BetaManagedAgentsEnvironmentVariableCreateParams`

  Authentication configuration for the credential.

  - `BetaManagedAgentsMCPOAuthCreateParams object`

    Parameters for creating an MCP OAuth credential.

    - `type: "mcp_oauth"`

    - `access_token: string`

      OAuth access token.

      minLength: 1, maxLength: 8192

    - `mcp_server_url: string`

      URL of the MCP server this credential authenticates against.

      minLength: 1, maxLength: 2047

    - `expires_at: optional string or null`

      A timestamp in RFC 3339 format

      format: date-time

    - `refresh: optional BetaManagedAgentsMCPOAuthRefreshParams or null`

      Refresh token configuration, if the credential supports token refresh.

      - `client_id: string`

        OAuth client ID.

        minLength: 1, maxLength: 1024

      - `refresh_token: string`

        OAuth refresh token.

        minLength: 1, maxLength: 8192

      - `token_endpoint: string`

        Token endpoint URL used to refresh the access token.

        minLength: 1, maxLength: 2047

      - `token_endpoint_auth: BetaManagedAgentsTokenEndpointAuthNoneParam or BetaManagedAgentsTokenEndpointAuthBasicParam or BetaManagedAgentsTokenEndpointAuthPostParam`

        - `BetaManagedAgentsTokenEndpointAuthNoneParam object`

          Token endpoint requires no client authentication.

          - `type: "none"`

        - `BetaManagedAgentsTokenEndpointAuthBasicParam object`

          Token endpoint uses HTTP Basic authentication with client credentials.

          - `type: "client_secret_basic"`

          - `client_secret: string`

            OAuth client secret.

            minLength: 1, maxLength: 512

        - `BetaManagedAgentsTokenEndpointAuthPostParam object`

          Token endpoint uses POST body authentication with client credentials.

          - `type: "client_secret_post"`

          - `client_secret: string`

            OAuth client secret.

            minLength: 1, maxLength: 512

      - `resource: optional string or null`

        OAuth resource indicator.

        minLength: 1, maxLength: 2047

      - `scope: optional string or null`

        OAuth scope for the refresh request.

        minLength: 1, maxLength: 8192

  - `BetaManagedAgentsStaticBearerCreateParams object`

    Parameters for creating a static bearer token credential.

    - `type: "static_bearer"`

    - `token: string`

      Static bearer token value.

      minLength: 1, maxLength: 8192

    - `mcp_server_url: string`

      URL of the MCP server this credential authenticates against.

      minLength: 1, maxLength: 2047

  - `BetaManagedAgentsEnvironmentVariableCreateParams object`

    Parameters for creating an environment variable credential.

    - `type: "environment_variable"`

    - `networking: BetaManagedAgentsCredentialNetworkingParams`

      Outbound hosts the secret value is substituted on.

      - `BetaManagedAgentsUnrestrictedCredentialNetworkingParams object`

        Substitute the secret on any host the session's Environment network policy permits egress to. The Environment's network policy is the only boundary on where the secret can reach.

        - `type: "unrestricted"`

      - `BetaManagedAgentsLimitedCredentialNetworkingParams object`

        Substitute the secret only on requests to the listed hosts.

        - `type: "limited"`

        - `allowed_hosts: array of string`

          Hostnames on which the secret will be substituted. Each entry is a bare hostname (`api.example.com`), an IPv4 address (`192.0.2.1`), or a `*.`-prefixed wildcard (`*.example.com`). URLs, ports, paths, and IPv6 addresses are not accepted. At most 16 entries.

    - `secret_name: string`

      Name of the environment variable. Immutable after create.

      minLength: 1, maxLength: 255

    - `secret_value: string`

      Secret value. Write-only; never returned in responses.

      minLength: 1, maxLength: 4096

    - `injection_location: optional BetaManagedAgentsInjectionLocationParams`

      Where in the outbound request the secret value may be substituted.

      - `body: optional boolean`

        Substitute when the placeholder appears in the request body.

      - `header: optional boolean`

        Substitute when the placeholder appears in a request header value.

- `display_name: optional string or null`

  Human-readable name for the credential. Up to 255 characters.

  maxLength: 255

- `metadata: optional map[string]`

  Arbitrary key-value metadata to attach to the credential. Maximum 16 pairs, keys up to 64 chars, values up to 512 chars.

## Returns

- `BetaManagedAgentsCredential object`

  A credential stored in a vault. Sensitive fields are never returned in responses.

  - `type: "vault_credential"`

  - `id: string`

    Unique identifier for the credential.

  - `archived_at: string or null`

    When the credential was archived. Null if not archived.

    format: date-time

  - `auth: BetaManagedAgentsMCPOAuthAuthResponse or BetaManagedAgentsStaticBearerAuthResponse or BetaManagedAgentsEnvironmentVariableAuthResponse`

    Authentication configuration for this credential.

    - `BetaManagedAgentsMCPOAuthAuthResponse object`

      OAuth credential details for an MCP server.

      - `type: "mcp_oauth"`

      - `mcp_server_url: string`

        URL of the MCP server this credential authenticates against.

      - `expires_at: optional string or null`

        A timestamp in RFC 3339 format

        format: date-time

      - `refresh: optional BetaManagedAgentsMCPOAuthRefreshResponse or null`

        Refresh token configuration, if the credential supports token refresh.

        - `client_id: string`

          OAuth client ID.

        - `token_endpoint: string`

          Token endpoint URL used to refresh the access token.

        - `token_endpoint_auth: BetaManagedAgentsTokenEndpointAuthNoneResponse or BetaManagedAgentsTokenEndpointAuthBasicResponse or BetaManagedAgentsTokenEndpointAuthPostResponse`

          - `BetaManagedAgentsTokenEndpointAuthNoneResponse object`

            Token endpoint requires no client authentication.

            - `type: "none"`

          - `BetaManagedAgentsTokenEndpointAuthBasicResponse object`

            Token endpoint uses HTTP Basic authentication with client credentials.

            - `type: "client_secret_basic"`

          - `BetaManagedAgentsTokenEndpointAuthPostResponse object`

            Token endpoint uses POST body authentication with client credentials.

            - `type: "client_secret_post"`

        - `resource: optional string or null`

          OAuth resource indicator.

        - `scope: optional string or null`

          OAuth scope for the refresh request.

    - `BetaManagedAgentsStaticBearerAuthResponse object`

      Static bearer token credential details for an MCP server.

      - `type: "static_bearer"`

      - `mcp_server_url: string`

        URL of the MCP server this credential authenticates against.

    - `BetaManagedAgentsEnvironmentVariableAuthResponse object`

      Environment variable credential details. The secret value is never returned.

      - `type: "environment_variable"`

      - `injection_location: BetaManagedAgentsInjectionLocationResponse`

        Where in the outbound request the secret value is substituted.

        - `body: boolean`

          Whether the placeholder is substituted in the request body.

        - `header: boolean`

          Whether the placeholder is substituted in request header values.

      - `networking: BetaManagedAgentsUnrestrictedCredentialNetworkingResponse or BetaManagedAgentsLimitedCredentialNetworkingResponse`

        Outbound hosts the secret value is substituted on.

        - `BetaManagedAgentsUnrestrictedCredentialNetworkingResponse object`

          The secret is substituted on any host the session's Environment network policy permits egress to.

          - `type: "unrestricted"`

        - `BetaManagedAgentsLimitedCredentialNetworkingResponse object`

          The secret is substituted only on requests to the listed hosts.

          - `type: "limited"`

          - `allowed_hosts: array of string`

            Hostnames on which the secret will be substituted. An entry matches the request host exactly; a `*.`-prefixed entry matches any subdomain of the named domain but not the domain itself.

      - `secret_name: string`

        Name of the environment variable.

  - `created_at: string`

    A timestamp in RFC 3339 format

    format: date-time

  - `metadata: map[string]`

    Arbitrary key-value metadata attached to the credential.

  - `updated_at: string`

    A timestamp in RFC 3339 format

    format: date-time

  - `vault_id: string`

    Identifier of the vault this credential belongs to.

  - `display_name: optional string or null`

    Human-readable name for the credential.

## Example

```bash
curl https://api.anthropic.com/v1/vaults/$VAULT_ID/credentials \
    -H 'Content-Type: application/json' \
    -H 'anthropic-version: 2023-06-01' \
    -H 'anthropic-beta: managed-agents-2026-04-01' \
    -H "X-Api-Key: $ANTHROPIC_API_KEY" \
    -d '{
          "auth": {
            "token": "bearer_exampletoken",
            "mcp_server_url": "https://example-server.modelcontextprotocol.io/sse",
            "type": "static_bearer"
          },
          "display_name": "Example credential",
          "metadata": {
            "environment": "production"
          }
        }'
```

### Response (200)

```json
{
  "id": "vcrd_011CZkZEMt8gZan2iYPQfSkw",
  "archived_at": null,
  "auth": {
    "mcp_server_url": "https://example-server.modelcontextprotocol.io/sse",
    "type": "static_bearer"
  },
  "created_at": "2026-03-15T10:00:00Z",
  "metadata": {
    "environment": "production"
  },
  "type": "vault_credential",
  "updated_at": "2026-03-15T10:00:00Z",
  "vault_id": "vlt_011CZkZDLs7fYzm1hXNPeRjv",
  "display_name": "Example credential"
}
```
