---
title: Validate Credential
url: https://platform.claude.com/docs/en/api/beta/vaults/credentials/mcp_oauth_validate
---

# Validate Credential

**POST** `/v1/vaults/{vault_id}/credentials/{credential_id}/mcp_oauth_validate`

Validate Credential

## Path parameters

- `vault_id: string`

  Identifier of the vault containing the credential.

- `credential_id: string`

  Unique identifier of the credential to validate.

## Headers

- `"anthropic-version": optional string`

- `"anthropic-beta": optional array of AnthropicBeta`

  Optional header to specify the beta version(s) you want to use. (전체 enum 목록 생략 — Managed Agents는 `managed-agents-2026-04-01`, Dreams는 `dreaming-2026-04-21`, Tunnels는 `mcp-tunnels-2026-06-22`)

- `"anthropic-workspace-id": optional string`

  Optional header to select the Workspace for this request. The value is a Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).

  Only needed for credentials that can act on more than one Workspace. A credential that belongs to a specific Workspace may omit it; if sent, it must match that Workspace.

## Returns

- `BetaManagedAgentsCredentialValidation object`

  Result of live-probing a credential against its configured MCP server.

  - `type: "vault_credential_validation"`

  - `credential_id: string`

    Unique identifier of the credential that was validated.

  - `has_refresh_token: boolean`

    Whether the credential has a refresh token configured.

  - `mcp_probe: BetaManagedAgentsMCPProbe or null`

    Details of the failing MCP probe step. Null when the probe succeeded.

    - `http_response: BetaManagedAgentsRefreshHTTPResponse or null`

      The captured HTTP error response. Null when no HTTP response was received (timeout, DNS, TLS).

      - `body: string`

        Response body. May be truncated and has sensitive values scrubbed.

      - `body_truncated: boolean`

        Whether `body` was truncated.

      - `content_type: string`

        Value of the `Content-Type` response header.

      - `status_code: number`

        HTTP status code.

        format: int32

    - `method: string`

      The MCP method that failed (for example `initialize` or `tools/list`).

  - `refresh: BetaManagedAgentsRefreshObject or null`

    Details of the refresh-token exchange attempted on a 401. Null when no refresh was attempted.

    - `http_response: BetaManagedAgentsRefreshHTTPResponse or null`

      The captured HTTP error response from the token endpoint. Populated only when `status` is `failed`.

    - `status: "succeeded" or "failed" or "connect_error" or "no_refresh_token"`

      Outcome of the refresh attempt.

      - `"succeeded"`

        The token endpoint returned a new access token.

      - `"failed"`

        The token endpoint returned an error response. See `http_response` for detail.

      - `"connect_error"`

        The token endpoint could not be reached (DNS, TLS, or connection error).

      - `"no_refresh_token"`

        No refresh token is stored for the credential, so no exchange was attempted.

  - `status: BetaManagedAgentsCredentialValidationStatus`

    Overall verdict of the validation probe.

    - `"valid"`

      The credential successfully authenticated against its MCP server.

    - `"invalid"`

      The probe reached the MCP server and was rejected, and a refresh (if attempted) did not recover it.

    - `"unknown"`

      The probe could not determine validity — for example, a transport error or a successful refresh that was not re-probed.

  - `validated_at: string`

    When the validation probe was performed.

    format: date-time

  - `vault_id: string`

    Identifier of the vault containing the credential.

## Example

```bash
curl https://api.anthropic.com/v1/vaults/$VAULT_ID/credentials/$CREDENTIAL_ID/mcp_oauth_validate \
    -X POST \
    -H 'anthropic-version: 2023-06-01' \
    -H 'anthropic-beta: managed-agents-2026-04-01' \
    -H "X-Api-Key: $ANTHROPIC_API_KEY"
```

### Response (200)

```json
{
  "credential_id": "vcrd_011CZkZEMt8gZan2iYPQfSkw",
  "has_refresh_token": true,
  "mcp_probe": {
    "http_response": {
      "body": "body",
      "body_truncated": true,
      "content_type": "content_type",
      "status_code": 0
    },
    "method": "method"
  },
  "refresh": {
    "http_response": {
      "body": "body",
      "body_truncated": true,
      "content_type": "content_type",
      "status_code": 0
    },
    "status": "succeeded"
  },
  "status": "valid",
  "type": "vault_credential_validation",
  "validated_at": "2026-03-15T10:00:00Z",
  "vault_id": "vlt_011CZkZDLs7fYzm1hXNPeRjv"
}
```
