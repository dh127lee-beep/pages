---
title: Update Credential
url: https://platform.claude.com/docs/en/api/beta/vaults/credentials/update
---

# Update Credential

**POST** `/v1/vaults/{vault_id}/credentials/{credential_id}`

Update Credential

## Path parameters

- `vault_id: string`

  Identifier of the vault containing the credential.

- `credential_id: string`

  Unique identifier of the credential to update.

## Headers

- `"anthropic-version": optional string`

- `"anthropic-beta": optional array of AnthropicBeta`

  Optional header to specify the beta version(s) you want to use. (전체 enum 목록 생략 — Managed Agents는 `managed-agents-2026-04-01`, Dreams는 `dreaming-2026-04-21`, Tunnels는 `mcp-tunnels-2026-06-22`)

- `"anthropic-workspace-id": optional string`

  Optional header to select the Workspace for this request. The value is a Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).

  Only needed for credentials that can act on more than one Workspace. A credential that belongs to a specific Workspace may omit it; if sent, it must match that Workspace.

## Body parameters

- `auth: optional BetaManagedAgentsMCPOAuthUpdateParams or BetaManagedAgentsStaticBearerUpdateParams or BetaManagedAgentsEnvironmentVariableUpdateParams`

  Updated authentication configuration. The `type` is immutable; the variant sent must match the stored credential's type.

  - `BetaManagedAgentsMCPOAuthUpdateParams object`

    Parameters for updating an MCP OAuth credential. The `mcp_server_url` is immutable.

    - `type: "mcp_oauth"`

    - `access_token: optional string or null`

      Updated OAuth access token.

      minLength: 1, maxLength: 8192

    - `expires_at: optional string or null`

      A timestamp in RFC 3339 format

      format: date-time

    - `refresh: optional BetaManagedAgentsMCPOAuthRefreshUpdateParams or null`

      Updated refresh token configuration.

      - `refresh_token: optional string or null`

        Updated OAuth refresh token.

        minLength: 1, maxLength: 8192

      - `scope: optional string or null`

        Updated OAuth scope for the refresh request.

        maxLength: 8192

      - `token_endpoint_auth: optional BetaManagedAgentsTokenEndpointAuthBasicUpdateParam or BetaManagedAgentsTokenEndpointAuthPostUpdateParam`

        - `BetaManagedAgentsTokenEndpointAuthBasicUpdateParam object`

          Updated HTTP Basic authentication parameters for the token endpoint.

          - `type: "client_secret_basic"`

          - `client_secret: optional string or null`

            Updated OAuth client secret.

            minLength: 1, maxLength: 512

        - `BetaManagedAgentsTokenEndpointAuthPostUpdateParam object`

          Updated POST body authentication parameters for the token endpoint.

          - `type: "client_secret_post"`

          - `client_secret: optional string or null`

            Updated OAuth client secret.

            minLength: 1, maxLength: 512

  - `BetaManagedAgentsStaticBearerUpdateParams object`

    Parameters for updating a static bearer token credential. The `mcp_server_url` is immutable.

    - `type: "static_bearer"`

    - `token: optional string or null`

      Updated static bearer token value.

      minLength: 1, maxLength: 8192

  - `BetaManagedAgentsEnvironmentVariableUpdateParams object`

    Parameters for updating an environment variable credential. `secret_name` is immutable.

    - `type: "environment_variable"`

    - `injection_location: optional BetaManagedAgentsInjectionLocationUpdateParams`

      Updated injection location.

      - `body: optional boolean`

        Substitute when the placeholder appears in the request body.

      - `header: optional boolean`

        Substitute when the placeholder appears in a request header value.

    - `networking: optional BetaManagedAgentsCredentialNetworkingParams or null`

      Updated networking scope. Full replacement.

      - `BetaManagedAgentsUnrestrictedCredentialNetworkingParams object`

        Substitute the secret on any host the session's Environment network policy permits egress to. The Environment's network policy is the only boundary on where the secret can reach.

        - `type: "unrestricted"`

      - `BetaManagedAgentsLimitedCredentialNetworkingParams object`

        Substitute the secret only on requests to the listed hosts.

        - `type: "limited"`

        - `allowed_hosts: array of string`

          Hostnames on which the secret will be substituted. Each entry is a bare hostname (`api.example.com`), an IPv4 address (`192.0.2.1`), or a `*.`-prefixed wildcard (`*.example.com`). URLs, ports, paths, and IPv6 addresses are not accepted. At most 16 entries.

    - `secret_value: optional string or null`

      Updated secret value.

      minLength: 1, maxLength: 4096

- `display_name: optional string or null`

  Updated human-readable name for the credential. 1-255 characters.

  minLength: 1, maxLength: 255

- `metadata: optional map[string] or null`

  Metadata patch. Set a key to a string to upsert it, or to null to delete it. Omitted keys are preserved.

## Returns

- `BetaManagedAgentsCredential object`

  A credential stored in a vault. Sensitive fields are never returned in responses.

  - `type: "vault_credential"`

  - `id: string`

    Unique identifier for the credential.

  - `archived_at: string or null`

    When the credential was archived. Null if not archived.

    format: date-time

  - `auth: BetaManagedAgentsMCPOAuthAuthResponse or BetaManagedAgentsStaticBearerAuthResponse or BetaManagedAgentsEnvironmentVariableAuthResponse`

    Authentication configuration for this credential.

    - `BetaManagedAgentsMCPOAuthAuthResponse object`

      OAuth credential details for an MCP server.

      - `type: "mcp_oauth"`

      - `mcp_server_url: string`

        URL of the MCP server this credential authenticates against.

      - `expires_at: optional string or null`

        A timestamp in RFC 3339 format

        format: date-time

      - `refresh: optional BetaManagedAgentsMCPOAuthRefreshResponse or null`

        Refresh token configuration, if the credential supports token refresh.

        - `client_id: string`

          OAuth client ID.

        - `token_endpoint: string`

          Token endpoint URL used to refresh the access token.

        - `token_endpoint_auth: BetaManagedAgentsTokenEndpointAuthNoneResponse or BetaManagedAgentsTokenEndpointAuthBasicResponse or BetaManagedAgentsTokenEndpointAuthPostResponse`

          - `BetaManagedAgentsTokenEndpointAuthNoneResponse object`

            Token endpoint requires no client authentication.

            - `type: "none"`

          - `BetaManagedAgentsTokenEndpointAuthBasicResponse object`

            Token endpoint uses HTTP Basic authentication with client credentials.

            - `type: "client_secret_basic"`

          - `BetaManagedAgentsTokenEndpointAuthPostResponse object`

            Token endpoint uses POST body authentication with client credentials.

            - `type: "client_secret_post"`

        - `resource: optional string or null`

          OAuth resource indicator.

        - `scope: optional string or null`

          OAuth scope for the refresh request.

    - `BetaManagedAgentsStaticBearerAuthResponse object`

      Static bearer token credential details for an MCP server.

      - `type: "static_bearer"`

      - `mcp_server_url: string`

        URL of the MCP server this credential authenticates against.

    - `BetaManagedAgentsEnvironmentVariableAuthResponse object`

      Environment variable credential details. The secret value is never returned.

      - `type: "environment_variable"`

      - `injection_location: BetaManagedAgentsInjectionLocationResponse`

        Where in the outbound request the secret value is substituted.

        - `body: boolean`

          Whether the placeholder is substituted in the request body.

        - `header: boolean`

          Whether the placeholder is substituted in request header values.

      - `networking: BetaManagedAgentsUnrestrictedCredentialNetworkingResponse or BetaManagedAgentsLimitedCredentialNetworkingResponse`

        Outbound hosts the secret value is substituted on.

        - `BetaManagedAgentsUnrestrictedCredentialNetworkingResponse object`

          The secret is substituted on any host the session's Environment network policy permits egress to.

          - `type: "unrestricted"`

        - `BetaManagedAgentsLimitedCredentialNetworkingResponse object`

          The secret is substituted only on requests to the listed hosts.

          - `type: "limited"`

          - `allowed_hosts: array of string`

            Hostnames on which the secret will be substituted. An entry matches the request host exactly; a `*.`-prefixed entry matches any subdomain of the named domain but not the domain itself.

      - `secret_name: string`

        Name of the environment variable.

  - `created_at: string`

    A timestamp in RFC 3339 format

    format: date-time

  - `metadata: map[string]`

    Arbitrary key-value metadata attached to the credential.

  - `updated_at: string`

    A timestamp in RFC 3339 format

    format: date-time

  - `vault_id: string`

    Identifier of the vault this credential belongs to.

  - `display_name: optional string or null`

    Human-readable name for the credential.

## Example

```bash
curl https://api.anthropic.com/v1/vaults/$VAULT_ID/credentials/$CREDENTIAL_ID \
    -H 'Content-Type: application/json' \
    -H 'anthropic-version: 2023-06-01' \
    -H 'anthropic-beta: managed-agents-2026-04-01' \
    -H "X-Api-Key: $ANTHROPIC_API_KEY" \
    -d '{
          "display_name": "Example credential",
          "metadata": {
            "environment": "production"
          }
        }'
```

### Response (200)

```json
{
  "id": "vcrd_011CZkZEMt8gZan2iYPQfSkw",
  "archived_at": null,
  "auth": {
    "mcp_server_url": "https://example-server.modelcontextprotocol.io/sse",
    "type": "static_bearer"
  },
  "created_at": "2026-03-15T10:00:00Z",
  "metadata": {
    "environment": "production"
  },
  "type": "vault_credential",
  "updated_at": "2026-03-15T10:00:00Z",
  "vault_id": "vlt_011CZkZDLs7fYzm1hXNPeRjv",
  "display_name": "Example credential"
}
```
