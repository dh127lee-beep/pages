---
title: List Vaults
url: https://platform.claude.com/docs/en/api/beta/vaults/list
---

# List Vaults

**GET** `/v1/vaults`

List Vaults

## Query parameters

- `include_archived: optional boolean`

  Whether to include archived vaults in the results.

- `limit: optional number`

  Maximum number of vaults to return per page. Defaults to 20, maximum 100.

  format: int32

- `page: optional string`

  Opaque pagination token from a previous `list_vaults` response.

## Headers

- `"anthropic-version": optional string`

- `"anthropic-beta": optional array of AnthropicBeta`

  Optional header to specify the beta version(s) you want to use. (전체 enum 목록 생략 — Managed Agents는 `managed-agents-2026-04-01`, Dreams는 `dreaming-2026-04-21`, Tunnels는 `mcp-tunnels-2026-06-22`)

- `"anthropic-workspace-id": optional string`

  Optional header to select the Workspace for this request. The value is a Workspace ID (for example, `wrkspc_011CZkZaBF1tNoB5wlCeusgy`).

  Only needed for credentials that can act on more than one Workspace. A credential that belongs to a specific Workspace may omit it; if sent, it must match that Workspace.

## Returns

- `data: optional array of BetaManagedAgentsVault`

  List of vaults.

  - `type: "vault"`

  - `id: string`

    Unique identifier for the vault.

  - `archived_at: string or null`

    When the vault was archived. Null if not archived.

    format: date-time

  - `created_at: string`

    A timestamp in RFC 3339 format

    format: date-time

  - `display_name: string`

    Human-readable name for the vault.

  - `metadata: map[string]`

    Arbitrary key-value metadata attached to the vault.

  - `updated_at: string`

    A timestamp in RFC 3339 format

    format: date-time

- `next_page: optional string or null`

  Pagination token for the next page, or null if no more results.

## Example

```bash
curl https://api.anthropic.com/v1/vaults \
    -H 'anthropic-version: 2023-06-01' \
    -H 'anthropic-beta: managed-agents-2026-04-01' \
    -H "X-Api-Key: $ANTHROPIC_API_KEY"
```

### Response (200)

```json
{
  "data": [
    {
      "id": "vlt_011CZkZDLs7fYzm1hXNPeRjv",
      "archived_at": null,
      "created_at": "2026-03-15T10:00:00Z",
      "display_name": "Example vault",
      "metadata": {
        "environment": "production"
      },
      "type": "vault",
      "updated_at": "2026-03-15T10:00:00Z"
    }
  ],
  "next_page": "page_MjAyNS0wNS0xNFQwMDowMDowMFo="
}
```
