# Vaults — Domain types

원문: https://platform.claude.com/docs/en/api/beta/vaults



### Beta Managed Agents Deleted Vault

- `BetaManagedAgentsDeletedVault object`

  Confirmation of a deleted vault.

  - `type: "vault_deleted"`

  - `id: string`

    Unique identifier of the deleted vault.

### Beta Managed Agents Vault

- `BetaManagedAgentsVault object`

  A vault that stores credentials for use by agents during sessions.

  - `type: "vault"`

  - `id: string`

    Unique identifier for the vault.

  - `archived_at: string or null`

    When the vault was archived. Null if not archived.

    format: date-time

  - `created_at: string`

    A timestamp in RFC 3339 format

    format: date-time

  - `display_name: string`

    Human-readable name for the vault.

  - `metadata: map[string]`

    Arbitrary key-value metadata attached to the vault.

  - `updated_at: string`

    A timestamp in RFC 3339 format

    format: date-time

