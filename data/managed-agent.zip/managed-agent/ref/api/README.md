# Claude Managed Agents — API Reference

출처: https://platform.claude.com/docs/en/api/overview 및 `https://platform.claude.com/docs/en/api/beta/*` (2026-10-14 수집)

Base URL: `https://api.anthropic.com`

## 공통 헤더

| 헤더 | 값 | 비고 |
|---|---|---|
| `x-api-key` 또는 `Authorization: Bearer <token>` | API 키 / WIF 토큰 | 둘 중 하나 필수 |
| `anthropic-version` | `2023-06-01` | 필수 |
| `anthropic-beta` | `managed-agents-2026-04-01` | Managed Agents 리소스 공통. Dreams는 `dreaming-2026-04-21`, Tunnels는 `mcp-tunnels-2026-06-22` |
| `anthropic-workspace-id` | `wrkspc_...` | 여러 워크스페이스에 접근 가능한 키일 때만 필요 |
| `content-type` | `application/json` | body가 있는 요청 |

- 수정(update)은 `PATCH`가 아니라 `POST /v1/<resource>/{id}` 입니다.
- 목록 API는 커서 기반 페이지네이션(`limit`, `page` → 응답의 `next_page`)을 사용합니다. 세부 파라미터는 각 `list.md` 참고.
- 삭제 외에 `archive`(소프트 삭제, 새 사용 불가) 엔드포인트가 대부분 리소스에 있습니다.

## 디렉터리 구조

- `<resource>/<operation>.md` — 엔드포인트별 원문 레퍼런스 (헤더·경로/쿼리/바디 파라미터·응답 스키마·예제)
- `<resource>/_types.md` — 해당 리소스의 Domain types (공용 스키마 정의)
- `webhooks/_types.md` — 웹훅 이벤트 페이로드 타입
- 원문의 `anthropic-beta` enum 전체 목록(수십 개)은 반복이 심해 한 줄 요약으로 대체했습니다. 그 외 내용은 원문 그대로입니다.

## 리소스 개요

| 리소스 | 설명 | beta 헤더 |
|---|---|---|
| [Agents](#agents) | 에이전트 정의(모델·시스템 프롬프트·툴·MCP·스킬)를 버전 관리되는 재사용 설정으로 저장 | `managed-agents-2026-04-01` |
| [Sessions](#sessions) | 에이전트 + 환경으로 실행되는 상태 유지 세션. 이벤트 송수신/스트리밍, 리소스, 멀티에이전트 스레드 | `managed-agents-2026-04-01` |
| [Environments](#environments) | 세션이 실행될 샌드박스(클라우드/self-hosted) 템플릿. work/* 는 self-hosted 워커 오케스트레이션용 | `managed-agents-2026-04-01` |
| [Vaults](#vaults) | MCP 서버 등에 쓰는 자격증명(OAuth·토큰) 보관소 | `managed-agents-2026-04-01` |
| [Memory Stores](#memory-stores) | 세션 간 지속되는 메모리 저장소와 메모리·버전 관리 | `managed-agents-2026-04-01` |
| [Deployments](#deployments) | 에이전트를 cron 스케줄/수동 트리거로 실행하는 배포 | `managed-agents-2026-04-01` |
| [Deployment Runs](#deployment-runs) | 배포의 개별 실행 기록 | `managed-agents-2026-04-01` |
| [Dreams](#dreams) | 과거 세션을 바탕으로 메모리 스토어를 재정리하는 비동기 작업 | `dreaming-2026-04-21` |
| [Tunnels (research preview)](#tunnels) | 사설망 MCP 서버를 에이전트에 노출하는 터널 및 CA 인증서 | `mcp-tunnels-2026-06-22` |
| [Webhooks](webhooks/_types.md) | 리소스 상태 변화 웹훅 이벤트 타입 | — |

## 엔드포인트 전체 목록

### Agents
<a id="agents"></a>

에이전트 정의(모델·시스템 프롬프트·툴·MCP·스킬)를 버전 관리되는 재사용 설정으로 저장. 스키마: [`agents/_types.md`](agents/_types.md)

| Method | Path | 설명 | 문서 |
|---|---|---|---|
| `POST` | `/v1/agents` | 에이전트 생성 | [agents/create.md](agents/create.md) |
| `GET` | `/v1/agents` | 에이전트 목록 조회 | [agents/list.md](agents/list.md) |
| `GET` | `/v1/agents/{agent_id}` | 에이전트 단건 조회 | [agents/retrieve.md](agents/retrieve.md) |
| `POST` | `/v1/agents/{agent_id}` | 에이전트 수정 (새 버전 생성) | [agents/update.md](agents/update.md) |
| `POST` | `/v1/agents/{agent_id}/archive` | 에이전트 보관(archive) | [agents/archive.md](agents/archive.md) |
| `GET` | `/v1/agents/{agent_id}/versions` | 에이전트 버전 목록 조회 | [agents/versions/list.md](agents/versions/list.md) |

### Sessions
<a id="sessions"></a>

에이전트 + 환경으로 실행되는 상태 유지 세션. 이벤트 송수신/스트리밍, 리소스, 멀티에이전트 스레드. 스키마: [`sessions/_types.md`](sessions/_types.md)

| Method | Path | 설명 | 문서 |
|---|---|---|---|
| `POST` | `/v1/sessions` | 세션 생성 (agent + environment 지정, 리소스/볼트 연결) | [sessions/create.md](sessions/create.md) |
| `GET` | `/v1/sessions` | 세션 목록 조회 | [sessions/list.md](sessions/list.md) |
| `GET` | `/v1/sessions/{session_id}` | 세션 단건 조회 | [sessions/retrieve.md](sessions/retrieve.md) |
| `POST` | `/v1/sessions/{session_id}` | 세션 수정 | [sessions/update.md](sessions/update.md) |
| `POST` | `/v1/sessions/{session_id}/archive` | 세션 보관(archive) | [sessions/archive.md](sessions/archive.md) |
| `DELETE` | `/v1/sessions/{session_id}` | 세션 삭제 | [sessions/delete.md](sessions/delete.md) |
| `GET` | `/v1/sessions/{session_id}/resources` | 세션 리소스 목록 조회 | [sessions/resources/list.md](sessions/resources/list.md) |
| `GET` | `/v1/sessions/{session_id}/threads` | 세션 스레드 목록 조회 | [sessions/threads/list.md](sessions/threads/list.md) |
| `GET` | `/v1/sessions/{session_id}/events` | 세션 이벤트 기록 조회 (페이지네이션) | [sessions/events/list.md](sessions/events/list.md) |
| `GET` | `/v1/sessions/{session_id}/resources/{resource_id}` | 세션 리소스 단건 조회 | [sessions/resources/retrieve.md](sessions/resources/retrieve.md) |
| `GET` | `/v1/sessions/{session_id}/threads/{thread_id}` | 세션 스레드 단건 조회 | [sessions/threads/retrieve.md](sessions/threads/retrieve.md) |
| `POST` | `/v1/sessions/{session_id}/resources/{resource_id}` | 세션 리소스 수정 | [sessions/resources/update.md](sessions/resources/update.md) |
| `POST` | `/v1/sessions/{session_id}/threads/{thread_id}/archive` | 세션 스레드 보관(archive) | [sessions/threads/archive.md](sessions/threads/archive.md) |
| `DELETE` | `/v1/sessions/{session_id}/resources/{resource_id}` | 세션 리소스 삭제 | [sessions/resources/delete.md](sessions/resources/delete.md) |
| `POST` | `/v1/sessions/{session_id}/resources` | 세션에 리소스(파일·레포 등) 추가 | [sessions/resources/add.md](sessions/resources/add.md) |
| `POST` | `/v1/sessions/{session_id}/events` | 세션에 이벤트 전송 (user.message, user.interrupt, user.tool_confirmation, user.custom_tool_result 등) | [sessions/events/send.md](sessions/events/send.md) |
| `GET` | `/v1/sessions/{session_id}/events/stream` | 세션 이벤트 SSE 스트림 | [sessions/events/stream.md](sessions/events/stream.md) |
| `GET` | `/v1/sessions/{session_id}/threads/{thread_id}/events` | 스레드 이벤트 목록 조회 | [sessions/threads/events/list.md](sessions/threads/events/list.md) |
| `GET` | `/v1/sessions/{session_id}/threads/{thread_id}/stream` | 스레드 이벤트 SSE 스트림 | [sessions/threads/events/stream.md](sessions/threads/events/stream.md) |

### Environments
<a id="environments"></a>

세션이 실행될 샌드박스(클라우드/self-hosted) 템플릿. work/* 는 self-hosted 워커 오케스트레이션용. 스키마: [`environments/_types.md`](environments/_types.md)

| Method | Path | 설명 | 문서 |
|---|---|---|---|
| `POST` | `/v1/environments` | 환경 생성 | [environments/create.md](environments/create.md) |
| `GET` | `/v1/environments` | 환경 목록 조회 | [environments/list.md](environments/list.md) |
| `GET` | `/v1/environments/{environment_id}` | 환경 단건 조회 | [environments/retrieve.md](environments/retrieve.md) |
| `POST` | `/v1/environments/{environment_id}` | 환경 수정 | [environments/update.md](environments/update.md) |
| `POST` | `/v1/environments/{environment_id}/archive` | 환경 보관(archive) | [environments/archive.md](environments/archive.md) |
| `DELETE` | `/v1/environments/{environment_id}` | 환경 삭제 | [environments/delete.md](environments/delete.md) |
| `GET` | `/v1/environments/{environment_id}/work` | 작업(work) 항목 목록 조회 | [environments/work/list.md](environments/work/list.md) |
| `GET` | `/v1/environments/{environment_id}/work/{work_id}` | 작업(work) 항목 단건 조회 | [environments/work/retrieve.md](environments/work/retrieve.md) |
| `POST` | `/v1/environments/{environment_id}/work/{work_id}` | 작업(work) 항목 수정 | [environments/work/update.md](environments/work/update.md) |
| `POST` | `/v1/environments/{environment_id}/work/{work_id}/ack` | 작업 항목 수신 확인 (self-hosted 워커용) | [environments/work/ack.md](environments/work/ack.md) |
| `POST` | `/v1/environments/{environment_id}/work/{work_id}/heartbeat` | 작업 항목 heartbeat (self-hosted 워커용) | [environments/work/heartbeat.md](environments/work/heartbeat.md) |
| `GET` | `/v1/environments/{environment_id}/work/poll` | 작업 큐 long-poll (self-hosted 워커용) | [environments/work/poll.md](environments/work/poll.md) |
| `GET` | `/v1/environments/{environment_id}/work/stats` | 작업 큐 통계 | [environments/work/stats.md](environments/work/stats.md) |
| `POST` | `/v1/environments/{environment_id}/work/{work_id}/stop` | 작업 항목 중지 (self-hosted 워커용) | [environments/work/stop.md](environments/work/stop.md) |

### Vaults
<a id="vaults"></a>

MCP 서버 등에 쓰는 자격증명(OAuth·토큰) 보관소. 스키마: [`vaults/_types.md`](vaults/_types.md)

| Method | Path | 설명 | 문서 |
|---|---|---|---|
| `POST` | `/v1/vaults` | 볼트 생성 | [vaults/create.md](vaults/create.md) |
| `GET` | `/v1/vaults` | 볼트 목록 조회 | [vaults/list.md](vaults/list.md) |
| `GET` | `/v1/vaults/{vault_id}` | 볼트 단건 조회 | [vaults/retrieve.md](vaults/retrieve.md) |
| `POST` | `/v1/vaults/{vault_id}` | 볼트 수정 | [vaults/update.md](vaults/update.md) |
| `POST` | `/v1/vaults/{vault_id}/archive` | 볼트 보관(archive) | [vaults/archive.md](vaults/archive.md) |
| `DELETE` | `/v1/vaults/{vault_id}` | 볼트 삭제 | [vaults/delete.md](vaults/delete.md) |
| `POST` | `/v1/vaults/{vault_id}/credentials` | 자격증명 생성 | [vaults/credentials/create.md](vaults/credentials/create.md) |
| `GET` | `/v1/vaults/{vault_id}/credentials` | 자격증명 목록 조회 | [vaults/credentials/list.md](vaults/credentials/list.md) |
| `GET` | `/v1/vaults/{vault_id}/credentials/{credential_id}` | 자격증명 단건 조회 | [vaults/credentials/retrieve.md](vaults/credentials/retrieve.md) |
| `POST` | `/v1/vaults/{vault_id}/credentials/{credential_id}` | 자격증명 수정 | [vaults/credentials/update.md](vaults/credentials/update.md) |
| `POST` | `/v1/vaults/{vault_id}/credentials/{credential_id}/archive` | 자격증명 보관(archive) | [vaults/credentials/archive.md](vaults/credentials/archive.md) |
| `DELETE` | `/v1/vaults/{vault_id}/credentials/{credential_id}` | 자격증명 삭제 | [vaults/credentials/delete.md](vaults/credentials/delete.md) |
| `POST` | `/v1/vaults/{vault_id}/credentials/{credential_id}/mcp_oauth_validate` | MCP OAuth 자격증명 유효성 검증 | [vaults/credentials/mcp_oauth_validate.md](vaults/credentials/mcp_oauth_validate.md) |

### Memory Stores
<a id="memory-stores"></a>

세션 간 지속되는 메모리 저장소와 메모리·버전 관리. 스키마: [`memory_stores/_types.md`](memory_stores/_types.md)

| Method | Path | 설명 | 문서 |
|---|---|---|---|
| `POST` | `/v1/memory_stores` | 메모리 스토어 생성 | [memory_stores/create.md](memory_stores/create.md) |
| `GET` | `/v1/memory_stores` | 메모리 스토어 목록 조회 | [memory_stores/list.md](memory_stores/list.md) |
| `GET` | `/v1/memory_stores/{memory_store_id}` | 메모리 스토어 단건 조회 | [memory_stores/retrieve.md](memory_stores/retrieve.md) |
| `POST` | `/v1/memory_stores/{memory_store_id}` | 메모리 스토어 수정 | [memory_stores/update.md](memory_stores/update.md) |
| `POST` | `/v1/memory_stores/{memory_store_id}/archive` | 메모리 스토어 보관(archive) | [memory_stores/archive.md](memory_stores/archive.md) |
| `DELETE` | `/v1/memory_stores/{memory_store_id}` | 메모리 스토어 삭제 | [memory_stores/delete.md](memory_stores/delete.md) |
| `POST` | `/v1/memory_stores/{memory_store_id}/memories` | 메모리 생성 | [memory_stores/memories/create.md](memory_stores/memories/create.md) |
| `GET` | `/v1/memory_stores/{memory_store_id}/memory_versions` | 메모리 버전 목록 조회 | [memory_stores/memory_versions/list.md](memory_stores/memory_versions/list.md) |
| `GET` | `/v1/memory_stores/{memory_store_id}/memories` | 메모리 목록 조회 | [memory_stores/memories/list.md](memory_stores/memories/list.md) |
| `GET` | `/v1/memory_stores/{memory_store_id}/memory_versions/{memory_version_id}` | 메모리 버전 단건 조회 | [memory_stores/memory_versions/retrieve.md](memory_stores/memory_versions/retrieve.md) |
| `GET` | `/v1/memory_stores/{memory_store_id}/memories/{memory_id}` | 메모리 단건 조회 | [memory_stores/memories/retrieve.md](memory_stores/memories/retrieve.md) |
| `POST` | `/v1/memory_stores/{memory_store_id}/memories/{memory_id}` | 메모리 수정 | [memory_stores/memories/update.md](memory_stores/memories/update.md) |
| `DELETE` | `/v1/memory_stores/{memory_store_id}/memories/{memory_id}` | 메모리 삭제 | [memory_stores/memories/delete.md](memory_stores/memories/delete.md) |
| `POST` | `/v1/memory_stores/{memory_store_id}/memory_versions/{memory_version_id}/redact` | 메모리 버전 내용 redact(삭제 처리) | [memory_stores/memory_versions/redact.md](memory_stores/memory_versions/redact.md) |

### Deployments
<a id="deployments"></a>

에이전트를 cron 스케줄/수동 트리거로 실행하는 배포. 스키마: [`deployments/_types.md`](deployments/_types.md)

| Method | Path | 설명 | 문서 |
|---|---|---|---|
| `POST` | `/v1/deployments` | 배포 생성 | [deployments/create.md](deployments/create.md) |
| `GET` | `/v1/deployments` | 배포 목록 조회 | [deployments/list.md](deployments/list.md) |
| `GET` | `/v1/deployments/{deployment_id}` | 배포 단건 조회 | [deployments/retrieve.md](deployments/retrieve.md) |
| `POST` | `/v1/deployments/{deployment_id}` | 배포 수정 | [deployments/update.md](deployments/update.md) |
| `POST` | `/v1/deployments/{deployment_id}/archive` | 배포 보관(archive) | [deployments/archive.md](deployments/archive.md) |
| `POST` | `/v1/deployments/{deployment_id}/pause` | 배포 일시정지 (스케줄 실행 중단) | [deployments/pause.md](deployments/pause.md) |
| `POST` | `/v1/deployments/{deployment_id}/run` | 배포 즉시 수동 실행 | [deployments/run.md](deployments/run.md) |
| `POST` | `/v1/deployments/{deployment_id}/unpause` | 배포 재개 | [deployments/unpause.md](deployments/unpause.md) |

### Deployment Runs
<a id="deployment-runs"></a>

배포의 개별 실행 기록. 스키마: [`deployment_runs/_types.md`](deployment_runs/_types.md)

| Method | Path | 설명 | 문서 |
|---|---|---|---|
| `GET` | `/v1/deployment_runs` | 배포 실행(run) 목록 조회 | [deployment_runs/list.md](deployment_runs/list.md) |
| `GET` | `/v1/deployment_runs/{deployment_run_id}` | 배포 실행(run) 단건 조회 | [deployment_runs/retrieve.md](deployment_runs/retrieve.md) |

### Dreams
<a id="dreams"></a>

과거 세션을 바탕으로 메모리 스토어를 재정리하는 비동기 작업. 스키마: [`dreams/_types.md`](dreams/_types.md)

| Method | Path | 설명 | 문서 |
|---|---|---|---|
| `POST` | `/v1/dreams` | Dream 생성 — 과거 세션으로 메모리 스토어를 재구성하는 비동기 작업 | [dreams/create.md](dreams/create.md) |
| `GET` | `/v1/dreams` | Dream 목록 조회 | [dreams/list.md](dreams/list.md) |
| `GET` | `/v1/dreams/{dream_id}` | Dream 단건 조회 | [dreams/retrieve.md](dreams/retrieve.md) |
| `POST` | `/v1/dreams/{dream_id}/archive` | Dream 보관(archive) | [dreams/archive.md](dreams/archive.md) |
| `POST` | `/v1/dreams/{dream_id}/cancel` | pending/running Dream 취소 | [dreams/cancel.md](dreams/cancel.md) |

### Tunnels (research preview)
<a id="tunnels"></a>

사설망 MCP 서버를 에이전트에 노출하는 터널 및 CA 인증서. 스키마: [`tunnels/_types.md`](tunnels/_types.md)

| Method | Path | 설명 | 문서 |
|---|---|---|---|
| `POST` | `/v1/tunnels` | 터널 생성 (새 hostname 할당, 비멱등) | [tunnels/create.md](tunnels/create.md) |
| `GET` | `/v1/tunnels` | 터널 목록 조회 | [tunnels/list.md](tunnels/list.md) |
| `GET` | `/v1/tunnels/{tunnel_id}` | 터널 단건 조회 | [tunnels/retrieve.md](tunnels/retrieve.md) |
| `POST` | `/v1/tunnels/{tunnel_id}/archive` | 터널 보관(archive) | [tunnels/archive.md](tunnels/archive.md) |
| `POST` | `/v1/tunnels/{tunnel_id}/reveal_token` | 커넥터 토큰 조회 | [tunnels/reveal_token.md](tunnels/reveal_token.md) |
| `POST` | `/v1/tunnels/{tunnel_id}/rotate_token` | 커넥터 토큰 교체 | [tunnels/rotate_token.md](tunnels/rotate_token.md) |
| `POST` | `/v1/tunnels/{tunnel_id}/certificates` | CA 인증서 등록 (터널당 최대 2개) | [tunnels/certificates/create.md](tunnels/certificates/create.md) |
| `GET` | `/v1/tunnels/{tunnel_id}/certificates` | 터널 CA 인증서 목록 조회 | [tunnels/certificates/list.md](tunnels/certificates/list.md) |
| `GET` | `/v1/tunnels/{tunnel_id}/certificates/{certificate_id}` | 터널 CA 인증서 단건 조회 | [tunnels/certificates/retrieve.md](tunnels/certificates/retrieve.md) |
| `POST` | `/v1/tunnels/{tunnel_id}/certificates/{certificate_id}/archive` | 터널 CA 인증서 보관(archive) | [tunnels/certificates/archive.md](tunnels/certificates/archive.md) |

## 세션 이벤트 타입 (`sessions/events/_types.md`)

- **사용자 → 에이전트 (send)**: `user.message`, `user.interrupt`, `user.tool_confirmation`, `user.custom_tool_result`, `user.tool_result`, `user.define_outcome`
- **에이전트**: `agent.message`, `agent.thinking`, `agent.tool_use`, `agent.tool_result`, `agent.mcp_tool_use`, `agent.mcp_tool_result`, `agent.custom_tool_use`, `agent.thread_message_sent`, `agent.thread_message_received`, `agent.thread_context_compacted`
- **세션 상태**: `session.status_running`, `session.status_idle`, `session.status_rescheduled`, `session.status_terminated`, `session.error`, `session.deleted`, `session.thread_created`, `session.thread_status_*`
- **스팬**: `span.model_request_start/end`, `span.outcome_evaluation_start/ongoing/end`
- **워크플로 런**: `workflow_run.created`, `workflow_run.status_running/idle/ended`, `workflow_run.phase_started/ended`, `workflow_run.error`
- **시스템**: `system.message`

## 웹훅 이벤트 타입 (`webhooks/_types.md`)

`agent.{created,updated,archived,deleted}` · `session.{created,updated,pending,running,idled,requires_action,budget_reached,archived,deleted,outcome_evaluation_ended,thread_created,thread_idled,thread_terminated,status_*}` · `environment.{created,updated,archived,deleted}` · `deployment.{created,updated,paused,unpaused,archived,deleted}` · `deployment_run.{started,succeeded,failed}` · `memory_store.{created,archived,deleted}` · `vault.{created,archived,deleted}` · `vault_credential.{created,archived,deleted,refresh_failed}`

## 관련 가이드 (API 레퍼런스 외)

- Quickstart: https://platform.claude.com/docs/en/managed-agents/quickstart
- Agent setup: https://platform.claude.com/docs/en/managed-agents/agent-setup
- Sessions: https://platform.claude.com/docs/en/managed-agents/sessions
- Environments: https://platform.claude.com/docs/en/managed-agents/environments
- Dreams: https://platform.claude.com/docs/en/managed-agents/dreams
- Beta headers: https://platform.claude.com/docs/en/api/beta-headers
