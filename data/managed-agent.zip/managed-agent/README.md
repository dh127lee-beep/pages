# AWP — 사내 에이전트 운영 플랫폼

> 코드명 **AWP** (Agent Workspace Platform). 아직 구현 코드는 없고 설계·계획·규약만 있습니다.
> 2026-10-15 기준.

사내 부서가 자기 업무용 에이전트를 **버전 관리되는 자산**으로 운영하고, 실행을
**감사 가능한 append-only 이벤트 로그**로 남기며, 자격증명이 에이전트 주소공간에
**아예 존재하지 않게** 만드는 플랫폼입니다.

스택: Python 3.13 / FastAPI / SQLAlchemy / PostgreSQL 17 / Kubernetes ·
모델 `deepseek-flash` (교체 가능) · 샌드박스 Wasm(WASI p2) + bubblewrap/Landlock

---

## 어디부터 읽는가

| 당신이 | 읽을 것 |
|---|---|
| 이 프로젝트가 처음이다 | [`plan/README.md`](plan/README.md) → 핵심 결정 13개 |
| 설계 전체를 보고 싶다 | [`plan/index.html`](plan/index.html) — 브라우저로 열면 다이어그램 21개 포함 |
| 지금 뭘 만들면 되는지 알고 싶다 | [`task/README.md`](task/README.md) → `T-0101` |
| 코드를 쓰려고 한다 | [`docs/conventions/`](docs/conventions/) |
| 왜 이렇게 정했는지 궁금하다 | [`docs/adr/`](docs/adr/) |

---

## 폴더 — 섞지 않는다

| 폴더 | 무엇 | 질문 | 바뀌는 때 |
|---|---|---|---|
| [`ref/`](ref/) | 외부 자료 원문과 분석 | — | 원본이 갱신될 때 다시 수집 |
| [`plan/`](plan/) | 합의된 설계 | **무엇을 · 왜** | 설계가 바뀔 때 (ADR 동반) |
| [`task/`](task/) | 실행 단위 38개 | **언제 · 무엇을 만든다** | 작업 진행 시 (상태만) |
| [`docs/`](docs/) | 규약과 결정 기록 | **어떻게 쓰는가 · 왜 그렇게 정했나** | 결정이 날 때 |

무언가를 적기 전에 [`docs/README.md`](docs/README.md) §1의 결정 트리를 보십시오.
**가장 흔한 실수는 전부 `plan/`에 밀어 넣는 것**입니다.

```
ref/   claude-managed-agents/  공식 문서 37편
       api/                    공식 API 레퍼런스 110 엔드포인트
       open-code/              Open Managed Agents 소스 (TS, 173패키지)
       open-code-analysis/     위 소스 분석 5부

plan/  README.md               핵심 결정 D1~D13
       01~10-*.md              컨셉 · 아키텍처 · 레이어 · API · DB ·
                               하네스/모델 · 샌드박스 · 인프라 · 코드베이스 · 관계
       svg/                    다이어그램 21
       index.html              위 전부를 합친 읽기용 (MD에서 생성)

task/  README.md               마일스톤 지도 + goal 모드 실행 규칙
       M0~M6/                  작업 38개 + 마일스톤별 종료 조건

docs/  README.md               ★ 무엇을 어디에 쓰는가 (결정 트리)
       conventions/            python · naming · api · sql · testing · git
       adr/                    결정 기록
       impl/                   측정 · 함정 · 수용 보고
       survey/                 공식 문서 서베이 7부
```

---

## 지금 상태

- 설계 — **완료**. `plan/` 10편 + 다이어그램 21
- 계획 — **완료**. `task/` 작업 38개, 6 마일스톤
- 규약 — **초안**. 코드가 생기면 구체화
- 구현 — **시작 전**

### 다음 할 일

```
task/M0-foundation/T-0101-monorepo-ci.md     모노레포 뼈대와 CI 게이트
task/M0-foundation/T-0106-deepseek-spike.md  DeepSeek 실측 (병렬, 외부 비용 발생)
```

---

## 두 개의 관문

**M1 종료 = Phase 0 종료.** 턴 중간에 워커를 `kill -9` 해도 이벤트 유실 0 · 중복 커밋 0으로
이어받는 것을 테스트로 보입니다. 통과하지 못하면 **M2를 시작하지 않습니다** — 설계에서
가장 뒤집기 비싼 D3(실행 권한)·D4(이벤트 순서)를 고쳐야 한다는 뜻입니다.

**M4 종료 = MVP.** 성공 기준 7개를 측정값으로 보고하고, 열린 질문
Q1(`bash` 필요 비율) · Q2(CPython WASI 실효성) · Q3(프로덕션 userns)을 답합니다.

---

## 문서를 다시 만들 때

```sh
python3 plan/_build/gen_svg.py       # 다이어그램 21개
python3 plan/_build/build_html.py    # plan/*.md → plan/index.html
python3 task/_build/gen_tasks.py     # 작업 명세 38개 + 마일스톤 README
```

`plan/*.md`와 `task/_build/gen_tasks.py`가 원천이고 `index.html`·작업 명세는 산출물입니다.
단 작업 **상태**를 손으로 관리하기 시작하면 그때부터 `gen_tasks.py`를 돌리지 마십시오.
