"""SQL 승인 저장소. `plan/05-database.md` §3 G10.

**결정은 CAS 다.** `state='pending'` 과 "아직 안 누른 사람"을 WHERE 에 넣어,
두 사람이 동시에 눌러도 표가 정확히 둘이 된다.
"""

from __future__ import annotations

import json
from datetime import UTC, datetime
from decimal import Decimal
from typing import Any

from ma_domain.agents import ToolKind
from ma_domain.governance import (
    ActorKind,
    Approval,
    ApprovalPolicy,
    ApprovalState,
    AuditEntry,
    Budget,
    BudgetPeriod,
    BudgetScope,
    UsageEvent,
)
from ma_domain.ids import ApprovalId, SessionId, WorkspaceId
from ma_domain.models import TokenUsage
from ma_domain.workspaces import Role
from ma_sql.ports import Row, SqlClient, Statement
from ma_store._results import Cursor, ListQuery, Page
from ma_store.governance import DecideApproval

_APPROVAL_COLS = (
    "id, workspace_id, session_id, event_id, tool_call_id, tool_name, tool_kind, "
    "input_summary, policy_id, state, decided_by, decided_at, reason, "
    "requested_at, expires_at"
)
_POLICY_COLS = (
    "id, workspace_id, agent_id, tool_pattern, required_role, required_approvals, "
    "self_approval, notify, expires_after_s, priority, created_at"
)


def _obj(raw: object) -> dict[str, Any]:
    if raw is None:
        return {}
    if isinstance(raw, str):
        loaded: dict[str, Any] = json.loads(raw)
        return loaded
    return dict(raw) if isinstance(raw, dict) else {}


def _approval(row: Row) -> Approval:
    return Approval(
        id=row["id"],
        workspace_id=row["workspace_id"],
        session_id=row["session_id"],
        event_id=row["event_id"],
        tool_call_id=row["tool_call_id"],
        tool_name=row["tool_name"],
        tool_kind=ToolKind(row["tool_kind"]),
        state=ApprovalState(row["state"]),
        requested_at=row["requested_at"],
        input_summary=tuple(sorted(_obj(row["input_summary"]).items())),
        policy_id=row["policy_id"],
        decided_by=tuple(row["decided_by"] or ()),
        decided_at=row["decided_at"],
        reason=row["reason"],
        expires_at=row["expires_at"],
    )


def _policy(row: Row) -> ApprovalPolicy:
    return ApprovalPolicy(
        id=row["id"],
        workspace_id=row["workspace_id"],
        tool_pattern=row["tool_pattern"],
        required_role=Role(row["required_role"]),
        created_at=row["created_at"],
        agent_id=row["agent_id"],
        required_approvals=row["required_approvals"],
        self_approval=row["self_approval"],
        expires_after_seconds=row["expires_after_s"],
        notify=tuple(sorted((k, str(v)) for k, v in _obj(row["notify"]).items())),
        priority=row["priority"],
    )


class SqlApprovalStore:
    def __init__(self, sql: SqlClient) -> None:
        self._sql = sql

    async def insert(self, approval: Approval) -> Approval:
        """**한 호출에 승인은 하나.** 충돌하면 기존 것을 돌려준다.

        예외를 던지지 않는 이유: 재개 경로가 같은 턴을 다시 밟을 수 있고
        (워커 크래시 뒤 재claim), 그때 "이미 있다"는 정상이다.
        """
        row = await self._sql.fetch_one(
            Statement(
                f"""
                INSERT INTO approvals
                  (id, workspace_id, session_id, event_id, tool_call_id, tool_name,
                   tool_kind, input_summary, policy_id, state, requested_at, expires_at)
                VALUES ($1,$2,$3,$4,$5,$6,$7,$8::jsonb,$9,$10,$11,$12)
                ON CONFLICT (workspace_id, session_id, tool_call_id) DO NOTHING
                RETURNING {_APPROVAL_COLS}
                """,  # noqa: S608 — _APPROVAL_COLS 는 이 모듈의 상수 리터럴이다
                (
                    approval.id,
                    approval.workspace_id,
                    approval.session_id,
                    approval.event_id,
                    approval.tool_call_id,
                    approval.tool_name,
                    approval.tool_kind.value,
                    json.dumps(dict(approval.input_summary), ensure_ascii=False),
                    approval.policy_id,
                    approval.state.value,
                    approval.requested_at,
                    approval.expires_at,
                ),
            )
        )
        if row is not None:
            return _approval(row)
        existing = await self.find_by_tool_call(
            approval.workspace_id, approval.session_id, approval.tool_call_id
        )
        assert existing is not None  # 충돌했으니 반드시 있다
        return existing

    async def find(self, workspace_id: WorkspaceId, approval_id: ApprovalId) -> Approval | None:
        row = await self._sql.fetch_one(
            Statement(
                f"SELECT {_APPROVAL_COLS} FROM approvals WHERE workspace_id=$1 AND id=$2",  # noqa: S608
                (workspace_id, approval_id),
            )
        )
        return _approval(row) if row else None

    async def find_by_tool_call(
        self, workspace_id: WorkspaceId, session_id: SessionId, tool_call_id: str
    ) -> Approval | None:
        row = await self._sql.fetch_one(
            Statement(
                f"SELECT {_APPROVAL_COLS} FROM approvals "  # noqa: S608
                "WHERE workspace_id=$1 AND session_id=$2 AND tool_call_id=$3",
                (workspace_id, session_id, tool_call_id),
            )
        )
        return _approval(row) if row else None

    async def decide(self, cmd: DecideApproval) -> Approval | None:
        """**한 번의 결정은 한 표.** 동시에 둘이 눌러도 표가 둘이 된다.

        `NOT ($3 = ANY(decided_by))` 가 CAS 다 — 같은 사람의 두 번째
        클릭은 0행을 만든다. 그것이 없으면 혼자 4-eyes 를 채운다.

        거부는 **한 표로 끝난다.** 반대가 하나라도 있으면 진행하지 않는
        것이 fail-closed 이고, 승인만 수를 센다.
        """
        row = await self._sql.fetch_one(
            Statement(
                f"""
                UPDATE approvals SET
                  decided_by = array_append(decided_by, $3),
                  decided_at = $4,
                  reason = COALESCE($5, reason),
                  state = CASE WHEN $6 THEN state ELSE 'denied' END
                WHERE workspace_id = $1 AND id = $2
                  AND state = 'pending'
                  AND NOT ($3 = ANY(decided_by))
                RETURNING {_APPROVAL_COLS}
                """,  # noqa: S608
                (
                    cmd.workspace_id,
                    cmd.approval_id,
                    cmd.decided_by,
                    cmd.now,
                    cmd.reason,
                    cmd.approve,
                ),
            )
        )
        return _approval(row) if row else None

    async def finalize(
        self, workspace_id: WorkspaceId, approval_id: ApprovalId, now: datetime
    ) -> Approval | None:
        """표가 다 찼을 때 `approved` 로 올린다. 정책 레이어가 부른다.

        수를 Store 가 모르는 이유: `required_approvals` 는 정책에 있고,
        두 곳이 그 수를 알면 어긋난다.
        """
        row = await self._sql.fetch_one(
            Statement(
                f"""
                UPDATE approvals SET state = 'approved', decided_at = $3
                WHERE workspace_id = $1 AND id = $2
                  AND state = 'pending' AND array_length(decided_by, 1) >= 1
                RETURNING {_APPROVAL_COLS}
                """,  # noqa: S608
                (workspace_id, approval_id, now),
            )
        )
        return _approval(row) if row else None

    async def expire_due(self, workspace_id: WorkspaceId, now: datetime) -> int:
        got = await self._sql.execute(
            Statement(
                """
                UPDATE approvals SET state = 'expired', decided_at = $2
                WHERE workspace_id = $1 AND state = 'pending'
                  AND expires_at IS NOT NULL AND expires_at <= $2
                """,
                (workspace_id, now),
            )
        )
        return got.rows_affected

    async def list_inbox(self, q: ListQuery, state: ApprovalState) -> Page[Approval]:
        rows = await self._sql.fetch_all(
            Statement(
                f"""
                SELECT {_APPROVAL_COLS} FROM approvals
                WHERE workspace_id = $1 AND state = $2
                  AND ($3::timestamptz IS NULL OR (requested_at, id) > ($3, $4))
                ORDER BY requested_at, id
                LIMIT $5
                """,  # noqa: S608
                (
                    q.workspace_id,
                    state.value,
                    q.after.created_at if q.after else None,
                    q.after.id if q.after else None,
                    q.limit + 1,
                ),
            )
        )
        window = [_approval(r) for r in rows[: q.limit]]
        nxt = (
            Cursor(window[-1].requested_at, window[-1].id)
            if len(rows) > q.limit and window
            else None
        )
        return Page(items=tuple(window), next_cursor=nxt)


class SqlApprovalPolicyStore:
    def __init__(self, sql: SqlClient) -> None:
        self._sql = sql

    async def upsert(self, policy: ApprovalPolicy) -> ApprovalPolicy:
        row = await self._sql.fetch_one(
            Statement(
                f"""
                INSERT INTO approval_policies
                  (id, workspace_id, agent_id, tool_pattern, required_role,
                   required_approvals, self_approval, notify, expires_after_s,
                   priority, created_at)
                VALUES ($1,$2,$3,$4,$5,$6,$7,$8::jsonb,$9,$10,$11)
                ON CONFLICT (id) DO UPDATE SET
                  agent_id = EXCLUDED.agent_id,
                  tool_pattern = EXCLUDED.tool_pattern,
                  required_role = EXCLUDED.required_role,
                  required_approvals = EXCLUDED.required_approvals,
                  self_approval = EXCLUDED.self_approval,
                  notify = EXCLUDED.notify,
                  expires_after_s = EXCLUDED.expires_after_s,
                  priority = EXCLUDED.priority
                RETURNING {_POLICY_COLS}
                """,  # noqa: S608
                (
                    policy.id,
                    policy.workspace_id,
                    policy.agent_id,
                    policy.tool_pattern,
                    policy.required_role.value,
                    policy.required_approvals,
                    policy.self_approval,
                    json.dumps(dict(policy.notify), ensure_ascii=False),
                    policy.expires_after_seconds,
                    policy.priority,
                    policy.created_at,
                ),
            )
        )
        assert row is not None
        return _policy(row)

    async def list_policies(self, workspace_id: WorkspaceId) -> tuple[ApprovalPolicy, ...]:
        rows = await self._sql.fetch_all(
            Statement(
                f"SELECT {_POLICY_COLS} FROM approval_policies "  # noqa: S608
                "WHERE workspace_id=$1 ORDER BY priority DESC, id",
                (workspace_id,),
            )
        )
        return tuple(_policy(r) for r in rows)

    async def delete(self, workspace_id: WorkspaceId, policy_id: str) -> bool:
        got = await self._sql.execute(
            Statement(
                "DELETE FROM approval_policies WHERE workspace_id=$1 AND id=$2",
                (workspace_id, policy_id),
            )
        )
        return got.rows_affected == 1


_AUDIT_COLS = (
    "id, workspace_id, actor_type, actor_id, action, resource_type, resource_id, "
    "session_id, detail, request_id, ip, created_at"
)


def _audit(row: Row) -> AuditEntry:
    return AuditEntry(
        workspace_id=row["workspace_id"],
        actor_kind=ActorKind(row["actor_type"]),
        actor_id=row["actor_id"],
        action=row["action"],
        resource_type=row["resource_type"],
        resource_id=row["resource_id"],
        created_at=row["created_at"],
        session_id=row["session_id"],
        detail=tuple(sorted(_obj(row["detail"]).items())),
        request_id=row["request_id"],
    )


class SqlAuditStore:
    """append-only. **DB 권한이 그것을 강제한다** (`0006_audit_log`).

    이 클래스에 `update` 도 `delete` 도 없지만, 그것만으로는 부족하다 —
    누군가 `SqlClient` 로 직접 쓰면 그만이다. `REVOKE UPDATE, DELETE,
    TRUNCATE` 가 마지막 방어선이고, 그래서 마이그레이션에 있다.
    """

    def __init__(self, sql: SqlClient) -> None:
        self._sql = sql

    async def append(self, entry: AuditEntry) -> None:
        await self._sql.execute(
            Statement(
                """
                INSERT INTO audit_log
                  (workspace_id, actor_type, actor_id, action, resource_type,
                   resource_id, session_id, detail, request_id, created_at)
                VALUES ($1,$2,$3,$4,$5,$6,$7,$8::jsonb,$9,$10)
                """,
                (
                    entry.workspace_id,
                    entry.actor_kind.value,
                    entry.actor_id,
                    entry.action,
                    entry.resource_type,
                    entry.resource_id,
                    entry.session_id,
                    json.dumps(dict(entry.detail), ensure_ascii=False, default=str),
                    entry.request_id,
                    entry.created_at,
                ),
            )
        )

    async def list_entries(self, q: ListQuery) -> Page[AuditEntry]:
        """**최신이 먼저**다. 다른 목록과 반대 — 조사는 지금부터 거슬러 간다."""
        rows = await self._sql.fetch_all(
            Statement(
                f"""
                SELECT {_AUDIT_COLS} FROM audit_log
                WHERE workspace_id = $1
                  AND ($2::timestamptz IS NULL OR created_at >= $2)
                  AND ($3::timestamptz IS NULL OR created_at <= $3)
                  AND ($4::timestamptz IS NULL OR (created_at, id::text) < ($4, $5))
                ORDER BY created_at DESC, id DESC
                LIMIT $6
                """,  # noqa: S608
                (
                    q.workspace_id,
                    q.created_at_gte,
                    q.created_at_lte,
                    q.after.created_at if q.after else None,
                    q.after.id if q.after else None,
                    q.limit + 1,
                ),
            )
        )
        window = [(_audit(r), str(r["id"])) for r in rows[: q.limit]]
        nxt = (
            Cursor(window[-1][0].created_at, window[-1][1])
            if len(rows) > q.limit and window
            else None
        )
        return Page(items=tuple(e for e, _ in window), next_cursor=nxt)

    async def list_for_session(
        self, workspace_id: WorkspaceId, session_id: SessionId
    ) -> tuple[AuditEntry, ...]:
        """타임라인은 **오래된 것부터** — 이야기를 처음부터 읽는다."""
        rows = await self._sql.fetch_all(
            Statement(
                f"SELECT {_AUDIT_COLS} FROM audit_log "  # noqa: S608
                "WHERE workspace_id=$1 AND session_id=$2 ORDER BY created_at, id",
                (workspace_id, session_id),
            )
        )
        return tuple(_audit(r) for r in rows)


_USAGE_COLS = (
    "workspace_id, session_id, thread_id, agent_id, model_card_id, wire_model, "
    "input_cache_hit_tokens, input_cache_miss_tokens, output_tokens, "
    "list_cost_cents, sandbox_seconds, created_at, off_peak"
)
_BUDGET_COLS = (
    "id, workspace_id, scope, scope_id, period, limit_cents, "
    "session_default_cents, hard, created_at"
)


def _budget(row: Row) -> Budget:
    return Budget(
        workspace_id=row["workspace_id"],
        scope=BudgetScope(row["scope"]),
        period=BudgetPeriod(row["period"]),
        limit_cents=row["limit_cents"],
        scope_id=row["scope_id"],
        session_default_cents=row["session_default_cents"],
        hard=row["hard"],
    )


def _usage(row: Row) -> UsageEvent:
    return UsageEvent(
        workspace_id=row["workspace_id"],
        session_id=row["session_id"],
        model_card_id=row["model_card_id"],
        wire_model=row["wire_model"],
        usage=TokenUsage(
            input_cache_hit=row["input_cache_hit_tokens"],
            input_cache_miss=row["input_cache_miss_tokens"],
            output=row["output_tokens"],
        ),
        list_cost_cents=Decimal(str(row["list_cost_cents"])),
        created_at=row["created_at"],
        thread_id=row["thread_id"],
        agent_id=row["agent_id"],
        sandbox_seconds=row["sandbox_seconds"],
        off_peak=row["off_peak"],
    )


class SqlBudgetStore:
    """예산. **워커는 읽기만 한다** (`0007_budgets` 의 GRANT).

    탈취된 워커가 자기 상한을 올릴 수 있으면 예산이 의미를 잃는다.
    """

    def __init__(self, sql: SqlClient) -> None:
        self._sql = sql

    async def upsert(self, budget: Budget) -> Budget:
        row = await self._sql.fetch_one(
            Statement(
                f"""
                INSERT INTO budgets
                  (id, workspace_id, scope, scope_id, period, limit_cents,
                   session_default_cents, hard, created_at)
                VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
                ON CONFLICT (workspace_id, scope, COALESCE(scope_id, ''), period)
                DO UPDATE SET
                  limit_cents = EXCLUDED.limit_cents,
                  session_default_cents = EXCLUDED.session_default_cents,
                  hard = EXCLUDED.hard
                RETURNING {_BUDGET_COLS}
                """,  # noqa: S608
                (
                    _budget_id(budget),
                    budget.workspace_id,
                    budget.scope.value,
                    budget.scope_id,
                    budget.period.value,
                    budget.limit_cents,
                    budget.session_default_cents,
                    budget.hard,
                    datetime.now(UTC),
                ),
            )
        )
        assert row is not None
        return _budget(row)

    async def find(
        self,
        workspace_id: WorkspaceId,
        scope: BudgetScope,
        scope_id: str | None,
        period: BudgetPeriod,
    ) -> Budget | None:
        row = await self._sql.fetch_one(
            Statement(
                f"SELECT {_BUDGET_COLS} FROM budgets WHERE workspace_id=$1 "  # noqa: S608
                "AND scope=$2 AND COALESCE(scope_id,'')=COALESCE($3,'') AND period=$4",
                (workspace_id, scope.value, scope_id, period.value),
            )
        )
        return _budget(row) if row else None

    async def list_budgets(self, workspace_id: WorkspaceId) -> tuple[Budget, ...]:
        rows = await self._sql.fetch_all(
            Statement(
                f"SELECT {_BUDGET_COLS} FROM budgets WHERE workspace_id=$1 "  # noqa: S608
                "ORDER BY scope, COALESCE(scope_id,''), period",
                (workspace_id,),
            )
        )
        return tuple(_budget(r) for r in rows)


def _budget_id(budget: Budget) -> str:
    """예산 id 를 **스코프에서 유도한다.**

    유니크 키가 `(workspace, scope, scope_id, period)` 이므로 id 는
    사실상 그것의 다른 표현이다. 따로 생성하면 같은 스코프에 두 id 가
    생겨 `ON CONFLICT` 가 어느 쪽을 남길지 모호해진다.
    """
    import hashlib

    raw = (
        f"{budget.workspace_id}/{budget.scope.value}/{budget.scope_id or ''}/{budget.period.value}"
    )
    return "bdgt_" + hashlib.sha256(raw.encode()).hexdigest()[:26]


class SqlUsageStore:
    """append-only. **비용 기록은 감사의 일부다.**"""

    def __init__(self, sql: SqlClient) -> None:
        self._sql = sql

    async def record(self, event: UsageEvent) -> None:
        await self._sql.execute(
            Statement(
                """
                INSERT INTO usage_events
                  (workspace_id, session_id, thread_id, agent_id, model_card_id,
                   wire_model, input_cache_hit_tokens, input_cache_miss_tokens,
                   output_tokens, list_cost_cents, sandbox_seconds, created_at,
                   off_peak)
                VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)
                """,
                (
                    event.workspace_id,
                    event.session_id,
                    event.thread_id,
                    event.agent_id,
                    event.model_card_id,
                    event.wire_model,
                    event.usage.input_cache_hit,
                    event.usage.input_cache_miss,
                    event.usage.output,
                    event.list_cost_cents,
                    event.sandbox_seconds,
                    event.created_at,
                    event.off_peak,
                ),
            )
        )

    async def sum_cost_cents(
        self,
        workspace_id: WorkspaceId,
        since: datetime,
        until: datetime,
        agent_id: str | None = None,
    ) -> Decimal:
        """**`[since, until)`** — 끝이 배타다.

        포함으로 하면 자정에 걸친 이벤트가 두 날에 모두 세어진다.
        """
        row = await self._sql.fetch_one(
            Statement(
                """
                SELECT COALESCE(SUM(list_cost_cents), 0) AS total FROM usage_events
                WHERE workspace_id = $1 AND created_at >= $2 AND created_at < $3
                  AND ($4::text IS NULL OR agent_id = $4)
                """,
                (workspace_id, since, until, agent_id),
            )
        )
        return Decimal(str(row["total"])) if row else Decimal(0)

    async def list_events(self, q: ListQuery) -> Page[UsageEvent]:
        rows = await self._sql.fetch_all(
            Statement(
                f"""
                SELECT {_USAGE_COLS} FROM usage_events
                WHERE workspace_id = $1
                  AND ($2::timestamptz IS NULL OR created_at >= $2)
                  AND ($3::timestamptz IS NULL OR created_at <= $3)
                  AND ($4::timestamptz IS NULL OR (created_at, session_id) < ($4, $5))
                ORDER BY created_at DESC, session_id DESC
                LIMIT $6
                """,  # noqa: S608
                (
                    q.workspace_id,
                    q.created_at_gte,
                    q.created_at_lte,
                    q.after.created_at if q.after else None,
                    q.after.id if q.after else None,
                    q.limit + 1,
                ),
            )
        )
        window = [_usage(r) for r in rows[: q.limit]]
        nxt = (
            Cursor(window[-1].created_at, window[-1].session_id)
            if len(rows) > q.limit and window
            else None
        )
        return Page(items=tuple(window), next_cursor=nxt)


__all__ = [
    "SqlApprovalPolicyStore",
    "SqlApprovalStore",
    "SqlAuditStore",
    "SqlBudgetStore",
    "SqlUsageStore",
]
