"""SqlAgentStore — 버전 관리 리소스 SQL 구현의 표준형.

`plan/03-layers.md` §6 · `plan/05-database.md` §3 G2.

**CAS는 한 번의 원자적 배치다.** 스냅샷과 교체가 쪼개지면 버전 역사가 깨진다.
영향 행 수가 `(1,1)`이 아니고 `(0,0)`도 아니면 **불변식 위반이므로 예외**를 올린다 —
조용히 넘기지 않는다.
"""

from __future__ import annotations

import json
from typing import Any

from ma_domain.agents import AgentRecord
from ma_domain.errors import InvariantViolation
from ma_sql.ports import Row, SqlClient, Statement
from ma_store._results import (
    Archived,
    ArchiveResult,
    Cursor,
    ListQuery,
    NotFound,
    Page,
    Replaced,
    ReplaceResult,
    VersionConflict,
)
from ma_store.agents import (
    ArchiveAgent,
    FindAgentVersion,
    FindCurrentAgent,
    InsertAgent,
    ListAgentVersions,
    ReplaceAgent,
)

from ma_store_sql._codec import decode_agent_definition, encode_agent_definition


def _row_to_record(row: Row) -> AgentRecord:
    return AgentRecord(
        id=row["id"],
        workspace_id=row["workspace_id"],
        definition=decode_agent_definition(row["document"]),
        version=row["version"],
        created_by=row["created_by"],
        created_at=row["created_at"],
        updated_at=row["updated_at"],
        archived_at=row["archived_at"],
    )


class SqlAgentStore:
    """ "Agent를 아는" SQL은 여기에만 있다."""

    def __init__(self, sql: SqlClient) -> None:
        self._sql = sql

    async def insert(self, cmd: InsertAgent) -> AgentRecord:
        doc = json.dumps(encode_agent_definition(cmd.definition))
        row = await self._sql.fetch_one(
            Statement(
                """
                INSERT INTO agents
                  (id, workspace_id, document, version, created_by, created_at, updated_at)
                VALUES ($1, $2, $3::jsonb, 1, $4, $5, $5)
                RETURNING *
                """,
                (cmd.id, cmd.workspace_id, doc, cmd.created_by, cmd.now),
            )
        )
        if row is None:  # pragma: no cover — RETURNING 은 항상 행을 준다
            raise InvariantViolation("INSERT ... RETURNING 이 행을 돌려주지 않았다")
        return _row_to_record(row)

    async def find_current(self, q: FindCurrentAgent) -> AgentRecord | None:
        row = await self._sql.fetch_one(
            Statement(
                "SELECT * FROM agents "
                "WHERE workspace_id = $1 AND id = $2 AND ($3 OR archived_at IS NULL)",
                (q.workspace_id, q.id, q.include_archived),
            )
        )
        return _row_to_record(row) if row else None

    async def find_version(self, q: FindAgentVersion) -> AgentRecord | None:
        """현재 버전은 `agents`에, 과거 버전은 `agent_versions`에 있다."""
        row = await self._sql.fetch_one(
            Statement(
                """
                SELECT a.id, a.workspace_id, v.document, v.version,
                       a.created_by, v.created_at, v.created_at AS updated_at,
                       NULL::timestamptz AS archived_at
                  FROM agent_versions v
                  JOIN agents a
                    ON a.workspace_id = v.workspace_id AND a.id = v.agent_id
                 WHERE v.workspace_id = $1 AND v.agent_id = $2 AND v.version = $3
                """,
                (q.workspace_id, q.id, q.version),
            )
        )
        if row is not None:
            return _row_to_record(row)
        cur = await self._sql.fetch_one(
            Statement(
                "SELECT * FROM agents WHERE workspace_id = $1 AND id = $2 AND version = $3",
                (q.workspace_id, q.id, q.version),
            )
        )
        return _row_to_record(cur) if cur else None

    async def replace_current(self, cmd: ReplaceAgent) -> ReplaceResult[AgentRecord]:
        doc = json.dumps(encode_agent_definition(cmd.definition))
        snapshot = Statement(
            """
            INSERT INTO agent_versions (workspace_id, agent_id, version, document, created_at)
            SELECT workspace_id, id, version, document, updated_at FROM agents
             WHERE workspace_id = $1 AND id = $2 AND version = $3 AND archived_at IS NULL
            ON CONFLICT DO NOTHING
            """,
            (cmd.workspace_id, cmd.id, cmd.expected_version),
        )
        update = Statement(
            """
            UPDATE agents SET document = $4::jsonb, version = version + 1, updated_at = $5
             WHERE workspace_id = $1 AND id = $2 AND version = $3 AND archived_at IS NULL
            """,
            (cmd.workspace_id, cmd.id, cmd.expected_version, doc, cmd.now),
        )
        results = await self._sql.batch([snapshot, update])
        snap_n, upd_n = results[0].rows_affected, results[1].rows_affected

        if (snap_n, upd_n) == (1, 1):
            got = await self.find_current(FindCurrentAgent(cmd.workspace_id, cmd.id))
            if got is None:  # pragma: no cover
                raise InvariantViolation("교체 직후 행을 찾을 수 없다")
            return Replaced(record=got)
        if (snap_n, upd_n) == (0, 0):
            return await self._miss(cmd.workspace_id, cmd.id, cmd.expected_version)
        raise InvariantViolation(
            f"CAS 배치의 영향 행 수가 불변식을 깼다: snapshot={snap_n} update={upd_n}"
        )

    async def archive_current(self, cmd: ArchiveAgent) -> ArchiveResult[AgentRecord]:
        res = await self._sql.execute(
            Statement(
                """
                UPDATE agents SET archived_at = $4, updated_at = $4
                 WHERE workspace_id = $1 AND id = $2 AND version = $3 AND archived_at IS NULL
                """,
                (cmd.workspace_id, cmd.id, cmd.expected_version, cmd.now),
            )
        )
        if res.rows_affected == 1:
            got = await self.find_current(
                FindCurrentAgent(cmd.workspace_id, cmd.id, include_archived=True)
            )
            if got is None:  # pragma: no cover
                raise InvariantViolation("아카이브 직후 행을 찾을 수 없다")
            return Archived(record=got)
        return await self._miss(cmd.workspace_id, cmd.id, cmd.expected_version)

    async def _miss(
        self, workspace_id: str, agent_id: str, expected: int
    ) -> NotFound | VersionConflict:
        """`(0,0)`이 not_found인지 version_conflict인지 가른다."""
        row = await self._sql.fetch_one(
            Statement(
                "SELECT version, archived_at FROM agents WHERE workspace_id = $1 AND id = $2",
                (workspace_id, agent_id),
            )
        )
        if row is None or row["archived_at"] is not None:
            return NotFound()
        if row["version"] != expected:
            return VersionConflict(actual_version=row["version"])
        return NotFound()

    async def list_current(self, q: ListQuery) -> Page[AgentRecord]:
        where: list[str] = ["workspace_id = $1"]
        args: list[Any] = [q.workspace_id]
        if not q.include_archived:
            where.append("archived_at IS NULL")
        if q.created_at_gte is not None:
            args.append(q.created_at_gte)
            where.append(f"created_at >= ${len(args)}")
        if q.created_at_lte is not None:
            args.append(q.created_at_lte)
            where.append(f"created_at <= ${len(args)}")
        if q.after is not None:
            args.extend([q.after.created_at, q.after.id])
            where.append(f"(created_at, id) > (${len(args) - 1}, ${len(args)})")
        args.append(q.limit + 1)  # has_more 판정용으로 하나 더
        # where 의 조각은 전부 이 함수 안의 리터럴이고, 사용자 값은 $N 바인딩으로만 들어간다.
        # 문자열에 섞이는 것은 플레이스홀더 번호뿐이다.
        sql = (
            f"SELECT * FROM agents WHERE {' AND '.join(where)} "  # noqa: S608 — 조각이 상수다
            f"ORDER BY created_at, id LIMIT ${len(args)}"
        )
        rows = await self._sql.fetch_all(Statement(sql, tuple(args)))
        return _page(rows, q.limit)

    async def list_versions(self, q: ListAgentVersions) -> Page[AgentRecord]:
        rows = await self._sql.fetch_all(
            Statement(
                """
                SELECT a.id, a.workspace_id, v.document, v.version, a.created_by,
                       v.created_at, v.created_at AS updated_at,
                       NULL::timestamptz AS archived_at
                  FROM agent_versions v
                  JOIN agents a ON a.workspace_id = v.workspace_id AND a.id = v.agent_id
                 WHERE v.workspace_id = $1 AND v.agent_id = $2
                UNION ALL
                SELECT id, workspace_id, document, version, created_by,
                       created_at, updated_at, archived_at
                  FROM agents WHERE workspace_id = $1 AND id = $2
                 ORDER BY version DESC LIMIT $3
                """,
                (q.workspace_id, q.id, q.limit),
            )
        )
        return Page(items=tuple(_row_to_record(r) for r in rows))


def _page(rows: list[Row], limit: int) -> Page[AgentRecord]:
    items = [_row_to_record(r) for r in rows[:limit]]
    nxt: Cursor | None = None
    if len(rows) > limit and items:
        nxt = Cursor(items[-1].created_at, items[-1].id)
    return Page(items=tuple(items), next_cursor=nxt)


__all__ = ["SqlAgentStore"]
