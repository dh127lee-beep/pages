"""AWP · Store SQL 구현 (PostgreSQL)"""
