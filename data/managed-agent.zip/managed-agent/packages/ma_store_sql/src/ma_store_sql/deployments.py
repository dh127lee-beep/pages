"""SQL 배포 스토어 (G9).

`plan/05-database.md` §3 G9.

**`claim_fire` 가 한 배치다.** 실행 INSERT 와 다음 발화 UPDATE 가
쪼개지면 둘 사이에 다른 스케줄러가 끼어들어 같은 발화를 두 번 돌린다 —
리더 교체 중에 실제로 일어난다. 유니크 인덱스(`idx_runs_fire`)가
최종 방어선이다.
"""

from __future__ import annotations

import json
from datetime import datetime, timedelta

from ma_domain.deployments import (
    Deployment,
    DeploymentRun,
    DeploymentState,
    RunState,
    RunTrigger,
    Schedule,
)
from ma_domain.ids import WorkspaceId
from ma_sql.errors import ForeignKeyViolation, UniqueViolation
from ma_sql.ports import Row, SqlClient, Statement
from ma_store._results import Cursor, ListQuery, NotFound, Page
from ma_store.deployments import (
    AlreadyFired,
    ClaimedFire,
    ClaimFire,
    ClaimFireResult,
    FinishRun,
    InsertDeployment,
    UpdateDeploymentState,
)

_DEP_COLS = (
    "id, workspace_id, name, agent_id, agent_version, environment_id, state, "
    "cron, timezone, off_peak_preferred, max_shift_seconds, initial_events, "
    "budget_cents, consecutive_failures, last_run_at, next_fire_at, "
    "paused_reason, created_at, updated_at, archived_at"
)
_RUN_COLS = (
    "id, workspace_id, deployment_id, session_id, state, trigger, "
    "scheduled_for, shifted_seconds, started_at, ended_at, error, "
    "cost_cents, created_at"
)


def _deployment(row: Row) -> Deployment:
    raw_events = row["initial_events"]
    events = json.loads(raw_events) if isinstance(raw_events, str) else (raw_events or [])
    schedule = (
        Schedule(
            cron=row["cron"],
            timezone=row["timezone"],
            off_peak_preferred=row["off_peak_preferred"],
            max_shift=timedelta(seconds=row["max_shift_seconds"]),
        )
        if row["cron"]
        else None
    )
    return Deployment(
        id=row["id"],
        workspace_id=row["workspace_id"],
        name=row["name"],
        agent_id=row["agent_id"],
        agent_version=row["agent_version"],
        state=DeploymentState(row["state"]),
        created_at=row["created_at"],
        updated_at=row["updated_at"],
        environment_id=row["environment_id"],
        schedule=schedule,
        initial_events=tuple(tuple(sorted(dict(e).items())) for e in events),
        budget_cents=row["budget_cents"],
        consecutive_failures=row["consecutive_failures"],
        last_run_at=row["last_run_at"],
        next_fire_at=row["next_fire_at"],
        paused_reason=row["paused_reason"],
        archived_at=row["archived_at"],
    )


def _run(row: Row) -> DeploymentRun:
    return DeploymentRun(
        id=row["id"],
        workspace_id=row["workspace_id"],
        deployment_id=row["deployment_id"],
        state=RunState(row["state"]),
        trigger=RunTrigger(row["trigger"]),
        scheduled_for=row["scheduled_for"],
        created_at=row["created_at"],
        session_id=row["session_id"],
        started_at=row["started_at"],
        ended_at=row["ended_at"],
        shifted_by=timedelta(seconds=row["shifted_seconds"]),
        error=row["error"],
        cost_cents=row["cost_cents"],
    )


class SqlDeploymentStore:
    def __init__(self, sql: SqlClient) -> None:
        self._sql = sql

    async def insert(self, cmd: InsertDeployment) -> Deployment:
        s = cmd.schedule
        row = await self._sql.fetch_one(
            Statement(
                f"""
                INSERT INTO deployments
                  (id, workspace_id, name, agent_id, agent_version, environment_id,
                   state, cron, timezone, off_peak_preferred, max_shift_seconds,
                   initial_events, budget_cents, next_fire_at,
                   created_by, created_at, updated_at)
                VALUES ($1,$2,$3,$4,$5,$6,'active',$7,$8,$9,$10,$11::jsonb,$12,$13,$14,$15,$15)
                RETURNING {_DEP_COLS}
                """,  # noqa: S608
                (
                    cmd.id,
                    cmd.workspace_id,
                    cmd.name,
                    cmd.agent_id,
                    cmd.agent_version,
                    cmd.environment_id,
                    s.cron if s else None,
                    s.timezone if s else "UTC",
                    s.off_peak_preferred if s else False,
                    int(s.max_shift.total_seconds()) if s else 21600,
                    json.dumps(list(cmd.initial_events), ensure_ascii=False),
                    cmd.budget_cents,
                    cmd.next_fire_at,
                    cmd.created_by,
                    cmd.now,
                ),
            )
        )
        if row is None:  # pragma: no cover
            raise ValueError("INSERT ... RETURNING 이 행을 돌려주지 않았다")
        return _deployment(row)

    async def find(self, workspace_id: WorkspaceId, deployment_id: str) -> Deployment | None:
        row = await self._sql.fetch_one(
            Statement(
                f"SELECT {_DEP_COLS} FROM deployments "  # noqa: S608
                "WHERE workspace_id=$1 AND id=$2",
                (workspace_id, deployment_id),
            )
        )
        return _deployment(row) if row else None

    async def list_deployments(self, q: ListQuery) -> Page[Deployment]:
        rows = await self._sql.fetch_all(
            Statement(
                f"""
                SELECT {_DEP_COLS} FROM deployments
                WHERE workspace_id = $1
                  AND ($2 OR archived_at IS NULL)
                  AND ($3::timestamptz IS NULL OR (created_at, id) > ($3, $4))
                ORDER BY created_at, id
                LIMIT $5
                """,  # noqa: S608
                (
                    q.workspace_id,
                    q.include_archived,
                    q.after.created_at if q.after else None,
                    q.after.id if q.after else None,
                    q.limit + 1,
                ),
            )
        )
        window = [_deployment(r) for r in rows[: q.limit]]
        nxt = (
            Cursor(window[-1].created_at, window[-1].id) if len(rows) > q.limit and window else None
        )
        return Page(items=tuple(window), next_cursor=nxt)

    async def set_state(self, cmd: UpdateDeploymentState) -> Deployment | None:
        row = await self._sql.fetch_one(
            Statement(
                f"""
                UPDATE deployments
                   SET state = $3, updated_at = $4, paused_reason = $5,
                       -- **아카이브·일시정지는 발화하지 않는다** (DB CHECK).
                       next_fire_at = CASE WHEN $3 = 'active'
                                           THEN $6::timestamptz ELSE NULL END,
                       archived_at = CASE WHEN $3 = 'archived'
                                          THEN $4::timestamptz ELSE archived_at END
                 WHERE workspace_id = $1 AND id = $2
                RETURNING {_DEP_COLS}
                """,  # noqa: S608
                (
                    cmd.workspace_id,
                    cmd.deployment_id,
                    cmd.state.value,
                    cmd.now,
                    cmd.reason,
                    cmd.next_fire_at,
                ),
            )
        )
        return _deployment(row) if row else None

    async def due(self, now: datetime, limit: int = 50) -> tuple[Deployment, ...]:
        """**부분 인덱스를 탄다** (`idx_deployments_due`)."""
        rows = await self._sql.fetch_all(
            Statement(
                f"""
                SELECT {_DEP_COLS} FROM deployments
                WHERE state = 'active' AND next_fire_at IS NOT NULL
                  AND next_fire_at <= $1
                ORDER BY next_fire_at, id
                LIMIT $2
                """,  # noqa: S608
                (now, limit),
            )
        )
        return tuple(_deployment(r) for r in rows)

    async def claim_fire(self, cmd: ClaimFire) -> ClaimFireResult:
        """**한 배치다.** 실행 INSERT 와 다음 발화 UPDATE 가 함께 간다."""
        insert = Statement(
            """
            INSERT INTO deployment_runs
              (id, workspace_id, deployment_id, state, trigger,
               scheduled_for, shifted_seconds, created_at)
            VALUES ($1,$2,$3,'queued',$4,$5,$6,$7)
            """,
            (
                cmd.run_id,
                cmd.workspace_id,
                cmd.deployment_id,
                cmd.trigger.value,
                cmd.scheduled_for,
                int(cmd.shifted.total_seconds()),
                cmd.now,
            ),
        )
        advance = Statement(
            """
            UPDATE deployments
               SET next_fire_at = $3, last_run_at = $4, updated_at = $4
             WHERE workspace_id = $1 AND id = $2
            """,
            (cmd.workspace_id, cmd.deployment_id, cmd.next_fire_at, cmd.now),
        )
        try:
            results = await self._sql.batch([insert, advance])
        except UniqueViolation:
            # **다른 스케줄러가 먼저 집었다.** 정상이다.
            return AlreadyFired(scheduled_for=cmd.scheduled_for)
        except ForeignKeyViolation:
            # 배포가 없다. **메모리 구현과 같은 결과를 낸다** — 한쪽이
            # 예외를 던지고 다른 쪽이 결과를 돌려주면 호출자가
            # 백엔드에 따라 다르게 동작한다.
            return NotFound()

        if results[1].rows_affected == 0:
            return NotFound()

        deployment = await self.find(cmd.workspace_id, cmd.deployment_id)
        run = await self.find_run(cmd.workspace_id, cmd.run_id)
        if deployment is None or run is None:  # pragma: no cover
            return NotFound()
        return ClaimedFire(deployment=deployment, run=run)

    async def finish_run(self, cmd: FinishRun) -> DeploymentRun | None:
        finish = Statement(
            """
            UPDATE deployment_runs
               SET state = $3,
                   session_id = COALESCE($4, session_id),
                   started_at = COALESCE(started_at, $5),
                   ended_at = $5,
                   error = $6, cost_cents = $7
             WHERE workspace_id = $1 AND id = $2
            """,
            (
                cmd.workspace_id,
                cmd.run_id,
                cmd.state.value,
                cmd.session_id,
                cmd.now,
                cmd.error,
                cmd.cost_cents,
            ),
        )
        # 연속 실패를 센다 — 성공하면 0 으로 되돌린다.
        count = Statement(
            """
            UPDATE deployments d
               SET consecutive_failures = CASE WHEN $3 = 'failed'
                                               THEN d.consecutive_failures + 1
                                               ELSE 0 END,
                   updated_at = $4
              FROM deployment_runs r
             WHERE r.workspace_id = $1 AND r.id = $2
               AND d.workspace_id = r.workspace_id AND d.id = r.deployment_id
            """,
            (cmd.workspace_id, cmd.run_id, cmd.state.value, cmd.now),
        )
        await self._sql.batch([finish, count])
        return await self.find_run(cmd.workspace_id, cmd.run_id)

    async def find_run(self, workspace_id: WorkspaceId, run_id: str) -> DeploymentRun | None:
        row = await self._sql.fetch_one(
            Statement(
                f"SELECT {_RUN_COLS} FROM deployment_runs "  # noqa: S608
                "WHERE workspace_id=$1 AND id=$2",
                (workspace_id, run_id),
            )
        )
        return _run(row) if row else None

    async def list_runs(self, q: ListQuery, deployment_id: str) -> Page[DeploymentRun]:
        rows = await self._sql.fetch_all(
            Statement(
                f"""
                SELECT {_RUN_COLS} FROM deployment_runs
                WHERE workspace_id = $1 AND deployment_id = $2
                  AND ($3::timestamptz IS NULL OR (created_at, id) > ($3, $4))
                ORDER BY created_at, id
                LIMIT $5
                """,  # noqa: S608
                (
                    q.workspace_id,
                    deployment_id,
                    q.after.created_at if q.after else None,
                    q.after.id if q.after else None,
                    q.limit + 1,
                ),
            )
        )
        window = [_run(r) for r in rows[: q.limit]]
        nxt = (
            Cursor(window[-1].created_at, window[-1].id) if len(rows) > q.limit and window else None
        )
        return Page(items=tuple(window), next_cursor=nxt)

    async def running_count(self, workspace_id: WorkspaceId, deployment_id: str) -> int:
        got = await self._sql.fetch_one(
            Statement(
                "SELECT count(*) AS n FROM deployment_runs "
                "WHERE workspace_id=$1 AND deployment_id=$2 "
                "  AND state IN ('queued','running')",
                (workspace_id, deployment_id),
            )
        )
        return int(got["n"]) if got else 0


__all__ = ["SqlDeploymentStore"]
