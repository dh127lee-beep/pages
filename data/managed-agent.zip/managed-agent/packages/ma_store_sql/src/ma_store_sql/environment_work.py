"""SQL self_hosted 워커 큐 (G3 · T-0606).

`plan/05-database.md` §3 G3 · `plan/04-api.md` §3.3.

**`claim` 이 한 문장이다.** `FOR UPDATE SKIP LOCKED` 로 집고 같은
UPDATE 에서 generation 을 올린다. 쪼개면 둘 사이에 다른 워커가
끼어들어 같은 일을 두 번 돌린다 (D3 의 claim 과 같은 모양).

회수도 **같은 문장**에서 한다. 따로 돌면 "회수했는데 아직 큐에 안
올라온" 창이 생기고, 그 창에 폴링한 워커가 빈손으로 돌아간다.
"""

from __future__ import annotations

from datetime import datetime, timedelta

from ma_domain.environment_work import (
    DEFAULT_LEASE_TTL,
    MAX_ATTEMPTS,
    WorkItem,
    WorkState,
    WorkStats,
)
from ma_domain.ids import EnvironmentId, SessionId, WorkspaceId
from ma_governance.cipher import CredentialCipher, associated_data
from ma_sql.errors import UniqueViolation
from ma_sql.ports import Row, SqlClient, Statement
from ma_store._results import Cursor, ListQuery, Page
from ma_store.environment_work import (
    AckResult,
    AckWork,
    ClaimedWork,
    ClaimResult,
    ClaimWork,
    EnqueueWork,
    FenceLost,
    Heartbeat,
    HeartbeatResult,
    NoWork,
    WorkGone,
)

#: **`secret_ciphertext`·`secret_nonce` 가 없다.** 메타데이터 조회가
#: 비밀을 끌고 오면 그 행이 로그·추적·예외 메시지에 실릴 기회가 생긴다.
_NAMES = (
    "id",
    "workspace_id",
    "environment_id",
    "environment_version",
    "session_id",
    "state",
    "claim_generation",
    "worker_id",
    "attempts",
    "claimed_at",
    "heartbeat_at",
    "acked_at",
    "error",
    "created_at",
    "updated_at",
)
_COLS = ", ".join(_NAMES)
#: CTE 와 조인하는 UPDATE 에서 쓴다. **접두가 없으면 `id` 가 모호하다** —
#: `picked` 쪽에도 `id` 가 있고, Postgres 가 거부한다.
_W_COLS = ", ".join(f"w.{n}" for n in _NAMES)


def _out(row: Row) -> WorkItem:
    return WorkItem(
        id=row["id"],
        workspace_id=row["workspace_id"],
        environment_id=row["environment_id"],
        environment_version=row["environment_version"],
        session_id=row["session_id"],
        state=WorkState(row["state"]),
        claim_generation=row["claim_generation"],
        worker_id=row["worker_id"],
        attempts=row["attempts"],
        claimed_at=row["claimed_at"],
        heartbeat_at=row["heartbeat_at"],
        acked_at=row["acked_at"],
        error=row["error"] or "",
        created_at=row["created_at"],
        updated_at=row["updated_at"],
    )


class SqlEnvironmentWorkStore:
    def __init__(self, sql: SqlClient, cipher: CredentialCipher) -> None:
        self._sql = sql
        # **생성자 인자다.** Port 가 아니다 (`plan/03` §3 L2) — Port
        # 그래프에 들어가면 어떤 유스케이스가 평문을 만질 수 있는지
        # 추적할 수 없다.
        self._cipher = cipher

    async def enqueue(self, cmd: EnqueueWork) -> WorkItem:
        from ma_domain.errors import InvariantViolation

        try:
            row = await self._sql.fetch_one(
                Statement(
                    f"""
                    INSERT INTO environment_work
                      (id, workspace_id, environment_id, environment_version,
                       session_id, state, created_at, updated_at)
                    VALUES ($1,$2,$3,$4,$5,'queued',$6,$6)
                    RETURNING {_COLS}
                    """,  # noqa: S608 — _COLS 는 이 모듈의 상수 리터럴이다
                    (
                        cmd.id,
                        cmd.workspace_id,
                        cmd.environment_id,
                        cmd.environment_version,
                        cmd.session_id,
                        cmd.now,
                    ),
                )
            )
        except UniqueViolation as exc:
            # **세션 하나당 열린 일은 하나.** 메모리 구현과 **같은
            # 결과를 낸다** — 한쪽이 예외를 던지고 다른 쪽이 결과를
            # 돌려주면 호출자가 백엔드에 따라 다르게 동작한다.
            raise InvariantViolation(f"세션 {cmd.session_id} 에 이미 열린 일이 있다") from exc
        assert row is not None
        return _out(row)

    async def claim(self, cmd: ClaimWork) -> ClaimResult:
        """집고 generation 을 올린다. **한 문장으로.**

        `WHERE` 가 두 경우를 함께 본다:

        1. `queued` — 아직 아무도 안 집었다
        2. `claimed` 인데 하트비트가 끊겼다 — 회수한다

        `ORDER BY created_at` 으로 오래된 것부터, `SKIP LOCKED` 로
        다른 워커가 잡은 행은 건너뛴다.
        """
        cutoff = cmd.now - cmd.reclaim_after
        row = await self._sql.fetch_one(
            Statement(
                f"""
                WITH picked AS (
                  SELECT id FROM environment_work
                   WHERE workspace_id = $1
                     AND environment_id = $2
                     AND (
                       state = 'queued'
                       OR (
                         state = 'claimed'
                         AND attempts < $6
                         AND COALESCE(heartbeat_at, claimed_at) < $5::timestamptz
                       )
                     )
                   ORDER BY state <> 'queued', created_at, id
                   FOR UPDATE SKIP LOCKED
                   LIMIT 1
                )
                UPDATE environment_work w
                   SET state = 'claimed',
                       claim_generation = w.claim_generation + 1,
                       worker_id = $3,
                       attempts = w.attempts + 1,
                       claimed_at = $4,
                       heartbeat_at = $4,
                       updated_at = $4
                  FROM picked
                 WHERE w.workspace_id = $1 AND w.id = picked.id
             RETURNING {_W_COLS}
                """,  # noqa: S608 — _COLS 는 이 모듈의 상수 리터럴이다
                (
                    cmd.workspace_id,
                    cmd.environment_id,
                    cmd.worker_id,
                    cmd.now,
                    cutoff,
                    cmd.max_attempts,
                ),
            )
        )
        if row is None:
            # **회수 상한을 넘은 것들을 굳힌다.** 큐가 그 하나로
            # 막히면 다른 일이 영원히 안 돈다.
            await self._fail_exhausted(cmd, cutoff)
            return NoWork()

        item = _out(row)
        # **봉인은 집은 뒤에 한다.** aad 에 work id 가 들어가야 다른
        # 행의 암호문으로 바꿔치기할 수 없는데, 어느 행을 집을지는
        # 위 UPDATE 가 정하므로 그 전에는 id 를 모른다.
        final = self._cipher.seal(cmd.secret, aad=associated_data(cmd.workspace_id, item.id))
        await self._sql.execute(
            Statement(
                """
                UPDATE environment_work
                   SET secret_ciphertext = $3, secret_nonce = $4, secret_key_version = $5
                 WHERE workspace_id = $1 AND id = $2
                """,
                (
                    cmd.workspace_id,
                    item.id,
                    final.ciphertext,
                    final.nonce,
                    final.key_version,
                ),
            )
        )
        return ClaimedWork(item=item, secret=cmd.secret)

    async def _fail_exhausted(self, cmd: ClaimWork, cutoff: datetime) -> None:
        await self._sql.execute(
            Statement(
                """
                UPDATE environment_work
                   SET state = 'failed', acked_at = $3, updated_at = $3,
                       error = attempts || '회 회수 후 포기',
                       secret_ciphertext = NULL, secret_nonce = NULL
                 WHERE workspace_id = $1 AND environment_id = $2
                   AND state = 'claimed' AND attempts >= $5
                   AND COALESCE(heartbeat_at, claimed_at) < $4::timestamptz
                """,
                (cmd.workspace_id, cmd.environment_id, cmd.now, cutoff, cmd.max_attempts),
            )
        )

    async def heartbeat(self, cmd: Heartbeat) -> HeartbeatResult:
        row = await self._sql.fetch_one(
            Statement(
                f"""
                UPDATE environment_work
                   SET heartbeat_at = $5, updated_at = $5
                 WHERE workspace_id = $1 AND id = $2
                   AND worker_id = $3 AND claim_generation = $4
                   AND state = 'claimed'
             RETURNING {_COLS}
                """,  # noqa: S608 — _COLS 는 이 모듈의 상수 리터럴이다
                (cmd.workspace_id, cmd.work_id, cmd.worker_id, cmd.generation, cmd.now),
            )
        )
        if row is not None:
            return _out(row)
        return await self._why_not(cmd.workspace_id, cmd.work_id)

    async def ack(self, cmd: AckWork) -> AckResult:
        row = await self._sql.fetch_one(
            Statement(
                f"""
                UPDATE environment_work
                   SET state = $5,
                       acked_at = CASE WHEN $5 IN ('done','failed')
                                       THEN $6::timestamptz ELSE acked_at END,
                       error = $7,
                       updated_at = $6::timestamptz,
                       -- **시크릿을 버린다.** 1회용이고, 끝난 뒤에도
                       -- 남아 있으면 1회용이 아니다.
                       secret_ciphertext = NULL,
                       secret_nonce = NULL
                 WHERE workspace_id = $1 AND id = $2
                   AND worker_id = $3 AND claim_generation = $4
             RETURNING {_COLS}
                """,  # noqa: S608 — _COLS 는 이 모듈의 상수 리터럴이다
                (
                    cmd.workspace_id,
                    cmd.work_id,
                    cmd.worker_id,
                    cmd.generation,
                    cmd.state.value,
                    cmd.now,
                    cmd.error[:1000],
                ),
            )
        )
        if row is not None:
            return _out(row)
        return await self._why_not(cmd.workspace_id, cmd.work_id)

    async def _why_not(self, workspace_id: WorkspaceId, work_id: str) -> FenceLost | WorkGone:
        """**없는 것과 뺏긴 것을 구분한다.**

        워커 입장에서 둘의 대응이 다르다: 없으면 폴링으로 돌아가고,
        뺏겼으면 **진행 중인 일을 버려야 한다** — 새 워커가 이미 돌고 있다.
        """
        got = await self.find(workspace_id, work_id)
        if got is None:
            return WorkGone(work_id=work_id)
        return FenceLost(actual_generation=got.claim_generation)

    async def find(self, workspace_id: WorkspaceId, work_id: str) -> WorkItem | None:
        row = await self._sql.fetch_one(
            Statement(
                f"SELECT {_COLS} FROM environment_work WHERE workspace_id = $1 AND id = $2",  # noqa: S608
                (workspace_id, work_id),
            )
        )
        return _out(row) if row else None

    async def find_for_session(
        self, workspace_id: WorkspaceId, session_id: SessionId
    ) -> WorkItem | None:
        row = await self._sql.fetch_one(
            Statement(
                f"""
                SELECT {_COLS} FROM environment_work
                 WHERE workspace_id = $1 AND session_id = $2
                   AND state IN ('queued','claimed')
                 ORDER BY created_at, id LIMIT 1
                """,  # noqa: S608 — _COLS 는 이 모듈의 상수 리터럴이다
                (workspace_id, session_id),
            )
        )
        return _out(row) if row else None

    async def list_work(self, q: ListQuery, environment_id: EnvironmentId) -> Page[WorkItem]:
        after = q.after
        rows = await self._sql.fetch_all(
            Statement(
                f"""
                SELECT {_COLS} FROM environment_work
                 WHERE workspace_id = $1 AND environment_id = $2
                   AND ($3::timestamptz IS NULL OR (created_at, id) > ($3, $4))
                 ORDER BY created_at, id
                 LIMIT $5
                """,  # noqa: S608 — _COLS 는 이 모듈의 상수 리터럴이다
                (
                    q.workspace_id,
                    environment_id,
                    after.created_at if after else None,
                    after.id if after else None,
                    q.limit + 1,
                ),
            )
        )
        items = [_out(r) for r in rows[: q.limit]]
        more = len(rows) > q.limit
        return Page(
            items=tuple(items),
            next_cursor=(
                Cursor(created_at=items[-1].created_at, id=items[-1].id) if more and items else None
            ),
        )

    async def stats(
        self, workspace_id: WorkspaceId, environment_id: EnvironmentId, now: datetime
    ) -> WorkStats:
        rows = await self._sql.fetch_all(
            Statement(
                """
                SELECT state, count(*) AS n, min(created_at) AS oldest
                  FROM environment_work
                 WHERE workspace_id = $1 AND environment_id = $2
                 GROUP BY state
                """,
                (workspace_id, environment_id),
            )
        )
        counts = {str(r["state"]): int(r["n"]) for r in rows}
        oldest = next(
            (r["oldest"] for r in rows if str(r["state"]) == WorkState.QUEUED.value), None
        )
        return WorkStats(
            environment_id=environment_id,
            queued=counts.get("queued", 0),
            claimed=counts.get("claimed", 0),
            done=counts.get("done", 0),
            failed=counts.get("failed", 0),
            expired=counts.get("expired", 0),
            oldest_queued_seconds=int((now - oldest).total_seconds()) if oldest else 0,
        )

    async def reclaim_stale(
        self, now: datetime, *, ttl: timedelta = DEFAULT_LEASE_TTL, limit: int = 100
    ) -> tuple[WorkItem, ...]:
        """**워크스페이스를 가로지른다.** 스케줄러가 부르고, 스케줄러는
        모든 워크스페이스를 본다."""
        rows = await self._sql.fetch_all(
            Statement(
                f"""
                WITH stale AS (
                  SELECT workspace_id, id FROM environment_work
                   WHERE state = 'claimed'
                     AND COALESCE(heartbeat_at, claimed_at) < $1::timestamptz
                   ORDER BY heartbeat_at NULLS FIRST
                   FOR UPDATE SKIP LOCKED
                   LIMIT $3
                )
                UPDATE environment_work w
                   SET state = 'queued', worker_id = NULL, claimed_at = NULL,
                       heartbeat_at = NULL, updated_at = $2,
                       -- 회수했으면 그 시크릿은 **죽은 것이다.**
                       secret_ciphertext = NULL, secret_nonce = NULL
                  FROM stale
                 WHERE w.workspace_id = stale.workspace_id AND w.id = stale.id
             RETURNING {_W_COLS}
                """,  # noqa: S608 — _COLS 는 이 모듈의 상수 리터럴이다
                (now - ttl, now, limit),
            )
        )
        return tuple(_out(r) for r in rows)


__all__ = ["MAX_ATTEMPTS", "SqlEnvironmentWorkStore"]
