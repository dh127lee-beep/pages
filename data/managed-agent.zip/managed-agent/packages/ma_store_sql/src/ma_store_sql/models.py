"""SqlModelCardStore — 모델을 설정으로 만드는 저장소 (D12).

`plan/06-harness-and-model.md` §1 · `plan/05-database.md` §3 G2b.

`reasoning`·`pricing`·`defaults` 가 JSONB 인 이유는 **provider 마다 모양이 다르고
앞으로 더 달라지기 때문**이다. 컬럼으로 펴면 새 provider 가 올 때마다
마이그레이션이 필요해지고, 그러면 "모델 교체가 릴리스"라는 D12 가 막으려던
상황으로 돌아간다.
"""

from __future__ import annotations

import json
from collections.abc import Mapping
from datetime import datetime
from decimal import Decimal

from ma_domain.ids import CredentialId, ModelCardId, WorkspaceId
from ma_domain.models import (
    EffortIntent,
    ModelCard,
    PeakWindow,
    PricingSpec,
    ProviderKind,
    ReasoningSpec,
)
from ma_sql.ports import Row, SqlClient, Statement
from ma_store._results import Cursor, ListQuery, Page
from ma_store.models import UpsertModelCard

_COLS = (
    "id, workspace_id, provider, wire_model, base_url, credential_id, "
    "max_input_tokens, max_output_tokens, supports_tools, supports_vision, "
    "supports_prompt_cache, reasoning, pricing, off_peak_preferred, defaults, "
    "enabled, created_at, updated_at, archived_at"
)


def _seq(raw: object) -> list[object]:
    """jsonb 배열을 안전하게 꺼낸다. 아니면 빈 리스트."""
    return list(raw) if isinstance(raw, list | tuple) else []


def _obj(raw: object) -> dict[str, object]:
    if raw is None:
        return {}
    if isinstance(raw, str):
        loaded: dict[str, object] = json.loads(raw)
        return loaded
    if isinstance(raw, dict):
        return dict(raw)
    return {}  # pragma: no cover


def _reasoning_in(spec: ReasoningSpec | None) -> str | None:
    if spec is None:
        return None
    return json.dumps(
        {
            "param": spec.param,
            "style": spec.style,
            "levels": list(spec.levels),
            "mapping": [[e.value, w] for e, w in spec.mapping],
        }
    )


def _reasoning_out(raw: object) -> ReasoningSpec | None:
    d = _obj(raw)
    if not d:
        return None
    raw_mapping = d.get("mapping")
    mapping: list[object] = raw_mapping if isinstance(raw_mapping, list) else []
    pairs = tuple(
        (EffortIntent(str(m[0])), str(m[1]))
        for m in mapping
        if isinstance(m, list | tuple) and len(m) == 2
    )
    style = d.get("style")
    return ReasoningSpec(
        param=str(d["param"]),
        style="object" if style == "object" else "enum",
        levels=tuple(str(x) for x in _seq(d.get("levels"))),
        mapping=pairs,
    )


def _pricing_in(p: PricingSpec) -> str:
    return json.dumps(
        {
            "currency": p.currency,
            "unit_tokens": p.unit_tokens,
            # Decimal 을 **문자열로** 싣는다. float 로 가면 요금에 오차가 생긴다.
            "input_cache_miss": str(p.input_cache_miss),
            "input_cache_hit": str(p.input_cache_hit),
            "output": str(p.output),
            "off_peak_multiplier": str(p.off_peak_multiplier),
            "peak_windows": [
                {
                    "start_hour_utc": w.start_hour_utc,
                    "end_hour_utc": w.end_hour_utc,
                    "weekdays": list(w.weekdays),
                }
                for w in p.peak_windows
            ],
        }
    )


def _pricing_out(raw: object) -> PricingSpec:
    d = _obj(raw)
    windows = tuple(
        PeakWindow(
            start_hour_utc=int(str(w["start_hour_utc"])),
            end_hour_utc=int(str(w["end_hour_utc"])),
            weekdays=tuple(int(str(x)) for x in _seq(w.get("weekdays"))) or (0, 1, 2, 3, 4),
        )
        for w in _seq(d.get("peak_windows"))
        if isinstance(w, Mapping)
    )
    return PricingSpec(
        currency=str(d.get("currency", "USD")),
        unit_tokens=int(str(d.get("unit_tokens", 1_000_000))),
        input_cache_miss=Decimal(str(d.get("input_cache_miss", "0"))),
        input_cache_hit=Decimal(str(d.get("input_cache_hit", "0"))),
        output=Decimal(str(d.get("output", "0"))),
        off_peak_multiplier=Decimal(str(d.get("off_peak_multiplier", "1"))),
        peak_windows=windows,
    )


def _to_card(row: Row) -> ModelCard:
    defaults = _obj(row["defaults"])
    return ModelCard(
        id=ModelCardId(row["id"]),
        workspace_id=WorkspaceId(row["workspace_id"]),
        provider=ProviderKind(row["provider"]),
        wire_model=row["wire_model"],
        base_url=row["base_url"],
        credential_id=CredentialId(row["credential_id"]) if row["credential_id"] else None,
        max_input_tokens=row["max_input_tokens"],
        max_output_tokens=row["max_output_tokens"],
        supports_tools=row["supports_tools"],
        supports_vision=row["supports_vision"],
        supports_prompt_cache=row["supports_prompt_cache"],
        reasoning=_reasoning_out(row["reasoning"]),
        pricing=_pricing_out(row["pricing"]),
        off_peak_preferred=row["off_peak_preferred"],
        defaults=tuple(
            (k, v) for k, v in defaults.items() if isinstance(v, str | int | float | bool)
        ),
        enabled=row["enabled"] and row["archived_at"] is None,
    )


class SqlModelCardStore:
    def __init__(self, sql: SqlClient) -> None:
        self._sql = sql

    async def upsert(self, cmd: UpsertModelCard) -> ModelCard:
        c = cmd.card
        row = await self._sql.fetch_one(
            Statement(
                f"""
                INSERT INTO model_cards
                  (id, workspace_id, provider, wire_model, base_url, credential_id,
                   max_input_tokens, max_output_tokens, supports_tools, supports_vision,
                   supports_prompt_cache, reasoning, pricing, off_peak_preferred,
                   defaults, enabled, created_at, updated_at)
                VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12::jsonb,$13::jsonb,$14,
                        $15::jsonb,$16,$17,$17)
                ON CONFLICT (workspace_id, id) DO UPDATE SET
                  provider = EXCLUDED.provider,
                  wire_model = EXCLUDED.wire_model,
                  base_url = EXCLUDED.base_url,
                  credential_id = EXCLUDED.credential_id,
                  max_input_tokens = EXCLUDED.max_input_tokens,
                  max_output_tokens = EXCLUDED.max_output_tokens,
                  supports_tools = EXCLUDED.supports_tools,
                  supports_vision = EXCLUDED.supports_vision,
                  supports_prompt_cache = EXCLUDED.supports_prompt_cache,
                  reasoning = EXCLUDED.reasoning,
                  pricing = EXCLUDED.pricing,
                  off_peak_preferred = EXCLUDED.off_peak_preferred,
                  defaults = EXCLUDED.defaults,
                  enabled = EXCLUDED.enabled,
                  updated_at = EXCLUDED.updated_at
                RETURNING {_COLS}
                """,  # noqa: S608 — _COLS 는 이 모듈의 상수 리터럴이다
                (
                    c.id,
                    c.workspace_id,
                    c.provider.value,
                    c.wire_model,
                    c.base_url,
                    c.credential_id,
                    c.max_input_tokens,
                    c.max_output_tokens,
                    c.supports_tools,
                    c.supports_vision,
                    c.supports_prompt_cache,
                    _reasoning_in(c.reasoning),
                    _pricing_in(c.pricing),
                    c.off_peak_preferred,
                    json.dumps(dict(c.defaults)),
                    c.enabled,
                    cmd.now,
                ),
            )
        )
        if row is None:  # pragma: no cover
            raise RuntimeError("upsert 가 행을 돌려주지 않았다")
        return _to_card(row)

    async def find(self, workspace_id: WorkspaceId, card_id: ModelCardId) -> ModelCard | None:
        row = await self._sql.fetch_one(
            Statement(
                f"SELECT {_COLS} FROM model_cards "  # noqa: S608
                "WHERE workspace_id = $1 AND id = $2",
                (workspace_id, card_id),
            )
        )
        return _to_card(row) if row else None

    async def list_enabled(self, q: ListQuery) -> Page[ModelCard]:
        args: list[object] = [q.workspace_id]
        where = "workspace_id = $1 AND enabled AND archived_at IS NULL"
        if isinstance(q.after, Cursor):
            args += [q.after.id]
            where += f" AND id > ${len(args)}"
        args.append(q.limit + 1)
        rows = await self._sql.fetch_all(
            Statement(
                f"SELECT {_COLS} FROM model_cards WHERE {where} "  # noqa: S608
                f"ORDER BY id LIMIT ${len(args)}",
                tuple(args),
            )
        )
        items = [_to_card(r) for r in rows[: q.limit]]
        nxt = (
            Cursor(rows[q.limit - 1]["created_at"], items[-1].id)
            if len(rows) > q.limit and items
            else None
        )
        return Page(items=tuple(items), next_cursor=nxt)

    async def archive(self, workspace_id: WorkspaceId, card_id: ModelCardId, now: datetime) -> bool:
        """카드를 끈다. **지우지 않는다** — 과거 세션이 이 카드를 참조한다.

        지우면 "그 세션이 어떤 모델로 돌았는가"를 영영 답할 수 없다.
        """
        res = await self._sql.execute(
            Statement(
                "UPDATE model_cards SET archived_at = $3, enabled = FALSE, updated_at = $3 "
                "WHERE workspace_id = $1 AND id = $2 AND archived_at IS NULL",
                (workspace_id, card_id, now),
            )
        )
        return res.rows_affected == 1


__all__ = ["SqlModelCardStore"]
