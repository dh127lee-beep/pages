"""SqlSessionStore — 세션은 `revision`으로 CAS한다.

`plan/02-architecture.md` §3 규칙 1 · `plan/05-database.md` §3 G4.

`revision` 증가는 **이벤트 수용 트랜잭션의 첫 문장**이다. 여기서 지면 pending 도
outbox 도 생기지 않는다 (`SqlSessionEventStore.admit`).
"""

from __future__ import annotations

import json
from datetime import datetime

from ma_domain.ids import (
    AgentId,
    EnvironmentId,
    ModelCardId,
    SessionId,
    VaultId,
    WorkspaceId,
)
from ma_domain.models import EffortIntent, TokenUsage
from ma_domain.sessions import (
    ConfigOverride,
    RequiredAction,
    SessionBudget,
    SessionRecord,
    SessionStatus,
    StopReason,
)
from ma_sql.ports import Row, SqlClient, Statement
from ma_store._results import Cursor, NotFound, Page, VersionConflict
from ma_store.sessions import (
    AccrueSessionUsage,
    FindSession,
    InsertSession,
    ListSessions,
    SessionUpdateResult,
    UpdatedSession,
    UpdateSessionStatus,
)

_COLS = (
    "id, workspace_id, agent_id, agent_version, environment_id, environment_version, "
    "config_override, status, stop_reason, required_action, revision, budget_cents, "
    "spent_cents, usage, vault_ids, created_by, created_at, updated_at, "
    "last_active_at, archived_at, deleted_at"
)


def _json_out(raw: object) -> dict[str, object]:
    """jsonb 는 드라이버에 따라 str 로도 dict 로도 온다."""
    if raw is None:
        return {}
    if isinstance(raw, str):
        loaded: dict[str, object] = json.loads(raw)
        return loaded
    if isinstance(raw, dict):
        return dict(raw)
    return {}  # pragma: no cover — jsonb 는 둘 중 하나다


def _to_override(raw: dict[str, object] | None) -> ConfigOverride | None:
    if not raw:
        return None
    effort = raw.get("effort")
    return ConfigOverride(
        model=ModelCardId(str(raw["model"])) if raw.get("model") else None,
        system=str(raw["system"]) if raw.get("system") else None,
        effort=EffortIntent(str(effort)) if effort else None,
    )


def _to_usage(raw: dict[str, object]) -> TokenUsage:
    def n(key: str) -> int:
        v = raw.get(key, 0)
        return int(v) if isinstance(v, int | float | str) else 0

    return TokenUsage(
        input_cache_hit=n("input_cache_hit"),
        input_cache_miss=n("input_cache_miss"),
        output=n("output"),
    )


def _to_record(row: Row) -> SessionRecord:
    usage = _json_out(row["usage"])
    override = _json_out(row["config_override"]) if row["config_override"] else None
    return SessionRecord(
        id=SessionId(row["id"]),
        workspace_id=WorkspaceId(row["workspace_id"]),
        agent_id=AgentId(row["agent_id"]),
        agent_version=row["agent_version"],
        environment_id=EnvironmentId(row["environment_id"]),
        environment_version=row["environment_version"],
        status=SessionStatus(row["status"]),
        revision=row["revision"],
        created_by=row["created_by"],
        created_at=row["created_at"],
        updated_at=row["updated_at"],
        stop_reason=StopReason(row["stop_reason"]) if row["stop_reason"] else None,
        required_action=(
            RequiredAction(row["required_action"]) if row["required_action"] else None
        ),
        config_override=_to_override(override),
        budget=(
            SessionBudget(limit_cents=row["budget_cents"], spent_cents=row["spent_cents"])
            if row["budget_cents"] is not None
            else None
        ),
        usage=_to_usage(usage),
        vault_ids=tuple(VaultId(v) for v in (row["vault_ids"] or ())),
        last_active_at=row["last_active_at"],
        archived_at=row["archived_at"],
        deleted_at=row["deleted_at"],
    )


def _override_in(o: ConfigOverride | None) -> str | None:
    if o is None:
        return None
    return json.dumps(
        {
            k: v
            for k, v in (
                ("model", o.model),
                ("system", o.system),
                ("effort", o.effort.value if o.effort else None),
            )
            if v is not None
        }
    )


class SqlSessionStore:
    def __init__(self, sql: SqlClient) -> None:
        self._sql = sql

    async def insert(self, cmd: InsertSession) -> SessionRecord:
        r = cmd.record
        row = await self._sql.fetch_one(
            Statement(
                f"""
                INSERT INTO sessions
                  (id, workspace_id, agent_id, agent_version, environment_id,
                   environment_version, config_override, status, revision,
                   budget_cents, spent_cents, usage, vault_ids, created_by,
                   created_at, updated_at)
                VALUES ($1,$2,$3,$4,$5,$6,$7::jsonb,$8,$9,$10,$11,$12::jsonb,$13,$14,$15,$16)
                RETURNING {_COLS}
                """,  # noqa: S608 — _COLS 는 이 모듈의 상수 리터럴이다
                (
                    r.id,
                    r.workspace_id,
                    r.agent_id,
                    r.agent_version,
                    r.environment_id,
                    r.environment_version,
                    _override_in(r.config_override),
                    r.status.value,
                    r.revision,
                    r.budget.limit_cents if r.budget else None,
                    r.budget.spent_cents if r.budget else 0,
                    json.dumps({}),
                    list(r.vault_ids),
                    r.created_by,
                    r.created_at,
                    r.updated_at,
                ),
            )
        )
        if row is None:  # pragma: no cover
            raise RuntimeError("insert 가 행을 돌려주지 않았다")
        return _to_record(row)

    async def find(self, q: FindSession) -> SessionRecord | None:
        row = await self._sql.fetch_one(
            Statement(
                f"SELECT {_COLS} FROM sessions "  # noqa: S608
                "WHERE workspace_id = $1 AND id = $2 AND ($3 OR deleted_at IS NULL)",
                (q.workspace_id, q.id, q.include_deleted),
            )
        )
        return _to_record(row) if row else None

    async def update_status(self, cmd: UpdateSessionStatus) -> SessionUpdateResult:
        args: list[object] = [
            cmd.workspace_id,
            cmd.id,
            cmd.status.value,
            cmd.stop_reason.value if cmd.stop_reason else None,
            cmd.required_action.value if cmd.required_action else None,
            cmd.now,
        ]
        cas = ""
        if cmd.expected_revision is not None:
            args.append(cmd.expected_revision)
            cas = f" AND revision = ${len(args)}"
        row = await self._sql.fetch_one(
            Statement(
                f"""
                UPDATE sessions
                   SET status = $3, stop_reason = $4, required_action = $5,
                       revision = revision + 1, updated_at = $6, last_active_at = $6
                 WHERE workspace_id = $1 AND id = $2 AND deleted_at IS NULL{cas}
                RETURNING {_COLS}
                """,  # noqa: S608 — cas 는 이 함수 안의 리터럴이다
                tuple(args),
            )
        )
        if row is not None:
            return UpdatedSession(record=_to_record(row))
        return await self._miss(cmd.workspace_id, cmd.id)

    async def accrue_usage(self, cmd: AccrueSessionUsage) -> SessionUpdateResult:
        """사용량은 **누적**이다. CAS 하지 않는다 — 두 lane 이 동시에 써도 더해져야 한다."""
        row = await self._sql.fetch_one(
            Statement(
                f"""
                UPDATE sessions
                   SET spent_cents = spent_cents + $3,
                       -- 토큰도 **누적**이다. 덮어쓰면 턴 하나의 숫자만 남고
                       -- 세션 전체 비용을 잃는다.
                       usage = jsonb_build_object(
                         'input_cache_hit',
                           coalesce((usage->>'input_cache_hit')::bigint, 0) + $4::bigint,
                         'input_cache_miss',
                           coalesce((usage->>'input_cache_miss')::bigint, 0) + $5::bigint,
                         'output',
                           coalesce((usage->>'output')::bigint, 0) + $6::bigint
                       ),
                       updated_at = $7, last_active_at = $7
                 WHERE workspace_id = $1 AND id = $2 AND deleted_at IS NULL
                RETURNING {_COLS}
                """,  # noqa: S608 — _COLS 는 이 모듈의 상수 리터럴이다
                (
                    cmd.workspace_id,
                    cmd.id,
                    cmd.cost_cents,
                    # 캐시 히트·미스를 **분리해 둔다** — 합치면 `plan/06` §5 의
                    # 가장 큰 비용 지렛대를 측정할 수 없다.
                    cmd.usage.input_cache_hit,
                    cmd.usage.input_cache_miss,
                    cmd.usage.output,
                    cmd.now,
                ),
            )
        )
        if row is not None:
            return UpdatedSession(record=_to_record(row))
        return await self._miss(cmd.workspace_id, cmd.id)

    async def archive(
        self, workspace_id: WorkspaceId, session_id: SessionId, now: datetime
    ) -> SessionUpdateResult:
        row = await self._sql.fetch_one(
            Statement(
                f"""
                UPDATE sessions SET archived_at = $3, updated_at = $3
                 WHERE workspace_id = $1 AND id = $2 AND deleted_at IS NULL
                RETURNING {_COLS}
                """,  # noqa: S608 — _COLS 는 이 모듈의 상수 리터럴이다
                (workspace_id, session_id, now),
            )
        )
        if row is not None:
            return UpdatedSession(record=_to_record(row))
        return await self._miss(workspace_id, session_id)

    async def delete(self, workspace_id: WorkspaceId, session_id: SessionId, now: datetime) -> bool:
        res = await self._sql.execute(
            Statement(
                "UPDATE sessions SET deleted_at = $3, updated_at = $3 "
                "WHERE workspace_id = $1 AND id = $2 AND deleted_at IS NULL",
                (workspace_id, session_id, now),
            )
        )
        return res.rows_affected == 1

    async def list_sessions(self, q: ListSessions) -> Page[SessionRecord]:
        args: list[object] = [q.workspace_id]
        where = "workspace_id = $1 AND deleted_at IS NULL"
        if q.status is not None:
            args.append(q.status.value)
            where += f" AND status = ${len(args)}"
        if q.agent_id is not None:
            args.append(q.agent_id)
            where += f" AND agent_id = ${len(args)}"
        if q.created_by is not None:
            args.append(q.created_by)
            where += f" AND created_by = ${len(args)}"
        if q.created_at_gte is not None:
            args.append(q.created_at_gte)
            where += f" AND created_at >= ${len(args)}"
        if q.created_at_lte is not None:
            args.append(q.created_at_lte)
            where += f" AND created_at <= ${len(args)}"
        if isinstance(q.after, Cursor):
            args += [q.after.created_at, q.after.id]
            where += f" AND (created_at, id) > (${len(args) - 1}, ${len(args)})"
        args.append(q.limit + 1)
        rows = await self._sql.fetch_all(
            Statement(
                f"SELECT {_COLS} FROM sessions WHERE {where} "  # noqa: S608
                f"ORDER BY created_at, id LIMIT ${len(args)}",
                tuple(args),
            )
        )
        items = [_to_record(r) for r in rows[: q.limit]]
        nxt = Cursor(items[-1].created_at, items[-1].id) if len(rows) > q.limit and items else None
        return Page(items=tuple(items), next_cursor=nxt)

    async def _miss(self, workspace_id: WorkspaceId, session_id: SessionId) -> SessionUpdateResult:
        row = await self._sql.fetch_one(
            Statement(
                "SELECT revision FROM sessions "
                "WHERE workspace_id = $1 AND id = $2 AND deleted_at IS NULL",
                (workspace_id, session_id),
            )
        )
        if row is None:
            return NotFound()
        return VersionConflict(actual_version=int(row["revision"]))


__all__ = ["SqlSessionStore"]
