"""SQL 이벤트 저장소 — 이중 테이블과 순서 불변식 (D4).

`plan/02-architecture.md` §4 · `plan/05-database.md` §3 G5 · `ADR-0004`.

**`seq`는 promote 시점에 부여된다.** 도착 시점이 아니다. 그래야 `ORDER BY seq`가
"모델이 본 순서"와 같아진다 — 에이전트가 스트리밍하는 중에 들어온 사용자 입력이
이전 턴 중간에 꽂히지 않는다.

`seq`는 시퀀스 객체가 아니라 **트랜잭션 안 MAX+1**이다. 시퀀스는 롤백 때 구멍이
생기는데 replay는 구멍 없는 `seq`를 전제한다. 대신 같은 세션의 lane 둘이 동시에
쓰면 같은 `seq`를 계산하므로, 세션 단위 **advisory lock**으로 직렬화한다
(`ADR-0004`에 경합 비용과 대안을 적었다).

promote는 **peek → INSERT → DELETE** 순서다. 여기서는 셋을 한 트랜잭션에 묶을 수
있으므로 보통은 원자적이지만, 그래도 `idx_events_event_id` 유니크와 멱등 복구
경로를 유지한다 — 둘이 갈라지는 경우(배치 드레인, 재시도, 커밋 결과 불확실)가
남고, 그때는 **유실보다 중복이 낫다**. 중복은 DB가 막을 수 있지만 유실은
아무도 되돌릴 수 없다.
"""

from __future__ import annotations

import json
from datetime import datetime

from ma_domain.events import EventType, PendingEvent, SessionEvent
from ma_domain.ids import EventId, SessionId, ThreadId, WorkspaceId
from ma_sql.errors import UniqueViolation
from ma_sql.ports import Row, SqlClient, Statement
from ma_store._results import NotFound, VersionConflict
from ma_store.events import AdmitEvents, AdmitResult, Admitted, PromoteEvent, ReadEvents

_EVENT_COLS = "workspace_id, session_id, seq, id, thread_id, type, payload, generation, created_at"
_PENDING_COLS = (
    "workspace_id, session_id, pending_seq, id, thread_id, type, payload, enqueued_at, cancelled_at"
)

#: 세션 단위 seq 직렬화. 트랜잭션이 끝나면 자동으로 풀린다.
_SEQ_LOCK = Statement(
    "SELECT pg_advisory_xact_lock(hashtextextended($1 || '/' || $2, 0))",
    (),
)


def _seq_lock(workspace_id: WorkspaceId, session_id: SessionId) -> Statement:
    return Statement(_SEQ_LOCK.sql, (workspace_id, session_id))


def _payload_in(payload: tuple[tuple[str, object], ...]) -> str:
    return json.dumps(dict(payload))


def _payload_out(raw: object) -> tuple[tuple[str, object], ...]:
    """jsonb 는 드라이버에 따라 str 로도 dict 로도 온다. 둘 다 받는다."""
    if raw is None:
        return ()
    parsed: dict[str, object] = json.loads(raw) if isinstance(raw, str) else dict(raw)  # type: ignore[call-overload]
    return tuple(parsed.items())


def _to_event(row: Row) -> SessionEvent:
    return SessionEvent(
        id=EventId(row["id"]),
        workspace_id=WorkspaceId(row["workspace_id"]),
        session_id=SessionId(row["session_id"]),
        thread_id=ThreadId(row["thread_id"]),
        type=EventType(row["type"]),
        payload=_payload_out(row["payload"]),
        created_at=row["created_at"],
        seq=row["seq"],
        generation=row["generation"],
    )


def _to_pending(row: Row) -> PendingEvent:
    return PendingEvent(
        id=EventId(row["id"]),
        workspace_id=WorkspaceId(row["workspace_id"]),
        session_id=SessionId(row["session_id"]),
        thread_id=ThreadId(row["thread_id"]),
        type=EventType(row["type"]),
        payload=_payload_out(row["payload"]),
        enqueued_at=row["enqueued_at"],
        pending_seq=row["pending_seq"],
        cancelled_at=row["cancelled_at"],
    )


_APPEND_SQL = f"""
    INSERT INTO session_events ({_EVENT_COLS})
    SELECT $1, $2,
           coalesce((SELECT max(seq) FROM session_events
                      WHERE workspace_id = $1 AND session_id = $2), -1) + 1,
           $3, $4, $5, $6::jsonb, $7, $8
    RETURNING {_EVENT_COLS}
"""  # noqa: S608 — _EVENT_COLS 는 이 모듈의 상수 리터럴이다

_PROMOTE_SQL = f"""
    WITH src AS (
        SELECT * FROM session_pending_events
         WHERE workspace_id = $1 AND session_id = $2 AND id = $3
           AND cancelled_at IS NULL
    )
    INSERT INTO session_events ({_EVENT_COLS})
    SELECT s.workspace_id, s.session_id,
           coalesce((SELECT max(e.seq) FROM session_events e
                      WHERE e.workspace_id = $1 AND e.session_id = $2), -1) + 1,
           s.id, s.thread_id, s.type, s.payload, $4, $5
      FROM src s
    RETURNING {_EVENT_COLS}
"""  # noqa: S608 — _EVENT_COLS 는 이 모듈의 상수 리터럴이다

_DELETE_PENDING_SQL = (
    "DELETE FROM session_pending_events WHERE workspace_id = $1 AND session_id = $2 AND id = $3"
)


class SqlSessionEventStore:
    """`session_events` — 정본 로그. append-only."""

    def __init__(self, sql: SqlClient) -> None:
        self._sql = sql

    async def append(self, event: SessionEvent, *, generation: int) -> SessionEvent:
        """에이전트가 낸 이벤트를 바로 로그에 넣는다 (pending을 거치지 않는다)."""
        args = (
            event.workspace_id,
            event.session_id,
            event.id,
            event.thread_id,
            event.type.value,
            _payload_in(event.payload),
            generation,
            event.created_at,
        )
        async with self._sql.transaction() as tx:
            await tx.execute(_seq_lock(event.workspace_id, event.session_id))
            row = await tx.fetch_one(Statement(_APPEND_SQL, args))
            if row is None:  # pragma: no cover — INSERT … RETURNING 은 항상 돌려준다
                raise RuntimeError("append 가 행을 돌려주지 않았다")
            return _to_event(row)

    async def promote(self, cmd: PromoteEvent) -> SessionEvent | None:
        """pending 하나를 정본으로 올린다.

        취소된 pending(`cancelled_at`)은 올리지 않는다 — 인터럽트로 접힌 입력을
        모델이 보면 안 된다. pending에 없어도 `None`이다.

        **이미 올라가 있으면** (INSERT 는 커밋됐는데 DELETE 가 안 된 상태) 중복을
        만들지 않고 뒷정리만 하고 기존 행을 돌려준다. 크래시 후 재실행이 정확히
        이 경로를 탄다 — 멱등성의 전부가 여기에 있다.
        """
        args = (cmd.workspace_id, cmd.session_id, cmd.event_id, cmd.generation, cmd.now)
        missed = False
        try:
            async with self._sql.transaction() as tx:
                await tx.execute(_seq_lock(cmd.workspace_id, cmd.session_id))
                row = await tx.fetch_one(Statement(_PROMOTE_SQL, args))
                if row is None:
                    # pending 에 없다 — 취소됐거나, 모르는 id 거나, **이미 올라갔다**.
                    # 셋을 가르는 것은 트랜잭션 밖에서 한다.
                    missed = True
                else:
                    await tx.execute(
                        Statement(
                            _DELETE_PENDING_SQL,
                            (cmd.workspace_id, cmd.session_id, cmd.event_id),
                        )
                    )
                    return _to_event(row)
        except UniqueViolation:
            # INSERT 는 커밋됐는데 DELETE 가 안 된 상태였다. 트랜잭션은 롤백됐으니
            # 새 트랜잭션에서 뒷정리만 한다.
            missed = True

        if not missed:  # pragma: no cover — 위 분기가 전부다
            return None

        # pending 에서 못 집은 이유는 셋 중 하나다. **정본 로그가 가른다.**
        already = await self.find_by_id(cmd.workspace_id, cmd.session_id, cmd.event_id)
        if already is None:
            # 취소됐거나 모르는 id 다. pending 행은 **건드리지 않는다** —
            # 취소 흔적(`cancelled_at`)은 감사가 읽어야 한다.
            return None

        # 이미 올라가 있다 (INSERT 커밋 후 DELETE 전에 죽었던 것). 뒷정리만 한다.
        await self._sql.execute(
            Statement(_DELETE_PENDING_SQL, (cmd.workspace_id, cmd.session_id, cmd.event_id))
        )
        return already

    async def admit(self, cmd: AdmitEvents) -> AdmitResult:
        """입력 수용 — **한 트랜잭션**이다 (`plan/02-architecture.md` §3 규칙 1).

        네 가지가 같이 일어나거나 같이 안 일어난다:

        1. `sessions.revision` CAS
        2. 인터럽트 대상 lane 의 진행 중 execution 에 플래그 + **그때까지 쌓인**
           pending 취소
        3. pending INSERT (`id` 유니크로 멱등)
        4. outbox INSERT (`execution_id` 유니크로 멱등)

        2가 3보다 **먼저**다. 인터럽트는 "지금까지 들어온 것을 접어라"이지
        "이 요청 전체를 버려라"가 아니다. 순서를 뒤집으면 인터럽트와 같은
        요청에 실려 온 새 메시지(흔한 조합이다)까지 같이 접힌다.

        쪼개지면 **"실행은 예약됐는데 이벤트가 없는"** 상태가 생긴다. 워커가
        깨어나서 할 일을 찾지 못하고, 사용자는 보낸 메시지가 사라진 것을 본다.
        경합에서 진 쪽은 **아무 행도 남기지 않아야** 한다.
        """
        now = cmd.now or (cmd.events[0].enqueued_at if cmd.events else None)
        if now is None:
            raise ValueError("admit 에는 now 가 필요하다")

        async with self._sql.transaction() as tx:
            # 1. revision CAS. 여기서 지면 아래 어느 것도 일어나지 않는다.
            cas = await tx.fetch_one(
                Statement(
                    """
                    UPDATE sessions SET revision = revision + 1, updated_at = $4,
                           last_active_at = $4
                     WHERE workspace_id = $1 AND id = $2 AND revision = $3
                       AND deleted_at IS NULL
                    RETURNING revision
                    """,
                    (cmd.workspace_id, cmd.session_id, cmd.expected_revision, now),
                )
            )
            if cas is None:
                return await self._admit_miss(cmd)

            # 2. 인터럽트 — 실행을 새로 만들지 않는다. 진행 중인 것에 플래그만.
            #    **이 요청의 이벤트를 넣기 전에** 한다. 그러지 않으면 인터럽트
            #    자신과 같은 요청에 실려 온 새 메시지까지 접힌다.
            for lane in cmd.interrupt_lanes:
                await tx.execute(
                    Statement(
                        """
                        UPDATE session_executions SET interrupt_requested_at = $4
                         WHERE workspace_id = $1 AND session_id = $2 AND lane_id = $3
                           AND state IN ('queued', 'running')
                           AND interrupt_requested_at IS NULL
                        """,
                        (cmd.workspace_id, cmd.session_id, lane, now),
                    )
                )
                # 아직 모델이 보지 않은 입력을 접는다 (지우지 않고 표시 — IMPL-0007)
                await tx.execute(
                    Statement(
                        """
                        UPDATE session_pending_events SET cancelled_at = $4
                         WHERE workspace_id = $1 AND session_id = $2 AND thread_id = $3
                           AND cancelled_at IS NULL
                        """,
                        (cmd.workspace_id, cmd.session_id, lane, now),
                    )
                )

            # 3. pending INSERT — 멱등. **인터럽트 뒤에 와야 한다.**
            for e in cmd.events:
                await tx.execute(
                    Statement(
                        """
                        INSERT INTO session_pending_events
                          (workspace_id, session_id, id, thread_id, type, payload, enqueued_at)
                        VALUES ($1, $2, $3, $4, $5, $6::jsonb, $7)
                        ON CONFLICT (workspace_id, session_id, id) DO NOTHING
                        """,
                        (
                            cmd.workspace_id,
                            cmd.session_id,
                            e.id,
                            e.thread_id,
                            e.type.value,
                            _payload_in(e.payload),
                            e.enqueued_at,
                        ),
                    )
                )

            # 4. outbox — lane 하나당 실행 하나. `execution_id` 가 멱등키다.
            for lane, execution_id, event_ids in cmd.lane_batches:
                await tx.execute(
                    Statement(
                        """
                        INSERT INTO session_executions
                          (workspace_id, session_id, lane_id, execution_id, state,
                           event_ids, generation, attempt_count, created_at,
                           trace_context)
                        VALUES ($1, $2, $3, $4, 'queued', $5, 0, 0, $6, $7)
                        ON CONFLICT (workspace_id, session_id, execution_id) DO NOTHING
                        """,
                        (
                            cmd.workspace_id,
                            cmd.session_id,
                            lane,
                            execution_id,
                            list(event_ids),
                            now,
                            json.dumps(dict(cmd.trace_context)) if cmd.trace_context else None,
                        ),
                    )
                )

            return Admitted(accepted=tuple(e.id for e in cmd.events), revision=int(cas["revision"]))

    async def _admit_miss(self, cmd: AdmitEvents) -> AdmitResult:
        """CAS 가 0행이다. 세션이 없는 것과 revision 이 어긋난 것을 가른다."""
        row = await self._sql.fetch_one(
            Statement(
                "SELECT revision FROM sessions "
                "WHERE workspace_id = $1 AND id = $2 AND deleted_at IS NULL",
                (cmd.workspace_id, cmd.session_id),
            )
        )
        if row is None:
            return NotFound()
        return VersionConflict(actual_version=int(row["revision"]))

    async def read(self, q: ReadEvents) -> tuple[SessionEvent, ...]:
        """`ORDER BY seq` — 이것이 "모델이 본 순서"다."""
        args: list[object] = [q.workspace_id, q.session_id]
        where = "workspace_id = $1 AND session_id = $2"
        if q.after_seq is not None:
            args.append(q.after_seq)
            where += f" AND seq > ${len(args)}"
        if q.thread_id is not None:
            args.append(q.thread_id)
            where += f" AND thread_id = ${len(args)}"
        args.append(q.limit)
        rows = await self._sql.fetch_all(
            Statement(
                f"SELECT {_EVENT_COLS} FROM session_events "  # noqa: S608
                f"WHERE {where} ORDER BY seq LIMIT ${len(args)}",
                tuple(args),
            )
        )
        return tuple(_to_event(r) for r in rows)

    async def find_by_id(
        self, workspace_id: WorkspaceId, session_id: SessionId, event_id: EventId
    ) -> SessionEvent | None:
        row = await self._sql.fetch_one(
            Statement(
                f"SELECT {_EVENT_COLS} FROM session_events "  # noqa: S608
                "WHERE workspace_id = $1 AND session_id = $2 AND id = $3",
                (workspace_id, session_id, event_id),
            )
        )
        return _to_event(row) if row else None

    async def max_seq(self, workspace_id: WorkspaceId, session_id: SessionId) -> int:
        """이벤트가 없으면 `-1`. 다음 `seq`는 항상 `max_seq + 1`이다."""
        row = await self._sql.fetch_one(
            Statement(
                "SELECT coalesce(max(seq), -1) AS n FROM session_events "
                "WHERE workspace_id = $1 AND session_id = $2",
                (workspace_id, session_id),
            )
        )
        return int(row["n"]) if row else -1


class SqlPendingEventStore:
    """`session_pending_events` — 아직 모델이 보지 않은 입력의 큐."""

    def __init__(self, sql: SqlClient) -> None:
        self._sql = sql

    async def enqueue(self, event: PendingEvent) -> PendingEvent:
        """큐에 넣는다. `id`가 멱등키 — 같은 입력이 두 번 들어가지 않는다."""
        row = await self._sql.fetch_one(
            Statement(
                f"""
                INSERT INTO session_pending_events
                  (workspace_id, session_id, id, thread_id, type, payload, enqueued_at)
                VALUES ($1, $2, $3, $4, $5, $6::jsonb, $7)
                ON CONFLICT (workspace_id, session_id, id) DO NOTHING
                RETURNING {_PENDING_COLS}
                """,  # noqa: S608 — _PENDING_COLS 는 이 모듈의 상수 리터럴이다
                (
                    event.workspace_id,
                    event.session_id,
                    event.id,
                    event.thread_id,
                    event.type.value,
                    _payload_in(event.payload),
                    event.enqueued_at,
                ),
            )
        )
        if row is not None:
            return _to_pending(row)
        existing = await self.find_by_id(event.workspace_id, event.session_id, event.id)
        if existing is None:  # pragma: no cover — ON CONFLICT 후엔 반드시 있다
            raise RuntimeError("enqueue 충돌 후 기존 행을 찾을 수 없다")
        return existing

    async def peek(
        self,
        workspace_id: WorkspaceId,
        session_id: SessionId,
        thread_id: ThreadId,
        limit: int = 50,
    ) -> tuple[PendingEvent, ...]:
        """드레인 대상 — `pending_seq` 순, 취소된 것 제외.

        `idx_pending_drain`이 정확히 이 모양이다.
        """
        rows = await self._sql.fetch_all(
            Statement(
                f"SELECT {_PENDING_COLS} FROM session_pending_events "  # noqa: S608
                "WHERE workspace_id = $1 AND session_id = $2 AND thread_id = $3 "
                "  AND cancelled_at IS NULL "
                "ORDER BY pending_seq LIMIT $4",
                (workspace_id, session_id, thread_id, limit),
            )
        )
        return tuple(_to_pending(r) for r in rows)

    async def delete(
        self, workspace_id: WorkspaceId, session_id: SessionId, event_id: EventId
    ) -> bool:
        res = await self._sql.execute(
            Statement(_DELETE_PENDING_SQL, (workspace_id, session_id, event_id))
        )
        return res.rows_affected == 1

    async def cancel_lane(
        self,
        workspace_id: WorkspaceId,
        session_id: SessionId,
        thread_id: ThreadId,
        now: datetime,
    ) -> int:
        """인터럽트 — 아직 모델이 보지 않은 입력을 접는다.

        삭제하지 않고 `cancelled_at`을 세운다. 삭제하면 "사용자가 보냈는데 조용히
        사라졌다"가 되어 감사로 추적할 수 없다 (`IMPL-0007`).
        """
        res = await self._sql.execute(
            Statement(
                "UPDATE session_pending_events SET cancelled_at = $4 "
                "WHERE workspace_id = $1 AND session_id = $2 AND thread_id = $3 "
                "  AND cancelled_at IS NULL",
                (workspace_id, session_id, thread_id, now),
            )
        )
        return res.rows_affected

    async def find_by_id(
        self, workspace_id: WorkspaceId, session_id: SessionId, event_id: EventId
    ) -> PendingEvent | None:
        row = await self._sql.fetch_one(
            Statement(
                f"SELECT {_PENDING_COLS} FROM session_pending_events "  # noqa: S608
                "WHERE workspace_id = $1 AND session_id = $2 AND id = $3",
                (workspace_id, session_id, event_id),
            )
        )
        return _to_pending(row) if row else None


__all__ = ["SqlPendingEventStore", "SqlSessionEventStore"]
