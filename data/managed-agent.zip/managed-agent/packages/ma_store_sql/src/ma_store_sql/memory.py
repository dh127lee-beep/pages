"""SQL 메모리 스토어 — **경로 충돌을 DB 가 보장한다**.

`plan/05-database.md` §3 G7 · `plan/02-architecture.md` §9.

CAS 는 `content_sha256` precondition 이다. 버전 번호가 아니라 내용 해시인
이유: 동기화가 **파일시스템 디프**에서 오기 때문이다 — 워커는 "내가
읽었을 때 이 내용이었다"는 알지만 그때의 revision 은 모른다.
"""

from __future__ import annotations

import hashlib
from datetime import datetime

from ma_domain.ids import MemoryId, MemoryStoreId, MemoryVersionId, WorkspaceId
from ma_domain.memory import Memory, MemoryVersion
from ma_domain.memory import MemoryStore as MemoryStoreEntity
from ma_sql.ports import Row, SqlClient, Statement
from ma_store._results import Cursor, ListQuery, NotFound, Page, VersionConflict
from ma_store.memory import (
    InsertMemoryStore,
    PathConflict,
    WriteMemory,
    WriteMemoryResult,
    WrittenMemory,
)

_STORE_COLS = "id, workspace_id, name, slug, revision, created_at, archived_at"
_MEM_COLS = (
    "id, workspace_id, store_id, path, content, content_sha256, revision, "
    "created_at, updated_at, deleted_at"
)
_VER_COLS = (
    "id, workspace_id, store_id, memory_id, path, content, content_sha256, "
    "author, redacted_at, redacted_by, created_at"
)


def sha256_of(content: str) -> str:
    return hashlib.sha256(content.encode("utf-8")).hexdigest()


def _store(row: Row) -> MemoryStoreEntity:
    return MemoryStoreEntity(
        id=row["id"],
        workspace_id=row["workspace_id"],
        name=row["name"],
        slug=row["slug"],
        revision=row["revision"],
        created_at=row["created_at"],
        archived_at=row["archived_at"],
    )


def _memory(row: Row) -> Memory:
    return Memory(
        id=row["id"],
        workspace_id=row["workspace_id"],
        store_id=row["store_id"],
        path=row["path"],
        content=row["content"],
        content_sha256=row["content_sha256"],
        revision=row["revision"],
        created_at=row["created_at"],
        updated_at=row["updated_at"],
        deleted_at=row["deleted_at"],
    )


def _version(row: Row) -> MemoryVersion:
    return MemoryVersion(
        id=row["id"],
        workspace_id=row["workspace_id"],
        store_id=row["store_id"],
        memory_id=row["memory_id"],
        path=row["path"],
        content=row["content"],
        content_sha256=row["content_sha256"],
        author=row["author"],
        created_at=row["created_at"],
        redacted_at=row["redacted_at"],
        redacted_by=row["redacted_by"],
    )


class SqlMemoryStoreStore:
    def __init__(self, sql: SqlClient) -> None:
        self._sql = sql

    async def insert(self, cmd: InsertMemoryStore) -> MemoryStoreEntity:
        row = await self._sql.fetch_one(
            Statement(
                f"""
                INSERT INTO memory_stores (id, workspace_id, name, slug, created_at)
                VALUES ($1,$2,$3,$4,$5)
                RETURNING {_STORE_COLS}
                """,  # noqa: S608
                (cmd.id, cmd.workspace_id, cmd.name, cmd.slug, cmd.now),
            )
        )
        if row is None:  # pragma: no cover
            raise ValueError("INSERT ... RETURNING 이 행을 돌려주지 않았다")
        return _store(row)

    async def find(
        self, workspace_id: WorkspaceId, store_id: MemoryStoreId
    ) -> MemoryStoreEntity | None:
        row = await self._sql.fetch_one(
            Statement(
                f"SELECT {_STORE_COLS} FROM memory_stores WHERE workspace_id=$1 AND id=$2",  # noqa: S608
                (workspace_id, store_id),
            )
        )
        return _store(row) if row else None

    async def find_by_slug(self, workspace_id: WorkspaceId, slug: str) -> MemoryStoreEntity | None:
        row = await self._sql.fetch_one(
            Statement(
                f"SELECT {_STORE_COLS} FROM memory_stores "  # noqa: S608
                "WHERE workspace_id=$1 AND slug=$2 AND archived_at IS NULL",
                (workspace_id, slug),
            )
        )
        return _store(row) if row else None

    async def list_stores(self, q: ListQuery) -> Page[MemoryStoreEntity]:
        rows = await self._sql.fetch_all(
            Statement(
                f"""
                SELECT {_STORE_COLS} FROM memory_stores
                WHERE workspace_id = $1
                  AND ($2 OR archived_at IS NULL)
                  AND ($3::timestamptz IS NULL OR (created_at, id) > ($3, $4))
                ORDER BY created_at, id
                LIMIT $5
                """,  # noqa: S608
                (
                    q.workspace_id,
                    q.include_archived,
                    q.after.created_at if q.after else None,
                    q.after.id if q.after else None,
                    q.limit + 1,
                ),
            )
        )
        window = [_store(r) for r in rows[: q.limit]]
        nxt = (
            Cursor(window[-1].created_at, window[-1].id) if len(rows) > q.limit and window else None
        )
        return Page(items=tuple(window), next_cursor=nxt)

    async def archive(
        self, workspace_id: WorkspaceId, store_id: MemoryStoreId, now: datetime
    ) -> bool:
        got = await self._sql.execute(
            Statement(
                "UPDATE memory_stores SET archived_at=$3 "
                "WHERE workspace_id=$1 AND id=$2 AND archived_at IS NULL",
                (workspace_id, store_id, now),
            )
        )
        return got.rows_affected == 1


class SqlMemoryDocumentStore:
    def __init__(self, sql: SqlClient) -> None:
        self._sql = sql

    async def write(self, cmd: WriteMemory) -> WriteMemoryResult:
        """**CAS 는 내용 해시로.** 버전 행은 같은 트랜잭션에서 남긴다.

        쪼개면 "내용은 바뀌었는데 역사가 없는" 상태가 생기고, 그것은
        감사에서 되돌릴 수 없다.
        """
        current = await self.find_by_path(cmd.workspace_id, cmd.store_id, cmd.path)

        if cmd.precondition_sha256 is None:
            if current is not None:
                return PathConflict(conflicting_memory_id=current.id)
        else:
            if current is None:
                return NotFound()
            if current.content_sha256 != cmd.precondition_sha256:
                return VersionConflict(actual_version=current.revision)

        digest = sha256_of(cmd.content)
        memory_id = current.id if current is not None else cmd.id

        if current is None:
            upsert = Statement(
                f"""
                INSERT INTO memories
                  (id, workspace_id, store_id, path, content, content_sha256,
                   revision, created_at, updated_at)
                VALUES ($1,$2,$3,$4,$5,$6,1,$7,$7)
                RETURNING {_MEM_COLS}
                """,  # noqa: S608
                (
                    memory_id,
                    cmd.workspace_id,
                    cmd.store_id,
                    cmd.path,
                    cmd.content,
                    digest,
                    cmd.now,
                ),
            )
        else:
            upsert = Statement(
                f"""
                UPDATE memories
                   SET content = $3, content_sha256 = $4,
                       revision = revision + 1, updated_at = $5
                 WHERE workspace_id = $1 AND id = $2
                   AND deleted_at IS NULL AND content_sha256 = $6
                RETURNING {_MEM_COLS}
                """,  # noqa: S608
                (
                    cmd.workspace_id,
                    memory_id,
                    cmd.content,
                    digest,
                    cmd.now,
                    cmd.precondition_sha256,
                ),
            )

        row = await self._sql.fetch_one(upsert)
        if row is None:
            # 그 사이에 누가 썼다. **읽은 값으로 다시 판정한다.**
            again = await self.find_by_path(cmd.workspace_id, cmd.store_id, cmd.path)
            if again is None:
                return NotFound()
            return VersionConflict(actual_version=again.revision)

        memory = _memory(row)
        version_row = await self._sql.fetch_one(
            Statement(
                f"""
                INSERT INTO memory_versions
                  (id, workspace_id, store_id, memory_id, path, content,
                   content_sha256, author, created_at)
                VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
                RETURNING {_VER_COLS}
                """,  # noqa: S608
                (
                    _version_id(cmd.workspace_id, memory.id, memory.revision),
                    cmd.workspace_id,
                    cmd.store_id,
                    memory.id,
                    cmd.path,
                    cmd.content,
                    digest,
                    cmd.author,
                    cmd.now,
                ),
            )
        )
        if version_row is None:  # pragma: no cover
            raise ValueError("버전 행을 남기지 못했다")
        return WrittenMemory(memory=memory, version=_version(version_row))

    async def find(self, workspace_id: WorkspaceId, memory_id: MemoryId) -> Memory | None:
        row = await self._sql.fetch_one(
            Statement(
                f"SELECT {_MEM_COLS} FROM memories "  # noqa: S608
                "WHERE workspace_id=$1 AND id=$2 AND deleted_at IS NULL",
                (workspace_id, memory_id),
            )
        )
        return _memory(row) if row else None

    async def find_by_path(
        self, workspace_id: WorkspaceId, store_id: MemoryStoreId, path: str
    ) -> Memory | None:
        row = await self._sql.fetch_one(
            Statement(
                f"SELECT {_MEM_COLS} FROM memories "  # noqa: S608
                "WHERE workspace_id=$1 AND store_id=$2 AND path=$3 AND deleted_at IS NULL",
                (workspace_id, store_id, path),
            )
        )
        return _memory(row) if row else None

    async def list_in_store(self, q: ListQuery, store_id: MemoryStoreId) -> Page[Memory]:
        """**경로순이다.** materialize 가 디렉터리를 만들며 순회한다."""
        rows = await self._sql.fetch_all(
            Statement(
                f"""
                SELECT {_MEM_COLS} FROM memories
                WHERE workspace_id = $1 AND store_id = $2 AND deleted_at IS NULL
                ORDER BY path
                LIMIT $3
                """,  # noqa: S608
                (q.workspace_id, store_id, q.limit + 1),
            )
        )
        window = [_memory(r) for r in rows[: q.limit]]
        nxt = (
            Cursor(window[-1].created_at, window[-1].id) if len(rows) > q.limit and window else None
        )
        return Page(items=tuple(window), next_cursor=nxt)

    async def delete(self, workspace_id: WorkspaceId, memory_id: MemoryId, now: datetime) -> bool:
        """**soft delete.** 버전 역사가 참조하고 감사가 그것을 읽는다."""
        got = await self._sql.execute(
            Statement(
                "UPDATE memories SET deleted_at=$3 "
                "WHERE workspace_id=$1 AND id=$2 AND deleted_at IS NULL",
                (workspace_id, memory_id, now),
            )
        )
        return got.rows_affected == 1

    async def list_versions(self, q: ListQuery, store_id: MemoryStoreId) -> Page[MemoryVersion]:
        rows = await self._sql.fetch_all(
            Statement(
                f"""
                SELECT {_VER_COLS} FROM memory_versions
                WHERE workspace_id = $1 AND store_id = $2
                ORDER BY created_at DESC, id DESC
                LIMIT $3
                """,  # noqa: S608
                (q.workspace_id, store_id, q.limit + 1),
            )
        )
        window = [_version(r) for r in rows[: q.limit]]
        nxt = (
            Cursor(window[-1].created_at, window[-1].id) if len(rows) > q.limit and window else None
        )
        return Page(items=tuple(window), next_cursor=nxt)

    async def redact_version(
        self,
        workspace_id: WorkspaceId,
        version_id: MemoryVersionId,
        by: str,
        now: datetime,
    ) -> bool:
        """**live head 는 거부한다.**

        `NOT EXISTS` 가 그것을 한 문장으로 한다 — 읽고 판단한 뒤 쓰면
        그 사이에 내용이 바뀌어, 방금 live 가 된 버전을 지울 수 있다.
        """
        got = await self._sql.execute(
            Statement(
                """
                UPDATE memory_versions v
                   SET content = NULL, redacted_at = $3, redacted_by = $4
                 WHERE v.workspace_id = $1 AND v.id = $2 AND v.redacted_at IS NULL
                   AND NOT EXISTS (
                     SELECT 1 FROM memories m
                      WHERE m.workspace_id = v.workspace_id
                        AND m.id = v.memory_id
                        AND m.deleted_at IS NULL
                        AND m.content_sha256 = v.content_sha256
                   )
                """,
                (workspace_id, version_id, now, by),
            )
        )
        return got.rows_affected == 1


def _version_id(workspace_id: str, memory_id: str, revision: int) -> str:
    """버전 id 를 **내용에서 유도한다.**

    `(메모리, revision)` 이 유일하므로 id 도 그래야 한다. 따로 생성하면
    재시도가 같은 revision 에 두 버전 행을 만든다.
    """
    raw = f"{workspace_id}/{memory_id}/{revision}"
    return "memv_" + hashlib.sha256(raw.encode()).hexdigest()[:26]


__all__ = ["SqlMemoryDocumentStore", "SqlMemoryStoreStore", "sha256_of"]
