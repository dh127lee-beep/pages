"""SqlExecutionStore — 실행 권한 (D3).

`plan/02-architecture.md` §3 · `plan/05-database.md` §3 G5.

**claim은 `FOR UPDATE SKIP LOCKED`다** — 여러 워커의 동시 claim이 자연히 직렬화된다.
행 잠금을 건 워커만 그 행을 보고, 나머지는 건너뛴다. 잠금 대기가 없으므로 워커를
수십 개로 늘려도 claim 지연이 늘지 않는다.
"""

from __future__ import annotations

import json
from datetime import datetime, timedelta
from uuid import UUID

from ma_domain.executions import (
    ExecutionFence,
    ExecutionRecord,
    ExecutionScope,
    ExecutionState,
)
from ma_domain.ids import EventId, ExecutionId, ThreadId, WorkerId, WorkspaceId
from ma_sql.errors import UniqueViolation
from ma_sql.ports import Row, SqlClient, Statement
from ma_store.executions import AdmitExecution, Claimed, ClaimExecution, SettleExecution

_COLUMNS = (
    "id, workspace_id, session_id, lane_id, execution_id, state, event_ids, "
    "generation, attempt_id, attempt_count, lease_owner, lease_expires_at, "
    "interrupt_requested_at, deadline_at, error, created_at, settled_at, "
    "trace_context"
)


def _row_to_record(row: Row) -> ExecutionRecord:
    raw_error = row["error"]
    error = None
    if raw_error:
        parsed = json.loads(raw_error) if isinstance(raw_error, str) else raw_error
        error = tuple(parsed.items())
    return ExecutionRecord(
        id=row["id"],
        scope=ExecutionScope(
            workspace_id=WorkspaceId(row["workspace_id"]),
            session_id=row["session_id"],
            lane_id=ThreadId(row["lane_id"]),
        ),
        execution_id=ExecutionId(row["execution_id"]),
        state=ExecutionState(row["state"]),
        event_ids=tuple(EventId(e) for e in row["event_ids"]),
        generation=row["generation"],
        created_at=row["created_at"],
        attempt_id=row["attempt_id"],
        attempt_count=row["attempt_count"],
        lease_owner=WorkerId(row["lease_owner"]) if row["lease_owner"] else None,
        lease_expires_at=row["lease_expires_at"],
        interrupt_requested_at=row["interrupt_requested_at"],
        deadline_at=row["deadline_at"],
        error=error,
        settled_at=row["settled_at"],
        trace_context=_trace_context(row["trace_context"]),
    )


def _trace_context(raw: object) -> tuple[tuple[str, str], ...]:
    """`NULL` 이면 빈 tuple. **워커가 새 trace 를 시작한다.**"""
    if not raw:
        return ()
    parsed = json.loads(raw) if isinstance(raw, str) else raw
    if not isinstance(parsed, dict):  # pragma: no cover — JSONB 는 dict 로 온다
        return ()
    return tuple((str(k), str(v)) for k, v in parsed.items())


class SqlExecutionStore:
    def __init__(self, sql: SqlClient) -> None:
        self._sql = sql

    async def admit(self, cmd: AdmitExecution) -> ExecutionRecord:
        s = cmd.scope
        row = await self._sql.fetch_one(
            Statement(
                f"""
                INSERT INTO session_executions
                  (workspace_id, session_id, lane_id, execution_id, state,
                   event_ids, generation, attempt_count, created_at, deadline_at,
                   trace_context)
                VALUES ($1, $2, $3, $4, 'queued', $5, 0, 0, $6, $7, $8)
                ON CONFLICT (workspace_id, session_id, execution_id) DO NOTHING
                RETURNING {_COLUMNS}
                """,  # noqa: S608 — _COLUMNS 는 이 모듈의 상수 리터럴이다
                (
                    s.workspace_id,
                    s.session_id,
                    s.lane_id,
                    cmd.execution_id,
                    list(cmd.event_ids),
                    cmd.now,
                    cmd.deadline_at,
                    json.dumps(dict(cmd.trace_context)) if cmd.trace_context else None,
                ),
            )
        )
        if row is not None:
            return _row_to_record(row)
        # 이미 있다 — 멱등하게 기존 것을 돌려준다
        existing = await self.find(s, cmd.execution_id)
        if existing is None:  # pragma: no cover — ON CONFLICT 후엔 반드시 있다
            raise RuntimeError("admit 충돌 후 기존 행을 찾을 수 없다")
        return existing

    async def claim(self, cmd: ClaimExecution) -> Claimed | None:
        """claimable = queued 이거나, running 인데 lease 가 만료된 것.

        `idx_exec_one_running` 부분 유니크가 있으므로, 같은 lane 에 이미 **살아 있는**
        running 이 있으면 그 lane 의 queued 는 집어도 UPDATE 가 충돌한다.
        그래서 lane 단위로 살아 있는 running 이 없는 것만 고른다.

        그래도 경합은 남는다. 두 워커가 같은 lane 의 **서로 다른** 행을 잠그면
        (`SKIP LOCKED` 는 겹치지 않게 해 주지만) 둘 다 `NOT EXISTS` 를 통과한 뒤
        둘 다 running 으로 올리려 한다. 그때 유니크 인덱스가 하나를 떨어뜨린다 —
        그것이 바로 이 인덱스를 둔 이유이고, 진 쪽에게는 "claim 실패"가 맞는 답이다.
        """
        lane_filter = ""
        args: list[object] = [cmd.now, cmd.attempt_id, cmd.owner, cmd.lease_ttl]
        if cmd.scope is not None:
            lane_filter = " AND e.workspace_id = $5 AND e.session_id = $6 AND e.lane_id = $7"
            args += [cmd.scope.workspace_id, cmd.scope.session_id, cmd.scope.lane_id]
        elif cmd.workspace_id is not None:
            lane_filter = " AND e.workspace_id = $5"
            args.append(cmd.workspace_id)

        try:
            row = await self._claim_once(lane_filter, tuple(args))
        except UniqueViolation:
            # 같은 lane 을 노린 다른 워커가 먼저 올렸다. 예외가 아니라 결과다.
            return None
        if row is None:
            return None
        rec = _row_to_record(row)
        return Claimed(
            execution=rec,
            fence=ExecutionFence(
                scope=rec.scope,
                generation=rec.generation,
                attempt_id=rec.attempt_id or UUID(int=0),
                owner=rec.lease_owner or WorkerId(""),
                expires_at=rec.lease_expires_at or cmd.now,
            ),
        )

    async def _claim_once(self, lane_filter: str, args: tuple[object, ...]) -> Row | None:
        return await self._sql.fetch_one(
            Statement(
                f"""
                UPDATE session_executions SET
                    state            = 'running',
                    generation       = generation + 1,
                    attempt_id       = $2,
                    attempt_count    = attempt_count + 1,
                    lease_owner      = $3,
                    lease_expires_at = $1::timestamptz + $4::interval
                WHERE id = (
                    SELECT e.id FROM session_executions e
                     WHERE (
                            e.state = 'queued'
                            OR (e.state = 'running' AND e.lease_expires_at < $1)
                           )
                       -- 같은 lane 에 살아 있는 running 이 있으면 건드리지 않는다
                       AND NOT EXISTS (
                            SELECT 1 FROM session_executions o
                             WHERE o.workspace_id = e.workspace_id
                               AND o.session_id   = e.session_id
                               AND o.lane_id      = e.lane_id
                               AND o.state        = 'running'
                               AND o.lease_expires_at >= $1
                           )
                       {lane_filter}
                     ORDER BY e.created_at, e.id
                       FOR UPDATE SKIP LOCKED
                     LIMIT 1
                )
                RETURNING {_COLUMNS}
                """,  # noqa: S608 — lane_filter 는 이 함수 안의 리터럴이다
                args,
            )
        )

    async def renew(self, fence: ExecutionFence, now: datetime, ttl: timedelta) -> bool:
        res = await self._sql.execute(
            Statement(
                """
                UPDATE session_executions SET lease_expires_at = $1::timestamptz + $2::interval
                 WHERE workspace_id = $3 AND session_id = $4 AND lane_id = $5
                   AND generation = $6 AND state = 'running'
                """,
                (
                    now,
                    ttl,
                    fence.scope.workspace_id,
                    fence.scope.session_id,
                    fence.scope.lane_id,
                    fence.generation,
                ),
            )
        )
        return res.rows_affected == 1

    async def settle(self, cmd: SettleExecution) -> bool:
        f = cmd.fence
        err = json.dumps(dict(cmd.error)) if cmd.error else None
        res = await self._sql.execute(
            Statement(
                """
                UPDATE session_executions
                   SET state = $1, settled_at = $2, error = $3::jsonb,
                       lease_expires_at = NULL
                 WHERE workspace_id = $4 AND session_id = $5 AND lane_id = $6
                   AND generation = $7 AND state = 'running'
                """,
                (
                    cmd.state.value,
                    cmd.now,
                    err,
                    f.scope.workspace_id,
                    f.scope.session_id,
                    f.scope.lane_id,
                    f.generation,
                ),
            )
        )
        return res.rows_affected == 1

    async def request_interrupt(self, scope: ExecutionScope, now: datetime) -> int:
        res = await self._sql.execute(
            Statement(
                """
                UPDATE session_executions SET interrupt_requested_at = $1
                 WHERE workspace_id = $2 AND session_id = $3 AND lane_id = $4
                   AND state IN ('queued', 'running')
                   AND interrupt_requested_at IS NULL
                """,
                (now, scope.workspace_id, scope.session_id, scope.lane_id),
            )
        )
        return res.rows_affected

    async def current_generation(self, scope: ExecutionScope) -> int | None:
        row = await self._sql.fetch_one(
            Statement(
                """
                SELECT generation FROM session_executions
                 WHERE workspace_id = $1 AND session_id = $2 AND lane_id = $3
                   AND state = 'running'
                 ORDER BY generation DESC LIMIT 1
                """,
                (scope.workspace_id, scope.session_id, scope.lane_id),
            )
        )
        return row["generation"] if row else None

    async def find(
        self, scope: ExecutionScope, execution_id: ExecutionId
    ) -> ExecutionRecord | None:
        row = await self._sql.fetch_one(
            Statement(
                f"SELECT {_COLUMNS} FROM session_executions "  # noqa: S608
                "WHERE workspace_id = $1 AND session_id = $2 AND execution_id = $3",
                (scope.workspace_id, scope.session_id, execution_id),
            )
        )
        return _row_to_record(row) if row else None

    async def queued_count(self, workspace_id: WorkspaceId | None = None) -> int:
        if workspace_id is None:
            row = await self._sql.fetch_one(
                Statement("SELECT count(*) AS n FROM session_executions WHERE state = 'queued'")
            )
        else:
            row = await self._sql.fetch_one(
                Statement(
                    "SELECT count(*) AS n FROM session_executions "
                    "WHERE state = 'queued' AND workspace_id = $1",
                    (workspace_id,),
                )
            )
        return int(row["n"]) if row else 0

    async def reclaim_expired(self, now: datetime, limit: int = 100) -> int:
        res = await self._sql.execute(
            Statement(
                """
                UPDATE session_executions
                   SET state = 'queued', lease_owner = NULL, lease_expires_at = NULL
                 WHERE id IN (
                    SELECT id FROM session_executions
                     WHERE state = 'running' AND lease_expires_at < $1
                     ORDER BY lease_expires_at
                     LIMIT $2
                 )
                """,
                (now, limit),
            )
        )
        return res.rows_affected


__all__ = ["SqlExecutionStore"]
