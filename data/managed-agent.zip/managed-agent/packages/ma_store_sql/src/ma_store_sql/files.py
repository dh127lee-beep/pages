"""SQL 파일 · 산출물 · 스냅샷 스토어 (G8).

`plan/05-database.md` §3 G8 · `plan/08-infrastructure.md` §6.

**바이트가 여기 없다.** 행만 다루고 객체는 `BlobPort` 가 맡는다.

업로드는 2단계다 (`insert` → `mark_uploaded`). 사이에서 죽으면 미완성
행이 남고, 그 행은 `is_complete` 가 False 라 마운트되지 않는다.
**주인 없는 객체보다 낫다** — 미완성 행은 DB 안에 있으니 찾을 수 있다.
"""

from __future__ import annotations

from datetime import datetime

from ma_domain.files import FileMeta, SessionOutput, WorkspaceSnapshot
from ma_domain.ids import FileId, SessionId, WorkspaceId
from ma_sql.ports import Row, SqlClient, Statement
from ma_store._results import Cursor, ListQuery, Page
from ma_store.files import (
    InsertFile,
    InsertOutput,
    InsertSnapshot,
    InsertSnapshotResult,
    SnapshotExists,
)

_FILE_COLS = (
    "id, workspace_id, filename, safe_name, content_type, size_bytes, sha256, "
    "storage_key, created_by, created_at, uploaded_at, deleted_at"
)
_OUT_COLS = (
    "id, workspace_id, session_id, path, content_type, size_bytes, sha256, "
    "storage_key, generation, created_at, deleted_at"
)
_SNAP_COLS = (
    "id, workspace_id, session_id, generation, size_bytes, sha256, "
    "storage_key, created_at, expires_at, deleted_at"
)


def _file(row: Row) -> FileMeta:
    return FileMeta(
        id=row["id"],
        workspace_id=row["workspace_id"],
        filename=row["filename"],
        safe_name=row["safe_name"],
        content_type=row["content_type"],
        size_bytes=row["size_bytes"],
        sha256=row["sha256"],
        storage_key=row["storage_key"],
        created_by=row["created_by"],
        created_at=row["created_at"],
        uploaded_at=row["uploaded_at"],
        deleted_at=row["deleted_at"],
    )


def _output(row: Row) -> SessionOutput:
    return SessionOutput(
        id=row["id"],
        workspace_id=row["workspace_id"],
        session_id=row["session_id"],
        path=row["path"],
        content_type=row["content_type"],
        size_bytes=row["size_bytes"],
        sha256=row["sha256"],
        storage_key=row["storage_key"],
        generation=row["generation"],
        created_at=row["created_at"],
        deleted_at=row["deleted_at"],
    )


def _snapshot(row: Row) -> WorkspaceSnapshot:
    return WorkspaceSnapshot(
        id=row["id"],
        workspace_id=row["workspace_id"],
        session_id=row["session_id"],
        generation=row["generation"],
        size_bytes=row["size_bytes"],
        sha256=row["sha256"],
        storage_key=row["storage_key"],
        created_at=row["created_at"],
        expires_at=row["expires_at"],
        deleted_at=row["deleted_at"],
    )


class SqlFileStore:
    def __init__(self, sql: SqlClient) -> None:
        self._sql = sql

    async def insert(self, cmd: InsertFile) -> FileMeta:
        row = await self._sql.fetch_one(
            Statement(
                f"""
                INSERT INTO files (
                  id, workspace_id, filename, safe_name, content_type,
                  size_bytes, sha256, storage_key, created_by, created_at
                )
                VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
                RETURNING {_FILE_COLS}
                """,  # noqa: S608
                (
                    cmd.id,
                    cmd.workspace_id,
                    cmd.filename,
                    cmd.safe_name,
                    cmd.content_type,
                    cmd.size_bytes,
                    cmd.sha256,
                    cmd.storage_key,
                    cmd.created_by,
                    cmd.now,
                ),
            )
        )
        if row is None:  # pragma: no cover
            raise ValueError("INSERT ... RETURNING 이 행을 돌려주지 않았다")
        return _file(row)

    async def mark_uploaded(
        self, workspace_id: WorkspaceId, file_id: FileId, now: datetime
    ) -> FileMeta | None:
        """**이미 찍혀 있으면 그대로 둔다** — `uploaded_at IS NULL` 조건이
        그것을 한 문장으로 한다. 재시도가 시각을 뒤로 미루지 않는다."""
        await self._sql.execute(
            Statement(
                "UPDATE files SET uploaded_at=$3 "
                "WHERE workspace_id=$1 AND id=$2 "
                "  AND uploaded_at IS NULL AND deleted_at IS NULL",
                (workspace_id, file_id, now),
            )
        )
        return await self.find(workspace_id, file_id)

    async def find(self, workspace_id: WorkspaceId, file_id: FileId) -> FileMeta | None:
        row = await self._sql.fetch_one(
            Statement(
                f"SELECT {_FILE_COLS} FROM files "  # noqa: S608
                "WHERE workspace_id=$1 AND id=$2 AND deleted_at IS NULL",
                (workspace_id, file_id),
            )
        )
        return _file(row) if row else None

    async def list_files(self, q: ListQuery) -> Page[FileMeta]:
        rows = await self._sql.fetch_all(
            Statement(
                f"""
                SELECT {_FILE_COLS} FROM files
                WHERE workspace_id = $1
                  AND ($2 OR deleted_at IS NULL)
                  AND ($3::timestamptz IS NULL OR (created_at, id) > ($3, $4))
                ORDER BY created_at, id
                LIMIT $5
                """,  # noqa: S608
                (
                    q.workspace_id,
                    q.include_archived,
                    q.after.created_at if q.after else None,
                    q.after.id if q.after else None,
                    q.limit + 1,
                ),
            )
        )
        window = [_file(r) for r in rows[: q.limit]]
        nxt = (
            Cursor(window[-1].created_at, window[-1].id) if len(rows) > q.limit and window else None
        )
        return Page(items=tuple(window), next_cursor=nxt)

    async def usage_since(self, workspace_id: WorkspaceId, since: datetime) -> tuple[int, int]:
        """**`deleted_at` 을 보지 않는다** — 올리고 지우기로 상한을
        우회하는 길을 막는다."""
        row = await self._sql.fetch_one(
            Statement(
                "SELECT count(*) AS n, coalesce(sum(size_bytes), 0) AS total "
                "FROM files WHERE workspace_id=$1 AND created_at >= $2",
                (workspace_id, since),
            )
        )
        if row is None:  # pragma: no cover — 집계는 항상 행을 준다
            return 0, 0
        return int(row["n"]), int(row["total"])

    async def delete(self, workspace_id: WorkspaceId, file_id: FileId, now: datetime) -> bool:
        got = await self._sql.execute(
            Statement(
                "UPDATE files SET deleted_at=$3 "
                "WHERE workspace_id=$1 AND id=$2 AND deleted_at IS NULL",
                (workspace_id, file_id, now),
            )
        )
        return got.rows_affected == 1


class SqlSessionOutputStore:
    def __init__(self, sql: SqlClient) -> None:
        self._sql = sql

    async def insert(self, cmd: InsertOutput) -> SessionOutput:
        row = await self._sql.fetch_one(
            Statement(
                f"""
                INSERT INTO session_outputs (
                  id, workspace_id, session_id, path, content_type,
                  size_bytes, sha256, storage_key, generation, created_at
                )
                VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
                RETURNING {_OUT_COLS}
                """,  # noqa: S608
                (
                    cmd.id,
                    cmd.workspace_id,
                    cmd.session_id,
                    cmd.path,
                    cmd.content_type,
                    cmd.size_bytes,
                    cmd.sha256,
                    cmd.storage_key,
                    cmd.generation,
                    cmd.now,
                ),
            )
        )
        if row is None:  # pragma: no cover
            raise ValueError("INSERT ... RETURNING 이 행을 돌려주지 않았다")
        return _output(row)

    async def find(self, workspace_id: WorkspaceId, output_id: str) -> SessionOutput | None:
        row = await self._sql.fetch_one(
            Statement(
                f"SELECT {_OUT_COLS} FROM session_outputs "  # noqa: S608
                "WHERE workspace_id=$1 AND id=$2 AND deleted_at IS NULL",
                (workspace_id, output_id),
            )
        )
        return _output(row) if row else None

    async def list_for_session(self, q: ListQuery, session_id: SessionId) -> Page[SessionOutput]:
        rows = await self._sql.fetch_all(
            Statement(
                f"""
                SELECT {_OUT_COLS} FROM session_outputs
                WHERE workspace_id = $1 AND session_id = $2
                  AND ($3 OR deleted_at IS NULL)
                  AND ($4::timestamptz IS NULL OR (created_at, id) > ($4, $5))
                ORDER BY created_at, id
                LIMIT $6
                """,  # noqa: S608
                (
                    q.workspace_id,
                    session_id,
                    q.include_archived,
                    q.after.created_at if q.after else None,
                    q.after.id if q.after else None,
                    q.limit + 1,
                ),
            )
        )
        window = [_output(r) for r in rows[: q.limit]]
        nxt = (
            Cursor(window[-1].created_at, window[-1].id) if len(rows) > q.limit and window else None
        )
        return Page(items=tuple(window), next_cursor=nxt)

    async def delete(self, workspace_id: WorkspaceId, output_id: str, now: datetime) -> bool:
        got = await self._sql.execute(
            Statement(
                "UPDATE session_outputs SET deleted_at=$3 "
                "WHERE workspace_id=$1 AND id=$2 AND deleted_at IS NULL",
                (workspace_id, output_id, now),
            )
        )
        return got.rows_affected == 1


class SqlSnapshotStore:
    def __init__(self, sql: SqlClient) -> None:
        self._sql = sql

    async def insert(self, cmd: InsertSnapshot) -> InsertSnapshotResult:
        """**같은 세대를 거부한다.**

        `ON CONFLICT DO NOTHING` 이 유니크 인덱스를 그대로 쓴다 —
        미리 SELECT 해서 보면 그 사이에 다른 워커가 끼어든다.
        """
        row = await self._sql.fetch_one(
            Statement(
                f"""
                INSERT INTO workspace_snapshots (
                  id, workspace_id, session_id, generation,
                  size_bytes, sha256, storage_key, created_at, expires_at
                )
                VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
                ON CONFLICT (workspace_id, session_id, generation) DO NOTHING
                RETURNING {_SNAP_COLS}
                """,  # noqa: S608
                (
                    cmd.id,
                    cmd.workspace_id,
                    cmd.session_id,
                    cmd.generation,
                    cmd.size_bytes,
                    cmd.sha256,
                    cmd.storage_key,
                    cmd.now,
                    cmd.expires_at,
                ),
            )
        )
        if row is None:
            return SnapshotExists(generation=cmd.generation)
        return _snapshot(row)

    async def latest(
        self, workspace_id: WorkspaceId, session_id: SessionId
    ) -> WorkspaceSnapshot | None:
        """**`generation DESC`.** `created_at DESC` 가 아니다 — 좀비가
        늦게 쓴 낮은 세대가 이기면 옛날 워크스페이스가 복원된다."""
        row = await self._sql.fetch_one(
            Statement(
                f"""
                SELECT {_SNAP_COLS} FROM workspace_snapshots
                WHERE workspace_id=$1 AND session_id=$2 AND deleted_at IS NULL
                ORDER BY generation DESC
                LIMIT 1
                """,  # noqa: S608
                (workspace_id, session_id),
            )
        )
        return _snapshot(row) if row else None

    async def list_expired(
        self, workspace_id: WorkspaceId, now: datetime, limit: int = 100
    ) -> tuple[WorkspaceSnapshot, ...]:
        rows = await self._sql.fetch_all(
            Statement(
                f"""
                SELECT {_SNAP_COLS} FROM workspace_snapshots
                WHERE workspace_id=$1 AND deleted_at IS NULL AND expires_at <= $2
                ORDER BY expires_at, id
                LIMIT $3
                """,  # noqa: S608
                (workspace_id, now, limit),
            )
        )
        return tuple(_snapshot(r) for r in rows)

    async def delete(self, workspace_id: WorkspaceId, snapshot_id: str, now: datetime) -> bool:
        got = await self._sql.execute(
            Statement(
                "UPDATE workspace_snapshots SET deleted_at=$3 "
                "WHERE workspace_id=$1 AND id=$2 AND deleted_at IS NULL",
                (workspace_id, snapshot_id, now),
            )
        )
        return got.rows_affected == 1


__all__ = ["SqlFileStore", "SqlSessionOutputStore", "SqlSnapshotStore"]
