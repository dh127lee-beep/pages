"""SqlCredentialStore — **평문 컬럼이 없다** (D5).

`plan/05-database.md` §3 G6 · §7 · `plan/03-layers.md` §3 L2.

`cipher` 는 **생성자 인자**다. Port 그래프에 들어가면 어떤 유스케이스가
평문을 만질 수 있는지 추적할 수 없게 된다 (`plan/03` §3 L2). 주입은
`ma_platform` 조립 시점에만 일어난다.

읽기는 **메타데이터만** 돌려준다. 평문이 나가는 경로는
`reveal_for_injection` 하나뿐이고 egress 프록시만 쓴다.
"""

from __future__ import annotations

from datetime import datetime

from ma_domain.ids import CredentialId, VaultId, WorkspaceId
from ma_domain.vaults import (
    CredentialKind,
    CredentialMeta,
    OAuthTokens,
    decode_oauth_secret,
    encode_oauth_secret,
    injectable_secret,
)
from ma_governance.cipher import CredentialCipher, Sealed, associated_data
from ma_sql.ports import Row, SqlClient, Statement
from ma_store._results import Cursor, ListQuery, Page
from ma_store.credentials import (
    InjectionSecret,
    InsertCredential,
    RecordCredentialEvent,
    RecordRefresh,
    RevealForInjection,
    RevealOAuth,
    RotateCredential,
)

#: **`ciphertext` 와 `nonce` 가 없다.** 메타데이터 조회가 비밀을 끌고 오면,
#: 그 행이 로그·추적·예외 메시지에 실릴 기회가 생긴다.
_META_COLS = (
    "id, workspace_id, vault_id, kind, match_hosts, mcp_server_name, header_name, "
    "key_version, expires_at, refresh_failed_at, refresh_error, "
    "created_by, created_at, rotated_at, archived_at"
)


def _out(row: Row) -> CredentialMeta:
    return CredentialMeta(
        id=row["id"],
        workspace_id=row["workspace_id"],
        vault_id=row["vault_id"],
        kind=CredentialKind(row["kind"]),
        created_by=row["created_by"],
        created_at=row["created_at"],
        match_hosts=tuple(row["match_hosts"] or ()),
        mcp_server_name=row["mcp_server_name"],
        header_name=row["header_name"],
        key_version=row["key_version"],
        expires_at=row["expires_at"],
        refresh_failed_at=row["refresh_failed_at"],
        refresh_error=row["refresh_error"],
        rotated_at=row["rotated_at"],
        archived_at=row["archived_at"],
    )


class SqlCredentialStore:
    def __init__(self, sql: SqlClient, cipher: CredentialCipher) -> None:
        self._sql, self._cipher = sql, cipher

    async def insert(self, cmd: InsertCredential) -> CredentialMeta:
        sealed = self._cipher.seal(cmd.secret, aad=associated_data(cmd.workspace_id, cmd.id))
        row = await self._sql.fetch_one(
            Statement(
                f"""
                INSERT INTO credentials
                  (id, workspace_id, vault_id, kind, match_hosts, mcp_server_name,
                   header_name, ciphertext, nonce, key_version, expires_at,
                   created_by, created_at)
                VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)
                RETURNING {_META_COLS}
                """,  # noqa: S608 — _COLS 는 이 모듈의 상수 리터럴이다
                (
                    cmd.id,
                    cmd.workspace_id,
                    cmd.vault_id,
                    cmd.kind.value,
                    list(cmd.match_hosts),
                    cmd.mcp_server_name,
                    cmd.header_name,
                    sealed.ciphertext,
                    sealed.nonce,
                    sealed.key_version,
                    cmd.expires_at,
                    cmd.created_by,
                    cmd.now,
                ),
            )
        )
        assert row is not None  # RETURNING 은 항상 한 행이다
        return _out(row)

    async def find(
        self, workspace_id: WorkspaceId, credential_id: CredentialId
    ) -> CredentialMeta | None:
        row = await self._sql.fetch_one(
            Statement(
                f"SELECT {_META_COLS} FROM credentials WHERE workspace_id=$1 AND id=$2",  # noqa: S608
                (workspace_id, credential_id),
            )
        )
        return _out(row) if row else None

    async def list_in_vault(self, q: ListQuery, vault_id: VaultId) -> Page[CredentialMeta]:
        rows = await self._sql.fetch_all(
            Statement(
                f"""
                SELECT {_META_COLS} FROM credentials
                WHERE workspace_id = $1 AND vault_id = $2
                  AND ($3 OR archived_at IS NULL)
                  AND ($4::timestamptz IS NULL OR created_at >= $4)
                  AND ($5::timestamptz IS NULL OR created_at <= $5)
                  AND ($6::timestamptz IS NULL OR (created_at, id) > ($6, $7))
                ORDER BY created_at, id
                LIMIT $8
                """,  # noqa: S608 — _COLS 는 이 모듈의 상수 리터럴이다
                (
                    q.workspace_id,
                    vault_id,
                    q.include_archived,
                    q.created_at_gte,
                    q.created_at_lte,
                    q.after.created_at if q.after else None,
                    q.after.id if q.after else None,
                    q.limit + 1,
                ),
            )
        )
        window = [_out(r) for r in rows[: q.limit]]
        nxt = (
            Cursor(window[-1].created_at, window[-1].id) if len(rows) > q.limit and window else None
        )
        return Page(items=tuple(window), next_cursor=nxt)

    async def rotate(self, cmd: RotateCredential) -> CredentialMeta | None:
        sealed = self._cipher.seal(cmd.secret, aad=associated_data(cmd.workspace_id, cmd.id))
        row = await self._sql.fetch_one(
            Statement(
                f"""
                UPDATE credentials SET
                  ciphertext = $3, nonce = $4, key_version = $5,
                  rotated_at = $6, expires_at = $7,
                  -- 새 비밀은 아직 실패한 적이 없다. 남겨 두면 운영자가
                  -- 고친 것을 못 고친 것으로 본다.
                  refresh_failed_at = NULL, refresh_error = NULL
                WHERE workspace_id=$1 AND id=$2 AND archived_at IS NULL
                RETURNING {_META_COLS}
                """,  # noqa: S608 — _COLS 는 이 모듈의 상수 리터럴이다
                (
                    cmd.workspace_id,
                    cmd.id,
                    sealed.ciphertext,
                    sealed.nonce,
                    sealed.key_version,
                    cmd.now,
                    cmd.expires_at,
                ),
            )
        )
        return _out(row) if row else None

    async def archive(
        self, workspace_id: WorkspaceId, credential_id: CredentialId, now: datetime
    ) -> bool:
        got = await self._sql.execute(
            Statement(
                "UPDATE credentials SET archived_at=$3 "
                "WHERE workspace_id=$1 AND id=$2 AND archived_at IS NULL",
                (workspace_id, credential_id, now),
            )
        )
        return got.rows_affected == 1

    async def reveal_for_injection(self, q: RevealForInjection) -> InjectionSecret | None:
        """**평문이 나가는 유일한 경로.** egress 프록시만 쓴다.

        호스트 매칭을 SQL 이 아니라 파이썬에서 한다. 이유: `match_hosts` 는
        서브도메인을 덮으므로(`CredentialMeta.matches_host`) SQL 로 쓰면
        그 규칙이 **두 곳에 생긴다.** 두 곳이 어긋나면 프록시가 주입하는
        자격증명과 API 가 보여 주는 목록이 달라진다.

        GIN 인덱스가 **후보를 좁히는 데**는 쓰인다 — 정확 일치를 먼저 걸러
        전체 스캔을 피한다. 그 결과를 파이썬 규칙으로 한 번 더 본다.
        """
        rows = await self._sql.fetch_all(
            Statement(
                f"""
                SELECT {_META_COLS}, ciphertext, nonce FROM credentials
                WHERE workspace_id = $1
                  AND archived_at IS NULL
                  AND ($2::text[] IS NULL OR vault_id = ANY($2))
                ORDER BY created_at, id
                """,  # noqa: S608 — _COLS 는 이 모듈의 상수 리터럴이다
                (
                    q.workspace_id,
                    list(q.allowed_vault_ids) if q.allowed_vault_ids else None,
                ),
            )
        )
        for row in rows:
            meta = _out(row)
            if not meta.matches_host(q.host):
                continue
            sealed = Sealed(
                ciphertext=bytes(row["ciphertext"]),
                nonce=bytes(row["nonce"]),
                key_version=row["key_version"],
            )
            return InjectionSecret(
                credential_id=meta.id,
                kind=meta.kind,
                # **`mcp_oauth` 는 access token 만 나간다** — 갱신
                # 토큰이 프록시에 가면 프록시가 토큰을 새로 만들 수
                # 있게 된다 (D5 보다 센 권한이다).
                secret=injectable_secret(
                    meta.kind,
                    self._cipher.open(sealed, aad=associated_data(meta.workspace_id, meta.id)),
                ),
                header_name=meta.header_name,
            )
        return None

    async def reveal_oauth(self, q: RevealOAuth) -> OAuthTokens | None:
        """**갱신 토큰이 나가는 유일한 경로.** 제어 평면만 쓴다."""
        row = await self._sql.fetch_one(
            Statement(
                f"""
                SELECT {_META_COLS}, ciphertext, nonce FROM credentials
                WHERE workspace_id = $1 AND id = $2 AND archived_at IS NULL
                """,  # noqa: S608 — _META_COLS 는 이 모듈의 상수 리터럴이다
                (q.workspace_id, q.id),
            )
        )
        if row is None:
            return None
        meta = _out(row)
        if meta.kind is not CredentialKind.MCP_OAUTH:
            # **종류가 다르면 없는 것과 같다.** bearer 토큰을 OAuth 로
            # 읽어 주면 갱신 경로가 아무 자격증명이나 건드리게 된다.
            return None
        sealed = Sealed(
            ciphertext=bytes(row["ciphertext"]),
            nonce=bytes(row["nonce"]),
            key_version=row["key_version"],
        )
        return decode_oauth_secret(
            self._cipher.open(sealed, aad=associated_data(q.workspace_id, q.id))
        )

    async def record_refresh(self, cmd: RecordRefresh) -> CredentialMeta | None:
        """갱신 결과를 적는다. **실패는 옛 토큰을 지우지 않는다.**"""
        if cmd.tokens is None:
            row = await self._sql.fetch_one(
                Statement(
                    f"""
                    UPDATE credentials
                       SET refresh_failed_at = $3, refresh_error = $4
                     WHERE workspace_id = $1 AND id = $2
                       AND archived_at IS NULL AND kind = 'mcp_oauth'
                 RETURNING {_META_COLS}
                    """,  # noqa: S608 — _META_COLS 는 이 모듈의 상수 리터럴이다
                    (cmd.workspace_id, cmd.id, cmd.now, cmd.error[:500]),
                )
            )
            return _out(row) if row else None

        sealed = self._cipher.seal(
            encode_oauth_secret(cmd.tokens),
            aad=associated_data(cmd.workspace_id, cmd.id),
        )
        row = await self._sql.fetch_one(
            Statement(
                f"""
                UPDATE credentials
                   SET ciphertext = $3, nonce = $4, key_version = $5,
                       rotated_at = $6, expires_at = $7::timestamptz,
                       refresh_failed_at = NULL, refresh_error = NULL
                 WHERE workspace_id = $1 AND id = $2
                   AND archived_at IS NULL AND kind = 'mcp_oauth'
             RETURNING {_META_COLS}
                """,  # noqa: S608 — _META_COLS 는 이 모듈의 상수 리터럴이다
                (
                    cmd.workspace_id,
                    cmd.id,
                    sealed.ciphertext,
                    sealed.nonce,
                    sealed.key_version,
                    cmd.now,
                    cmd.expires_at,
                ),
            )
        )
        return _out(row) if row else None

    async def record_event(self, cmd: RecordCredentialEvent) -> None:
        await self._sql.execute(
            Statement(
                """
                INSERT INTO credential_events
                  (workspace_id, credential_id, session_id, action, host,
                   generation, created_at)
                VALUES ($1,$2,$3,$4,$5,$6,$7)
                """,
                (
                    cmd.workspace_id,
                    cmd.credential_id,
                    cmd.session_id,
                    cmd.action.value,
                    cmd.host,
                    cmd.generation,
                    cmd.now,
                ),
            )
        )

    # ── 재암호화 배치 (`IMPL-0020`) ──────────────────────
    async def stale_key_versions(
        self, workspace_id: WorkspaceId, *, limit: int = 100
    ) -> tuple[CredentialId, ...]:
        rows = await self._sql.fetch_all(
            Statement(
                """
                SELECT id FROM credentials
                WHERE workspace_id = $1 AND archived_at IS NULL AND key_version < $2
                ORDER BY key_version, created_at, id
                LIMIT $3
                """,
                (workspace_id, self._cipher.current_version, limit),
            )
        )
        return tuple(r["id"] for r in rows)

    async def rewrap(self, workspace_id: WorkspaceId, credential_id: CredentialId) -> bool:
        """옛 키로 열어 새 키로 다시 봉한다.

        **`key_version` 을 WHERE 에 넣는다.** 넣지 않으면 두 배치가 같은 행을
        집었을 때 둘 다 쓰고, 나중 것이 이긴다 — 그 자체는 무해하지만
        "몇 건을 처리했는가"가 거짓이 된다.
        """
        row = await self._sql.fetch_one(
            Statement(
                "SELECT ciphertext, nonce, key_version FROM credentials "
                "WHERE workspace_id=$1 AND id=$2 AND archived_at IS NULL",
                (workspace_id, credential_id),
            )
        )
        if row is None:
            return False
        sealed = Sealed(
            ciphertext=bytes(row["ciphertext"]),
            nonce=bytes(row["nonce"]),
            key_version=row["key_version"],
        )
        if not self._cipher.needs_rewrap(sealed):
            return False

        fresh = self._cipher.rewrap(sealed, aad=associated_data(workspace_id, credential_id))
        got = await self._sql.execute(
            Statement(
                "UPDATE credentials SET ciphertext=$3, nonce=$4, key_version=$5 "
                "WHERE workspace_id=$1 AND id=$2 AND key_version=$6",
                (
                    workspace_id,
                    credential_id,
                    fresh.ciphertext,
                    fresh.nonce,
                    fresh.key_version,
                    sealed.key_version,
                ),
            )
        )
        return got.rows_affected == 1


__all__ = ["SqlCredentialStore"]
