"""도메인 타입 ↔ JSONB 문서.

`document` 컬럼은 JSONB다 (S2) — 설정 shape가 자주 바뀌므로 컬럼으로 펼치지 않는다.
직렬화는 **여기 한 곳에서만** 한다. 도메인은 JSON을 모른다.
"""

from __future__ import annotations

import json
from typing import Any

from ma_domain.agents import (
    AgentDefinition,
    AgentToolset,
    CustomToolSpec,
    McpServerSpec,
    PermissionPolicy,
    ToolConfig,
)
from ma_domain.environments import (
    EgressRequirement,
    EnvironmentConfig,
    NetworkKind,
    NetworkPolicy,
    PackageSpec,
    SandboxTier,
)
from ma_domain.models import EffortIntent
from ma_domain.skills import SkillDocument, SkillFile, SkillSource


def _loads(doc: Any) -> dict[str, Any]:
    """asyncpg는 jsonb를 str로 준다 (codec 미등록 시)."""
    if isinstance(doc, str):
        return dict(json.loads(doc))
    return dict(doc)


def encode_agent_definition(d: AgentDefinition) -> dict[str, Any]:
    return {
        "name": d.name,
        "model": d.model,
        "system": d.system,
        "toolset": None
        if d.toolset is None
        else {
            "type": d.toolset.type,
            "default_permission_policy": d.toolset.default_permission_policy.value,
            "configs": [
                {
                    "name": c.name,
                    "enabled": c.enabled,
                    "permission_policy": c.permission_policy.value if c.permission_policy else None,
                }
                for c in d.toolset.configs
            ],
        },
        "custom_tools": [
            {"name": t.name, "description": t.description, "input_schema": t.input_schema}
            for t in d.custom_tools
        ],
        "mcp_servers": [
            {
                "name": s.name,
                "url": s.url,
                "allowed_tools": list(s.allowed_tools),
                "default_permission_policy": s.default_permission_policy.value,
            }
            for s in d.mcp_servers
        ],
        "skills": list(d.skills),
        "harness": d.harness,
        "effort": d.effort.value if d.effort else None,
        "description": d.description,
        "metadata": [list(kv) for kv in d.metadata],
    }


def decode_agent_definition(doc: Any) -> AgentDefinition:
    raw = _loads(doc)
    ts = raw.get("toolset")
    toolset = (
        None
        if ts is None
        else AgentToolset(
            type=ts["type"],
            default_permission_policy=PermissionPolicy(ts["default_permission_policy"]),
            configs=tuple(
                ToolConfig(
                    name=c["name"],
                    enabled=c["enabled"],
                    permission_policy=PermissionPolicy(c["permission_policy"])
                    if c.get("permission_policy")
                    else None,
                )
                for c in ts.get("configs", [])
            ),
        )
    )
    return AgentDefinition(
        name=raw["name"],
        model=raw["model"],
        system=raw.get("system"),
        toolset=toolset,
        custom_tools=tuple(
            CustomToolSpec(
                name=t["name"], description=t["description"], input_schema=t["input_schema"]
            )
            for t in raw.get("custom_tools", [])
        ),
        mcp_servers=tuple(
            McpServerSpec(
                name=s["name"],
                url=s["url"],
                allowed_tools=tuple(s.get("allowed_tools", [])),
                default_permission_policy=PermissionPolicy(s["default_permission_policy"]),
            )
            for s in raw.get("mcp_servers", [])
        ),
        skills=tuple(raw.get("skills", [])),
        harness=raw.get("harness", "default"),
        effort=EffortIntent(raw["effort"]) if raw.get("effort") else None,
        description=raw.get("description"),
        metadata=tuple((k, v) for k, v in raw.get("metadata", [])),
    )


# ── 환경 ───────────────────────────────────────────────────
def encode_environment_config(c: EnvironmentConfig) -> dict[str, Any]:
    """`EnvironmentConfig` → JSONB.

    `document` 가 JSONB 인 이유는 에이전트와 같다 — 설정 shape 가 자주
    바뀌고, 컬럼으로 펴면 바뀔 때마다 마이그레이션이 필요하다.
    """
    return {
        "tier": c.tier.value,
        "self_hosted": c.self_hosted,
        "networking": {
            "kind": c.networking.kind.value,
            "allowed_hosts": list(c.networking.allowed_hosts),
            "blocked_hosts": list(c.networking.blocked_hosts),
            "allow_mcp_servers": c.networking.allow_mcp_servers,
            "allow_package_managers": c.networking.allow_package_managers,
        },
        "packages": {
            "apt": list(c.packages.apt),
            "pip": list(c.packages.pip),
            "npm": list(c.packages.npm),
        },
        "egress": c.egress.value,
        "idle_timeout_seconds": c.idle_timeout_seconds,
    }


def decode_environment_config(doc: Any) -> EnvironmentConfig:
    """JSONB → `EnvironmentConfig`. **기본값으로 메운다.**

    옛 문서에 없는 필드가 생길 수 있다 (설정 shape 가 바뀐다는 것이
    JSONB 를 쓴 이유다). 빠진 것은 도메인 기본값으로 채우되, **느슨한
    쪽으로 채우지 않는다** — `NetworkPolicy` 의 기본은 `UNRESTRICTED`
    인데 그것은 도메인이 정한 것이고, 여기서 다시 정하지 않는다.
    """
    d = _loads(doc)
    net = dict(d.get("networking") or {})
    pkg = dict(d.get("packages") or {})
    return EnvironmentConfig(
        tier=SandboxTier(d.get("tier", SandboxTier.WASM.value)),
        self_hosted=bool(d.get("self_hosted", False)),
        networking=NetworkPolicy(
            kind=NetworkKind(net.get("kind", NetworkKind.UNRESTRICTED.value)),
            allowed_hosts=tuple(net.get("allowed_hosts") or ()),
            blocked_hosts=tuple(net.get("blocked_hosts") or ()),
            allow_mcp_servers=bool(net.get("allow_mcp_servers", True)),
            allow_package_managers=bool(net.get("allow_package_managers", False)),
        ),
        packages=PackageSpec(
            apt=tuple(pkg.get("apt") or ()),
            pip=tuple(pkg.get("pip") or ()),
            npm=tuple(pkg.get("npm") or ()),
        ),
        egress=EgressRequirement(d.get("egress", EgressRequirement.REQUIRED.value)),
        idle_timeout_seconds=int(d.get("idle_timeout_seconds", 300)),
    )


# ── 스킬 (T-0602) ────────────────────────────────────────
def encode_skill_document(d: SkillDocument) -> dict[str, Any]:
    """`SkillDocument` → JSONB.

    `description`·`files`·`source` 가 여기 있고 `name`·`slug` 는
    컬럼이다 — **인덱스를 걸 것만 컬럼으로 올린다** (`0014_skills`).
    """
    body: dict[str, Any] = {
        "description": d.description,
        "files": [{"path": f.path, "content": f.content} for f in d.files],
    }
    if d.source is not None:
        body["source"] = {
            "repo": d.source.repo,
            "path": d.source.path,
            "commit": d.source.commit,
            "ref": d.source.ref,
        }
    return body


def decode_skill_document(doc: Any) -> SkillDocument:
    """JSONB → `SkillDocument`. **도메인 검증을 다시 탄다.**

    읽어 온 행도 `__post_init__` 을 거친다 — DB 에 잘못된 것이 들어가
    있으면 **읽을 때 터지는 쪽**이 조용히 마운트되는 쪽보다 낫다.
    """
    d = _loads(doc)
    raw_source = d.get("source")
    source = (
        SkillSource(
            repo=str(raw_source.get("repo", "")),
            path=str(raw_source.get("path", "")),
            commit=str(raw_source.get("commit", "")),
            ref=str(raw_source.get("ref", "main")),
        )
        if isinstance(raw_source, dict)
        else None
    )
    return SkillDocument(
        description=str(d.get("description", "")),
        files=tuple(
            SkillFile(path=str(f.get("path", "")), content=str(f.get("content", "")))
            for f in (d.get("files") or [])
        ),
        source=source,
    )
