"""SqlSkillStore — `environments` 와 **같은 CAS 배치**.

`plan/05-database.md` §3 G2 · `task/M5-extensions/T-0602-skills.md`.

세 번째 복사다 (`agents` → `environments` → `skills`). 다른 점은
`slug` 뿐이고, 그것 때문에 `insert` 가 **유니크 위반을 결과로** 번역한다 —
마운트 경로가 겹치는 것은 500 이 아니라 409 다.
"""

from __future__ import annotations

import json
from typing import Any

from ma_domain.errors import InvariantViolation
from ma_domain.ids import SkillId, WorkspaceId
from ma_domain.skills import SkillRecord
from ma_sql.errors import UniqueViolation
from ma_sql.ports import Row, SqlClient, Statement
from ma_store._results import (
    Archived,
    ArchiveResult,
    Cursor,
    ListQuery,
    NotFound,
    Page,
    Replaced,
    ReplaceResult,
    VersionConflict,
)
from ma_store.skills import (
    ArchiveSkill,
    FindCurrentSkill,
    FindSkillVersion,
    InsertSkill,
    InsertSkillResult,
    ReplaceSkill,
    SlugTaken,
)

from ma_store_sql._codec import decode_skill_document, encode_skill_document


def _row_to_record(row: Row) -> SkillRecord:
    return SkillRecord(
        id=row["id"],
        workspace_id=row["workspace_id"],
        name=row["name"] or "",
        slug=row["slug"] or "",
        document=decode_skill_document(row["document"]),
        version=row["version"],
        created_at=row["created_at"],
        updated_at=row["updated_at"],
        archived_at=row["archived_at"],
    )


class SqlSkillStore:
    def __init__(self, sql: SqlClient) -> None:
        self._sql = sql

    async def insert(self, cmd: InsertSkill) -> InsertSkillResult:
        doc = json.dumps(encode_skill_document(cmd.document), ensure_ascii=False)
        try:
            row = await self._sql.fetch_one(
                Statement(
                    """
                    INSERT INTO skills
                      (id, workspace_id, name, slug, document, version,
                       created_by, created_at, updated_at)
                    VALUES ($1, $2, $3, $4, $5::jsonb, 1, $6, $7, $7)
                    RETURNING *
                    """,
                    (cmd.id, cmd.workspace_id, cmd.name, cmd.slug, doc, "system", cmd.now),
                )
            )
        except UniqueViolation:
            # **유니크 인덱스가 최종 방어선이다.** 미리 SELECT 해서
            # 보면 그 사이에 다른 요청이 끼어든다.
            return SlugTaken(slug=cmd.slug)
        if row is None:  # pragma: no cover — RETURNING 은 항상 행을 준다
            raise InvariantViolation("INSERT ... RETURNING 이 행을 돌려주지 않았다")
        return _row_to_record(row)

    async def find_current(self, q: FindCurrentSkill) -> SkillRecord | None:
        row = await self._sql.fetch_one(
            Statement(
                "SELECT * FROM skills "
                "WHERE workspace_id = $1 AND id = $2 AND ($3 OR archived_at IS NULL)",
                (q.workspace_id, q.id, q.include_archived),
            )
        )
        return _row_to_record(row) if row else None

    async def find_version(self, q: FindSkillVersion) -> SkillRecord | None:
        row = await self._sql.fetch_one(
            Statement(
                """
                SELECT s.id, s.workspace_id, v.name, v.slug, v.document, v.version,
                       v.created_at, v.created_at AS updated_at,
                       NULL::timestamptz AS archived_at
                  FROM skill_versions v
                  JOIN skills s
                    ON s.workspace_id = v.workspace_id AND s.id = v.skill_id
                 WHERE v.workspace_id = $1 AND v.skill_id = $2 AND v.version = $3
                """,
                (q.workspace_id, q.id, q.version),
            )
        )
        if row is not None:
            return _row_to_record(row)
        cur = await self._sql.fetch_one(
            Statement(
                "SELECT * FROM skills WHERE workspace_id=$1 AND id=$2 AND version=$3",
                (q.workspace_id, q.id, q.version),
            )
        )
        return _row_to_record(cur) if cur else None

    async def find_by_slug(self, workspace_id: WorkspaceId, slug: str) -> SkillRecord | None:
        row = await self._sql.fetch_one(
            Statement(
                "SELECT * FROM skills WHERE workspace_id=$1 AND slug=$2 AND archived_at IS NULL",
                (workspace_id, slug),
            )
        )
        return _row_to_record(row) if row else None

    async def replace_current(self, cmd: ReplaceSkill) -> ReplaceResult[SkillRecord]:
        doc = json.dumps(encode_skill_document(cmd.document), ensure_ascii=False)
        snapshot = Statement(
            """
            INSERT INTO skill_versions
              (workspace_id, skill_id, version, name, slug, document, created_at)
            SELECT workspace_id, id, version, name, slug, document, updated_at
              FROM skills
             WHERE workspace_id = $1 AND id = $2 AND version = $3 AND archived_at IS NULL
            ON CONFLICT DO NOTHING
            """,
            (cmd.workspace_id, cmd.id, cmd.expected_version),
        )
        update = Statement(
            """
            UPDATE skills
               SET name = $4, slug = $5, document = $6::jsonb,
                   version = version + 1, updated_at = $7
             WHERE workspace_id = $1 AND id = $2 AND version = $3 AND archived_at IS NULL
            """,
            (cmd.workspace_id, cmd.id, cmd.expected_version, cmd.name, cmd.slug, doc, cmd.now),
        )
        try:
            results = await self._sql.batch([snapshot, update])
        except UniqueViolation:
            # slug 를 남이 쓰는 것으로 바꾸려 했다.
            return VersionConflict(actual_version=cmd.expected_version)
        snap_n, upd_n = results[0].rows_affected, results[1].rows_affected

        if (snap_n, upd_n) == (1, 1):
            got = await self.find_current(FindCurrentSkill(cmd.workspace_id, cmd.id))
            if got is None:  # pragma: no cover
                raise InvariantViolation("교체 직후 행을 찾을 수 없다")
            return Replaced(record=got)
        if (snap_n, upd_n) == (0, 0):
            return await self._miss(cmd.workspace_id, cmd.id, cmd.expected_version)
        raise InvariantViolation(
            f"CAS 배치의 영향 행 수가 불변식을 깼다: snapshot={snap_n} update={upd_n}"
        )

    async def archive(self, cmd: ArchiveSkill) -> ArchiveResult[SkillRecord]:
        res = await self._sql.execute(
            Statement(
                """
                UPDATE skills SET archived_at = $4, updated_at = $4
                 WHERE workspace_id = $1 AND id = $2 AND version = $3 AND archived_at IS NULL
                """,
                (cmd.workspace_id, cmd.id, cmd.expected_version, cmd.now),
            )
        )
        if res.rows_affected == 1:
            got = await self.find_current(
                FindCurrentSkill(cmd.workspace_id, cmd.id, include_archived=True)
            )
            if got is None:  # pragma: no cover
                raise InvariantViolation("아카이브 직후 행을 찾을 수 없다")
            return Archived(record=got)
        return await self._miss(cmd.workspace_id, cmd.id, cmd.expected_version)

    async def _miss(
        self, workspace_id: str, skill_id: str, expected: int
    ) -> NotFound | VersionConflict:
        row = await self._sql.fetch_one(
            Statement(
                "SELECT version, archived_at FROM skills WHERE workspace_id=$1 AND id=$2",
                (workspace_id, skill_id),
            )
        )
        if row is None or row["archived_at"] is not None:
            return NotFound()
        if row["version"] != expected:
            return VersionConflict(actual_version=row["version"])
        return NotFound()

    async def list_skills(self, q: ListQuery) -> Page[SkillRecord]:
        where: list[str] = ["workspace_id = $1"]
        args: list[Any] = [q.workspace_id]
        if not q.include_archived:
            where.append("archived_at IS NULL")
        if q.after is not None:
            args.extend([q.after.created_at, q.after.id])
            where.append(f"(created_at, id) > (${len(args) - 1}, ${len(args)})")
        args.append(q.limit + 1)
        sql = (
            f"SELECT * FROM skills WHERE {' AND '.join(where)} "  # noqa: S608
            f"ORDER BY created_at, id LIMIT ${len(args)}"
        )
        rows = await self._sql.fetch_all(Statement(sql, tuple(args)))
        window = [_row_to_record(r) for r in rows[: q.limit]]
        nxt = (
            Cursor(window[-1].created_at, window[-1].id) if len(rows) > q.limit and window else None
        )
        return Page(items=tuple(window), next_cursor=nxt)

    async def find_many(
        self, workspace_id: WorkspaceId, ids: tuple[SkillId, ...]
    ) -> tuple[SkillRecord, ...]:
        """**한 번에 읽는다.** 하나씩 읽으면 스킬 수만큼 왕복이 생기고,
        그것이 세션 웜업의 지연이 된다 — 웜업은 첫 턴 앞에 있다."""
        if not ids:
            return ()
        rows = await self._sql.fetch_all(
            Statement(
                "SELECT * FROM skills "
                "WHERE workspace_id = $1 AND id = ANY($2) AND archived_at IS NULL "
                # **slug 순이다.** 카탈로그가 이것을 그대로 쓰면
                # 호출마다 같은 문자열이 나온다 (D12b).
                "ORDER BY slug",
                (workspace_id, list(ids)),
            )
        )
        return tuple(_row_to_record(r) for r in rows)


__all__ = ["SqlSkillStore"]
