"""SQL 웹훅 스토어 (G9).

`plan/05-database.md` §3 G9 · `task/M5-extensions/T-0604-webhooks-notify.md`.

**시크릿을 봉해서 넣는다.** `credentials` 와 같은 cipher 를 쓰고,
생성자가 그것을 받는다 — 유스케이스는 cipher 를 모른다 (`plan/03` §3 L2).

전송 큐는 `session_executions` 와 같은 부분 인덱스 모양이지만 **lease 가
없다.** 중복 전송은 허용되고 수신 측이 `delivery_id` 로 거른다 —
lease 를 걸면 그 복잡도를 사는 셈이고 얻는 것이 없다.
"""

from __future__ import annotations

import json
from datetime import datetime

from ma_domain.ids import WorkspaceId
from ma_domain.webhooks import (
    DeliveryState,
    WebhookDelivery,
    WebhookEndpoint,
    WebhookEvent,
)
from ma_governance.cipher import CredentialCipher, Sealed, associated_data
from ma_sql.ports import Row, SqlClient, Statement
from ma_store._results import Cursor, ListQuery, Page
from ma_store.webhooks import EnqueueDelivery, InsertEndpoint, RecordAttempt

_ENDPOINT_COLS = "id, workspace_id, url, events, description, created_at, disabled_at"
_DELIVERY_COLS = (
    "id, workspace_id, endpoint_id, event, payload, state, attempts, "
    "next_attempt_at, delivered_at, last_error, last_status, created_at"
)


def _endpoint(row: Row) -> WebhookEndpoint:
    return WebhookEndpoint(
        id=row["id"],
        workspace_id=row["workspace_id"],
        url=row["url"],
        events=tuple(WebhookEvent(e) for e in (row["events"] or ())),
        description=row["description"],
        created_at=row["created_at"],
        disabled_at=row["disabled_at"],
    )


def _delivery(row: Row) -> WebhookDelivery:
    raw = row["payload"]
    payload = json.loads(raw) if isinstance(raw, str) else (raw or {})
    return WebhookDelivery(
        id=row["id"],
        workspace_id=row["workspace_id"],
        endpoint_id=row["endpoint_id"],
        event=WebhookEvent(row["event"]),
        payload=tuple(sorted(dict(payload).items())),
        state=DeliveryState(row["state"]),
        attempts=row["attempts"],
        created_at=row["created_at"],
        next_attempt_at=row["next_attempt_at"],
        delivered_at=row["delivered_at"],
        last_error=row["last_error"],
        last_status=row["last_status"],
    )


class SqlWebhookStore:
    def __init__(self, sql: SqlClient, cipher: CredentialCipher) -> None:
        self._sql = sql
        self._cipher = cipher

    # ── 엔드포인트 ───────────────────────────────────────
    async def insert_endpoint(self, cmd: InsertEndpoint) -> WebhookEndpoint:
        sealed = self._cipher.seal(
            cmd.secret.decode("latin-1"),
            aad=associated_data(cmd.workspace_id, cmd.id),
        )
        row = await self._sql.fetch_one(
            Statement(
                f"""
                INSERT INTO webhook_endpoints
                  (id, workspace_id, url, events, description,
                   secret_ciphertext, secret_nonce, key_version, created_by, created_at)
                VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
                RETURNING {_ENDPOINT_COLS}
                """,  # noqa: S608
                (
                    cmd.id,
                    cmd.workspace_id,
                    cmd.url,
                    [e.value for e in cmd.events],
                    cmd.description,
                    sealed.ciphertext,
                    sealed.nonce,
                    sealed.key_version,
                    cmd.created_by,
                    cmd.now,
                ),
            )
        )
        if row is None:  # pragma: no cover
            raise ValueError("INSERT ... RETURNING 이 행을 돌려주지 않았다")
        return _endpoint(row)

    async def find_endpoint(
        self, workspace_id: WorkspaceId, endpoint_id: str
    ) -> WebhookEndpoint | None:
        row = await self._sql.fetch_one(
            Statement(
                f"SELECT {_ENDPOINT_COLS} FROM webhook_endpoints "  # noqa: S608
                "WHERE workspace_id=$1 AND id=$2",
                (workspace_id, endpoint_id),
            )
        )
        return _endpoint(row) if row else None

    async def list_endpoints(self, q: ListQuery) -> Page[WebhookEndpoint]:
        rows = await self._sql.fetch_all(
            Statement(
                f"""
                SELECT {_ENDPOINT_COLS} FROM webhook_endpoints
                WHERE workspace_id = $1
                  AND ($2 OR disabled_at IS NULL)
                  AND ($3::timestamptz IS NULL OR (created_at, id) > ($3, $4))
                ORDER BY created_at, id
                LIMIT $5
                """,  # noqa: S608
                (
                    q.workspace_id,
                    q.include_archived,
                    q.after.created_at if q.after else None,
                    q.after.id if q.after else None,
                    q.limit + 1,
                ),
            )
        )
        window = [_endpoint(r) for r in rows[: q.limit]]
        nxt = (
            Cursor(window[-1].created_at or datetime.min, window[-1].id)
            if len(rows) > q.limit and window
            else None
        )
        return Page(items=tuple(window), next_cursor=nxt)

    async def disable_endpoint(
        self, workspace_id: WorkspaceId, endpoint_id: str, now: datetime
    ) -> bool:
        got = await self._sql.execute(
            Statement(
                "UPDATE webhook_endpoints SET disabled_at=$3 "
                "WHERE workspace_id=$1 AND id=$2 AND disabled_at IS NULL",
                (workspace_id, endpoint_id, now),
            )
        )
        return got.rows_affected == 1

    async def secret_for(self, workspace_id: WorkspaceId, endpoint_id: str) -> bytes | None:
        """**보내는 쪽만 부른다.** 꺼내는 경로를 좁혀 둔다 (D5)."""
        row = await self._sql.fetch_one(
            Statement(
                "SELECT secret_ciphertext, secret_nonce, key_version "
                "FROM webhook_endpoints WHERE workspace_id=$1 AND id=$2",
                (workspace_id, endpoint_id),
            )
        )
        if row is None:
            return None
        plain = self._cipher.open(
            Sealed(
                ciphertext=bytes(row["secret_ciphertext"]),
                nonce=bytes(row["secret_nonce"]),
                key_version=row["key_version"],
            ),
            aad=associated_data(workspace_id, endpoint_id),
        )
        return plain.encode("latin-1")

    async def subscribers(
        self, workspace_id: WorkspaceId, event: WebhookEvent
    ) -> tuple[WebhookEndpoint, ...]:
        rows = await self._sql.fetch_all(
            Statement(
                f"""
                SELECT {_ENDPOINT_COLS} FROM webhook_endpoints
                WHERE workspace_id = $1 AND disabled_at IS NULL
                  -- 빈 배열이면 **전부** 구독이다.
                  AND (cardinality(events) = 0 OR $2 = ANY(events))
                ORDER BY created_at, id
                """,  # noqa: S608
                (workspace_id, event.value),
            )
        )
        return tuple(_endpoint(r) for r in rows)

    # ── 전송 ─────────────────────────────────────────────
    async def enqueue(self, cmd: EnqueueDelivery) -> WebhookDelivery:
        row = await self._sql.fetch_one(
            Statement(
                f"""
                INSERT INTO webhook_deliveries
                  (id, workspace_id, endpoint_id, event, payload, state,
                   attempts, next_attempt_at, created_at)
                VALUES ($1,$2,$3,$4,$5::jsonb,'pending',0,$6,$6)
                RETURNING {_DELIVERY_COLS}
                """,  # noqa: S608
                (
                    cmd.id,
                    cmd.workspace_id,
                    cmd.endpoint_id,
                    cmd.event.value,
                    json.dumps(cmd.payload, ensure_ascii=False),
                    cmd.now,
                ),
            )
        )
        if row is None:  # pragma: no cover
            raise ValueError("INSERT ... RETURNING 이 행을 돌려주지 않았다")
        return _delivery(row)

    async def claim_due(self, now: datetime, limit: int = 50) -> tuple[WebhookDelivery, ...]:
        """**부분 인덱스를 탄다** (`idx_webhook_due`). 끝난 전송이
        쌓여도 스캔 비용이 늘지 않는다.

        워크스페이스를 가로지른다 — 스케줄러가 전부 보낸다. RLS 를
        쓰는 경로가 아니므로 `scoped()` 밖에서 돈다.
        """
        rows = await self._sql.fetch_all(
            Statement(
                f"""
                SELECT {_DELIVERY_COLS} FROM webhook_deliveries
                WHERE state IN ('pending','retrying') AND next_attempt_at <= $1
                ORDER BY next_attempt_at, id
                LIMIT $2
                """,  # noqa: S608
                (now, limit),
            )
        )
        return tuple(_delivery(r) for r in rows)

    async def record_attempt(self, cmd: RecordAttempt) -> WebhookDelivery | None:
        row = await self._sql.fetch_one(
            Statement(
                f"""
                UPDATE webhook_deliveries
                   SET state = $3, attempts = $4,
                       -- **끝난 전송에는 다음 시도가 없다** (DB CHECK).
                       -- **타입을 박는다.** `NULL` 만 두면 Postgres 가
                       -- CASE 의 타입을 `text` 로 추론하고, 그러면
                       -- `timestamptz` 컬럼에 넣다 실패한다.
                       next_attempt_at = CASE WHEN $3 IN ('delivered','dead')
                                              THEN NULL::timestamptz
                                              ELSE $5::timestamptz END,
                       delivered_at = CASE WHEN $3 = 'delivered'
                                           THEN $6::timestamptz
                                           ELSE delivered_at END,
                       last_error = $7, last_status = $8
                 WHERE workspace_id = $1 AND id = $2
                RETURNING {_DELIVERY_COLS}
                """,  # noqa: S608
                (
                    cmd.workspace_id,
                    cmd.delivery_id,
                    cmd.state.value,
                    cmd.attempts,
                    cmd.next_attempt_at,
                    cmd.now,
                    cmd.last_error,
                    cmd.last_status,
                ),
            )
        )
        return _delivery(row) if row else None

    async def find_delivery(
        self, workspace_id: WorkspaceId, delivery_id: str
    ) -> WebhookDelivery | None:
        row = await self._sql.fetch_one(
            Statement(
                f"SELECT {_DELIVERY_COLS} FROM webhook_deliveries "  # noqa: S608
                "WHERE workspace_id=$1 AND id=$2",
                (workspace_id, delivery_id),
            )
        )
        return _delivery(row) if row else None

    async def list_dead(self, q: ListQuery) -> Page[WebhookDelivery]:
        rows = await self._sql.fetch_all(
            Statement(
                f"""
                SELECT {_DELIVERY_COLS} FROM webhook_deliveries
                WHERE workspace_id = $1 AND state = 'dead'
                  AND ($2::timestamptz IS NULL OR (created_at, id) > ($2, $3))
                ORDER BY created_at, id
                LIMIT $4
                """,  # noqa: S608
                (
                    q.workspace_id,
                    q.after.created_at if q.after else None,
                    q.after.id if q.after else None,
                    q.limit + 1,
                ),
            )
        )
        window = [_delivery(r) for r in rows[: q.limit]]
        nxt = (
            Cursor(window[-1].created_at, window[-1].id) if len(rows) > q.limit and window else None
        )
        return Page(items=tuple(window), next_cursor=nxt)


__all__ = ["SqlWebhookStore"]
