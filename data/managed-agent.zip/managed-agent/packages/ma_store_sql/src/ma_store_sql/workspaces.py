"""SqlApiKeyStore — 인증의 뿌리.

`plan/04-api.md` §2.1 · `plan/05-database.md` §3 G1.

**평문은 저장하지 않는다.** `find_by_hash` 가 조회 경로의 전부이고, 해시 계산은
호출자(`ma_auth`)의 일이다 — 해시 알고리즘이 Store 의 관심사가 되면 교체할 때
저장소를 고쳐야 한다.

`api_keys.workspace_id` 가 **발급 시점에 고정**된다. `x-active-workspace` 헤더로
덮어쓸 수 없는 이유가 이것이다 — 허용하면 키 탈취 시 횡적 이동이 가능해진다.

> M1 에서는 `ApiKeyStore` 만 구현한다. `WorkspaceStore`·`MembershipStore` 는
> 쿠키 세션(Console)이 필요해지는 M4 에서 붙인다.
"""

from __future__ import annotations

from datetime import datetime

from ma_domain.ids import ApiKeyId, UserId, WorkspaceId
from ma_domain.workspaces import ApiKey, Role
from ma_sql.ports import Row, SqlClient, Statement
from ma_store._results import Cursor, ListQuery, Page
from ma_store.workspaces import InsertApiKey

_COLS = (
    "id, workspace_id, name, key_prefix, role, created_by, created_at, "
    "last_used_at, expires_at, revoked_at"
)


def _to_key(row: Row) -> ApiKey:
    return ApiKey(
        id=ApiKeyId(row["id"]),
        workspace_id=WorkspaceId(row["workspace_id"]),
        name=row["name"],
        key_prefix=row["key_prefix"],
        role=Role(row["role"]),
        created_by=UserId(row["created_by"]),
        created_at=row["created_at"],
        last_used_at=row["last_used_at"],
        expires_at=row["expires_at"],
        revoked_at=row["revoked_at"],
    )


class SqlApiKeyStore:
    def __init__(self, sql: SqlClient) -> None:
        self._sql = sql

    async def insert(self, cmd: InsertApiKey) -> ApiKey:
        row = await self._sql.fetch_one(
            Statement(
                f"""
                INSERT INTO api_keys
                  (id, workspace_id, name, key_hash, key_prefix, role,
                   created_by, created_at, expires_at)
                VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
                RETURNING {_COLS}
                """,  # noqa: S608 — _COLS 는 이 모듈의 상수 리터럴이다
                (
                    cmd.id,
                    cmd.workspace_id,
                    cmd.name,
                    cmd.key_hash,
                    cmd.key_prefix,
                    cmd.role.value,
                    cmd.created_by,
                    cmd.now,
                    cmd.expires_at,
                ),
            )
        )
        if row is None:  # pragma: no cover
            raise RuntimeError("insert 가 행을 돌려주지 않았다")
        return _to_key(row)

    async def find_by_hash(self, key_hash: bytes) -> ApiKey | None:
        """**해시로만 찾는다.** 평문도, prefix 도 조회 키가 아니다."""
        row = await self._sql.fetch_one(
            Statement(
                f"SELECT {_COLS} FROM api_keys WHERE key_hash = $1",  # noqa: S608
                (key_hash,),
            )
        )
        return _to_key(row) if row else None

    async def touch_used(self, key_id: ApiKeyId, now: datetime) -> None:
        """마지막 사용 시각. **인증 경로에서 돌므로 가볍게** — CAS 하지 않는다."""
        await self._sql.execute(
            Statement("UPDATE api_keys SET last_used_at = $2 WHERE id = $1", (key_id, now))
        )

    async def revoke(self, workspace_id: WorkspaceId, key_id: ApiKeyId, now: datetime) -> bool:
        res = await self._sql.execute(
            Statement(
                "UPDATE api_keys SET revoked_at = $3 "
                "WHERE workspace_id = $1 AND id = $2 AND revoked_at IS NULL",
                (workspace_id, key_id, now),
            )
        )
        return res.rows_affected == 1

    async def list_keys(self, q: ListQuery) -> Page[ApiKey]:
        args: list[object] = [q.workspace_id]
        where = "workspace_id = $1"
        if isinstance(q.after, Cursor):
            args += [q.after.created_at, q.after.id]
            where += f" AND (created_at, id) > (${len(args) - 1}, ${len(args)})"
        args.append(q.limit + 1)
        rows = await self._sql.fetch_all(
            Statement(
                f"SELECT {_COLS} FROM api_keys WHERE {where} "  # noqa: S608
                f"ORDER BY created_at, id LIMIT ${len(args)}",
                tuple(args),
            )
        )
        items = [_to_key(r) for r in rows[: q.limit]]
        nxt = Cursor(items[-1].created_at, items[-1].id) if len(rows) > q.limit and items else None
        return Page(items=tuple(items), next_cursor=nxt)


__all__ = ["SqlApiKeyStore"]
