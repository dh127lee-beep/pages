"""SqlVaultStore — 볼트 메타데이터. **비밀은 여기 없다.**

`plan/05-database.md` §3 G6.
"""

from __future__ import annotations

from datetime import datetime

from ma_domain.ids import VaultId, WorkspaceId
from ma_domain.vaults import Vault
from ma_sql.ports import Row, SqlClient, Statement
from ma_store._results import Cursor, ListQuery, Page
from ma_store.vaults import InsertVault

_COLS = "id, workspace_id, name, version, created_at, archived_at"


def _out(row: Row) -> Vault:
    return Vault(
        id=row["id"],
        workspace_id=row["workspace_id"],
        name=row["name"],
        version=row["version"],
        created_at=row["created_at"],
        archived_at=row["archived_at"],
    )


class SqlVaultStore:
    def __init__(self, sql: SqlClient) -> None:
        self._sql = sql

    async def insert(self, cmd: InsertVault) -> Vault:
        row = await self._sql.fetch_one(
            Statement(
                f"""
                INSERT INTO vaults (id, workspace_id, name, created_at)
                VALUES ($1,$2,$3,$4)
                RETURNING {_COLS}
                """,  # noqa: S608 — _COLS 는 이 모듈의 상수 리터럴이다
                (cmd.id, cmd.workspace_id, cmd.name, cmd.now),
            )
        )
        assert row is not None  # RETURNING 은 항상 한 행이다
        return _out(row)

    async def find(self, workspace_id: WorkspaceId, vault_id: VaultId) -> Vault | None:
        row = await self._sql.fetch_one(
            Statement(
                f"SELECT {_COLS} FROM vaults WHERE workspace_id=$1 AND id=$2",  # noqa: S608
                (workspace_id, vault_id),
            )
        )
        return _out(row) if row else None

    async def list_vaults(self, q: ListQuery) -> Page[Vault]:
        # 커서는 `(created_at, id)` — 메모리 구현의 정렬과 **같아야 한다.**
        rows = await self._sql.fetch_all(
            Statement(
                f"""
                SELECT {_COLS} FROM vaults
                WHERE workspace_id = $1
                  AND ($2 OR archived_at IS NULL)
                  AND ($3::timestamptz IS NULL OR created_at >= $3)
                  AND ($4::timestamptz IS NULL OR created_at <= $4)
                  AND ($5::timestamptz IS NULL OR (created_at, id) > ($5, $6))
                ORDER BY created_at, id
                LIMIT $7
                """,  # noqa: S608 — _COLS 는 이 모듈의 상수 리터럴이다
                (
                    q.workspace_id,
                    q.include_archived,
                    q.created_at_gte,
                    q.created_at_lte,
                    q.after.created_at if q.after else None,
                    q.after.id if q.after else None,
                    q.limit + 1,
                ),
            )
        )
        window = [_out(r) for r in rows[: q.limit]]
        nxt = (
            Cursor(window[-1].created_at, window[-1].id) if len(rows) > q.limit and window else None
        )
        return Page(items=tuple(window), next_cursor=nxt)

    async def archive(self, workspace_id: WorkspaceId, vault_id: VaultId, now: datetime) -> bool:
        got = await self._sql.execute(
            Statement(
                "UPDATE vaults SET archived_at=$3 "
                "WHERE workspace_id=$1 AND id=$2 AND archived_at IS NULL",
                (workspace_id, vault_id, now),
            )
        )
        return got.rows_affected == 1


__all__ = ["SqlVaultStore"]
