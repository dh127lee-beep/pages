"""WebhookStore — 엔드포인트와 전송 큐 (G9).

`plan/05-database.md` §3 G9 · `task/M5-extensions/T-0604-webhooks-notify.md`.

전송 큐는 **`session_executions` 와 같은 모양**이다: 부분 인덱스로
집고, 상태로 진행하고, 끝난 것은 남긴다. 다른 점은 lease 가 없다는
것 — 웹훅은 중복 전송이 허용된다 (수신 측이 `delivery_id` 로 멱등
처리한다). lease 를 걸면 그 복잡도를 사는 셈이고, **사는 값만큼
얻는 것이 없다.**
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any, Protocol

from ma_domain.ids import WorkspaceId
from ma_domain.webhooks import (
    DeliveryState,
    WebhookDelivery,
    WebhookEndpoint,
    WebhookEvent,
)

from ma_store._results import ListQuery, Page


@dataclass(frozen=True, slots=True)
class InsertEndpoint:
    id: str
    workspace_id: WorkspaceId
    url: str
    #: **평문.** Store 구현이 cipher 로 봉한다 — 유스케이스는 cipher 를
    #: 들지 않는다 (`credentials` 와 같은 규칙, `plan/03` §3 L2).
    secret: bytes
    events: tuple[WebhookEvent, ...]
    description: str
    created_by: str
    now: datetime


@dataclass(frozen=True, slots=True)
class EnqueueDelivery:
    id: str
    workspace_id: WorkspaceId
    endpoint_id: str
    event: WebhookEvent
    payload: dict[str, Any]
    now: datetime


@dataclass(frozen=True, slots=True)
class RecordAttempt:
    """한 번 보낸 결과. **상태 전이를 Store 가 정하지 않는다** —
    호출자가 다음 상태와 시각을 계산해서 준다 (재시도 곡선은
    도메인에 있다)."""

    workspace_id: WorkspaceId
    delivery_id: str
    state: DeliveryState
    attempts: int
    now: datetime
    next_attempt_at: datetime | None = None
    last_error: str = ""
    last_status: int | None = None


class WebhookStore(Protocol):
    # ── 엔드포인트 ───────────────────────────────────────
    async def insert_endpoint(self, cmd: InsertEndpoint) -> WebhookEndpoint: ...
    async def find_endpoint(
        self, workspace_id: WorkspaceId, endpoint_id: str
    ) -> WebhookEndpoint | None: ...
    async def list_endpoints(self, q: ListQuery) -> Page[WebhookEndpoint]: ...
    async def disable_endpoint(
        self, workspace_id: WorkspaceId, endpoint_id: str, now: datetime
    ) -> bool: ...

    async def secret_for(self, workspace_id: WorkspaceId, endpoint_id: str) -> bytes | None:
        """서명에 쓸 평문. **보내는 쪽만 부른다.**

        별도 메서드인 이유: `find_endpoint` 가 시크릿을 담으면 목록
        응답에도 실릴 수 있다. 꺼내는 경로를 좁혀 둔다 (D5).
        """
        ...

    async def subscribers(
        self, workspace_id: WorkspaceId, event: WebhookEvent
    ) -> tuple[WebhookEndpoint, ...]:
        """이 이벤트를 받을 활성 엔드포인트."""
        ...

    # ── 전송 ─────────────────────────────────────────────
    async def enqueue(self, cmd: EnqueueDelivery) -> WebhookDelivery: ...
    async def claim_due(self, now: datetime, limit: int = 50) -> tuple[WebhookDelivery, ...]:
        """보낼 때가 된 것. **lease 를 걸지 않는다** — 중복 전송은
        수신 측이 `delivery_id` 로 거른다."""
        ...

    async def record_attempt(self, cmd: RecordAttempt) -> WebhookDelivery | None: ...
    async def find_delivery(
        self, workspace_id: WorkspaceId, delivery_id: str
    ) -> WebhookDelivery | None: ...
    async def list_dead(self, q: ListQuery) -> Page[WebhookDelivery]:
        """DLQ. **지우지 않고 남긴다** — 사람이 보고 다시 쏜다."""
        ...


__all__ = [
    "EnqueueDelivery",
    "InsertEndpoint",
    "RecordAttempt",
    "WebhookStore",
]
