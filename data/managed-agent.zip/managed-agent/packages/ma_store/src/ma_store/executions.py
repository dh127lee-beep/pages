"""ExecutionStore — 실행 권한 (D3).

`plan/02-architecture.md` §3.

이 Store가 **유일한 실행 권한**이다. 워커는 claim해서 fence를 얻고, fence 없는 쓰기는
거부된다. 계약 테스트가 가장 엄격해야 하는 곳이다.

규칙 4개:
1. 입력 수용과 실행 예약은 **같은 트랜잭션**에서 일어난다 (`admit`).
2. 워커는 claim해서 fence를 얻는다 — 권한의 증거는 `(generation, attempt_id, expires_at)`.
3. **fence 없는 쓰기는 거부된다** (`current_generation`으로 검증).
4. at-least-once 실행, at-most-once 커밋.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Protocol
from uuid import UUID

from ma_domain.executions import (
    ExecutionFence,
    ExecutionRecord,
    ExecutionScope,
    ExecutionState,
)
from ma_domain.ids import EventId, ExecutionId, WorkerId, WorkspaceId


@dataclass(frozen=True, slots=True)
class AdmitExecution:
    """outbox에 실행 단위를 넣는다. `execution_id`가 멱등키다.

    같은 `execution_id`로 두 번 넣으면 두 번째는 무시된다 (`ON CONFLICT DO NOTHING`) —
    wake hint가 중복 도착해도 실행이 두 번 생기지 않는다.
    """

    scope: ExecutionScope
    execution_id: ExecutionId
    event_ids: tuple[EventId, ...]
    now: datetime
    deadline_at: datetime | None = None
    #: 제어 평면의 trace 를 워커로 넘긴다 (`ma_observability.trace`).
    #: 비면 워커가 새 trace 를 시작한다.
    trace_context: tuple[tuple[str, str], ...] = ()


@dataclass(frozen=True, slots=True)
class ClaimExecution:
    """`FOR UPDATE SKIP LOCKED`로 하나를 집는다.

    `scope`를 주면 그 lane만, 없으면 아무 claimable 한 건. 워커 루프는 후자를 쓴다.
    """

    owner: WorkerId
    now: datetime
    lease_ttl: timedelta
    attempt_id: UUID
    scope: ExecutionScope | None = None
    workspace_id: WorkspaceId | None = None


@dataclass(frozen=True, slots=True)
class Claimed:
    execution: ExecutionRecord
    fence: ExecutionFence


@dataclass(frozen=True, slots=True)
class SettleExecution:
    """마지막이다. 모든 append가 끝난 뒤 하트비트 한 번 더 갱신하고 settle한다.

    lease 안에서 커밋이 끝나야 fence가 의미를 갖는다.
    """

    fence: ExecutionFence
    state: ExecutionState
    now: datetime
    error: tuple[tuple[str, object], ...] | None = None


class ExecutionStore(Protocol):
    async def admit(self, cmd: AdmitExecution) -> ExecutionRecord:
        """outbox에 넣는다. 이미 있으면 기존 레코드를 돌려준다 (멱등)."""
        ...

    async def claim(self, cmd: ClaimExecution) -> Claimed | None:
        """claimable 한 것 하나를 집어 fence를 만든다. 없으면 None.

        `generation`을 +1 하고 `attempt_count`를 올린다.
        """
        ...

    async def renew(self, fence: ExecutionFence, now: datetime, ttl: timedelta) -> bool:
        """하트비트. fence가 더 이상 현재가 아니면 False — 그때 턴을 중단해야 한다."""
        ...

    async def settle(self, cmd: SettleExecution) -> bool:
        """fence가 현재일 때만 성공한다. 좀비 워커의 커밋을 막는 지점."""
        ...

    async def request_interrupt(self, scope: ExecutionScope, now: datetime) -> int:
        """진행 중 execution에 플래그를 세운다. **내구적 권한** — 워커가 죽어도 남는다.

        돌려주는 값은 영향받은 행 수.
        """
        ...

    async def current_generation(self, scope: ExecutionScope) -> int | None:
        """fence 검증용. running execution이 없으면 None."""
        ...

    async def find(
        self, scope: ExecutionScope, execution_id: ExecutionId
    ) -> ExecutionRecord | None: ...

    async def queued_count(self, workspace_id: WorkspaceId | None = None) -> int:
        """KEDA 스케일 신호. `workspace_id`가 없으면 전체."""
        ...

    async def reclaim_expired(self, now: datetime, limit: int = 100) -> int:
        """lease가 만료된 running을 queued로 되돌린다.

        `claim`이 만료 건도 집으므로 필수는 아니지만, 관측(만료 건수)과
        `attempt_count` 정확도를 위해 둔다.
        """
        ...
