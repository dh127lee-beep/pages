"""SkillStore — `agents`·`environments` 와 **같은 버전 관리 모양** (G2).

`plan/05-database.md` §3 G2 · `task/M5-extensions/T-0602-skills.md`.

세 번째 복사다. 모양이 같다는 것이 요점이고, 다른 점은 둘뿐이다:

- `slug` 가 있다 — `/mnt/skills/<slug>` 가 되므로 **유니크**해야 한다
- `find_by_slug` 가 있다 — 마운트 충돌을 미리 보려면 필요하다
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Protocol

from ma_domain.ids import SkillId, WorkspaceId
from ma_domain.skills import SkillDocument, SkillRecord

from ma_store._results import ArchiveResult, ListQuery, Page, ReplaceResult


@dataclass(frozen=True, slots=True)
class InsertSkill:
    id: SkillId
    workspace_id: WorkspaceId
    name: str
    slug: str
    document: SkillDocument
    now: datetime


@dataclass(frozen=True, slots=True)
class FindCurrentSkill:
    workspace_id: WorkspaceId
    id: SkillId
    include_archived: bool = False


@dataclass(frozen=True, slots=True)
class FindSkillVersion:
    workspace_id: WorkspaceId
    id: SkillId
    version: int


@dataclass(frozen=True, slots=True)
class ReplaceSkill:
    workspace_id: WorkspaceId
    id: SkillId
    name: str
    slug: str
    document: SkillDocument
    expected_version: int
    now: datetime


@dataclass(frozen=True, slots=True)
class ArchiveSkill:
    workspace_id: WorkspaceId
    id: SkillId
    expected_version: int
    now: datetime


@dataclass(frozen=True, slots=True)
class SlugTaken:
    """같은 slug 가 이미 있다. **마운트 경로가 겹친다.**"""

    slug: str


type InsertSkillResult = SkillRecord | SlugTaken


class SkillStore(Protocol):
    async def insert(self, cmd: InsertSkill) -> InsertSkillResult: ...
    async def find_current(self, q: FindCurrentSkill) -> SkillRecord | None: ...
    async def find_version(self, q: FindSkillVersion) -> SkillRecord | None: ...
    async def find_by_slug(self, workspace_id: WorkspaceId, slug: str) -> SkillRecord | None: ...
    async def replace_current(self, cmd: ReplaceSkill) -> ReplaceResult[SkillRecord]: ...
    async def archive(self, cmd: ArchiveSkill) -> ArchiveResult[SkillRecord]: ...
    async def list_skills(self, q: ListQuery) -> Page[SkillRecord]: ...

    async def find_many(
        self, workspace_id: WorkspaceId, ids: tuple[SkillId, ...]
    ) -> tuple[SkillRecord, ...]:
        """에이전트가 부착한 스킬들을 **한 번에** 읽는다.

        하나씩 읽으면 스킬 수만큼 왕복이 생기고, 그것이 세션 웜업의
        지연이 된다 — 웜업은 첫 턴 앞에 있다.
        """
        ...


__all__ = [
    "ArchiveSkill",
    "FindCurrentSkill",
    "FindSkillVersion",
    "InsertSkill",
    "InsertSkillResult",
    "ReplaceSkill",
    "SkillStore",
    "SlugTaken",
]
