"""모든 Store가 공유하는 결과 모양과 커서.

`plan/03-layers.md` §3 L3 · §6.

**비즈니스 결과를 예외로 표현하지 않는다.** `version_conflict`는 버그가 아니라 정상적인
동시성 결과다. 예외로 던지면 호출자가 `try/except`로 흐름 제어를 하게 되고, 어떤 예외가
비즈니스 결과이고 어떤 것이 장애인지 구분이 사라진다.
"""

from __future__ import annotations

import base64
from dataclasses import dataclass
from datetime import UTC, datetime


# ── CAS 결과 ────────────────────────────────────────────────
@dataclass(frozen=True, slots=True)
class Replaced[T]:
    """교체 성공. 새 버전의 레코드를 담는다."""

    record: T


@dataclass(frozen=True, slots=True)
class NotFound:
    """없거나, **다른 워크스페이스에 있다**. 둘을 구분하지 않는다 — 존재를 누설하지 않는다."""


@dataclass(frozen=True, slots=True)
class VersionConflict:
    """기대한 버전과 실제가 다르다. 호출자는 409 + `actual_version`으로 응답한다."""

    actual_version: int


@dataclass(frozen=True, slots=True)
class Archived[T]:
    record: T


type ReplaceResult[T] = Replaced[T] | NotFound | VersionConflict
type ArchiveResult[T] = Archived[T] | NotFound | VersionConflict


# ── 커서 페이지네이션 ────────────────────────────────────────
@dataclass(frozen=True, slots=True)
class Cursor:
    """`(created_at, id)` 복합 커서.

    offset을 쓰지 않는다 — 이벤트가 계속 들어오는 테이블에서 offset은 틀린다.
    **인덱스가 정확히 이 순서여야 한다** (`plan/05-database.md` §4).
    """

    created_at: datetime
    id: str

    def encode(self) -> str:
        raw = f"{self.created_at.timestamp():.6f}|{self.id}".encode()
        return base64.urlsafe_b64encode(raw).decode().rstrip("=")

    @classmethod
    def decode(cls, token: str) -> Cursor:
        pad = "=" * (-len(token) % 4)
        raw = base64.urlsafe_b64decode(token + pad).decode()
        ts, _, ident = raw.partition("|")
        if not ident:
            raise ValueError("잘못된 커서")
        return cls(datetime.fromtimestamp(float(ts), tz=UTC), ident)


@dataclass(frozen=True, slots=True)
class Page[T]:
    """한 페이지. `next_cursor`가 None이면 끝이다."""

    items: tuple[T, ...]
    next_cursor: Cursor | None = None

    @property
    def has_more(self) -> bool:
        return self.next_cursor is not None


@dataclass(frozen=True, slots=True)
class ListQuery:
    """목록 조회 공통 파라미터."""

    workspace_id: str
    limit: int = 50
    after: Cursor | None = None
    include_archived: bool = False
    created_at_gte: datetime | None = None
    created_at_lte: datetime | None = None

    def __post_init__(self) -> None:
        if not 1 <= self.limit <= 200:
            raise ValueError("limit은 1~200 범위여야 한다")
