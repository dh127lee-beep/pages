"""ApprovalStore · ApprovalPolicyStore · AuditStore · BudgetStore · UsageStore."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal
from typing import Protocol

from ma_domain.governance import (
    Approval,
    ApprovalPolicy,
    ApprovalState,
    AuditEntry,
    Budget,
    BudgetPeriod,
    BudgetScope,
    UsageEvent,
)
from ma_domain.ids import ApprovalId, SessionId, UserId, WorkspaceId

from ma_store._results import ListQuery, Page


@dataclass(frozen=True, slots=True)
class DecideApproval:
    workspace_id: WorkspaceId
    approval_id: ApprovalId
    decided_by: UserId
    approve: bool
    now: datetime
    reason: str | None = None


class ApprovalStore(Protocol):
    """**Store 는 표를 세지 않는다.**

    `required_approvals` 는 정책에 있고(`ma_governance.approval`), 두 곳이
    그 수를 알면 어긋난다. 그래서 `decide` 는 표를 하나 더하고,
    `finalize` 는 정책 레이어가 "찼다"고 판단했을 때 부른다.
    """

    async def insert(self, approval: Approval) -> Approval: ...
    async def find(self, workspace_id: WorkspaceId, approval_id: ApprovalId) -> Approval | None: ...
    async def find_by_tool_call(
        self, workspace_id: WorkspaceId, session_id: SessionId, tool_call_id: str
    ) -> Approval | None: ...
    async def decide(self, cmd: DecideApproval) -> Approval | None:
        """표를 하나 더한다. **같은 사람의 두 번째 표는 `None`** —
        혼자 4-eyes 를 채울 수 없다. 거부는 한 표로 끝난다."""
        ...

    async def finalize(
        self, workspace_id: WorkspaceId, approval_id: ApprovalId, now: datetime
    ) -> Approval | None:
        """`pending` → `approved`. 정책 레이어가 표를 센 뒤 부른다."""
        ...

    async def expire_due(self, workspace_id: WorkspaceId, now: datetime) -> int: ...
    async def list_inbox(self, q: ListQuery, state: ApprovalState) -> Page[Approval]: ...


class ApprovalPolicyStore(Protocol):
    async def upsert(self, policy: ApprovalPolicy) -> ApprovalPolicy: ...
    async def list_policies(self, workspace_id: WorkspaceId) -> tuple[ApprovalPolicy, ...]: ...
    async def delete(self, workspace_id: WorkspaceId, policy_id: str) -> bool: ...


class AuditStore(Protocol):
    """append-only. **수정·삭제 메서드가 없다** — 인터페이스 차원에서 막는다."""

    async def append(self, entry: AuditEntry) -> None: ...
    async def list_entries(self, q: ListQuery) -> Page[AuditEntry]: ...
    async def list_for_session(
        self, workspace_id: WorkspaceId, session_id: SessionId
    ) -> tuple[AuditEntry, ...]: ...


class BudgetStore(Protocol):
    async def upsert(self, budget: Budget) -> Budget: ...
    async def find(
        self,
        workspace_id: WorkspaceId,
        scope: BudgetScope,
        scope_id: str | None,
        period: BudgetPeriod,
    ) -> Budget | None: ...
    async def list_budgets(self, workspace_id: WorkspaceId) -> tuple[Budget, ...]: ...


class UsageStore(Protocol):
    async def record(self, event: UsageEvent) -> None: ...
    async def sum_cost_cents(
        self,
        workspace_id: WorkspaceId,
        since: datetime,
        until: datetime,
        agent_id: str | None = None,
    ) -> Decimal: ...
    async def list_events(self, q: ListQuery) -> Page[UsageEvent]: ...
