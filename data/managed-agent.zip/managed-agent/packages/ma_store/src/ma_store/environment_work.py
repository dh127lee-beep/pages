"""`EnvironmentWorkStore` — self_hosted 워커 큐 (G3 · T-0606).

`plan/04-api.md` §3.3 · `plan/05-database.md` §3 G3.

**claim 은 하나의 원자 연산이다.** 찾기와 표시를 나누면 둘 사이에
다른 워커가 끼어들어 같은 일을 두 번 돌린다 — `session_executions`
의 claim 과 같은 이유다 (D3).

차이는 **누가 부르는가**다. 여기서는 부서의 워커가 HTTP 로 부르고,
그 워커는 DB 에 닿지 않는다.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Protocol

from ma_domain.environment_work import (
    DEFAULT_LEASE_TTL,
    MAX_ATTEMPTS,
    WorkItem,
    WorkState,
    WorkStats,
)
from ma_domain.ids import EnvironmentId, SessionId, WorkspaceId

from ma_store._results import ListQuery, Page


@dataclass(frozen=True, slots=True)
class EnqueueWork:
    id: str
    workspace_id: WorkspaceId
    environment_id: EnvironmentId
    environment_version: int
    session_id: SessionId
    now: datetime


@dataclass(frozen=True, slots=True)
class ClaimWork:
    """일 하나를 집는다. **환경을 가로질러 집지 않는다** — 워커는
    자기 환경의 큐만 본다."""

    workspace_id: WorkspaceId
    environment_id: EnvironmentId
    worker_id: str
    now: datetime
    #: 새 1회용 시크릿. **Store 가 만들지 않는다** — 난수 생성은
    #: 주입받는 것이어야 테스트가 결정적이다.
    secret: str
    #: 하트비트가 이보다 오래 끊긴 것도 **함께 회수해 집는다.**
    reclaim_after: timedelta = DEFAULT_LEASE_TTL
    max_attempts: int = MAX_ATTEMPTS


@dataclass(frozen=True, slots=True)
class ClaimedWork:
    """집었다. **평문 시크릿이 여기에만 한 번 실린다** (D5)."""

    item: WorkItem
    secret: str

    def __repr__(self) -> str:
        # 기본 `repr` 이 시크릿을 출력한다 — 예외 추적이 지역 변수를
        # 찍으면 거기 실린다.
        return f"ClaimedWork(item={self.item.id!r}, secret=<가림>)"


@dataclass(frozen=True, slots=True)
class NoWork:
    """큐가 비었다. **오류가 아니다** — long-poll 이 정상적으로 끝난 것."""


@dataclass(frozen=True, slots=True)
class Heartbeat:
    workspace_id: WorkspaceId
    work_id: str
    worker_id: str
    generation: int
    now: datetime


@dataclass(frozen=True, slots=True)
class AckWork:
    """일을 끝냈다고 알린다.

    `generation` 이 틀리면 **거부한다.** 회수된 뒤 살아 돌아온 워커의
    ack 가 새 워커의 결과를 덮으면 안 된다.
    """

    workspace_id: WorkspaceId
    work_id: str
    worker_id: str
    generation: int
    state: WorkState
    now: datetime
    error: str = ""


@dataclass(frozen=True, slots=True)
class FenceLost:
    """generation 이 어긋났다. **이 워커는 더 이상 이 일의 주인이 아니다.**"""

    actual_generation: int


@dataclass(frozen=True, slots=True)
class WorkGone:
    work_id: str


type ClaimResult = ClaimedWork | NoWork
type AckResult = WorkItem | FenceLost | WorkGone
type HeartbeatResult = WorkItem | FenceLost | WorkGone


class EnvironmentWorkStore(Protocol):
    async def enqueue(self, cmd: EnqueueWork) -> WorkItem:
        """세션 하나당 **열린 일은 하나**다. 둘이면 같은 세션의 턴이
        두 워커에서 동시에 돈다 — DB 의 부분 유니크 인덱스가 막는다."""
        ...

    async def claim(self, cmd: ClaimWork) -> ClaimResult:
        """집고 generation 을 올린다. **한 번에.**

        끊긴 것도 함께 회수한다 — 따로 돌면 회수와 claim 사이에
        다른 워커가 끼어든다.
        """
        ...

    async def heartbeat(self, cmd: Heartbeat) -> HeartbeatResult: ...
    async def ack(self, cmd: AckWork) -> AckResult: ...
    async def find(self, workspace_id: WorkspaceId, work_id: str) -> WorkItem | None: ...
    async def find_for_session(
        self, workspace_id: WorkspaceId, session_id: SessionId
    ) -> WorkItem | None: ...
    async def list_work(self, q: ListQuery, environment_id: EnvironmentId) -> Page[WorkItem]: ...

    async def stats(
        self, workspace_id: WorkspaceId, environment_id: EnvironmentId, now: datetime
    ) -> WorkStats:
        """운영자가 "워커가 도는가"를 보는 수치."""
        ...

    async def reclaim_stale(
        self, now: datetime, *, ttl: timedelta = DEFAULT_LEASE_TTL, limit: int = 100
    ) -> tuple[WorkItem, ...]:
        """하트비트가 끊긴 것을 큐로 되돌린다. **스케줄러가 부른다.**

        claim 이 이미 회수하지만, 그것은 **누군가 폴링할 때만** 돈다.
        환경의 워커가 전부 죽으면 집힌 일이 영원히 `claimed` 로 남고,
        `stats` 가 "일하는 중"이라고 거짓말한다.
        """
        ...


__all__ = [
    "AckResult",
    "AckWork",
    "ClaimResult",
    "ClaimWork",
    "ClaimedWork",
    "EnqueueWork",
    "EnvironmentWorkStore",
    "FenceLost",
    "Heartbeat",
    "HeartbeatResult",
    "NoWork",
    "WorkGone",
]
