"""EnvironmentStore — agents와 같은 버전 관리 모양."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Protocol

from ma_domain.environments import EnvironmentConfig, EnvironmentRecord
from ma_domain.ids import EnvironmentId, WorkspaceId

from ma_store._results import ArchiveResult, ListQuery, Page, ReplaceResult


@dataclass(frozen=True, slots=True)
class InsertEnvironment:
    id: EnvironmentId
    workspace_id: WorkspaceId
    name: str
    config: EnvironmentConfig
    now: datetime


@dataclass(frozen=True, slots=True)
class FindCurrentEnvironment:
    workspace_id: WorkspaceId
    id: EnvironmentId
    include_archived: bool = False


@dataclass(frozen=True, slots=True)
class FindEnvironmentVersion:
    workspace_id: WorkspaceId
    id: EnvironmentId
    version: int


@dataclass(frozen=True, slots=True)
class ReplaceEnvironment:
    workspace_id: WorkspaceId
    id: EnvironmentId
    name: str
    config: EnvironmentConfig
    expected_version: int
    now: datetime


@dataclass(frozen=True, slots=True)
class ArchiveEnvironment:
    workspace_id: WorkspaceId
    id: EnvironmentId
    expected_version: int
    now: datetime


class EnvironmentStore(Protocol):
    async def insert(self, cmd: InsertEnvironment) -> EnvironmentRecord: ...
    async def find_current(self, q: FindCurrentEnvironment) -> EnvironmentRecord | None: ...
    async def find_version(self, q: FindEnvironmentVersion) -> EnvironmentRecord | None: ...
    async def replace_current(
        self, cmd: ReplaceEnvironment
    ) -> ReplaceResult[EnvironmentRecord]: ...
    async def archive_current(
        self, cmd: ArchiveEnvironment
    ) -> ArchiveResult[EnvironmentRecord]: ...
    async def list_current(self, q: ListQuery) -> Page[EnvironmentRecord]: ...
