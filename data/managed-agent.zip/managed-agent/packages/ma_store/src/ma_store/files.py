"""FileStore · SessionOutputStore · SnapshotStore (G8).

**바이트가 여기 없다.** Store 는 행만 다루고, 객체는 `BlobPort` 가
맡는다. 둘을 한 Store 에 묶지 않는 이유: 그러면 모든 Store 구현이
오브젝트 스토어 클라이언트를 들어야 하고, 메모리 구현이 "진짜" 블롭
백엔드를 흉내 내야 한다.

**업로드는 2단계다** (`insert` → `mark_uploaded`). 중간에 죽으면
미완성 행이 남고, 그 행은 `is_complete` 가 False 라 마운트되지 않는다.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Protocol

from ma_domain.files import FileMeta, SessionOutput, WorkspaceSnapshot
from ma_domain.ids import FileId, SessionId, WorkspaceId

from ma_store._results import ListQuery, Page


@dataclass(frozen=True, slots=True)
class InsertFile:
    """**`uploaded_at` 을 받지 않는다.** 행은 항상 미완성으로 태어난다."""

    id: FileId
    workspace_id: WorkspaceId
    filename: str
    safe_name: str
    content_type: str
    size_bytes: int
    sha256: str
    storage_key: str
    created_by: str
    now: datetime


class FileStore(Protocol):
    async def insert(self, cmd: InsertFile) -> FileMeta: ...

    async def mark_uploaded(
        self, workspace_id: WorkspaceId, file_id: FileId, now: datetime
    ) -> FileMeta | None:
        """바이트가 올라갔음을 기록한다. **이미 찍혀 있으면 그대로 둔다** —
        재시도가 시각을 뒤로 미루면 안 된다."""
        ...

    async def find(self, workspace_id: WorkspaceId, file_id: FileId) -> FileMeta | None: ...
    async def list_files(self, q: ListQuery) -> Page[FileMeta]: ...

    async def usage_since(self, workspace_id: WorkspaceId, since: datetime) -> tuple[int, int]:
        """`since` 이후 업로드의 `(개수, 바이트)`.

        **지워진 것도 센다.** 쿼터는 "얼마나 올렸는가"이지 "얼마나
        남아 있는가"가 아니다 — 올리고 지우기를 반복하면 상한이
        무의미해진다.
        """
        ...

    async def delete(self, workspace_id: WorkspaceId, file_id: FileId, now: datetime) -> bool: ...


@dataclass(frozen=True, slots=True)
class InsertOutput:
    id: str
    workspace_id: WorkspaceId
    session_id: SessionId
    path: str
    content_type: str
    size_bytes: int
    sha256: str
    storage_key: str
    generation: int
    now: datetime


class SessionOutputStore(Protocol):
    async def insert(self, cmd: InsertOutput) -> SessionOutput: ...
    async def find(self, workspace_id: WorkspaceId, output_id: str) -> SessionOutput | None: ...
    async def list_for_session(
        self, q: ListQuery, session_id: SessionId
    ) -> Page[SessionOutput]: ...
    async def delete(self, workspace_id: WorkspaceId, output_id: str, now: datetime) -> bool: ...


@dataclass(frozen=True, slots=True)
class InsertSnapshot:
    id: str
    workspace_id: WorkspaceId
    session_id: SessionId
    generation: int
    size_bytes: int
    sha256: str
    storage_key: str
    now: datetime
    expires_at: datetime


@dataclass(frozen=True, slots=True)
class SnapshotExists:
    """**같은 세대의 스냅샷이 이미 있다.**

    좀비 워커가 새 소유자의 스냅샷을 덮으려 한 것일 수 있다 (D3).
    덮어쓰지 않고 거부하는 것이 핵심이다 — 덮으면 복원했을 때 옛날
    워크스페이스가 돌아온다.
    """

    generation: int


type InsertSnapshotResult = WorkspaceSnapshot | SnapshotExists


class SnapshotStore(Protocol):
    async def insert(self, cmd: InsertSnapshot) -> InsertSnapshotResult: ...
    async def latest(
        self, workspace_id: WorkspaceId, session_id: SessionId
    ) -> WorkspaceSnapshot | None:
        """가장 **높은 세대**를 돌려준다. 가장 최근 시각이 아니다 —
        좀비가 늦게 쓴 낮은 세대가 이기면 안 된다."""
        ...

    async def list_expired(
        self, workspace_id: WorkspaceId, now: datetime, limit: int = 100
    ) -> tuple[WorkspaceSnapshot, ...]: ...
    async def delete(self, workspace_id: WorkspaceId, snapshot_id: str, now: datetime) -> bool: ...


__all__ = [
    "FileStore",
    "InsertFile",
    "InsertOutput",
    "InsertSnapshot",
    "InsertSnapshotResult",
    "SessionOutputStore",
    "SnapshotExists",
    "SnapshotStore",
]
