"""DeploymentStore — 배포와 실행 (G9).

`plan/05-database.md` §3 G9 · `ref/api/deployments/`.

**발화는 `claim_fire` 하나로 끝난다.** 찾기와 표시를 나누면 둘 사이에
다른 스케줄러가 끼어들어 같은 발화를 두 번 돌린다 — 리더 교체 중에
실제로 일어난다.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Any, Protocol

from ma_domain.deployments import (
    Deployment,
    DeploymentRun,
    DeploymentState,
    RunState,
    RunTrigger,
    Schedule,
)
from ma_domain.ids import AgentId, EnvironmentId, SessionId, WorkspaceId

from ma_store._results import ListQuery, NotFound, Page


@dataclass(frozen=True, slots=True)
class InsertDeployment:
    id: str
    workspace_id: WorkspaceId
    name: str
    agent_id: AgentId
    agent_version: int
    now: datetime
    environment_id: EnvironmentId | None = None
    schedule: Schedule | None = None
    initial_events: tuple[dict[str, Any], ...] = ()
    budget_cents: int | None = None
    created_by: str = ""
    #: 첫 발화 시각. **유스케이스가 cron 을 풀어 계산해서 준다** —
    #: Store 가 cron 을 알 이유가 없다.
    next_fire_at: datetime | None = None


@dataclass(frozen=True, slots=True)
class UpdateDeploymentState:
    workspace_id: WorkspaceId
    deployment_id: str
    state: DeploymentState
    now: datetime
    reason: str = ""
    next_fire_at: datetime | None = None


@dataclass(frozen=True, slots=True)
class ClaimedFire:
    """발화 하나를 집었다. **중복 없이.**"""

    deployment: Deployment
    run: DeploymentRun


@dataclass(frozen=True, slots=True)
class ClaimFire:
    workspace_id: WorkspaceId
    deployment_id: str
    #: 원래 발화 시각. **멱등 키다** — 같은 것으로 두 번 집히지 않는다.
    scheduled_for: datetime
    run_id: str
    now: datetime
    #: off-peak 이동량. 0 이면 안 밀렸다.
    shifted: timedelta = timedelta(0)
    trigger: RunTrigger = RunTrigger.SCHEDULE
    #: 다음 발화. 집는 것과 **같은 트랜잭션에서** 민다.
    next_fire_at: datetime | None = None


@dataclass(frozen=True, slots=True)
class FinishRun:
    workspace_id: WorkspaceId
    run_id: str
    state: RunState
    now: datetime
    session_id: SessionId | None = None
    error: str = ""
    cost_cents: int = 0


#: 같은 발화를 이미 집었다. **정상이다** — 두 스케줄러가 겹친 것뿐이다.
@dataclass(frozen=True, slots=True)
class AlreadyFired:
    scheduled_for: datetime


type ClaimFireResult = ClaimedFire | AlreadyFired | NotFound


class DeploymentStore(Protocol):
    async def insert(self, cmd: InsertDeployment) -> Deployment: ...
    async def find(self, workspace_id: WorkspaceId, deployment_id: str) -> Deployment | None: ...
    async def list_deployments(self, q: ListQuery) -> Page[Deployment]: ...
    async def set_state(self, cmd: UpdateDeploymentState) -> Deployment | None: ...

    async def due(self, now: datetime, limit: int = 50) -> tuple[Deployment, ...]:
        """발화할 때가 된 배포. **워크스페이스를 가로지른다.**"""
        ...

    async def claim_fire(self, cmd: ClaimFire) -> ClaimFireResult:
        """발화를 집고 다음 발화를 민다. **한 번에.**

        나누면 둘 사이에 다른 스케줄러가 끼어들어 같은 발화를 두 번
        돌린다 — 리더 교체 중에 실제로 일어난다.
        """
        ...

    async def finish_run(self, cmd: FinishRun) -> DeploymentRun | None: ...
    async def find_run(self, workspace_id: WorkspaceId, run_id: str) -> DeploymentRun | None: ...
    async def list_runs(self, q: ListQuery, deployment_id: str) -> Page[DeploymentRun]: ...

    async def running_count(self, workspace_id: WorkspaceId, deployment_id: str) -> int:
        """아직 끝나지 않은 실행 수. **겹침을 막는 데 쓴다** — 앞
        실행이 도는 중이면 새 발화를 건너뛴다."""
        ...


__all__ = [
    "AlreadyFired",
    "ClaimFire",
    "ClaimFireResult",
    "ClaimedFire",
    "DeploymentStore",
    "FinishRun",
    "InsertDeployment",
    "UpdateDeploymentState",
]
