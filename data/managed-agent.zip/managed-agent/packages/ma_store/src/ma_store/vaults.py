"""VaultStore — 볼트 메타데이터."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Protocol

from ma_domain.ids import VaultId, WorkspaceId
from ma_domain.vaults import Vault

from ma_store._results import ListQuery, Page


@dataclass(frozen=True, slots=True)
class InsertVault:
    id: VaultId
    workspace_id: WorkspaceId
    name: str
    now: datetime


class VaultStore(Protocol):
    async def insert(self, cmd: InsertVault) -> Vault: ...
    async def find(self, workspace_id: WorkspaceId, vault_id: VaultId) -> Vault | None: ...
    async def list_vaults(self, q: ListQuery) -> Page[Vault]: ...
    async def archive(
        self, workspace_id: WorkspaceId, vault_id: VaultId, now: datetime
    ) -> bool: ...
