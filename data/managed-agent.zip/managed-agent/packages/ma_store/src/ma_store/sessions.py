"""SessionStore · SessionResourceStore · SessionThreadStore.

세션은 `version`이 아니라 `revision`으로 CAS한다 — 이벤트 수용이 그 위에서 돈다
(`plan/02-architecture.md` §3 규칙 1).
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Protocol

from ma_domain.ids import SessionId, ThreadId, WorkspaceId
from ma_domain.models import TokenUsage
from ma_domain.sessions import (
    RequiredAction,
    SessionRecord,
    SessionResource,
    SessionStatus,
    SessionThread,
    StopReason,
)

from ma_store._results import NotFound, Page, VersionConflict


@dataclass(frozen=True, slots=True)
class InsertSession:
    record: SessionRecord


@dataclass(frozen=True, slots=True)
class FindSession:
    workspace_id: WorkspaceId
    id: SessionId
    include_deleted: bool = False


@dataclass(frozen=True, slots=True)
class UpdateSessionStatus:
    """상태 전이. `expected_revision`을 주면 CAS한다."""

    workspace_id: WorkspaceId
    id: SessionId
    status: SessionStatus
    now: datetime
    stop_reason: StopReason | None = None
    required_action: RequiredAction | None = None
    expected_revision: int | None = None


@dataclass(frozen=True, slots=True)
class AccrueSessionUsage:
    workspace_id: WorkspaceId
    id: SessionId
    usage: TokenUsage
    cost_cents: int
    now: datetime


@dataclass(frozen=True, slots=True)
class UpdatedSession:
    record: SessionRecord


type SessionUpdateResult = UpdatedSession | NotFound | VersionConflict


@dataclass(frozen=True, slots=True)
class ListSessions:
    workspace_id: WorkspaceId
    limit: int = 50
    after: object | None = None
    status: SessionStatus | None = None
    agent_id: str | None = None
    created_by: str | None = None
    #: 기간 필터. `[gte, lte]` 양끝 포함 — 콘솔이 "이 날 하루"를
    #: 고르면 그 날의 마지막 세션도 들어와야 한다.
    created_at_gte: datetime | None = None
    created_at_lte: datetime | None = None


class SessionStore(Protocol):
    async def insert(self, cmd: InsertSession) -> SessionRecord: ...
    async def find(self, q: FindSession) -> SessionRecord | None: ...
    async def update_status(self, cmd: UpdateSessionStatus) -> SessionUpdateResult: ...
    async def accrue_usage(self, cmd: AccrueSessionUsage) -> SessionUpdateResult: ...
    async def archive(
        self, workspace_id: WorkspaceId, session_id: SessionId, now: datetime
    ) -> SessionUpdateResult: ...
    async def delete(
        self, workspace_id: WorkspaceId, session_id: SessionId, now: datetime
    ) -> bool: ...
    async def list_sessions(self, q: ListSessions) -> Page[SessionRecord]: ...


class SessionResourceStore(Protocol):
    async def add(self, resource: SessionResource) -> SessionResource: ...
    async def find(self, workspace_id: WorkspaceId, resource_id: str) -> SessionResource | None: ...
    async def list_for_session(
        self, workspace_id: WorkspaceId, session_id: SessionId
    ) -> tuple[SessionResource, ...]: ...
    async def remove(self, workspace_id: WorkspaceId, resource_id: str, now: datetime) -> bool: ...


class SessionThreadStore(Protocol):
    async def ensure(self, thread: SessionThread) -> SessionThread: ...
    async def find(
        self, workspace_id: WorkspaceId, session_id: SessionId, thread_id: ThreadId
    ) -> SessionThread | None: ...
    async def list_for_session(
        self, workspace_id: WorkspaceId, session_id: SessionId
    ) -> tuple[SessionThread, ...]: ...
    async def archive(
        self, workspace_id: WorkspaceId, session_id: SessionId, thread_id: ThreadId, now: datetime
    ) -> bool: ...
