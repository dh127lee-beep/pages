"""CredentialStore — 평문은 이 인터페이스를 지나지 않는다 (D5).

`plan/05-database.md` §3 G6 · §7.

쓰기는 평문을 **받아서** 구현체의 cipher가 암호화하고, 읽기는 **메타데이터만** 돌려준다.
평문을 꺼내는 경로는 `reveal_for_injection` 하나뿐이고, egress 프록시만 쓴다.
cipher는 구현체의 **생성자 인자**지 Port가 아니다 (`plan/03-layers.md` §3 L2).
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Protocol

from ma_domain.ids import CredentialId, SessionId, UserId, VaultId, WorkspaceId
from ma_domain.vaults import CredentialAction, CredentialKind, CredentialMeta, OAuthTokens

from ma_store._results import ListQuery, Page


@dataclass(frozen=True, slots=True)
class InsertCredential:
    """평문을 받는 **유일한** 입력. 구현체가 즉시 암호화한다."""

    id: CredentialId
    workspace_id: WorkspaceId
    vault_id: VaultId
    kind: CredentialKind
    secret: str
    created_by: UserId
    now: datetime
    match_hosts: tuple[str, ...] = ()
    mcp_server_name: str | None = None
    header_name: str | None = None
    expires_at: datetime | None = None


@dataclass(frozen=True, slots=True)
class RotateCredential:
    workspace_id: WorkspaceId
    id: CredentialId
    secret: str
    now: datetime
    expires_at: datetime | None = None


@dataclass(frozen=True, slots=True)
class RecordRefresh:
    """OAuth 갱신 결과를 적는다 (T-0601).

    `tokens` 가 있으면 성공 — 새 토큰으로 바꾸고 실패 표시를 **지운다**.
    `None` 이면 실패 — 실패 시각과 사유만 적고 **옛 토큰은 그대로 둔다.**

    옛 토큰을 지우지 않는 이유: 만료 전에 갱신을 시도하는 경우가
    있고(선제 갱신), 그때 지우면 아직 쓸 수 있는 토큰을 버린다.
    만료 뒤였다면 어차피 401 이 나므로 지워서 얻는 것이 없다.
    """

    workspace_id: WorkspaceId
    id: CredentialId
    now: datetime
    tokens: OAuthTokens | None = None
    error: str = ""
    expires_at: datetime | None = None


@dataclass(frozen=True, slots=True)
class RevealOAuth:
    """**갱신 토큰이 나가는 유일한 경로.** 제어 평면만 쓴다.

    `reveal_for_injection` 과 나눈 이유가 D5 다: 프록시는 access token
    만 받아야 하고, 갱신 토큰을 받으면 **토큰을 새로 만들 수 있게**
    된다. 두 경로를 한 함수로 합치면 그 구분이 호출자의 주의력에
    달리고, 주의력은 언젠가 진다.
    """

    workspace_id: WorkspaceId
    id: CredentialId


@dataclass(frozen=True, slots=True)
class RevealForInjection:
    """egress 프록시 전용. **fence generation을 함께 검증한다** —
    소유권이 넘어간 세션은 자격증명을 받지 못한다."""

    workspace_id: WorkspaceId
    session_id: SessionId
    host: str
    allowed_vault_ids: tuple[VaultId, ...]
    generation: int | None = None


@dataclass(frozen=True, slots=True)
class InjectionSecret:
    """프록시 메모리에만 머무는 값. 로그에 쓰지 않는다."""

    credential_id: CredentialId
    kind: CredentialKind
    secret: str
    header_name: str | None = None


@dataclass(frozen=True, slots=True)
class RecordCredentialEvent:
    workspace_id: WorkspaceId
    credential_id: CredentialId
    action: CredentialAction
    now: datetime
    session_id: SessionId | None = None
    host: str | None = None
    generation: int | None = None


class CredentialStore(Protocol):
    """**평문은 `insert`·`rotate`(입력)와 `reveal_for_injection`(출력)만 지난다.**

    `stale_key_versions` / `rewrap` 은 키 로테이션의 백그라운드 축이다
    (`plan/05` §7). 평문이 **프로세스 메모리에만** 머물고 호출자에게
    돌아가지 않는 것이 요점이다 — 그래서 `rewrap` 이 `bool` 을 돌려준다.
    """

    async def insert(self, cmd: InsertCredential) -> CredentialMeta: ...
    async def find(
        self, workspace_id: WorkspaceId, credential_id: CredentialId
    ) -> CredentialMeta | None: ...
    async def list_in_vault(self, q: ListQuery, vault_id: VaultId) -> Page[CredentialMeta]: ...
    async def rotate(self, cmd: RotateCredential) -> CredentialMeta | None: ...
    async def archive(
        self, workspace_id: WorkspaceId, credential_id: CredentialId, now: datetime
    ) -> bool: ...
    async def reveal_for_injection(self, q: RevealForInjection) -> InjectionSecret | None:
        """**프록시가 쓴다.** `mcp_oauth` 는 access token 만 나간다."""
        ...

    async def reveal_oauth(self, q: RevealOAuth) -> OAuthTokens | None:
        """**제어 평면이 쓴다.** 갱신 토큰이 나가는 유일한 경로."""
        ...

    async def record_refresh(self, cmd: RecordRefresh) -> CredentialMeta | None: ...
    async def record_event(self, cmd: RecordCredentialEvent) -> None: ...
    async def stale_key_versions(
        self, workspace_id: WorkspaceId, *, limit: int = 100
    ) -> tuple[CredentialId, ...]:
        """현재 키 버전보다 뒤처진 자격증명. **배치가 고르는 경로.**"""
        ...

    async def rewrap(self, workspace_id: WorkspaceId, credential_id: CredentialId) -> bool:
        """옛 키로 열어 새 키로 다시 봉한다. 이미 최신이면 `False`."""
        ...
