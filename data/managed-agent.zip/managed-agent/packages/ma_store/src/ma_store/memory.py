"""MemoryStoreStore · MemoryDocumentStore (D10)."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Protocol

from ma_domain.ids import MemoryId, MemoryStoreId, MemoryVersionId, WorkspaceId
from ma_domain.memory import Memory, MemoryVersion, validate_write
from ma_domain.memory import MemoryStore as MemoryStoreEntity

from ma_store._results import ListQuery, NotFound, Page, VersionConflict


@dataclass(frozen=True, slots=True)
class InsertMemoryStore:
    id: MemoryStoreId
    workspace_id: WorkspaceId
    name: str
    slug: str
    now: datetime


class MemoryStoreStore(Protocol):
    async def insert(self, cmd: InsertMemoryStore) -> MemoryStoreEntity: ...
    async def find(
        self, workspace_id: WorkspaceId, store_id: MemoryStoreId
    ) -> MemoryStoreEntity | None: ...
    async def find_by_slug(
        self, workspace_id: WorkspaceId, slug: str
    ) -> MemoryStoreEntity | None: ...
    async def list_stores(self, q: ListQuery) -> Page[MemoryStoreEntity]: ...
    async def archive(
        self, workspace_id: WorkspaceId, store_id: MemoryStoreId, now: datetime
    ) -> bool: ...


@dataclass(frozen=True, slots=True)
class WriteMemory:
    """CAS는 `precondition_sha256`으로. None이면 신규 생성(이미 있으면 충돌)."""

    id: MemoryId
    workspace_id: WorkspaceId
    store_id: MemoryStoreId
    path: str
    content: str
    author: str
    now: datetime
    precondition_sha256: str | None = None

    def __post_init__(self) -> None:
        # **두 구현이 같은 입력을 같은 예외로 거부해야 한다.**
        # 명령 객체가 그 공통 지점이다 — SQL 구현은 도메인 객체를
        # 거치지 않고 INSERT 로 바로 가기 때문이다.
        validate_write(self.path, self.content)


@dataclass(frozen=True, slots=True)
class WrittenMemory:
    memory: Memory
    version: MemoryVersion


@dataclass(frozen=True, slots=True)
class PathConflict:
    """같은 경로에 다른 메모리가 이미 있다."""

    conflicting_memory_id: MemoryId


type WriteMemoryResult = WrittenMemory | PathConflict | VersionConflict | NotFound


class MemoryDocumentStore(Protocol):
    async def write(self, cmd: WriteMemory) -> WriteMemoryResult: ...
    async def find(self, workspace_id: WorkspaceId, memory_id: MemoryId) -> Memory | None: ...
    async def find_by_path(
        self, workspace_id: WorkspaceId, store_id: MemoryStoreId, path: str
    ) -> Memory | None: ...
    async def list_in_store(self, q: ListQuery, store_id: MemoryStoreId) -> Page[Memory]: ...
    async def delete(
        self, workspace_id: WorkspaceId, memory_id: MemoryId, now: datetime
    ) -> bool: ...
    async def list_versions(self, q: ListQuery, store_id: MemoryStoreId) -> Page[MemoryVersion]: ...
    async def redact_version(
        self, workspace_id: WorkspaceId, version_id: MemoryVersionId, by: str, now: datetime
    ) -> bool:
        """live head는 거부한다."""
        ...
