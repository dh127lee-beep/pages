"""ModelCardStore — 모델을 설정으로 만드는 저장소 (D12)."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Protocol

from ma_domain.ids import ModelCardId, WorkspaceId
from ma_domain.models import ModelCard

from ma_store._results import ListQuery, Page


@dataclass(frozen=True, slots=True)
class UpsertModelCard:
    card: ModelCard
    now: datetime


class ModelCardStore(Protocol):
    async def upsert(self, cmd: UpsertModelCard) -> ModelCard: ...
    async def find(self, workspace_id: WorkspaceId, card_id: ModelCardId) -> ModelCard | None: ...
    async def list_enabled(self, q: ListQuery) -> Page[ModelCard]: ...
    async def archive(
        self, workspace_id: WorkspaceId, card_id: ModelCardId, now: datetime
    ) -> bool: ...
