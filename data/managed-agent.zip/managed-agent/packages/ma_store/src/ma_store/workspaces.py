"""WorkspaceStore · MembershipStore · ApiKeyStore."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Protocol

from ma_domain.ids import ApiKeyId, UserId, WorkspaceId
from ma_domain.workspaces import ApiKey, Membership, Role, User, Workspace, WorkspaceSettings

from ma_store._results import ListQuery, Page


@dataclass(frozen=True, slots=True)
class InsertWorkspace:
    id: WorkspaceId
    name: str
    slug: str
    settings: WorkspaceSettings
    now: datetime


@dataclass(frozen=True, slots=True)
class UpdateWorkspaceSettings:
    workspace_id: WorkspaceId
    settings: WorkspaceSettings


class WorkspaceStore(Protocol):
    async def insert(self, cmd: InsertWorkspace) -> Workspace: ...
    async def find(self, workspace_id: WorkspaceId) -> Workspace | None: ...
    async def find_by_slug(self, slug: str) -> Workspace | None: ...
    async def update_settings(self, cmd: UpdateWorkspaceSettings) -> Workspace | None: ...
    async def list_all(self, q: ListQuery) -> Page[Workspace]: ...


@dataclass(frozen=True, slots=True)
class UpsertMembership:
    workspace_id: WorkspaceId
    user_id: UserId
    role: Role
    now: datetime


class MembershipStore(Protocol):
    async def upsert_user(self, user: User) -> User: ...
    async def find_user(self, user_id: UserId) -> User | None: ...
    async def upsert(self, cmd: UpsertMembership) -> Membership: ...
    async def find(self, workspace_id: WorkspaceId, user_id: UserId) -> Membership | None: ...
    async def remove(self, workspace_id: WorkspaceId, user_id: UserId) -> bool: ...
    async def list_members(self, q: ListQuery) -> Page[Membership]: ...
    async def list_for_user(self, user_id: UserId) -> tuple[Membership, ...]: ...


@dataclass(frozen=True, slots=True)
class InsertApiKey:
    id: ApiKeyId
    workspace_id: WorkspaceId
    name: str
    key_hash: bytes
    key_prefix: str
    role: Role
    created_by: UserId
    now: datetime
    expires_at: datetime | None = None


class ApiKeyStore(Protocol):
    """평문은 저장하지 않는다. 발급 시 한 번만 호출자에게 돌려준다."""

    async def insert(self, cmd: InsertApiKey) -> ApiKey: ...
    async def find_by_hash(self, key_hash: bytes) -> ApiKey | None: ...
    async def touch_used(self, key_id: ApiKeyId, now: datetime) -> None: ...
    async def revoke(self, workspace_id: WorkspaceId, key_id: ApiKeyId, now: datetime) -> bool: ...
    async def list_keys(self, q: ListQuery) -> Page[ApiKey]: ...
