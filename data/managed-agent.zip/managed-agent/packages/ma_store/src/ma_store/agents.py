"""AgentStore — 버전 관리 리소스의 **표준형**.

`plan/03-layers.md` §3 L3 · §6.

`skills` · `environments`도 같은 모양이다. 새 버전 관리 리소스를 추가할 때
이 파일을 복사하면 된다.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Protocol

from ma_domain.agents import AgentDefinition, AgentRecord
from ma_domain.ids import AgentId, WorkspaceId

from ma_store._results import ArchiveResult, ListQuery, Page, ReplaceResult


@dataclass(frozen=True, slots=True)
class InsertAgent:
    id: AgentId
    workspace_id: WorkspaceId
    definition: AgentDefinition
    created_by: str
    now: datetime


@dataclass(frozen=True, slots=True)
class FindCurrentAgent:
    workspace_id: WorkspaceId
    id: AgentId
    include_archived: bool = False


@dataclass(frozen=True, slots=True)
class FindAgentVersion:
    workspace_id: WorkspaceId
    id: AgentId
    version: int


@dataclass(frozen=True, slots=True)
class ReplaceAgent:
    workspace_id: WorkspaceId
    id: AgentId
    definition: AgentDefinition
    expected_version: int
    now: datetime


@dataclass(frozen=True, slots=True)
class ArchiveAgent:
    workspace_id: WorkspaceId
    id: AgentId
    expected_version: int
    now: datetime


@dataclass(frozen=True, slots=True)
class ListAgentVersions:
    workspace_id: WorkspaceId
    id: AgentId
    limit: int = 50


class AgentStore(Protocol):
    """에이전트 저장소.

    모든 입력에 `workspace_id`가 있다 — 도메인에 "테넌트" 개념은 없고
    호스트가 주는 파티션 키일 뿐이다.
    """

    async def insert(self, cmd: InsertAgent) -> AgentRecord: ...

    async def find_current(self, q: FindCurrentAgent) -> AgentRecord | None: ...

    async def find_version(self, q: FindAgentVersion) -> AgentRecord | None: ...

    async def replace_current(self, cmd: ReplaceAgent) -> ReplaceResult[AgentRecord]: ...

    async def archive_current(self, cmd: ArchiveAgent) -> ArchiveResult[AgentRecord]: ...

    async def list_current(self, q: ListQuery) -> Page[AgentRecord]: ...

    async def list_versions(self, q: ListAgentVersions) -> Page[AgentRecord]: ...
