"""SessionEventStore · PendingEventStore — 이중 테이블 (D4).

`plan/02-architecture.md` §4.

**`seq`는 promote 시점에 부여된다.** 도착 시점이 아니다. 그래야 `ORDER BY seq`가
"모델이 본 순서"가 된다.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Protocol

from ma_domain.events import PendingEvent, SessionEvent
from ma_domain.ids import EventId, SessionId, ThreadId, WorkspaceId

from ma_store._results import NotFound, VersionConflict


@dataclass(frozen=True, slots=True)
class AdmitEvents:
    """입력 수용 — **한 트랜잭션**으로 처리된다.

    revision CAS가 실패하면 롤백되므로 pending·interrupt·outbox 중 어느 것도 새지 않는다.
    `lane_batches`는 `(lane_id, execution_id, event_ids)` — outbox에 넣을 실행 단위다.
    """

    workspace_id: WorkspaceId
    session_id: SessionId
    expected_revision: int
    events: tuple[PendingEvent, ...]
    lane_batches: tuple[tuple[ThreadId, EventId, tuple[EventId, ...]], ...] = ()
    interrupt_lanes: tuple[ThreadId, ...] = ()
    now: datetime | None = None
    #: W3C trace 컨텍스트. outbox 행에 실어 **워커가 이어받는다**
    #: (`ma_observability.trace`). 워커는 요청을 받지 않고 큐를 긁어
    #: 가므로 헤더로는 이을 수 없다.
    trace_context: tuple[tuple[str, str], ...] = ()


@dataclass(frozen=True, slots=True)
class Admitted:
    accepted: tuple[EventId, ...]
    revision: int


type AdmitResult = Admitted | NotFound | VersionConflict


@dataclass(frozen=True, slots=True)
class ReadEvents:
    workspace_id: WorkspaceId
    session_id: SessionId
    after_seq: int | None = None
    thread_id: ThreadId | None = None
    limit: int = 1000


@dataclass(frozen=True, slots=True)
class PromoteEvent:
    """pending → events. **peek → INSERT → DELETE** 순서로 구현해야 한다.

    반대 순서면 크래시 시 이벤트가 사라진다. 이 순서면 중복이 생기고,
    중복은 `event_id` 유니크 인덱스가 막는다.
    """

    workspace_id: WorkspaceId
    session_id: SessionId
    event_id: EventId
    generation: int
    now: datetime


class SessionEventStore(Protocol):
    async def admit(self, cmd: AdmitEvents) -> AdmitResult: ...
    async def append(self, event: SessionEvent, *, generation: int) -> SessionEvent: ...
    async def promote(self, cmd: PromoteEvent) -> SessionEvent | None: ...
    async def read(self, q: ReadEvents) -> tuple[SessionEvent, ...]: ...
    async def find_by_id(
        self, workspace_id: WorkspaceId, session_id: SessionId, event_id: EventId
    ) -> SessionEvent | None: ...
    async def max_seq(self, workspace_id: WorkspaceId, session_id: SessionId) -> int: ...


class PendingEventStore(Protocol):
    async def enqueue(self, event: PendingEvent) -> PendingEvent:
        """큐에 넣는다. `id`가 멱등키 — 같은 입력이 두 번 들어가지 않는다."""
        ...

    async def peek(
        self, workspace_id: WorkspaceId, session_id: SessionId, thread_id: ThreadId, limit: int = 50
    ) -> tuple[PendingEvent, ...]: ...
    async def delete(
        self, workspace_id: WorkspaceId, session_id: SessionId, event_id: EventId
    ) -> bool: ...
    async def cancel_lane(
        self, workspace_id: WorkspaceId, session_id: SessionId, thread_id: ThreadId, now: datetime
    ) -> int: ...
    async def find_by_id(
        self, workspace_id: WorkspaceId, session_id: SessionId, event_id: EventId
    ) -> PendingEvent | None: ...
