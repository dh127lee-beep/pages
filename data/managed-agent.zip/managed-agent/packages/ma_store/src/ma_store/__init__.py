"""AWP · 도메인별 Store 인터페이스 (Protocol)"""
