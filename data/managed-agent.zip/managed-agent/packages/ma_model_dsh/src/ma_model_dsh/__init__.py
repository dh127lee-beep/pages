"""AWP · DeepSeek Harness 대안 하네스 (2단계)"""
