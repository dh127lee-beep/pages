"""스킬 마운트 — **읽기 전용, 되돌리지 않는다** (T-0602).

`plan/01-product-concept.md` §4 · `task/M5-extensions/T-0602-skills.md`.

```
세션 웜업                          턴 종료
─────────                         ───────
skills (SQL, 핀된 버전)             (아무것도 안 한다)
  → /mnt/skills/<slug>/              스킬은 사람이 만드는 자산이고
  → **읽기 전용**                     세션이 고치면 부서 지식이 흔들린다
  → 카탈로그는 프롬프트 접두사로
```

메모리(D10)·파일(T-0502)과 비교하면 **가장 단순하다**:

| | 방향 | 턴 종료 |
|---|---|---|
| 메모리 | 양방향 | CAS 로 되돌린다 |
| 업로드 파일 | 입력 단방향 | 없다 |
| 산출물 | 출력 단방향 | 수거한다 |
| **스킬** | **입력 단방향** | **없다** |

파일을 직접 열지 않는다 — `write_file` 을 주입받는다 (`ADR-0008`).
"""

from __future__ import annotations

import logging
from collections.abc import Awaitable, Callable, Sequence
from typing import TYPE_CHECKING

from ma_domain.skills import MountedSkill, SkillCatalogEntry, catalog_text

if TYPE_CHECKING:
    from ma_domain.skills import SkillRecord

_log = logging.getLogger("ma_harness.skills_mount")


async def mount_skills(
    skills: Sequence[SkillRecord],
    *,
    write_file: Callable[[str, str], Awaitable[None]],
) -> tuple[MountedSkill, ...]:
    """`/mnt/skills/<slug>/` 에 푼다.

    **slug 가 겹치면 뒤엣것을 건너뛴다.** DB 의 유니크 인덱스가 먼저
    막지만, 아카이브된 스킬의 버전을 핀한 에이전트가 있을 수 있다 —
    그때는 두 레코드가 같은 slug 를 가질 수 있고, 덮어쓰면 하나가
    조용히 사라진다.
    """
    seen: set[str] = set()
    out: list[MountedSkill] = []
    for skill in skills:
        if skill.slug in seen:
            _log.warning("스킬 slug 가 겹쳐 건너뛴다 slug=%s skill=%s", skill.slug, skill.id)
            continue
        seen.add(skill.slug)
        written: list[str] = []
        for f in skill.document.files:
            await write_file(f"{skill.mount_path}/{f.path}", f.content)
            written.append(f.path)
        out.append(
            MountedSkill(
                skill_id=skill.id,
                slug=skill.slug,
                mount_path=skill.mount_path,
                files=tuple(written),
            )
        )
    return tuple(out)


def catalog_for(skills: Sequence[SkillRecord]) -> str:
    """프롬프트 접두사에 들어갈 카탈로그.

    > **매 턴 같아야 한다** (D12b). `catalog_text` 가 slug 로 정렬하고,
    > 빈 목록이면 **빈 문자열**이다 — "스킬 없음" 같은 줄을 넣으면
    > 스킬이 하나 생기는 순간 접두사가 바뀐다.

    **파일 내용을 넣지 않는다.** 점진적 공개가 요점이다 — 한 줄만
    넣고 필요하면 모델이 파일을 읽는다. 본문을 넣으면 토큰이 스킬
    수에 비례해 늘고, 그중 대부분은 그 턴에 쓰이지 않는다.
    """
    return catalog_text(
        [
            SkillCatalogEntry(
                slug=s.slug,
                description=s.document.description,
                mount_path=s.mount_path,
                file_count=len(s.document.files),
            )
            for s in skills
        ]
    )


__all__ = ["catalog_for", "mount_skills"]
