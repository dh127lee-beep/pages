"""업로드 파일 마운트와 산출물 수거 (T-0502).

`plan/04-api.md` §3.4 · `plan/08-infrastructure.md` §6 ·
`task/M4-productization/T-0502-files-outputs.md`.

```
세션 웜업                      턴 종료 (turn_stopping)
─────────                     ──────────────────────
files (업로드 완료분)            outputs/ 디렉터리 훑기
  → /mnt/files/<safe_name>       → blob.put + 행
  → **읽기 전용**                 → 세대를 함께 남긴다 (D3)
```

**마운트는 읽기 전용이다.** 업로드 파일은 사람이 올린 입력이고,
에이전트가 그것을 고치면 다음 세션이 다른 입력을 본다. 고쳐야 할
것은 **산출물로 내보낸다** — 그쪽은 새 행이 생기므로 원본이 남는다.

메모리(`memory_sync`)와 대칭이지만 **되돌리지 않는다**: 메모리는
양방향 동기화고, 파일은 입력 단방향 + 산출물 단방향이다.

파일을 직접 열지 않는다 — `write_file` · `read_file` · `list_files` 를
주입받는다 (`ADR-0008` 워크스페이스 경계 단일 진입점).
"""

from __future__ import annotations

import logging
import posixpath
from collections.abc import Awaitable, Callable, Sequence
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from ma_domain.files import OUTPUT_DIR, UPLOAD_MOUNT

if TYPE_CHECKING:
    from ma_domain.files import FileMeta
    from ma_domain.ids import SessionId, WorkspaceId

    from ma_harness.hooks import HookSet, TurnStopping

_log = logging.getLogger("ma_harness.file_mount")

#: 한 세션이 내보낼 수 있는 산출물 수. 넘으면 **잘렸다고 로그에 남긴다.**
MAX_OUTPUTS = 200

#: 산출물 하나의 상한. 샌드박스가 거대한 파일을 만들어 오브젝트 스토어
#: 요금을 태우는 것을 막는다.
MAX_OUTPUT_BYTES = 100 * 1024 * 1024


@dataclass(frozen=True, slots=True)
class MountedFile:
    file_id: str
    mount_path: str
    #: 항상 True. **필드로 두는 이유**: 나중에 rw 마운트를 넣고 싶어질
    #: 때 "그때 왜 ro 였는가"를 이 자리에서 다시 읽게 하려고.
    read_only: bool = True


@dataclass(frozen=True, slots=True)
class CollectedOutput:
    path: str
    content: bytes


@dataclass(frozen=True, slots=True)
class CollectReport:
    collected: int = 0
    skipped: tuple[str, ...] = ()
    truncated: bool = False


async def mount_uploads(
    files: Sequence[FileMeta],
    *,
    read_blob: Callable[[str], Awaitable[bytes]],
    write_file: Callable[[str, bytes], Awaitable[None]],
) -> tuple[MountedFile, ...]:
    """업로드 파일을 `/mnt/files/<safe_name>` 에 놓는다.

    **미완성 행은 건너뛴다** (`is_complete`). 바이트가 없는 파일을
    마운트하면 에이전트가 빈 파일을 읽고 "내용이 없다"고 보고한다 —
    업로드가 아직 안 끝난 것인데.

    **같은 `safe_name` 이 겹치면 뒤엣것을 건너뛴다.** 덮어쓰면 두
    파일 중 하나가 조용히 사라지고, 에이전트는 그것을 알 수 없다.
    """
    seen: set[str] = set()
    out: list[MountedFile] = []
    for meta in files:
        if not meta.is_complete:
            _log.info("미완성 파일을 마운트하지 않는다 file=%s", meta.id)
            continue
        path = meta.mount_path()
        if path in seen:
            _log.warning(
                "마운트 경로가 겹쳐 건너뛴다 path=%s file=%s (safe_name 충돌)",
                path,
                meta.id,
            )
            continue
        await write_file(path, await read_blob(meta.storage_key))
        seen.add(path)
        out.append(MountedFile(file_id=meta.id, mount_path=path))
    return tuple(out)


def is_output_path(path: str) -> bool:
    """`outputs/` 안인가. **경로를 정규화해서 본다.**

    `outputs/../../etc/passwd` 가 접두사 검사만으로 통과하면 샌드박스
    밖의 파일이 산출물로 업로드된다.
    """
    normalized = posixpath.normpath(path)
    if normalized.startswith(("/", "../")) or normalized == "..":
        return False
    return normalized == OUTPUT_DIR or normalized.startswith(f"{OUTPUT_DIR}/")


def relative_output(path: str) -> str:
    """`outputs/reports/q3.pdf` → `reports/q3.pdf`."""
    return posixpath.normpath(path)[len(OUTPUT_DIR) + 1 :]


async def collect_outputs(
    *,
    list_dir: Callable[[str], Awaitable[Sequence[str]]],
    read_file: Callable[[str], Awaitable[bytes]],
) -> tuple[tuple[CollectedOutput, ...], CollectReport]:
    """`outputs/` 를 훑어 수거 대상을 모은다. **업로드는 하지 않는다.**

    업로드는 유스케이스가 한다 (`FilesUseCases.record_output`) — 하네스가
    `BlobPort` 를 들면 "무엇이 오브젝트 스토어에 쓸 수 있는가"가
    하네스 구현마다 달라진다.
    """
    paths = list(await list_dir(OUTPUT_DIR))
    truncated = len(paths) > MAX_OUTPUTS
    if truncated:
        _log.warning("산출물이 %d개를 넘는다 — 잘라서 수거한다", MAX_OUTPUTS)
        paths = paths[:MAX_OUTPUTS]

    collected: list[CollectedOutput] = []
    skipped: list[str] = []
    for path in sorted(paths):
        if not is_output_path(path):
            # **경로가 빠져나갔다.** 수거하면 샌드박스 밖 파일이 나간다.
            _log.warning("산출물 경로가 outputs/ 밖이다 — 건너뛴다 path=%s", path)
            skipped.append(path)
            continue
        content = await read_file(path)
        if len(content) > MAX_OUTPUT_BYTES:
            _log.warning("산출물이 상한을 넘어 건너뛴다 path=%s size=%d", path, len(content))
            skipped.append(path)
            continue
        collected.append(CollectedOutput(path=relative_output(path), content=content))

    return tuple(collected), CollectReport(
        collected=len(collected), skipped=tuple(skipped), truncated=truncated
    )


@dataclass
class OutputCollector:
    """`turn_stopping` 에 거는 것. **메모리 동기화와 같은 자리다.**

    산출물이 `idle` 뒤로 밀리면 클라이언트가 "끝났다"를 보고 목록을
    조회하는데 아직 비어 있다.
    """

    workspace_id: WorkspaceId
    session_id: SessionId
    list_dir: Callable[[str], Awaitable[Sequence[str]]]
    read_file: Callable[[str], Awaitable[bytes]]
    #: `FilesUseCases.record_output` 을 감싼 것. 하네스는 Store 를 모른다.
    record: Callable[[str, bytes, int], Awaitable[None]]
    reports: list[CollectReport] = field(default_factory=list)

    async def __call__(self, payload: TurnStopping) -> None:
        found, report = await collect_outputs(list_dir=self.list_dir, read_file=self.read_file)
        for item in found:
            await self.record(item.path, item.content, payload.fence.generation)
        self.reports.append(report)


def install(hooks: HookSet, collector: OutputCollector) -> None:
    """조립이 부르는 유일한 함수 — `memory_sync.install` 과 같은 모양."""
    hooks.turn_stopping.add(collector)


def prompt_hint(mounts: Sequence[MountedFile]) -> str:
    """시스템 프롬프트 접두사에 들어갈 안내.

    **정렬한다** — 매 턴 같은 문자열이어야 캐시 접두사가 안정적이다
    (D12b, `plan/06` §5).
    """
    lines = [f"내보낼 파일은 `{OUTPUT_DIR}/` 아래에 쓴다. 턴이 끝날 때 수거된다."]
    if mounts:
        lines.insert(0, f"업로드된 파일이 `{UPLOAD_MOUNT}/` 에 있다 (읽기 전용):")
        lines[1:1] = [f"  {m.mount_path}" for m in sorted(mounts, key=lambda m: m.mount_path)]
    return "\n".join(lines)


__all__ = [
    "MAX_OUTPUTS",
    "MAX_OUTPUT_BYTES",
    "CollectReport",
    "CollectedOutput",
    "MountedFile",
    "OutputCollector",
    "collect_outputs",
    "install",
    "is_output_path",
    "mount_uploads",
    "prompt_hint",
    "relative_output",
]
