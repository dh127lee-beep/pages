"""ModelPort — provider 중립 모델 호출 (D12).

`plan/06-harness-and-model.md` §1 · `ADR-0005`.

**모델은 코드가 아니라 설정이다.** 모델 ID·한도·추론 파라미터 이름·요금이 전부
`model_cards`의 선언이고, 하네스는 그 선언을 읽어 적응한다. 이 모듈에는
provider 이름도, 모델 문자열도, wire 포맷도 없다.

어댑터가 하는 일은 하나다: provider별 스트림을 아래 **중립 어휘**로 정규화한다.
하네스 루프는 그 어휘만 안다.

    text_delta · thinking_delta · tool_call_start · tool_call_delta
    tool_call_end · usage · finish · error

이 목록은 **나중에 추가하면 모든 어댑터가 바뀐다.** 그래서 `ADR-0005`에 무엇을
넣고 무엇을 뺐는지 적었다.
"""

from __future__ import annotations

from collections.abc import AsyncIterator, Mapping, Sequence
from dataclasses import dataclass, field
from enum import StrEnum
from typing import TYPE_CHECKING, Protocol

if TYPE_CHECKING:
    import anyio
    from ma_domain.models import EffortIntent, ModelCapabilities, ModelCard, TokenUsage


# ── 요청 쪽 ────────────────────────────────────────────────
@dataclass(frozen=True, slots=True)
class WireMessage:
    """모델에 보낼 메시지 하나. **provider 포맷이 아니다** — 어댑터가 번역한다."""

    role: str  # "system" | "user" | "assistant" | "tool"
    content: str = ""
    #: assistant 가 낸 툴 호출들
    tool_calls: tuple[ToolCall, ...] = ()
    #: role="tool" 일 때 어느 호출에 대한 답인가
    tool_call_id: str | None = None
    #: 추론 블록. provider 가 지원하면 어댑터가 실어 보낸다.
    thinking: str | None = None


@dataclass(frozen=True, slots=True)
class ToolCall:
    id: str
    name: str
    #: JSON 문자열. 파싱은 툴 레지스트리의 일이다 (T-0305).
    arguments: str = ""


@dataclass(frozen=True, slots=True)
class ToolSchema:
    name: str
    description: str
    #: JSON Schema. 그대로 전달된다.
    parameters: Mapping[str, object] = field(default_factory=dict)


# ── 응답 쪽 — 중립 어휘 ────────────────────────────────────
class StreamEventKind(StrEnum):
    """`ADR-0005`. **여기에 추가하면 모든 어댑터가 바뀐다.**"""

    TEXT_DELTA = "text_delta"
    THINKING_DELTA = "thinking_delta"
    TOOL_CALL_START = "tool_call_start"
    TOOL_CALL_DELTA = "tool_call_delta"
    TOOL_CALL_END = "tool_call_end"
    USAGE = "usage"
    FINISH = "finish"
    ERROR = "error"


class FinishReason(StrEnum):
    """왜 멈췄는가. **`TOOL_CALLS`와 `STOP`을 가르는 것이 턴 루프의 분기점이다.**"""

    STOP = "stop"
    TOOL_CALLS = "tool_calls"
    MAX_TOKENS = "max_tokens"
    CONTENT_FILTER = "content_filter"
    CANCELLED = "cancelled"
    ERROR = "error"


@dataclass(frozen=True, slots=True)
class ModelStreamEvent:
    """스트림의 한 조각. 어댑터가 provider SSE 를 이것으로 정규화한다."""

    kind: StreamEventKind
    #: TEXT_DELTA · THINKING_DELTA 의 내용
    text: str = ""
    #: TOOL_CALL_* 가 가리키는 호출
    tool_call_id: str | None = None
    tool_name: str | None = None
    #: TOOL_CALL_DELTA 의 인자 조각 (JSON 문자열의 일부)
    arguments_delta: str = ""
    #: USAGE
    usage: TokenUsage | None = None
    #: FINISH
    finish_reason: FinishReason | None = None
    #: ERROR
    error: ModelError | None = None


@dataclass(frozen=True, slots=True)
class ModelError:
    """provider 에러를 중립화한 것.

    `retryable`이 **이 타입의 존재 이유**다. 하네스는 429 와 500 을 구별할 필요가
    없고, "다시 걸어도 되는가"만 알면 된다 (`IMPL-0009`에 분류표).
    """

    kind: str  # "rate_limit" | "overloaded" | "bad_request" | "auth" | "timeout" | ...
    message: str
    retryable: bool
    status: int | None = None
    #: provider 가 알려준 대기 시간(초). 없으면 호출자가 백오프를 정한다.
    retry_after: float | None = None


class ModelPort(Protocol):
    """어댑터가 구현하는 유일한 인터페이스.

    새 provider 를 붙이는 비용 = 파일 하나 + 계약 테스트 통과.
    하네스·API·DB 는 무변경이다.
    """

    def describe(self, card: ModelCard) -> ModelCapabilities:
        """카드 선언을 사실로 좁힌다. 네트워크를 쓰지 않는다."""
        ...

    def stream(
        self,
        card: ModelCard,
        *,
        messages: Sequence[WireMessage],
        tools: Sequence[ToolSchema] = (),
        effort: EffortIntent | None = None,
        max_tokens: int | None = None,
        signal: anyio.Event | None = None,
    ) -> AsyncIterator[ModelStreamEvent]:
        """**항상 스트리밍이다.**

        최대 출력이 384K 토큰이다. 비스트리밍으로 받으면 HTTP 타임아웃에 걸린다
        (`plan/06` §2).

        `signal`이 세워지면 어댑터는 연결을 끊고 `FINISH(CANCELLED)`를 낸 뒤
        종료해야 한다 — 인터럽트가 모델 호출 중에 도착하는 것이 정상이다.
        """
        ...


__all__ = [
    "FinishReason",
    "ModelError",
    "ModelPort",
    "ModelStreamEvent",
    "StreamEventKind",
    "ToolCall",
    "ToolSchema",
    "WireMessage",
]
