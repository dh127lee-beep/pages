"""waterfall 훅 6개 — 루프를 고치지 않고 정책을 끼우는 지점.

`plan/06-harness-and-model.md` §4.2 · `ADR-0006`.

각 리스너는 `next()`로 다음 리스너에 위임한다. 위임하지 않으면 **거기서 멈춘다** —
그것이 거부·단락의 표현 방법이다. 예외로 거부를 표현하지 않는 이유는, 예외는
"정책이 막았다"와 "코드가 터졌다"를 구별하지 못하기 때문이다.

```
pre_step      입력 재작성/거부      예산 초과 거부, 인터럽트 확인
pre_request   요청 직전             캐시 진단, 요청 크기 상한
pre_execute   툴 실행 전            권한 정책 판정, 예산, 감사
execute       실행 자체             샌드박스 / 호스트 함수 / MCP
post_execute  결과 후처리           spill, 레다크션, 감사
turn_stopping 턴 종료 직전          메모리 동기화, 사용량 확정  (serial)
```

`turn_stopping`만 **serial** 이다 — `next()`가 없고 등록된 순서대로 전부 돈다.
"종료 직전에 할 일"은 서로를 막을 이유가 없고, 하나가 멈추면 나머지가 안 도는
것이 더 나쁘다 (메모리는 동기화됐는데 사용량이 안 적립되는 식).
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable, Sequence
from dataclasses import dataclass, field
from enum import StrEnum
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ma_domain.events import PendingEvent
    from ma_domain.executions import ExecutionFence
    from ma_domain.ids import SessionId, WorkspaceId

    from ma_harness.model_port import ToolCall, WireMessage


class HookPoint(StrEnum):
    """`ADR-0006`. **나중에 추가하면 모든 리스너가 영향받는다.**"""

    PRE_STEP = "pre_step"
    PRE_REQUEST = "pre_request"
    PRE_EXECUTE = "pre_execute"
    EXECUTE = "execute"
    POST_EXECUTE = "post_execute"
    TURN_STOPPING = "turn_stopping"


# ── 훅마다 흐르는 것 ───────────────────────────────────────
@dataclass(frozen=True, slots=True)
class StepInput:
    """`pre_step` — 이번 step 이 볼 입력."""

    workspace_id: WorkspaceId
    session_id: SessionId
    promoted: tuple[PendingEvent, ...]
    #: 거부 사유. 비어 있지 않으면 step 없이 턴을 끝낸다.
    rejected: str | None = None

    def reject(self, reason: str) -> StepInput:
        from dataclasses import replace

        return replace(self, rejected=reason)


@dataclass(frozen=True, slots=True)
class RequestDraft:
    """`pre_request` — 동결 **직전**의 요청.

    여기서 바꾼 것이 마지막이다. 동결 후에는 재시도해도 이 내용 그대로 간다.
    """

    messages: tuple[WireMessage, ...]
    max_tokens: int | None = None
    #: 리스너가 남기는 진단. 로그로만 나간다.
    notes: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class ToolInvocation:
    """`pre_execute` · `execute` · `post_execute` 를 흐르는 것."""

    call: ToolCall
    #: 정책 판정 결과. `pre_execute` 가 채운다.
    decision: ToolDecision | None = None
    result: ToolOutcome | None = None


class Verdict(StrEnum):
    ALLOW = "allow"
    ASK = "ask"
    DENY = "deny"


@dataclass(frozen=True, slots=True)
class ToolDecision:
    verdict: Verdict
    reason: str = ""


@dataclass(frozen=True, slots=True)
class ToolOutcome:
    content: str
    is_error: bool = False
    #: 상한 초과로 파일에 흘린 경우의 경로.
    spilled_to: str | None = None


@dataclass(frozen=True, slots=True)
class TurnStopping:
    """`turn_stopping` 에 실려 가는 것. **턴이 `idle` 로 보이기 전이다.**

    리스너가 필요로 하는 바깥 것들(Store·마운트 목록·파일시스템)은 조립
    시점의 클로저로 들어온다. 여기 실리는 것은 **턴에서만 알 수 있는
    것** 뿐이다 — 특히 `fence` 가 그렇다.

    `fence` 가 실리는 이유: 리스너는 쓰기 전에 소유권을 **다시** 확인해야
    한다. 턴이 도는 동안 lease 가 넘어갔을 수 있고, 그때 쓰면 새 소유자가
    쓴 것을 덮는다 (D3).
    """

    fence: ExecutionFence
    stop_reason: str
    #: 턴이 예외로 끝났는가. 동기화는 **그래도 돈다** — 에이전트가 턴
    #: 중간까지 쓴 메모는 버릴 이유가 없다.
    errored: bool = False


# ── waterfall 기계 ─────────────────────────────────────────
type Next[T] = Callable[[T], Awaitable[T]]
type Listener[T] = Callable[[T, Next[T]], Awaitable[T]]


@dataclass
class Waterfall[T]:
    """등록 순서대로 감싼다. 먼저 등록한 것이 **바깥**이다.

    바깥쪽이 먼저 보고 마지막에 본다 — 감사·측정처럼 전체를 감싸야 하는 것이
    먼저 등록된다.
    """

    listeners: list[Listener[T]] = field(default_factory=list)

    def add(self, listener: Listener[T]) -> Waterfall[T]:
        self.listeners.append(listener)
        return self

    async def run(self, value: T, terminal: Next[T] | None = None) -> T:
        async def passthrough(v: T) -> T:
            return v

        chain: Next[T] = terminal or passthrough
        for listener in reversed(self.listeners):
            chain = _bind(listener, chain)
        return await chain(value)


def _bind[T](listener: Listener[T], nxt: Next[T]) -> Next[T]:
    async def call(value: T) -> T:
        return await listener(value, nxt)

    return call


@dataclass
class SerialHooks[T]:
    """`turn_stopping` 전용. `next()` 가 없고 **전부 돈다**.

    하나가 실패해도 나머지를 돌린다 — 메모리는 동기화됐는데 사용량이 적립되지
    않는 상태가 "둘 다 안 된" 상태보다 나쁘다. 실패는 모아서 돌려준다.
    """

    listeners: list[Callable[[T], Awaitable[None]]] = field(default_factory=list)

    def add(self, listener: Callable[[T], Awaitable[None]]) -> SerialHooks[T]:
        self.listeners.append(listener)
        return self

    async def run(self, value: T) -> tuple[Exception, ...]:
        failures: list[Exception] = []
        for listener in self.listeners:
            try:
                await listener(value)
            except Exception as exc:
                failures.append(exc)
        return tuple(failures)


@dataclass
class HookSet:
    """하네스가 들고 있는 훅 묶음. 조립 시점에 리스너가 등록된다."""

    pre_step: Waterfall[StepInput] = field(default_factory=Waterfall)
    pre_request: Waterfall[RequestDraft] = field(default_factory=Waterfall)
    pre_execute: Waterfall[ToolInvocation] = field(default_factory=Waterfall)
    execute: Waterfall[ToolInvocation] = field(default_factory=Waterfall)
    post_execute: Waterfall[ToolInvocation] = field(default_factory=Waterfall)
    turn_stopping: SerialHooks[TurnStopping] = field(default_factory=SerialHooks)

    def points(self) -> Sequence[HookPoint]:
        return tuple(HookPoint)


__all__ = [
    "HookPoint",
    "HookSet",
    "Listener",
    "Next",
    "RequestDraft",
    "SerialHooks",
    "StepInput",
    "ToolDecision",
    "ToolInvocation",
    "ToolOutcome",
    "TurnStopping",
    "Verdict",
    "Waterfall",
]
