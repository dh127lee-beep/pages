"""`pre_execute` 권한 훅 — **정책은 한 곳에서만 본다.**

`plan/06-harness-and-model.md` §4.3 · `plan/02-architecture.md` §7 ·
`task/M2-sandbox-tools/T-0305-tool-registry.md`.

승인 메커니즘의 핵심은 **에이전트가 "승인이 필요하다"를 배우지 않는다**는
것이다. 모델은 실행할 수 없는 툴을 호출했을 뿐이고, 플랫폼이 턴을 끊는다.
그래서 프롬프트 인젝션으로 우회할 수 없다 — 설득할 상대가 없다.

> **정책을 두 번 보면 승인이 영영 안 열린다.** `build_tools` 가 정책을
> 적용해 executor 를 떼어 두는데, 훅이 정책을 **다시** 읽으면 승인이
> 와서 executor 가 붙어도 `ASK` 가 유지된다. 레퍼런스가 "승인 후에도
> 결과 없이 재개"되던 것과 같은 모양이다.
>
> 그래서 이 훅은 `registry.decide()` 만 부르고, 그것은
> **`executor is None` 하나만** 본다.
"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from ma_harness.hooks import ToolDecision, ToolInvocation, Verdict

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable

    from ma_harness.registry import ToolRegistry


@dataclass
class PermissionHook:
    """`pre_execute` 워터폴에 꽂는다. **거부 사유를 기록한다.**

    기록이 필요한 이유: 승인 대기로 끊긴 턴이 "왜 끊겼는지"를 사용자가
    물어볼 때, 모델의 말이 아니라 **우리 기록**이 답이어야 한다.
    """

    registry: ToolRegistry
    #: 이번 턴에 ASK 로 끊긴 호출들. `requires_action` 을 만들 때 쓴다.
    asked: list[ToolInvocation] = field(default_factory=list)
    denied: list[ToolInvocation] = field(default_factory=list)

    async def __call__(
        self,
        invocation: ToolInvocation,
        nxt: Callable[[ToolInvocation], Awaitable[ToolInvocation]],
    ) -> ToolInvocation:
        decision = self.registry.decide(invocation.call)
        if decision.verdict is Verdict.ASK:
            self.asked.append(invocation)
        elif decision.verdict is Verdict.DENY:
            self.denied.append(invocation)
        # **판정을 실어 내려보낸다.** 여기서 끊지 않는 이유: 뒤의 훅이
        # 로깅·메트릭을 할 수 있어야 하고, 끊는 것은 루프의 일이다.
        return _with_decision(invocation, decision)

    @property
    def blocked(self) -> tuple[ToolInvocation, ...]:
        return (*self.asked, *self.denied)


def _with_decision(invocation: ToolInvocation, decision: ToolDecision) -> ToolInvocation:
    from dataclasses import replace

    return replace(invocation, decision=decision)


def pending_tool_names(asked: Sequence[ToolInvocation]) -> tuple[str, ...]:
    """승인 대기 중인 툴 이름. **정렬해서 돌려준다.**

    순서가 호출마다 흔들리면 `requires_action` 이벤트의 내용이 달라지고,
    그것을 비교하는 테스트와 클라이언트가 함께 깨진다.
    """
    return tuple(sorted({i.call.name for i in asked}))


__all__ = ["PermissionHook", "pending_tool_names"]
