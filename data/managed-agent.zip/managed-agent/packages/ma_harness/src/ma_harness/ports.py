"""Harness · HarnessContext — 플랫폼이 준비하고 하네스가 결정하는 경계.

`plan/02-architecture.md` §2 · `plan/06-harness-and-model.md` §4.5.

**하네스는 무상태다.** 필요한 모든 것은 (1) 이벤트 로그 (2) 에이전트 설정
(3) 샌드박스 파일시스템에서 온다. 인스턴스 변수에 턴 상태를 들고 있으면
크래시 복구가 "다음 claim"으로 끝나지 않는다 — 죽은 워커의 메모리에만 있던
것을 다음 워커가 복원할 수 없기 때문이다.

그래서 이 Protocol 의 모양이 `run(ctx) -> outcome` 하나다. 턴 사이에 하네스
객체에 남는 것이 없어야 한다.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Protocol

from ma_domain.models import TokenUsage
from ma_domain.sessions import RequiredAction, StopReason

if TYPE_CHECKING:
    import anyio
    from ma_domain.agents import AgentDefinition
    from ma_domain.clock import Clock, IdGenerator
    from ma_domain.events import SessionEvent
    from ma_domain.executions import ExecutionFence
    from ma_domain.models import EffortIntent, ModelCard

    from ma_harness.hooks import HookSet
    from ma_harness.model_port import ModelPort
    from ma_harness.registry import ToolRegistry


@dataclass(frozen=True, slots=True)
class HarnessContext:
    """한 턴이 필요한 전부. **플랫폼이 조립해서 넘긴다.**

    하네스가 Store 를 직접 쥐지 않는 이유는, 쥐면 "무엇을 읽을 수 있는가"가
    하네스 구현마다 달라지기 때문이다. 여기 있는 것만이 턴의 입력이다.
    """

    fence: ExecutionFence
    agent: AgentDefinition
    card: ModelCard
    model: ModelPort
    tools: ToolRegistry
    runtime: HarnessRuntime
    hooks: HookSet
    clock: Clock
    ids: IdGenerator
    effort: EffortIntent | None = None
    max_tokens: int | None = None
    #: 인터럽트 신호. 모델 호출 중에 세워질 수 있다.
    signal: anyio.Event | None = None
    #: step 상한. 넘으면 턴을 끝낸다 — 무한 툴 루프를 막는 마지막 방어선.
    max_steps: int = 32


class HarnessRuntime(Protocol):
    """하네스가 바깥에 할 수 있는 일 전부.

    **fence 검증이 여기 들어 있다.** 하네스가 직접 Store 를 부르면 fence 를
    빼먹을 수 있지만, 이 좁은 창구를 통하면 구현이 한 번만 검증하면 된다.
    """

    async def drain_pending(self, fence: ExecutionFence) -> tuple[SessionEvent, ...]:
        """pending → promote. 승격된 것만 돌려준다 (취소된 것은 제외)."""
        ...

    async def read_history(self, fence: ExecutionFence) -> tuple[SessionEvent, ...]:
        """`seq` 순 전체. 압축 경계가 생기면 거기부터 (M4)."""
        ...

    async def append(self, fence: ExecutionFence, event: SessionEvent) -> SessionEvent:
        """**fence 가 현재가 아니면 `ExecutionFenceLost`.** 좀비는 쓰지 못한다."""
        ...

    async def emit(self, fence: ExecutionFence, frame: StreamFrame) -> None:
        """스트림 전용 프레임. **영속되지 않는다** — SSE 로만 나간다."""
        ...

    async def accrue(self, fence: ExecutionFence, usage: TokenUsage, cost_cents: int) -> None: ...

    async def is_interrupted(self, fence: ExecutionFence) -> bool:
        """내구적 인터럽트 플래그. 워커가 죽어도 남는다."""
        ...


@dataclass(frozen=True, slots=True)
class StreamFrame:
    """영속되지 않는 UI 신호. `plan/02-architecture.md` §4."""

    type: str
    text: str = ""
    data: tuple[tuple[str, object], ...] = ()


@dataclass(frozen=True, slots=True)
class HarnessOutcome:
    """턴의 결과. 워커가 이것으로 settle 한다."""

    stop_reason: StopReason
    required_action: RequiredAction | None = None
    steps: int = 0
    usage: TokenUsage = field(default_factory=TokenUsage)
    cost_cents: int = 0
    #: 턴 중 실패했지만 치명적이지 않았던 것들 (재시도한 모델 호출 등).
    recovered: tuple[str, ...] = ()
    error: str | None = None

    @property
    def awaits_human(self) -> bool:
        return self.stop_reason is StopReason.REQUIRES_ACTION


class Harness(Protocol):
    name: str

    async def run(self, ctx: HarnessContext) -> HarnessOutcome: ...


#: 비용 계산을 주입받는다 — 하네스가 요금표를 알면 D12 가 깨진다.
type CostFn = Callable[[ModelCard, TokenUsage], int]
#: 테스트가 비용을 끄고 싶을 때.
ZERO_COST: CostFn = lambda card, usage: 0  # noqa: E731


__all__ = [
    "ZERO_COST",
    "CostFn",
    "Harness",
    "HarnessContext",
    "HarnessOutcome",
    "HarnessRuntime",
    "StreamFrame",
]
