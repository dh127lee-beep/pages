"""`stop_reason` 결정 — **툴의 `kind` 로 정하고 이름을 보지 않는다.**

`plan/02-architecture.md` §5 · `plan/06-harness-and-model.md` §4.3.

레퍼런스는 "이 툴이 커스텀인가"를 하드코딩된 이름 목록으로 판별한다. 그래서
`schedule_*`·`browser_*` 처럼 목록에 없는 이름이 생기면 **오분류**된다 —
사용자 입력을 기다려야 하는 턴이 그냥 끝나거나, 끝나야 할 턴이 멈춘다.

여기서는 `ToolRegistry` 가 각 툴의 `kind` 를 실체로 들고 있고, 이 모듈은
그 `kind` 만 본다. 이름 문자열이 **한 번도 등장하지 않는다.**
"""

from __future__ import annotations

from dataclasses import dataclass

from ma_domain.agents import ToolKind
from ma_domain.sessions import RequiredAction, StopReason

from ma_harness.model_port import FinishReason

#: 결과를 **애플리케이션이** 돌려줘야 하는 툴 종류. 세션이 멈춰서 기다린다.
AWAITS_CLIENT: frozenset[ToolKind] = frozenset({ToolKind.CUSTOM})


@dataclass(frozen=True, slots=True)
class StopDecision:
    reason: StopReason
    required_action: RequiredAction | None = None

    def __post_init__(self) -> None:
        from ma_domain.errors import InvariantViolation

        if self.reason is StopReason.REQUIRES_ACTION and self.required_action is None:
            raise InvariantViolation("requires_action 에는 어떤 입력이 필요한지가 함께 있어야 한다")


def decide(
    *,
    finish: FinishReason | None,
    pending_tool_kinds: tuple[ToolKind, ...] = (),
    awaiting_approval: bool = False,
    interrupted: bool = False,
    budget_reached: bool = False,
    errored: bool = False,
) -> StopDecision:
    """턴이 왜 끝났는가.

    **순서가 의미를 갖는다.** 인터럽트와 예산은 모델이 뭐라 하든 이긴다 —
    사용자나 운영자가 멈추라고 한 것이기 때문이다. 그다음이 "사람을 기다리는가",
    마지막이 모델의 `finish_reason` 이다.
    """
    if interrupted:
        return StopDecision(StopReason.INTERRUPTED)
    if budget_reached:
        # **도달은 일시정지지 종료가 아니다** (`SessionBudget`).
        return StopDecision(StopReason.BUDGET_REACHED)

    if awaiting_approval:
        return StopDecision(StopReason.REQUIRES_ACTION, RequiredAction.TOOL_CONFIRMATION)
    if any(k in AWAITS_CLIENT for k in pending_tool_kinds):
        return StopDecision(StopReason.REQUIRES_ACTION, RequiredAction.CUSTOM_TOOL_RESULT)

    if errored:
        return StopDecision(StopReason.ERROR)
    if finish is FinishReason.MAX_TOKENS:
        return StopDecision(StopReason.MAX_TOKENS)
    if finish is FinishReason.CANCELLED:
        return StopDecision(StopReason.INTERRUPTED)
    if finish is FinishReason.ERROR:
        return StopDecision(StopReason.ERROR)
    return StopDecision(StopReason.END_TURN)


__all__ = ["AWAITS_CLIENT", "StopDecision", "decide"]
