"""메모리 동기화 — **턴의 일부지 턴 뒤가 아니다** (D10).

`plan/02-architecture.md` §9 · `plan/05-database.md` §3 G7 ·
`task/M4-productization/T-0501-memory-sync.md` · `IMPL-0025`.

```
세션 웜업                          턴 종료 (public idle 직전)
─────────                         ─────────────────────────
memories (SQL)                    /mnt/memory/<slug> 디프
  → materialize                     │
  → 마운트 (rw / ro)                 ▼
                                  fence 재검증 (generation 일치?)
                                    │
                                    ▼
                                  CAS write (content_sha256)
                                    │
                           ┌────────┴────────┐
                        성공            revision_conflict
                           │                 │
                         완료      rebase 로그 + 재시도 (최대 3회)
```

**동기화가 `idle` 뒤로 밀리면 다음 세션이 오래된 메모리를 읽는다.** 그래서
`turn_stopping` 훅에서 돈다 — 그 훅이 직렬인 이유가 이것이다.

> **`fence_lost` 면 포기한다.** 소유권이 넘어갔다면 이 워커의 파일시스템
> 뷰는 더 이상 정본이 아니다. split-brain 방어의 **마지막 지점**이다.

> **충돌 시 SQL 을 유지한다.** 에이전트의 쓰기를 버린다 — 반대로 하면
> 다른 세션의 메모리를 조용히 덮는다.

파일을 직접 열지 않는다. `read_file`·`write_file`·`list_files` 를
주입받는다 — `ADR-0008` 의 워크스페이스 경계 단일 진입점과 같은 이유다.
"""

from __future__ import annotations

import hashlib
import logging
from collections.abc import Awaitable, Callable, Mapping, Sequence
from dataclasses import dataclass, field
from enum import StrEnum
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from datetime import datetime

    from ma_domain.ids import MemoryStoreId, SessionId, WorkspaceId
    from ma_store.memory import MemoryDocumentStore

    from ma_harness.hooks import HookSet, TurnStopping

_log = logging.getLogger("ma_harness.memory_sync")

#: CAS 재시도 상한. 넘으면 **포기하고 SQL 을 유지한다.**
#:
#: 3회인 이유는 이벤트 수용(`MAX_CAS_RETRIES`)과 같다 — 그 이상 부딪히면
#: 경합이 아니라 **다른 세션이 계속 쓰고 있는 것**이고, 그때는 양보하는
#: 편이 맞다.
MAX_RETRIES = 3

#: 한 스토어에서 동기화할 파일 수 상한. 넘으면 **잘렸다고 로그에 남긴다.**
MAX_FILES = 1_000

#: 한 번에 읽을 페이지 크기. `ListQuery` 의 상한이 200 이다.
PAGE_SIZE = 200


class Outcome(StrEnum):
    #: 바뀐 것이 없다.
    UNCHANGED = "unchanged"
    SYNCED = "synced"
    #: 읽기 전용 마운트. 애초에 디프를 보지 않는다.
    READ_ONLY = "read_only"
    #: **소유권이 넘어갔다.** 이 워커의 뷰는 정본이 아니다.
    FENCE_LOST = "fence_lost"
    #: 충돌이 재시도 상한을 넘었다. SQL 을 유지했다.
    CONFLICT = "conflict"


@dataclass(frozen=True, slots=True)
class Change:
    path: str
    content: str
    #: materialize 시점의 해시. CAS precondition 이다. `None` 이면 신규.
    base_sha256: str | None


@dataclass(frozen=True, slots=True)
class SyncReport:
    """무슨 일이 있었는가. **로그와 이벤트에 그대로 들어간다.**"""

    store_id: MemoryStoreId
    outcome: Outcome
    written: int = 0
    conflicts: tuple[str, ...] = ()
    skipped: tuple[str, ...] = ()
    attempts: int = 0

    @property
    def ok(self) -> bool:
        return self.outcome in (Outcome.UNCHANGED, Outcome.SYNCED, Outcome.READ_ONLY)


@dataclass(frozen=True, slots=True)
class Mounted:
    """웜업이 마운트한 결과. **turn_stopping 이 이것을 받아 디프한다.**"""

    store_id: MemoryStoreId
    slug: str
    mount_path: str
    writable: bool
    #: 마지막으로 **우리가 안다고 믿는** `경로 → 해시`. 디프의 기준선이다.
    #:
    #: **동기화가 끝나면 갱신된다** (`dict` 인 이유). 갱신하지 않으면
    #: 같은 세션의 두 번째 턴이 1번 턴의 결과를 "바뀐 것"으로 보고
    #: 낡은 precondition 으로 다시 써서 **에이전트 쓰기를 잃는다.**
    #: 웜업은 세션당 한 번이므로 이 갱신이 유일한 길이다.
    baseline: dict[str, str] = field(default_factory=dict)


def sha256_of(content: str) -> str:
    return hashlib.sha256(content.encode("utf-8")).hexdigest()


# ── 웜업 ─────────────────────────────────────────────────
async def materialize(
    docs: MemoryDocumentStore,
    *,
    workspace_id: WorkspaceId,
    store_id: MemoryStoreId,
    slug: str,
    mount_path: str,
    writable: bool,
    write_file: Callable[[str, str], Awaitable[None]],
) -> Mounted:
    """SQL → 파일시스템. **기준선을 함께 돌려준다.**

    기준선이 없으면 턴 종료에 "무엇이 바뀌었는가"를 알 수 없고, 그러면
    전부를 덮어쓰게 된다 — 다른 세션이 그 사이에 쓴 것까지.
    """
    from ma_store._results import ListQuery

    baseline: dict[str, str] = {}
    cursor = None
    truncated = False
    while True:
        # **페이지를 끝까지 따라간다.** `ListQuery.limit` 상한이 200 이라
        # 한 번만 부르면 201번째 파일부터 마운트에서 조용히 사라지고,
        # 그러면 디프가 그것들을 "신규"로 보고 전부 다시 쓴다.
        page = await docs.list_in_store(
            ListQuery(workspace_id=workspace_id, limit=PAGE_SIZE, after=cursor), store_id
        )
        for memory in page.items:
            await write_file(f"{mount_path}/{memory.path}", memory.content)
            baseline[memory.path] = memory.content_sha256
            if len(baseline) >= MAX_FILES:
                truncated = page.next_cursor is not None or memory is not page.items[-1]
                break
        cursor = page.next_cursor
        if cursor is None or len(baseline) >= MAX_FILES:
            truncated = truncated or cursor is not None
            break

    if truncated:
        _log.warning(
            "메모리 스토어가 %d개를 넘는다 — 잘라서 마운트한다 store=%s",
            MAX_FILES,
            store_id,
        )

    return Mounted(
        store_id=store_id,
        slug=slug,
        mount_path=mount_path,
        writable=writable,
        baseline=baseline,
    )


# ── 턴 종료 ──────────────────────────────────────────────
def diff(mounted: Mounted, current: Mapping[str, str]) -> tuple[Change, ...]:
    """파일시스템 상태 → 바뀐 것.

    **삭제는 다루지 않는다.** 에이전트가 파일을 지운 것인지 materialize
    가 실패한 것인지 구분할 수 없고, 후자를 삭제로 읽으면 **메모리가
    조용히 사라진다.** 지우려면 API 를 쓴다.
    """
    out: list[Change] = []
    for path, content in sorted(current.items()):
        base = mounted.baseline.get(path)
        if base is not None and base == sha256_of(content):
            continue
        out.append(Change(path=path, content=content, base_sha256=base))
    return tuple(out)


@dataclass
class MemorySync:
    """`turn_stopping` 훅이 쓰는 것.

    **fence 를 재검증한다** — 디프를 계산하는 동안 소유권이 넘어갔을 수
    있고, 그때 쓰면 다른 워커가 쓴 것을 덮는다.
    """

    docs: MemoryDocumentStore
    workspace_id: WorkspaceId
    session_id: SessionId
    #: 지금 fence 가 유효한가. `ExecutionFence.is_current()` 를 받는다.
    fence_ok: Callable[[], Awaitable[bool]]
    now: Callable[[], datetime]
    next_id: Callable[[], str]

    async def sync(self, mounted: Mounted, current: Mapping[str, str]) -> SyncReport:
        """한 스토어를 되돌린다."""
        if not mounted.writable:
            # 읽기 전용은 **디프도 보지 않는다.** 보면 "거부했다"는 로그가
            # 쏟아지는데, 그것은 정상 상태다.
            return SyncReport(store_id=mounted.store_id, outcome=Outcome.READ_ONLY)

        changes = diff(mounted, current)
        if not changes:
            return SyncReport(store_id=mounted.store_id, outcome=Outcome.UNCHANGED)

        if not await self.fence_ok():
            # **split-brain 방어의 마지막 지점.**
            _log.warning(
                "fence 를 잃어 메모리 동기화를 포기한다 session=%s store=%s 변경=%d",
                self.session_id,
                mounted.store_id,
                len(changes),
            )
            return SyncReport(
                store_id=mounted.store_id,
                outcome=Outcome.FENCE_LOST,
                skipped=tuple(c.path for c in changes),
            )

        return await self._write_all(mounted, changes)

    async def _write_all(self, mounted: Mounted, changes: Sequence[Change]) -> SyncReport:
        from ma_store._results import NotFound, VersionConflict
        from ma_store.memory import PathConflict, WriteMemory, WrittenMemory

        written = 0
        conflicts: list[str] = []
        attempts = 0

        for change in changes:
            precondition = change.base_sha256
            for attempt in range(1, MAX_RETRIES + 1):
                attempts = max(attempts, attempt)
                result = await self.docs.write(
                    WriteMemory(
                        id=self.next_id(),  # type: ignore[arg-type]
                        workspace_id=self.workspace_id,
                        store_id=mounted.store_id,
                        path=change.path,
                        content=change.content,
                        author=f"session:{self.session_id}",
                        now=self.now(),
                        precondition_sha256=precondition,
                    )
                )
                if isinstance(result, WrittenMemory):
                    written += 1
                    # **기준선을 민다.** 다음 턴의 디프가 이것을 본다.
                    mounted.baseline[change.path] = sha256_of(change.content)
                    break

                if isinstance(result, PathConflict):
                    # 우리가 "신규"로 알았는데 이미 있다 — 다른 세션이
                    # 같은 경로를 만들었다. **그쪽을 기준으로 다시 본다.**
                    existing = await self.docs.find_by_path(
                        self.workspace_id, mounted.store_id, change.path
                    )
                    if existing is None:  # pragma: no cover — 방금 충돌했다
                        conflicts.append(change.path)
                        break
                    if existing.content == change.content:
                        # 내용이 같다. 쓸 것이 없다 — **기준선만 맞춘다.**
                        mounted.baseline[change.path] = existing.content_sha256
                        break
                    precondition = existing.content_sha256
                    _log.info(
                        "메모리 rebase path=%s attempt=%d (경로 충돌)",
                        change.path,
                        attempt,
                    )
                    continue

                if isinstance(result, VersionConflict | NotFound):
                    # **SQL 을 유지한다.** 에이전트가 쓴 것을 버리고,
                    # 그 사실을 남긴다 — 조용히 버리면 사용자는 자기
                    # 메모가 저장됐다고 믿는다.
                    _log.info("메모리 충돌 — SQL 유지 path=%s attempt=%d", change.path, attempt)
                    conflicts.append(change.path)
                    # **진 쪽으로 기준선을 맞춘다.** 그대로 두면 다음
                    # 턴이 같은 낡은 해시로 다시 부딪히고, 에이전트가
                    # 고쳐도 영원히 저장되지 않는다.
                    loser = await self.docs.find_by_path(
                        self.workspace_id, mounted.store_id, change.path
                    )
                    if loser is not None:
                        mounted.baseline[change.path] = loser.content_sha256
                    break
            else:  # pragma: no cover — 위 break 들이 거의 항상 잡는다
                conflicts.append(change.path)

        outcome = Outcome.SYNCED if written else Outcome.CONFLICT
        if conflicts and not written:
            outcome = Outcome.CONFLICT
        return SyncReport(
            store_id=mounted.store_id,
            outcome=outcome,
            written=written,
            conflicts=tuple(conflicts),
            attempts=attempts,
        )


def install(
    hooks: HookSet,
    sync: MemorySync,
    mounts: Sequence[Mounted],
    read_mount: Callable[[Mounted], Awaitable[Mapping[str, str]]],
    on_report: Callable[[SyncReport], None] | None = None,
) -> None:
    """`turn_stopping` 에 리스너를 건다. **조립이 부르는 유일한 함수다.**

    마운트 자체(샌드박스에 디렉터리를 붙이는 일)는 여기서 하지 않는다 —
    워커의 워크스페이스 프로비저닝이 하고, 그것이 생기면 여기에
    `mounts` 와 `read_mount` 를 넘기면 된다.

    `read_mount` 를 **주입받는 이유**: 파일을 직접 열지 않는다
    (`ADR-0008` 의 워크스페이스 경계 단일 진입점). 티어 W 는 게스트
    메모리에서, 티어 P 는 바인드마운트된 디렉터리에서 읽어야 하고,
    그 차이를 하네스가 알 이유가 없다.
    """

    async def listener(_: TurnStopping) -> None:
        for mounted in mounts:
            current = await read_mount(mounted)
            report = await sync.sync(mounted, current)
            if on_report is not None:
                on_report(report)
            if not report.ok:
                # **올리지 않는다.** `SerialHooks` 가 잡아 `recovered` 로
                # 보내 주지만, 그러면 뒤의 마운트가 돌지 않는다. 하나가
                # 충돌했다고 나머지를 버릴 이유가 없다.
                _log.warning(
                    "메모리 동기화 실패 store=%s outcome=%s 충돌=%s",
                    mounted.store_id,
                    report.outcome.value,
                    report.conflicts,
                )

    hooks.turn_stopping.add(listener)


def prompt_hint(mounts: Sequence[Mounted]) -> str:
    """시스템 프롬프트에 들어갈 안내.

    **전용 툴을 만들지 않는다** (D10). 에이전트는 일반 파일 툴로
    접근하고, 프롬프트에는 "어디에 마운트됐다"만 들어간다.

    프롬프트 **접두사에 인라인**된다 — 캐시에 포함돼야 하므로 매 턴
    같은 문자열이어야 하고, 그래서 정렬한다 (`plan/06` §5).
    """
    if not mounts:
        return ""
    lines = ["다음 디렉터리가 메모리 스토어다. 일반 파일 툴로 읽고 쓴다."]
    for m in sorted(mounts, key=lambda x: x.slug):
        mode = "읽기/쓰기" if m.writable else "읽기 전용"
        lines.append(f"  {m.mount_path}  ({mode})")
    lines.append("쓴 내용은 턴이 끝날 때 저장된다.")
    return "\n".join(lines)


__all__ = [
    "MAX_FILES",
    "MAX_RETRIES",
    "PAGE_SIZE",
    "Change",
    "MemorySync",
    "Mounted",
    "Outcome",
    "SyncReport",
    "diff",
    "install",
    "materialize",
    "prompt_hint",
    "sha256_of",
]
