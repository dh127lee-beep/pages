"""이벤트 로그 → 모델 메시지 (D4의 소비자).

`plan/02-architecture.md` §4 · §5.

`seq` 순서를 지키는 이유가 **전부 여기 있다.** 이 모듈이 `ORDER BY seq`로 읽은
이벤트를 모델 메시지로 접는다. 순서가 흔들리면:

1. 프롬프트 접두사가 매 턴 달라져 **캐시가 전부 미스**가 된다. DeepSeek 기준
   캐시 히트와 미스는 50배 차이라, drift 하나가 비용을 50배로 만든다.
2. 모델이 **자기가 보지 않은 순서의 역사**를 보게 된다. "사용자가 저 말을 하기
   전에 내가 이미 이렇게 답했다"는 상태가 되어 추론이 깨진다.

그래서 `derive_messages`는 **순수 함수**다 — 같은 이벤트 수열에서 항상 같은
메시지를 낸다. 시간도, 랜덤도, 외부 상태도 보지 않는다. 그래야 캐시 접두사가
안정적이라는 것을 테스트로 고정할 수 있다.

이 단계(T-0202)에서는 **골격**이다. 툴 결과·추론 블록·첨부의 정확한 모양은
T-0204(ModelPort)에서 모델 카드가 정해지면 채운다.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from ma_domain.events import EventType, SessionEvent
from ma_store.events import ReadEvents

if TYPE_CHECKING:
    from ma_domain.ids import SessionId, ThreadId, WorkspaceId
    from ma_store.events import SessionEventStore

#: 한 번에 읽어올 이벤트 수. 긴 세션은 여러 번 읽는다.
PAGE = 1000


@dataclass(frozen=True, slots=True)
class Message:
    """모델에 보낼 한 메시지. provider 중립이다 — `ModelPort`가 와이어로 번역한다."""

    role: str  # "user" | "assistant" | "tool"
    content: tuple[tuple[str, object], ...]

    def get(self, key: str) -> object | None:
        for k, v in self.content:
            if k == key:
                return v
        return None


@dataclass(frozen=True, slots=True)
class History:
    """replay 결과. `last_seq`는 다음 읽기의 시작점이다."""

    messages: tuple[Message, ...]
    last_seq: int
    #: 모델이 보지 않는 이벤트까지 포함한 전체 개수 (관측용).
    event_count: int = 0


async def read_events(
    store: SessionEventStore,
    workspace_id: WorkspaceId,
    session_id: SessionId,
    *,
    after_seq: int | None = None,
    thread_id: ThreadId | None = None,
) -> tuple[SessionEvent, ...]:
    """`seq` 순으로 전부 읽는다. 페이지를 넘겨가며 이어 붙인다.

    `after_seq`를 주면 증분 읽기다 — 하네스가 턴마다 전체를 다시 읽지 않아도 된다.
    """
    out: list[SessionEvent] = []
    cursor = after_seq
    while True:
        page = await store.read(
            ReadEvents(
                workspace_id=workspace_id,
                session_id=session_id,
                after_seq=cursor,
                thread_id=thread_id,
                limit=PAGE,
            )
        )
        if not page:
            break
        out.extend(page)
        last = page[-1].seq
        if last is None or len(page) < PAGE:  # pragma: no cover — seq 는 항상 있다
            break
        cursor = last
    return tuple(out)


@dataclass
class _Builder:
    """`user` 연속·`assistant` 연속을 하나로 접는다.

    모델 API는 같은 role 이 연달아 오는 것을 싫어하고, 접어 두면 캐시 접두사도
    짧고 안정적이다.
    """

    messages: list[Message] = field(default_factory=list)

    def add(self, role: str, content: tuple[tuple[str, object], ...]) -> None:
        self.messages.append(Message(role=role, content=content))


def derive_messages(events: tuple[SessionEvent, ...]) -> History:
    """**순수 함수.** 이벤트 수열 → 모델 메시지 수열.

    `is_model_visible`이 False인 이벤트는 건너뛴다 — `agent.message_attempt`,
    `agent.thinking` 같은 것들은 로그에는 남지만 모델에게는 다시 보이지 않는다.
    다시 보이면 모델이 자기 초안을 사실로 착각한다.

    `seq`가 없는 이벤트(promote 안 된 것)는 **입력으로 들어와선 안 된다** —
    들어오면 순서를 정할 수 없으므로 조용히 버리지 않고 걸러 낸 뒤
    `event_count`로 차이를 드러낸다.
    """
    b = _Builder()
    last_seq = -1
    counted = 0

    for e in events:
        if e.seq is None:
            continue
        counted += 1
        last_seq = max(last_seq, e.seq)
        if not e.is_model_visible:
            continue

        match e.type:
            case EventType.USER_MESSAGE:
                b.add("user", e.payload)
            case EventType.AGENT_MESSAGE:
                b.add("assistant", e.payload)
            case EventType.AGENT_TOOL_USE:
                b.add("assistant", e.payload)
            case (
                EventType.AGENT_TOOL_RESULT
                | EventType.USER_TOOL_RESULT
                | EventType.USER_CUSTOM_TOOL_RESULT
                | EventType.AGENT_MCP_TOOL_RESULT
            ):
                b.add("tool", e.payload)
            case _:
                # 아직 모델 메시지로 접지 않는 종류. T-0204 에서 모델 카드가
                # 정해지면 채운다. 지금 임의로 접으면 그때 전부 다시 써야 한다.
                continue

    return History(messages=tuple(b.messages), last_seq=last_seq, event_count=counted)


__all__ = ["PAGE", "History", "Message", "derive_messages", "read_events"]
