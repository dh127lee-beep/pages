"""툴 레지스트리 — `kind`를 **실체로** 들고 있는다.

`plan/06-harness-and-model.md` §4.3 · `plan/02-architecture.md` §5.

레퍼런스는 "커스텀 툴인지"를 **이름 하드코딩 목록**으로 판별한다. 그래서
`schedule_*`·`browser_*` 같은 새 이름에 `always_ask`를 걸면 오분류된다.
여기서는 `ToolEntry.kind`가 사실이고, `stop_reason` 결정이 이름을 보지 않는다.

`grants`가 **승인 재개의 정확성**을 만든다. 레퍼런스는 승인 후 툴을 재구성할 때도
executor 스트리핑이 그대로 적용돼 "실행 함수가 없는 채로 재개"될 수 있다.
`ToolGrant`에 `tool_call_id`가 있으면 **그 호출에 대해서만** executor 를 유지한다.
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable, Collection, Mapping, Sequence
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from ma_domain.agents import PermissionPolicy, ToolKind, mcp_tool_name

from ma_harness.hooks import ToolDecision, ToolOutcome, Verdict
from ma_harness.model_port import ToolSchema

if TYPE_CHECKING:
    from ma_domain.agents import AgentDefinition

    from ma_harness.model_port import ToolCall

type ToolExecutor = Callable[["ToolCall"], Awaitable[ToolOutcome]]


@dataclass(frozen=True, slots=True)
class ToolGrant:
    """승인된 **1회** 호출. `tool_call_id` 가 범위를 좁힌다.

    툴 이름으로 승인하면 "한 번 허락했더니 계속 한다"가 된다. 호출 id 로
    묶으면 승인은 정확히 그 호출에만 적용된다.
    """

    tool_name: str
    tool_call_id: str
    granted_by: str
    reason: str = ""


@dataclass(frozen=True, slots=True)
class ToolEntry:
    name: str
    kind: ToolKind
    schema: ToolSchema
    #: `None` 이면 **승인 대기 상태로 노출된다** — 모델에게는 보이지만 실행은
    #: 못 한다. 승인이 오면 `grants` 를 통해 executor 가 붙는다.
    executor: ToolExecutor | None
    policy: PermissionPolicy = PermissionPolicy.ALWAYS_ASK

    @property
    def is_runnable(self) -> bool:
        return self.executor is not None


@dataclass
class ToolRegistry:
    entries: Mapping[str, ToolEntry] = field(default_factory=dict)
    #: 승인된 **호출 하나**에만 붙는 실행기. `tool_call_id` → 실행기.
    #:
    #: 왜 `ToolEntry` 안에 두지 않는가: 엔트리는 **툴 하나**를 나타내고
    #: 승인은 **호출 하나**에 대한 것이다. 엔트리에 실행기를 되돌려 놓으면
    #: 그 툴의 다음 호출도 함께 열린다 — "한 번 허락했더니 계속 한다".
    granted: Mapping[str, ToolExecutor] = field(default_factory=dict)

    def get(self, name: str) -> ToolEntry | None:
        return self.entries.get(name)

    def executor_for(self, call: ToolCall) -> ToolExecutor | None:
        """이 **호출**을 실행할 함수. 없으면 `None`.

        `ToolEntry.executor` 는 "언제나 실행해도 되는" 툴의 것이고,
        `granted` 는 "이 호출 하나만" 이다.
        """
        entry = self.get(call.name)
        if entry is None:
            return None
        if entry.executor is not None:
            return entry.executor
        return self.granted.get(call.id)

    def schemas(self) -> tuple[ToolSchema, ...]:
        """모델에게 보낼 스키마. **실행 불가한 것도 포함한다.**

        승인 대기 중인 툴을 숨기면 모델이 그 능력을 모르게 되고, 사용자가
        "왜 안 하지"를 묻게 된다. 노출하되 호출하면 승인을 요구한다.
        """
        return tuple(e.schema for e in self.entries.values())

    def decide(self, call: ToolCall) -> ToolDecision:
        """권한 판정. **실행기 유무가 답이다** — 이름도, 정책 재평가도 아니다.

        정책은 `build_tools` 가 **한 번만** 적용한다: `always_ask` 면 거기서
        실행기를 떼어 둔다. 여기서 정책(`entry.policy`)을 다시 보면
        **승인이 와도 ASK 가 유지되어** 재개가 영영 안 된다 — 레퍼런스가
        "승인 후에도 결과 없이 재개"되던 것과 같은 모양의 버그다.

        승인은 `granted` 에 **호출 id 로** 들어 있고, `executor_for` 가
        그것까지 본다. 그래서 같은 툴의 **다른 호출**은 다시 멈춘다.
        """
        if self.get(call.name) is None:
            return ToolDecision(verdict=Verdict.DENY, reason=f"등록되지 않은 툴: {call.name}")
        if self.executor_for(call) is None:
            return ToolDecision(verdict=Verdict.ASK, reason=f"{call.name}은 승인이 필요하다")
        return ToolDecision(verdict=Verdict.ALLOW)

    def kinds_of(self, names: Sequence[str]) -> tuple[ToolKind, ...]:
        """`stop_reason` 결정이 쓴다. 모르는 이름은 건너뛴다."""
        out = []
        for n in names:
            e = self.get(n)
            if e is not None:
                out.append(e.kind)
        return tuple(out)


def build_tools(
    agent: AgentDefinition,
    *,
    executors: Mapping[str, ToolExecutor] | None = None,
    grants: Sequence[ToolGrant] = (),
    schemas: Mapping[str, ToolSchema] | None = None,
    available: Collection[str] | None = None,
    allow_mcp: bool = True,
) -> ToolRegistry:
    """에이전트 설정 + 사용 가능한 실행기 → 레지스트리.

    세 출처를 **각자의 `kind` 로** 모은다. 이름이 아니라 출처가 종류를 정하므로
    `schedule_*` 같은 새 이름이 와도 오분류되지 않는다.

    | 출처 | kind | 기본 정책 |
    |---|---|---|
    | `agent.toolset.enabled_tools()` | `builtin` | 툴셋의 정책 |
    | `agent.custom_tools` | `custom` | 항상 `always_ask` — 애플리케이션이 실행한다 |
    | `agent.mcp_servers[].allowed_tools` | `mcp` | 서버의 기본 정책 |

    MCP 툴은 **`mcp__<server>__<tool>` 로 등록된다.** 두 서버가 둘 다
    `search` 를 주는 일이 흔하고, 접두가 없으면 뒤에 등록된 쪽이 앞을
    조용히 덮는다. 접두 덕에 권한 정책이 `mcp__github__*` 로 서버
    단위를 가리킬 수도 있다.

    `allow_mcp=False` 면 **MCP 툴을 하나도 등록하지 않는다**
    (`environments.networking.allow_mcp_servers`). `available` 로
    거르는 것과 같은 이유다: 환경이 금지한 것은 승인해도 안 되므로,
    모델에게 보여 주면 **열 수 없는 문을 계속 두드린다.**

    `executors` 에 없는 툴은 `executor=None` 으로 **등록된다 — 빼지 않는다.**
    빼면 모델이 능력을 모르고, 사용자는 에이전트가 할 수 있다고 믿는 일을
    못 하는 것을 본다.

    `grants` 는 `always_ask` 툴의 실행기를 **그 `tool_call_id` 에 한해**
    되살린다. 엔트리에 되돌려 놓지 않는 것이 중요하다 — 되돌려 놓으면
    같은 툴의 **다음 호출도 함께 열린다** ("한 번 허락했더니 계속 한다").

    `available` 은 **이 환경이 줄 수 있는 내장 툴 이름**이다
    (`ma_application.tools.registry.registrable_tools`). 주면 그 밖의
    내장 툴은 **등록하지 않는다** — 티어 W 에서 `bash` 가 그렇다.

    빼는 것과 `executor=None` 으로 두는 것의 차이가 중요하다. 후자는
    "승인하면 된다"는 뜻인데, 티어 W 의 `bash` 는 승인해도 안 된다 —
    존재하지 않는다. 모델에게 보여 주면 **열 수 없는 문을 계속 두드린다.**

    커스텀·MCP 툴은 `available` 로 거르지 않는다. 그것들은 샌드박스가
    아니라 애플리케이션과 원격 서버가 실행하므로 티어와 무관하다 —
    MCP 를 거르는 것은 티어가 아니라 **환경의 네트워크 정책**이다.
    """
    allowed = None if available is None else frozenset(available)
    execs = dict(executors or {})
    schema_map = dict(schemas or {})

    def entry(name: str, kind: ToolKind, policy: PermissionPolicy) -> ToolEntry:
        executor = execs.get(name)
        # always_ask 면 실행기를 떼어 둔다. **승인은 엔트리가 아니라
        # `granted` 로 간다** — 호출 하나에만 붙어야 하기 때문이다.
        if executor is not None and policy is PermissionPolicy.ALWAYS_ASK:
            executor = None
        return ToolEntry(
            name=name,
            kind=kind,
            schema=schema_map.get(name) or ToolSchema(name=name, description=""),
            executor=executor,
            policy=policy,
        )

    entries: dict[str, ToolEntry] = {}

    toolset = agent.toolset
    if toolset is not None:
        for name in sorted(toolset.enabled_tools()):
            if allowed is not None and name not in allowed:
                continue
            entries[name] = entry(name, ToolKind.BUILTIN, toolset.policy_for(name))

    for spec in agent.custom_tools:
        # 커스텀 툴은 **애플리케이션이 실행한다** — 세션은 requires_action 으로
        # 멈추고 결과를 기다린다. 그래서 워커에 executor 가 있을 수 없다.
        entries[spec.name] = entry(spec.name, ToolKind.CUSTOM, PermissionPolicy.ALWAYS_ASK)

    if allow_mcp:
        for server in agent.mcp_servers:
            for tool in server.allowed_tools:
                # **서버 이름을 접두로 붙인다** — 두 서버의 `search` 가
                # 안 겹치게, 그리고 정책이 서버 단위를 가리킬 수 있게.
                name = mcp_tool_name(server.name, tool)
                entries[name] = entry(name, ToolKind.MCP, server.default_permission_policy)

    # 승인은 **그 호출 id 에만** 붙인다. 승인된 툴이 실제로 등록돼 있고
    # 실행기가 있을 때만 — 없는 툴을 승인해 봐야 실행할 것이 없다.
    granted = {
        g.tool_call_id: execs[g.tool_name]
        for g in grants
        if g.tool_name in entries and g.tool_name in execs
    }
    return ToolRegistry(entries=entries, granted=granted)


__all__ = [
    "ToolEntry",
    "ToolExecutor",
    "ToolGrant",
    "ToolRegistry",
    "build_tools",
]
