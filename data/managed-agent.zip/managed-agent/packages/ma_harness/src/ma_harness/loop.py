"""DefaultHarness — 턴 루프 8단계.

`plan/06-harness-and-model.md` §4.1 · `plan/02-architecture.md` §5 · `ADR-0006`.

```
turn 시작  → session.status_running
  ① 입력 확정 (pre_step)       pending → promote → events (seq 부여)
  ② 프롬프트 조립               system + 툴 스키마
  ③ 모델 히스토리 파생           derive_messages — 실패 시도 제외
  ④ 요청 동결(freeze)          이후 재시도는 ②③을 반복하지 않는다
  ⑤ step → 모델 스트림          중립 이벤트 → 우리 이벤트
  ⑥ 툴 실행 파이프라인           pre_execute → execute → post_execute
  ⑦ 툴 결과가 있으면 → ⑤
  ⑧ turn_stopping · stop_reason 결정
turn 종료  → session.status_idle{stop_reason}   ← 정확히 한 번
```

세 가지가 이 파일의 핵심이다.

**무상태.** 턴 상태는 전부 지역 변수다. 인스턴스 변수에 들고 있으면 크래시
복구가 "다음 claim"으로 끝나지 않는다.

**요청 동결.** ②③ 결과를 `_Frozen` 에 담고 재시도는 그것을 그대로 쓴다.
재조립하면 프롬프트가 미세하게 달라져 캐시가 매번 미스되고, 비용이 최대 50배다
(`plan/06` §5).

**`idle` 정확히 한 번.** `try/finally` 로 보장한다. 예외가 나도, 인터럽트로
빠져나가도, fence 를 잃어도 — 정확히 한 번이다. 두 번 나가면 콘솔이 턴이
두 번 끝난 것으로 보고, 안 나가면 세션이 영원히 `running` 으로 남는다.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from ma_domain.events import EventType, SessionEvent, StreamFrameType
from ma_domain.executions import ExecutionFenceLost
from ma_domain.ids import EventId
from ma_domain.models import TokenUsage

from ma_harness.history import derive_messages
from ma_harness.hooks import (
    RequestDraft,
    StepInput,
    ToolDecision,
    ToolInvocation,
    ToolOutcome,
    Verdict,
)
from ma_harness.model_port import (
    FinishReason,
    StreamEventKind,
    ToolCall,
    WireMessage,
)
from ma_harness.ports import HarnessContext, HarnessOutcome, StreamFrame
from ma_harness.stop_reason import AWAITS_CLIENT, StopDecision, decide

if TYPE_CHECKING:
    from ma_domain.agents import ToolKind

    from ma_harness.ports import CostFn

#: 툴 출력 상한. 초과분은 파일로 spill 하고 모델에는 프리뷰만 준다
#: (`plan/06` §4.4 — 공식 CMA 와 같은 동작).
MAX_TOOL_OUTPUT = 100_000


@dataclass(frozen=True, slots=True)
class _Frozen:
    """동결된 요청. **재시도가 이것을 재조립하지 않는다.**"""

    messages: tuple[WireMessage, ...]
    max_tokens: int | None


@dataclass
class _Turn:
    """턴 하나의 지역 상태. **인스턴스 변수가 아니다** — 턴마다 새로 만든다."""

    usage: TokenUsage = field(default_factory=TokenUsage)
    steps: int = 0
    recovered: list[str] = field(default_factory=list)
    interrupted: bool = False
    errored: bool = False
    error: str | None = None
    awaiting_approval: bool = False
    pending_kinds: list[ToolKind] = field(default_factory=list)
    last_finish: FinishReason | None = None


@dataclass
class DefaultHarness:
    """`plan/06` §4.1 의 루프."""

    name: str = "default"
    cost: CostFn | None = None

    async def run(self, ctx: HarnessContext) -> HarnessOutcome:
        t = _Turn()
        idle_emitted = False
        try:
            await self._append(ctx, EventType.SESSION_STATUS_RUNNING, ())
            await self._turn(ctx, t)
        except ExecutionFenceLost:
            # 소유권을 잃었다. **idle 을 쓰지 않는다** — 쓸 권한이 없고,
            # 새 소유자가 자기 턴을 끝낼 때 자기 idle 을 쓴다.
            idle_emitted = True
            raise
        except Exception as exc:  # 턴의 실패는 워커의 죽음이 아니다
            t.errored = True
            t.error = f"{type(exc).__name__}: {exc}"
        finally:
            if not idle_emitted:
                stop = self._stop(ctx, t)
                # ⑧ turn_stopping — **`idle` 보다 먼저.**
                #
                # 메모리 동기화가 여기 붙는다 (T-0501). `idle` 뒤로 밀면
                # 클라이언트가 "끝났다"를 보고 다음 세션을 여는데 메모리는
                # 아직 옛날 것이다. 그래서 이 훅은 **직렬이고 await 한다** —
                # 백그라운드 태스크로 만드는 순간 그 경합이 돌아온다.
                await self._stopping(ctx, t, stop)
                # finally 안에서도 fence 를 잃을 수 있다. 그때는 조용히 포기한다 —
                # 이미 다른 워커의 턴이고, 여기서 예외를 올리면 원래 예외를 가린다.
                try:
                    await self._append(
                        ctx,
                        EventType.SESSION_STATUS_IDLE,
                        (("stop_reason", stop.reason.value),)
                        + (
                            (("required_action", stop.required_action.value),)
                            if stop.required_action
                            else ()
                        ),
                    )
                except ExecutionFenceLost:
                    pass

        stop = self._stop(ctx, t)
        cents = self.cost(ctx.card, t.usage) if self.cost else 0
        if t.usage != TokenUsage():
            await ctx.runtime.accrue(ctx.fence, t.usage, cents)
        return HarnessOutcome(
            stop_reason=stop.reason,
            required_action=stop.required_action,
            steps=t.steps,
            usage=t.usage,
            cost_cents=cents,
            recovered=tuple(t.recovered),
            error=t.error,
        )

    async def _stopping(self, ctx: HarnessContext, t: _Turn, stop: StopDecision) -> None:
        """`turn_stopping` 리스너를 전부 돌린다. **턴을 깨뜨리지 않는다.**

        `SerialHooks` 가 실패를 모아서 돌려주고, 여기서 그것을
        `recovered` 에 싣는다 — 삼키면 "동기화가 조용히 안 됐다"가 되고,
        올리면 원래의 stop_reason 이 가려진다.
        """
        from ma_harness.hooks import TurnStopping

        failures = await ctx.hooks.turn_stopping.run(
            TurnStopping(fence=ctx.fence, stop_reason=stop.reason.value, errored=t.errored)
        )
        for exc in failures:
            t.recovered.append(f"turn_stopping: {type(exc).__name__}: {exc}")

    # ── ①~⑧ ───────────────────────────────────────────────
    async def _turn(self, ctx: HarnessContext, t: _Turn) -> None:
        # ① 입력 확정
        promoted = await ctx.runtime.drain_pending(ctx.fence)
        step_in = await ctx.hooks.pre_step.run(
            StepInput(
                workspace_id=ctx.fence.scope.workspace_id,
                session_id=ctx.fence.scope.session_id,
                promoted=(),
            )
        )
        if step_in.rejected:
            # 훅이 거부했다 — step 없이 턴을 끝낸다.
            t.recovered.append(f"pre_step 거부: {step_in.rejected}")
            return

        for ev in promoted:
            await ctx.runtime.emit(
                ctx.fence,
                StreamFrame(type=StreamFrameType.USER_MESSAGE_PROMOTED, data=(("id", ev.id),)),
            )

        # ②③④ 조립 → 파생 → 동결. **한 번만 한다.**
        history = await ctx.runtime.read_history(ctx.fence)
        draft = await ctx.hooks.pre_request.run(
            RequestDraft(messages=self._assemble(ctx, history), max_tokens=ctx.max_tokens)
        )
        frozen = _Frozen(messages=draft.messages, max_tokens=draft.max_tokens)

        # ⑤~⑦ step 루프
        tool_results: list[WireMessage] = []
        while t.steps < ctx.max_steps:
            if await self._check_interrupt(ctx, t):
                return

            t.steps += 1
            calls = await self._step(ctx, t, frozen, tool_results)
            if not calls:
                return

            tool_results = await self._run_tools(ctx, t, calls)
            if t.awaiting_approval or t.interrupted:
                return
            if not tool_results:
                return

        t.recovered.append(f"step 상한 {ctx.max_steps} 도달")

    async def _step(
        self,
        ctx: HarnessContext,
        t: _Turn,
        frozen: _Frozen,
        tool_results: list[WireMessage],
    ) -> list[ToolCall]:
        """모델 한 번 호출. **동결된 메시지 + 그동안 쌓인 툴 결과**만 보낸다.

        동결분을 다시 만들지 않는 것이 캐시 접두사를 지킨다.
        """
        await self._append(ctx, EventType.SPAN_MODEL_REQUEST_START, ())

        text: list[str] = []
        calls: dict[str, _PartialCall] = {}
        order: list[str] = []
        finish: FinishReason | None = None
        stream_error: str | None = None

        async for ev in ctx.model.stream(
            ctx.card,
            messages=[*frozen.messages, *tool_results],
            tools=ctx.tools.schemas(),
            effort=ctx.effort,
            max_tokens=frozen.max_tokens,
            signal=ctx.signal,
        ):
            match ev.kind:
                case StreamEventKind.TEXT_DELTA:
                    text.append(ev.text)
                    await ctx.runtime.emit(
                        ctx.fence,
                        StreamFrame(type=StreamFrameType.AGENT_MESSAGE_CHUNK, text=ev.text),
                    )
                case StreamEventKind.THINKING_DELTA:
                    await self._append(ctx, EventType.AGENT_THINKING, (("text", ev.text),))
                case StreamEventKind.TOOL_CALL_START:
                    cid = ev.tool_call_id or ""
                    calls[cid] = _PartialCall(id=cid, name=ev.tool_name or "")
                    order.append(cid)
                case StreamEventKind.TOOL_CALL_DELTA:
                    c = calls.get(ev.tool_call_id or "")
                    if c is not None:
                        c.arguments += ev.arguments_delta
                case StreamEventKind.USAGE:
                    if ev.usage is not None:
                        t.usage = t.usage + ev.usage
                case StreamEventKind.FINISH:
                    finish = ev.finish_reason
                case StreamEventKind.ERROR:
                    stream_error = ev.error.message if ev.error else "unknown"
                case _:
                    pass

        t.last_finish = finish
        await self._append(
            ctx,
            EventType.SPAN_MODEL_REQUEST_END,
            (
                ("finish_reason", finish.value if finish else "none"),
                ("input_cache_hit", t.usage.input_cache_hit),
                ("input_cache_miss", t.usage.input_cache_miss),
                ("output", t.usage.output),
            ),
        )

        body = "".join(text)

        if stream_error is not None or finish is FinishReason.ERROR:
            # **실패 시도는 모델 히스토리에 넣지 않는다.** 로그에만 남긴다 —
            # 짝 없는 tool_use 와 잘린 텍스트가 다음 요청에 섞이면 모델이
            # 자기 초안을 사실로 착각한다 (`NOT_MODEL_VISIBLE`).
            await self._append(
                ctx,
                EventType.AGENT_MESSAGE_ATTEMPT,
                (("text", body), ("error", stream_error or "stream_error")),
            )
            t.errored = True
            t.error = stream_error
            return []

        if finish is FinishReason.CANCELLED:
            await self._append(
                ctx, EventType.AGENT_MESSAGE_ATTEMPT, (("text", body), ("cancelled", True))
            )
            t.interrupted = True
            return []

        if body:
            await self._append(ctx, EventType.AGENT_MESSAGE, (("text", body),))

        out: list[ToolCall] = []
        for cid in order:
            c = calls[cid]
            await self._append(
                ctx,
                EventType.AGENT_TOOL_USE,
                (("tool_call_id", c.id), ("tool_name", c.name), ("arguments", c.arguments)),
            )
            out.append(ToolCall(id=c.id, name=c.name, arguments=c.arguments))
        return out

    async def _run_tools(
        self, ctx: HarnessContext, t: _Turn, calls: list[ToolCall]
    ) -> list[WireMessage]:
        """⑥ pre_execute → execute → post_execute."""
        results: list[WireMessage] = []
        for call in calls:
            inv = ToolInvocation(call=call, decision=ctx.tools.decide(call))
            inv = await ctx.hooks.pre_execute.run(inv)
            decision = inv.decision or ToolDecision(verdict=Verdict.DENY)

            if decision.verdict is Verdict.ASK:
                # 세션이 멈춘다. **무엇을 기다리는지는 `kind` 가 정한다.**
                #
                #   custom  → 애플리케이션이 **결과**를 돌려줘야 한다
                #   그 외   → 사람이 **승인**해야 한다
                #
                # 둘을 합치면 커스텀 툴이 "승인 버튼"을 기다리는 것으로 보이고,
                # 사용자는 누를 버튼이 없는 화면을 본다.
                entry = ctx.tools.get(call.name)
                if entry is not None:
                    t.pending_kinds.append(entry.kind)
                if entry is None or entry.kind not in AWAITS_CLIENT:
                    t.awaiting_approval = True
                return []

            if decision.verdict is Verdict.DENY:
                outcome = ToolOutcome(content=f"거부됨: {decision.reason}", is_error=True)
            else:
                inv = await ctx.hooks.execute.run(inv, terminal=self._execute(ctx))
                inv = await ctx.hooks.post_execute.run(inv)
                outcome = inv.result or ToolOutcome(
                    content="실행기가 결과를 내지 않았다", is_error=True
                )

            outcome = self._clamp(outcome)
            await self._append(
                ctx,
                EventType.AGENT_TOOL_RESULT,
                (
                    ("tool_call_id", call.id),
                    ("content", outcome.content),
                    ("is_error", outcome.is_error),
                ),
            )
            results.append(WireMessage(role="tool", content=outcome.content, tool_call_id=call.id))
        return results

    def _execute(self, ctx: HarnessContext):  # type: ignore[no-untyped-def]
        async def terminal(inv: ToolInvocation) -> ToolInvocation:
            from dataclasses import replace

            # **호출 단위로** 실행기를 찾는다 — 승인은 호출 하나에만 붙는다.
            executor = ctx.tools.executor_for(inv.call)
            if executor is None:
                return replace(
                    inv,
                    result=ToolOutcome(content=f"실행기가 없다: {inv.call.name}", is_error=True),
                )
            try:
                return replace(inv, result=await executor(inv.call))
            except Exception as exc:  # 툴 실패는 **모델에게 돌려줄 결과**다
                return replace(
                    inv,
                    result=ToolOutcome(content=f"{type(exc).__name__}: {exc}", is_error=True),
                )

        return terminal

    def _clamp(self, outcome: ToolOutcome) -> ToolOutcome:
        """출력 상한 100,000자. 초과분은 잘라 프리뷰만 준다.

        실제 spill(파일 저장)은 `post_execute` 리스너의 일이다 (M2) — 여기서는
        **모델이 받는 것**만 자른다. 자르지 않으면 툴 출력 하나가 컨텍스트를
        전부 먹고 캐시 접두사를 날린다.
        """
        if len(outcome.content) <= MAX_TOOL_OUTPUT:
            return outcome
        from dataclasses import replace

        head = outcome.content[:MAX_TOOL_OUTPUT]
        dropped = len(outcome.content) - MAX_TOOL_OUTPUT
        return replace(outcome, content=f"{head}\n…({dropped:,}자 잘림)")

    # ── 보조 ───────────────────────────────────────────────
    def _assemble(
        self, ctx: HarnessContext, history: tuple[SessionEvent, ...]
    ) -> tuple[WireMessage, ...]:
        """② + ③. **system 이 맨 앞**이어야 캐시 접두사가 안정적이다."""
        out: list[WireMessage] = []
        if ctx.agent.system:
            out.append(WireMessage(role="system", content=ctx.agent.system))
        out.extend(
            WireMessage(role=m.role, content=str(m.get("text") or ""))
            for m in derive_messages(history).messages
        )
        return tuple(out)

    async def _check_interrupt(self, ctx: HarnessContext, t: _Turn) -> bool:
        if ctx.signal is not None and ctx.signal.is_set():
            t.interrupted = True
            return True
        if await ctx.runtime.is_interrupted(ctx.fence):
            t.interrupted = True
            return True
        return False

    async def _append(
        self, ctx: HarnessContext, type_: EventType, payload: tuple[tuple[str, object], ...]
    ) -> None:
        await ctx.runtime.append(
            ctx.fence,
            SessionEvent(
                id=EventId(ctx.ids.next("event")),
                workspace_id=ctx.fence.scope.workspace_id,
                session_id=ctx.fence.scope.session_id,
                thread_id=ctx.fence.scope.lane_id,
                type=type_,
                payload=payload,
                created_at=ctx.clock.now(),
            ),
        )

    def _stop(self, ctx: HarnessContext, t: _Turn):  # type: ignore[no-untyped-def]
        return decide(
            finish=t.last_finish,
            pending_tool_kinds=tuple(t.pending_kinds),
            awaiting_approval=t.awaiting_approval,
            interrupted=t.interrupted,
            errored=t.errored,
        )


@dataclass
class _PartialCall:
    id: str
    name: str
    arguments: str = ""


__all__ = ["MAX_TOOL_OUTPUT", "DefaultHarness"]
