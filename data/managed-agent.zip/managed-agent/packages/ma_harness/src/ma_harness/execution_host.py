"""SessionExecutionHost — claim한 lane 하나를 호스팅한다 (D3).

`plan/02-architecture.md` §3 · `task/M1-runtime-core/T-0201-execution-authority.md`.

워커는 "실행을 가진 주체"가 아니라 **claim한 lane의 호스트**다. 권한은 DB에 있고,
워커는 fence를 빌려 쓸 뿐이다. 이 클래스가 그 빌림의 수명을 관리한다:

    claim → (하트비트 ‖ 턴 본문) → settle

세 가지를 보장한다.

1. **하트비트가 실패하면 턴을 중단한다.** `renew`가 False면 누군가 lease를 가져간
   것이다. 그 순간부터 이 워커가 쓰는 모든 것은 무효이므로 본문을 즉시 취소하고
   settle하지 않는다 — 좀비가 커밋하지 못하게 하는 것은 Store가 막지만, 애초에
   쓸모없는 일을 계속할 이유가 없다.
2. **인터럽트는 폴링으로 확인한다.** `interrupt_requested_at`은 워커가 죽어도 남는
   내구적 권한이다. 하트비트가 어차피 DB를 왕복하므로 같은 주기에 함께 읽는다.
3. **settle 직전에 하트비트를 한 번 더 친다.** lease 안에서 커밋이 끝나야 fence가
   의미를 갖는다.
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from datetime import timedelta
from typing import TYPE_CHECKING
from uuid import uuid4

import anyio
from ma_domain.executions import (
    DEFAULT_HEARTBEAT,
    DEFAULT_LEASE_TTL,
    ExecutionFence,
    ExecutionRecord,
    ExecutionState,
)
from ma_store.executions import ClaimExecution, SettleExecution

if TYPE_CHECKING:
    from ma_domain.clock import Clock
    from ma_domain.ids import WorkerId, WorkspaceId
    from ma_store.executions import ExecutionStore


class TurnInterrupted(Exception):
    """본문이 인터럽트를 받아 스스로 접었을 때. `cancelled`로 settle된다."""


@dataclass(frozen=True, slots=True)
class TurnContext:
    """턴 본문이 받는 유일한 입력. fence가 **권한의 증거**다."""

    execution: ExecutionRecord
    fence: ExecutionFence

    @property
    def generation(self) -> int:
        return self.fence.generation


@dataclass(frozen=True, slots=True)
class TurnOutcome:
    """턴이 어떻게 끝났는지. 워커 루프와 관측이 읽는다."""

    execution: ExecutionRecord
    state: ExecutionState | None
    settled: bool
    fence_lost: bool = False
    interrupted: bool = False
    error: tuple[tuple[str, object], ...] | None = None


#: 턴 본문. **최종 상태를 돌려줄 수 있다.**
#:
#: `None` 을 돌려주면 `completed` 다. 하네스는 `stop_reason` 을 알지만 호스트는
#: 모르므로, 그 번역을 본문이 한다 — 호스트가 settle 한 뒤 호출자가 다시
#: settle 하면 두 번째는 **항상 실패한다**(상태가 이미 running 이 아니다).
#: settle 은 한 곳에서만 일어나야 한다.
TurnBody = Callable[[TurnContext], Awaitable["ExecutionState | None"]]


class SessionExecutionHost:
    def __init__(
        self,
        store: ExecutionStore,
        clock: Clock,
        owner: WorkerId,
        *,
        lease_ttl: timedelta = DEFAULT_LEASE_TTL,
        heartbeat: timedelta = DEFAULT_HEARTBEAT,
        workspace_id: WorkspaceId | None = None,
    ) -> None:
        self._store = store
        self._clock = clock
        self._owner = owner
        self._lease_ttl = lease_ttl
        self._heartbeat = heartbeat
        self._workspace_id = workspace_id

    async def run_once(self, body: TurnBody) -> TurnOutcome | None:
        """claimable 한 것 하나를 집어 호스팅한다. 없으면 None."""
        claimed = await self._store.claim(
            ClaimExecution(
                owner=self._owner,
                now=self._clock.now(),
                lease_ttl=self._lease_ttl,
                attempt_id=uuid4(),
                workspace_id=self._workspace_id,
            )
        )
        if claimed is None:
            return None
        return await self.host(claimed.execution, claimed.fence, body)

    async def host(
        self, execution: ExecutionRecord, fence: ExecutionFence, body: TurnBody
    ) -> TurnOutcome:
        """이미 claim한 실행을 호스팅한다. `run_once`가 쓰는 본체."""
        ctx = TurnContext(execution=execution, fence=fence)
        state: ExecutionState | None = None
        error: tuple[tuple[str, object], ...] | None = None
        fence_lost = False
        interrupted = False

        async with anyio.create_task_group() as tg:

            async def watchdog() -> None:
                nonlocal fence_lost, interrupted
                while True:
                    await anyio.sleep(self._heartbeat.total_seconds())
                    if not await self._store.renew(fence, self._clock.now(), self._lease_ttl):
                        fence_lost = True
                        tg.cancel_scope.cancel()
                        return
                    current = await self._store.find(fence.scope, execution.execution_id)
                    if current is not None and current.is_interrupted:
                        interrupted = True
                        tg.cancel_scope.cancel()
                        return

            tg.start_soon(watchdog)
            try:
                state = await body(ctx) or ExecutionState.COMPLETED
            except TurnInterrupted:
                interrupted = True
                state = ExecutionState.CANCELLED
            except Exception as exc:  # 본문 실패는 턴의 결과이지 워커의 죽음이 아니다
                state = ExecutionState.FAILED
                error = (("kind", type(exc).__name__), ("message", str(exc)))
            tg.cancel_scope.cancel()  # 감시자를 접는다

        if fence_lost:
            # 소유권을 잃었다. settle을 시도조차 하지 않는다 — 다음 워커의 턴이다.
            return TurnOutcome(execution=execution, state=None, settled=False, fence_lost=True)

        if state is None:
            # 감시자가 인터럽트로 본문을 취소했다
            state = ExecutionState.CANCELLED

        # lease 안에서 커밋이 끝나야 fence 가 의미를 갖는다
        await self._store.renew(fence, self._clock.now(), self._lease_ttl)
        settled = await self._store.settle(
            SettleExecution(fence=fence, state=state, now=self._clock.now(), error=error)
        )
        return TurnOutcome(
            execution=execution,
            state=state if settled else None,
            settled=settled,
            fence_lost=not settled,
            interrupted=interrupted,
            error=error,
        )


__all__ = [
    "SessionExecutionHost",
    "TurnBody",
    "TurnContext",
    "TurnInterrupted",
    "TurnOutcome",
]
