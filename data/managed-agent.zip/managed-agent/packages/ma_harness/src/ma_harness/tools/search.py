"""`glob` · `grep` — **호스트 함수. 샌드박스 셸이 필요 없다** (D13).

`plan/07-sandbox.md` §2 · `plan/06-harness-and-model.md` §4.4.

`grep` 은 ripgrep 바이너리를 **호스트에서** 돌린다. 레퍼런스도 번들 ripgrep 을
`ctx.subprocess` 로 돌리는데, **그 subprocess 가 샌드박스 안일 필요가 없다** —
검색 대상이 워크스페이스 안이고, 우리가 `--` 뒤에 경계를 통과한 경로만 넘기기
때문이다.

ripgrep 이 없으면 **순수 파이썬으로 떨어진다.** 느리지만 동작하는 편이
"grep 을 못 쓴다"보다 낫다. 어느 쪽으로 돌았는지는 결과에 적는다.
"""

from __future__ import annotations

import json
import re
import shutil
import subprocess
from dataclasses import dataclass
from fnmatch import fnmatch
from pathlib import Path

from ma_harness.tools import _io
from ma_harness.tools._paths import Denied, resolve
from ma_harness.tools.fs import FsContext, ToolResult

#: `glob` 이 돌려주는 최대 건수. 근거는 `IMPL-0015`.
GLOB_LIMIT = 500

#: `grep` 이 돌려주는 최대 매치 수.
GREP_LIMIT = 300

#: ripgrep 타임아웃(초). 넘으면 러너 고장이 아니라 **툴 실패**로 다룬다.
RG_TIMEOUT = 30.0

#: 순회에서 항상 건너뛰는 디렉터리. 모델에게 쓸모없고 결과를 덮는다.
SKIP_DIRS = frozenset({".git", ".hg", ".svn", "node_modules", "__pycache__", ".venv", ".awp"})


def _skipped(rel: str) -> bool:
    return any(part in SKIP_DIRS for part in rel.split("/"))


# ── glob ──────────────────────────────────────────────────
def glob(ctx: FsContext, pattern: str, *, path: str = ".", limit: int = GLOB_LIMIT) -> ToolResult:
    """패턴에 맞는 파일을 **mtime 내림차순**으로 돌려준다.

    mtime 정렬인 이유: 모델이 찾는 것은 보통 **최근에 건드린 파일**이다.
    이름순으로 주면 `a_old.py` 가 맨 위에 오고, 상한에 걸려 정작 필요한
    최신 파일이 잘린다.
    """
    root = resolve(ctx.workspace_root, path)
    if isinstance(root, Denied):
        return ToolResult.error(root.message)
    if not _io.exists(root):
        return ToolResult.error(f"디렉터리가 없다: {root.label}")

    base = ctx.workspace_root.resolve()
    hits: list[tuple[float, str]] = []
    for found in _io.walk_files(root):
        rel = str(found.relative_to(base))
        if _skipped(rel):
            continue
        if not (fnmatch(rel, pattern) or fnmatch(found.name, pattern)):
            continue
        try:
            hits.append((found.stat().st_mtime, rel))  # awp-boundary-ok: walk_files 결과
        except OSError:  # pragma: no cover — 순회 중 사라진 파일
            continue

    if not hits:
        return ToolResult(content=f"'{pattern}' 에 맞는 파일이 없다 ({root.label} 아래)")

    hits.sort(key=lambda t: (-t[0], t[1]))
    shown = hits[:limit]
    body = "\n".join(rel for _, rel in shown)
    if len(hits) > limit:
        body += f"\n\n…{len(hits) - limit:,}건 더 있다 (최근 수정 순 상위 {limit}건만)"
    return ToolResult.of(ctx.emit(body, label=f"glob-{pattern}"))


# ── grep ──────────────────────────────────────────────────
@dataclass(frozen=True, slots=True)
class Match:
    path: str
    line_no: int
    text: str


def grep(
    ctx: FsContext,
    pattern: str,
    *,
    path: str = ".",
    glob_filter: str | None = None,
    ignore_case: bool = False,
    limit: int = GREP_LIMIT,
) -> ToolResult:
    """정규식으로 파일을 검색한다. ripgrep 이 있으면 쓰고, 없으면 파이썬."""
    root = resolve(ctx.workspace_root, path)
    if isinstance(root, Denied):
        return ToolResult.error(root.message)
    if not _io.exists(root):
        return ToolResult.error(f"디렉터리가 없다: {root.label}")

    try:
        re.compile(pattern)
    except re.error as exc:
        return ToolResult.error(f"정규식이 잘못됐다: {exc}")

    rg = shutil.which("rg")
    if rg is not None:
        got = _grep_ripgrep(
            rg, root.path, pattern, glob_filter, ignore_case, limit, ctx.workspace_root
        )
        if got is not None:
            matches, engine = got
        else:
            matches, engine = (
                _grep_python(
                    root.path, pattern, glob_filter, ignore_case, limit, ctx.workspace_root
                ),
                "python(ripgrep 실패)",
            )
    else:
        matches = _grep_python(
            root.path, pattern, glob_filter, ignore_case, limit, ctx.workspace_root
        )
        engine = "python(ripgrep 없음)"

    if not matches:
        return ToolResult(content=f"'{pattern}' 에 맞는 줄이 없다 ({root.label} 아래)")

    lines = [f"{m.path}:{m.line_no}:{m.text}" for m in matches[:limit]]
    body = "\n".join(lines)
    if len(matches) > limit:
        body += f"\n\n…{len(matches) - limit:,}건 더 있다 (상위 {limit}건만)"
    if not engine.startswith("ripgrep"):
        # **어느 엔진으로 돌았는지 숨기지 않는다.** 결과가 다를 수 있다.
        body += f"\n\n(검색 엔진: {engine})"
    return ToolResult.of(ctx.emit(body, label=f"grep-{pattern[:20]}"))


def _grep_ripgrep(
    rg: str,
    root: Path,
    pattern: str,
    glob_filter: str | None,
    ignore_case: bool,
    limit: int,
    workspace_root: Path,
) -> tuple[list[Match], str] | None:
    """`--json` 으로 받는다. 줄 파싱보다 **안정적**이다.

    실패하면 `None` — 호출자가 파이썬으로 떨어진다. ripgrep 이 깨졌다고
    `grep` 툴 자체를 못 쓰게 할 이유가 없다.
    """
    argv = [rg, "--json", "--no-config"]
    if ignore_case:
        argv.append("--ignore-case")
    for d in sorted(SKIP_DIRS):
        # **`**/` 접두사가 필요하다.** `!node_modules/**` 는 검색 루트 바로
        # 아래만 걸러서 `sub/node_modules/x.py` 가 통과한다 — 파이썬 경로는
        # 걸렀으므로 두 엔진이 다른 답을 낸다. 두 엔진 비교 테스트가 잡았다.
        argv += ["--glob", f"!**/{d}/**", "--glob", f"!**/{d}"]
    if glob_filter:
        argv += ["--glob", glob_filter]
    # **`--` 뒤에 경계를 통과한 경로만 넘긴다.** 패턴이 `-e` 로 시작해도
    # ripgrep 의 플래그로 먹히지 않는다.
    argv += ["--regexp", pattern, "--", str(root)]

    try:
        proc = subprocess.run(  # noqa: S603 — argv 리스트, 셸 없음
            argv, capture_output=True, text=True, timeout=RG_TIMEOUT, check=False
        )
    except (OSError, subprocess.TimeoutExpired):
        return None
    # 0=매치 있음, 1=매치 없음. 그 외는 ripgrep 쪽 문제.
    if proc.returncode not in (0, 1):
        return None

    base = workspace_root.resolve()
    out: list[Match] = []
    for line in proc.stdout.splitlines():
        if len(out) >= limit + 1:
            break
        try:
            event = json.loads(line)
        except ValueError:  # pragma: no cover — --json 은 한 줄 한 객체다
            continue
        if event.get("type") != "match":
            continue
        data = event.get("data", {})
        raw_path = (data.get("path") or {}).get("text")
        if not raw_path:
            continue
        try:
            rel = str(Path(raw_path).resolve().relative_to(base))  # awp-boundary-ok: 표시용
        except ValueError:  # pragma: no cover — rg 는 root 아래만 본다
            continue
        out.append(
            Match(
                path=rel,
                line_no=int(data.get("line_number") or 0),
                text=((data.get("lines") or {}).get("text") or "").rstrip("\n"),
            )
        )
    return out, "ripgrep"


def _grep_python(
    root: Path,
    pattern: str,
    glob_filter: str | None,
    ignore_case: bool,
    limit: int,
    workspace_root: Path,
) -> list[Match]:
    """ripgrep 이 없을 때. **느리지만 동작한다.**"""
    from ma_harness.tools._paths import Resolved

    flags = re.IGNORECASE if ignore_case else 0
    rx = re.compile(pattern, flags)
    base = workspace_root.resolve()
    out: list[Match] = []

    for found in _io.walk_files(Resolved(path=root, label="")):
        rel = str(found.relative_to(base))
        if _skipped(rel):
            continue
        if glob_filter and not (fnmatch(rel, glob_filter) or fnmatch(found.name, glob_filter)):
            continue
        target = Resolved(path=found, label=rel)
        try:
            if _io.looks_binary(target):
                continue
            text = _io.read_text(target)
        except OSError:  # pragma: no cover — 순회 중 사라진 파일
            continue
        for i, line in enumerate(text.splitlines(), 1):
            if rx.search(line):
                out.append(Match(path=rel, line_no=i, text=line))
                if len(out) >= limit + 1:
                    return out
    return out


__all__ = [
    "GLOB_LIMIT",
    "GREP_LIMIT",
    "RG_TIMEOUT",
    "SKIP_DIRS",
    "Match",
    "glob",
    "grep",
]
