"""`bash` — **티어 P 에서만 등록된다.**

`plan/07-sandbox.md` §2 §4 · `task/M2-sandbox-tools/T-0304-tier-process.md`.

내장 툴 8개 중 **7개는 샌드박스 셸이 필요 없다** (D13). 프로세스 세계가
필요한 것은 이것 하나뿐이고, 그래서 이것 하나 때문에 티어 P 가 있다.

이 모듈은 **감금된 argv 를 받아 실행할 뿐 감금하지 않는다.** 감금은
`SandboxProvider.confine()` 이 하고, 이 파일은 그 결과를 실행한 뒤
**거부인지 러너 고장인지 분류**한다 (`plan/07` §4.2).

> **셸을 거치지 않는다.** `shell=True` 로 띄우면 우리가 조립한 argv 가
> 다시 해석되고, `--` 뒤의 사용자 입력이 러너 플래그로 먹을 수 있다.
> 명령 문자열은 **게스트 안의** `/bin/sh -c` 에 넘긴다 — 그 셸은 이미
> 감금 안에 있다.
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass

from ma_sandbox.ports import ConfinedArgv, DenialKind, SandboxPolicy, SandboxProvider

from ma_harness.tools.fs import FsContext, ToolResult

#: 기본 상한. 모델이 `sleep 3600` 을 치는 일이 실제로 일어난다.
DEFAULT_TIMEOUT_SECONDS = 120.0

#: 넘길 수 있는 최대 상한. 모델이 정하게 두면 턴 하나가 영원히 돈다.
MAX_TIMEOUT_SECONDS = 600.0

#: 게스트 안에서 명령을 해석할 셸. **게스트 경로다.**
GUEST_SHELL = ("/bin/sh", "-c")


class RunnerFailure(RuntimeError):
    """**인프라 오류다.** 모델에 "작업 실패"로 보고하지 않는다.

    `plan/07` §4.2 — 인프라 장애를 작업 실패로 주면 모델이 엉뚱한 재시도를
    한다. 같은 명령을 다시 쳐도 bwrap 이 없는 것은 여전히 없다.
    """

    def __init__(self, message: str, *, stderr: str = "") -> None:
        super().__init__(message)
        self.stderr = stderr


@dataclass(frozen=True, slots=True)
class BashContext:
    """`bash` 한 번에 필요한 전부.

    `fs` 를 들고 있는 이유는 **출력 spill 때문**이다. 큰 출력을 파일로
    내리는 경로는 이미 `FsContext.emit()` 에 있고, 그것은 경계를 통과한
    쓰기(`_io`)를 쓴다. 여기서 따로 파일을 열면 `ADR-0008` 의 단일
    진입점이 둘이 된다.
    """

    provider: SandboxProvider
    policy: SandboxPolicy
    fs: FsContext


async def bash(
    ctx: BashContext,
    command: str,
    *,
    timeout_seconds: float = DEFAULT_TIMEOUT_SECONDS,
) -> ToolResult:
    """명령을 감금된 서브프로세스로 돌린다.

    돌려주는 것은 **툴 결과**다. 거부(권한 없음)는 `is_error=True` 인 결과로
    모델에 간다 — 모델이 고칠 수 있는 실수이기 때문이다. 러너 고장은
    `RunnerFailure` 로 올라가 `session.error` 가 된다.
    """
    if not command.strip():
        return ToolResult(content="빈 명령이다", is_error=True)

    budget = min(max(timeout_seconds, 1.0), MAX_TIMEOUT_SECONDS)
    confined = ctx.provider.confine((*GUEST_SHELL, command), ctx.policy)

    try:
        proc = await asyncio.create_subprocess_exec(
            *confined.argv,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            # **환경을 주지 않는다.** bwrap 의 `--clearenv` 가 이미 지우지만,
            # 감금되지 않은 provider(`local`)에서도 새지 않아야 한다.
            env={},
        )
    except OSError as exc:
        raise RunnerFailure(f"러너를 띄우지 못했다: {exc}") from exc

    try:
        out, err = await asyncio.wait_for(proc.communicate(), timeout=budget)
    except TimeoutError:
        proc.kill()
        await proc.wait()
        return ToolResult(content=f"{budget:.0f}초 안에 끝나지 않아 중단했다", is_error=True)

    stdout = out.decode("utf-8", "replace")
    stderr = err.decode("utf-8", "replace")
    code = proc.returncode if proc.returncode is not None else -1

    _raise_if_runner_broke(confined, code, stderr)
    return _as_result(ctx, stdout, stderr, code)


def _raise_if_runner_broke(confined: ConfinedArgv, code: int, stderr: str) -> None:
    """**모르면 보수적으로.** `UNKNOWN` 도 러너 고장으로 다룬다.

    단 종료 코드 0 은 예외다 — 성공했는데 stderr 에 모를 말이 섞인 것을
    장애로 올리면, 경고를 내는 멀쩡한 명령마다 세션이 죽는다.
    """
    if code == 0:
        return
    kind = confined.classify(exit_code=code, stderr=stderr)
    if kind is DenialKind.RUNNER_FAILURE:
        raise RunnerFailure("샌드박스 러너가 고장났다", stderr=stderr[:2000])


def _as_result(ctx: BashContext, stdout: str, stderr: str, code: int) -> ToolResult:
    body = stdout
    if stderr:
        body = f"{body}\n--- stderr ---\n{stderr}" if body else stderr
    if code != 0:
        body = f"{body}\n--- 종료 코드 {code} ---" if body else f"종료 코드 {code}"

    out = ctx.fs.emit(body or "(출력 없음)", label="bash")
    return ToolResult(content=out.text, is_error=code != 0, spilled_to=out.spilled_to)


__all__ = [
    "DEFAULT_TIMEOUT_SECONDS",
    "GUEST_SHELL",
    "MAX_TIMEOUT_SECONDS",
    "BashContext",
    "RunnerFailure",
    "bash",
]
