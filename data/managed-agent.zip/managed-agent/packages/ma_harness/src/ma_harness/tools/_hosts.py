"""호스트 허용 판정 — **두 목록이 서로 다르게 매칭된다.**

`plan/07-sandbox.md` §2 · `ref/claude-managed-agents/06-tools/tools-web-restrictions.md`
· `task/M2-sandbox-tools/T-0306-web-tools.md`.

| 목록 | 어디서 오는가 | `example.com` 항목이 덮는 것 |
|---|---|---|
| 툴의 `allowed_domains`/`blocked_domains` | 에이전트 설정 | `example.com` **과 모든 서브도메인** |
| 환경의 `allowed_hosts`/`blocked_hosts` | 환경 설정 | `example.com` **하나뿐**. `*.` 로 시작해야 서브도메인 |

**이 비대칭이 공식 계약이다.** 하나로 합치고 싶은 유혹이 크지만, 합치면
둘 중 하나가 의도보다 넓어진다 — 환경 쪽이 넓어지면 운영자가 좁혔다고
믿는 경계가 실제로는 안 좁혀져 있다.

```
툴 allowed_domains = ["example.com"]  → docs.example.com 허용
환경 allowed_hosts  = ["example.com"]  → docs.example.com **거부**
환경 allowed_hosts  = ["*.example.com"] → docs.example.com 허용
```

**검사는 리다이렉트 홉마다 한다.** 첫 URL 만 보면 허용된 호스트가 금지된
곳으로 리다이렉트시켜 우회할 수 있다 (`web.py`).
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
from urllib.parse import urlsplit

from ma_domain.hosts import covers_subdomains, matches_exact_host

#: 목록 하나의 항목 수 상한 (공식 계약).
MAX_DOMAINS = 64
#: 항목 하나의 길이 상한.
MAX_DOMAIN_CHARS = 255

#: 도메인에 쓸 수 있는 문자. 공식: ASCII 영문자·숫자·하이픈·밑줄·점.
_ALLOWED_CHARS = set("abcdefghijklmnopqrstuvwxyz0123456789-_.")

#: 두 라벨짜리 **레지스트리 접미사**. 여기 있는 것을 `allowed_domains` 에
#: 넣으면 그 아래 전부가 열린다 — `co.uk` 하나로 영국 상업 도메인 전체다.
#:
#: **Public Suffix List 가 아니다.** PSL 은 10,000줄짜리 데이터 파일이고
#: 주기적으로 갱신해야 하며, 갱신을 빠뜨리면 **틀린 줄 모르고 틀린다**.
#: 여기 있는 것은 사내에서 실제로 나올 법한 것만 추린 **최선 노력**이고,
#: 그 사실을 숨기지 않는다 (`IMPL-0018`).
#:
#: 빠진 접미사를 누가 넣으면 그 아래가 통째로 열린다. 그것을 막는 최종
#: 방어선은 이 목록이 아니라 **환경의 `allowed_hosts`** 다 — 그쪽은 정확
#: 일치라 `co.uk` 를 넣어도 `co.uk` 하나만 열린다.
KNOWN_REGISTRY_SUFFIXES = frozenset(
    {
        "co.kr",
        "or.kr",
        "ne.kr",
        "go.kr",
        "re.kr",
        "pe.kr",
        "ac.kr",
        "co.uk",
        "org.uk",
        "ac.uk",
        "gov.uk",
        "me.uk",
        "net.uk",
        "co.jp",
        "ne.jp",
        "or.jp",
        "ac.jp",
        "go.jp",
        "com.au",
        "net.au",
        "org.au",
        "edu.au",
        "gov.au",
        "com.cn",
        "net.cn",
        "org.cn",
        "gov.cn",
        "edu.cn",
        "com.br",
        "com.mx",
        "com.ar",
        "com.tr",
        "com.tw",
        "com.hk",
        "com.sg",
        "com.my",
        "com.ph",
        "com.vn",
        "co.in",
        "co.id",
        "co.za",
        "co.nz",
        "com.pl",
        "com.ua",
    }
)

#: 이 스킴만 가져온다. `file:` · `data:` · `gopher:` 는 **호스트 검사를
#: 통과해 버린다** (호스트가 없으므로) — 그래서 스킴을 먼저 건다.
ALLOWED_SCHEMES = frozenset({"http", "https"})


class DomainListError(ValueError):
    """도메인 목록이 규칙을 어겼다. **환경/에이전트 생성 단계에서 막는다.**"""


class Verdict(StrEnum):
    ALLOWED = "allowed"
    #: 목록이 막았다. 모델에게 `url_not_allowed` 로 간다.
    NOT_ALLOWED = "url_not_allowed"
    #: URL 자체가 쓸 수 없는 모양이다.
    MALFORMED = "malformed_url"


@dataclass(frozen=True, slots=True)
class Decision:
    verdict: Verdict
    #: 왜. 이벤트에 남긴다 — "왜 막혔나"를 운영자가 추적할 수 있어야 한다.
    reason: str = ""

    @property
    def ok(self) -> bool:
        return self.verdict is Verdict.ALLOWED


def normalize_domain(raw: str) -> str:
    """목록 항목 하나를 정규화한다. **규칙을 어기면 예외.**

    여기서 거부하는 것들은 전부 "쓴 사람의 의도와 다르게 동작할" 모양이다.
    `https://example.com` 을 그냥 받아 주면 어떤 호스트와도 일치하지 않아
    **아무것도 허용되지 않는 allowed_domains** 가 된다 — 조용히.
    """
    value = raw.strip().rstrip("/").lower()
    if not value:
        raise DomainListError("빈 도메인")
    if len(value) > MAX_DOMAIN_CHARS:
        raise DomainListError(f"도메인이 {MAX_DOMAIN_CHARS}자를 넘는다: {raw!r}")
    if "://" in value:
        raise DomainListError(f"스킴을 빼십시오: {raw!r}")
    if ":" in value:
        raise DomainListError(f"포트를 빼십시오: {raw!r}")
    if "/" in value:
        raise DomainListError(f"경로를 빼십시오: {raw!r}")
    if value.startswith("*."):
        raise DomainListError(f"와일드카드를 쓰지 않습니다 — 항목은 서브도메인을 덮습니다: {raw!r}")
    if set(value) - _ALLOWED_CHARS:
        raise DomainListError(f"쓸 수 없는 문자가 있다: {raw!r}")
    if "." not in value:
        raise DomainListError(f"최상위 도메인만으로는 안 된다: {raw!r}")
    if _looks_like_ip(value):
        raise DomainListError(f"IP 주소는 쓸 수 없다 — 도메인 이름을 쓰십시오: {raw!r}")
    if value in KNOWN_REGISTRY_SUFFIXES:
        raise DomainListError(
            f"레지스트리 접미사다 — 그 아래 전부가 열린다: {raw!r} (예: example.{value})"
        )
    return value


def normalize_list(raw: tuple[str, ...]) -> tuple[str, ...]:
    """목록 전체. **빈 목록은 받지 않는다** — "제한 없음"은 `None` 이다.

    빈 튜플을 "아무것도 허용 안 함"으로 읽을지 "제한 없음"으로 읽을지가
    갈리는 지점이고, 갈리면 한쪽이 **의도와 정반대**가 된다.
    """
    if not raw:
        raise DomainListError("빈 목록 — 제한이 없으면 필드를 생략하십시오")
    if len(raw) > MAX_DOMAINS:
        raise DomainListError(f"도메인은 최대 {MAX_DOMAINS}개다 (받은 것 {len(raw)}개)")
    out = [normalize_domain(d) for d in raw]
    if len(set(out)) != len(out):
        dupes = sorted({d for d in out if out.count(d) > 1})
        raise DomainListError(f"중복된 도메인: {', '.join(dupes)}")
    return tuple(out)


def host_of(url: str) -> str | None:
    """URL 에서 호스트만. **쓸 수 없는 모양이면 `None`.**"""
    try:
        parts = urlsplit(url)
    except ValueError:
        return None
    if parts.scheme.lower() not in ALLOWED_SCHEMES:
        return None
    host = parts.hostname
    if not host:
        return None
    return host.lower().rstrip(".")


# 매칭 규칙 두 개는 **도메인에 있다** (`ma_domain.hosts`).
#
# 여기와 `ma_egress.allowlist` 가 같은 규칙을 쓰기 때문이다. 두 곳에 따로
# 쓰면 어긋나고, 어긋나면 **프록시가 막는 것과 툴이 막는 것이 달라진다** —
# 그 차이가 곧 우회 경로다.


@dataclass(frozen=True, slots=True)
class HostGate:
    """한 번의 요청이 통과해야 하는 전부.

    **두 층이 모두 통과해야 한다.** 툴 목록은 환경 목록을 넓힐 수 없다 —
    에이전트 설정이 환경의 경계를 넘을 수 있으면 환경 설정이 의미가 없다.
    """

    #: 툴의 `allowed_domains`. `None` 이면 이 축으로 제한하지 않는다.
    tool_allowed: tuple[str, ...] | None = None
    #: 툴의 `blocked_domains`.
    tool_blocked: tuple[str, ...] | None = None
    #: 환경의 `allowed_hosts`. `networking.kind == LIMITED` 일 때만 찬다.
    env_allowed: tuple[str, ...] | None = None
    env_blocked: tuple[str, ...] | None = None

    def __post_init__(self) -> None:
        if self.tool_allowed is not None and self.tool_blocked is not None:
            raise DomainListError("allowed_domains 와 blocked_domains 를 함께 줄 수 없다")
        if self.env_allowed is not None and self.env_blocked is not None:
            raise DomainListError("allowed_hosts 와 blocked_hosts 를 함께 줄 수 없다")

    def decide(self, url: str) -> Decision:
        host = host_of(url)
        if host is None:
            return Decision(Verdict.MALFORMED, f"가져올 수 없는 URL 이다: {url!r}")

        if self.env_blocked is not None and any(
            matches_exact_host(e, host) for e in self.env_blocked
        ):
            return Decision(Verdict.NOT_ALLOWED, f"환경의 blocked_hosts 가 막았다: {host}")
        if self.env_allowed is not None and not any(
            matches_exact_host(e, host) for e in self.env_allowed
        ):
            return Decision(Verdict.NOT_ALLOWED, f"환경의 allowed_hosts 에 없다: {host}")

        if self.tool_blocked is not None and any(
            covers_subdomains(e, host) for e in self.tool_blocked
        ):
            return Decision(Verdict.NOT_ALLOWED, f"툴의 blocked_domains 가 막았다: {host}")
        if self.tool_allowed is not None and not any(
            covers_subdomains(e, host) for e in self.tool_allowed
        ):
            return Decision(Verdict.NOT_ALLOWED, f"툴의 allowed_domains 에 없다: {host}")

        return Decision(Verdict.ALLOWED)

    @property
    def unrestricted(self) -> bool:
        """아무 목록도 없는가. **그 사실을 이벤트에 남겨야 한다** (T-0306)."""
        return not any((self.tool_allowed, self.tool_blocked, self.env_allowed, self.env_blocked))


def tool_list_within_env(
    tool_allowed: tuple[str, ...], env_allowed: tuple[str, ...]
) -> tuple[str, ...]:
    """툴 목록이 환경 목록 **안에** 있는가. 밖에 있는 항목을 돌려준다.

    공식 계약: 환경이 `limited` 인데 툴의 `allowed_domains` 에 환경
    `allowed_hosts` 밖의 항목이 있으면 **세션 생성이 400 으로 실패한다.**

    런타임에 조용히 막는 것과 생성 시점에 거부하는 것의 차이가 크다 —
    전자는 "설정했는데 왜 안 되지"가 되고, 후자는 그 자리에서 고친다.

    비대칭에 주의: 툴 항목 `docs.example.com` 은 환경 `["example.com"]`
    **안에 없다** (환경 규칙은 정확 일치). `["docs.example.com"]` 이나
    `["*.example.com"]` 이어야 안에 있다.
    """
    return tuple(
        entry
        for entry in tool_allowed
        if not any(matches_exact_host(env, entry) for env in env_allowed)
    )


def _looks_like_ip(value: str) -> bool:
    """IPv4 · 숫자 축약(`127.1`) · 괄호 IPv6. **마지막 라벨이 숫자면 IP다.**

    도메인의 최상위 라벨은 숫자로만 이뤄질 수 없다 (RFC 1123). 그래서
    `127.1` 도 `1.2.3.4` 도 이 한 줄로 걸린다.
    """
    if value.startswith("[") or ":" in value:
        return True
    return value.rsplit(".", 1)[-1].isdigit()


__all__ = [
    "ALLOWED_SCHEMES",
    "MAX_DOMAINS",
    "MAX_DOMAIN_CHARS",
    "Decision",
    "DomainListError",
    "HostGate",
    "Verdict",
    "covers_subdomains",
    "host_of",
    "matches_exact_host",
    "normalize_domain",
    "normalize_list",
    "tool_list_within_env",
]
