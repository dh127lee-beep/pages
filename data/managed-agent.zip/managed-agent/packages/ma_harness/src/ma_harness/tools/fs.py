"""`read` · `write` · `edit` — **호스트 함수. 샌드박스 셸이 필요 없다** (D13).

`plan/07-sandbox.md` §2 · `plan/06-harness-and-model.md` §4.4.

"내장 툴 8개 중 7개가 샌드박스 셸을 필요로 하지 않는다"는 것이 티어 W 의
근거다. 이 셋이 호스트 함수로 동작해야 그 전제가 성립한다.

**툴 실패는 예외가 아니라 결과다.** 경로를 잘못 주거나 `old_string` 이
유일하지 않은 것은 모델이 고칠 수 있는 실수이고, 예외로 올리면 턴 하나가
통째로 죽는다.
"""

from __future__ import annotations

import base64
from dataclasses import dataclass
from typing import TYPE_CHECKING

from ma_harness.tools import _io
from ma_harness.tools._paths import Denied, Resolved, resolve
from ma_harness.tools.spill import Output, clamp, spill

if TYPE_CHECKING:
    from pathlib import Path

#: `read` 가 한 번에 돌려주는 최대 줄 수. 넘으면 offset 으로 이어 읽는다.
DEFAULT_LINE_LIMIT = 2_000

#: 이미지로 다룰 확장자. 카드가 `supports_vision` 일 때만 실제로 싣는다.
IMAGE_SUFFIXES = frozenset({".png", ".jpg", ".jpeg", ".gif", ".webp"})
PDF_SUFFIXES = frozenset({".pdf"})

#: 이미지·PDF 의 최대 바이트. 넘으면 싣지 않고 경로만 알려 준다.
MAX_BINARY_BYTES = 5 * 1024 * 1024


@dataclass(frozen=True, slots=True)
class ToolResult:
    """모델에게 가는 것. **`is_error` 여도 예외가 아니다.**"""

    content: str
    is_error: bool = False
    spilled_to: str | None = None
    #: 이미지를 실을 때. `(media_type, base64)`.
    image: tuple[str, str] | None = None

    @classmethod
    def error(cls, message: str) -> ToolResult:
        return cls(content=message, is_error=True)

    @classmethod
    def of(cls, out: Output) -> ToolResult:
        return cls(content=out.text, spilled_to=out.spilled_to)


@dataclass(frozen=True, slots=True)
class FsContext:
    """툴이 필요한 것 전부. **워크스페이스 루트와 쓰기 권한.**"""

    workspace_root: Path
    writable: bool = True
    #: 카드가 비전을 지원하는가. 아니면 이미지를 싣지 않는다.
    supports_vision: bool = False

    def _write_raw(self, relative: str, text: str) -> None:
        """spill 전용. **경계를 다시 통과시킨다** — 지름길을 만들지 않는다."""
        got = resolve(self.workspace_root, relative)
        if isinstance(got, Denied):  # pragma: no cover — 우리가 만든 경로다
            raise RuntimeError(got.message)
        _io.write_text(got, text)

    def emit(self, text: str, *, label: str) -> Output:
        """상한을 넘으면 spill. 쓰기 권한이 없으면 자르기만 한다."""
        if not self.writable:
            return clamp(text)
        return spill(
            text,
            workspace_root=self.workspace_root,
            label=label,
            write_file=self._write_raw,
        )


# ── read ──────────────────────────────────────────────────
def read(
    ctx: FsContext, path: str, *, offset: int = 0, limit: int = DEFAULT_LINE_LIMIT
) -> ToolResult:
    """파일을 읽는다. 텍스트 / 이미지 / PDF 를 **카드 능력에 따라** 분기한다.

    `offset`·`limit` 은 줄 단위다. 큰 파일을 통째로 주면 컨텍스트를 먹으므로
    기본 2,000줄에서 자르고, 모델이 이어 읽을 수 있게 안내한다.
    """
    got = resolve(ctx.workspace_root, path)
    if isinstance(got, Denied):
        return ToolResult.error(got.message)
    if not _io.exists(got):
        return ToolResult.error(f"파일이 없다: {got.label}")
    if not _io.is_file(got):
        return ToolResult.error(f"파일이 아니다: {got.label}")

    suffix = got.path.suffix.lower()
    if suffix in IMAGE_SUFFIXES:
        return _read_image(ctx, got)
    if suffix in PDF_SUFFIXES:
        return _read_pdf(ctx, got)
    if _io.looks_binary(got):
        size = _io.size_of(got)
        return ToolResult.error(
            f"바이너리 파일이다 ({size:,}바이트): {got.label} — 텍스트로 읽을 수 없다"
        )

    lines = _io.read_text(got).splitlines()
    total = len(lines)
    if offset < 0:
        return ToolResult.error("offset 은 0 이상이어야 한다")
    window = lines[offset : offset + limit]

    # **줄 번호를 붙인다.** `edit` 이 참조할 수 있고, 모델이 "몇 번째 줄"을
    # 말할 수 있다.
    numbered = "\n".join(f"{offset + i + 1:>6}\t{line}" for i, line in enumerate(window))
    shown = offset + len(window)
    if shown < total:
        numbered += f"\n\n…{total - shown:,}줄 더 있다. `offset={shown}` 으로 이어 읽는다."

    return ToolResult.of(ctx.emit(numbered, label=f"read-{got.path.name}"))


def _read_image(ctx: FsContext, got: Resolved) -> ToolResult:
    """**카드가 비전을 지원할 때만 싣는다.**

    지원하지 않는데 실으면 어댑터가 거부하거나(400) 조용히 버린다. 둘 다
    모델에게는 "읽었는데 안 보인다"로 나타나므로, 여기서 분명히 말한다.
    """
    size = _io.size_of(got)
    if not ctx.supports_vision:
        return ToolResult.error(
            f"이 모델은 이미지를 보지 못한다: {got.label} ({size:,}바이트). "
            "비전을 지원하는 모델 카드로 세션을 열어야 한다."
        )
    if size > MAX_BINARY_BYTES:
        return ToolResult.error(
            f"이미지가 너무 크다 ({size:,}바이트 > {MAX_BINARY_BYTES:,}): {got.label}"
        )
    data = base64.b64encode(_io.read_bytes(got)).decode("ascii")
    media = f"image/{got.path.suffix.lower().lstrip('.').replace('jpg', 'jpeg')}"
    return ToolResult(content=f"이미지: {got.label}", image=(media, data))


def _read_pdf(ctx: FsContext, got: Resolved) -> ToolResult:
    """PDF 는 **아직 텍스트로 뽑지 않는다**.

    추출기(pypdf 등)를 넣으면 의존성과 함께 "어떤 PDF 를 어떻게 뽑는가"라는
    긴 꼬리가 생긴다. 지금은 **못 한다고 분명히 말한다** — 조용히 깨진 텍스트를
    주는 것보다 낫다. M4 의 파일 작업(T-0502)에서 함께 정한다.
    """
    size = _io.size_of(got)
    return ToolResult.error(f"PDF 텍스트 추출은 아직 지원하지 않는다: {got.label} ({size:,}바이트)")


# ── write ─────────────────────────────────────────────────
def write(ctx: FsContext, path: str, content: str) -> ToolResult:
    """파일을 쓴다. 부모 디렉터리는 자동으로 만든다."""
    if not ctx.writable:
        return ToolResult.error("읽기 전용 세션이라 쓸 수 없다")
    got = resolve(ctx.workspace_root, path)
    if isinstance(got, Denied):
        return ToolResult.error(got.message)
    if _io.exists(got) and not _io.is_file(got):
        return ToolResult.error(f"파일이 아니다: {got.label}")

    written = _io.write_text(got, content)
    return ToolResult(content=f"{got.label} 에 {written:,}바이트를 썼다")


# ── edit ──────────────────────────────────────────────────
def edit(
    ctx: FsContext,
    path: str,
    old_string: str,
    new_string: str,
    *,
    replace_all: bool = False,
) -> ToolResult:
    """문자열을 치환한다.

    **`old_string` 유일성 검사가 핵심이다.** 두 군데 이상 맞으면 어디를
    고칠지 모르는 채로 고치게 된다 — 모델에게 **에러 문자열로** 돌려주어
    더 긴 맥락을 포함한 `old_string` 을 다시 주게 한다.
    """
    if not ctx.writable:
        return ToolResult.error("읽기 전용 세션이라 고칠 수 없다")
    if old_string == new_string:
        return ToolResult.error("old_string 과 new_string 이 같다")

    got = resolve(ctx.workspace_root, path)
    if isinstance(got, Denied):
        return ToolResult.error(got.message)
    if not _io.exists(got) or not _io.is_file(got):
        return ToolResult.error(f"파일이 없다: {got.label}")
    if _io.looks_binary(got):
        return ToolResult.error(f"바이너리 파일은 고칠 수 없다: {got.label}")

    before = _io.read_text(got)
    count = before.count(old_string)
    if count == 0:
        return ToolResult.error(
            f"{got.label} 에서 old_string 을 찾지 못했다. 공백과 들여쓰기까지 정확히 일치해야 한다."
        )
    if count > 1 and not replace_all:
        return ToolResult.error(
            f"{got.label} 에서 old_string 이 {count}곳에 맞는다. "
            "더 긴 맥락을 포함해 유일하게 만들거나 replace_all=true 를 준다."
        )

    after = (
        before.replace(old_string, new_string)
        if replace_all
        else before.replace(old_string, new_string, 1)
    )
    _io.write_text(got, after)
    where = f"{count}곳" if replace_all else "1곳"
    return ToolResult(content=f"{got.label} 에서 {where}을 고쳤다")


__all__ = [
    "DEFAULT_LINE_LIMIT",
    "IMAGE_SUFFIXES",
    "MAX_BINARY_BYTES",
    "PDF_SUFFIXES",
    "FsContext",
    "ToolResult",
    "edit",
    "read",
    "write",
]
