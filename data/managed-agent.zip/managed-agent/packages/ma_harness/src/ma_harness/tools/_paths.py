"""호스트 툴의 경로 해석 — **`resolve_in_workspace` 만 쓴다**.

`plan/07-sandbox.md` §8 · `ADR-0008`.

다른 경로 해석 코드를 만들지 않는다. 이 모듈은 그 함수를 감싸 툴이 쓰기
좋은 모양(결과 유니온)으로 바꿀 뿐이고, **판정 로직은 하나도 없다**.

`tools/check_architecture.py` 의 "워크스페이스 경계 단일 진입점" 검사가
이 패키지 안의 직접 파일 접근을 금지한다. 이 파일이 그 검사에 걸리지 않는
이유는 `Path` 를 **호출하지 않고 타입으로만** 쓰기 때문이다.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from ma_sandbox.paths import PathEscape, relative_label, resolve_in_workspace

if TYPE_CHECKING:
    from pathlib import Path


@dataclass(frozen=True, slots=True)
class Resolved:
    """경계를 통과한 경로. **이것 없이는 파일을 열지 않는다.**"""

    path: Path
    #: 모델에게 보여줄 상대 경로. 절대 경로를 노출하지 않는다.
    label: str


@dataclass(frozen=True, slots=True)
class Denied:
    """경계 밖. **예외가 아니라 결과다** — 툴 실패는 모델에게 돌려줄 문자열이다."""

    candidate: str
    message: str


type PathResult = Resolved | Denied


def resolve(root: Path, candidate: str) -> PathResult:
    """경계 검사. 실패를 **예외가 아니라 결과로** 돌려준다.

    하네스가 예외로 죽으면 턴 하나가 통째로 실패한다. 경로를 잘못 준 것은
    모델이 고칠 수 있는 실수이므로, 에러 문자열로 돌려주고 다음 step 에서
    다시 시도하게 한다.
    """
    try:
        target = resolve_in_workspace(root, candidate)
    except PathEscape:
        # **이유를 모델에게 주지 않는다** — 탐색을 도와주는 셈이다.
        return Denied(candidate=candidate, message=f"워크스페이스 밖 경로: {candidate}")
    return Resolved(path=target, label=relative_label(root, target))


__all__ = ["Denied", "PathResult", "Resolved", "resolve"]
