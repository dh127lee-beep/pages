"""출력 상한과 spill — **모델 보호 장치**.

`plan/06-harness-and-model.md` §4.4 · `plan/07-sandbox.md` §2.

툴 출력 하나가 100,000자(약 25K 토큰)를 넘으면 컨텍스트를 통째로 먹고
**캐시 접두사를 날린다**. DeepSeek 기준 캐시 히트와 미스는 50배 차이라,
큰 출력 한 번이 그 세션의 남은 비용을 바꾼다.

그래서 상한을 넘으면 워크스페이스 파일로 쓰고 모델에는 **잘린 프리뷰 + 경로**
만 준다. 공식 CMA 와 같은 동작이다.

모델이 전체를 보려면 그 경로를 `read` 하면 된다 — 그때는 **모델이 그 비용을
의도한 것**이고, offset/limit 으로 필요한 부분만 가져올 수도 있다.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pathlib import Path

#: 모델이 받는 최대 글자 수. `plan/06` §4.4.
MAX_OUTPUT_CHARS = 100_000

#: spill 했을 때 모델에게 보여줄 앞부분.
PREVIEW_CHARS = 2_000

#: spill 파일이 사는 곳. 워크스페이스 **안**이라 모델이 `read` 로 꺼낼 수 있고,
#: 세션이 끝나면 워크스페이스와 함께 사라진다 (`IMPL-0015`).
SPILL_DIR = ".awp/outputs"


@dataclass(frozen=True, slots=True)
class Output:
    """툴이 모델에게 돌려주는 것."""

    text: str
    #: spill 됐으면 그 경로(워크스페이스 상대). 아니면 `None`.
    spilled_to: str | None = None
    #: 원본 길이. 관측용 — 얼마나 잘렸는지 운영이 알아야 한다.
    original_chars: int = 0

    @property
    def was_spilled(self) -> bool:
        return self.spilled_to is not None


def fits(text: str) -> bool:
    return len(text) <= MAX_OUTPUT_CHARS


def spill(
    text: str,
    *,
    workspace_root: Path,
    label: str,
    write_file: object,
) -> Output:
    """상한을 넘으면 파일로 쓰고 프리뷰를 돌려준다.

    `write_file` 을 주입받는 이유: 이 모듈이 **직접 파일을 열지 않기** 위해서다.
    `ma_harness.tools` 안에서 `open(` 은 CI 가 막는다 (`ADR-0008`) — 그 규칙을
    `# awp-boundary-ok` 로 우회하는 대신, 쓰기를 이미 경계를 통과한 호출자에게
    맡긴다.

    `label` 은 파일 이름에 들어간다. 같은 툴이 여러 번 spill 해도 내용 해시로
    구분되므로 **덮어쓰지 않는다**.
    """
    original = len(text)
    if original <= MAX_OUTPUT_CHARS:
        return Output(text=text, original_chars=original)

    digest = hashlib.sha256(text.encode("utf-8", "surrogatepass")).hexdigest()[:12]
    safe_label = "".join(c if c.isalnum() or c in "-_" else "_" for c in label)[:40]
    rel = f"{SPILL_DIR}/{safe_label}-{digest}.txt"

    write_file(rel, text)  # type: ignore[operator]

    preview = text[:PREVIEW_CHARS]
    dropped = original - len(preview)
    return Output(
        text=(
            f"{preview}\n\n"
            f"…출력이 {original:,}자라 잘렸다 ({dropped:,}자 생략). "
            f"전체는 `{rel}` 에 있다 — `read` 로 offset/limit 을 주어 꺼낼 수 있다."
        ),
        spilled_to=rel,
        original_chars=original,
    )


def clamp(text: str) -> Output:
    """spill 없이 **자르기만** 한다.

    파일로 쓸 수 없는 상황(읽기 전용 정책)에서 쓴다. 전체를 잃지만 **컨텍스트를
    날리는 것보다 낫다**.
    """
    original = len(text)
    if original <= MAX_OUTPUT_CHARS:
        return Output(text=text, original_chars=original)
    return Output(
        text=(
            f"{text[:MAX_OUTPUT_CHARS]}\n\n"
            f"…{original - MAX_OUTPUT_CHARS:,}자 잘림 (쓰기 권한이 없어 저장하지 못했다)"
        ),
        original_chars=original,
    )


__all__ = [
    "MAX_OUTPUT_CHARS",
    "PREVIEW_CHARS",
    "SPILL_DIR",
    "Output",
    "clamp",
    "fits",
    "spill",
]
