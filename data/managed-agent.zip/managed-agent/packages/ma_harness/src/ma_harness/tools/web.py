"""`web_fetch` · `web_search` — **신뢰 영역에서 돈다.**

`plan/07-sandbox.md` §2 · `plan/06-harness-and-model.md` §4.4 ·
`task/M2-sandbox-tools/T-0306-web-tools.md`.

공식 CMA 도 웹 툴을 샌드박스 밖에서 돌린다. 그래서 **샌드박스에 네트워크가
없어도 에이전트는 웹을 본다 — 우리가 중개하는 경로로만.** 이것이 티어 W 가
소켓을 주지 않고도 쓸 만한 이유이기도 하다 (D13).

```
게스트 (네트워크 0)          호스트 (신뢰 영역)
  run_code  ───────────        web_fetch ──→ HostGate ──→ httpx ──→ 인터넷
  소켓 없음                       ↑ 홉마다 검사
```

> **리다이렉트 홉마다 검사한다.** 첫 URL 만 보면 허용된 호스트가 금지된
> 곳으로 302 를 주어 우회할 수 있다. 그래서 `follow_redirects=False` 로
> 두고 **우리가 직접 따라간다**.

> **TODO(T-0402)**: 지금은 직접 나간다. egress 프록시가 생기면 그쪽으로
> 보내고, 자격증명 주입도 거기서 일어난다 (D5). `credential_events` 에
> 남길 자리는 `FetchTrace` 가 들고 있다.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Protocol

import anyio

from ma_harness.tools._hosts import Decision, HostGate, Verdict, host_of
from ma_harness.tools.fs import ToolResult

if TYPE_CHECKING:
    from collections.abc import Sequence

#: 응답 본문 상한. 100MB 문서를 가져와 **컨텍스트를 폭파시키지 않게.**
MAX_RESPONSE_BYTES = 5 * 1024 * 1024

#: 모델 컨텍스트에 들어갈 상한. 바이트 상한과 **다른 축**이다 — 5MB HTML 이
#: 마크다운으로는 200KB 가 될 수 있고, 그래도 여전히 너무 크다.
DEFAULT_MAX_CONTENT_CHARS = 100_000

#: 한 번의 `web_fetch` 가 쓸 수 있는 시간.
DEFAULT_TIMEOUT_SECONDS = 30.0

#: 따라갈 리다이렉트 수. 넘으면 **고리에 빠진 것**으로 본다.
MAX_REDIRECTS = 5

#: 보낼 User-Agent. 우리를 숨기지 않는다 — 사이트 운영자가 차단할 수
#: 있어야 하는 것이 맞다.
USER_AGENT = "AWP-Agent/0.1 (+내부 에이전트 플랫폼)"


class HttpResponse(Protocol):
    """`httpx.Response` 중 우리가 쓰는 것만. **테스트가 가짜를 넣을 수 있게.**"""

    status_code: int
    headers: dict[str, str]
    text: str
    content: bytes


class HttpClient(Protocol):
    """주입받는다 — 이 모듈이 `httpx` 를 직접 들지 않는다.

    `ma_harness` 는 provider SDK 를 모른다 (`.importlinter` 의
    `harness-neutral`). HTTP 클라이언트도 같은 이유로 바깥에서 온다.

    **타임아웃을 인자로 받지 않는다.** 주입받은 클라이언트가 그것을
    지킬지 우리가 보장할 수 없고, 안 지키면 턴 하나가 영원히 매달린다.
    그래서 `web_fetch` 가 `anyio.fail_after` 로 **자기가 끊는다.**
    어댑터는 자기 기본 타임아웃을 더 짧게 둘 수 있고 그래도 된다.
    """

    async def get(self, url: str, *, headers: dict[str, str]) -> HttpResponse: ...


@dataclass
class FetchTrace:
    """이번 요청이 지나간 길. **이벤트에 남긴다.**"""

    hops: list[str] = field(default_factory=list)
    #: 막혔으면 어디서 왜.
    blocked_at: str | None = None
    reason: str = ""
    #: 목록이 하나도 없었는가. **"검사를 건너뛰었다"도 기록할 사실이다**
    #: (`T-0306` 구현 지침).
    unrestricted: bool = False
    #: TODO(T-0402) — egress 프록시가 주입한 자격증명. 지금은 항상 비었다.
    credentials_used: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class WebContext:
    """`web_fetch` 한 번에 필요한 전부."""

    client: HttpClient
    gate: HostGate
    max_content_chars: int = DEFAULT_MAX_CONTENT_CHARS
    timeout_seconds: float = DEFAULT_TIMEOUT_SECONDS


async def web_fetch(ctx: WebContext, url: str) -> tuple[ToolResult, FetchTrace]:
    """URL 을 가져와 마크다운에 가깝게 바꾼다.

    돌려주는 것은 `(결과, 추적)` 이다. 추적은 **모델에게 가지 않고**
    이벤트로 간다 — 어느 홉에서 막혔는지는 운영자가 볼 것이지 모델이
    볼 것이 아니다 (모델에게는 "막혔다"로 충분하고, 더 주면 우회할 길을
    탐색하는 재료가 된다).
    """
    trace = FetchTrace(unrestricted=ctx.gate.unrestricted)
    current = url

    for _ in range(MAX_REDIRECTS + 1):
        decision = ctx.gate.decide(current)
        trace.hops.append(current)
        if not decision.ok:
            trace.blocked_at = current
            trace.reason = decision.reason
            return _denied(decision, current), trace

        try:
            with anyio.fail_after(ctx.timeout_seconds):
                response = await ctx.client.get(
                    current,
                    headers={
                        "User-Agent": USER_AGENT,
                        "Accept": "text/html,text/plain,*/*",
                    },
                )
        except TimeoutError:
            trace.reason = f"{ctx.timeout_seconds:.0f}초 안에 응답이 없었다"
            return ToolResult(content=trace.reason, is_error=True), trace
        except Exception as exc:
            # 어떤 네트워크 오류든 **툴 실패**다 — 인프라 오류가 아니다.
            # 모델이 다른 URL 을 시도하면 되는 종류의 일이다.
            trace.reason = f"{type(exc).__name__}: {exc}"
            return (
                ToolResult(content=f"가져오지 못했다: {type(exc).__name__}", is_error=True),
                trace,
            )

        location = _redirect_target(response, current)
        if location is None:
            return _as_result(ctx, response, current), trace
        current = location

    trace.reason = f"리다이렉트가 {MAX_REDIRECTS}회를 넘었다"
    return ToolResult(content=trace.reason, is_error=True), trace


def _redirect_target(response: HttpResponse, base: str) -> str | None:
    """리다이렉트면 다음 URL. 아니면 `None`.

    상대 경로 `Location` 을 절대 URL 로 만든다 — 만들지 않으면 다음 홉의
    호스트 검사가 **호스트 없음**으로 떨어져 `malformed` 가 되고, 실제로는
    같은 호스트 안의 정상 리다이렉트인데 막힌다.
    """
    if response.status_code not in (301, 302, 303, 307, 308):
        return None
    location = response.headers.get("location") or response.headers.get("Location")
    if not location:
        return None
    from urllib.parse import urljoin

    return urljoin(base, location)


def _denied(decision: Decision, url: str) -> ToolResult:
    """**모델에게는 코드와 호스트만.** 어느 목록이 막았는지는 주지 않는다.

    "툴의 allowed_domains 에 없다" 를 모델에게 주면, 모델이 목록을 탐색하는
    재료가 된다. 그 정보는 추적(`FetchTrace`)으로 운영자에게 간다.
    """
    code = decision.verdict.value
    host = host_of(url) or url
    if decision.verdict is Verdict.MALFORMED:
        return ToolResult(content=f"{code}: 가져올 수 없는 URL 이다", is_error=True)
    return ToolResult(content=f"{code}: {host} 에 접근할 수 없다", is_error=True)


def _as_result(ctx: WebContext, response: HttpResponse, url: str) -> ToolResult:
    if response.status_code >= 400:
        return ToolResult(content=f"HTTP {response.status_code} — {url}", is_error=True)

    raw = response.content[: MAX_RESPONSE_BYTES + 1]
    too_big = len(raw) > MAX_RESPONSE_BYTES
    text = raw[:MAX_RESPONSE_BYTES].decode("utf-8", "replace")

    content_type = (response.headers.get("content-type") or "").lower()
    body = to_markdown(text) if "html" in content_type else text

    if len(body) > ctx.max_content_chars:
        body = (
            body[: ctx.max_content_chars] + f"\n\n…본문이 {ctx.max_content_chars:,}자를 넘어 잘렸다"
        )
    elif too_big:
        body += f"\n\n…응답이 {MAX_RESPONSE_BYTES:,}바이트를 넘어 잘렸다"

    return ToolResult(content=f"# {url}\n\n{body}")


# ── HTML → 마크다운 ──────────────────────────────────────
#
# **라이브러리를 쓰지 않는다** (`IMPL-0018`). 후보(`markdownify`,
# `html2text`, `trafilatura`)는 전부 의존성을 끌고 오고, 그중 일부는
# 네트워크를 쓴다. 우리가 필요한 것은 "모델이 읽을 수 있는 텍스트"이지
# 왕복 변환이 아니다.
_DROP_BLOCKS = re.compile(
    r"<(script|style|noscript|svg|head)\b[^>]*>.*?</\1>", re.IGNORECASE | re.DOTALL
)
_BREAKS = re.compile(r"</?(br|p|div|li|tr|h[1-6]|section|article)\b[^>]*>", re.IGNORECASE)
_TAGS = re.compile(r"<[^>]+>")
_BLANKS = re.compile(r"\n{3,}")


def to_markdown(html: str) -> str:
    """HTML 을 읽을 수 있는 평문으로. **완벽하지 않지만 충분하다.**

    `<script>`/`<style>` 을 먼저 통째로 버리는 것이 핵심이다 — 태그만
    지우면 자바스크립트 소스가 본문으로 남아 컨텍스트를 먹는다.
    """
    import html as html_mod

    text = _DROP_BLOCKS.sub(" ", html)
    text = _BREAKS.sub("\n", text)
    text = _TAGS.sub(" ", text)
    text = html_mod.unescape(text)
    lines = [" ".join(line.split()) for line in text.splitlines()]
    return _BLANKS.sub("\n\n", "\n".join(lines)).strip()


# ── web_search ───────────────────────────────────────────
@dataclass(frozen=True, slots=True)
class SearchHit:
    title: str
    url: str
    snippet: str = ""


class SearchProvider(Protocol):
    """검색은 provider 설정이다. **기본 하나를 두되 박지 않는다.**"""

    name: str

    async def search(self, query: str, *, limit: int) -> Sequence[SearchHit]: ...


#: 검색 결과 기본 개수.
DEFAULT_SEARCH_LIMIT = 10


async def web_search(
    ctx: WebContext, provider: SearchProvider, query: str, *, limit: int = DEFAULT_SEARCH_LIMIT
) -> tuple[ToolResult, FetchTrace]:
    """검색하고 **허용되지 않는 호스트의 결과를 빼고** 돌려준다.

    `web_fetch` 와 다르게 **오류가 아니라 생략**이다 (공식 계약). 검색은
    모델이 고를 목록을 주는 것이고, 고를 수 없는 것을 목록에 넣을 이유가
    없다.
    """
    trace = FetchTrace(unrestricted=ctx.gate.unrestricted)
    if not query.strip():
        return ToolResult(content="빈 검색어다", is_error=True), trace

    try:
        with anyio.fail_after(ctx.timeout_seconds):
            hits = await provider.search(query, limit=limit)
    except TimeoutError:
        trace.reason = f"{ctx.timeout_seconds:.0f}초 안에 검색이 끝나지 않았다"
        return ToolResult(content=trace.reason, is_error=True), trace
    except Exception as exc:
        # 검색 실패도 툴 실패다.
        trace.reason = f"{type(exc).__name__}: {exc}"
        return (
            ToolResult(content=f"검색하지 못했다: {type(exc).__name__}", is_error=True),
            trace,
        )

    kept, dropped = [], 0
    for hit in hits:
        if ctx.gate.decide(hit.url).ok:
            kept.append(hit)
        else:
            dropped += 1

    trace.hops = [h.url for h in kept]
    if dropped:
        trace.reason = f"허용되지 않는 호스트의 결과 {dropped}건을 뺐다"

    if not kept:
        note = f" (허용되지 않는 결과 {dropped}건을 뺐다)" if dropped else ""
        return ToolResult(content=f"검색 결과가 없다{note}"), trace

    lines = [f"검색: {query}  ·  엔진: {provider.name}", ""]
    lines += [f"{i}. {h.title}\n   {h.url}\n   {h.snippet}" for i, h in enumerate(kept, 1)]
    if dropped:
        lines.append(f"\n(허용되지 않는 호스트의 결과 {dropped}건을 뺐다)")
    return ToolResult(content="\n".join(lines)), trace


__all__ = [
    "DEFAULT_MAX_CONTENT_CHARS",
    "DEFAULT_SEARCH_LIMIT",
    "DEFAULT_TIMEOUT_SECONDS",
    "MAX_REDIRECTS",
    "MAX_RESPONSE_BYTES",
    "USER_AGENT",
    "FetchTrace",
    "HttpClient",
    "HttpResponse",
    "SearchHit",
    "SearchProvider",
    "WebContext",
    "to_markdown",
    "web_fetch",
    "web_search",
]
