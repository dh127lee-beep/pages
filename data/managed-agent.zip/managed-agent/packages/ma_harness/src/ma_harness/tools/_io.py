"""파일 I/O — **경계를 통과한 경로만 받는다**.

`plan/07-sandbox.md` §8 · `ADR-0008`.

이 파일이 `ma_harness.tools` 안에서 **유일하게 파일을 여는 곳**이다. 그래서
`# awp-boundary-ok` 가 여기에만 있고, 각 줄에 왜 안전한지 적혀 있다.

안전한 이유는 하나다: **`Resolved` 타입만 받는다.** `Resolved` 는
`_paths.resolve()` 만 만들 수 있고, 그 함수는 `resolve_in_workspace` 를
통과한 것만 돌려준다. 즉 경계 검사를 건너뛸 방법이 타입 수준에서 없다.

> 리뷰할 때 이 파일만 보면 된다. 다른 툴 파일에 `open(` 이 생기면 CI 가 막는다.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Iterator
    from pathlib import Path

    from ma_harness.tools._paths import Resolved

#: 텍스트로 읽기 전에 보는 선두 바이트. 널바이트가 있으면 바이너리로 본다.
_SNIFF_BYTES = 8192


def read_text(target: Resolved, *, encoding: str = "utf-8") -> str:
    """경계를 통과한 경로에서 텍스트를 읽는다.

    **디코드 실패를 예외로 올리지 않는다** — `errors="replace"` 로 읽는다.
    모델에게는 깨진 글자가 보이는 편이 "읽을 수 없다"보다 낫고, 바이너리
    판정은 호출자가 `looks_binary` 로 먼저 한다.
    """
    return target.path.read_text(encoding=encoding, errors="replace")  # awp-boundary-ok: Resolved


def read_bytes(target: Resolved) -> bytes:
    return target.path.read_bytes()  # awp-boundary-ok: Resolved 만 받는다


def write_text(target: Resolved, text: str, *, encoding: str = "utf-8") -> int:
    """부모 디렉터리를 만들고 쓴다. 쓴 바이트 수를 돌려준다."""
    target.path.parent.mkdir(parents=True, exist_ok=True)  # awp-boundary-ok: Resolved
    return target.path.write_text(text, encoding=encoding)  # awp-boundary-ok: Resolved


def exists(target: Resolved) -> bool:
    return target.path.exists()  # awp-boundary-ok: Resolved 만 받는다


def is_file(target: Resolved) -> bool:
    return target.path.is_file()  # awp-boundary-ok: Resolved 만 받는다


def size_of(target: Resolved) -> int:
    return target.path.stat().st_size  # awp-boundary-ok: Resolved 만 받는다


def mtime_of(target: Resolved) -> float:
    return target.path.stat().st_mtime  # awp-boundary-ok: Resolved 만 받는다


def looks_binary(target: Resolved) -> bool:
    """선두에 널바이트가 있으면 바이너리. **완벽하지 않지만 충분하다.**

    정확한 판정(libmagic)은 의존성을 늘리고, 우리가 필요한 것은 "텍스트로
    읽으면 모델에게 쓰레기가 가는가"뿐이다.
    """
    with target.path.open("rb") as fh:  # awp-boundary-ok: Resolved 만 받는다
        return b"\x00" in fh.read(_SNIFF_BYTES)


def walk_files(root: Resolved) -> Iterator[Path]:
    """루트 아래의 파일을 흘린다. **심링크를 따라가지 않는다.**

    따라가면 워크스페이스 안의 심링크로 밖의 디렉터리를 열거할 수 있다 —
    `resolve_in_workspace` 는 **주어진 경로**를 검사하지 비구조적 순회를
    막지는 않는다. 그래서 순회 자체가 심링크를 피한다.
    """
    stack = [root.path]
    while stack:
        current = stack.pop()
        try:
            entries = list(current.iterdir())  # awp-boundary-ok: Resolved 하위
        except (OSError, PermissionError):
            continue
        for entry in entries:
            if entry.is_symlink():
                # **따라가지 않는다.** 모델이 그 경로를 직접 주면 그때
                # `resolve_in_workspace` 가 판정한다.
                continue
            if entry.is_dir():
                stack.append(entry)
            elif entry.is_file():
                yield entry


__all__ = [
    "exists",
    "is_file",
    "looks_binary",
    "mtime_of",
    "read_bytes",
    "read_text",
    "size_of",
    "walk_files",
    "write_text",
]
