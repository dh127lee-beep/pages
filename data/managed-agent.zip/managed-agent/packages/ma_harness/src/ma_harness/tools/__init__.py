"""호스트 툴 — **경로는 `resolve_in_workspace` 로만 연다** (T-0302에서 채운다).

`plan/06-harness-and-model.md` §4.4 · `plan/07-sandbox.md` §8.

`tools/check_architecture.py` 의 "워크스페이스 경계 단일 진입점" 검사가
이 패키지 안의 `open(`·`Path(`·`os.walk(` 같은 직접 접근을 금지한다.
불가피한 경우 `# awp-boundary-ok` 와 **이유**를 같은 줄에 적는다.
"""
