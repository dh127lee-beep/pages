"""AWP · OpenAI 호환 엔드포인트 어댑터"""
