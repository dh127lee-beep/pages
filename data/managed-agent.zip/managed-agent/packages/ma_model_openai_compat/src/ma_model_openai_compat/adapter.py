"""OpenAI 호환 어댑터 — 사내 게이트웨이 · vLLM · DeepSeek 공식.

`plan/06-harness-and-model.md` §1 · `ADR-0005` · `IMPL-0009`.

**이 파일에 모델 문자열이 없다.** `card.wire_model`을 그대로 보낸다. 모델을
바꾸는 것은 `model_cards` 행을 고치는 일이고 코드 변경이 0이다 (D12).

추론 파라미터도 마찬가지다. 하네스는 `EffortIntent.HIGH`라는 **의도**만 갖고,
그것을 `reasoning_effort: "high"`로 쓸지 `thinking: {"type": "enabled"}`로 쓸지는
카드의 `ReasoningSpec`이 정한다.
"""

from __future__ import annotations

from collections.abc import AsyncIterator, Mapping, Sequence
from typing import TYPE_CHECKING, Any

from ma_domain.models import EffortIntent, ModelCapabilities, ModelCard, ReasoningSpec
from ma_harness.model_port import (
    FinishReason,
    ModelError,
    ModelStreamEvent,
    StreamEventKind,
    ToolSchema,
    WireMessage,
)

from ma_model_openai_compat.normalize import StreamNormalizer, parse_sse_line

if TYPE_CHECKING:
    import anyio
    import httpx

#: 재시도해도 되는 HTTP 상태. 분류 근거는 `IMPL-0009`.
RETRYABLE_STATUS = frozenset({408, 409, 425, 429, 500, 502, 503, 504})

_STATUS_KIND: Mapping[int, str] = {
    400: "bad_request",
    401: "auth",
    403: "auth",
    404: "not_found",
    408: "timeout",
    413: "too_large",
    422: "bad_request",
    429: "rate_limit",
    500: "server_error",
    502: "overloaded",
    503: "overloaded",
    504: "timeout",
}


def reasoning_param(spec: ReasoningSpec, effort: EffortIntent) -> tuple[str, object]:
    """의도 → wire 파라미터. **번역이 카드에 있다는 것이 D12의 요점이다.**

    `style="enum"`이면 값 자체를 보내고(`reasoning_effort: "high"`),
    `style="object"`면 객체로 감싼다(`thinking: {"type": "enabled", "effort": "high"}`).
    """
    wire = dict(spec.mapping).get(effort, effort.value)
    if wire not in spec.levels:
        # 카드가 이 깊이를 지원하지 않는다 — 가장 가까운 아래 단계로 내린다.
        # 올리면 비용이 의도보다 커지므로, 모르면 내린다.
        order = [e.value for e in EffortIntent]
        want = order.index(effort.value)
        candidates = [lv for lv in spec.levels if lv in order and order.index(lv) <= want]
        wire = candidates[-1] if candidates else spec.levels[0]

    if spec.style == "object":
        return spec.param, {"type": "enabled", "effort": wire}
    return spec.param, wire


def build_request(
    card: ModelCard,
    *,
    messages: Sequence[WireMessage],
    tools: Sequence[ToolSchema] = (),
    effort: EffortIntent | None = None,
    max_tokens: int | None = None,
) -> dict[str, Any]:
    """중립 요청 → OpenAI 포맷 본문.

    **항상 `stream: true`다.** 최대 출력이 384K 라 비스트리밍은 HTTP 타임아웃에
    걸린다 (`plan/06` §2). `stream_options.include_usage`를 켜야 usage 가
    스트림 끝에 온다 — 끄면 비용을 셀 수 없다.
    """
    body: dict[str, Any] = {
        "model": card.wire_model,
        "messages": [_message_out(m) for m in messages],
        "stream": True,
        "stream_options": {"include_usage": True},
    }

    for key, default_value in card.defaults:
        body[key] = default_value

    limit = max_tokens if max_tokens is not None else body.get("max_tokens")
    if limit is not None:
        body["max_tokens"] = min(int(limit), card.max_output_tokens)

    if tools:
        if not card.supports_tools:
            raise ValueError(f"카드 {card.id}는 툴을 지원하지 않는다고 선언했다")
        # **바이트 단위로 안정적이어야 한다** (T-0305 DoD).
        #
        # 툴 블록은 프롬프트 접두사의 일부다. 순서가 호출마다 흔들리면
        # 캐시가 전부 미스되고, DeepSeek 기준 입력 비용이 **50배**가 된다
        # (`plan/06` §5 — 캐시 히트 $0.006 vs 미스 $0.3 / 1M).
        #
        # 두 축을 다 고정한다: 툴은 이름순, JSON Schema 는 키순.
        body["tools"] = [
            {
                "type": "function",
                "function": {
                    "name": t.name,
                    "description": t.description,
                    "parameters": _canonical(dict(t.parameters)),
                },
            }
            for t in sorted(tools, key=lambda t: t.name)
        ]

    if effort is not None and card.reasoning is not None:
        param, wire_value = reasoning_param(card.reasoning, effort)
        body[param] = wire_value

    return body


def _canonical(value: Any) -> Any:
    """중첩 dict 의 키를 재귀적으로 정렬한다.

    JSON 객체의 키 순서는 의미가 없으므로 정렬해도 스키마가 바뀌지 않는다.
    바뀌는 것은 **직렬화 바이트**이고, 그것이 캐시 접두사를 정한다.

    리스트의 순서는 **건드리지 않는다** — JSON 배열의 순서는 의미가 있다
    (`enum` 값 순서, `required` 목록 등을 재배열하면 스키마가 달라진다).
    """
    if isinstance(value, dict):
        return {k: _canonical(value[k]) for k in sorted(value)}
    if isinstance(value, list):
        return [_canonical(v) for v in value]
    return value


def _message_out(m: WireMessage) -> dict[str, Any]:
    out: dict[str, Any] = {"role": m.role}
    if m.content or not m.tool_calls:
        out["content"] = m.content
    if m.tool_calls:
        out["tool_calls"] = [
            {
                "id": c.id,
                "type": "function",
                "function": {"name": c.name, "arguments": c.arguments},
            }
            for c in m.tool_calls
        ]
    if m.tool_call_id:
        out["tool_call_id"] = m.tool_call_id
    return out


def classify_status(status: int, message: str = "") -> ModelError:
    """HTTP 상태 → 중립 에러. 하네스는 "다시 걸어도 되는가"만 알면 된다."""
    return ModelError(
        kind=_STATUS_KIND.get(status, "unknown"),
        message=message or f"HTTP {status}",
        retryable=status in RETRYABLE_STATUS,
        status=status,
    )


class OpenAICompatibleAdapter:
    """`ModelPort` 구현. `base_url`과 자격증명은 **밖에서 주입된다**.

    자격증명이 생성자로 들어오는 것은 **M1 한정**이다. T-0402 에서 egress-proxy가
    주입하게 바뀐다 — 그때 워커는 키를 아예 보지 않는다 (D5).
    """

    #: 이 어댑터가 담당하는 provider 종류. 카드가 이것과 다르면 조립이 거부된다.
    name = "openai_compatible"

    def __init__(
        self,
        client: httpx.AsyncClient,
        *,
        # `None` 이 **기본이자 운영 경로**다 — egress 프록시가 주입한다
        # (`plan/07` §6.3). 값을 주는 것은 개발 전용이고, 프로덕션에서는
        # 워커 설정이 그것을 거부한다 (`runtime_worker.config`).
        api_key: str | None = None,
        default_base_url: str | None = None,
        path: str = "/v1/chat/completions",
    ) -> None:
        self._client = client
        self._api_key = api_key
        self._default_base_url = default_base_url
        self._path = path

    def describe(self, card: ModelCard) -> ModelCapabilities:
        """카드 선언을 사실로 좁힌다. 어긋나면 `caveats`에 적는다."""
        caveats: list[str] = []
        if card.base_url is None and self._default_base_url is None:
            caveats.append("base_url 이 카드에도 어댑터에도 없다")
        if card.supports_vision:
            caveats.append("비전은 이 어댑터에서 아직 검증되지 않았다")
        return ModelCapabilities(
            max_input_tokens=card.max_input_tokens,
            max_output_tokens=card.max_output_tokens,
            supports_tools=card.supports_tools,
            supports_vision=False,  # 카드가 뭐라 하든 아직 사실이 아니다
            supports_prompt_cache=card.supports_prompt_cache,
            reasoning=card.reasoning,
            caveats=tuple(caveats),
        )

    async def stream(
        self,
        card: ModelCard,
        *,
        messages: Sequence[WireMessage],
        tools: Sequence[ToolSchema] = (),
        effort: EffortIntent | None = None,
        max_tokens: int | None = None,
        signal: anyio.Event | None = None,
    ) -> AsyncIterator[ModelStreamEvent]:
        body = build_request(
            card, messages=messages, tools=tools, effort=effort, max_tokens=max_tokens
        )
        base = card.base_url or self._default_base_url
        if base is None:
            raise ValueError(f"카드 {card.id}에 base_url 이 없다")

        headers = {"Accept": "text/event-stream"}
        if self._api_key:
            headers["Authorization"] = f"Bearer {self._api_key}"

        norm = StreamNormalizer()
        async with self._client.stream(
            "POST", f"{base.rstrip('/')}{self._path}", json=body, headers=headers
        ) as response:
            if response.status_code >= 400:
                text = (await response.aread()).decode("utf-8", "replace")[:500]
                yield ModelStreamEvent(
                    kind=StreamEventKind.ERROR,
                    error=classify_status(response.status_code, text),
                )
                yield ModelStreamEvent(
                    kind=StreamEventKind.FINISH, finish_reason=FinishReason.ERROR
                )
                return

            async for line in response.aiter_lines():
                if signal is not None and signal.is_set():
                    # 인터럽트가 모델 호출 중에 도착하는 것은 **정상**이다.
                    yield ModelStreamEvent(
                        kind=StreamEventKind.FINISH,
                        finish_reason=FinishReason.CANCELLED,
                    )
                    return
                chunk = parse_sse_line(line)
                if chunk is None:
                    continue
                for ev in norm.feed(chunk):
                    yield ev

        for ev in norm.finalize():
            yield ev


__all__ = [
    "RETRYABLE_STATUS",
    "OpenAICompatibleAdapter",
    "build_request",
    "classify_status",
    "reasoning_param",
]
