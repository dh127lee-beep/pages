"""OpenAI 포맷 SSE → 중립 `ModelStreamEvent`.

`plan/06-harness-and-model.md` §1 · `ADR-0005`.

DeepSeek 공식 엔드포인트도 **OpenAI 포맷**이므로 정규화 로직은 하나면 된다.
DeepSeek 확장(`reasoning_content`)은 여기서 같이 다룬다 — OpenAI 가 안 보내면
그 키가 없을 뿐이다.

정규화가 책임지는 것은 셋이다.

1. **툴 호출 조립.** OpenAI 는 툴 호출을 `index`로 묶인 조각으로 흘린다. 첫 조각에만
   `id`와 `name`이 있고 나머지는 `arguments` 문자열의 일부다. 중립 어휘는
   `start → delta* → end`라 그 경계를 **여기서** 만들어야 한다.
2. **usage 분리.** 캐시 히트/미스를 나눠 싣는다. 합치면 `plan/06` §5 의 가장 큰
   비용 지렛대를 측정할 수 없다.
3. **finish 정규화.** `"length"` → `MAX_TOKENS` 같은 이름 차이를 흡수한다.

이 모듈은 **순수**하다 — HTTP 를 모르고, 파싱된 chunk dict 만 받는다. 그래서
네트워크 없이 녹음 픽스처로 계약을 검증할 수 있다.
"""

from __future__ import annotations

import json
from collections.abc import Iterator, Mapping
from dataclasses import dataclass, field

from ma_domain.models import TokenUsage
from ma_harness.model_port import (
    FinishReason,
    ModelError,
    ModelStreamEvent,
    StreamEventKind,
)

_FINISH: Mapping[str, FinishReason] = {
    "stop": FinishReason.STOP,
    "tool_calls": FinishReason.TOOL_CALLS,
    "function_call": FinishReason.TOOL_CALLS,  # 구형 이름
    "length": FinishReason.MAX_TOKENS,
    "max_tokens": FinishReason.MAX_TOKENS,
    "content_filter": FinishReason.CONTENT_FILTER,
}


@dataclass
class _PartialToolCall:
    id: str
    name: str
    started: bool = False


@dataclass
class StreamNormalizer:
    """상태를 들고 chunk 를 중립 이벤트로 바꾼다.

    상태가 필요한 이유는 툴 호출 하나가 **여러 chunk 에 걸쳐** 오기 때문이다.
    인스턴스 하나가 스트림 하나를 담당한다 — 재사용하지 않는다.
    """

    _calls: dict[int, _PartialToolCall] = field(default_factory=dict)
    _finished: bool = False
    _saw_usage: bool = False

    def feed(self, chunk: Mapping[str, object]) -> Iterator[ModelStreamEvent]:
        """chunk 하나 → 중립 이벤트 0개 이상."""
        if "error" in chunk:
            yield ModelStreamEvent(kind=StreamEventKind.ERROR, error=_error_from(chunk["error"]))
            return

        usage = chunk.get("usage")
        if isinstance(usage, Mapping):
            self._saw_usage = True
            yield ModelStreamEvent(kind=StreamEventKind.USAGE, usage=usage_from(usage))

        choices = chunk.get("choices")
        if not isinstance(choices, list) or not choices:
            return
        choice = choices[0]
        if not isinstance(choice, Mapping):  # pragma: no cover — 방어
            return

        delta = choice.get("delta")
        if isinstance(delta, Mapping):
            yield from self._feed_delta(delta)

        finish = choice.get("finish_reason")
        if isinstance(finish, str):
            yield from self._close_calls()
            self._finished = True
            yield ModelStreamEvent(
                kind=StreamEventKind.FINISH,
                finish_reason=_FINISH.get(finish, FinishReason.STOP),
            )

    def _feed_delta(self, delta: Mapping[str, object]) -> Iterator[ModelStreamEvent]:
        # DeepSeek 확장. OpenAI 는 이 키를 보내지 않는다.
        thinking = delta.get("reasoning_content")
        if isinstance(thinking, str) and thinking:
            yield ModelStreamEvent(kind=StreamEventKind.THINKING_DELTA, text=thinking)

        content = delta.get("content")
        if isinstance(content, str) and content:
            yield ModelStreamEvent(kind=StreamEventKind.TEXT_DELTA, text=content)

        calls = delta.get("tool_calls")
        if isinstance(calls, list):
            for raw in calls:
                if isinstance(raw, Mapping):
                    yield from self._feed_tool_call(raw)

    def _feed_tool_call(self, raw: Mapping[str, object]) -> Iterator[ModelStreamEvent]:
        """`index`가 호출을 식별한다. 첫 조각에만 `id`·`name`이 있다."""
        index = raw.get("index")
        idx = int(index) if isinstance(index, int) else 0
        fn = raw.get("function")
        fn_map: Mapping[str, object] = fn if isinstance(fn, Mapping) else {}

        call = self._calls.get(idx)
        if call is None:
            call = _PartialToolCall(
                id=str(raw.get("id") or f"call_{idx}"),
                name=str(fn_map.get("name") or ""),
            )
            self._calls[idx] = call
        else:
            # 드물게 이름이 나중 조각에 온다
            if not call.name and fn_map.get("name"):
                call.name = str(fn_map["name"])
            if raw.get("id"):
                call.id = str(raw["id"])

        if not call.started and call.name:
            call.started = True
            yield ModelStreamEvent(
                kind=StreamEventKind.TOOL_CALL_START,
                tool_call_id=call.id,
                tool_name=call.name,
            )

        args = fn_map.get("arguments")
        if isinstance(args, str) and args:
            yield ModelStreamEvent(
                kind=StreamEventKind.TOOL_CALL_DELTA,
                tool_call_id=call.id,
                tool_name=call.name,
                arguments_delta=args,
            )

    def _close_calls(self) -> Iterator[ModelStreamEvent]:
        """`finish_reason`이 오면 열린 호출을 전부 닫는다.

        OpenAI 는 툴 호출의 끝을 **따로 알려주지 않는다.** 중립 어휘에
        `tool_call_end`가 있는 이유는 하네스가 "인자가 다 모였다"를 알아야
        하기 때문이고, 그 경계를 만드는 것이 여기다.
        """
        for call in self._calls.values():
            if call.started:
                yield ModelStreamEvent(
                    kind=StreamEventKind.TOOL_CALL_END,
                    tool_call_id=call.id,
                    tool_name=call.name,
                )
        self._calls.clear()

    def finalize(self) -> Iterator[ModelStreamEvent]:
        """스트림이 `finish_reason` 없이 끝났을 때 뒷정리.

        연결이 끊기거나 `[DONE]`만 오고 끝나는 경우가 실제로 있다. 그때도
        하네스는 **반드시 FINISH 를 하나 받아야** 루프를 닫을 수 있다.
        """
        if self._finished:
            return
        yield from self._close_calls()
        self._finished = True
        yield ModelStreamEvent(kind=StreamEventKind.FINISH, finish_reason=FinishReason.STOP)

    @property
    def saw_usage(self) -> bool:
        return self._saw_usage


def usage_from(raw: Mapping[str, object]) -> TokenUsage:
    """**캐시 히트/미스를 반드시 분리한다.** 비용 계산과 캐시 알람의 원천이다.

    OpenAI 포맷의 `prompt_tokens`는 히트와 미스의 **합**이고, 세부는
    `prompt_tokens_details.cached_tokens`(OpenAI) 또는
    `prompt_cache_hit_tokens`/`prompt_cache_miss_tokens`(DeepSeek)에 있다.
    둘 다 없으면 전부 미스로 센다 — **비용을 적게 잡는 것보다 많이 잡는 편이
    안전하다.** 예산이 조용히 새는 것보다 일찍 멈추는 편이 낫다.
    """

    def n(key: str) -> int:
        v = raw.get(key)
        return int(v) if isinstance(v, int | float) else 0

    hit = n("prompt_cache_hit_tokens")
    miss = n("prompt_cache_miss_tokens")

    if not hit and not miss:
        details = raw.get("prompt_tokens_details")
        if isinstance(details, Mapping):
            cached = details.get("cached_tokens")
            hit = int(cached) if isinstance(cached, int | float) else 0
        total = n("prompt_tokens")
        miss = max(total - hit, 0)

    return TokenUsage(
        input_cache_hit=hit,
        input_cache_miss=miss,
        output=n("completion_tokens"),
    )


def _error_from(raw: object) -> ModelError:
    body: Mapping[str, object] = raw if isinstance(raw, Mapping) else {}
    message = str(body.get("message") or raw)
    kind = str(body.get("type") or body.get("code") or "unknown")
    return ModelError(kind=kind, message=message, retryable=False)


def parse_sse_line(line: str) -> Mapping[str, object] | None:
    """`data: {...}` 한 줄 → dict. `[DONE]`과 빈 줄은 None.

    주석 줄(`:`로 시작)도 None 이다 — 일부 게이트웨이가 하트비트로 보낸다.
    """
    line = line.strip()
    if not line or line.startswith(":"):
        return None
    if line.startswith("data:"):
        line = line[5:].strip()
    if not line or line == "[DONE]":
        return None
    parsed = json.loads(line)
    return parsed if isinstance(parsed, dict) else None


__all__ = ["StreamNormalizer", "parse_sse_line", "usage_from"]
