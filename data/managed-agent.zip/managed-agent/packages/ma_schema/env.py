"""Alembic 환경.

DSN은 `AWP_DATABASE_URL`에서 읽는다. 마이그레이션은 **앱 기동 시 자동 실행하지 않고**
별도 Job으로 돌린다 (`docs/conventions/sql.md`) — 여러 Pod가 동시에 하면 깨진다.
`pg_advisory_lock`으로 이중 안전을 건다.
"""

from __future__ import annotations

import os

from alembic import context
from sqlalchemy import create_engine, pool, text

#: 마이그레이션 단일 실행을 보장하는 자문 잠금 키 (임의 상수)
ADVISORY_LOCK_KEY = 0x41575001  # "AWP\x01"


def _dsn() -> str:
    dsn = os.environ.get("AWP_DATABASE_URL")  # awp-env-ok — 마이그레이션 진입점
    if not dsn:
        raise SystemExit("AWP_DATABASE_URL 이 필요하다")
    return dsn.replace("postgresql+asyncpg://", "postgresql://")


def run_migrations_online() -> None:
    engine = create_engine(_dsn(), poolclass=pool.NullPool, future=True)
    with engine.connect() as conn:
        conn.execute(text("SELECT pg_advisory_lock(:k)"), {"k": ADVISORY_LOCK_KEY})
        try:
            context.configure(connection=conn, target_metadata=None)
            with context.begin_transaction():
                context.run_migrations()
        finally:
            conn.execute(text("SELECT pg_advisory_unlock(:k)"), {"k": ADVISORY_LOCK_KEY})
            conn.commit()


def run_migrations_offline() -> None:
    context.configure(url=_dsn(), literal_binds=True)
    with context.begin_transaction():
        context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
