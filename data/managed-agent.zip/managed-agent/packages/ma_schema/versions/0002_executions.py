"""0002 · 워크스페이스 범위 claim 인덱스 보강

`plan/05-database.md` §3 G5 · `task/M1-runtime-core/T-0201-execution-authority.md`.

0001이 만든 `idx_exec_claimable (created_at) WHERE state='queued'`는 전역 워커
(`ClaimExecution.workspace_id` 없이 도는 워커)에는 충분하다. 하지만 두 경로가
워크스페이스로 좁혀 읽는다:

- 워크스페이스 전용 워커의 `claim` — `WHERE state='queued' AND workspace_id=? ORDER BY created_at`
- KEDA 스케일 신호인 `queued_count(workspace_id)`

둘 다 기존 인덱스로는 **그 워크스페이스에 해당하지 않는 queued까지 훑는다**. 한
부서의 큐가 밀리면 다른 부서의 claim이 같이 느려진다 — 격리가 깨지는 지점이고,
부서별 런타임 네임스페이스를 나눈 이유(`plan/08-infra.md`)와 정면으로 어긋난다.

선행 열을 `workspace_id`로 둔 부분 인덱스 하나로 두 경로를 모두 덮는다.

Revision ID: 0002
Revises: 0001
Create Date: 2026-10-15
"""

from __future__ import annotations

from alembic import op

revision = "0002"
down_revision = "0001"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute("""
        CREATE INDEX idx_exec_claimable_ws
        ON session_executions (workspace_id, created_at)
        WHERE state = 'queued'
    """)


def downgrade() -> None:
    """작성은 하되 프로덕션에서 실행하지 않는다 (`docs/conventions/sql.md`)."""
    op.execute("DROP INDEX IF EXISTS idx_exec_claimable_ws")
