"""0017 · environment_work — G3 (T-0606)

`plan/04-api.md` §3.3 · `plan/05-database.md` §3 G3 · §7 ·
`ref/claude-managed-agents/08-self-hosted/`.

> **왜 `session_executions` 를 재사용하지 않는가.**
>
> 둘 다 "일을 집는다"지만 신뢰 경계가 다르다. `session_executions` 는
> **우리 워커**가 DB 에서 `FOR UPDATE SKIP LOCKED` 로 집는다 (D3).
> `environment_work` 는 **부서의 워커**가 HTTP 로 집는다 — DB 에
> 닿지 않고, 닿아서도 안 된다. 그 워커는 사내 다른 네트워크에 있다.
>
> 한 테이블에 두 경계를 넣으면, 외부 워커에게 열어 줘야 하는 컬럼이
> 우리 워커의 lease 와 같은 행에 있게 된다.

claim generation 이 핵심이다. 워커가 죽은 줄 알고 회수했는데 그
워커가 **살아 돌아오는** 경우가 있다 (네트워크 분단). generation 이
올라가 있으면 옛 워커의 ack 가 거부된다 — `session_executions` 의
fence 와 같은 장치다 (D3).

Revision ID: 0017
Revises: 0016
Create Date: 2026-10-16
"""

from __future__ import annotations

from alembic import op

revision = "0017"
down_revision = "0016"
branch_labels = None
depends_on = None

APP_ROLE = "awp_app"
WORKER_ROLE = "awp_worker"
SETTING = "awp.workspace_id"

TABLES = ("environment_work",)


def upgrade() -> None:
    op.execute("""
        CREATE TABLE environment_work (
          id             TEXT NOT NULL,
          workspace_id   TEXT NOT NULL REFERENCES workspaces(id),
          environment_id TEXT NOT NULL,
          -- **핀한 버전.** 환경이 바뀌어도 집힌 일은 집힐 때의
          -- 경계로 돈다 (세션이 버전을 핀하는 것과 같은 이유).
          environment_version INT NOT NULL,
          session_id     TEXT NOT NULL,
          state          TEXT NOT NULL DEFAULT 'queued'
            CHECK (state IN ('queued','claimed','done','failed','expired')),
          -- **claim 할 때마다 올라간다.** 죽은 줄 알고 회수했는데 그
          -- 워커가 살아 돌아오면(네트워크 분단) 옛 generation 의 ack 를
          -- 거부한다 — `session_executions` 의 fence 와 같은 장치다.
          claim_generation INT NOT NULL DEFAULT 0 CHECK (claim_generation >= 0),
          worker_id      TEXT,
          -- **1회용 워커 시크릿.** 평문은 claim 응답에만 한 번 실린다
          -- (`credentials` 와 같은 규칙 — `plan/05` §7).
          secret_ciphertext BYTEA,
          secret_nonce      BYTEA,
          secret_key_version INT NOT NULL DEFAULT 1,
          attempts       INT NOT NULL DEFAULT 0 CHECK (attempts >= 0),
          claimed_at     TIMESTAMPTZ,
          -- 하트비트가 끊기면 회수한다. **TTL 은 질의가 정한다** —
          -- 컬럼에 두면 워커가 자기 TTL 을 늘릴 수 있다.
          heartbeat_at   TIMESTAMPTZ,
          acked_at       TIMESTAMPTZ,
          error          TEXT NOT NULL DEFAULT '',
          created_at     TIMESTAMPTZ NOT NULL,
          updated_at     TIMESTAMPTZ NOT NULL,
          PRIMARY KEY (workspace_id, id),
          -- 집힌 일에는 워커와 시각이 **반드시** 있다. 없으면 회수
          -- 질의가 그 행을 영원히 못 본다.
          CONSTRAINT work_claimed_has_worker
            CHECK (state <> 'claimed' OR (worker_id IS NOT NULL AND claimed_at IS NOT NULL)),
          -- 끝난 일에는 시각이 있다.
          CONSTRAINT work_final_has_acked
            CHECK (state NOT IN ('done','failed') OR acked_at IS NOT NULL)
        )
    """)
    # **집을 것을 찾는 핫 경로.** 부분 인덱스 — 끝난 일이 쌓여도
    # 폴링 비용이 늘지 않는다.
    op.execute("""
        CREATE INDEX idx_work_queued
        ON environment_work (environment_id, created_at, id)
        WHERE state = 'queued'
    """)
    # 회수 질의. 하트비트가 오래된 것부터 본다.
    op.execute("""
        CREATE INDEX idx_work_stale
        ON environment_work (heartbeat_at)
        WHERE state = 'claimed'
    """)
    # **세션 하나에 큐된 일은 하나다.** 두 개면 같은 세션의 턴이
    # 두 워커에서 동시에 돈다.
    op.execute("""
        CREATE UNIQUE INDEX idx_work_session_open
        ON environment_work (workspace_id, session_id)
        WHERE state IN ('queued','claimed')
    """)

    _apply_security()


def _apply_security() -> None:
    for table in TABLES:
        op.execute(f"""
            DO $$
            BEGIN
              EXECUTE 'ALTER TABLE {table} ENABLE ROW LEVEL SECURITY';
              EXECUTE 'DROP POLICY IF EXISTS {table}_ws ON {table}';
              EXECUTE 'CREATE POLICY {table}_ws ON {table} '
                      'USING (workspace_id = current_setting(''{SETTING}'', true))';
            EXCEPTION WHEN insufficient_privilege THEN
              RAISE WARNING '{table} 에 RLS 를 걸지 못했다';
            END $$
        """)
    op.execute(f"""
        DO $$
        BEGIN
          GRANT SELECT, INSERT, UPDATE, DELETE ON environment_work TO {APP_ROLE};
          -- **우리 워커는 이 테이블을 안 본다.** 여기 있는 일은
          -- 부서의 워커가 HTTP 로 집는 것이고, 우리 워커가 집으면
          -- self_hosted 의 의미가 사라진다 (데이터가 경계를 넘는다).
        EXCEPTION
          WHEN undefined_object OR insufficient_privilege THEN
            RAISE WARNING 'environment_work 권한을 걸지 못했다';
        END $$
    """)


def downgrade() -> None:
    op.execute("DROP TABLE IF EXISTS environment_work")
