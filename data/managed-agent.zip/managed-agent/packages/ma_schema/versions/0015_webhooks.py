"""0015 · webhook_endpoints · webhook_deliveries — G9 (T-0604)

`plan/05-database.md` §3 G9 · `plan/04-api.md` §3.8.

> **DLQ 를 지우지 않는다.** 포기한 전송은 `state='dead'` 로 남고,
> 사람이 보고 다시 쏠 수 있어야 한다. 지우면 "웹훅이 안 왔다"는
> 문의에 답할 자료가 없다.

**시크릿은 암호화해 둔다.** 평문으로 두면 DB 를 읽는 모든 경로가
서명을 위조할 수 있다 — `credentials` 와 같은 cipher 를 쓴다 (D5).

Revision ID: 0015
Revises: 0014
Create Date: 2026-10-16
"""

from __future__ import annotations

from alembic import op

revision = "0015"
down_revision = "0014"
branch_labels = None
depends_on = None

APP_ROLE = "awp_app"
WORKER_ROLE = "awp_worker"
SETTING = "awp.workspace_id"

TABLES = ("webhook_endpoints", "webhook_deliveries")


def upgrade() -> None:
    op.execute("""
        CREATE TABLE webhook_endpoints (
          id            TEXT NOT NULL,
          workspace_id  TEXT NOT NULL REFERENCES workspaces(id),
          url           TEXT NOT NULL,
          -- 구독 이벤트. 빈 배열이면 **전부**.
          events        TEXT[] NOT NULL DEFAULT '{}',
          description   TEXT NOT NULL DEFAULT '',
          -- 시크릿은 **암호화해 둔다** (`credentials` 와 같은 cipher).
          secret_ciphertext BYTEA NOT NULL,
          secret_nonce      BYTEA NOT NULL,
          key_version       INT NOT NULL DEFAULT 1,
          created_by    TEXT NOT NULL,
          created_at    TIMESTAMPTZ NOT NULL,
          disabled_at   TIMESTAMPTZ,
          PRIMARY KEY (workspace_id, id),
          -- **http 를 받지 않는다.** 서명이 있어도 본문이 평문으로
          -- 나가고, 거기에 세션 id 와 에이전트 이름이 들어 있다.
          CONSTRAINT webhook_endpoints_https CHECK (url LIKE 'https://%')
        )
    """)
    op.execute("""
        CREATE INDEX idx_webhook_endpoints_active
        ON webhook_endpoints (workspace_id) WHERE disabled_at IS NULL
    """)

    op.execute("""
        CREATE TABLE webhook_deliveries (
          id            TEXT NOT NULL,
          workspace_id  TEXT NOT NULL,
          endpoint_id   TEXT NOT NULL,
          event         TEXT NOT NULL,
          payload       JSONB NOT NULL,
          state         TEXT NOT NULL
            CHECK (state IN ('pending','delivered','retrying','dead')),
          attempts      INT NOT NULL DEFAULT 0 CHECK (attempts >= 0),
          next_attempt_at TIMESTAMPTZ,
          delivered_at    TIMESTAMPTZ,
          last_error      TEXT NOT NULL DEFAULT '',
          last_status     INT,
          created_at    TIMESTAMPTZ NOT NULL,
          PRIMARY KEY (workspace_id, id),
          FOREIGN KEY (workspace_id, endpoint_id)
            REFERENCES webhook_endpoints (workspace_id, id),
          -- 끝난 전송에는 다음 시도가 없다. 남아 있으면 **영원히
          -- 다시 보낸다.**
          CONSTRAINT webhook_deliveries_settled
            CHECK (state NOT IN ('delivered','dead') OR next_attempt_at IS NULL)
        )
    """)
    # 보낼 것을 집는 핫 경로. **부분 인덱스** — 끝난 전송이 쌓여도
    # 스캔 비용이 늘지 않는다 (`session_executions` 와 같은 이유).
    op.execute("""
        CREATE INDEX idx_webhook_due ON webhook_deliveries (next_attempt_at)
        WHERE state IN ('pending','retrying')
    """)
    # DLQ 조회.
    op.execute("""
        CREATE INDEX idx_webhook_dead
        ON webhook_deliveries (workspace_id, created_at DESC)
        WHERE state = 'dead'
    """)

    _apply_security()


def _apply_security() -> None:
    tables = ", ".join(TABLES)
    for table in TABLES:
        op.execute(f"""
            DO $$
            BEGIN
              EXECUTE 'ALTER TABLE {table} ENABLE ROW LEVEL SECURITY';
              EXECUTE 'DROP POLICY IF EXISTS {table}_ws ON {table}';
              EXECUTE 'CREATE POLICY {table}_ws ON {table} '
                      'USING (workspace_id = current_setting(''{SETTING}'', true))';
            EXCEPTION WHEN insufficient_privilege THEN
              RAISE WARNING '{table} 에 RLS 를 걸지 못했다';
            END $$
        """)
    op.execute(f"""
        DO $$
        BEGIN
          GRANT SELECT, INSERT, UPDATE, DELETE ON {tables} TO {APP_ROLE};
          -- **워커는 전송을 만들기만 한다** (세션 상태가 바뀌면).
          -- 보내는 것은 스케줄러이고, 엔드포인트 시크릿은 워커가
          -- 볼 이유가 없다 (D5).
          GRANT SELECT, INSERT ON webhook_deliveries TO {WORKER_ROLE};
        EXCEPTION
          WHEN undefined_object OR insufficient_privilege THEN
            RAISE WARNING '웹훅 테이블 권한을 걸지 못했다';
        END $$
    """)


def downgrade() -> None:
    op.execute("DROP TABLE IF EXISTS webhook_deliveries")
    op.execute("DROP TABLE IF EXISTS webhook_endpoints")
