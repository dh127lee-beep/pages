"""0006 · audit_log — **append-only 를 DB 가 강제한다** (S7)

`plan/05-database.md` §3 G10 · §6 · `task/M3-security-governance/T-0404-audit-log.md`.

> **DB 가 보장하면 코드 리뷰가 필요 없다.**

`REVOKE UPDATE, DELETE, TRUNCATE` 가 이 마이그레이션의 요점이다. 애플리케이션
코드가 아무리 바뀌어도 감사 기록을 고칠 수 없다 — 고치려면 마이그레이션을
하나 더 만들어야 하고, 그 행위가 리뷰에 걸린다.

## 파티션

월 단위 `RANGE (created_at)`. 보존 3년이고 **부서가 줄일 수 없다** —
다른 보존 정책과 다르다 (`plan/05` §6).

파티션을 미리 만드는 것은 스케줄러의 일이다 (`tools/ensure_partitions.py`).
여기서는 **이번 달과 다음 달**만 만든다 — 마이그레이션 시점에 3년치를
만들면 쓰지 않을 테이블 36개가 생긴다.

Revision ID: 0006
Revises: 0005
Create Date: 2026-10-15
"""

from __future__ import annotations

from datetime import UTC, datetime

from alembic import op

revision = "0006"
down_revision = "0005"
branch_labels = None
depends_on = None

APP_ROLE = "awp_app"
WORKER_ROLE = "awp_worker"


def upgrade() -> None:
    op.execute("""
        CREATE TABLE audit_log (
          id            BIGSERIAL,
          workspace_id  TEXT NOT NULL,
          actor_type    TEXT NOT NULL
              CHECK (actor_type IN ('user','api_key','system','agent')),
          actor_id      TEXT NOT NULL,
          action        TEXT NOT NULL,
          resource_type TEXT NOT NULL,
          resource_id   TEXT NOT NULL,
          session_id    TEXT,
          detail        JSONB NOT NULL DEFAULT '{}',
          request_id    TEXT,
          ip            INET,
          created_at    TIMESTAMPTZ NOT NULL,
          PRIMARY KEY (id, created_at)
        ) PARTITION BY RANGE (created_at)
    """)
    op.execute("CREATE INDEX idx_audit_ws_time ON audit_log (workspace_id, created_at DESC)")
    op.execute("CREATE INDEX idx_audit_session ON audit_log (workspace_id, session_id, created_at)")
    op.execute(
        "CREATE INDEX idx_audit_actor ON audit_log (workspace_id, actor_id, created_at DESC)"
    )

    for start, end, name in _month_bounds():
        op.execute(
            f"CREATE TABLE IF NOT EXISTS {name} PARTITION OF audit_log "
            f"FOR VALUES FROM ('{start}') TO ('{end}')"
        )

    _apply_grants()


def _month_bounds() -> list[tuple[str, str, str]]:
    """이번 달과 다음 달. **그 뒤는 스케줄러가 만든다.**"""
    now = datetime.now(UTC)
    out: list[tuple[str, str, str]] = []
    year, month = now.year, now.month
    for _ in range(2):
        nxt_year, nxt_month = (year, month + 1) if month < 12 else (year + 1, 1)
        out.append(
            (
                f"{year:04d}-{month:02d}-01",
                f"{nxt_year:04d}-{nxt_month:02d}-01",
                f"audit_log_{year:04d}_{month:02d}",
            )
        )
        year, month = nxt_year, nxt_month
    return out


def _apply_grants() -> None:
    """**append-only 를 DB 가 강제한다.**

    `REVOKE` 가 실패해도 마이그레이션을 깨지 않되 **경고로 남긴다** —
    조용히 넘어가면 append-only 가 아닌 채로 운영이 돌고, 그 사실을
    아무도 모른다 (`0004_credentials` 와 같은 패턴).
    """
    op.execute(f"""
        DO $$
        BEGIN
          REVOKE UPDATE, DELETE, TRUNCATE ON audit_log FROM {APP_ROLE};
          REVOKE UPDATE, DELETE, TRUNCATE ON audit_log FROM {WORKER_ROLE};
          GRANT  INSERT, SELECT ON audit_log TO {APP_ROLE};
          -- 워커도 감사에 쓴다 (툴 실행·샌드박스 사건). **읽지는 않는다** —
          -- 읽을 수 있으면 다른 워크스페이스의 감사를 볼 수 있다.
          GRANT  INSERT ON audit_log TO {WORKER_ROLE};
          GRANT  USAGE, SELECT ON SEQUENCE audit_log_id_seq TO {APP_ROLE};
          GRANT  USAGE, SELECT ON SEQUENCE audit_log_id_seq TO {WORKER_ROLE};
        EXCEPTION
          WHEN undefined_object OR insufficient_privilege THEN
            RAISE WARNING 'audit_log 권한을 걸지 못했다 — append-only 가 강제되지 않는다';
        END $$
    """)


def downgrade() -> None:
    op.execute("DROP TABLE IF EXISTS audit_log CASCADE")
