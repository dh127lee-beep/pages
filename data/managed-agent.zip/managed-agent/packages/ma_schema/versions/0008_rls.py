"""0008 · Row Level Security — **추가** 안전장치 (D7 보완)

`plan/05-database.md` §9 · `task/M3-security-governance/T-0406-security-suite-rls.md`.

> RLS 는 **추가** 안전장치다. 애플리케이션 필터를 빼도 되는 게 아니라,
> 빼먹었을 때 막아 주는 것이다. **둘 다 유지한다.**

애플리케이션은 연결마다 `SET LOCAL awp.workspace_id = '...'` 를 설정한다
(`ma_sql.workspace_scope`). 코드 버그로 `WHERE workspace_id = $1` 을
빠뜨려도 DB 가 막는다.

## 워커는 우회한다

워커의 claim 쿼리는 **워크스페이스를 횡단한다** — 아무 claimable 한
건을 집는 것이 그 설계다 (D3). 그래서 `awp_worker` 에 `BYPASSRLS` 를
준다.

그것이 구멍처럼 보이지만, **그 역할에 `credentials` 권한이 없다는 것이
보완한다** (`0004_credentials`). 워커가 횡단해서 볼 수 있는 것은 실행
권한과 이벤트이고, 비밀은 아니다.

## 정책을 거는 테이블

**스키마에서 유도한다** — `workspace_id` 컬럼이 있는 테이블 전부.

손으로 적으면 새 테이블이 조용히 빠지고 그 테이블만 구멍이 된다. 실제로
처음에 목록을 적었다가 9개를 빠뜨렸고, `test_every_scoped_table_has_rls`
가 잡았다. 빼는 것만 `EXCLUDED` 에 **이유와 함께** 적는다.

Revision ID: 0008
Revises: 0007
Create Date: 2026-10-15
"""

from __future__ import annotations

from alembic import op

revision = "0008"
down_revision = "0007"
branch_labels = None
depends_on = None

APP_ROLE = "awp_app"
WORKER_ROLE = "awp_worker"

#: 설정 키. `SET LOCAL` 로 트랜잭션 범위에만 산다.
SETTING = "awp.workspace_id"

#: **RLS 를 걸지 않는 테이블과 그 이유.**
#:
#: 목록을 손으로 적지 않는다 — 적으면 새 테이블이 조용히 빠지고, 그
#: 테이블만 구멍이 된다 (실제로 처음에 9개를 빠뜨렸고
#: `test_every_scoped_table_has_rls` 가 잡았다).
#:
#: 대신 **`workspace_id` 가 있는 테이블 전부**에 걸고, 빼는 것만 여기
#: 적는다. 빼려면 이유를 쓰게 되므로 그 자체가 리뷰 지점이다.
EXCLUDED: dict[str, str] = {
    # 테넌트 데이터가 아니라 **인프라 관측**이다 (D3 — 권한이 아니다).
    # `workspace_id` 가 nullable 이고, NULL 인 행(워크스페이스에 핀되지
    # 않은 워커)이 정책에 가려지면 운영이 전체 워커를 못 본다.
    "worker_instances": "인프라 관측 · workspace_id 가 nullable",
    # 이 테이블의 행이 **곧 워크스페이스 자신**이다. 자기를 자기로
    # 거르면 목록 조회가 통째로 막힌다.
    "workspaces": "워크스페이스 자신",
}


def upgrade() -> None:
    skip = ", ".join(f"'{t}'" for t in EXCLUDED)
    # **스키마에서 유도한다.** `workspace_id` 가 있는 테이블 전부에
    # 건다 — 손으로 적으면 새 테이블이 빠진다.
    #
    # `true` 두 번째 인자가 중요하다: 설정이 없으면 `current_setting`
    # 이 NULL 을 돌려주고, NULL 비교는 거짓이라 **아무것도 안 보인다.**
    # 설정을 빼먹으면 조회가 **비는 쪽으로** 실패한다. 반대였다면
    # 설정 누락이 전면 유출이 된다.
    op.execute(f"""
        DO $$
        DECLARE t RECORD;
        BEGIN
          FOR t IN
            SELECT c.relname AS name
            FROM pg_class c
            JOIN pg_namespace n ON n.oid = c.relnamespace
            WHERE n.nspname = 'public'
              AND c.relkind IN ('r', 'p')
              AND c.relname NOT IN ({skip})
              AND EXISTS (
                SELECT 1 FROM pg_attribute a
                WHERE a.attrelid = c.oid AND a.attname = 'workspace_id'
                  AND NOT a.attisdropped
              )
              -- 파티션 자식은 부모에서 상속된다.
              AND NOT EXISTS (SELECT 1 FROM pg_inherits i WHERE i.inhrelid = c.oid)
          LOOP
            EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t.name);
            EXECUTE format('DROP POLICY IF EXISTS %I ON %I', t.name || '_ws', t.name);
            EXECUTE format(
              'CREATE POLICY %I ON %I USING '
              '(workspace_id = current_setting(''{SETTING}'', true))',
              t.name || '_ws', t.name
            );
          END LOOP;
        EXCEPTION WHEN insufficient_privilege THEN
          RAISE WARNING 'RLS 를 걸지 못했다 — 권한을 확인하십시오';
        END $$
    """)  # noqa: S608 — skip 과 SETTING 은 이 모듈의 상수 리터럴이다

    _grant_operational()

    op.execute(f"""
        DO $$
        BEGIN
          -- **워커는 우회한다** — claim 이 워크스페이스를 횡단한다 (D3).
          -- 그 역할에 credentials 권한이 없다는 것이 보완한다.
          ALTER ROLE {WORKER_ROLE} BYPASSRLS;
        EXCEPTION
          WHEN undefined_object OR insufficient_privilege THEN
            RAISE WARNING '{WORKER_ROLE} 에 BYPASSRLS 를 주지 못했다 — claim 이 막힐 수 있다';
        END $$
    """)
    op.execute(f"""
        DO $$
        BEGIN
          -- 애플리케이션 역할은 **우회하지 않는다.** 그것이 요점이다.
          ALTER ROLE {APP_ROLE} NOBYPASSRLS;
        EXCEPTION
          WHEN undefined_object OR insufficient_privilege THEN
            RAISE WARNING '{APP_ROLE} 설정을 바꾸지 못했다';
        END $$
    """)


#: 이미 **명시적 권한이 걸린** 테이블. 여기 손대지 않는다 —
#: `0004_credentials`(워커 차단)·`0006_audit_log`(append-only)·
#: `0007_budgets`(워커 읽기 전용)가 정한 것을 덮으면 그 결정이 사라진다.
ALREADY_GRANTED = (
    "credentials",
    "vaults",
    "credential_events",
    "audit_log",
    "usage_events",
    "budgets",
)


def _grant_operational() -> None:
    """운영 테이블 권한. **역할이 아무것도 못 하면 RLS 는 의미가 없다.**

    여기까지 역할은 만들어졌지만 핵심 테이블(`sessions`·`agents`·
    `session_events`…)에 권한이 없었다. 소유자로만 돌던 개발 환경에서는
    안 보이다가, 역할로 접속하는 순간 전부 막힌다.

    `ALREADY_GRANTED` 는 건너뛴다 — 앞선 마이그레이션이 **일부러 좁혀
    놓은** 것들이고, 여기서 넓히면 그 결정이 사라진다.
    """
    skip = ", ".join(f"'{t}'" for t in ALREADY_GRANTED)
    op.execute(f"""
        DO $$
        DECLARE t RECORD;
        BEGIN
          FOR t IN
            SELECT c.relname AS name FROM pg_class c
            JOIN pg_namespace n ON n.oid = c.relnamespace
            WHERE n.nspname = 'public' AND c.relkind IN ('r', 'p')
              AND c.relname NOT IN ({skip})
              AND NOT EXISTS (SELECT 1 FROM pg_inherits i WHERE i.inhrelid = c.oid)
          LOOP
            EXECUTE format('GRANT SELECT, INSERT, UPDATE, DELETE ON %I TO {APP_ROLE}', t.name);
            EXECUTE format('GRANT SELECT, INSERT, UPDATE, DELETE ON %I TO {WORKER_ROLE}', t.name);
          END LOOP;
          FOR t IN
            SELECT c.relname AS name FROM pg_class c
            JOIN pg_namespace n ON n.oid = c.relnamespace
            WHERE n.nspname = 'public' AND c.relkind = 'S'
          LOOP
            EXECUTE format('GRANT USAGE, SELECT ON SEQUENCE %I TO {APP_ROLE}', t.name);
            EXECUTE format('GRANT USAGE, SELECT ON SEQUENCE %I TO {WORKER_ROLE}', t.name);
          END LOOP;
        EXCEPTION
          WHEN undefined_object OR insufficient_privilege THEN
            RAISE WARNING '운영 테이블 권한을 걸지 못했다 — 역할을 확인하십시오';
        END $$
    """)  # noqa: S608 — skip 과 역할 이름은 이 모듈의 상수 리터럴이다


def downgrade() -> None:
    op.execute("""
        DO $$
        DECLARE t RECORD;
        BEGIN
          FOR t IN
            SELECT c.relname AS name FROM pg_class c
            JOIN pg_namespace n ON n.oid = c.relnamespace
            WHERE n.nspname = 'public' AND c.relrowsecurity
          LOOP
            EXECUTE format('DROP POLICY IF EXISTS %I ON %I', t.name || '_ws', t.name);
            EXECUTE format('ALTER TABLE %I DISABLE ROW LEVEL SECURITY', t.name);
          END LOOP;
        END $$
    """)
