"""0007 · budgets · usage_events · quota_counters — 부서별 비용 통제 (P4)

`plan/05-database.md` §3 G10 · `plan/06-harness-and-model.md` §5 ·
`task/M3-security-governance/T-0405-budget-usage.md`.

> **`list_cost_cents` 를 그 시점 값으로 저장한다.** 나중에 요금이 바뀌어도
> 과거 비용이 재계산되지 않는다 — 카드를 아카이브해도 지우지 않는 이유와
> 같다.

캐시 히트/미스를 **분리해 적립한다.** 이것이 없으면 `plan/06` §5 의
지렛대(캐시 히트가 미스의 1/50)를 측정할 수 없다 — 합계만 있으면
"비용이 줄었다"는 보여도 **왜 줄었는지**를 모른다.

Revision ID: 0007
Revises: 0006
Create Date: 2026-10-15
"""

from __future__ import annotations

from datetime import UTC, datetime

from alembic import op

revision = "0007"
down_revision = "0006"
branch_labels = None
depends_on = None

APP_ROLE = "awp_app"
WORKER_ROLE = "awp_worker"


def upgrade() -> None:
    op.execute("""
        CREATE TABLE budgets (
          id             TEXT PRIMARY KEY,
          workspace_id   TEXT NOT NULL,
          scope          TEXT NOT NULL CHECK (scope IN ('workspace','agent','user')),
          scope_id       TEXT,
          period         TEXT NOT NULL CHECK (period IN ('daily','monthly','total')),
          limit_cents    INT  NOT NULL CHECK (limit_cents > 0),
          session_default_cents INT CHECK (session_default_cents IS NULL
                                           OR session_default_cents > 0),
          hard           BOOLEAN NOT NULL DEFAULT TRUE,
          created_at     TIMESTAMPTZ NOT NULL,
          -- 워크스페이스 예산은 `scope_id` 가 없고, 나머지는 있어야 한다.
          -- 도메인 불변식(`Budget.__post_init__`)과 같은 것을 DB 에도 건다.
          CONSTRAINT budgets_scope_id_present CHECK (
            scope = 'workspace' OR scope_id IS NOT NULL
          )
        )
    """)
    # `scope_id` 가 NULL 인 행도 유일해야 한다. `COALESCE` 로 묶는다 —
    # PostgreSQL 에서 NULL 은 서로 다르므로 그냥 두면 워크스페이스 예산을
    # 여러 개 만들 수 있다.
    op.execute("""
        CREATE UNIQUE INDEX idx_budgets_scope
        ON budgets (workspace_id, scope, COALESCE(scope_id, ''), period)
    """)

    op.execute("""
        CREATE TABLE usage_events (
          id            BIGSERIAL,
          workspace_id  TEXT NOT NULL,
          session_id    TEXT NOT NULL,
          thread_id     TEXT,
          agent_id      TEXT,
          model_card_id TEXT NOT NULL,
          wire_model    TEXT NOT NULL,
          -- **캐시 히트/미스를 분리한다** (`plan/06` §5).
          input_cache_hit_tokens  BIGINT NOT NULL DEFAULT 0,
          input_cache_miss_tokens BIGINT NOT NULL DEFAULT 0,
          output_tokens           BIGINT NOT NULL DEFAULT 0,
          -- **그 시점 요금으로 계산한 값.** 다시 계산하지 않는다.
          list_cost_cents       NUMERIC(12,4) NOT NULL DEFAULT 0
              CHECK (list_cost_cents >= 0),
          sandbox_seconds       INT NOT NULL DEFAULT 0,
          created_at    TIMESTAMPTZ NOT NULL,
          PRIMARY KEY (id, created_at)
        ) PARTITION BY RANGE (created_at)
    """)
    op.execute("CREATE INDEX idx_usage_ws_time ON usage_events (workspace_id, created_at DESC)")
    op.execute("CREATE INDEX idx_usage_session ON usage_events (workspace_id, session_id)")
    # 에이전트별 집계. 예산 스코프가 `agent` 일 때 쓴다.
    op.execute("""
        CREATE INDEX idx_usage_agent ON usage_events (workspace_id, agent_id, created_at DESC)
        WHERE agent_id IS NOT NULL
    """)

    for start, end, name in _month_bounds():
        op.execute(
            f"CREATE TABLE IF NOT EXISTS {name} PARTITION OF usage_events "
            f"FOR VALUES FROM ('{start}') TO ('{end}')"
        )

    op.execute("""
        CREATE TABLE quota_counters (
          workspace_id  TEXT NOT NULL,
          kind          TEXT NOT NULL
              CHECK (kind IN ('concurrent_sessions','daily_sessions')),
          window_start  DATE NOT NULL,
          value         INT  NOT NULL DEFAULT 0 CHECK (value >= 0),
          updated_at    TIMESTAMPTZ NOT NULL,
          PRIMARY KEY (workspace_id, kind, window_start)
        )
    """)

    _apply_grants()


def _month_bounds() -> list[tuple[str, str, str]]:
    now = datetime.now(UTC)
    out: list[tuple[str, str, str]] = []
    year, month = now.year, now.month
    for _ in range(2):
        ny, nm = (year, month + 1) if month < 12 else (year + 1, 1)
        out.append(
            (
                f"{year:04d}-{month:02d}-01",
                f"{ny:04d}-{nm:02d}-01",
                f"usage_events_{year:04d}_{month:02d}",
            )
        )
        year, month = ny, nm
    return out


def _apply_grants() -> None:
    """**사용량은 워커가 쓴다.** 예산은 제어 평면만 쓴다.

    워커가 `budgets` 를 쓸 수 있으면, 탈취된 워커가 자기 상한을 올릴 수
    있다. 읽기는 필요하다 — 상한에 도달했는지 봐야 한다.
    """
    op.execute(f"""
        DO $$
        BEGIN
          GRANT SELECT, INSERT, UPDATE, DELETE ON budgets TO {APP_ROLE};
          GRANT SELECT ON budgets TO {WORKER_ROLE};
          REVOKE INSERT, UPDATE, DELETE ON budgets FROM {WORKER_ROLE};

          GRANT SELECT, INSERT ON usage_events TO {APP_ROLE};
          GRANT SELECT, INSERT ON usage_events TO {WORKER_ROLE};
          -- 사용량도 **고치지 않는다.** 비용 기록은 감사의 일부다.
          REVOKE UPDATE, DELETE, TRUNCATE ON usage_events FROM {APP_ROLE};
          REVOKE UPDATE, DELETE, TRUNCATE ON usage_events FROM {WORKER_ROLE};
          GRANT USAGE, SELECT ON SEQUENCE usage_events_id_seq TO {APP_ROLE};
          GRANT USAGE, SELECT ON SEQUENCE usage_events_id_seq TO {WORKER_ROLE};

          GRANT SELECT, INSERT, UPDATE ON quota_counters TO {APP_ROLE};
          GRANT SELECT, INSERT, UPDATE ON quota_counters TO {WORKER_ROLE};
        EXCEPTION
          WHEN undefined_object OR insufficient_privilege THEN
            RAISE WARNING '예산·사용량 권한을 걸지 못했다 — 역할을 확인하십시오';
        END $$
    """)  # noqa: S608


def downgrade() -> None:
    op.execute("DROP TABLE IF EXISTS quota_counters")
    op.execute("DROP TABLE IF EXISTS usage_events CASCADE")
    op.execute("DROP TABLE IF EXISTS budgets")
