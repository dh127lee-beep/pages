"""0013 · session_executions.trace_context — trace 연결 (T-0505)

`plan/08-infrastructure.md` §9 · `IMPL-0029`.

> **두 프로세스를 잇는 길이 DB 뿐이다.**
>
> 보통은 HTTP 헤더로 trace 를 잇는다. 여기서는 안 된다 — 워커는 요청을
> 받지 않고 **큐를 긁어 간다** (D3). 제어 평면이 실행 행을 만들 때
> W3C `traceparent` 를 같이 넣고, 워커가 claim 할 때 꺼내 이어붙인다.

```
POST /sessions/{id}/events
  span: api.send_events
    └ inject ──→ session_executions.trace_context
                         │
                    claim 시 extract
                         └ span: worker.turn   ← 같은 trace
                             └ span: model.request
```

`NULL` 을 허용한다. 비어 있으면 워커가 **새 trace 를 시작한다** —
끊긴 것을 억지로 잇지 않고, 워커가 "앞이 없다"고 멈추지도 않는다.
관측의 손실은 실행의 실패가 아니다.

Revision ID: 0013
Revises: 0012
Create Date: 2026-10-16
"""

from __future__ import annotations

from alembic import op

revision = "0013"
down_revision = "0012"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute("ALTER TABLE session_executions ADD COLUMN IF NOT EXISTS trace_context JSONB")


def downgrade() -> None:
    op.execute("ALTER TABLE session_executions DROP COLUMN IF EXISTS trace_context")
