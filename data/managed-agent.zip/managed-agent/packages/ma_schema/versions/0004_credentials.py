"""0004 · vaults · credentials · credential_events — D5 의 저장 측면

`plan/05-database.md` §3 G6 · §7 · `task/M3-security-governance/T-0401-vault-credentials.md`.

**평문 컬럼이 없다.** `ciphertext BYTEA` 와 `nonce BYTEA` 뿐이다. 평문 컬럼이
하나라도 있으면 덤프·백업·복제본·로그에 남고, 그것들은 전부 우리 위협 모델
밖에 있다.

`credential_events` 는 "언제 누구에게 쓰였는가"다. **평문은 없다.** egress
프록시가 주입할 때마다 한 줄 쓰고, 세션별로 집계하면 "이 세션이 어떤
시스템에 몇 번 접근했는가"가 나온다 (T-0404 의 감사 요구를 직접 만족시킨다).

## DB 역할

`awp_worker` 는 **`credentials` 를 읽을 수 없다.** 워커 프로세스는 샌드박스를
호스팅하므로, 그 프로세스가 평문을 만들 수 있으면 D5 가 성립하지 않는다 —
"유출할 토큰이 존재하지 않는다"가 아니라 "유출할 토큰이 옆방에 있다"가 된다.

역할 생성은 **최선 노력**이다. 관리형 PostgreSQL 은 `CREATE ROLE` 에 권한이
필요하고, 로컬 개발 DB 에는 역할이 아예 없어도 된다. 실패해도 마이그레이션을
깨지 않되 **무엇을 못 했는지 남긴다** — 조용히 넘어가면 운영에서 역할이 없는
채로 돌고, 그 사실을 아무도 모른다.

Revision ID: 0004
Revises: 0003
Create Date: 2026-10-15
"""

from __future__ import annotations

from alembic import op

revision = "0004"
down_revision = "0003"
branch_labels = None
depends_on = None

#: 애플리케이션(제어 평면) 역할. 자격증명을 쓰고 읽는다.
APP_ROLE = "awp_app"
#: 워커 역할. **자격증명에 손댈 수 없다.**
WORKER_ROLE = "awp_worker"

SECRET_TABLES = ("vaults", "credentials", "credential_events")


def upgrade() -> None:
    op.execute("""
        CREATE TABLE vaults (
          id            TEXT NOT NULL,
          workspace_id  TEXT NOT NULL,
          name          TEXT NOT NULL,
          document      JSONB NOT NULL DEFAULT '{}',
          version       INT  NOT NULL DEFAULT 1,
          created_at    TIMESTAMPTZ NOT NULL,
          archived_at   TIMESTAMPTZ,
          PRIMARY KEY (workspace_id, id)
        )
    """)
    op.execute("""
        CREATE UNIQUE INDEX idx_vaults_name ON vaults (workspace_id, name)
        WHERE archived_at IS NULL
    """)

    op.execute("""
        CREATE TABLE credentials (
          id                TEXT NOT NULL,
          workspace_id      TEXT NOT NULL,
          vault_id          TEXT NOT NULL,
          kind              TEXT NOT NULL
              CHECK (kind IN ('bearer','basic','api_key_header','mcp_oauth',
                              'environment_variable')),
          match_hosts       TEXT[] NOT NULL DEFAULT '{}',
          mcp_server_name   TEXT,
          header_name       TEXT,
          ciphertext        BYTEA NOT NULL,
          nonce             BYTEA NOT NULL,
          key_version       INT  NOT NULL,
          expires_at        TIMESTAMPTZ,
          refresh_failed_at TIMESTAMPTZ,
          refresh_error     TEXT,
          created_by        TEXT NOT NULL,
          created_at        TIMESTAMPTZ NOT NULL,
          rotated_at        TIMESTAMPTZ,
          archived_at       TIMESTAMPTZ,
          PRIMARY KEY (workspace_id, id),
          FOREIGN KEY (workspace_id, vault_id) REFERENCES vaults (workspace_id, id)
        )
    """)
    op.execute("""
        CREATE INDEX idx_credentials_vault ON credentials (workspace_id, vault_id)
        WHERE archived_at IS NULL
    """)
    # egress 프록시의 핫 경로: (워크스페이스, 호스트) → 자격증명.
    op.execute("""
        CREATE INDEX idx_credentials_hosts ON credentials USING GIN (match_hosts)
        WHERE archived_at IS NULL
    """)
    # 재암호화 배치가 고르는 경로. 버전이 뒤처진 행만 본다 (`IMPL-0020`).
    op.execute("""
        CREATE INDEX idx_credentials_keyver ON credentials (workspace_id, key_version)
        WHERE archived_at IS NULL
    """)

    op.execute("""
        CREATE TABLE credential_events (
          id            BIGSERIAL PRIMARY KEY,
          workspace_id  TEXT NOT NULL,
          credential_id TEXT NOT NULL,
          session_id    TEXT,
          action        TEXT NOT NULL
              CHECK (action IN ('injected','refreshed','refresh_failed','rotated','denied')),
          host          TEXT,
          generation    INT,
          created_at    TIMESTAMPTZ NOT NULL
        )
    """)
    op.execute("""
        CREATE INDEX idx_cred_events_session
        ON credential_events (workspace_id, session_id, created_at)
    """)
    # "이 자격증명이 언제 쓰였나" — 로테이션 판단과 감사가 쓴다.
    op.execute("""
        CREATE INDEX idx_cred_events_credential
        ON credential_events (workspace_id, credential_id, created_at DESC)
    """)

    _apply_roles()


def _apply_roles() -> None:
    """역할과 권한. **실패해도 마이그레이션을 깨지 않는다.**

    `DO` 블록 안에서 `insufficient_privilege` 를 잡고 `RAISE WARNING` 으로
    남긴다. 관리형 DB 에서 `CREATE ROLE` 이 막혀 있는 것은 흔하고, 그때는
    운영자가 손으로 만들어야 한다 — 경고가 그 신호다.
    """
    for role in (APP_ROLE, WORKER_ROLE):
        # 역할 이름은 이 파일의 상수다 — 바깥에서 오지 않는다. DDL 은
        # 식별자를 파라미터로 받지 못하므로 문자열 조립 외에 방법이 없다.
        op.execute(f"""
            DO $$
            BEGIN
              IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = '{role}') THEN
                CREATE ROLE {role} NOLOGIN;
              END IF;
            EXCEPTION WHEN insufficient_privilege THEN
              RAISE WARNING '역할 {role} 을 만들지 못했다 — 손으로 만들고 권한을 거십시오';
            END $$
        """)  # noqa: S608

    tables = ", ".join(SECRET_TABLES)
    op.execute(f"""
        DO $$
        BEGIN
          -- 워커는 **아무것도** 못 한다. 기본값도 그렇지만 명시한다 —
          -- 나중에 누가 넓게 GRANT 해도 이 줄이 의도를 남긴다.
          REVOKE ALL ON {tables} FROM {WORKER_ROLE};
          GRANT SELECT, INSERT, UPDATE ON {tables} TO {APP_ROLE};
          GRANT USAGE, SELECT ON SEQUENCE credential_events_id_seq TO {APP_ROLE};
        EXCEPTION
          WHEN undefined_object OR insufficient_privilege THEN
            RAISE WARNING '자격증명 테이블 권한을 걸지 못했다 — 역할을 확인하십시오';
        END $$
    """)


def downgrade() -> None:
    op.execute("DROP TABLE IF EXISTS credential_events")
    op.execute("DROP TABLE IF EXISTS credentials")
    op.execute("DROP TABLE IF EXISTS vaults")
