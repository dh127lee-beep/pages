"""0005 · approval_policies · approvals — 승인 정책 레이어 (D8)

`plan/05-database.md` §3 G10 · `plan/02-architecture.md` §7 ·
`task/M3-security-governance/T-0403-approval-workflow.md`.

공식 계약은 "클라이언트가 `user.tool_confirmation` 을 보낸다"까지만 정의한다.
사내에서는 **누가 보낼 수 있는지**가 핵심이라 그 위에 정책을 얹는다.

> **승인 요청에 툴 인자를 복사하지 않는다.** 이미 스트리밍된
> `agent.tool_use` 이벤트에 `tool_call_id` 로 연결한다 — 두 번째 복사본은
> drift 한다. `input_summary` 만 둔다 (그마저도 비밀이 섞일 수 있어 요약이다).

`audit_log` 와 `budgets`·`usage_events` 는 여기 없다 — T-0404·T-0405 가
만든다. 한 마이그레이션에 몰면 그 셋 중 하나를 고칠 때 나머지가 함께
움직인다.

Revision ID: 0005
Revises: 0004
Create Date: 2026-10-15
"""

from __future__ import annotations

from alembic import op

revision = "0005"
down_revision = "0004"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute("""
        CREATE TABLE approval_policies (
          id                 TEXT PRIMARY KEY,
          workspace_id       TEXT NOT NULL,
          agent_id           TEXT,
          tool_pattern       TEXT NOT NULL,
          required_role      TEXT NOT NULL
              CHECK (required_role IN ('viewer','operator','admin','owner')),
          required_approvals INT  NOT NULL DEFAULT 1
              CHECK (required_approvals >= 1),
          self_approval      BOOLEAN NOT NULL DEFAULT FALSE,
          notify             JSONB NOT NULL DEFAULT '{}',
          expires_after_s    INT CHECK (expires_after_s IS NULL OR expires_after_s > 0),
          priority           INT  NOT NULL DEFAULT 0,
          created_at         TIMESTAMPTZ NOT NULL
        )
    """)
    # 정책 해석의 핫 경로: 워크스페이스의 정책을 우선순위 역순으로 본다.
    op.execute("""
        CREATE INDEX idx_approval_policies ON approval_policies (workspace_id, priority DESC)
    """)

    op.execute("""
        CREATE TABLE approvals (
          id             TEXT PRIMARY KEY,
          workspace_id   TEXT NOT NULL,
          session_id     TEXT NOT NULL,
          event_id       TEXT NOT NULL,
          tool_call_id   TEXT NOT NULL,
          tool_name      TEXT NOT NULL,
          tool_kind      TEXT NOT NULL
              CHECK (tool_kind IN ('builtin','mcp','custom','delegation')),
          input_summary  JSONB NOT NULL DEFAULT '{}',
          policy_id      TEXT,
          state          TEXT NOT NULL
              CHECK (state IN ('pending','approved','denied','expired')),
          decided_by     TEXT[] NOT NULL DEFAULT '{}',
          decided_at     TIMESTAMPTZ,
          reason         TEXT,
          requested_at   TIMESTAMPTZ NOT NULL,
          expires_at     TIMESTAMPTZ,
          -- **결정된 승인에는 결정자와 시각이 있어야 한다.**
          -- 도메인 불변식(`Approval.__post_init__`)과 같은 것을 DB 에도
          -- 건다 — 애플리케이션을 거치지 않는 쓰기가 생겨도 깨지지 않게.
          CONSTRAINT approvals_decided_complete CHECK (
            state NOT IN ('approved','denied')
            OR (decided_at IS NOT NULL AND array_length(decided_by, 1) >= 1)
          )
        )
    """)
    # **한 호출에 승인은 하나.** 두 개가 생기면 하나는 영영 안 보인다.
    op.execute("""
        CREATE UNIQUE INDEX idx_approvals_call
        ON approvals (workspace_id, session_id, tool_call_id)
    """)
    # 인박스. 대기 중인 것만 본다.
    op.execute("""
        CREATE INDEX idx_approvals_inbox ON approvals (workspace_id, requested_at DESC)
        WHERE state = 'pending'
    """)
    # 만료 스윕. 기한이 있는 대기 건만 본다.
    op.execute("""
        CREATE INDEX idx_approvals_expiry ON approvals (expires_at)
        WHERE state = 'pending' AND expires_at IS NOT NULL
    """)


def downgrade() -> None:
    op.execute("DROP TABLE IF EXISTS approvals")
    op.execute("DROP TABLE IF EXISTS approval_policies")
