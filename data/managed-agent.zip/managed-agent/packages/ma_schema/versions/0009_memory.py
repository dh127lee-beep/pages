"""0009 · memory_stores · memories · memory_versions — D10

`plan/05-database.md` §3 G7 · `plan/02-architecture.md` §9 ·
`task/M4-productization/T-0501-memory-sync.md`.

> **content 를 DB 에 두는 이유**: 메모리 하나는 100KB 이하이고, 진실의
> 원천이 하나여야 한다. 레퍼런스는 오브젝트 스토어를 bytes-of-truth 로
> 두고 DB 를 인덱스로 썼는데, 그 결과 "에이전트가 FUSE 로 직접 쓴 것"을
> 이벤트 큐로 reconcile 해야 하고 그 사이에 gap 이 생긴다.
>
> AWP 는 **SQL 이 진실**이고 샌드박스에는 **사본**을 마운트해 턴 종료에
> CAS 로 되돌린다.

경로 충돌을 **DB 가 보장한다** — 공식 계약의 `memory_path_conflict_error`
가 애플리케이션의 선의가 아니라 유니크 인덱스에서 나온다.

Revision ID: 0009
Revises: 0008
Create Date: 2026-10-16
"""

from __future__ import annotations

from alembic import op

revision = "0009"
down_revision = "0008"
branch_labels = None
depends_on = None

APP_ROLE = "awp_app"
WORKER_ROLE = "awp_worker"
SETTING = "awp.workspace_id"

TABLES = ("memory_stores", "memories", "memory_versions")


def upgrade() -> None:
    op.execute("""
        CREATE TABLE memory_stores (
          id            TEXT NOT NULL,
          workspace_id  TEXT NOT NULL REFERENCES workspaces(id),
          name          TEXT NOT NULL,
          slug          TEXT NOT NULL,
          document      JSONB NOT NULL DEFAULT '{}',
          revision      BIGINT NOT NULL DEFAULT 0,
          created_at    TIMESTAMPTZ NOT NULL,
          archived_at   TIMESTAMPTZ,
          PRIMARY KEY (workspace_id, id)
        )
    """)
    # `/mnt/memory/<slug>` 가 겹치면 **두 스토어가 같은 곳에 마운트된다.**
    op.execute("""
        CREATE UNIQUE INDEX idx_memory_stores_slug ON memory_stores (workspace_id, slug)
        WHERE archived_at IS NULL
    """)

    op.execute("""
        CREATE TABLE memories (
          id              TEXT NOT NULL,
          workspace_id    TEXT NOT NULL,
          store_id        TEXT NOT NULL,
          path            TEXT NOT NULL,
          content         TEXT NOT NULL,
          content_sha256  TEXT NOT NULL,
          revision        BIGINT NOT NULL DEFAULT 0,
          created_at      TIMESTAMPTZ NOT NULL,
          updated_at      TIMESTAMPTZ NOT NULL,
          deleted_at      TIMESTAMPTZ,
          PRIMARY KEY (workspace_id, id),
          FOREIGN KEY (workspace_id, store_id)
            REFERENCES memory_stores (workspace_id, id),
          -- 100KB 상한을 DB 에도 건다. 도메인이 먼저 막지만, 애플리케이션을
          -- 거치지 않는 쓰기(마이그레이션·복구 스크립트)가 생겨도 깨지지
          -- 않게 한다.
          CONSTRAINT memories_content_size CHECK (octet_length(content) <= 102400)
        )
    """)
    # **경로 충돌을 DB 가 보장한다** (`memory_path_conflict_error`).
    op.execute("""
        CREATE UNIQUE INDEX idx_memories_path ON memories (workspace_id, store_id, path)
        WHERE deleted_at IS NULL
    """)
    # 스토어 하나를 materialize 하는 경로 — 세션 웜업의 핫 경로다.
    op.execute("""
        CREATE INDEX idx_memories_store ON memories (workspace_id, store_id, path)
        WHERE deleted_at IS NULL
    """)

    op.execute("""
        CREATE TABLE memory_versions (
          id              TEXT NOT NULL,
          workspace_id    TEXT NOT NULL,
          store_id        TEXT NOT NULL,
          memory_id       TEXT NOT NULL,
          path            TEXT NOT NULL,
          -- **레댁션되면 NULL 이 된다.** 그래서 nullable 이다 —
          -- 행 자체는 남겨 "무엇이 있었고 누가 지웠는가"를 보존한다.
          content         TEXT,
          content_sha256  TEXT NOT NULL,
          author          TEXT NOT NULL,
          redacted_at     TIMESTAMPTZ,
          redacted_by     TEXT,
          created_at      TIMESTAMPTZ NOT NULL,
          PRIMARY KEY (workspace_id, id),
          -- 레댁션은 **둘 다 있거나 둘 다 없다.**
          CONSTRAINT memory_versions_redaction_complete CHECK (
            (redacted_at IS NULL) = (redacted_by IS NULL)
          )
        )
    """)
    op.execute("""
        CREATE INDEX idx_memory_versions
        ON memory_versions (workspace_id, memory_id, created_at DESC)
    """)

    _apply_security()


def _apply_security() -> None:
    """RLS + 권한. `0008_rls` 와 같은 규칙을 새 테이블에도 적용한다.

    `0008` 이 스키마에서 유도하지만 **그때 없던 테이블**이므로 여기서
    다시 건다. 마이그레이션을 다시 돌리지 않는 한 `0008` 은 이 테이블을
    모른다.
    """
    tables = ", ".join(TABLES)
    for table in TABLES:
        op.execute(f"""
            DO $$
            BEGIN
              EXECUTE 'ALTER TABLE {table} ENABLE ROW LEVEL SECURITY';
              EXECUTE 'DROP POLICY IF EXISTS {table}_ws ON {table}';
              EXECUTE 'CREATE POLICY {table}_ws ON {table} '
                      'USING (workspace_id = current_setting(''{SETTING}'', true))';
            EXCEPTION WHEN insufficient_privilege THEN
              RAISE WARNING '{table} 에 RLS 를 걸지 못했다';
            END $$
        """)
    op.execute(f"""
        DO $$
        BEGIN
          GRANT SELECT, INSERT, UPDATE, DELETE ON {tables} TO {APP_ROLE};
          -- **워커도 쓴다** — 턴 종료 동기화가 워커에서 일어난다
          -- (`plan/02` §9). 그래서 자격증명과 다르다.
          GRANT SELECT, INSERT, UPDATE, DELETE ON {tables} TO {WORKER_ROLE};
        EXCEPTION
          WHEN undefined_object OR insufficient_privilege THEN
            RAISE WARNING '메모리 테이블 권한을 걸지 못했다';
        END $$
    """)


def downgrade() -> None:
    op.execute("DROP TABLE IF EXISTS memory_versions")
    op.execute("DROP TABLE IF EXISTS memories")
    op.execute("DROP TABLE IF EXISTS memory_stores")
