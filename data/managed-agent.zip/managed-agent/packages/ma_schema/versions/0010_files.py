"""0010 · files · session_outputs · workspace_snapshots — G8

`plan/05-database.md` §3 G8 · `plan/08-infrastructure.md` §6 ·
`task/M4-productization/T-0502-files-outputs.md`.

> **바이트는 DB 에 없다.** 메모리(G7)와 정확히 반대다.
>
> 메모리는 100KB 이하의 텍스트이고 진실이 하나여야 해서 `content` 를
> DB 에 뒀다. 업로드 파일은 수십 MB 의 임의 바이트이고, DB 에 넣으면
> WAL 과 백업이 그만큼 부풀고 복제가 느려진다. 그래서 **DB 는 좌표와
> 메타데이터만** 들고 바이트는 오브젝트 스토어에 둔다.
>
> 그 대가로 **두 저장소가 어긋날 수 있다** — 행은 있는데 객체가 없는
> 상태. 그래서 `uploaded_at` 이 nullable 이다: 행을 먼저 만들고 업로드가
> 끝나야 채운다. 채워지지 않은 행은 **미완성이고 마운트되지 않는다.**

키 규칙은 `plan/08` §6 표 그대로다:

| 용도 | 키 |
|---|---|
| 업로드 파일 | `files/<ws>/<file_id>` |
| 세션 산출물 | `outputs/<ws>/<session>/<name>` |
| 워크스페이스 스냅샷 | `snapshots/<ws>/<session>/<gen>.tar.zst` |

스냅샷 키에 **generation 이 들어간다** — fence 와 맞춘다 (D3). 같은 세션의
두 세대가 같은 키를 쓰면 좀비 워커가 새 소유자의 스냅샷을 덮는다.

Revision ID: 0010
Revises: 0009
Create Date: 2026-10-16
"""

from __future__ import annotations

from alembic import op

revision = "0010"
down_revision = "0009"
branch_labels = None
depends_on = None

APP_ROLE = "awp_app"
WORKER_ROLE = "awp_worker"
SETTING = "awp.workspace_id"

TABLES = ("files", "session_outputs", "workspace_snapshots")

#: 업로드 상한. DB 에도 건다 — 애플리케이션을 거치지 않는 쓰기가 생겨도
#: 오브젝트 스토어 요금이 폭주하지 않게.
MAX_FILE_BYTES = 100 * 1024 * 1024


def upgrade() -> None:
    op.execute(f"""
        CREATE TABLE files (
          id            TEXT NOT NULL,
          workspace_id  TEXT NOT NULL REFERENCES workspaces(id),
          -- 사용자가 보낸 이름 그대로. **정규화본은 따로 둔다** —
          -- 원본을 잃으면 다운로드 헤더에 되돌려 줄 것이 없다.
          filename      TEXT NOT NULL,
          -- 경로 구분자·제어문자를 제거한 안전한 이름. 마운트에 쓴다.
          safe_name     TEXT NOT NULL,
          content_type  TEXT NOT NULL,
          size_bytes    BIGINT NOT NULL,
          sha256        TEXT NOT NULL,
          storage_key   TEXT NOT NULL,
          created_by    TEXT NOT NULL,
          created_at    TIMESTAMPTZ NOT NULL,
          -- **바이트가 실제로 올라간 시각.** NULL 이면 미완성이다.
          uploaded_at   TIMESTAMPTZ,
          deleted_at    TIMESTAMPTZ,
          PRIMARY KEY (workspace_id, id),
          CONSTRAINT files_size_positive CHECK (size_bytes >= 0),
          CONSTRAINT files_size_limit CHECK (size_bytes <= {MAX_FILE_BYTES}),
          -- 빈 이름은 마운트 경로를 망가뜨린다.
          CONSTRAINT files_safe_name_nonempty CHECK (safe_name <> '')
        )
    """)
    # 같은 바이트를 두 번 올리는 것은 **막지 않는다** (다른 사용자·다른
    # 보존정책일 수 있다). 대신 중복을 찾을 수 있게 인덱스만 둔다.
    op.execute("""
        CREATE INDEX idx_files_sha ON files (workspace_id, sha256)
        WHERE deleted_at IS NULL
    """)
    op.execute("""
        CREATE INDEX idx_files_created ON files (workspace_id, created_at DESC)
        WHERE deleted_at IS NULL
    """)
    # 객체는 있는데 행이 두 개인 상태를 막는다.
    op.execute("CREATE UNIQUE INDEX idx_files_key ON files (storage_key)")

    op.execute("""
        CREATE TABLE session_outputs (
          id            TEXT NOT NULL,
          workspace_id  TEXT NOT NULL,
          session_id    TEXT NOT NULL,
          -- 샌드박스 워크스페이스 기준 상대 경로 ('reports/q3.pdf').
          path          TEXT NOT NULL,
          content_type  TEXT NOT NULL,
          size_bytes    BIGINT NOT NULL,
          sha256        TEXT NOT NULL,
          storage_key   TEXT NOT NULL,
          -- 어느 세대가 만들었는가. **좀비가 쓴 산출물을 가려낸다.**
          generation    BIGINT NOT NULL,
          created_at    TIMESTAMPTZ NOT NULL,
          deleted_at    TIMESTAMPTZ,
          PRIMARY KEY (workspace_id, id),
          CONSTRAINT session_outputs_size_positive CHECK (size_bytes >= 0)
        )
    """)
    # 같은 세션이 같은 경로를 두 번 내면 **뒤엣것이 이긴다** — 그래서
    # 유니크가 아니라 조회 인덱스다. 버전은 `created_at` 으로 구분한다.
    op.execute("""
        CREATE INDEX idx_session_outputs
        ON session_outputs (workspace_id, session_id, created_at DESC)
        WHERE deleted_at IS NULL
    """)
    op.execute("CREATE UNIQUE INDEX idx_outputs_key ON session_outputs (storage_key)")

    op.execute("""
        CREATE TABLE workspace_snapshots (
          id            TEXT NOT NULL,
          workspace_id  TEXT NOT NULL,
          session_id    TEXT NOT NULL,
          -- `snapshots/<ws>/<session>/<gen>.tar.zst` 의 <gen>.
          generation    BIGINT NOT NULL,
          size_bytes    BIGINT NOT NULL,
          sha256        TEXT NOT NULL,
          storage_key   TEXT NOT NULL,
          created_at    TIMESTAMPTZ NOT NULL,
          -- 보존 만료 시각. 청소 잡이 이것을 본다 (기본 7일).
          expires_at    TIMESTAMPTZ NOT NULL,
          deleted_at    TIMESTAMPTZ,
          PRIMARY KEY (workspace_id, id),
          CONSTRAINT snapshots_size_positive CHECK (size_bytes >= 0)
        )
    """)
    # **세대마다 하나다.** 좀비 워커가 같은 세대 키를 다시 쓰면 막힌다.
    op.execute("""
        CREATE UNIQUE INDEX idx_snapshots_gen
        ON workspace_snapshots (workspace_id, session_id, generation)
    """)
    op.execute("""
        CREATE INDEX idx_snapshots_expiry ON workspace_snapshots (expires_at)
        WHERE deleted_at IS NULL
    """)

    _apply_security()


def _apply_security() -> None:
    """RLS + 권한. `0008_rls` 와 같은 규칙을 새 테이블에도 적용한다."""
    tables = ", ".join(TABLES)
    for table in TABLES:
        op.execute(f"""
            DO $$
            BEGIN
              EXECUTE 'ALTER TABLE {table} ENABLE ROW LEVEL SECURITY';
              EXECUTE 'DROP POLICY IF EXISTS {table}_ws ON {table}';
              EXECUTE 'CREATE POLICY {table}_ws ON {table} '
                      'USING (workspace_id = current_setting(''{SETTING}'', true))';
            EXCEPTION WHEN insufficient_privilege THEN
              RAISE WARNING '{table} 에 RLS 를 걸지 못했다';
            END $$
        """)
    op.execute(f"""
        DO $$
        BEGIN
          GRANT SELECT, INSERT, UPDATE, DELETE ON {tables} TO {APP_ROLE};
          -- 워커는 **산출물과 스냅샷을 쓴다** (세션 안에서 생긴다).
          -- `files` 는 업로드 경로라 제어 평면만 쓴다 — 워커에 INSERT 를
          -- 주면 샌드박스가 자기 입력 파일을 만들 수 있게 된다.
          GRANT SELECT ON files TO {WORKER_ROLE};
          GRANT SELECT, INSERT, UPDATE ON session_outputs TO {WORKER_ROLE};
          GRANT SELECT, INSERT, UPDATE ON workspace_snapshots TO {WORKER_ROLE};
        EXCEPTION
          WHEN undefined_object OR insufficient_privilege THEN
            RAISE WARNING '파일 테이블 권한을 걸지 못했다';
        END $$
    """)


def downgrade() -> None:
    op.execute("DROP TABLE IF EXISTS workspace_snapshots")
    op.execute("DROP TABLE IF EXISTS session_outputs")
    op.execute("DROP TABLE IF EXISTS files")
