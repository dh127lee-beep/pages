"""0016 · deployments · deployment_runs — G9 (T-0603)

`plan/05-database.md` §3 G9 · `plan/06-harness-and-model.md` §5.4 ·
`ref/api/deployments/`.

> **`schedules` 를 따로 두지 않는다.** `plan/05` §3 의 G9 표가 셋을
> 들지만, 공식 계약은 스케줄을 배포의 **필드**로 둔다
> (`schedule: BetaManagedAgentsSchedule or null`). 배포 하나에
> 스케줄 하나이고, 조인할 이유가 없다 — 테이블을 나누면 "스케줄만
> 있고 배포가 없는" 행이 가능해진다.

`next_fire_at` 을 컬럼으로 둔다. cron 을 매번 풀어 계산할 수도 있지만,
**스케줄러가 "지금 돌 것"을 찾는 질의**가 그것을 인덱스로 타야 한다 —
풀어서 비교하면 배포 수만큼 cron 을 파싱한다.

Revision ID: 0016
Revises: 0015
Create Date: 2026-10-16
"""

from __future__ import annotations

from alembic import op

revision = "0016"
down_revision = "0015"
branch_labels = None
depends_on = None

APP_ROLE = "awp_app"
WORKER_ROLE = "awp_worker"
SETTING = "awp.workspace_id"

TABLES = ("deployments", "deployment_runs")


def upgrade() -> None:
    op.execute("""
        CREATE TABLE deployments (
          id              TEXT NOT NULL,
          workspace_id    TEXT NOT NULL REFERENCES workspaces(id),
          name            TEXT NOT NULL,
          agent_id        TEXT NOT NULL,
          -- **버전을 핀한다.** 에이전트가 바뀌어도 배포는 그대로 돈다
          -- (세션이 버전을 핀하는 것과 같은 이유).
          agent_version   INT NOT NULL,
          environment_id  TEXT,
          state           TEXT NOT NULL DEFAULT 'active'
            CHECK (state IN ('active','paused','archived')),
          -- 스케줄. `NULL` 이면 **수동 실행만.**
          cron            TEXT,
          timezone        TEXT NOT NULL DEFAULT 'UTC',
          off_peak_preferred BOOLEAN NOT NULL DEFAULT FALSE,
          max_shift_seconds  INT NOT NULL DEFAULT 21600,
          initial_events  JSONB NOT NULL DEFAULT '[]',
          -- **실행 하나당** 상한. 배포는 사람이 안 보므로 특히 중요하다.
          budget_cents    INT CHECK (budget_cents IS NULL OR budget_cents > 0),
          consecutive_failures INT NOT NULL DEFAULT 0 CHECK (consecutive_failures >= 0),
          last_run_at     TIMESTAMPTZ,
          -- 스케줄러가 **인덱스로 탄다.** cron 을 매번 풀면 배포 수만큼
          -- 파싱한다.
          next_fire_at    TIMESTAMPTZ,
          paused_reason   TEXT NOT NULL DEFAULT '',
          created_by      TEXT NOT NULL,
          created_at      TIMESTAMPTZ NOT NULL,
          updated_at      TIMESTAMPTZ NOT NULL,
          archived_at     TIMESTAMPTZ,
          PRIMARY KEY (workspace_id, id),
          -- cron 이 있으면 타임존도 있어야 한다. 없으면 **9시간
          -- 어긋난 시각에** 돈다.
          CONSTRAINT deployments_schedule_complete
            CHECK (cron IS NULL OR timezone <> ''),
          -- 아카이브된 배포는 발화하지 않는다.
          CONSTRAINT deployments_archived_not_firing
            CHECK (state <> 'archived' OR next_fire_at IS NULL)
        )
    """)
    # **발화할 것을 찾는 핫 경로.** 부분 인덱스 — 멈춘 배포가 쌓여도
    # 스캔 비용이 늘지 않는다.
    op.execute("""
        CREATE INDEX idx_deployments_due ON deployments (next_fire_at)
        WHERE state = 'active' AND next_fire_at IS NOT NULL
    """)
    op.execute("""
        CREATE INDEX idx_deployments_ws ON deployments (workspace_id, created_at, id)
        WHERE archived_at IS NULL
    """)

    op.execute("""
        CREATE TABLE deployment_runs (
          id            TEXT NOT NULL,
          workspace_id  TEXT NOT NULL,
          deployment_id TEXT NOT NULL,
          session_id    TEXT,
          state         TEXT NOT NULL
            CHECK (state IN ('queued','running','succeeded','failed','skipped')),
          trigger       TEXT NOT NULL CHECK (trigger IN ('schedule','manual')),
          -- **이동 전** 시각. "원래 언제 돌았어야 하나"다.
          scheduled_for TIMESTAMPTZ NOT NULL,
          -- off-peak 로 얼마나 밀렸나. **절감 측정의 입력이다.**
          shifted_seconds INT NOT NULL DEFAULT 0 CHECK (shifted_seconds >= 0),
          started_at    TIMESTAMPTZ,
          ended_at      TIMESTAMPTZ,
          error         TEXT NOT NULL DEFAULT '',
          cost_cents    INT NOT NULL DEFAULT 0 CHECK (cost_cents >= 0),
          created_at    TIMESTAMPTZ NOT NULL,
          PRIMARY KEY (workspace_id, id),
          FOREIGN KEY (workspace_id, deployment_id)
            REFERENCES deployments (workspace_id, id)
        )
    """)
    # **같은 발화를 두 번 돌리지 않는다.** 스케줄러가 두 번 깨어나도
    # (리더 교체 중) 실행은 하나다.
    op.execute("""
        CREATE UNIQUE INDEX idx_runs_fire
        ON deployment_runs (workspace_id, deployment_id, scheduled_for)
        WHERE trigger = 'schedule'
    """)
    op.execute("""
        CREATE INDEX idx_runs_recent
        ON deployment_runs (workspace_id, deployment_id, created_at DESC)
    """)

    _apply_security()


def _apply_security() -> None:
    tables = ", ".join(TABLES)
    for table in TABLES:
        op.execute(f"""
            DO $$
            BEGIN
              EXECUTE 'ALTER TABLE {table} ENABLE ROW LEVEL SECURITY';
              EXECUTE 'DROP POLICY IF EXISTS {table}_ws ON {table}';
              EXECUTE 'CREATE POLICY {table}_ws ON {table} '
                      'USING (workspace_id = current_setting(''{SETTING}'', true))';
            EXCEPTION WHEN insufficient_privilege THEN
              RAISE WARNING '{table} 에 RLS 를 걸지 못했다';
            END $$
        """)
    op.execute(f"""
        DO $$
        BEGIN
          GRANT SELECT, INSERT, UPDATE, DELETE ON {tables} TO {APP_ROLE};
          -- **워커는 실행 결과만 쓴다.** 배포 설정을 고칠 이유가 없고,
          -- 고칠 수 있으면 세션이 자기 스케줄을 바꿀 수 있게 된다.
          GRANT SELECT ON deployments TO {WORKER_ROLE};
          GRANT SELECT, UPDATE ON deployment_runs TO {WORKER_ROLE};
        EXCEPTION
          WHEN undefined_object OR insufficient_privilege THEN
            RAISE WARNING '배포 테이블 권한을 걸지 못했다';
        END $$
    """)


def downgrade() -> None:
    op.execute("DROP TABLE IF EXISTS deployment_runs")
    op.execute("DROP TABLE IF EXISTS deployments")
