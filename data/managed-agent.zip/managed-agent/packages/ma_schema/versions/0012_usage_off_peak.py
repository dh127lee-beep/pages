"""0012 · usage_events.off_peak — off-peak 비율 (T-0504)

`plan/06-harness-and-model.md` §5 · `plan/04-api.md` §7.

> **적립 시점에 박아 둔다** — `list_cost_cents` 와 **같은 이유**다.
>
> off-peak 여부는 모델 카드의 `PeakWindow` 와 시각으로 계산할 수 있지만,
> 그 창은 **바뀐다** (DeepSeek 이 요금제를 고치면). 질의 시점에 다시
> 계산하면 과거 비율이 지금 창으로 재해석되고, "우리가 off-peak 로
> 옮겼더니 비용이 줄었다"는 측정이 **소급해서 틀려진다.**

`DEFAULT FALSE` 인 이유: 기존 행은 peak 였는지 알 수 없다. `NULL` 로
두면 집계가 "모르는 것"을 세야 하고, 그러면 비율의 분모가 흔들린다.
**과거를 peak 로 보수적으로 읽는다** — off-peak 비율을 낮게 잡는 쪽이
"이미 충분히 옮겼다"는 착각보다 낫다.

Revision ID: 0012
Revises: 0011
Create Date: 2026-10-16
"""

from __future__ import annotations

from alembic import op

revision = "0012"
down_revision = "0011"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # 파티션 테이블에 컬럼을 더하면 **모든 파티션에 전파된다.**
    op.execute(
        "ALTER TABLE usage_events ADD COLUMN IF NOT EXISTS off_peak BOOLEAN NOT NULL DEFAULT FALSE"
    )


def downgrade() -> None:
    op.execute("ALTER TABLE usage_events DROP COLUMN IF EXISTS off_peak")
