"""0001 · G1 테넌시 · G2 자산 · G2b 모델카드 · G3 환경 · G4 세션 · G5 이벤트/실행

`plan/05-database.md` §3.

**이 파일이 스키마의 유일한 출처다** (D2). 패키지 코드에 `CREATE TABLE`을 쓰지 않는다 —
`tools/check_architecture.py`가 검사한다.

Revision ID: 0001
Create Date: 2026-10-15
"""

from __future__ import annotations

from alembic import op

revision = "0001"
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    # ── G1 테넌시 ──────────────────────────────────────────
    op.execute("""
        CREATE TABLE workspaces (
          id                       TEXT PRIMARY KEY,
          name                     TEXT NOT NULL,
          slug                     TEXT NOT NULL UNIQUE,
          settings                 JSONB NOT NULL DEFAULT '{}',
          max_concurrent_sessions  INT  NOT NULL DEFAULT 10,
          daily_session_quota      INT  NOT NULL DEFAULT 200,
          warm_pool_size           INT  NOT NULL DEFAULT 0,
          created_at               TIMESTAMPTZ NOT NULL,
          archived_at              TIMESTAMPTZ,
          -- slug 는 k8s 네임스페이스 이름이 된다 (D7). 규칙 위반을 생성 시점에 막는다.
          CONSTRAINT workspaces_slug_dns
            CHECK (slug ~ '^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?$')
        )
    """)

    op.execute("""
        CREATE TABLE users (
          id           TEXT PRIMARY KEY,
          email        TEXT NOT NULL UNIQUE,
          name         TEXT NOT NULL,
          sso_subject  TEXT UNIQUE,
          created_at   TIMESTAMPTZ NOT NULL
        )
    """)

    op.execute("""
        CREATE TABLE workspace_members (
          workspace_id TEXT NOT NULL REFERENCES workspaces(id),
          user_id      TEXT NOT NULL REFERENCES users(id),
          role         TEXT NOT NULL
            CHECK (role IN ('viewer','operator','admin','owner')),
          created_at   TIMESTAMPTZ NOT NULL,
          PRIMARY KEY (workspace_id, user_id)
        )
    """)
    op.execute("CREATE INDEX idx_members_user ON workspace_members (user_id)")

    op.execute("""
        CREATE TABLE api_keys (
          id           TEXT PRIMARY KEY,
          workspace_id TEXT NOT NULL REFERENCES workspaces(id),
          name         TEXT NOT NULL,
          key_hash     BYTEA NOT NULL,
          key_prefix   TEXT NOT NULL,
          role         TEXT NOT NULL,
          created_by   TEXT NOT NULL REFERENCES users(id),
          last_used_at TIMESTAMPTZ,
          expires_at   TIMESTAMPTZ,
          revoked_at   TIMESTAMPTZ,
          created_at   TIMESTAMPTZ NOT NULL
        )
    """)
    op.execute("CREATE UNIQUE INDEX idx_api_keys_hash ON api_keys (key_hash)")

    # ── G2 에이전트 자산 — S2/S3/S4 표준형 ──────────────────
    for name in ("agents", "skills"):
        op.execute(f"""
            CREATE TABLE {name} (
              id           TEXT NOT NULL,
              workspace_id TEXT NOT NULL REFERENCES workspaces(id),
              document     JSONB NOT NULL,
              version      INT  NOT NULL,
              created_by   TEXT NOT NULL,
              created_at   TIMESTAMPTZ NOT NULL,
              updated_at   TIMESTAMPTZ NOT NULL,
              archived_at  TIMESTAMPTZ,
              PRIMARY KEY (workspace_id, id)
            )
        """)
        # 목록 조회 커서가 (workspace, created_at, id) 이므로 인덱스도 그 순서여야 한다
        op.execute(f"""
            CREATE INDEX idx_{name}_ws_created_id ON {name} (workspace_id, created_at, id)
            WHERE archived_at IS NULL
        """)
        singular = name[:-1]
        op.execute(f"""
            CREATE TABLE {singular}_versions (
              workspace_id TEXT NOT NULL,
              {singular}_id TEXT NOT NULL,
              version      INT  NOT NULL,
              document     JSONB NOT NULL,
              created_at   TIMESTAMPTZ NOT NULL,
              PRIMARY KEY (workspace_id, {singular}_id, version)
            )
        """)

    # ── G2b 모델 카드 — 모델을 설정으로 만든다 (D12) ─────────
    op.execute("""
        CREATE TABLE model_cards (
          id                    TEXT NOT NULL,
          workspace_id          TEXT NOT NULL REFERENCES workspaces(id),
          provider              TEXT NOT NULL
            CHECK (provider IN ('deepseek_official','openai_compatible','anthropic_compatible')),
          wire_model            TEXT NOT NULL,
          base_url              TEXT,
          credential_id         TEXT,
          max_input_tokens      BIGINT NOT NULL CHECK (max_input_tokens > 0),
          max_output_tokens     BIGINT NOT NULL CHECK (max_output_tokens > 0),
          supports_tools        BOOLEAN NOT NULL DEFAULT TRUE,
          supports_vision       BOOLEAN NOT NULL DEFAULT FALSE,
          supports_prompt_cache BOOLEAN NOT NULL DEFAULT TRUE,
          reasoning             JSONB,
          pricing               JSONB NOT NULL,
          off_peak_preferred    BOOLEAN NOT NULL DEFAULT FALSE,
          defaults              JSONB NOT NULL DEFAULT '{}',
          enabled               BOOLEAN NOT NULL DEFAULT TRUE,
          created_at            TIMESTAMPTZ NOT NULL,
          updated_at            TIMESTAMPTZ NOT NULL,
          archived_at           TIMESTAMPTZ,
          PRIMARY KEY (workspace_id, id)
        )
    """)
    op.execute("""
        CREATE INDEX idx_model_cards_enabled ON model_cards (workspace_id, created_at, id)
        WHERE enabled AND archived_at IS NULL
    """)

    # ── G3 환경 ────────────────────────────────────────────
    op.execute("""
        CREATE TABLE environments (
          id           TEXT NOT NULL,
          workspace_id TEXT NOT NULL REFERENCES workspaces(id),
          name         TEXT NOT NULL,
          document     JSONB NOT NULL,
          version      INT  NOT NULL,
          created_at   TIMESTAMPTZ NOT NULL,
          updated_at   TIMESTAMPTZ NOT NULL,
          archived_at  TIMESTAMPTZ,
          PRIMARY KEY (workspace_id, id)
        )
    """)
    op.execute("""
        CREATE INDEX idx_environments_ws_created_id
        ON environments (workspace_id, created_at, id) WHERE archived_at IS NULL
    """)
    op.execute("""
        CREATE TABLE environment_versions (
          workspace_id   TEXT NOT NULL,
          environment_id TEXT NOT NULL,
          version        INT  NOT NULL,
          name           TEXT NOT NULL,
          document       JSONB NOT NULL,
          created_at     TIMESTAMPTZ NOT NULL,
          PRIMARY KEY (workspace_id, environment_id, version)
        )
    """)

    # ── G4 세션 ────────────────────────────────────────────
    op.execute("""
        CREATE TABLE sessions (
          id                  TEXT NOT NULL,
          workspace_id        TEXT NOT NULL REFERENCES workspaces(id),
          agent_id            TEXT NOT NULL,
          agent_version       INT  NOT NULL,
          environment_id      TEXT NOT NULL,
          environment_version INT  NOT NULL,
          config_override     JSONB,
          status              TEXT NOT NULL
            CHECK (status IN ('idle','running','rescheduling','terminated')),
          stop_reason         TEXT,
          required_action     TEXT,
          revision            BIGINT NOT NULL DEFAULT 0,
          budget_cents        INT,
          spent_cents         INT  NOT NULL DEFAULT 0,
          usage               JSONB NOT NULL DEFAULT '{}',
          vault_ids           TEXT[] NOT NULL DEFAULT '{}',
          created_by          TEXT NOT NULL,
          created_at          TIMESTAMPTZ NOT NULL,
          updated_at          TIMESTAMPTZ NOT NULL,
          last_active_at      TIMESTAMPTZ,
          archived_at         TIMESTAMPTZ,
          deleted_at          TIMESTAMPTZ,
          PRIMARY KEY (workspace_id, id)
        )
    """)
    op.execute("""
        CREATE INDEX idx_sessions_ws_created ON sessions (workspace_id, created_at DESC, id)
    """)
    op.execute("""
        CREATE INDEX idx_sessions_ws_status ON sessions (workspace_id, status)
        WHERE status IN ('running','rescheduling')
    """)
    op.execute("""
        CREATE INDEX idx_sessions_ws_agent
        ON sessions (workspace_id, agent_id, created_at DESC)
    """)

    op.execute("""
        CREATE TABLE session_threads (
          workspace_id TEXT NOT NULL,
          session_id   TEXT NOT NULL,
          id           TEXT NOT NULL,
          status       TEXT NOT NULL DEFAULT 'idle',
          created_at   TIMESTAMPTZ NOT NULL,
          archived_at  TIMESTAMPTZ,
          PRIMARY KEY (workspace_id, session_id, id)
        )
    """)

    op.execute("""
        CREATE TABLE session_resources (
          id              TEXT NOT NULL,
          workspace_id    TEXT NOT NULL,
          session_id      TEXT NOT NULL,
          kind            TEXT NOT NULL
            CHECK (kind IN ('file','github_repository','memory_store','env')),
          spec            JSONB NOT NULL DEFAULT '{}',
          secret_ref      TEXT,
          memory_store_id TEXT,
          mount_path      TEXT,
          read_only       BOOLEAN NOT NULL DEFAULT FALSE,
          created_at      TIMESTAMPTZ NOT NULL,
          removed_at      TIMESTAMPTZ,
          PRIMARY KEY (workspace_id, id)
        )
    """)
    op.execute("""
        CREATE INDEX idx_session_resources ON session_resources (workspace_id, session_id)
        WHERE removed_at IS NULL
    """)

    # ── G5 이벤트 · 실행 — 이 설계의 핵심 ───────────────────
    # seq 는 promote 시점에 부여된다 (D4). 도착 순서가 아니다.
    op.execute("""
        CREATE TABLE session_events (
          workspace_id TEXT   NOT NULL,
          session_id   TEXT   NOT NULL,
          seq          BIGINT NOT NULL,
          id           TEXT   NOT NULL,
          thread_id    TEXT   NOT NULL,
          type         TEXT   NOT NULL,
          payload      JSONB  NOT NULL,
          generation   INT,
          created_at   TIMESTAMPTZ NOT NULL,
          PRIMARY KEY (workspace_id, session_id, seq)
        )
    """)
    # 중복 promote 방지. 크래시 복구가 이것에 의존한다.
    op.execute("""
        CREATE UNIQUE INDEX idx_events_event_id
        ON session_events (workspace_id, session_id, id)
    """)
    op.execute("""
        CREATE INDEX idx_events_thread
        ON session_events (workspace_id, session_id, thread_id, seq)
    """)
    op.execute("""
        CREATE INDEX idx_events_type
        ON session_events (workspace_id, session_id, type, seq)
    """)

    op.execute("""
        CREATE TABLE session_pending_events (
          workspace_id TEXT   NOT NULL,
          session_id   TEXT   NOT NULL,
          pending_seq  BIGSERIAL,
          id           TEXT   NOT NULL,
          thread_id    TEXT   NOT NULL,
          type         TEXT   NOT NULL,
          payload      JSONB  NOT NULL,
          enqueued_at  TIMESTAMPTZ NOT NULL,
          cancelled_at TIMESTAMPTZ,
          PRIMARY KEY (workspace_id, session_id, pending_seq)
        )
    """)
    op.execute("""
        CREATE UNIQUE INDEX idx_pending_event_id
        ON session_pending_events (workspace_id, session_id, id)
    """)
    op.execute("""
        CREATE INDEX idx_pending_drain
        ON session_pending_events (workspace_id, session_id, thread_id, pending_seq)
        WHERE cancelled_at IS NULL
    """)

    # 실행 권한 — outbox + lease + fence (D3)
    op.execute("""
        CREATE TABLE session_executions (
          id                     BIGSERIAL PRIMARY KEY,
          workspace_id           TEXT NOT NULL,
          session_id             TEXT NOT NULL,
          lane_id                TEXT NOT NULL,
          execution_id           TEXT NOT NULL,
          state                  TEXT NOT NULL
            CHECK (state IN ('queued','running','completed','failed','cancelled')),
          event_ids              TEXT[] NOT NULL,
          generation             INT  NOT NULL DEFAULT 0,
          attempt_id             UUID,
          attempt_count          INT  NOT NULL DEFAULT 0,
          lease_owner            TEXT,
          lease_expires_at       TIMESTAMPTZ,
          interrupt_requested_at TIMESTAMPTZ,
          deadline_at            TIMESTAMPTZ,
          error                  JSONB,
          created_at             TIMESTAMPTZ NOT NULL,
          settled_at             TIMESTAMPTZ
        )
    """)
    op.execute("""
        CREATE UNIQUE INDEX idx_exec_idem
        ON session_executions (workspace_id, session_id, execution_id)
    """)
    # 부분 인덱스 — 완료 행이 쌓여도 claim 은 상수 시간에 가깝다
    op.execute("""
        CREATE INDEX idx_exec_claimable ON session_executions (created_at)
        WHERE state = 'queued'
    """)
    op.execute("""
        CREATE INDEX idx_exec_reclaim ON session_executions (lease_expires_at)
        WHERE state = 'running'
    """)
    # split-brain 의 마지막 방어선 — 한 lane 에 running 은 하나뿐
    op.execute("""
        CREATE UNIQUE INDEX idx_exec_one_running
        ON session_executions (workspace_id, session_id, lane_id)
        WHERE state = 'running'
    """)

    op.execute("""
        CREATE TABLE session_streams (
          workspace_id TEXT NOT NULL,
          session_id   TEXT NOT NULL,
          stream_id    TEXT NOT NULL,
          thread_id    TEXT NOT NULL,
          kind         TEXT NOT NULL,
          partial      TEXT NOT NULL DEFAULT '',
          updated_at   TIMESTAMPTZ NOT NULL,
          PRIMARY KEY (workspace_id, session_id, stream_id)
        )
    """)


def downgrade() -> None:
    """작성은 하되 프로덕션에서 실행하지 않는다 (`docs/conventions/sql.md`)."""
    for t in (
        "session_streams",
        "session_executions",
        "session_pending_events",
        "session_events",
        "session_resources",
        "session_threads",
        "sessions",
        "environment_versions",
        "environments",
        "model_cards",
        "skill_versions",
        "skills",
        "agent_versions",
        "agents",
        "api_keys",
        "workspace_members",
        "users",
        "workspaces",
    ):
        op.execute(f"DROP TABLE IF EXISTS {t} CASCADE")
