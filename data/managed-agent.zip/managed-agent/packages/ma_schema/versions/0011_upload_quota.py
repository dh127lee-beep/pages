"""0011 · quota_counters 의 kind 확장 — 업로드 쿼터 (T-0502)

`plan/04-api.md` §7 · `ma_governance.quota`.

`0007_budgets` 가 `kind` 를 두 값으로 묶어 뒀다. 업로드 쿼터가 생기면서
그 CHECK 이 **새 kind 를 거부한다** — 애플리케이션은 멀쩡히 돌지만
INSERT 가 터진다.

> **CHECK 을 지우지 않고 다시 건다.** 지우고 끝내면 오타 난 kind 가
> 조용히 들어가고, 그러면 쿼터가 "없는 것"처럼 동작한다 — 상한이
> 사라진 것을 알아챌 방법이 없다.

Revision ID: 0011
Revises: 0010
Create Date: 2026-10-16
"""

from __future__ import annotations

from alembic import op

revision = "0011"
down_revision = "0010"
branch_labels = None
depends_on = None

#: `ma_governance.quota.QuotaKind` 와 **같아야 한다.**
#: 어긋나지 않는 것은 `tests/unit/test_quota_kinds.py` 가 본다.
KINDS = (
    "concurrent_sessions",
    "daily_sessions",
    "daily_upload_count",
    "daily_upload_bytes",
)

_OLD = "quota_counters_kind_check"


def upgrade() -> None:
    values = ", ".join(f"'{k}'" for k in KINDS)
    op.execute(f"ALTER TABLE quota_counters DROP CONSTRAINT IF EXISTS {_OLD}")
    op.execute(f"ALTER TABLE quota_counters ADD CONSTRAINT {_OLD} CHECK (kind IN ({values}))")
    # 바이트 카운터는 INT 를 넘는다 — 20GB 가 2.1e10 이고 INT 상한은 2.1e9.
    # **이것을 놓치면 상한에 닿기 전에 오버플로로 터진다.**
    op.execute("ALTER TABLE quota_counters ALTER COLUMN value TYPE BIGINT")


def downgrade() -> None:
    op.execute(f"ALTER TABLE quota_counters DROP CONSTRAINT IF EXISTS {_OLD}")
    op.execute(
        f"ALTER TABLE quota_counters ADD CONSTRAINT {_OLD} "
        "CHECK (kind IN ('concurrent_sessions','daily_sessions'))"
    )
    op.execute("ALTER TABLE quota_counters ALTER COLUMN value TYPE INT")
