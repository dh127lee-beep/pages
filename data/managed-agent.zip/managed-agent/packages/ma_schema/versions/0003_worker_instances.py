"""0003 · worker_instances — 워커가 자기 존재를 알린다

`plan/08-infrastructure.md` §3 · `task/M1-runtime-core/T-0207-worker-crash-recovery.md`.

**실행 권한은 여전히 `session_executions` 에 있다** (D3). 이 테이블은 권한이
아니라 **관측**이다 — "지금 몇 대가 살아 있고 누가 drain 중인가"를 운영자와
스케일러가 보기 위한 것이다.

권한과 섞지 않는 것이 중요하다. 워커 등록이 실패해도 claim 은 돌아야 하고,
이 테이블이 통째로 사라져도 세션은 멈추지 않는다.

Revision ID: 0003
Revises: 0002
Create Date: 2026-10-15
"""

from __future__ import annotations

from alembic import op

revision = "0003"
down_revision = "0002"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.execute("""
        CREATE TABLE worker_instances (
          id              TEXT PRIMARY KEY,
          hostname        TEXT NOT NULL,
          pid             INT  NOT NULL,
          state           TEXT NOT NULL
            CHECK (state IN ('starting','running','draining','stopped')),
          workspace_id    TEXT,
          started_at      TIMESTAMPTZ NOT NULL,
          heartbeat_at    TIMESTAMPTZ NOT NULL,
          stopped_at      TIMESTAMPTZ,
          claimed_total   BIGINT NOT NULL DEFAULT 0,
          version         TEXT
        )
    """)
    # "살아 있는 워커 수"를 세는 경로. 죽은 행이 쌓여도 상수 시간에 가깝다.
    op.execute("""
        CREATE INDEX idx_worker_alive ON worker_instances (heartbeat_at)
        WHERE state IN ('running', 'draining')
    """)


def downgrade() -> None:
    """작성은 하되 프로덕션에서 실행하지 않는다 (`docs/conventions/sql.md`)."""
    op.execute("DROP TABLE IF EXISTS worker_instances")
