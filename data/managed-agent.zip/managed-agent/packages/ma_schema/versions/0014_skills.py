"""0014 · skills 에 name·slug — 마운트 경로 (T-0602)

`plan/05-database.md` §3 G2 · `plan/01-product-concept.md` §4.

`skills`/`skill_versions` 는 **`0001_initial` 이 이미 만들었다** —
`agents` 와 같은 표준형(`document` JSONB + 버전)으로. 그때는 스킬이
무엇인지 정하지 않았고, 지금 두 가지가 더 필요해졌다:

| 컬럼 | 왜 컬럼이어야 하나 |
|---|---|
| `slug` | `/mnt/skills/<slug>` 가 된다 |
| `name` | 사람이 읽는 이름. `slug` 와 다를 수 있다 |

`slug` 가 겹치면 **두 스킬이 같은 곳에 마운트된다.** 유니크 인덱스가
막아야 하고, 그러려면 JSONB 안이 아니라 컬럼이어야 한다.

`description`·`files`·`source` 는 `document` 에 남긴다 — **인덱스를
걸 이유가 없는 것은 컬럼으로 올리지 않는다.**

`slug` 를 `NOT NULL` 로 만들지 **않는다.** 기존 행이 없지만(스킬 기능이
없었다) `NOT NULL` + `DEFAULT` 조합은 나중에 그 기본값이 진짜 값처럼
보이게 한다. 애플리케이션이 항상 채우고, 유니크 인덱스가 `NULL` 을
무시한다.

Revision ID: 0014
Revises: 0013
Create Date: 2026-10-16
"""

from __future__ import annotations

from alembic import op

revision = "0014"
down_revision = "0013"
branch_labels = None
depends_on = None


def upgrade() -> None:
    for table in ("skills", "skill_versions"):
        op.execute(f"ALTER TABLE {table} ADD COLUMN IF NOT EXISTS name TEXT")
        op.execute(f"ALTER TABLE {table} ADD COLUMN IF NOT EXISTS slug TEXT")

    # **`/mnt/skills/<slug>` 가 겹치면 두 스킬이 같은 곳에 마운트된다.**
    # `memory_stores` 와 같은 모양의 방어다.
    op.execute("""
        CREATE UNIQUE INDEX IF NOT EXISTS idx_skills_slug
        ON skills (workspace_id, slug)
        WHERE archived_at IS NULL AND slug IS NOT NULL
    """)

    # 워커가 스킬을 **읽는다** (세션 웜업이 마운트한다). `0008_rls` 가
    # 유도할 때 이 테이블들은 있었지만 워커 권한은 없었다 — 그때
    # 스킬을 아무도 안 썼기 때문이다.
    op.execute("""
        DO $$
        BEGIN
          -- **읽기만.** 스킬은 사람이 만드는 자산이고, 세션이 그것을
          -- 고칠 수 있으면 "부서 지식"이 턴마다 흔들린다.
          GRANT SELECT ON skills, skill_versions TO awp_worker;
        EXCEPTION
          WHEN undefined_object OR insufficient_privilege THEN
            RAISE WARNING '스킬 테이블 권한을 걸지 못했다';
        END $$
    """)


def downgrade() -> None:
    op.execute("DROP INDEX IF EXISTS idx_skills_slug")
    for table in ("skills", "skill_versions"):
        op.execute(f"ALTER TABLE {table} DROP COLUMN IF EXISTS slug")
        op.execute(f"ALTER TABLE {table} DROP COLUMN IF EXISTS name")
