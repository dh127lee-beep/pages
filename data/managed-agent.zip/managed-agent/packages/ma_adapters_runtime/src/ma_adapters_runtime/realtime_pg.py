"""PostgreSQL `LISTEN/NOTIFY` 기반 `RealtimePort`.

`plan/04-api.md` §5 · `IMPL-0011`.

**payload 에 id 와 seq 만 싣는다.** `NOTIFY` payload 는 8000바이트 한계가 있고,
이벤트 본문 하나가 그것을 넘는다. 구독자는 신호를 받고 **다시 읽는다** —
그러면 놓친 알림도 따라잡힌다.

채널 이름은 **워크스페이스 단위**다. 세션마다 채널을 만들면 `LISTEN` 수가
세션 수만큼 늘고, PostgreSQL 의 채널 수는 공짜가 아니다. 워크스페이스 채널
하나를 듣고 session_id 로 거른다.
"""

from __future__ import annotations

import json
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import TYPE_CHECKING

import anyio
import asyncpg
from ma_application.realtime import Wake

if TYPE_CHECKING:
    from collections.abc import Callable

#: 구독자 큐 상한. 넘으면 **가장 오래된 것을 버린다** — 신호는 데이터가 아니므로
#: 잃어도 다음 신호에서 따라잡는다. 끊는 것보다 낫다.
QUEUE_LIMIT = 64


def channel_for(workspace_id: str) -> str:
    """워크스페이스 단위 채널. PostgreSQL 식별자 63자 한계를 지킨다."""
    # 워크스페이스 id 는 ULID 접두사 형식이라 길이가 고정이다.
    return f"awp_{workspace_id}"[:63].lower()


class PgRealtime:
    """`RealtimePort` 구현.

    **전용 커넥션 하나**를 `LISTEN` 에 쓴다. 풀에서 빌리면 반환될 때 `LISTEN`
    이 끊긴다.
    """

    def __init__(self, dsn: str) -> None:
        self._dsn = dsn
        self._conn: asyncpg.Connection | None = None
        self._subs: dict[str, set[Callable[[Wake], None]]] = {}
        self._listening: set[str] = set()

    async def start(self) -> None:
        self._conn = await asyncpg.connect(self._dsn, statement_cache_size=0)

    async def stop(self) -> None:
        if self._conn is not None:
            await self._conn.close()
            self._conn = None
        self._listening.clear()
        self._subs.clear()

    async def publish(self, wake: Wake) -> None:
        if self._conn is None:  # pragma: no cover — 조립이 start 를 부른다
            raise RuntimeError("PgRealtime 이 시작되지 않았다")
        payload = json.dumps({"s": wake.session_id, "q": wake.up_to_seq}, separators=(",", ":"))
        # id 와 seq 만 싣는다 — 8000바이트 한계에 걸릴 수 없는 크기다.
        await self._conn.execute(
            "SELECT pg_notify($1, $2)", channel_for(wake.workspace_id), payload
        )

    @asynccontextmanager
    async def subscribe(
        self, workspace_id: str, session_id: str
    ) -> AsyncIterator[AsyncIterator[Wake]]:
        if self._conn is None:  # pragma: no cover
            raise RuntimeError("PgRealtime 이 시작되지 않았다")

        send, receive = anyio.create_memory_object_stream[Wake](QUEUE_LIMIT)
        channel = channel_for(workspace_id)

        def on_notify(
            conn: object, pid: int, chan: str, payload: str
        ) -> None:  # pragma: no cover — 콜백은 통합 테스트에서만 돈다
            try:
                body = json.loads(payload)
            except ValueError:
                return
            if body.get("s") != session_id:
                return
            wake = Wake(workspace_id=workspace_id, session_id=session_id, up_to_seq=body.get("q"))
            try:
                send.send_nowait(wake)
            except anyio.WouldBlock:
                # **버린다.** 신호는 데이터가 아니라 "다시 읽어라"이므로,
                # 하나를 잃어도 다음 신호에서 따라잡는다.
                pass

        await self._conn.add_listener(channel, on_notify)
        self._listening.add(channel)
        try:
            yield receive
        finally:
            await self._conn.remove_listener(channel, on_notify)
            send.close()
            receive.close()


class InProcessRealtime:
    """테스트·단일 프로세스용. **DB 를 쓰지 않는다.**

    `components.py` 가 이것으로 갈아끼울 수 있어야 E2E 가 가볍다.
    """

    def __init__(self) -> None:
        self._subs: dict[tuple[str, str], list[object]] = {}

    async def publish(self, wake: Wake) -> None:
        for stream in list(self._subs.get((wake.workspace_id, wake.session_id), [])):
            try:
                stream.send_nowait(wake)  # type: ignore[attr-defined]
            except anyio.WouldBlock:  # pragma: no cover
                pass

    @asynccontextmanager
    async def subscribe(
        self, workspace_id: str, session_id: str
    ) -> AsyncIterator[AsyncIterator[Wake]]:
        send, receive = anyio.create_memory_object_stream[Wake](QUEUE_LIMIT)
        key = (workspace_id, session_id)
        self._subs.setdefault(key, []).append(send)
        try:
            yield receive
        finally:
            self._subs[key].remove(send)
            send.close()
            receive.close()


__all__ = ["QUEUE_LIMIT", "InProcessRealtime", "PgRealtime", "channel_for"]
