"""웹훅 전송기 — 서명 · 재시도 · DLQ (T-0604).

`plan/04-api.md` §3.8 · `task/M5-extensions/T-0604-webhooks-notify.md`.

```
스케줄러 (30초)
  └ claim_due ──→ 각 전송
                    ├ 2xx          → delivered
                    ├ 4xx (410 제외) → **즉시 dead** (재시도해도 안 된다)
                    ├ 410 Gone     → 엔드포인트 비활성 + dead
                    └ 그 외        → retrying (지수 곡선) · 6회 뒤 dead
```

**4xx 를 재시도하지 않는 것이 요점이다.** 400·401·404 는 우리가 보낸
것이 틀렸거나 받는 쪽이 그 경로를 모르는 것이고, 한 시간 뒤에도 같다 —
재시도는 **일시적 장애**를 위한 것이다.

`410 Gone` 만 다르게 다룬다: 수신 측이 "여기 이제 없다"고 말한 것이므로
**엔드포인트를 끈다.** 안 끄면 죽은 주소로 모든 이벤트가 계속 나간다.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from ma_domain.webhooks import (
    MAX_ATTEMPTS,
    MAX_PAYLOAD_BYTES,
    SIGNATURE_HEADER,
    DeliveryState,
    envelope,
    retry_delay,
    serialize,
    sign,
)

if TYPE_CHECKING:
    import httpx
    from ma_domain.webhooks import WebhookDelivery
    from ma_store.webhooks import WebhookStore

_log = logging.getLogger("ma_adapters_runtime.webhook")

#: 한 번 시도의 상한. 넘으면 실패로 보고 재시도한다.
#:
#: 10초인 이유: 수신 측이 웹훅을 **받아서 큐에 넣는** 것 이상을 하면
#: 안 된다 (그것이 웹훅 계약이다). 그보다 오래 걸리면 그쪽 설계가
#: 틀렸고, 우리가 기다려 줄 이유가 없다.
TIMEOUT_SECONDS = 10.0

#: `410 Gone` — 수신 측이 "여기 이제 없다"고 말했다.
GONE = 410


@dataclass(frozen=True, slots=True)
class Attempt:
    """한 번 보낸 결과. **상태 전이를 호출자가 정한다.**"""

    ok: bool
    status: int | None
    error: str = ""
    #: 엔드포인트를 꺼야 하는가 (`410 Gone`).
    disable_endpoint: bool = False


@dataclass(frozen=True, slots=True)
class DrainReport:
    sent: int = 0
    retried: int = 0
    dead: int = 0
    disabled: int = 0

    @property
    def total(self) -> int:
        return self.sent + self.retried + self.dead


@dataclass
class WebhookSender:
    """전송 큐를 비운다. **스케줄러가 주기적으로 부른다.**

    `client` 를 주입받는다 — 조립이 프록시·타임아웃을 정한다. 웹훅은
    **밖으로 나가므로** egress 프록시를 지나야 하고, 그 설정이 여기
    박히면 두 벌이 된다.
    """

    store: WebhookStore
    client: httpx.AsyncClient
    now: Any
    #: 한 번에 처리할 수. 넘으면 다음 주기에.
    batch: int = 50
    max_attempts: int = MAX_ATTEMPTS

    async def drain(self) -> DrainReport:
        due = await self.store.claim_due(self.now(), limit=self.batch)
        sent = retried = dead = disabled = 0

        for delivery in due:
            result = await self._send(delivery)
            if result.disable_endpoint:
                await self.store.disable_endpoint(
                    delivery.workspace_id, delivery.endpoint_id, self.now()
                )
                disabled += 1
            state = await self._settle(delivery, result)
            if state is DeliveryState.DELIVERED:
                sent += 1
            elif state is DeliveryState.DEAD:
                dead += 1
            else:
                retried += 1

        return DrainReport(sent=sent, retried=retried, dead=dead, disabled=disabled)

    async def _send(self, delivery: WebhookDelivery) -> Attempt:
        endpoint = await self.store.find_endpoint(delivery.workspace_id, delivery.endpoint_id)
        if endpoint is None or not endpoint.is_active:
            # 엔드포인트가 사라졌다. **재시도하지 않는다.**
            return Attempt(ok=False, status=None, error="엔드포인트가 없거나 꺼졌다")

        secret = await self.store.secret_for(delivery.workspace_id, delivery.endpoint_id)
        if secret is None:  # pragma: no cover — 엔드포인트가 있으면 시크릿도 있다
            return Attempt(ok=False, status=None, error="시크릿을 읽지 못했다")

        at = self.now()
        body = serialize(
            envelope(
                delivery.event,
                delivery_id=delivery.id,
                workspace_id=delivery.workspace_id,
                at=delivery.created_at,
                data=dict(delivery.payload),
            )
        )
        if len(body.encode("utf-8")) > MAX_PAYLOAD_BYTES:
            # **잘라서 보내지 않는다.** 잘린 JSON 은 수신 측에서
            # 파싱 오류가 되고, 그것은 "웹훅이 깨졌다"로 보인다.
            return Attempt(ok=False, status=None, error="본문이 상한을 넘는다")

        try:
            response = await self.client.post(
                endpoint.url,
                content=body.encode("utf-8"),
                headers={
                    "content-type": "application/json",
                    SIGNATURE_HEADER: sign(secret, body, at),
                    # 수신 측이 **멱등 처리**할 수 있게 한다.
                    "awp-delivery-id": delivery.id,
                    "awp-event": delivery.event.value,
                },
                timeout=TIMEOUT_SECONDS,
            )
        except Exception as exc:
            # 네트워크 오류는 **일시적일 수 있다** — 재시도한다.
            return Attempt(ok=False, status=None, error=f"{type(exc).__name__}: {exc}")

        if 200 <= response.status_code < 300:
            return Attempt(ok=True, status=response.status_code)
        if response.status_code == GONE:
            return Attempt(
                ok=False,
                status=GONE,
                error="410 Gone — 엔드포인트를 끈다",
                disable_endpoint=True,
            )
        return Attempt(ok=False, status=response.status_code, error=f"HTTP {response.status_code}")

    async def _settle(self, delivery: WebhookDelivery, result: Attempt) -> DeliveryState:
        from ma_store.webhooks import RecordAttempt

        attempts = delivery.attempts + 1
        at = self.now()

        if result.ok:
            state: DeliveryState = DeliveryState.DELIVERED
            nxt = None
        elif self._is_permanent(result) or attempts >= self.max_attempts:
            state = DeliveryState.DEAD
            nxt = None
            _log.warning(
                "웹훅 전송 포기 delivery=%s endpoint=%s attempts=%d error=%s",
                delivery.id,
                delivery.endpoint_id,
                attempts,
                result.error,
            )
        else:
            state = DeliveryState.RETRYING
            nxt = at + retry_delay(attempts)

        await self.store.record_attempt(
            RecordAttempt(
                workspace_id=delivery.workspace_id,
                delivery_id=delivery.id,
                state=state,
                attempts=attempts,
                now=at,
                next_attempt_at=nxt,
                last_error=result.error,
                last_status=result.status,
            )
        )
        return state

    @staticmethod
    def _is_permanent(result: Attempt) -> bool:
        """**4xx 는 재시도해도 안 된다.**

        400·401·404 는 우리가 보낸 것이 틀렸거나 받는 쪽이 그 경로를
        모르는 것이고, 한 시간 뒤에도 같다. 재시도는 **일시적 장애**를
        위한 것이다.

        `408 Request Timeout` 과 `429 Too Many Requests` 는 예외다 —
        이름 그대로 일시적이다.
        """
        status = result.status
        if status is None:
            return False
        if status in (408, 429):
            return False
        return 400 <= status < 500


__all__ = ["GONE", "TIMEOUT_SECONDS", "Attempt", "DrainReport", "WebhookSender"]
