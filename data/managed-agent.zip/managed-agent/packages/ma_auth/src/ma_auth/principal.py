"""주체 해석 — 인증 직후 **한 번만** 워크스페이스를 정한다.

`plan/04-api.md` §2.1 · `plan/03-layers.md` §3.

```
1. x-api-key                      → API 키 (워크스페이스에 고정)
2. Authorization: Bearer <token>  → 서비스 토큰 / 워커 세션 토큰
3. 쿠키 세션 + x-active-workspace  → Console 사용자
4. 없음                            → 401
```

**`x-active-workspace` 는 쿠키 사용자에게만 의미가 있다.** API 키는 발급 시점에
워크스페이스가 정해지므로 이 헤더를 **무시한다** — 덮어쓰기를 허용하면 키 탈취
시 횡적 이동이 가능해진다.

워크스페이스가 정해지면 그 뒤로는 `workspace_id` 가 요청 컨텍스트에 **고정**되고,
애플리케이션 레이어는 그것을 파티션 키로만 쓴다.
"""

from __future__ import annotations

import hashlib
import hmac
from dataclasses import dataclass
from datetime import datetime
from typing import TYPE_CHECKING, Protocol

from ma_domain.ids import ApiKeyId
from ma_domain.workspaces import ApiKey, Role

if TYPE_CHECKING:
    from ma_domain.ids import WorkspaceId

#: API 키 평문의 접두사. 로그에 남는 부분이다.
KEY_PREFIX_LEN = 12


class PrincipalKind:
    API_KEY = "api_key"
    SERVICE = "service"
    USER = "user"


@dataclass(frozen=True, slots=True)
class Principal:
    """인증된 주체. **`workspace_id` 가 여기서 고정된다.**"""

    kind: str
    id: str
    workspace_id: WorkspaceId
    role: Role
    #: 로그·감사에 남길 이름. 비밀을 담지 않는다.
    label: str = ""


class ApiKeyLookup(Protocol):
    """`ApiKeyStore` 중 인증이 쓰는 **두 메서드만**.

    Store 전체를 요구하면 인증이 목록·폐기까지 할 수 있게 된다 — 필요 없는
    권한이다 (`plan/03-layers.md` §4 "좁은 Port").
    """

    async def find_by_hash(self, key_hash: bytes) -> ApiKey | None: ...
    async def touch_used(self, key_id: ApiKeyId, now: datetime) -> None: ...


def hash_key(plaintext: str, *, pepper: bytes = b"") -> bytes:
    """API 키 평문 → 저장되는 해시.

    **argon2 가 아니라 HMAC-SHA256 이다.** 이유는 이것이 비밀번호가 아니기
    때문이다 — API 키는 우리가 발급한 128비트 난수라 사전 공격 대상이 아니고,
    인증 경로에서 **모든 요청마다** 계산된다. argon2 를 쓰면 요청당 수십~수백
    ms 가 붙는다.

    `pepper` 는 DB 가 유출돼도 해시만으로 키를 만들 수 없게 한다 — 환경에서
    주입되고 DB 에 저장되지 않는다.
    """
    return hmac.new(pepper, plaintext.encode(), hashlib.sha256).digest()


def key_prefix(plaintext: str) -> str:
    """로그·목록에 보여줄 앞부분. 나머지는 복원 불가."""
    return plaintext[:KEY_PREFIX_LEN]


@dataclass
class ApiKeyAuthenticator:
    """`x-api-key` → `Principal`. 실패는 `None` — **이유를 구분하지 않는다**.

    "키가 없다"와 "폐기됐다"와 "만료됐다"를 구분해 주면 공격자가 유효한 키의
    존재를 확인할 수 있다.
    """

    keys: ApiKeyLookup
    pepper: bytes = b""

    async def authenticate(self, plaintext: str, now: datetime) -> Principal | None:
        if not plaintext:
            return None
        found = await self.keys.find_by_hash(hash_key(plaintext, pepper=self.pepper))
        if found is None:
            return None
        if not found.is_active(now):
            return None
        await self.keys.touch_used(found.id, now)
        return Principal(
            kind=PrincipalKind.API_KEY,
            id=found.id,
            workspace_id=found.workspace_id,
            role=found.role,
            label=found.name,
        )


__all__ = [
    "KEY_PREFIX_LEN",
    "ApiKeyAuthenticator",
    "ApiKeyLookup",
    "Principal",
    "PrincipalKind",
    "hash_key",
    "key_prefix",
]
