"""`run_code` — Wasm 안의 CPython. **호출마다 새 인스턴스.**

`plan/07-sandbox.md` §3.4 · `task/M2-sandbox-tools/T-0303-tier-wasm.md`.

`bash` 를 못 주더라도 "코드를 돌려 데이터를 처리"는 필요하다. 그래서 티어 W 는
`run_code` 를 CPython WASI 빌드로 제공한다.

**호출마다 새 인스턴스인 이유**: 상태를 누적하면 한 번의 실행이 다음 것을
오염시킨다. 모델은 그것을 모르고 "아까 정의한 변수"를 쓰려 하며, 그 변수가
다른 세션의 것일 수도 있다.

> **에셋이 없으면 정직하게 실패한다.** `python.wasm` 은 ~20MB 라 저장소에
> 넣지 않고 `tools/fetch_wasm_assets.py` 로 가져온다. 없는 채로 `run_code` 를
> 부르면 "준비되지 않았다"를 돌려주지, 조용히 다른 것을 실행하지 않는다.

게스트가 보는 것:

```
/workspace        세션 워크스페이스        rw
/scratch          이번 호출의 스크립트     rw, 호출이 끝나면 사라진다
/usr/local/lib    CPython stdlib           ro 로 쓰고 싶지만 p1 은 못 건다
```
"""

from __future__ import annotations

import os
import tempfile
import threading
import time
from dataclasses import dataclass, field
from enum import StrEnum
from pathlib import Path
from typing import TYPE_CHECKING
from weakref import WeakKeyDictionary

import wasmtime

from ma_sandbox_wasm.store import GUEST_WORKSPACE, SessionStore, epoch_ticker

if TYPE_CHECKING:
    from ma_sandbox_wasm.limits import Limits

#: 에셋이 사는 곳. `tools/fetch_wasm_assets.py` 가 여기에 내려놓는다.
ASSET_DIR = Path(__file__).parent / "assets"
CPYTHON_WASM = ASSET_DIR / "python.wasm"
#: 미리 컴파일한 캐시. **없어도 되고 깨져도 된다** — 그때는 다시 컴파일한다.
CPYTHON_CWASM = ASSET_DIR / "python.cwasm"
#: 게스트의 `/usr/local/lib` 이 될 디렉터리. `python.wasm` 과 **분리해 둔다** —
#: `assets/` 를 통째로 preopen 하면 인터프리터 바이너리까지 게스트에 보인다.
PYLIB_DIR = ASSET_DIR / "pylib"
STDLIB_ZIP = PYLIB_DIR / "python312.zip"

#: 게스트 경로.
GUEST_PREFIX = "/usr/local"
GUEST_LIB = "/usr/local/lib"
GUEST_SCRATCH = "/scratch"

#: 인터프리터가 **자기 자신에게** 거는 환경변수. 세션 환경과 섞지 않는다
#: (`SessionStore.wasi_config` 의 `runtime_env` 참고).
RUNTIME_ENV = {
    "PYTHONHOME": GUEST_PREFIX,
    # `.pyc` 를 쓰면 stdlib 디렉터리가 호출마다 더러워진다.
    "PYTHONDONTWRITEBYTECODE": "1",
    # 출력이 파일로 가면 기본이 블록 버퍼라, trap 으로 끝날 때 다 날아간다.
    "PYTHONUNBUFFERED": "1",
}

#: 모델에게 돌려주는 출력 상한. 툴 상한(100K)보다 작게 둔다 — 하네스가
#: 한 번 더 자르지만, 여기서 먼저 자르면 파일 I/O 가 줄어든다.
MAX_CAPTURE_BYTES = 256 * 1024


class RunStatus(StrEnum):
    OK = "ok"
    #: 코드가 0이 아닌 종료 코드로 끝났다. **툴 실패이지 인프라 오류가 아니다.**
    FAILED = "failed"
    #: fuel 또는 epoch deadline. 상한에 걸렸다.
    TIMEOUT = "timeout"
    #: 선형 메모리 상한.
    OUT_OF_MEMORY = "out_of_memory"
    #: 런타임이 준비되지 않았다. **인프라 오류다.**
    UNAVAILABLE = "unavailable"


@dataclass(frozen=True, slots=True)
class ExecResult:
    status: RunStatus
    stdout: str = ""
    stderr: str = ""
    exit_code: int | None = None
    duration_ms: float = 0.0
    #: 소비한 fuel. `IMPL-0016` 의 "fuel ↔ CPU 시간" 대응을 재는 데 쓴다.
    fuel_used: int | None = None

    @property
    def ok(self) -> bool:
        return self.status is RunStatus.OK

    @property
    def is_infrastructure_error(self) -> bool:
        """**인프라 오류를 "작업 실패"로 모델에 보고하면 안 된다** (§4.2)."""
        return self.status is RunStatus.UNAVAILABLE


def assets_ready() -> bool:
    """CPython WASI 에셋이 있는가. **없으면 `run_code` 를 등록하지 않는다.**"""
    return CPYTHON_WASM.is_file() and STDLIB_ZIP.is_file()


def missing_assets() -> tuple[str, ...]:
    return tuple(str(p) for p in (CPYTHON_WASM, STDLIB_ZIP) if not p.is_file())


_MODULES: WeakKeyDictionary[wasmtime.Engine, wasmtime.Module] = WeakKeyDictionary()
_MODULE_LOCK = threading.Lock()


def load_module(engine: wasmtime.Engine) -> wasmtime.Module:
    """컴파일된 CPython 모듈. **캐시가 있으면 200배 빠르다.**

    두 겹으로 캐시한다. **엔진별 메모리 캐시**가 먼저고, 없으면 디스크의
    미리 컴파일한 `.cwasm` 을 읽고, 그것도 없으면 컴파일한다.

    측정(`IMPL-0016`): `from_file` 314ms · `deserialize_file` 1.4ms ·
    메모리 캐시 적중 ~0ms. 20MB 짜리 모듈을 세션마다 컴파일하면
    프로비저닝 예산(50ms)을 혼자 넘긴다.

    캐시는 **신뢰 경계 안**이다 — 우리가 방금 직렬화한 것이고, 같은 호스트의
    같은 Wasmtime 버전만 읽는다. 버전이 바뀌면 `deserialize_file` 이 실패하고,
    그때는 조용히 다시 컴파일한다.
    """
    with _MODULE_LOCK:
        cached = _MODULES.get(engine)
        if cached is not None:
            return cached

        module: wasmtime.Module | None = None
        if CPYTHON_CWASM.is_file():
            try:
                module = wasmtime.Module.deserialize_file(engine, str(CPYTHON_CWASM))
            except Exception:
                module = None
        if module is None:
            module = wasmtime.Module.from_file(engine, str(CPYTHON_WASM))
            _write_cache(module)

        _MODULES[engine] = module
        return module


def _write_cache(module: wasmtime.Module) -> None:
    """원자적으로 쓴다. 워커 여러 개가 동시에 쓰면 **반쪽 파일**이 남는다."""
    try:
        blob = module.serialize()
        with tempfile.NamedTemporaryFile(
            dir=str(ASSET_DIR), suffix=".cwasm.tmp", delete=False
        ) as fh:
            fh.write(blob)
            tmp = fh.name
        os.replace(tmp, CPYTHON_CWASM)
    except OSError:  # pragma: no cover — 읽기 전용 배포본이면 캐시 없이 간다
        pass


@dataclass
class WasmRunner:
    """세션당 하나. `run_python` 호출마다 새 인스턴스를 만든다."""

    store: SessionStore
    _module: wasmtime.Module | None = field(default=None, repr=False)

    def module(self) -> wasmtime.Module:
        if self._module is None:
            self._module = load_module(self.store.engine)
        return self._module

    def warm(self) -> None:
        """모듈과 Linker 를 미리 올린다. **세션 시작 때 한 번** 부른다.

        부르지 않아도 동작은 같다 — 첫 `run_code` 가 느려질 뿐이다.
        """
        if assets_ready():
            self.module()
            self.store.linker()

    def run_python(self, code: str, *, limits: Limits | None = None) -> ExecResult:
        """코드를 게스트 CPython 으로 돌린다.

        코드는 **파일로 전달한다.** argv 로 넘기면 길이 제한과 인코딩 문제가
        생기고, stdin 으로 넘기면 게스트가 stdin 을 다른 용도로 쓸 때 섞인다.
        """
        if not assets_ready():
            return ExecResult(
                status=RunStatus.UNAVAILABLE,
                stderr=(
                    "CPython WASI 에셋이 없다: "
                    + ", ".join(missing_assets())
                    + " — `uv run python tools/fetch_wasm_assets.py` 로 가져온다"
                ),
            )

        effective = limits or self.store.limits
        started = time.monotonic()

        with tempfile.TemporaryDirectory() as tmp:
            # 스크립트를 **워크스페이스가 아닌 곳**에 둔다. 워크스페이스에
            # 쓰면 모델이 자기 코드 파일을 `glob` 결과에서 보게 되고,
            # 세션 산출물과 섞인다.
            scratch = Path(tmp)
            (scratch / "main.py").write_text(code, encoding="utf-8")
            # 빈 stdin. 주지 않으면 `input()` 한 줄에 게스트가 매달린다.
            (scratch / "stdin").write_bytes(b"")
            out_path = scratch / "stdout"
            err_path = scratch / "stderr"

            wasi = self.store.wasi_config(
                argv=["python", f"{GUEST_SCRATCH}/main.py"],
                runtime_env=RUNTIME_ENV,
                stdin_path=scratch / "stdin",
                stdout_path=out_path,
                stderr_path=err_path,
            )
            wasi.preopen_dir(str(scratch), GUEST_SCRATCH)
            wasi.preopen_dir(str(PYLIB_DIR), GUEST_LIB)

            wstore = self.store.new_store(wasi)
            wstore.set_fuel(effective.fuel)
            wstore.set_epoch_deadline(effective.epoch_ticks)
            status = RunStatus.OK
            exit_code: int | None = 0

            try:
                module = self.module()
            except (OSError, wasmtime.WasmtimeError) as exc:
                return ExecResult(
                    status=RunStatus.UNAVAILABLE,
                    stderr=f"Wasm 모듈을 읽지 못했다: {exc}",
                    duration_ms=(time.monotonic() - started) * 1000,
                )

            try:
                with epoch_ticker(self.store.engine):
                    instance = self.store.linker().instantiate(wstore, module)
                    start = instance.exports(wstore)["_start"]
                    start(wstore)  # type: ignore[operator]
            except wasmtime.ExitTrap as exc:
                exit_code = exc.code
                status = RunStatus.OK if exc.code == 0 else RunStatus.FAILED
            except wasmtime.Trap as exc:
                status, exit_code = _classify_trap(exc)
            except wasmtime.WasmtimeError as exc:
                # 상한에 걸린 인스턴스화도 여기로 온다 (메모리 상한 등).
                status, exit_code = _classify_trap(exc)

            fuel_left = _fuel_left(wstore)
            stderr = _read_capped(err_path)
            if status is RunStatus.FAILED and "MemoryError" in stderr:
                # **메모리 상한은 보통 trap 으로 오지 않는다.** `Store` 가
                # `memory.grow` 를 거부하면 게스트 malloc 이 실패하고,
                # CPython 은 그것을 평범한 `MemoryError` 로 올린 뒤 종료코드
                # 1 로 끝난다. 호스트에서 보면 그냥 FAILED 다.
                #
                # 구분해 주는 쪽이 낫다 — 모델에게 "나눠서 처리하라"고
                # 말해 줄 수 있는 것은 이 경우뿐이다.
                status = RunStatus.OUT_OF_MEMORY
            return ExecResult(
                status=status,
                stdout=_read_capped(out_path),
                stderr=stderr,
                exit_code=exit_code,
                duration_ms=(time.monotonic() - started) * 1000,
                fuel_used=(effective.fuel - fuel_left) if fuel_left is not None else None,
            )


def _classify_trap(exc: BaseException) -> tuple[RunStatus, int | None]:
    """trap 메시지를 상태로. **모르면 FAILED** — 인프라 오류로 올리지 않는다.

    모르는 trap 을 `UNAVAILABLE` 로 보고하면 모델의 코드 버그가
    `session.error` 가 되고, 운영자가 없는 장애를 쫓는다.
    """
    text = str(exc).lower()
    if "fuel" in text or "epoch" in text or "interrupt" in text:
        return RunStatus.TIMEOUT, None
    if "memory" in text and ("grow" in text or "limit" in text or "minimum" in text):
        return RunStatus.OUT_OF_MEMORY, None
    return RunStatus.FAILED, None


def _fuel_left(store: wasmtime.Store) -> int | None:
    try:
        return int(store.get_fuel())
    except Exception:
        return 0


def _read_capped(path: Path) -> str:
    """상한까지만 읽는다. 게스트가 무한히 쓰면 **호스트 메모리가 터진다**."""
    try:
        with path.open("rb") as fh:
            raw = fh.read(MAX_CAPTURE_BYTES + 1)
    except OSError:  # pragma: no cover — tempdir 안이라 거의 없다
        return ""
    text = raw[:MAX_CAPTURE_BYTES].decode("utf-8", "replace")
    if len(raw) > MAX_CAPTURE_BYTES:
        text += f"\n…출력이 {MAX_CAPTURE_BYTES:,}바이트를 넘어 잘렸다"
    return text


def guest_workspace_hint() -> str:
    """게스트에서 워크스페이스가 보이는 경로. 프롬프트에 넣는다."""
    return GUEST_WORKSPACE


__all__ = [
    "ASSET_DIR",
    "CPYTHON_CWASM",
    "CPYTHON_WASM",
    "GUEST_LIB",
    "GUEST_SCRATCH",
    "MAX_CAPTURE_BYTES",
    "PYLIB_DIR",
    "RUNTIME_ENV",
    "STDLIB_ZIP",
    "ExecResult",
    "RunStatus",
    "WasmRunner",
    "assets_ready",
    "guest_workspace_hint",
    "load_module",
    "missing_assets",
]
