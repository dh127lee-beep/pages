"""티어 W provider — **enforcement 를 구성상 `enforced` 로 보고한다**.

`plan/07-sandbox.md` §3 · `plan/02-architecture.md` §10.

티어 W 가 `enforced` 인 근거는 **설정이 아니라 구성**이다.

| 성질 | 왜 구성상 참인가 |
|---|---|
| 네트워크 불가 | `wasi:sockets` 를 제공하지 않는다 — **import 가 존재하지 않는다** |
| 파일 경계 | preopen 한 디렉터리만 열린다. 경로를 알아도 못 연다 |
| 환경변수 격리 | 화이트리스트만 전달. `inherit_env` 를 쓰지 않는다 |
| CPU·메모리 상한 | 엔진 수준 fuel·epoch·memory limit |

운영자가 설정을 틀려도 이 성질들이 깨지지 않는다. 그것이 티어 P 와 다른
점이다 — 티어 P 는 bwrap 이 있어야 하고, 커널이 Landlock 을 지원해야 하고,
그 둘이 노드마다 다르다.

**`supports_shell` 은 항상 False 다.** ambient authority 가 0 이라 셸이
없다. 셸이 필요한 에이전트는 조립 시점에 거부된다 (`SandboxOrchestrator`).
"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass, field

from ma_domain.environments import Enforcement, SandboxTier
from ma_sandbox.ports import (
    ConfinedArgv,
    ProviderCapabilities,
    RunnerFailureRule,
    SandboxPolicy,
)

from ma_sandbox_wasm.runner import assets_ready, missing_assets

#: 이 백엔드가 거부할 때 내는 stderr 방언. **백엔드별이다** — bwrap 의
#: `EROFS` 문구를 여기 섞으면 Wasmtime 이 내지 않는 거부를 주장하게 된다.
WASM_DENIAL_SIGNATURES = (
    "failed to find a pre-opened file descriptor",
    "capabilities insufficient",
    "not capable",
    "Operation not permitted",
    "unknown import",
)

WASM_RUNNER_FAILURES = (
    RunnerFailureRule(
        fatal_signatures=(
            "failed to parse WebAssembly module",
            "failed to compile",
            "incompatible import type",
        ),
        informational_lines=(),
    ),
)


@dataclass
class WasmSandboxProvider:
    """`SandboxProvider` 구현.

    **`confine()` 이 argv 를 래핑하지 않는다.** 티어 W 에는 러너가 없다 —
    프로세스를 띄우는 대신 Wasm 인스턴스 안에서 돈다. 그래서 argv 를 그대로
    돌려주되 `enforcement` 로 "이 경로는 Wasm 이 맡는다"를 말한다.

    티어 P 와 모양이 다른 것이 아니라 **역할이 다르다**: 티어 P 의
    `confine()` 은 "이렇게 실행하라"이고, 티어 W 는 "이것은 Wasm 안에서
    돈다"이다. argv 를 실제로 쓰는 것은 `WasmRunner` 다.
    """

    name: str = "wasm"
    _notes: tuple[str, ...] = field(default_factory=tuple)

    def confine(self, argv: Sequence[str], policy: SandboxPolicy) -> ConfinedArgv:
        return ConfinedArgv(
            argv=tuple(argv),
            enforcement=Enforcement.ENFORCED,
            denial_signatures=WASM_DENIAL_SIGNATURES,
            runner_failure_rules=WASM_RUNNER_FAILURES,
            caveats=(f"워크스페이스는 게스트에서 /workspace 다 (정책: {policy.mode.value})",),
        )

    def probe(self) -> ProviderCapabilities:
        """**구성상 참인 것만 `enforced` 라고 말한다.**

        `run_code` 에셋이 없으면 파일·네트워크 격리는 여전히 `enforced` 지만
        (Wasm 을 안 돌리면 아무 일도 안 일어난다), 그 사실을 `notes` 에
        적는다 — 운영자가 "왜 run_code 가 없지"를 추적할 수 있어야 한다.
        """
        notes: list[str] = list(self._notes)
        if not assets_ready():
            notes.append("run_code 비활성 — CPython WASI 에셋 없음: " + ", ".join(missing_assets()))

        return ProviderCapabilities(
            provider=self.name,
            tier=SandboxTier.WASM,
            # 소켓 import 가 **존재하지 않으므로** 구성상 강제된다.
            filesystem=Enforcement.ENFORCED,
            network=Enforcement.ENFORCED,
            # ambient authority 0 — 셸이 없다.
            supports_shell=False,
            notes=tuple(notes),
        )

    def tools_available(self) -> tuple[str, ...]:
        """이 티어에서 등록할 수 있는 툴. **`bash` 가 없다.**"""
        base = ("read", "write", "edit", "glob", "grep", "web_fetch", "web_search")
        return (*base, "run_code") if assets_ready() else base


__all__ = [
    "WASM_DENIAL_SIGNATURES",
    "WASM_RUNNER_FAILURES",
    "WasmSandboxProvider",
]
