"""세션당 Wasmtime Store — **ambient authority 0** (D13).

`plan/07-sandbox.md` §3.1 §3.3.

Wasm 모듈의 기본 상태는 **아무 권한도 없음**이다. 파일시스템을 건드릴 수
없고, 소켓을 열 수 없고, 환경변수를 읽을 수 없다. 명시적으로 제공된 import
로만 바깥과 통신한다.

그래서 이 파일이 하는 일은 **무엇을 주는가**를 정하는 것이다.

```
preopen /workspace          rw
preopen /mnt/memory/<name>  rw 또는 ro
env                         화이트리스트만 (자격증명 없음)
wasi:sockets                **주지 않는다**
```

소켓을 주지 않는 것이 핵심이다 — 네트워크 우회 경로가 **코드에 존재하지
않는다**. 운영 설정에 의존하지 않는 유일한 강제다.

> **WASI 버전에 대한 정정**: `plan/07` §3 은 WASI preview 2 를 전제했는데,
> `wasmtime-py` 49 에는 Component Model / p2 API 가 **없다** (`WasiConfig`
> 하나뿐이고 그것이 preview 1 이다). 우리가 의존하는 보안 성질(소켓 없음,
> preopen 만, ambient authority 0)은 p1 에서도 그대로 성립하므로 p1 으로
> 간다. 자세한 것은 `IMPL-0016`.
"""

from __future__ import annotations

import threading
import time
from collections.abc import Iterator, Mapping, Sequence
from contextlib import contextmanager
from dataclasses import dataclass, field
from pathlib import Path
from weakref import WeakKeyDictionary

import wasmtime

from ma_sandbox_wasm.limits import EPOCH_TICK_SECONDS, Limits

#: 게스트에서 보이는 워크스페이스 경로. 호스트 경로를 노출하지 않는다.
GUEST_WORKSPACE = "/workspace"

#: 메모리 스토어 마운트 지점.
GUEST_MEMORY_ROOT = "/mnt/memory"

#: 게스트에 **전달해도 되는** 환경변수. 화이트리스트다 — 블랙리스트로 하면
#: 새 변수가 생길 때마다 샌다.
ALLOWED_ENV = frozenset({"LANG", "LC_ALL", "TZ", "PYTHONHASHSEED"})


@dataclass(frozen=True, slots=True)
class Mount:
    """게스트에 보이는 디렉터리 하나."""

    host_path: Path
    guest_path: str
    writable: bool = False

    def __post_init__(self) -> None:
        if not self.host_path.is_absolute():
            raise ValueError(f"호스트 경로는 절대 경로여야 한다: {self.host_path}")
        if not self.guest_path.startswith("/"):
            raise ValueError(f"게스트 경로는 /로 시작해야 한다: {self.guest_path}")


def new_engine() -> wasmtime.Engine:
    """fuel 과 epoch 을 **엔진 수준에서** 켠다.

    둘 다 `Config` 옵션이라 엔진마다 정해진다. 끄고 켜는 것이 호출마다
    달라질 수 없으므로 **항상 켠다** — 상한을 안 걸 이유가 없고, 끈 엔진이
    섞이면 그 경로만 무제한이 된다.

    상한의 **값**(fuel 몇, 메모리 몇)은 여기 들어오지 않는다. 그것은
    `Store` 에 걸리므로 엔진을 공유해도 세션마다 다르게 줄 수 있다.
    """
    config = wasmtime.Config()
    config.consume_fuel = True
    config.epoch_interruption = True
    return wasmtime.Engine(config)


_SHARED_LOCK = threading.Lock()
_SHARED: wasmtime.Engine | None = None


def shared_engine() -> wasmtime.Engine:
    """**프로세스에 하나.** 세션마다 만들지 않는다.

    Wasmtime 의 격리 단위는 `Store` 지 `Engine` 이 아니다. Engine 은
    컴파일 캐시와 코드 메모리를 들고 있고, 두 세션이 같은 Engine 을 써도
    선형 메모리·테이블·fuel·epoch deadline 은 전부 `Store` 마다 따로다.

    세션마다 Engine 을 만들면 그 세션의 `Linker.define_wasi()` 와 모듈
    역직렬화를 매번 다시 해야 한다 — 측정(`IMPL-0016`)으로 **세션당
    165ms**, 프로비저닝 예산(50ms)의 세 배였다. 공유하면 0.1ms 다.
    """
    global _SHARED
    if _SHARED is None:
        with _SHARED_LOCK:
            if _SHARED is None:
                _SHARED = new_engine()
    return _SHARED


_TICKER_LOCK = threading.Lock()
_TICKER_USERS = 0
_TICKER_STOP: threading.Event | None = None
_TICKER_THREAD: threading.Thread | None = None


@contextmanager
def epoch_ticker(engine: wasmtime.Engine) -> Iterator[None]:
    """백그라운드에서 epoch 을 올린다.

    엔진을 공유하므로 **틱도 공유한다** — 동시에 도는 세션 수만큼 스레드를
    띄우면 틱이 그만큼 빨라지고, 모든 세션의 타임아웃이 함께 짧아진다.
    참조 수를 세어 마지막 사용자가 나갈 때 멈춘다.

    **데몬 스레드다.** 프로세스 종료를 막지 않는다 — 워커가 drain 중일 때
    이 스레드 때문에 안 끝나면 안 된다.
    """
    global _TICKER_USERS, _TICKER_STOP, _TICKER_THREAD

    with _TICKER_LOCK:
        _TICKER_USERS += 1
        if _TICKER_USERS == 1:
            stop = threading.Event()

            def tick() -> None:
                while not stop.wait(EPOCH_TICK_SECONDS):
                    engine.increment_epoch()

            _TICKER_STOP = stop
            _TICKER_THREAD = threading.Thread(target=tick, daemon=True, name="wasm-epoch")
            _TICKER_THREAD.start()
    try:
        yield
    finally:
        with _TICKER_LOCK:
            _TICKER_USERS -= 1
            if _TICKER_USERS == 0 and _TICKER_STOP is not None:
                _TICKER_STOP.set()
                if _TICKER_THREAD is not None:
                    _TICKER_THREAD.join(timeout=1.0)
                _TICKER_STOP = None
                _TICKER_THREAD = None


_LINKERS: WeakKeyDictionary[wasmtime.Engine, wasmtime.Linker] = WeakKeyDictionary()
_LINKER_LOCK = threading.Lock()


def linker_for(engine: wasmtime.Engine) -> wasmtime.Linker:
    """**엔진당 하나.** 매번 만들면 `define_wasi()` 가 측정상 가장 비싸다.

    `IMPL-0016`: Linker 를 세션마다 새로 만들면 인스턴스화가 ~164ms 로
    뛴다. 재사용하면 0.03ms 다. Linker 는 상태를 들지 않으므로 (상태는
    `Store` 에 있다) 재사용해도 세션 격리가 흐려지지 않는다.

    엔진에 약한 참조로 매단다 — 테스트가 임시 엔진을 쓰고 버려도
    Linker 가 남아 엔진을 붙잡고 있지 않게.
    """
    with _LINKER_LOCK:
        existing = _LINKERS.get(engine)
        if existing is None:
            existing = wasmtime.Linker(engine)
            existing.define_wasi()
            _LINKERS[engine] = existing
        return existing


@dataclass
class SessionStore:
    """세션 하나가 쓰는 Wasmtime 자원.

    **인스턴스는 호출마다 새로 만든다** — 이 객체는 엔진과 마운트 구성만
    들고 있다. 상태를 누적하면 세션 간 격리가 흐려지고, 같은 세션 안에서도
    한 번의 `run_code` 가 다음 것을 오염시킨다.
    """

    workspace_root: Path
    limits: Limits = field(default_factory=Limits)
    memory_mounts: tuple[Mount, ...] = ()
    env: Mapping[str, str] = field(default_factory=dict)
    _engine: wasmtime.Engine | None = None

    @property
    def engine(self) -> wasmtime.Engine:
        """**기본은 프로세스 공유 엔진이다.** 격리는 `Store` 가 한다.

        테스트가 격리된 엔진을 원하면 `_engine` 에 넣어 주면 된다.
        """
        if self._engine is None:
            self._engine = shared_engine()
        return self._engine

    def mounts(self) -> tuple[Mount, ...]:
        """게스트가 보는 전부. **여기 없는 것은 존재하지 않는다.**"""
        return (
            Mount(
                host_path=self.workspace_root.resolve(),
                guest_path=GUEST_WORKSPACE,
                writable=True,
            ),
            *self.memory_mounts,
        )

    def wasi_config(
        self,
        *,
        argv: Sequence[str] = (),
        runtime_env: Mapping[str, str] | None = None,
        stdout_path: Path | None = None,
        stderr_path: Path | None = None,
        stdin_path: Path | None = None,
    ) -> wasmtime.WasiConfig:
        """**주는 것만 적는다.** 적지 않은 것은 게스트에 없다.

        `inherit_env` 를 쓰지 않는 것이 중요하다 — 워커 프로세스의 환경에는
        DB 비밀번호와 모델 API 키가 있다 (M1 한정, T-0402 전까지). 상속하면
        그것이 전부 게스트로 간다.

        `runtime_env` 는 **런타임이 자기 자신에게 거는 것**이다 (CPython 의
        `PYTHONHOME` 같은). 세션 환경(`self.env`)과 섞지 않는다 — 전자는
        우리가 고른 값이고 후자는 바깥에서 온 값이라, 같은 화이트리스트로
        재면 바깥 값이 `PYTHONHOME` 을 덮어 인터프리터를 다른 stdlib 로
        돌리는 길이 열린다.
        """
        cfg = wasmtime.WasiConfig()
        cfg.argv = list(argv)

        # **화이트리스트만.** 블랙리스트는 새 변수가 생길 때마다 샌다.
        env = {k: v for k, v in self.env.items() if k in ALLOWED_ENV}
        # 런타임이 건 것이 나중이다 — 세션 값이 덮지 못한다.
        env.update(runtime_env or {})
        cfg.env = list(env.items())

        for mount in self.mounts():
            # `preopen_dir` 이 능력 부여 지점이다. 여기 없는 디렉터리는
            # 게스트에서 열 수 없다 — 경로를 알아도 못 연다.
            cfg.preopen_dir(str(mount.host_path), mount.guest_path)

        # stdin 을 주지 않으면 게스트가 읽기에서 블록될 수 있다.
        if stdin_path is not None:
            cfg.stdin_file = str(stdin_path)
        if stdout_path is not None:
            cfg.stdout_file = str(stdout_path)
        if stderr_path is not None:
            cfg.stderr_file = str(stderr_path)
        return cfg

    def new_store(self, wasi: wasmtime.WasiConfig) -> wasmtime.Store:
        """**호출마다 새 Store.** 상한을 여기서 건다."""
        store = wasmtime.Store(self.engine)
        store.set_wasi(wasi)
        store.set_fuel(self.limits.fuel)
        store.set_limits(
            memory_size=self.limits.memory_bytes,
            table_elements=self.limits.table_elements,
        )
        store.set_epoch_deadline(self.limits.epoch_ticks)
        return store

    def linker(self) -> wasmtime.Linker:
        """이 엔진의 Linker. **엔진당 하나** (`linker_for`)."""
        return linker_for(self.engine)

    def close(self) -> None:
        """세션이 끝났다. **엔진은 닫지 않는다** — 공유물이다."""
        self._engine = None


def wall_clock_deadline(limits: Limits) -> float:
    """epoch 이 놓칠 때의 백업. 호출자가 자기 루프에서 본다."""
    return time.monotonic() + limits.timeout_seconds


__all__ = [
    "ALLOWED_ENV",
    "GUEST_MEMORY_ROOT",
    "GUEST_WORKSPACE",
    "Mount",
    "SessionStore",
    "epoch_ticker",
    "linker_for",
    "new_engine",
    "shared_engine",
    "wall_clock_deadline",
]
