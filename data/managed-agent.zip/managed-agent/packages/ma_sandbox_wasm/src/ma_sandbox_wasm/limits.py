"""CPU·메모리 상한 — **워커를 죽이지 않고 세션만 멈춘다**.

`plan/07-sandbox.md` §3.3 · `task/M2-sandbox-tools/T-0303-tier-wasm.md`.

세 가지로 막는다.

| 장치 | 막는 것 | 어떻게 |
|---|---|---|
| **fuel** | 무한 루프·과도한 연산 | 명령어마다 차감. 0 이 되면 trap |
| **epoch** | fuel 로 안 잡히는 블로킹 | 백그라운드 타이머가 deadline 을 올린다 |
| **memory** | 선형 메모리 폭증 | `Store.set_limits` 가 grow 를 거부 |

**fuel 과 epoch 을 둘 다 쓰는 이유**: fuel 은 Wasm 명령어만 센다. 호스트
함수(파일 읽기 같은)에서 오래 걸리면 fuel 이 줄지 않는다. epoch 은 벽시계로
자르므로 그 틈을 덮는다.
"""

from __future__ import annotations

from dataclasses import dataclass

#: 이 머신에서 **1초에 타는 fuel** (`IMPL-0016` 측정, M4 Pro).
#:
#: 1M 회 정수 루프가 6.91G fuel / 617ms 였다. 머신마다 다르므로 상한을
#: 고를 때의 눈금으로만 쓴다 — fuel 자체는 결정적이지만 그 **시간 환산**은
#: 아니다.
FUEL_PER_SECOND = 11_200_000_000

#: CPython WASI 가 **아무것도 안 하고 기동하는 데** 드는 fuel (측정 244M).
#: 상한을 이것보다 낮게 잡으면 `print('hi')` 도 TIMEOUT 이 된다.
CPYTHON_STARTUP_FUEL = 250_000_000

#: 기본 fuel. 기본 타임아웃(30초)보다 **넉넉히** 잡는다.
#:
#: **fuel 이 먼저 터지면 안 된다.** 둘 다 "너무 오래 걸렸다"를 뜻하는데,
#: 벽시계(epoch)가 운영자가 이해하는 축이다. fuel 은 epoch 틱 스레드가
#: 굶었을 때를 받치는 **백스톱**이므로 여유분을 얹는다.
DEFAULT_FUEL = 400_000_000_000

#: 기본 벽시계 상한(초). epoch 틱이 이 시간 뒤 deadline 을 넘긴다.
DEFAULT_TIMEOUT_SECONDS = 30.0

#: epoch 틱 주기(초). 짧을수록 타임아웃이 정확하지만 스레드가 자주 깬다.
EPOCH_TICK_SECONDS = 0.1

#: 선형 메모리 상한(바이트). CPython WASI 가 기동에만 ~30MB 를 쓴다.
DEFAULT_MEMORY_BYTES = 512 * 1024 * 1024

#: 인스턴스당 테이블 요소 수 상한.
DEFAULT_TABLE_ELEMENTS = 100_000


@dataclass(frozen=True, slots=True)
class Limits:
    """한 번의 실행에 거는 상한.

    **호출마다 다를 수 있다.** 무거운 데이터 작업에 더 주고 간단한 계산에
    덜 주는 것이 자연스럽다 — `SandboxPolicy` 가 호출마다 실리는 것과 같은
    이유다.
    """

    fuel: int = DEFAULT_FUEL
    timeout_seconds: float = DEFAULT_TIMEOUT_SECONDS
    memory_bytes: int = DEFAULT_MEMORY_BYTES
    table_elements: int = DEFAULT_TABLE_ELEMENTS

    def __post_init__(self) -> None:
        if self.fuel <= 0:
            raise ValueError("fuel 은 양수여야 한다")
        if self.timeout_seconds <= 0:
            raise ValueError("timeout 은 양수여야 한다")
        if self.memory_bytes <= 0:
            raise ValueError("memory 상한은 양수여야 한다")

    @property
    def epoch_ticks(self) -> int:
        """이 타임아웃에 해당하는 epoch 틱 수. 최소 1."""
        return max(1, int(self.timeout_seconds / EPOCH_TICK_SECONDS))


#: 상한을 낮춘 것. **테스트와 신뢰할 수 없는 코드의 첫 실행**에 쓴다.
#:
#: fuel 은 기동 바닥(250M)의 80배, 메모리는 CPython 기동분(~40MB)의 6배다.
#: 더 조이면 "상한이 작동한다"가 아니라 "인터프리터가 안 뜬다"를 재게 된다.
STRICT = Limits(
    fuel=20_000_000_000,
    timeout_seconds=5.0,
    memory_bytes=256 * 1024 * 1024,
)


__all__ = [
    "CPYTHON_STARTUP_FUEL",
    "DEFAULT_FUEL",
    "DEFAULT_MEMORY_BYTES",
    "DEFAULT_TABLE_ELEMENTS",
    "DEFAULT_TIMEOUT_SECONDS",
    "EPOCH_TICK_SECONDS",
    "FUEL_PER_SECOND",
    "STRICT",
    "Limits",
]
