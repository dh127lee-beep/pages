# CPython WASI 에셋

**저장소에 넣지 않는다.** `python.wasm` 이 ~20MB 이고 버전마다 바뀐다.

```sh
uv run python tools/fetch_wasm_assets.py          # 받는다 (sha256 검증)
uv run python tools/fetch_wasm_assets.py --check  # 상태만 본다
```

받고 나면 이렇게 생긴다.

| 경로 | 무엇 | 출처 |
|---|---|---|
| `python.wasm` | CPython 3.12.0 `wasm32-wasip1` | VMware Labs `webassembly-language-runtimes` |
| `python.cwasm` | 미리 컴파일한 캐시 | **우리가 만든다.** 지워도 된다 (다시 생긴다) |
| `pylib/python312.zip` | 표준 라이브러리 | 같은 릴리스 |
| `pylib/python3.12/os.py` | 빌드가 zip 밖에 둔 것 | 같은 릴리스 |
| `pylib/python3.12/tzdata/` | 타임존 데이터베이스 | PyPI `tzdata` (순수 파이썬 휠) |
| `PROVENANCE.txt` | 어느 빌드인지 | 받을 때 기록된다 |

**`pylib/` 가 게스트의 `/usr/local/lib` 로 통째로 preopen 된다.** 그래서
`python.wasm` 을 그 밖에 둔다 — 안에 두면 인터프리터 바이너리가 게스트에
보인다.

에셋이 없으면 `run_code` 가 **등록되지 않는다** (`WasmSandboxProvider.tools_available`).
없는 채로 불리면 `RunStatus.UNAVAILABLE` 을 돌려주지, 조용히 다른 것을
실행하지 않는다.

버전 고정 근거·갱신 절차·측정값은 [`docs/impl/0016-wasm-tier.md`](../../../../../docs/impl/0016-wasm-tier.md),
Q2 통과율은 [`docs/impl/0003-wasm-tier-findings.md`](../../../../../docs/impl/0003-wasm-tier-findings.md).
