"""S3 백엔드 — **프로덕션.** `plan/08-infrastructure.md` §6.

`boto3` 는 **선택 의존이다** (`ma-adapters-blob[s3]`). 개발과 테스트는
메모리·로컬 백엔드로 돌고, 여기까지 오는 것은 프로덕션뿐이다. import 를
함수 안에서 하는 이유도 그것이다 — boto3 없이도 이 모듈을 import 할 수
있어야 `ma_adapters_blob` 전체가 열린다.

**boto3 는 동기다.** 모든 호출을 `anyio.to_thread` 로 감싼다. 감싸지
않으면 이벤트 루프가 네트워크 왕복 동안 멈추고, SSE 하트비트가
끊긴다 (`plan/04` §5).

**`BlobPort` 와 같은 계약을 지킨다.** `tests/contract/test_blob_store.py`
가 메모리 백엔드와 같이 돌려 발산을 잡는다 — 다만 S3 쪽은 자격증명이
있을 때만 돈다 (없으면 skip).
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from datetime import timedelta
from typing import TYPE_CHECKING, Any

import anyio
from ma_application.blob import DEFAULT_URL_TTL, BlobInfo, BlobNotFound

if TYPE_CHECKING:
    from collections.abc import Callable

#: 없는 키를 나타내는 S3 오류 코드. **404 와 403 을 같이 본다** —
#: 버킷 정책이 `s3:ListBucket` 을 주지 않으면 없는 객체가 403 으로
#: 온다. 둘을 구분하면 "없음"이 500 이 된다.
_MISSING_CODES = frozenset({"404", "NoSuchKey", "NotFound", "403", "AccessDenied"})


@dataclass
class S3BlobStore:
    """`boto3` 클라이언트를 감싼다.

    `client` 를 주입받는 이유: 엔드포인트·리전·자격증명 조립은
    `config.py` 의 일이고 (`plan/09` §4), 여기서 환경변수를 읽으면
    그 규칙이 깨진다. MinIO 같은 S3 호환 스토어도 같은 길로 들어온다.
    """

    bucket: str
    client: Any

    async def _call(self, fn: Callable[..., Any], /, **kwargs: Any) -> Any:
        return await anyio.to_thread.run_sync(lambda: fn(**kwargs))

    async def put(self, key: str, data: bytes, *, content_type: str) -> BlobInfo:
        await self._call(
            self.client.put_object,
            Bucket=self.bucket,
            Key=key,
            Body=data,
            ContentType=content_type,
        )
        return BlobInfo(key=key, size_bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

    async def get(self, key: str) -> bytes:
        try:
            got = await self._call(self.client.get_object, Bucket=self.bucket, Key=key)
        except Exception as exc:
            if _is_missing(exc):
                raise BlobNotFound(key) from None
            raise
        body = got["Body"]
        return await anyio.to_thread.run_sync(body.read)

    async def delete(self, key: str) -> bool:
        """**멱등하다.** 없어도 예외를 내지 않는다.

        S3 의 `delete_object` 는 없는 키에도 200 을 준다. 그래서 "정말
        지웠는가"를 알려면 먼저 `exists()` 를 봐야 하고, 그 사이에 경합이
        있다 — 삭제가 멱등한 이상 그 경합은 무해하다.
        """
        existed = await self.exists(key)
        await self._call(self.client.delete_object, Bucket=self.bucket, Key=key)
        return existed

    async def exists(self, key: str) -> bool:
        try:
            await self._call(self.client.head_object, Bucket=self.bucket, Key=key)
        except Exception as exc:
            if _is_missing(exc):
                return False
            raise
        return True

    async def signed_url(self, key: str, *, ttl: timedelta = DEFAULT_URL_TTL) -> str:
        """presigned GET. **제어 평면이 바이트를 중계하지 않는다.**"""
        return await anyio.to_thread.run_sync(
            lambda: self.client.generate_presigned_url(
                "get_object",
                Params={"Bucket": self.bucket, "Key": key},
                ExpiresIn=int(ttl.total_seconds()),
            )
        )


def _is_missing(exc: Exception) -> bool:
    """botocore `ClientError` 에서 "없음"을 읽는다.

    `botocore` 를 import 하지 않고 duck-typing 하는 이유: 이 모듈이
    boto3 없이도 import 돼야 하기 때문이다.
    """
    response = getattr(exc, "response", None)
    if not isinstance(response, dict):
        return False
    code = str(response.get("Error", {}).get("Code", ""))
    status = str(response.get("ResponseMetadata", {}).get("HTTPStatusCode", ""))
    return code in _MISSING_CODES or status in _MISSING_CODES


def client_for(
    *, endpoint_url: str | None = None, region: str | None = None
) -> Any:  # pragma: no cover — boto3 가 필요하다
    """`boto3` 클라이언트 하나. **조립에서만 부른다.**"""
    import boto3

    return boto3.client("s3", endpoint_url=endpoint_url, region_name=region)


__all__ = ["S3BlobStore", "client_for"]
