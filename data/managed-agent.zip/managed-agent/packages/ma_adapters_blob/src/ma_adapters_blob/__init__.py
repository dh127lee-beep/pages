"""AWP · 오브젝트 스토어 어댑터.

| 백엔드 | 쓰는 곳 | 서명 URL |
|---|---|---|
| `MemoryBlobStore` | 테스트 | **못 한다** (`BlobUnsupported`) |
| `LocalBlobStore` | 개발 머신 | **못 한다** — 아래 |
| `S3BlobStore` | 프로덕션 | presigned GET |

**로컬 백엔드가 서명 URL 을 못 하는 것은 기능 부족이 아니라 설계다.**
서명 대신 바이트를 중계하는 길을 열어 두면 프로덕션에서도 그렇게 되고,
그러면 제어 평면이 대용량에서 막힌다 (`T-0502` 구현 지침). 개발
머신에서 다운로드가 필요하면 그때 정직하게 막히는 편이 낫다.
"""

from ma_adapters_blob.local import LocalBlobStore
from ma_adapters_blob.memory import MemoryBlobStore

__all__ = ["LocalBlobStore", "MemoryBlobStore"]
