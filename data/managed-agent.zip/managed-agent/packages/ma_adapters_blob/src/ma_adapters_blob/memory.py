"""메모리 백엔드 — **테스트 전용.**

`S3BlobStore` 와 **같은 계약**을 지킨다. 계약 테스트가 둘을 같이 돌려
"두 구현이 같은 입력에 같은 답을 내는가"를 본다 — 그것이 어긋나면
테스트에서 통과한 것이 프로덕션에서 깨진다.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from datetime import timedelta

from ma_application.blob import DEFAULT_URL_TTL, BlobInfo, BlobNotFound, BlobUnsupported


@dataclass
class MemoryBlobStore:
    """프로세스 메모리. **재시작하면 사라진다.**"""

    objects: dict[str, bytes] = field(default_factory=dict)
    content_types: dict[str, str] = field(default_factory=dict)

    async def put(self, key: str, data: bytes, *, content_type: str) -> BlobInfo:
        self.objects[key] = data
        self.content_types[key] = content_type
        return BlobInfo(key=key, size_bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

    async def get(self, key: str) -> bytes:
        try:
            return self.objects[key]
        except KeyError:
            raise BlobNotFound(key) from None

    async def delete(self, key: str) -> bool:
        self.content_types.pop(key, None)
        return self.objects.pop(key, None) is not None

    async def exists(self, key: str) -> bool:
        return key in self.objects

    async def signed_url(self, key: str, *, ttl: timedelta = DEFAULT_URL_TTL) -> str:
        """**못 한다.** 서명할 비밀도, 받아 줄 서버도 없다.

        여기서 `http://test/...` 같은 가짜를 돌려주면 라우터의 리다이렉트
        경로가 테스트에서만 통과하게 된다. 서명 URL 을 테스트하려면
        S3 호환 백엔드를 띄워야 하고, 그 사실이 드러나는 편이 낫다.
        """
        raise BlobUnsupported("메모리 백엔드는 서명 URL 을 만들지 못한다")


__all__ = ["MemoryBlobStore"]
