"""로컬 파일시스템 백엔드 — **개발 머신 전용.**

키를 디렉터리 경로로 쓴다. 키에 `..` 이 들어오면 루트를 빠져나가므로
**쓰기 전에 해석해서 확인한다** — 키는 애플리케이션이 만들지만, 그
가정이 한 번 깨지면 임의 경로 쓰기가 된다.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from datetime import timedelta
from pathlib import Path

import anyio
from ma_application.blob import DEFAULT_URL_TTL, BlobInfo, BlobNotFound, BlobUnsupported


class UnsafeKey(ValueError):
    """키가 루트를 빠져나간다."""


@dataclass
class LocalBlobStore:
    root: Path

    def _path(self, key: str) -> Path:
        target = (self.root / key).resolve()
        root = self.root.resolve()
        # **`startswith` 가 아니라 `is_relative_to`.** 전자는
        # `/data/awp-evil` 이 `/data/awp` 로 시작하므로 통과시킨다.
        if not target.is_relative_to(root):
            raise UnsafeKey(f"키가 루트를 벗어난다: {key!r}")
        return target

    async def put(self, key: str, data: bytes, *, content_type: str) -> BlobInfo:
        path = self._path(key)
        await anyio.to_thread.run_sync(lambda: path.parent.mkdir(parents=True, exist_ok=True))
        await anyio.to_thread.run_sync(path.write_bytes, data)
        return BlobInfo(key=key, size_bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

    async def get(self, key: str) -> bytes:
        path = self._path(key)
        try:
            return await anyio.to_thread.run_sync(path.read_bytes)
        except FileNotFoundError:
            raise BlobNotFound(key) from None

    async def delete(self, key: str) -> bool:
        path = self._path(key)

        def _unlink() -> bool:
            try:
                path.unlink()
            except FileNotFoundError:
                return False
            return True

        return await anyio.to_thread.run_sync(_unlink)

    async def exists(self, key: str) -> bool:
        return await anyio.to_thread.run_sync(self._path(key).is_file)

    async def signed_url(self, key: str, *, ttl: timedelta = DEFAULT_URL_TTL) -> str:
        """**못 한다** — `MemoryBlobStore` 와 같은 이유."""
        raise BlobUnsupported("로컬 백엔드는 서명 URL 을 만들지 못한다")


__all__ = ["LocalBlobStore", "UnsafeKey"]
