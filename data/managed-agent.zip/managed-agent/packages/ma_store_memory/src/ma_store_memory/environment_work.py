"""self_hosted 워커 큐 — 메모리 구현 (T-0606).

**시크릿도 실제로 봉한다.** 평문을 dict 에 넣으면 이 구현이 SQL 에서는
불가능한 일을 통과시키고, 그 순간 계약 테스트가 거짓말이 된다
(`MemoryCredentialStore` 와 같은 규칙).
"""

from __future__ import annotations

from dataclasses import dataclass, replace
from datetime import datetime, timedelta
from typing import TYPE_CHECKING

from ma_domain.environment_work import (
    DEFAULT_LEASE_TTL,
    WorkItem,
    WorkState,
    WorkStats,
)
from ma_domain.errors import InvariantViolation
from ma_domain.ids import EnvironmentId, SessionId, WorkspaceId
from ma_store._results import ListQuery, Page
from ma_store.environment_work import (
    AckResult,
    AckWork,
    ClaimedWork,
    ClaimResult,
    ClaimWork,
    EnqueueWork,
    FenceLost,
    Heartbeat,
    HeartbeatResult,
    NoWork,
    WorkGone,
)

from ma_store_memory._base import isolate, paginate, partition_key

if TYPE_CHECKING:
    from ma_governance.cipher import CredentialCipher, Sealed


@dataclass
class _Row:
    item: WorkItem
    sealed: Sealed | None = None


class MemoryEnvironmentWorkStore:
    def __init__(self, cipher: CredentialCipher) -> None:
        # **생성자 인자다.** Port 가 아니다 (`plan/03` §3 L2).
        self._cipher = cipher
        self._rows: dict[tuple[str, str], _Row] = {}

    async def enqueue(self, cmd: EnqueueWork) -> WorkItem:
        # **세션 하나당 열린 일은 하나.** SQL 의 부분 유니크 인덱스와
        # 같은 규칙을 여기서도 지킨다 — 안 지키면 두 구현이 갈린다.
        for row in self._rows.values():
            if (
                row.item.workspace_id == cmd.workspace_id
                and row.item.session_id == cmd.session_id
                and row.item.state.is_open
            ):
                raise InvariantViolation(
                    f"세션 {cmd.session_id} 에 이미 열린 일이 있다: {row.item.id}"
                )

        made = WorkItem(
            id=cmd.id,
            workspace_id=cmd.workspace_id,
            environment_id=cmd.environment_id,
            environment_version=cmd.environment_version,
            session_id=cmd.session_id,
            state=WorkState.QUEUED,
            claim_generation=0,
            created_at=cmd.now,
            updated_at=cmd.now,
        )
        self._rows[partition_key(cmd.workspace_id, cmd.id)] = _Row(item=made)
        return isolate(made)

    async def claim(self, cmd: ClaimWork) -> ClaimResult:
        from ma_governance.cipher import associated_data

        # 큐된 것 먼저, 그다음 **끊긴 것을 회수해서** 집는다.
        # 순서가 중요하다: 끊긴 것을 먼저 보면 새 일이 밀린다.
        for wanted_stale in (False, True):
            for key in sorted(self._rows, key=lambda k: (self._rows[k].item.created_at, k)):
                row = self._rows[key]
                item = row.item
                if item.workspace_id != cmd.workspace_id:
                    continue
                if item.environment_id != cmd.environment_id:
                    continue

                if wanted_stale:
                    if not item.is_stale(cmd.now, ttl=cmd.reclaim_after):
                        continue
                    if item.attempts >= cmd.max_attempts:
                        # **상한을 넘었다.** 큐가 이 하나로 막히면 안 된다.
                        self._rows[key] = _Row(
                            item=replace(
                                item,
                                state=WorkState.FAILED,
                                acked_at=cmd.now,
                                updated_at=cmd.now,
                                error=f"{item.attempts}회 회수 후 포기",
                            ),
                            sealed=None,
                        )
                        continue
                elif item.state is not WorkState.QUEUED:
                    continue

                sealed = self._cipher.seal(
                    cmd.secret, aad=associated_data(cmd.workspace_id, item.id)
                )
                claimed = replace(
                    item,
                    state=WorkState.CLAIMED,
                    # **generation 을 올린다.** 옛 워커의 ack 가 거부된다.
                    claim_generation=item.claim_generation + 1,
                    worker_id=cmd.worker_id,
                    attempts=item.attempts + 1,
                    claimed_at=cmd.now,
                    heartbeat_at=cmd.now,
                    updated_at=cmd.now,
                )
                self._rows[key] = _Row(item=claimed, sealed=sealed)
                return ClaimedWork(item=isolate(claimed), secret=cmd.secret)

        return NoWork()

    async def heartbeat(self, cmd: Heartbeat) -> HeartbeatResult:
        row = self._rows.get(partition_key(cmd.workspace_id, cmd.work_id))
        if row is None:
            return WorkGone(work_id=cmd.work_id)
        item = row.item
        if not item.accepts(cmd.generation) or item.worker_id != cmd.worker_id:
            return FenceLost(actual_generation=item.claim_generation)
        if item.state is not WorkState.CLAIMED:
            # **끝난 일에는 하트비트가 없다.** 보내는 쪽이 상태를
            # 잘못 알고 있다는 뜻이므로 알려 준다.
            return FenceLost(actual_generation=item.claim_generation)

        beat = replace(item, heartbeat_at=cmd.now, updated_at=cmd.now)
        self._rows[partition_key(cmd.workspace_id, cmd.work_id)] = replace(row, item=beat)
        return isolate(beat)

    async def ack(self, cmd: AckWork) -> AckResult:
        key = partition_key(cmd.workspace_id, cmd.work_id)
        row = self._rows.get(key)
        if row is None:
            return WorkGone(work_id=cmd.work_id)
        item = row.item
        if not item.accepts(cmd.generation) or item.worker_id != cmd.worker_id:
            return FenceLost(actual_generation=item.claim_generation)

        done = replace(
            item,
            state=cmd.state,
            acked_at=cmd.now if cmd.state.is_final else item.acked_at,
            error=cmd.error[:1000],
            updated_at=cmd.now,
        )
        # **시크릿을 버린다.** 1회용이고, 끝난 뒤에도 남아 있으면
        # 1회용이 아니다.
        self._rows[key] = _Row(item=done, sealed=None)
        return isolate(done)

    async def find(self, workspace_id: WorkspaceId, work_id: str) -> WorkItem | None:
        row = self._rows.get(partition_key(workspace_id, work_id))
        return isolate(row.item) if row else None

    async def find_for_session(
        self, workspace_id: WorkspaceId, session_id: SessionId
    ) -> WorkItem | None:
        for row in sorted(self._rows.values(), key=lambda r: (r.item.created_at, r.item.id)):
            if (
                row.item.workspace_id == workspace_id
                and row.item.session_id == session_id
                and row.item.state.is_open
            ):
                return isolate(row.item)
        return None

    async def list_work(self, q: ListQuery, environment_id: EnvironmentId) -> Page[WorkItem]:
        rows = [
            r.item
            for r in self._rows.values()
            if r.item.workspace_id == q.workspace_id and r.item.environment_id == environment_id
        ]
        return paginate(rows, q, created_at=lambda w: w.created_at, ident=lambda w: w.id)

    async def stats(
        self, workspace_id: WorkspaceId, environment_id: EnvironmentId, now: datetime
    ) -> WorkStats:
        counts = dict.fromkeys(WorkState, 0)
        oldest: datetime | None = None
        for row in self._rows.values():
            item = row.item
            if item.workspace_id != workspace_id or item.environment_id != environment_id:
                continue
            counts[item.state] += 1
            if item.state is WorkState.QUEUED and (oldest is None or item.created_at < oldest):
                oldest = item.created_at

        return WorkStats(
            environment_id=environment_id,
            queued=counts[WorkState.QUEUED],
            claimed=counts[WorkState.CLAIMED],
            done=counts[WorkState.DONE],
            failed=counts[WorkState.FAILED],
            expired=counts[WorkState.EXPIRED],
            oldest_queued_seconds=int((now - oldest).total_seconds()) if oldest else 0,
        )

    async def reclaim_stale(
        self, now: datetime, *, ttl: timedelta = DEFAULT_LEASE_TTL, limit: int = 100
    ) -> tuple[WorkItem, ...]:
        out: list[WorkItem] = []
        for key in sorted(self._rows):
            if len(out) >= limit:
                break
            row = self._rows[key]
            if not row.item.is_stale(now, ttl=ttl):
                continue
            back = replace(
                row.item,
                state=WorkState.QUEUED,
                worker_id=None,
                claimed_at=None,
                heartbeat_at=None,
                updated_at=now,
            )
            # **시크릿을 버린다.** 회수했으면 그 시크릿은 죽은 것이다.
            self._rows[key] = _Row(item=back, sealed=None)
            out.append(isolate(back))
        return tuple(out)

    # ── 테스트가 쓰는 것 ─────────────────────────────────
    def reveal_secret(self, workspace_id: WorkspaceId, work_id: str) -> str | None:
        """**봉인이 실제로 일어났는지** 보려고 둔다. 운영 코드가 쓰지 않는다."""
        from ma_governance.cipher import associated_data

        row = self._rows.get(partition_key(workspace_id, work_id))
        if row is None or row.sealed is None:
            return None
        return self._cipher.open(row.sealed, aad=associated_data(workspace_id, work_id))


__all__ = ["MemoryEnvironmentWorkStore"]
