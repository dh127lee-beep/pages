"""파일 · 산출물 · 스냅샷 — 메모리 구현 (G8).

SQL 구현과 **같은 계약**을 지킨다. 특히 두 가지:

- `mark_uploaded` 는 **이미 찍혀 있으면 그대로 둔다.** 재시도가 시각을
  뒤로 미루면 "언제 올라갔는가"가 거짓이 된다.
- `SnapshotStore.insert` 는 같은 세대를 **거부한다.** 덮어쓰면 좀비
  워커가 새 소유자의 스냅샷을 지운다 (D3).
"""

from __future__ import annotations

from dataclasses import replace
from datetime import datetime

from ma_domain.files import FileMeta, SessionOutput, WorkspaceSnapshot
from ma_domain.ids import FileId, SessionId, WorkspaceId
from ma_store._results import ListQuery, Page
from ma_store.files import (
    InsertFile,
    InsertOutput,
    InsertSnapshot,
    InsertSnapshotResult,
    SnapshotExists,
)

from ma_store_memory._base import isolate, paginate, partition_key


class MemoryFileStore:
    def __init__(self) -> None:
        self._rows: dict[tuple[str, str], FileMeta] = {}

    async def insert(self, cmd: InsertFile) -> FileMeta:
        made = FileMeta(
            id=cmd.id,
            workspace_id=cmd.workspace_id,
            filename=cmd.filename,
            safe_name=cmd.safe_name,
            content_type=cmd.content_type,
            size_bytes=cmd.size_bytes,
            sha256=cmd.sha256,
            storage_key=cmd.storage_key,
            created_by=cmd.created_by,
            created_at=cmd.now,
            # **항상 미완성으로 태어난다.** 바이트가 올라간 뒤 채운다.
            uploaded_at=None,
        )
        self._rows[partition_key(cmd.workspace_id, cmd.id)] = made
        return isolate(made)

    async def mark_uploaded(
        self, workspace_id: WorkspaceId, file_id: FileId, now: datetime
    ) -> FileMeta | None:
        key = partition_key(workspace_id, file_id)
        got = self._rows.get(key)
        if got is None or got.deleted_at is not None:
            return None
        if got.uploaded_at is not None:
            # **이미 찍혀 있으면 그대로.** 재시도가 시각을 미루지 않는다.
            return isolate(got)
        self._rows[key] = replace(got, uploaded_at=now)
        return isolate(self._rows[key])

    async def find(self, workspace_id: WorkspaceId, file_id: FileId) -> FileMeta | None:
        got = self._rows.get(partition_key(workspace_id, file_id))
        if got is None or got.deleted_at is not None:
            return None
        return isolate(got)

    async def list_files(self, q: ListQuery) -> Page[FileMeta]:
        rows = [
            f
            for (ws, _), f in self._rows.items()
            if ws == q.workspace_id and (q.include_archived or f.deleted_at is None)
        ]
        return paginate(rows, q, created_at=lambda f: f.created_at, ident=lambda f: f.id)

    async def usage_since(self, workspace_id: WorkspaceId, since: datetime) -> tuple[int, int]:
        rows = [
            f
            for (ws, _), f in self._rows.items()
            # **`deleted_at` 을 보지 않는다** — 올리고 지우기를 반복해
            # 상한을 우회하는 길을 막는다.
            if ws == workspace_id and f.created_at >= since
        ]
        return len(rows), sum(f.size_bytes for f in rows)

    async def delete(self, workspace_id: WorkspaceId, file_id: FileId, now: datetime) -> bool:
        key = partition_key(workspace_id, file_id)
        got = self._rows.get(key)
        if got is None or got.deleted_at is not None:
            return False
        self._rows[key] = replace(got, deleted_at=now)
        return True


class MemorySessionOutputStore:
    def __init__(self) -> None:
        self._rows: dict[tuple[str, str], SessionOutput] = {}

    async def insert(self, cmd: InsertOutput) -> SessionOutput:
        made = SessionOutput(
            id=cmd.id,
            workspace_id=cmd.workspace_id,
            session_id=cmd.session_id,
            path=cmd.path,
            content_type=cmd.content_type,
            size_bytes=cmd.size_bytes,
            sha256=cmd.sha256,
            storage_key=cmd.storage_key,
            generation=cmd.generation,
            created_at=cmd.now,
        )
        self._rows[partition_key(cmd.workspace_id, cmd.id)] = made
        return isolate(made)

    async def find(self, workspace_id: WorkspaceId, output_id: str) -> SessionOutput | None:
        got = self._rows.get(partition_key(workspace_id, output_id))
        if got is None or got.deleted_at is not None:
            return None
        return isolate(got)

    async def list_for_session(self, q: ListQuery, session_id: SessionId) -> Page[SessionOutput]:
        rows = [
            o
            for (ws, _), o in self._rows.items()
            if ws == q.workspace_id
            and o.session_id == session_id
            and (q.include_archived or o.deleted_at is None)
        ]
        return paginate(rows, q, created_at=lambda o: o.created_at, ident=lambda o: o.id)

    async def delete(self, workspace_id: WorkspaceId, output_id: str, now: datetime) -> bool:
        key = partition_key(workspace_id, output_id)
        got = self._rows.get(key)
        if got is None or got.deleted_at is not None:
            return False
        self._rows[key] = replace(got, deleted_at=now)
        return True


class MemorySnapshotStore:
    def __init__(self) -> None:
        self._rows: dict[tuple[str, str], WorkspaceSnapshot] = {}

    async def insert(self, cmd: InsertSnapshot) -> InsertSnapshotResult:
        for (ws, _), s in self._rows.items():
            if (
                ws == cmd.workspace_id
                and s.session_id == cmd.session_id
                and s.generation == cmd.generation
            ):
                # **좀비 방어.** 같은 세대를 두 번 쓰지 못한다.
                return SnapshotExists(generation=cmd.generation)
        made = WorkspaceSnapshot(
            id=cmd.id,
            workspace_id=cmd.workspace_id,
            session_id=cmd.session_id,
            generation=cmd.generation,
            size_bytes=cmd.size_bytes,
            sha256=cmd.sha256,
            storage_key=cmd.storage_key,
            created_at=cmd.now,
            expires_at=cmd.expires_at,
        )
        self._rows[partition_key(cmd.workspace_id, cmd.id)] = made
        return isolate(made)

    async def latest(
        self, workspace_id: WorkspaceId, session_id: SessionId
    ) -> WorkspaceSnapshot | None:
        """**가장 높은 세대.** 가장 최근 시각이 아니다 — 좀비가 늦게 쓴
        낮은 세대가 이기면 복원했을 때 옛날 워크스페이스가 돌아온다."""
        rows = [
            s
            for (ws, _), s in self._rows.items()
            if ws == workspace_id and s.session_id == session_id and s.deleted_at is None
        ]
        if not rows:
            return None
        return isolate(max(rows, key=lambda s: s.generation))

    async def list_expired(
        self, workspace_id: WorkspaceId, now: datetime, limit: int = 100
    ) -> tuple[WorkspaceSnapshot, ...]:
        rows = [
            s
            for (ws, _), s in self._rows.items()
            if ws == workspace_id and s.deleted_at is None and s.is_expired(now)
        ]
        rows.sort(key=lambda s: (s.expires_at, s.id))
        return tuple(isolate(s) for s in rows[:limit])

    async def delete(self, workspace_id: WorkspaceId, snapshot_id: str, now: datetime) -> bool:
        key = partition_key(workspace_id, snapshot_id)
        got = self._rows.get(key)
        if got is None or got.deleted_at is not None:
            return False
        self._rows[key] = replace(got, deleted_at=now)
        return True


__all__ = ["MemoryFileStore", "MemorySessionOutputStore", "MemorySnapshotStore"]
