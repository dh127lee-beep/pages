"""메모리 구현 공통.

**`deepcopy`로 격리한다.** 참조를 그대로 돌려주면 테스트가 SQL 구현에서는 못 하는 일
(저장된 객체를 밖에서 수정)을 통과시킨다 — 그러면 계약 테스트가 거짓말을 한다.

도메인 타입은 `frozen=True`지만 `tuple` 안의 가변 객체나 향후 추가될 필드까지
보장하지는 못하므로, 경계에서 한 번 복사한다.
"""

from __future__ import annotations

import copy
from collections.abc import Callable
from datetime import datetime

from ma_store._results import Cursor, ListQuery, Page


def isolate[T](value: T) -> T:
    return copy.deepcopy(value)


def partition_key(workspace_id: str, resource_id: str) -> tuple[str, str]:
    """워크스페이스 교차 조회를 구조적으로 막는다."""
    return (workspace_id, resource_id)


def paginate[T](
    items: list[T],
    q: ListQuery,
    *,
    created_at: Callable[[T], datetime],
    ident: Callable[[T], str],
) -> Page[T]:
    """`(created_at, id)` 커서. SQL 인덱스 순서와 같아야 한다."""
    ordered = sorted(items, key=lambda x: (created_at(x), ident(x)))
    if q.created_at_gte is not None:
        ordered = [x for x in ordered if created_at(x) >= q.created_at_gte]
    if q.created_at_lte is not None:
        ordered = [x for x in ordered if created_at(x) <= q.created_at_lte]
    if q.after is not None:
        cut = (q.after.created_at, q.after.id)
        ordered = [x for x in ordered if (created_at(x), ident(x)) > cut]
    window = ordered[: q.limit]
    nxt = None
    if len(ordered) > q.limit:
        last = window[-1]
        nxt = Cursor(created_at(last), ident(last))
    return Page(items=tuple(isolate(x) for x in window), next_cursor=nxt)
