"""MemoryEnvironmentStore — `agents` 와 **같은 버전 관리 모양**.

`plan/05-database.md` §3 G3.

환경이 버전 관리되는 이유: 세션이 **생성 시점의 환경**에 핀된다. 환경을
좁혀도(allowed_hosts 를 줄여도) 돌고 있는 세션은 옛 설정으로 끝난다 —
그래야 중간에 규칙이 바뀌어 세션이 알 수 없는 이유로 깨지지 않는다.

> 그 대신 **좁힌 것이 즉시 적용되지 않는다.** 급하면 세션을 끊어야
> 한다 (`session.interrupt`).
"""

from __future__ import annotations

from dataclasses import replace

from ma_domain.environments import EnvironmentRecord
from ma_store._results import (
    Archived,
    ArchiveResult,
    ListQuery,
    NotFound,
    Page,
    Replaced,
    ReplaceResult,
    VersionConflict,
)
from ma_store.environments import (
    ArchiveEnvironment,
    FindCurrentEnvironment,
    FindEnvironmentVersion,
    InsertEnvironment,
    ReplaceEnvironment,
)

from ma_store_memory._base import isolate, paginate, partition_key


class MemoryEnvironmentStore:
    def __init__(self) -> None:
        self._current: dict[tuple[str, str], EnvironmentRecord] = {}
        self._versions: dict[tuple[str, str, int], EnvironmentRecord] = {}

    async def insert(self, cmd: InsertEnvironment) -> EnvironmentRecord:
        key = partition_key(cmd.workspace_id, cmd.id)
        if key in self._current:
            raise ValueError(f"이미 있는 환경: {cmd.id}")
        rec = EnvironmentRecord(
            id=cmd.id,
            workspace_id=cmd.workspace_id,
            name=cmd.name,
            config=cmd.config,
            version=1,
            created_at=cmd.now,
            updated_at=cmd.now,
        )
        self._current[key] = rec
        self._versions[(*key, 1)] = rec
        return isolate(rec)

    async def find_current(self, q: FindCurrentEnvironment) -> EnvironmentRecord | None:
        rec = self._current.get(partition_key(q.workspace_id, q.id))
        if rec is None:
            return None
        if rec.is_archived and not q.include_archived:
            return None
        return isolate(rec)

    async def find_version(self, q: FindEnvironmentVersion) -> EnvironmentRecord | None:
        rec = self._versions.get((q.workspace_id, q.id, q.version))
        return isolate(rec) if rec else None

    async def replace_current(self, cmd: ReplaceEnvironment) -> ReplaceResult[EnvironmentRecord]:
        key = partition_key(cmd.workspace_id, cmd.id)
        cur = self._current.get(key)
        if cur is None or cur.is_archived:
            return NotFound()
        if cur.version != cmd.expected_version:
            return VersionConflict(actual_version=cur.version)
        nxt = replace(
            cur,
            name=cmd.name,
            config=cmd.config,
            version=cur.version + 1,
            updated_at=cmd.now,
        )
        self._current[key] = nxt
        self._versions[(*key, nxt.version)] = nxt
        return Replaced(record=isolate(nxt))

    async def archive_current(self, cmd: ArchiveEnvironment) -> ArchiveResult[EnvironmentRecord]:
        key = partition_key(cmd.workspace_id, cmd.id)
        cur = self._current.get(key)
        if cur is None or cur.is_archived:
            return NotFound()
        if cur.version != cmd.expected_version:
            return VersionConflict(actual_version=cur.version)
        nxt = replace(cur, archived_at=cmd.now, updated_at=cmd.now)
        self._current[key] = nxt
        return Archived(record=isolate(nxt))

    async def list_current(self, q: ListQuery) -> Page[EnvironmentRecord]:
        items = [
            r
            for (ws, _), r in self._current.items()
            if ws == q.workspace_id and (q.include_archived or not r.is_archived)
        ]
        return paginate(items, q, created_at=lambda r: r.created_at, ident=lambda r: r.id)


__all__ = ["MemoryEnvironmentStore"]
