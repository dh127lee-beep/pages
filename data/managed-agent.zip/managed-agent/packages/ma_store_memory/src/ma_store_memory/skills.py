"""스킬 — 메모리 구현. `agents` 와 같은 CAS 모양."""

from __future__ import annotations

from dataclasses import replace

from ma_domain.ids import SkillId, WorkspaceId
from ma_domain.skills import SkillRecord
from ma_store._results import (
    Archived,
    ArchiveResult,
    ListQuery,
    NotFound,
    Page,
    Replaced,
    ReplaceResult,
    VersionConflict,
)
from ma_store.skills import (
    ArchiveSkill,
    FindCurrentSkill,
    FindSkillVersion,
    InsertSkill,
    InsertSkillResult,
    ReplaceSkill,
    SlugTaken,
)

from ma_store_memory._base import isolate, paginate, partition_key


class MemorySkillStore:
    def __init__(self) -> None:
        self._current: dict[tuple[str, str], SkillRecord] = {}
        #: `(ws, id, version)` → 그 시점 레코드.
        self._versions: dict[tuple[str, str, int], SkillRecord] = {}

    async def insert(self, cmd: InsertSkill) -> InsertSkillResult:
        taken = await self.find_by_slug(cmd.workspace_id, cmd.slug)
        if taken is not None:
            return SlugTaken(slug=cmd.slug)
        made = SkillRecord(
            id=cmd.id,
            workspace_id=cmd.workspace_id,
            name=cmd.name,
            slug=cmd.slug,
            document=cmd.document,
            version=1,
            created_at=cmd.now,
            updated_at=cmd.now,
        )
        self._current[partition_key(cmd.workspace_id, cmd.id)] = made
        self._versions[(cmd.workspace_id, cmd.id, 1)] = made
        return isolate(made)

    async def find_current(self, q: FindCurrentSkill) -> SkillRecord | None:
        got = self._current.get(partition_key(q.workspace_id, q.id))
        if got is None:
            return None
        if got.is_archived and not q.include_archived:
            return None
        return isolate(got)

    async def find_version(self, q: FindSkillVersion) -> SkillRecord | None:
        got = self._versions.get((q.workspace_id, q.id, q.version))
        return isolate(got) if got else None

    async def find_by_slug(self, workspace_id: WorkspaceId, slug: str) -> SkillRecord | None:
        for (ws, _), rec in sorted(self._current.items()):
            if ws == workspace_id and rec.slug == slug and not rec.is_archived:
                return isolate(rec)
        return None

    async def replace_current(self, cmd: ReplaceSkill) -> ReplaceResult[SkillRecord]:
        key = partition_key(cmd.workspace_id, cmd.id)
        got = self._current.get(key)
        if got is None or got.is_archived:
            return NotFound()
        if got.version != cmd.expected_version:
            return VersionConflict(actual_version=got.version)
        made = replace(
            got,
            name=cmd.name,
            slug=cmd.slug,
            document=cmd.document,
            version=got.version + 1,
            updated_at=cmd.now,
        )
        self._current[key] = made
        self._versions[(cmd.workspace_id, cmd.id, made.version)] = made
        return Replaced(record=isolate(made))

    async def archive(self, cmd: ArchiveSkill) -> ArchiveResult[SkillRecord]:
        key = partition_key(cmd.workspace_id, cmd.id)
        got = self._current.get(key)
        if got is None or got.is_archived:
            return NotFound()
        if got.version != cmd.expected_version:
            return VersionConflict(actual_version=got.version)
        made = replace(got, archived_at=cmd.now, updated_at=cmd.now)
        self._current[key] = made
        return Archived(record=isolate(made))

    async def list_skills(self, q: ListQuery) -> Page[SkillRecord]:
        rows = [
            r
            for (ws, _), r in self._current.items()
            if ws == q.workspace_id and (q.include_archived or not r.is_archived)
        ]
        return paginate(rows, q, created_at=lambda r: r.created_at, ident=lambda r: r.id)

    async def find_many(
        self, workspace_id: WorkspaceId, ids: tuple[SkillId, ...]
    ) -> tuple[SkillRecord, ...]:
        wanted = set(ids)
        rows = [
            r
            for (ws, sid), r in self._current.items()
            if ws == workspace_id and sid in wanted and not r.is_archived
        ]
        # **slug 순으로 돌려준다.** 카탈로그가 이것을 그대로 쓰면
        # 호출마다 같은 문자열이 나온다 (D12b).
        rows.sort(key=lambda r: r.slug)
        return tuple(isolate(r) for r in rows)


__all__ = ["MemorySkillStore"]
