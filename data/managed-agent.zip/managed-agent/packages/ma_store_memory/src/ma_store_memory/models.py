"""MemoryModelCardStore — SQL 구현과 같은 계약.

`archive`가 **지우지 않는다**는 성질까지 같아야 한다. 과거 세션이 카드를
참조하므로, 지우면 "그 세션이 어떤 모델로 돌았는가"를 답할 수 없다.
"""

from __future__ import annotations

from dataclasses import replace
from datetime import datetime

from ma_domain.ids import ModelCardId, WorkspaceId
from ma_domain.models import ModelCard
from ma_store._results import Cursor, ListQuery, Page
from ma_store.models import UpsertModelCard

from ma_store_memory._base import isolate


class MemoryModelCardStore:
    def __init__(self) -> None:
        self._rows: list[ModelCard] = []
        self._archived: set[tuple[str, str]] = set()

    def _index_of(self, workspace_id: WorkspaceId, card_id: ModelCardId) -> int | None:
        for i, c in enumerate(self._rows):
            if c.workspace_id == workspace_id and c.id == card_id:
                return i
        return None

    async def upsert(self, cmd: UpsertModelCard) -> ModelCard:
        idx = self._index_of(cmd.card.workspace_id, cmd.card.id)
        if idx is None:
            self._rows.append(cmd.card)
        else:
            self._rows[idx] = cmd.card
        self._archived.discard((cmd.card.workspace_id, cmd.card.id))
        return isolate(cmd.card)

    async def find(self, workspace_id: WorkspaceId, card_id: ModelCardId) -> ModelCard | None:
        idx = self._index_of(workspace_id, card_id)
        if idx is None:
            return None
        card = self._rows[idx]
        if (workspace_id, card_id) in self._archived:
            card = replace(card, enabled=False)
        return isolate(card)

    async def list_enabled(self, q: ListQuery) -> Page[ModelCard]:
        items = sorted(
            (
                c
                for c in self._rows
                if c.workspace_id == q.workspace_id
                and c.enabled
                and (c.workspace_id, c.id) not in self._archived
            ),
            key=lambda c: c.id,
        )
        if isinstance(q.after, Cursor):
            items = [c for c in items if c.id > q.after.id]
        window = items[: q.limit]
        nxt = Cursor(datetime.min, window[-1].id) if len(items) > q.limit else None
        return Page(items=tuple(isolate(c) for c in window), next_cursor=nxt)

    async def archive(self, workspace_id: WorkspaceId, card_id: ModelCardId, now: datetime) -> bool:
        key = (workspace_id, card_id)
        if self._index_of(workspace_id, card_id) is None or key in self._archived:
            return False
        self._archived.add(key)
        return True


__all__ = ["MemoryModelCardStore"]
