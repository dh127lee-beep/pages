"""메모리 이벤트 저장소 — SQL 구현과 **같은 계약**.

SQL 쪽이 advisory lock 과 유니크 인덱스로 지키는 것을 여기서는 코드가 지킨다:

- `seq`는 promote·append 시점의 `max_seq + 1` (구멍 없음)
- 같은 `id`로 두 번 올리면 두 번째는 기존 것을 돌려준다 (멱등)
- 취소된 pending 은 올라가지 않는다

계약 테스트가 두 구현에 같은 시나리오를 돌려 차이를 잡는다.
"""

from __future__ import annotations

import itertools
from dataclasses import replace
from datetime import datetime

from ma_domain.events import PendingEvent, SessionEvent
from ma_domain.executions import ExecutionScope
from ma_domain.ids import EventId, ExecutionId, SessionId, ThreadId, WorkspaceId
from ma_store._results import NotFound, VersionConflict
from ma_store.events import AdmitEvents, AdmitResult, Admitted, PromoteEvent, ReadEvents
from ma_store.executions import AdmitExecution

from ma_store_memory._base import isolate


class MemorySessionEventStore:
    def __init__(
        self,
        pending: MemoryPendingEventStore | None = None,
        sessions: object | None = None,
        executions: object | None = None,
    ) -> None:
        self._rows: list[SessionEvent] = []
        #: promote 는 pending 큐를 함께 건드린다. 같은 인스턴스를 공유해야 한다.
        self.pending = pending if pending is not None else MemoryPendingEventStore()
        #: `admit` 은 세션 revision 과 outbox 를 함께 건드린다.
        self.sessions = sessions
        self.executions = executions

    async def admit(self, cmd: AdmitEvents) -> AdmitResult:
        """SQL 과 **같은 원자성**을 흉내낸다 — 지면 아무것도 남기지 않는다.

        메모리에는 트랜잭션이 없으므로 **CAS 를 먼저 검사하고**, 통과한 뒤에만
        쓴다. 순서가 곧 원자성이다.
        """
        if self.sessions is None or self.executions is None:
            raise RuntimeError("admit 에는 sessions·executions Store 가 필요하다")

        now = cmd.now or (cmd.events[0].enqueued_at if cmd.events else None)
        if now is None:
            raise ValueError("admit 에는 now 가 필요하다")

        bumped = await self.sessions.bump_revision(  # type: ignore[attr-defined]
            cmd.workspace_id, cmd.session_id, cmd.expected_revision, now
        )
        if bumped is None:
            rec = await self.sessions.find_raw(cmd.workspace_id, cmd.session_id)  # type: ignore[attr-defined]
            if rec is None:
                return NotFound()
            return VersionConflict(actual_version=rec.revision)

        # 인터럽트가 **먼저**다 — 이 요청의 이벤트를 넣기 전에 접는다 (SQL 과 동일)
        for lane in cmd.interrupt_lanes:
            await self.executions.request_interrupt(  # type: ignore[attr-defined]
                ExecutionScope(
                    workspace_id=cmd.workspace_id, session_id=cmd.session_id, lane_id=lane
                ),
                now,
            )
            await self.pending.cancel_lane(cmd.workspace_id, cmd.session_id, lane, now)

        for e in cmd.events:
            await self.pending.enqueue(e)

        for lane, execution_id, event_ids in cmd.lane_batches:
            await self.executions.admit(  # type: ignore[attr-defined]
                AdmitExecution(
                    scope=ExecutionScope(
                        workspace_id=cmd.workspace_id, session_id=cmd.session_id, lane_id=lane
                    ),
                    execution_id=ExecutionId(execution_id),
                    event_ids=event_ids,
                    now=now,
                    trace_context=cmd.trace_context,
                )
            )

        return Admitted(accepted=tuple(e.id for e in cmd.events), revision=bumped)

    def _scoped(self, workspace_id: WorkspaceId, session_id: SessionId) -> list[SessionEvent]:
        return [
            e for e in self._rows if e.workspace_id == workspace_id and e.session_id == session_id
        ]

    async def max_seq(self, workspace_id: WorkspaceId, session_id: SessionId) -> int:
        seqs = [e.seq for e in self._scoped(workspace_id, session_id) if e.seq is not None]
        return max(seqs) if seqs else -1

    async def append(self, event: SessionEvent, *, generation: int) -> SessionEvent:
        seq = await self.max_seq(event.workspace_id, event.session_id) + 1
        stored = replace(event, seq=seq, generation=generation)
        self._rows.append(stored)
        return isolate(stored)

    async def promote(self, cmd: PromoteEvent) -> SessionEvent | None:
        existing = await self.find_by_id(cmd.workspace_id, cmd.session_id, cmd.event_id)
        if existing is not None:
            # 이미 올라가 있다 — 뒷정리만 하고 기존 것을 돌려준다 (멱등)
            await self.pending.delete(cmd.workspace_id, cmd.session_id, cmd.event_id)
            return existing

        p = await self.pending.find_by_id(cmd.workspace_id, cmd.session_id, cmd.event_id)
        if p is None or p.is_cancelled:
            return None

        seq = await self.max_seq(cmd.workspace_id, cmd.session_id) + 1
        stored = p.promote(seq=seq, generation=cmd.generation, at=cmd.now)
        self._rows.append(stored)
        await self.pending.delete(cmd.workspace_id, cmd.session_id, cmd.event_id)
        return isolate(stored)

    async def read(self, q: ReadEvents) -> tuple[SessionEvent, ...]:
        rows = self._scoped(q.workspace_id, q.session_id)
        if q.after_seq is not None:
            rows = [e for e in rows if e.seq is not None and e.seq > q.after_seq]
        if q.thread_id is not None:
            rows = [e for e in rows if e.thread_id == q.thread_id]
        rows.sort(key=lambda e: e.seq if e.seq is not None else -1)
        return tuple(isolate(e) for e in rows[: q.limit])

    async def find_by_id(
        self, workspace_id: WorkspaceId, session_id: SessionId, event_id: EventId
    ) -> SessionEvent | None:
        for e in self._scoped(workspace_id, session_id):
            if e.id == event_id:
                return isolate(e)
        return None


class MemoryPendingEventStore:
    def __init__(self) -> None:
        self._rows: list[PendingEvent] = []
        self._seq = itertools.count(1)

    def _index_of(
        self, workspace_id: WorkspaceId, session_id: SessionId, event_id: EventId
    ) -> int | None:
        for i, p in enumerate(self._rows):
            if p.workspace_id == workspace_id and p.session_id == session_id and p.id == event_id:
                return i
        return None

    async def enqueue(self, event: PendingEvent) -> PendingEvent:
        idx = self._index_of(event.workspace_id, event.session_id, event.id)
        if idx is not None:
            return isolate(self._rows[idx])
        stored = replace(event, pending_seq=next(self._seq))
        self._rows.append(stored)
        return isolate(stored)

    async def peek(
        self,
        workspace_id: WorkspaceId,
        session_id: SessionId,
        thread_id: ThreadId,
        limit: int = 50,
    ) -> tuple[PendingEvent, ...]:
        rows = [
            p
            for p in self._rows
            if p.workspace_id == workspace_id
            and p.session_id == session_id
            and p.thread_id == thread_id
            and not p.is_cancelled
        ]
        rows.sort(key=lambda p: p.pending_seq)
        return tuple(isolate(p) for p in rows[:limit])

    async def delete(
        self, workspace_id: WorkspaceId, session_id: SessionId, event_id: EventId
    ) -> bool:
        idx = self._index_of(workspace_id, session_id, event_id)
        if idx is None:
            return False
        del self._rows[idx]
        return True

    async def cancel_lane(
        self,
        workspace_id: WorkspaceId,
        session_id: SessionId,
        thread_id: ThreadId,
        now: datetime,
    ) -> int:
        n = 0
        for i, p in enumerate(self._rows):
            if (
                p.workspace_id == workspace_id
                and p.session_id == session_id
                and p.thread_id == thread_id
                and not p.is_cancelled
            ):
                self._rows[i] = replace(p, cancelled_at=now)
                n += 1
        return n

    async def find_by_id(
        self, workspace_id: WorkspaceId, session_id: SessionId, event_id: EventId
    ) -> PendingEvent | None:
        idx = self._index_of(workspace_id, session_id, event_id)
        return isolate(self._rows[idx]) if idx is not None else None


__all__ = ["MemoryPendingEventStore", "MemorySessionEventStore"]
