"""메모리 승인 저장소. **SQL 과 같은 계약을 통과한다.**

`plan/05-database.md` §3 G10 · `plan/09-codebase.md` §6.
"""

from __future__ import annotations

from dataclasses import replace
from datetime import datetime
from decimal import Decimal
from typing import TYPE_CHECKING

from ma_domain.governance import (
    Approval,
    ApprovalPolicy,
    ApprovalState,
    AuditEntry,
    Budget,
    BudgetPeriod,
    BudgetScope,
    UsageEvent,
)
from ma_domain.ids import ApprovalId, SessionId, WorkspaceId
from ma_store._results import Cursor, Page

from ma_store_memory._base import isolate, paginate, partition_key

if TYPE_CHECKING:
    from ma_store._results import ListQuery
    from ma_store.governance import DecideApproval


class MemoryApprovalStore:
    def __init__(self) -> None:
        self._rows: dict[tuple[str, str], Approval] = {}

    async def insert(self, approval: Approval) -> Approval:
        # **한 호출에 승인은 하나** — SQL 의 유니크 인덱스와 같은 규칙.
        existing = await self.find_by_tool_call(
            approval.workspace_id, approval.session_id, approval.tool_call_id
        )
        if existing is not None:
            return isolate(existing)
        self._rows[partition_key(approval.workspace_id, approval.id)] = approval
        return isolate(approval)

    async def find(self, workspace_id: WorkspaceId, approval_id: ApprovalId) -> Approval | None:
        got = self._rows.get(partition_key(workspace_id, approval_id))
        return isolate(got) if got is not None else None

    async def find_by_tool_call(
        self, workspace_id: WorkspaceId, session_id: SessionId, tool_call_id: str
    ) -> Approval | None:
        for (ws, _), a in sorted(self._rows.items()):
            if ws == workspace_id and a.session_id == session_id and a.tool_call_id == tool_call_id:
                return isolate(a)
        return None

    async def decide(self, cmd: DecideApproval) -> Approval | None:
        """**한 번의 결정은 한 표다.** 상태 전이는 호출자가 정한다.

        `required_approvals` 를 아는 것은 정책 레이어이고, Store 는
        "표를 더한다"까지만 한다 — 두 곳이 그 수를 알면 어긋난다.
        """
        key = partition_key(cmd.workspace_id, cmd.approval_id)
        got = self._rows.get(key)
        if got is None or got.state is not ApprovalState.PENDING:
            return None
        if cmd.decided_by in got.decided_by:
            return None

        votes = (*got.decided_by, cmd.decided_by)
        updated = replace(
            got,
            decided_by=votes,
            decided_at=cmd.now,
            reason=cmd.reason if cmd.reason is not None else got.reason,
            # 거부는 **한 표로 끝난다** — 반대가 하나라도 있으면 진행하지
            # 않는 것이 fail-closed 다. 승인만 수를 센다.
            state=ApprovalState.PENDING if cmd.approve else ApprovalState.DENIED,
        )
        self._rows[key] = updated
        return isolate(updated)

    async def finalize(
        self, workspace_id: WorkspaceId, approval_id: ApprovalId, now: datetime
    ) -> Approval | None:
        """표가 다 찼을 때 `approved` 로 올린다. 정책 레이어가 부른다."""
        key = partition_key(workspace_id, approval_id)
        got = self._rows.get(key)
        if got is None or got.state is not ApprovalState.PENDING or not got.decided_by:
            return None
        updated = replace(got, state=ApprovalState.APPROVED, decided_at=now)
        self._rows[key] = updated
        return isolate(updated)

    async def expire_due(self, workspace_id: WorkspaceId, now: datetime) -> int:
        count = 0
        for key, a in list(self._rows.items()):
            if key[0] != workspace_id or not a.is_expired(now):
                continue
            # **만료는 결정자가 없다.** 도메인 불변식이 `approved`/`denied`
            # 에만 결정자를 요구하므로 `expired` 는 비워 둘 수 있다.
            self._rows[key] = replace(a, state=ApprovalState.EXPIRED, decided_at=now)
            count += 1
        return count

    async def list_inbox(self, q: ListQuery, state: ApprovalState) -> Page[Approval]:
        rows = [a for (ws, _), a in self._rows.items() if ws == q.workspace_id and a.state is state]
        return paginate(rows, q, created_at=lambda a: a.requested_at, ident=lambda a: a.id)


class MemoryApprovalPolicyStore:
    def __init__(self) -> None:
        self._rows: dict[tuple[str, str], ApprovalPolicy] = {}

    async def upsert(self, policy: ApprovalPolicy) -> ApprovalPolicy:
        self._rows[partition_key(policy.workspace_id, policy.id)] = policy
        return isolate(policy)

    async def list_policies(self, workspace_id: WorkspaceId) -> tuple[ApprovalPolicy, ...]:
        rows = [p for (ws, _), p in self._rows.items() if ws == workspace_id]
        # SQL 과 **같은 순서** — priority 내림차순, 그다음 id.
        rows.sort(key=lambda p: (-p.priority, p.id))
        return tuple(isolate(p) for p in rows)

    async def delete(self, workspace_id: WorkspaceId, policy_id: str) -> bool:
        return self._rows.pop(partition_key(workspace_id, policy_id), None) is not None


class MemoryAuditStore:
    """append-only. **수정·삭제 메서드가 없다** — 인터페이스가 그것을 막는다.

    메모리 구현이라 리스트에 더하기만 하면 되지만, 그래서 더 조심한다:
    SQL 쪽은 DB 권한이 막아 주고 여기는 **코드가 유일한 보장**이다.
    """

    def __init__(self) -> None:
        self._rows: list[AuditEntry] = []

    async def append(self, entry: AuditEntry) -> None:
        self._rows.append(entry)

    async def list_entries(self, q: ListQuery) -> Page[AuditEntry]:
        rows = [e for e in self._rows if e.workspace_id == q.workspace_id]
        # 감사는 **최신이 먼저**다. 다른 목록과 반대 — 조사는 지금부터
        # 거슬러 올라간다.
        rows.sort(key=lambda e: (e.created_at, _ident(e)), reverse=True)
        if q.created_at_gte is not None:
            rows = [e for e in rows if e.created_at >= q.created_at_gte]
        if q.created_at_lte is not None:
            rows = [e for e in rows if e.created_at <= q.created_at_lte]
        if q.after is not None:
            cut = (q.after.created_at, q.after.id)
            rows = [e for e in rows if (e.created_at, _ident(e)) < cut]
        window = rows[: q.limit]
        nxt = None
        if len(rows) > q.limit and window:
            last = window[-1]
            nxt = Cursor(last.created_at, _ident(last))
        return Page(items=tuple(isolate(e) for e in window), next_cursor=nxt)

    async def list_for_session(
        self, workspace_id: WorkspaceId, session_id: SessionId
    ) -> tuple[AuditEntry, ...]:
        rows = [
            e for e in self._rows if e.workspace_id == workspace_id and e.session_id == session_id
        ]
        # 타임라인은 **오래된 것부터**다 — 이야기를 처음부터 읽는다.
        rows.sort(key=lambda e: (e.created_at, _ident(e)))
        return tuple(isolate(e) for e in rows)


def _ident(entry: AuditEntry) -> str:
    """감사 항목에는 공개 id 가 없다 (BIGSERIAL 은 DB 안의 것).

    커서를 위해 **같은 시각의 항목을 가를 안정적인 키**를 만든다.
    SQL 은 `id` 를 쓰고 메모리는 이것을 쓰는데, 둘은 순서만 같으면 된다 —
    커서 값 자체는 클라이언트에게 불투명하다.
    """
    return f"{entry.action}:{entry.resource_id}:{entry.actor_id}"


class MemoryBudgetStore:
    def __init__(self) -> None:
        self._rows: dict[tuple[str, str, str, str], Budget] = {}

    @staticmethod
    def _key(b: Budget) -> tuple[str, str, str, str]:
        # `scope_id` 가 None 인 것도 유일해야 한다 — SQL 의
        # `COALESCE(scope_id, '')` 유니크 인덱스와 같은 규칙.
        return (b.workspace_id, b.scope.value, b.scope_id or "", b.period.value)

    async def upsert(self, budget: Budget) -> Budget:
        self._rows[self._key(budget)] = budget
        return isolate(budget)

    async def find(
        self,
        workspace_id: WorkspaceId,
        scope: BudgetScope,
        scope_id: str | None,
        period: BudgetPeriod,
    ) -> Budget | None:
        got = self._rows.get((workspace_id, scope.value, scope_id or "", period.value))
        return isolate(got) if got is not None else None

    async def list_budgets(self, workspace_id: WorkspaceId) -> tuple[Budget, ...]:
        rows = [b for k, b in self._rows.items() if k[0] == workspace_id]
        rows.sort(key=lambda b: (b.scope.value, b.scope_id or "", b.period.value))
        return tuple(isolate(b) for b in rows)


class MemoryUsageStore:
    """append-only. **비용 기록은 감사의 일부다** — 고치는 메서드가 없다."""

    def __init__(self) -> None:
        self._rows: list[UsageEvent] = []

    async def record(self, event: UsageEvent) -> None:
        self._rows.append(event)

    async def sum_cost_cents(
        self,
        workspace_id: WorkspaceId,
        since: datetime,
        until: datetime,
        agent_id: str | None = None,
    ) -> Decimal:
        total = Decimal(0)
        for e in self._rows:
            if e.workspace_id != workspace_id or not since <= e.created_at < until:
                continue
            if agent_id is not None and e.agent_id != agent_id:
                continue
            total += e.list_cost_cents
        return total

    async def list_events(self, q: ListQuery) -> Page[UsageEvent]:
        rows = [e for e in self._rows if e.workspace_id == q.workspace_id]
        if q.created_at_gte is not None:
            rows = [e for e in rows if e.created_at >= q.created_at_gte]
        if q.created_at_lte is not None:
            rows = [e for e in rows if e.created_at <= q.created_at_lte]
        rows.sort(key=lambda e: (e.created_at, e.session_id), reverse=True)
        if q.after is not None:
            cut = (q.after.created_at, q.after.id)
            rows = [e for e in rows if (e.created_at, e.session_id) < cut]
        window = rows[: q.limit]
        nxt = None
        if len(rows) > q.limit and window:
            nxt = Cursor(window[-1].created_at, window[-1].session_id)
        return Page(items=tuple(isolate(e) for e in window), next_cursor=nxt)


__all__ = [
    "MemoryApprovalPolicyStore",
    "MemoryApprovalStore",
    "MemoryAuditStore",
    "MemoryBudgetStore",
    "MemoryUsageStore",
]
