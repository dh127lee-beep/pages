"""메모리 스토어 — **SQL 이 진실이고 샌드박스에는 사본이 간다** (D10).

`plan/02-architecture.md` §9 · `plan/05-database.md` §3 G7.

CAS 는 `content_sha256` precondition 으로 한다. 버전 번호가 아니라 내용
해시인 이유: 동기화가 **파일시스템 디프**에서 오기 때문이다 — 워커는
"내가 읽었을 때 이 내용이었다"는 알지만 그때의 revision 번호는 모른다.
"""

from __future__ import annotations

import hashlib
from dataclasses import replace
from datetime import datetime

from ma_domain.ids import MemoryId, MemoryStoreId, MemoryVersionId, WorkspaceId
from ma_domain.memory import Memory, MemoryVersion
from ma_domain.memory import MemoryStore as MemoryStoreEntity
from ma_store._results import Cursor, ListQuery, NotFound, Page, VersionConflict
from ma_store.memory import (
    InsertMemoryStore,
    PathConflict,
    WriteMemory,
    WriteMemoryResult,
    WrittenMemory,
)

from ma_store_memory._base import isolate, paginate, partition_key


def sha256_of(content: str) -> str:
    return hashlib.sha256(content.encode("utf-8")).hexdigest()


class MemoryStoreStore:
    def __init__(self) -> None:
        self._rows: dict[tuple[str, str], MemoryStoreEntity] = {}

    async def insert(self, cmd: InsertMemoryStore) -> MemoryStoreEntity:
        # slug 충돌은 **두 스토어가 같은 곳에 마운트되는 것**이다.
        existing = await self.find_by_slug(cmd.workspace_id, cmd.slug)
        if existing is not None:
            raise ValueError(f"이미 쓰이는 slug: {cmd.slug}")
        made = MemoryStoreEntity(
            id=cmd.id,
            workspace_id=cmd.workspace_id,
            name=cmd.name,
            slug=cmd.slug,
            revision=0,
            created_at=cmd.now,
        )
        self._rows[partition_key(cmd.workspace_id, cmd.id)] = made
        return isolate(made)

    async def find(
        self, workspace_id: WorkspaceId, store_id: MemoryStoreId
    ) -> MemoryStoreEntity | None:
        got = self._rows.get(partition_key(workspace_id, store_id))
        return isolate(got) if got else None

    async def find_by_slug(self, workspace_id: WorkspaceId, slug: str) -> MemoryStoreEntity | None:
        for (ws, _), s in sorted(self._rows.items()):
            if ws == workspace_id and s.slug == slug and s.archived_at is None:
                return isolate(s)
        return None

    async def list_stores(self, q: ListQuery) -> Page[MemoryStoreEntity]:
        rows = [
            s
            for (ws, _), s in self._rows.items()
            if ws == q.workspace_id and (q.include_archived or s.archived_at is None)
        ]
        return paginate(rows, q, created_at=lambda s: s.created_at, ident=lambda s: s.id)

    async def archive(
        self, workspace_id: WorkspaceId, store_id: MemoryStoreId, now: datetime
    ) -> bool:
        key = partition_key(workspace_id, store_id)
        got = self._rows.get(key)
        if got is None or got.archived_at is not None:
            return False
        self._rows[key] = replace(got, archived_at=now)
        return True


class MemoryDocumentStore:
    def __init__(self) -> None:
        self._rows: dict[tuple[str, str], Memory] = {}
        self._versions: dict[tuple[str, str], MemoryVersion] = {}
        self._seq = 0

    async def write(self, cmd: WriteMemory) -> WriteMemoryResult:
        """**CAS 는 내용 해시로 한다.**

        `precondition_sha256` 이
        - `None` 이면 신규 생성 (이미 있으면 `PathConflict`)
        - 값이면 그 해시와 **현재가 같을 때만** 쓴다

        같지 않으면 `VersionConflict` 다 — 다른 세션이 그 사이에 썼다.
        """
        current = await self.find_by_path(cmd.workspace_id, cmd.store_id, cmd.path)

        if cmd.precondition_sha256 is None:
            if current is not None:
                return PathConflict(conflicting_memory_id=current.id)
        else:
            if current is None:
                return NotFound()
            if current.content_sha256 != cmd.precondition_sha256:
                return VersionConflict(actual_version=current.revision)

        digest = sha256_of(cmd.content)
        if current is None:
            memory = Memory(
                id=cmd.id,
                workspace_id=cmd.workspace_id,
                store_id=cmd.store_id,
                path=cmd.path,
                content=cmd.content,
                content_sha256=digest,
                revision=1,
                created_at=cmd.now,
                updated_at=cmd.now,
            )
        else:
            memory = replace(
                current,
                content=cmd.content,
                content_sha256=digest,
                revision=current.revision + 1,
                updated_at=cmd.now,
            )
        self._rows[partition_key(cmd.workspace_id, memory.id)] = memory

        self._seq += 1
        version = MemoryVersion(
            id=MemoryVersionId(f"memv_{self._seq:08d}"),
            workspace_id=cmd.workspace_id,
            store_id=cmd.store_id,
            memory_id=memory.id,
            path=cmd.path,
            content=cmd.content,
            content_sha256=digest,
            author=cmd.author,
            created_at=cmd.now,
        )
        self._versions[partition_key(cmd.workspace_id, version.id)] = version
        return WrittenMemory(memory=isolate(memory), version=isolate(version))

    async def find(self, workspace_id: WorkspaceId, memory_id: MemoryId) -> Memory | None:
        got = self._rows.get(partition_key(workspace_id, memory_id))
        return isolate(got) if got and got.deleted_at is None else None

    async def find_by_path(
        self, workspace_id: WorkspaceId, store_id: MemoryStoreId, path: str
    ) -> Memory | None:
        for (ws, _), m in sorted(self._rows.items()):
            if (
                ws == workspace_id
                and m.store_id == store_id
                and m.path == path
                and m.deleted_at is None
            ):
                return isolate(m)
        return None

    async def list_in_store(self, q: ListQuery, store_id: MemoryStoreId) -> Page[Memory]:
        rows = [
            m
            for (ws, _), m in self._rows.items()
            if ws == q.workspace_id and m.store_id == store_id and m.deleted_at is None
        ]
        # **경로순이다.** materialize 가 디렉터리를 만들며 순회하므로
        # 부모가 먼저 오는 편이 낫고, SQL 인덱스도 경로순이다.
        rows.sort(key=lambda m: m.path)
        window = rows[: q.limit]
        nxt = (
            Cursor(window[-1].created_at, window[-1].id) if len(rows) > q.limit and window else None
        )
        return Page(items=tuple(isolate(m) for m in window), next_cursor=nxt)

    async def delete(self, workspace_id: WorkspaceId, memory_id: MemoryId, now: datetime) -> bool:
        key = partition_key(workspace_id, memory_id)
        got = self._rows.get(key)
        if got is None or got.deleted_at is not None:
            return False
        # **soft delete.** 버전 역사가 참조하고, 감사가 그것을 읽는다.
        self._rows[key] = replace(got, deleted_at=now)
        return True

    async def list_versions(self, q: ListQuery, store_id: MemoryStoreId) -> Page[MemoryVersion]:
        rows = [
            v
            for (ws, _), v in self._versions.items()
            if ws == q.workspace_id and v.store_id == store_id
        ]
        rows.sort(key=lambda v: (v.created_at, v.id), reverse=True)
        window = rows[: q.limit]
        nxt = (
            Cursor(window[-1].created_at, window[-1].id) if len(rows) > q.limit and window else None
        )
        return Page(items=tuple(isolate(v) for v in window), next_cursor=nxt)

    async def redact_version(
        self,
        workspace_id: WorkspaceId,
        version_id: MemoryVersionId,
        by: str,
        now: datetime,
    ) -> bool:
        """**live head 는 거부한다.**

        지금 쓰이고 있는 내용을 지우면 다음 materialize 가 빈 파일을
        만들고, 에이전트는 그것을 "메모리가 비었다"로 읽는다. 지우려면
        먼저 새 내용을 쓰거나 메모리를 삭제해야 한다.
        """
        key = partition_key(workspace_id, version_id)
        version = self._versions.get(key)
        if version is None or version.is_redacted:
            return False

        live = await self.find(workspace_id, version.memory_id)
        if live is not None and live.content_sha256 == version.content_sha256:
            return False

        self._versions[key] = replace(version, content=None, redacted_at=now, redacted_by=by)
        return True


__all__ = ["MemoryDocumentStore", "MemoryStoreStore", "sha256_of"]
