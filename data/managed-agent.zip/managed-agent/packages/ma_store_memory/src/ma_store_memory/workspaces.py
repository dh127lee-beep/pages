"""MemoryApiKeyStore — SQL 구현과 같은 계약."""

from __future__ import annotations

from dataclasses import replace
from datetime import datetime

from ma_domain.ids import ApiKeyId, WorkspaceId
from ma_domain.workspaces import ApiKey
from ma_store._results import Cursor, ListQuery, Page
from ma_store.workspaces import InsertApiKey

from ma_store_memory._base import isolate, paginate


class MemoryApiKeyStore:
    def __init__(self) -> None:
        self._rows: list[ApiKey] = []
        self._hashes: dict[bytes, ApiKeyId] = {}

    def _index_of(self, key_id: ApiKeyId) -> int | None:
        for i, k in enumerate(self._rows):
            if k.id == key_id:
                return i
        return None

    async def insert(self, cmd: InsertApiKey) -> ApiKey:
        key = ApiKey(
            id=cmd.id,
            workspace_id=cmd.workspace_id,
            name=cmd.name,
            key_prefix=cmd.key_prefix,
            role=cmd.role,
            created_by=cmd.created_by,
            created_at=cmd.now,
            expires_at=cmd.expires_at,
        )
        self._rows.append(key)
        self._hashes[cmd.key_hash] = cmd.id
        return isolate(key)

    async def find_by_hash(self, key_hash: bytes) -> ApiKey | None:
        key_id = self._hashes.get(key_hash)
        if key_id is None:
            return None
        idx = self._index_of(key_id)
        return isolate(self._rows[idx]) if idx is not None else None

    async def touch_used(self, key_id: ApiKeyId, now: datetime) -> None:
        idx = self._index_of(key_id)
        if idx is not None:
            self._rows[idx] = replace(self._rows[idx], last_used_at=now)

    async def revoke(self, workspace_id: WorkspaceId, key_id: ApiKeyId, now: datetime) -> bool:
        idx = self._index_of(key_id)
        if idx is None:
            return False
        k = self._rows[idx]
        if k.workspace_id != workspace_id or k.revoked_at is not None:
            return False
        self._rows[idx] = replace(k, revoked_at=now)
        return True

    async def list_keys(self, q: ListQuery) -> Page[ApiKey]:
        items = [k for k in self._rows if k.workspace_id == q.workspace_id]
        after = q.after if isinstance(q.after, Cursor) else None
        return paginate(
            items,
            ListQuery(workspace_id=q.workspace_id, limit=q.limit, after=after),
            created_at=lambda k: k.created_at,
            ident=lambda k: k.id,
        )


__all__ = ["MemoryApiKeyStore"]
