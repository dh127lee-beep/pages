"""MemorySessionStore — 세션은 `version`이 아니라 `revision`으로 CAS한다.

`plan/02-architecture.md` §3 규칙 1.

`bump_revision`/`find_raw`는 **`admit` 전용 내부 경로**다. Protocol 에 없는 이유는
이벤트 수용이 세션 테이블을 건드리는 유일한 곳이고, SQL 에서는 그것이 한
트랜잭션의 첫 문장이기 때문이다 — 메모리는 그 순서를 코드로 흉내낸다.
"""

from __future__ import annotations

from dataclasses import replace
from datetime import datetime

from ma_domain.ids import SessionId, WorkspaceId
from ma_domain.sessions import SessionRecord
from ma_store._results import NotFound, Page, VersionConflict
from ma_store.sessions import (
    AccrueSessionUsage,
    FindSession,
    InsertSession,
    ListSessions,
    SessionUpdateResult,
    UpdatedSession,
    UpdateSessionStatus,
)

from ma_store_memory._base import isolate, paginate


class MemorySessionStore:
    def __init__(self) -> None:
        self._rows: list[SessionRecord] = []

    def _index_of(self, workspace_id: WorkspaceId, session_id: SessionId) -> int | None:
        for i, r in enumerate(self._rows):
            if r.workspace_id == workspace_id and r.id == session_id:
                return i
        return None

    async def insert(self, cmd: InsertSession) -> SessionRecord:
        self._rows.append(cmd.record)
        return isolate(cmd.record)

    async def find(self, q: FindSession) -> SessionRecord | None:
        idx = self._index_of(q.workspace_id, q.id)
        if idx is None:
            return None
        rec = self._rows[idx]
        if rec.is_deleted and not q.include_deleted:
            return None
        return isolate(rec)

    # ── admit 전용 ─────────────────────────────────────────
    async def find_raw(
        self, workspace_id: WorkspaceId, session_id: SessionId
    ) -> SessionRecord | None:
        idx = self._index_of(workspace_id, session_id)
        if idx is None or self._rows[idx].is_deleted:
            return None
        return self._rows[idx]

    async def bump_revision(
        self,
        workspace_id: WorkspaceId,
        session_id: SessionId,
        expected: int,
        now: datetime,
    ) -> int | None:
        """CAS. 맞으면 새 revision, 틀리면 None — **아무것도 쓰지 않는다**."""
        idx = self._index_of(workspace_id, session_id)
        if idx is None:
            return None
        rec = self._rows[idx]
        if rec.is_deleted or rec.revision != expected:
            return None
        self._rows[idx] = replace(
            rec, revision=rec.revision + 1, updated_at=now, last_active_at=now
        )
        return rec.revision + 1

    # ── Protocol ───────────────────────────────────────────
    async def update_status(self, cmd: UpdateSessionStatus) -> SessionUpdateResult:
        idx = self._index_of(cmd.workspace_id, cmd.id)
        if idx is None or self._rows[idx].is_deleted:
            return NotFound()
        rec = self._rows[idx]
        if cmd.expected_revision is not None and rec.revision != cmd.expected_revision:
            return VersionConflict(actual_version=rec.revision)
        updated = replace(
            rec,
            status=cmd.status,
            stop_reason=cmd.stop_reason,
            required_action=cmd.required_action,
            revision=rec.revision + 1,
            updated_at=cmd.now,
            last_active_at=cmd.now,
        )
        self._rows[idx] = updated
        return UpdatedSession(record=isolate(updated))

    async def accrue_usage(self, cmd: AccrueSessionUsage) -> SessionUpdateResult:
        """사용량은 **누적**이다. CAS 하지 않는다 — 두 lane 이 동시에 써도 더해져야 한다."""
        idx = self._index_of(cmd.workspace_id, cmd.id)
        if idx is None or self._rows[idx].is_deleted:
            return NotFound()
        rec = self._rows[idx]
        updated = replace(
            rec,
            usage=rec.usage + cmd.usage,
            budget=(
                replace(rec.budget, spent_cents=rec.budget.spent_cents + cmd.cost_cents)
                if rec.budget
                else None
            ),
            updated_at=cmd.now,
            last_active_at=cmd.now,
        )
        self._rows[idx] = updated
        return UpdatedSession(record=isolate(updated))

    async def archive(
        self, workspace_id: WorkspaceId, session_id: SessionId, now: datetime
    ) -> SessionUpdateResult:
        idx = self._index_of(workspace_id, session_id)
        if idx is None or self._rows[idx].is_deleted:
            return NotFound()
        updated = replace(self._rows[idx], archived_at=now, updated_at=now)
        self._rows[idx] = updated
        return UpdatedSession(record=isolate(updated))

    async def delete(self, workspace_id: WorkspaceId, session_id: SessionId, now: datetime) -> bool:
        idx = self._index_of(workspace_id, session_id)
        if idx is None or self._rows[idx].is_deleted:
            return False
        self._rows[idx] = replace(self._rows[idx], deleted_at=now, updated_at=now)
        return True

    async def list_sessions(self, q: ListSessions) -> Page[SessionRecord]:
        items = [
            r
            for r in self._rows
            if r.workspace_id == q.workspace_id
            and not r.is_deleted
            and (q.status is None or r.status is q.status)
            and (q.agent_id is None or r.agent_id == q.agent_id)
            and (q.created_by is None or r.created_by == q.created_by)
            and (q.created_at_gte is None or r.created_at >= q.created_at_gte)
            and (q.created_at_lte is None or r.created_at <= q.created_at_lte)
        ]
        from ma_store._results import Cursor, ListQuery

        after = q.after if isinstance(q.after, Cursor) else None
        return paginate(
            items,
            ListQuery(workspace_id=q.workspace_id, limit=q.limit, after=after),
            created_at=lambda r: r.created_at,
            ident=lambda r: r.id,
        )


__all__ = ["MemorySessionStore"]
