"""MemoryExecutionStore — SQL 구현과 **같은 계약**을 만족해야 한다.

특히 "같은 lane에 살아 있는 running은 하나"를 메모리에서도 지켜야 한다.
SQL은 부분 유니크 인덱스가 보장하지만, 여기서는 코드가 보장한다 — 계약 테스트가
두 구현에 같은 시나리오를 돌려 차이를 잡는다.
"""

from __future__ import annotations

import itertools
from dataclasses import replace
from datetime import datetime, timedelta
from uuid import UUID

from ma_domain.executions import (
    ExecutionFence,
    ExecutionRecord,
    ExecutionScope,
    ExecutionState,
)
from ma_domain.ids import ExecutionId, WorkerId, WorkspaceId
from ma_store.executions import AdmitExecution, Claimed, ClaimExecution, SettleExecution

from ma_store_memory._base import isolate


class MemoryExecutionStore:
    def __init__(self) -> None:
        self._rows: list[ExecutionRecord] = []
        self._ids = itertools.count(1)

    # ── 내부 ────────────────────────────────────────────────
    def _index_of(self, scope: ExecutionScope, execution_id: ExecutionId) -> int | None:
        for i, r in enumerate(self._rows):
            if r.scope == scope and r.execution_id == execution_id:
                return i
        return None

    def _live_running(self, scope: ExecutionScope, now: datetime) -> bool:
        return any(
            r.scope.workspace_id == scope.workspace_id
            and r.scope.session_id == scope.session_id
            and r.scope.lane_id == scope.lane_id
            and r.state is ExecutionState.RUNNING
            and r.lease_expires_at is not None
            and r.lease_expires_at >= now
            for r in self._rows
        )

    # ── Protocol ───────────────────────────────────────────
    async def admit(self, cmd: AdmitExecution) -> ExecutionRecord:
        idx = self._index_of(cmd.scope, cmd.execution_id)
        if idx is not None:
            return isolate(self._rows[idx])
        rec = ExecutionRecord(
            id=next(self._ids),
            scope=cmd.scope,
            execution_id=cmd.execution_id,
            state=ExecutionState.QUEUED,
            event_ids=cmd.event_ids,
            generation=0,
            created_at=cmd.now,
            deadline_at=cmd.deadline_at,
            trace_context=cmd.trace_context,
        )
        self._rows.append(rec)
        return isolate(rec)

    async def claim(self, cmd: ClaimExecution) -> Claimed | None:
        candidates = [
            (i, r)
            for i, r in enumerate(self._rows)
            if (
                r.state is ExecutionState.QUEUED
                or (
                    r.state is ExecutionState.RUNNING
                    and r.lease_expires_at is not None
                    and r.lease_expires_at < cmd.now
                )
            )
        ]
        if cmd.scope is not None:
            candidates = [(i, r) for i, r in candidates if r.scope == cmd.scope]
        elif cmd.workspace_id is not None:
            candidates = [(i, r) for i, r in candidates if r.scope.workspace_id == cmd.workspace_id]
        # 같은 lane 에 살아 있는 running 이 있으면 건드리지 않는다
        candidates = [(i, r) for i, r in candidates if not self._live_running(r.scope, cmd.now)]
        if not candidates:
            return None
        candidates.sort(key=lambda t: (t[1].created_at, t[1].id))
        idx, rec = candidates[0]

        claimed = replace(
            rec,
            state=ExecutionState.RUNNING,
            generation=rec.generation + 1,
            attempt_id=cmd.attempt_id,
            attempt_count=rec.attempt_count + 1,
            lease_owner=cmd.owner,
            lease_expires_at=cmd.now + cmd.lease_ttl,
            settled_at=None,
        )
        self._rows[idx] = claimed
        return Claimed(
            execution=isolate(claimed),
            fence=ExecutionFence(
                scope=claimed.scope,
                generation=claimed.generation,
                attempt_id=claimed.attempt_id or UUID(int=0),
                owner=claimed.lease_owner or WorkerId(""),
                expires_at=claimed.lease_expires_at or cmd.now,
            ),
        )

    async def renew(self, fence: ExecutionFence, now: datetime, ttl: timedelta) -> bool:
        for i, r in enumerate(self._rows):
            if (
                r.scope == fence.scope
                and r.generation == fence.generation
                and r.state is ExecutionState.RUNNING
            ):
                self._rows[i] = replace(r, lease_expires_at=now + ttl)
                return True
        return False

    async def settle(self, cmd: SettleExecution) -> bool:
        f = cmd.fence
        for i, r in enumerate(self._rows):
            if (
                r.scope == f.scope
                and r.generation == f.generation
                and r.state is ExecutionState.RUNNING
            ):
                self._rows[i] = replace(
                    r,
                    state=cmd.state,
                    settled_at=cmd.now,
                    error=cmd.error,
                    lease_expires_at=None,
                )
                return True
        return False

    async def request_interrupt(self, scope: ExecutionScope, now: datetime) -> int:
        n = 0
        for i, r in enumerate(self._rows):
            if (
                r.scope == scope
                and r.state in (ExecutionState.QUEUED, ExecutionState.RUNNING)
                and r.interrupt_requested_at is None
            ):
                self._rows[i] = replace(r, interrupt_requested_at=now)
                n += 1
        return n

    async def current_generation(self, scope: ExecutionScope) -> int | None:
        gens = [
            r.generation
            for r in self._rows
            if r.scope == scope and r.state is ExecutionState.RUNNING
        ]
        return max(gens) if gens else None

    async def find(
        self, scope: ExecutionScope, execution_id: ExecutionId
    ) -> ExecutionRecord | None:
        idx = self._index_of(scope, execution_id)
        return isolate(self._rows[idx]) if idx is not None else None

    async def queued_count(self, workspace_id: WorkspaceId | None = None) -> int:
        return sum(
            1
            for r in self._rows
            if r.state is ExecutionState.QUEUED
            and (workspace_id is None or r.scope.workspace_id == workspace_id)
        )

    async def reclaim_expired(self, now: datetime, limit: int = 100) -> int:
        n = 0
        for i, r in enumerate(self._rows):
            if n >= limit:
                break
            if (
                r.state is ExecutionState.RUNNING
                and r.lease_expires_at is not None
                and r.lease_expires_at < now
            ):
                self._rows[i] = replace(
                    r, state=ExecutionState.QUEUED, lease_owner=None, lease_expires_at=None
                )
                n += 1
        return n


__all__ = ["MemoryExecutionStore"]
