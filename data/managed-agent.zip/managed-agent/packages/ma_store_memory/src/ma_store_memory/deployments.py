"""배포 — 메모리 구현."""

from __future__ import annotations

from dataclasses import replace
from datetime import datetime

from ma_domain.deployments import (
    Deployment,
    DeploymentRun,
    DeploymentState,
    RunState,
)
from ma_domain.ids import WorkspaceId
from ma_store._results import ListQuery, NotFound, Page
from ma_store.deployments import (
    AlreadyFired,
    ClaimedFire,
    ClaimFire,
    ClaimFireResult,
    FinishRun,
    InsertDeployment,
    UpdateDeploymentState,
)

from ma_store_memory._base import isolate, paginate, partition_key


class MemoryDeploymentStore:
    def __init__(self) -> None:
        self._rows: dict[tuple[str, str], Deployment] = {}
        self._runs: dict[tuple[str, str], DeploymentRun] = {}

    async def insert(self, cmd: InsertDeployment) -> Deployment:
        made = Deployment(
            id=cmd.id,
            workspace_id=cmd.workspace_id,
            name=cmd.name,
            agent_id=cmd.agent_id,
            agent_version=cmd.agent_version,
            state=DeploymentState.ACTIVE,
            created_at=cmd.now,
            updated_at=cmd.now,
            environment_id=cmd.environment_id,
            schedule=cmd.schedule,
            initial_events=tuple(tuple(sorted(e.items())) for e in cmd.initial_events),
            budget_cents=cmd.budget_cents,
            next_fire_at=cmd.next_fire_at,
        )
        self._rows[partition_key(cmd.workspace_id, cmd.id)] = made
        return isolate(made)

    async def find(self, workspace_id: WorkspaceId, deployment_id: str) -> Deployment | None:
        got = self._rows.get(partition_key(workspace_id, deployment_id))
        return isolate(got) if got else None

    async def list_deployments(self, q: ListQuery) -> Page[Deployment]:
        rows = [
            d
            for (ws, _), d in self._rows.items()
            if ws == q.workspace_id
            and (q.include_archived or d.state is not DeploymentState.ARCHIVED)
        ]
        return paginate(rows, q, created_at=lambda d: d.created_at, ident=lambda d: d.id)

    async def set_state(self, cmd: UpdateDeploymentState) -> Deployment | None:
        key = partition_key(cmd.workspace_id, cmd.deployment_id)
        got = self._rows.get(key)
        if got is None:
            return None
        self._rows[key] = replace(
            got,
            state=cmd.state,
            updated_at=cmd.now,
            paused_reason=cmd.reason,
            # **아카이브된 배포는 발화하지 않는다** (DB CHECK 과 같은 불변식).
            next_fire_at=None if cmd.state is not DeploymentState.ACTIVE else cmd.next_fire_at,
            archived_at=cmd.now if cmd.state is DeploymentState.ARCHIVED else got.archived_at,
        )
        return isolate(self._rows[key])

    async def due(self, now: datetime, limit: int = 50) -> tuple[Deployment, ...]:
        rows = [
            d
            for d in self._rows.values()
            if d.state is DeploymentState.ACTIVE
            and d.next_fire_at is not None
            and d.next_fire_at <= now
        ]
        rows.sort(key=lambda d: (d.next_fire_at or now, d.id))
        return tuple(isolate(d) for d in rows[:limit])

    async def claim_fire(self, cmd: ClaimFire) -> ClaimFireResult:
        key = partition_key(cmd.workspace_id, cmd.deployment_id)
        deployment = self._rows.get(key)
        if deployment is None:
            return NotFound()

        # **멱등 키.** 같은 발화를 두 번 집지 않는다.
        for run in self._runs.values():
            if (
                run.workspace_id == cmd.workspace_id
                and run.deployment_id == cmd.deployment_id
                and run.scheduled_for == cmd.scheduled_for
                and run.trigger == cmd.trigger
                and run.trigger.value == "schedule"
            ):
                return AlreadyFired(scheduled_for=cmd.scheduled_for)

        made = DeploymentRun(
            id=cmd.run_id,
            workspace_id=cmd.workspace_id,
            deployment_id=cmd.deployment_id,
            state=RunState.QUEUED,
            trigger=cmd.trigger,
            scheduled_for=cmd.scheduled_for,
            created_at=cmd.now,
            shifted_by=cmd.shifted,
        )
        self._runs[partition_key(cmd.workspace_id, cmd.run_id)] = made
        # **같은 배치에서 다음 발화를 민다.**
        self._rows[key] = replace(
            deployment,
            next_fire_at=cmd.next_fire_at,
            last_run_at=cmd.now,
            updated_at=cmd.now,
        )
        return ClaimedFire(deployment=isolate(self._rows[key]), run=isolate(made))

    async def finish_run(self, cmd: FinishRun) -> DeploymentRun | None:
        key = partition_key(cmd.workspace_id, cmd.run_id)
        got = self._runs.get(key)
        if got is None:
            return None
        self._runs[key] = replace(
            got,
            state=cmd.state,
            session_id=cmd.session_id or got.session_id,
            started_at=got.started_at or cmd.now,
            ended_at=cmd.now if cmd.state.is_final else None,
            error=cmd.error,
            cost_cents=cmd.cost_cents,
        )

        # 연속 실패를 센다 — `AUTO_PAUSE_AFTER` 에서 자동 일시정지한다.
        dep_key = partition_key(cmd.workspace_id, got.deployment_id)
        deployment = self._rows.get(dep_key)
        if deployment is not None and cmd.state.is_final:
            failures = deployment.consecutive_failures + 1 if cmd.state is RunState.FAILED else 0
            self._rows[dep_key] = replace(
                deployment, consecutive_failures=failures, updated_at=cmd.now
            )
        return isolate(self._runs[key])

    async def find_run(self, workspace_id: WorkspaceId, run_id: str) -> DeploymentRun | None:
        got = self._runs.get(partition_key(workspace_id, run_id))
        return isolate(got) if got else None

    async def list_runs(self, q: ListQuery, deployment_id: str) -> Page[DeploymentRun]:
        rows = [
            r
            for (ws, _), r in self._runs.items()
            if ws == q.workspace_id and r.deployment_id == deployment_id
        ]
        return paginate(rows, q, created_at=lambda r: r.created_at, ident=lambda r: r.id)

    async def running_count(self, workspace_id: WorkspaceId, deployment_id: str) -> int:
        return sum(
            1
            for (ws, _), r in self._runs.items()
            if ws == workspace_id and r.deployment_id == deployment_id and not r.state.is_final
        )


__all__ = ["MemoryDeploymentStore"]
