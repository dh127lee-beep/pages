"""MemoryAgentStore — 버전 관리 리소스 메모리 구현의 표준형."""

from __future__ import annotations

from dataclasses import replace

from ma_domain.agents import AgentRecord
from ma_store._results import (
    Archived,
    ArchiveResult,
    ListQuery,
    NotFound,
    Page,
    Replaced,
    ReplaceResult,
    VersionConflict,
)
from ma_store.agents import (
    ArchiveAgent,
    FindAgentVersion,
    FindCurrentAgent,
    InsertAgent,
    ListAgentVersions,
    ReplaceAgent,
)

from ma_store_memory._base import isolate, paginate, partition_key


class MemoryAgentStore:
    """dict 기반. 테스트·로컬 전용."""

    def __init__(self) -> None:
        self._current: dict[tuple[str, str], AgentRecord] = {}
        self._versions: dict[tuple[str, str, int], AgentRecord] = {}

    async def insert(self, cmd: InsertAgent) -> AgentRecord:
        key = partition_key(cmd.workspace_id, cmd.id)
        if key in self._current:
            raise ValueError(f"이미 있는 에이전트: {cmd.id}")
        rec = AgentRecord(
            id=cmd.id,
            workspace_id=cmd.workspace_id,
            definition=cmd.definition,
            version=1,
            created_by=cmd.created_by,
            created_at=cmd.now,
            updated_at=cmd.now,
        )
        self._current[key] = rec
        self._versions[(*key, 1)] = rec
        return isolate(rec)

    async def find_current(self, q: FindCurrentAgent) -> AgentRecord | None:
        rec = self._current.get(partition_key(q.workspace_id, q.id))
        if rec is None:
            return None
        if rec.is_archived and not q.include_archived:
            return None
        return isolate(rec)

    async def find_version(self, q: FindAgentVersion) -> AgentRecord | None:
        rec = self._versions.get((q.workspace_id, q.id, q.version))
        return isolate(rec) if rec else None

    async def replace_current(self, cmd: ReplaceAgent) -> ReplaceResult[AgentRecord]:
        key = partition_key(cmd.workspace_id, cmd.id)
        cur = self._current.get(key)
        if cur is None or cur.is_archived:
            return NotFound()
        if cur.version != cmd.expected_version:
            return VersionConflict(actual_version=cur.version)
        nxt = replace(
            cur,
            definition=cmd.definition,
            version=cur.version + 1,
            updated_at=cmd.now,
        )
        self._current[key] = nxt
        self._versions[(*key, nxt.version)] = nxt
        return Replaced(record=isolate(nxt))

    async def archive_current(self, cmd: ArchiveAgent) -> ArchiveResult[AgentRecord]:
        key = partition_key(cmd.workspace_id, cmd.id)
        cur = self._current.get(key)
        if cur is None or cur.is_archived:
            return NotFound()
        if cur.version != cmd.expected_version:
            return VersionConflict(actual_version=cur.version)
        nxt = replace(cur, archived_at=cmd.now, updated_at=cmd.now)
        self._current[key] = nxt
        return Archived(record=isolate(nxt))

    async def list_current(self, q: ListQuery) -> Page[AgentRecord]:
        items = [
            r
            for (ws, _), r in self._current.items()
            if ws == q.workspace_id and (q.include_archived or not r.is_archived)
        ]
        return paginate(items, q, created_at=lambda r: r.created_at, ident=lambda r: r.id)

    async def list_versions(self, q: ListAgentVersions) -> Page[AgentRecord]:
        items = [
            r for (ws, aid, _), r in self._versions.items() if ws == q.workspace_id and aid == q.id
        ]
        ordered = sorted(items, key=lambda r: r.version, reverse=True)[: q.limit]
        return Page(items=tuple(isolate(r) for r in ordered))
