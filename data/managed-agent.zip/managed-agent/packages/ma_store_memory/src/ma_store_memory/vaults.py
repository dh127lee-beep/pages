"""메모리 VaultStore. **계약 테스트가 SQL 구현과 함께 돈다.**

`plan/09-codebase.md` §6 — 두 구현이 같은 스위트를 통과하는 것이
"런타임 이식성"을 주장이 아니라 사실로 만든다.
"""

from __future__ import annotations

from dataclasses import replace
from datetime import datetime
from typing import TYPE_CHECKING

from ma_domain.ids import VaultId, WorkspaceId
from ma_domain.vaults import Vault

from ma_store_memory._base import isolate, paginate, partition_key

if TYPE_CHECKING:
    from ma_store._results import ListQuery, Page
    from ma_store.vaults import InsertVault


class MemoryVaultStore:
    def __init__(self) -> None:
        self._rows: dict[tuple[str, str], Vault] = {}

    async def insert(self, cmd: InsertVault) -> Vault:
        vault = Vault(
            id=cmd.id,
            workspace_id=cmd.workspace_id,
            name=cmd.name,
            version=1,
            created_at=cmd.now,
        )
        self._rows[partition_key(cmd.workspace_id, cmd.id)] = vault
        return isolate(vault)

    async def find(self, workspace_id: WorkspaceId, vault_id: VaultId) -> Vault | None:
        got = self._rows.get(partition_key(workspace_id, vault_id))
        return isolate(got) if got is not None else None

    async def list_vaults(self, q: ListQuery) -> Page[Vault]:
        rows = [
            v
            for (ws, _), v in self._rows.items()
            if ws == q.workspace_id and (q.include_archived or v.archived_at is None)
        ]
        return paginate(rows, q, created_at=lambda v: v.created_at, ident=lambda v: v.id)

    async def archive(self, workspace_id: WorkspaceId, vault_id: VaultId, now: datetime) -> bool:
        key = partition_key(workspace_id, vault_id)
        got = self._rows.get(key)
        if got is None or got.archived_at is not None:
            return False
        self._rows[key] = replace(got, archived_at=now)
        return True


__all__ = ["MemoryVaultStore"]
