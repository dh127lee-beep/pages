"""웹훅 — 메모리 구현.

**시크릿을 평문으로 들고 있다.** SQL 구현은 cipher 로 봉하지만, 메모리
구현은 프로세스 밖으로 나가지 않으므로 봉할 대상이 없다 — 봉하는
흉내를 내면 "암호화가 됐다"는 거짓 신호를 준다.
"""

from __future__ import annotations

from dataclasses import replace
from datetime import datetime

from ma_domain.ids import WorkspaceId
from ma_domain.webhooks import (
    DeliveryState,
    WebhookDelivery,
    WebhookEndpoint,
    WebhookEvent,
)
from ma_store._results import ListQuery, Page
from ma_store.webhooks import EnqueueDelivery, InsertEndpoint, RecordAttempt

from ma_store_memory._base import isolate, paginate, partition_key


class MemoryWebhookStore:
    def __init__(self) -> None:
        self._endpoints: dict[tuple[str, str], WebhookEndpoint] = {}
        self._secrets: dict[tuple[str, str], bytes] = {}
        self._deliveries: dict[tuple[str, str], WebhookDelivery] = {}

    # ── 엔드포인트 ───────────────────────────────────────
    async def insert_endpoint(self, cmd: InsertEndpoint) -> WebhookEndpoint:
        made = WebhookEndpoint(
            id=cmd.id,
            workspace_id=cmd.workspace_id,
            url=cmd.url,
            events=cmd.events,
            description=cmd.description,
            created_at=cmd.now,
        )
        key = partition_key(cmd.workspace_id, cmd.id)
        self._endpoints[key] = made
        self._secrets[key] = cmd.secret
        return isolate(made)

    async def find_endpoint(
        self, workspace_id: WorkspaceId, endpoint_id: str
    ) -> WebhookEndpoint | None:
        got = self._endpoints.get(partition_key(workspace_id, endpoint_id))
        return isolate(got) if got else None

    async def list_endpoints(self, q: ListQuery) -> Page[WebhookEndpoint]:
        rows = [
            e
            for (ws, _), e in self._endpoints.items()
            if ws == q.workspace_id and (q.include_archived or e.is_active)
        ]
        return paginate(
            rows,
            q,
            created_at=lambda e: e.created_at or datetime.min,
            ident=lambda e: e.id,
        )

    async def disable_endpoint(
        self, workspace_id: WorkspaceId, endpoint_id: str, now: datetime
    ) -> bool:
        key = partition_key(workspace_id, endpoint_id)
        got = self._endpoints.get(key)
        if got is None or not got.is_active:
            return False
        self._endpoints[key] = replace(got, disabled_at=now)
        return True

    async def secret_for(self, workspace_id: WorkspaceId, endpoint_id: str) -> bytes | None:
        return self._secrets.get(partition_key(workspace_id, endpoint_id))

    async def subscribers(
        self, workspace_id: WorkspaceId, event: WebhookEvent
    ) -> tuple[WebhookEndpoint, ...]:
        rows = [
            e
            for (ws, _), e in sorted(self._endpoints.items())
            if ws == workspace_id and e.is_active and e.wants(event)
        ]
        return tuple(isolate(e) for e in rows)

    # ── 전송 ─────────────────────────────────────────────
    async def enqueue(self, cmd: EnqueueDelivery) -> WebhookDelivery:
        made = WebhookDelivery(
            id=cmd.id,
            workspace_id=cmd.workspace_id,
            endpoint_id=cmd.endpoint_id,
            event=cmd.event,
            payload=tuple(sorted(cmd.payload.items())),
            state=DeliveryState.PENDING,
            attempts=0,
            created_at=cmd.now,
            # **즉시 대상이다.** `None` 으로 두면 `claim_due` 가 못 집는다.
            next_attempt_at=cmd.now,
        )
        self._deliveries[partition_key(cmd.workspace_id, cmd.id)] = made
        return isolate(made)

    async def claim_due(self, now: datetime, limit: int = 50) -> tuple[WebhookDelivery, ...]:
        rows = [
            d
            for d in self._deliveries.values()
            if not d.state.is_final and d.next_attempt_at is not None and d.next_attempt_at <= now
        ]
        rows.sort(key=lambda d: (d.next_attempt_at or now, d.id))
        return tuple(isolate(d) for d in rows[:limit])

    async def record_attempt(self, cmd: RecordAttempt) -> WebhookDelivery | None:
        key = partition_key(cmd.workspace_id, cmd.delivery_id)
        got = self._deliveries.get(key)
        if got is None:
            return None
        self._deliveries[key] = replace(
            got,
            state=cmd.state,
            attempts=cmd.attempts,
            # **끝난 전송에는 다음 시도가 없다** — 남아 있으면
            # 영원히 다시 보낸다 (DB CHECK 과 같은 불변식).
            next_attempt_at=None if cmd.state.is_final else cmd.next_attempt_at,
            delivered_at=cmd.now if cmd.state is DeliveryState.DELIVERED else got.delivered_at,
            last_error=cmd.last_error,
            last_status=cmd.last_status,
        )
        return isolate(self._deliveries[key])

    async def find_delivery(
        self, workspace_id: WorkspaceId, delivery_id: str
    ) -> WebhookDelivery | None:
        got = self._deliveries.get(partition_key(workspace_id, delivery_id))
        return isolate(got) if got else None

    async def list_dead(self, q: ListQuery) -> Page[WebhookDelivery]:
        rows = [d for (ws, _), d in self._deliveries.items() if ws == q.workspace_id and d.is_dead]
        return paginate(rows, q, created_at=lambda d: d.created_at, ident=lambda d: d.id)


__all__ = ["MemoryWebhookStore"]
