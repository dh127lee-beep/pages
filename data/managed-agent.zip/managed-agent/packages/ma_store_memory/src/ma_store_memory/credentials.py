"""메모리 CredentialStore — **평문을 들고 있지 않다.**

`plan/05-database.md` §3 G6 · `plan/03-layers.md` §3 L2.

메모리 구현인데도 cipher 를 받아 **실제로 암호화한다.** 평문을 dict 에 넣고
싶은 유혹이 있지만, 그러면 계약 테스트가 SQL 구현에서는 불가능한 일
(평문을 꺼내 비교)을 통과시킨다 — 그 순간 계약 테스트가 거짓말이 된다.

같은 이유로 `reveal_for_injection` 도 **복호화 경로를 실제로 탄다.** 거기서
AAD 가 틀리면 메모리 구현에서도 깨져야 한다.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
from datetime import datetime
from typing import TYPE_CHECKING

from ma_domain.ids import CredentialId, VaultId, WorkspaceId
from ma_domain.vaults import (
    CredentialKind,
    CredentialMeta,
    OAuthTokens,
    decode_oauth_secret,
    encode_oauth_secret,
    injectable_secret,
)

from ma_store_memory._base import isolate, paginate, partition_key

if TYPE_CHECKING:
    from ma_governance.cipher import CredentialCipher, Sealed
    from ma_store._results import ListQuery, Page
    from ma_store.credentials import (
        InjectionSecret,
        InsertCredential,
        RecordCredentialEvent,
        RecordRefresh,
        RevealForInjection,
        RevealOAuth,
        RotateCredential,
    )


@dataclass
class _Row:
    meta: CredentialMeta
    sealed: Sealed


class MemoryCredentialStore:
    def __init__(self, cipher: CredentialCipher) -> None:
        # **생성자 인자다.** Port 가 아니다 (`plan/03` §3 L2) — Port 그래프에
        # 들어가면 어떤 유스케이스가 평문을 만질 수 있는지 추적할 수 없다.
        self._cipher = cipher
        self._rows: dict[tuple[str, str], _Row] = {}
        self._events: list[RecordCredentialEvent] = []

    async def insert(self, cmd: InsertCredential) -> CredentialMeta:
        from ma_governance.cipher import associated_data

        sealed = self._cipher.seal(cmd.secret, aad=associated_data(cmd.workspace_id, cmd.id))
        meta = CredentialMeta(
            id=cmd.id,
            workspace_id=cmd.workspace_id,
            vault_id=cmd.vault_id,
            kind=cmd.kind,
            created_by=cmd.created_by,
            created_at=cmd.now,
            match_hosts=cmd.match_hosts,
            mcp_server_name=cmd.mcp_server_name,
            header_name=cmd.header_name,
            key_version=sealed.key_version,
            expires_at=cmd.expires_at,
        )
        self._rows[partition_key(cmd.workspace_id, cmd.id)] = _Row(meta=meta, sealed=sealed)
        return isolate(meta)

    async def find(
        self, workspace_id: WorkspaceId, credential_id: CredentialId
    ) -> CredentialMeta | None:
        row = self._rows.get(partition_key(workspace_id, credential_id))
        return isolate(row.meta) if row is not None else None

    async def list_in_vault(self, q: ListQuery, vault_id: VaultId) -> Page[CredentialMeta]:
        rows = [
            r.meta
            for (ws, _), r in self._rows.items()
            if ws == q.workspace_id
            and r.meta.vault_id == vault_id
            and (q.include_archived or r.meta.archived_at is None)
        ]
        return paginate(rows, q, created_at=lambda m: m.created_at, ident=lambda m: m.id)

    async def rotate(self, cmd: RotateCredential) -> CredentialMeta | None:
        from ma_governance.cipher import associated_data

        key = partition_key(cmd.workspace_id, cmd.id)
        row = self._rows.get(key)
        if row is None or row.meta.archived_at is not None:
            return None

        sealed = self._cipher.seal(cmd.secret, aad=associated_data(cmd.workspace_id, cmd.id))
        meta = replace(
            row.meta,
            key_version=sealed.key_version,
            rotated_at=cmd.now,
            expires_at=cmd.expires_at,
            # 로테이션은 **갱신 실패 기록을 지운다** — 새 비밀은 아직 실패한
            # 적이 없다. 남겨 두면 운영자가 고친 것을 못 고친 것으로 본다.
            refresh_failed_at=None,
            refresh_error=None,
        )
        self._rows[key] = _Row(meta=meta, sealed=sealed)
        return isolate(meta)

    async def archive(
        self, workspace_id: WorkspaceId, credential_id: CredentialId, now: datetime
    ) -> bool:
        key = partition_key(workspace_id, credential_id)
        row = self._rows.get(key)
        if row is None or row.meta.archived_at is not None:
            return False
        self._rows[key] = _Row(meta=replace(row.meta, archived_at=now), sealed=row.sealed)
        return True

    async def reveal_for_injection(self, q: RevealForInjection) -> InjectionSecret | None:
        """**평문이 나가는 유일한 경로.** egress 프록시만 쓴다."""
        from ma_governance.cipher import associated_data
        from ma_store.credentials import InjectionSecret

        allowed = set(q.allowed_vault_ids)
        for (ws, cid), row in sorted(self._rows.items()):
            meta = row.meta
            if ws != q.workspace_id or meta.archived_at is not None:
                continue
            if allowed and meta.vault_id not in allowed:
                continue
            if not meta.matches_host(q.host):
                continue
            return InjectionSecret(
                credential_id=meta.id,
                kind=meta.kind,
                # **`mcp_oauth` 는 access token 만 나간다** — 갱신
                # 토큰이 프록시에 가면 프록시가 토큰을 새로 만들 수
                # 있게 된다 (D5 보다 센 권한이다).
                secret=injectable_secret(
                    meta.kind, self._cipher.open(row.sealed, aad=associated_data(ws, cid))
                ),
                header_name=meta.header_name,
            )
        return None

    async def reveal_oauth(self, q: RevealOAuth) -> OAuthTokens | None:
        """**갱신 토큰이 나가는 유일한 경로.** 제어 평면만 쓴다."""
        from ma_governance.cipher import associated_data

        row = self._rows.get(partition_key(q.workspace_id, q.id))
        if row is None or row.meta.archived_at is not None:
            return None
        if row.meta.kind is not CredentialKind.MCP_OAUTH:
            # **종류가 다르면 없는 것과 같다.** bearer 토큰을 OAuth 로
            # 읽어 주면 갱신 경로가 아무 자격증명이나 건드리게 된다.
            return None
        return decode_oauth_secret(
            self._cipher.open(row.sealed, aad=associated_data(q.workspace_id, q.id))
        )

    async def record_refresh(self, cmd: RecordRefresh) -> CredentialMeta | None:
        from ma_governance.cipher import associated_data

        key = partition_key(cmd.workspace_id, cmd.id)
        row = self._rows.get(key)
        if row is None or row.meta.archived_at is not None:
            return None
        if row.meta.kind is not CredentialKind.MCP_OAUTH:
            return None

        if cmd.tokens is None:
            # **실패.** 옛 토큰은 그대로 둔다 — 아직 쓸 수 있을 수 있다.
            meta = replace(row.meta, refresh_failed_at=cmd.now, refresh_error=cmd.error[:500])
            self._rows[key] = _Row(meta=meta, sealed=row.sealed)
            return isolate(meta)

        sealed = self._cipher.seal(
            encode_oauth_secret(cmd.tokens),
            aad=associated_data(cmd.workspace_id, cmd.id),
        )
        meta = replace(
            row.meta,
            key_version=sealed.key_version,
            rotated_at=cmd.now,
            expires_at=cmd.expires_at,
            # **성공은 실패 기록을 지운다.** 안 지우면 운영자가 고친
            # 것을 못 고친 것으로 본다.
            refresh_failed_at=None,
            refresh_error=None,
        )
        self._rows[key] = _Row(meta=meta, sealed=sealed)
        return isolate(meta)

    async def record_event(self, cmd: RecordCredentialEvent) -> None:
        self._events.append(cmd)

    # ── 테스트·재암호화 배치가 쓰는 것 ───────────────────
    def events(self) -> tuple[RecordCredentialEvent, ...]:
        return tuple(self._events)

    async def stale_key_versions(
        self, workspace_id: WorkspaceId, *, limit: int = 100
    ) -> tuple[CredentialId, ...]:
        """재암호화가 필요한 행. `IMPL-0020` 의 배치가 쓴다.

        SQL 과 **같은 순서**로 돌려준다 (`key_version, created_at`) —
        순서가 다르면 배치가 두 구현에서 다른 묶음을 처리하고, "몇 번째
        배치에서 멈췄나"가 재현되지 않는다.
        """
        rows = [
            r
            for (ws, _), r in self._rows.items()
            if ws == workspace_id
            and r.meta.archived_at is None
            and self._cipher.needs_rewrap(r.sealed)
        ]
        rows.sort(key=lambda r: (r.sealed.key_version, r.meta.created_at, r.meta.id))
        return tuple(r.meta.id for r in rows[:limit])

    async def rewrap(self, workspace_id: WorkspaceId, credential_id: CredentialId) -> bool:
        from ma_governance.cipher import associated_data

        key = partition_key(workspace_id, credential_id)
        row = self._rows.get(key)
        if row is None or row.meta.archived_at is not None:
            # **아카이브된 것은 다시 열지 않는다.** 평문을 만들 이유가 없고,
            # 그 한 번이 로그·추적에 실릴 기회다.
            return False
        if not self._cipher.needs_rewrap(row.sealed):
            return False
        sealed = self._cipher.rewrap(row.sealed, aad=associated_data(workspace_id, credential_id))
        self._rows[key] = _Row(
            meta=replace(row.meta, key_version=sealed.key_version), sealed=sealed
        )
        return True


__all__ = ["MemoryCredentialStore"]
