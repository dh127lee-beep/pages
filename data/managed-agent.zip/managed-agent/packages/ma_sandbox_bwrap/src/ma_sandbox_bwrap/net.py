"""티어 P 의 네트워크 — **`pasta` 로 유저모드 스택을, 프록시 하나로만**.

`plan/08-infrastructure.md` §4 · `plan/07-sandbox.md` §6.2 ·
`task/M3-security-governance/T-0402-egress-proxy.md`.

기본은 `--unshare-net` 이다 — 샌드박스에 네트워크가 **없다**. 그런데
`pip install` 이나 `git clone` 이 필요한 티어 P 환경이 있고, 그때 쓰는 것이
`pasta`(passt 의 한 모드)다. 커널 모듈 없이 유저모드 TCP/IP 스택을 붙인다.

```
bwrap --unshare-net …          ← netns 를 만든다 (네트워크 없음)
pasta --config-net <pid>       ← 그 netns 에 유저모드 스택을 꽂는다
      --tcp-ports <프록시만>    ← **나갈 수 있는 곳이 프록시 하나뿐**
```

> **`pasta` 가 없으면 `--unshare-net` 을 유지하고 그 환경에서는 네트워크
> 툴을 등록하지 않는다** (`plan/08` §4). 조용히 전체 네트워크를 여는
> 것보다 기능이 없는 편이 낫다.

**이 모듈은 argv 를 만들 뿐 실행하지 않는다.** 실행은 호출자(워커)가
하고, 그래야 이 판단을 네트워크 없이 테스트할 수 있다.
"""

from __future__ import annotations

import shutil
from dataclasses import dataclass
from enum import StrEnum

#: 러너 이름. `slirp4netns` 는 더 느리고 기능이 적어 대안으로만 둔다.
PASTA = "pasta"
SLIRP = "slirp4netns"


class NetMode(StrEnum):
    """샌드박스가 가질 네트워크."""

    #: `--unshare-net` 만. **기본값.**
    NONE = "none"
    #: pasta + 프록시 하나로만 나간다.
    PROXY_ONLY = "proxy_only"


@dataclass(frozen=True, slots=True)
class ProxyEndpoint:
    host: str
    port: int

    def __post_init__(self) -> None:
        if not self.host:
            raise ValueError("프록시 호스트가 비었다")
        if not 1 <= self.port <= 65535:
            raise ValueError(f"프록시 포트가 범위를 벗어났다: {self.port}")


@dataclass(frozen=True, slots=True)
class NetPlan:
    """무엇을 할지. **`argv` 가 비어 있으면 아무것도 하지 않는다.**"""

    mode: NetMode
    argv: tuple[str, ...] = ()
    #: 왜 이 모드인가. `unsupported` 일 때 운영자가 읽는다.
    reason: str = ""
    #: 이 계획에서 네트워크 툴을 등록해도 되는가.
    tools_enabled: bool = False


def available() -> str | None:
    """`pasta` 또는 `slirp4netns`. 둘 다 없으면 `None`."""
    for runner in (PASTA, SLIRP):
        if shutil.which(runner):
            return runner
    return None


def plan(
    *,
    want: NetMode,
    sandbox_pid: int,
    proxy: ProxyEndpoint | None,
) -> NetPlan:
    """원하는 모드 + 이 노드의 사실 → 실제 계획.

    **원하는 것을 못 주면 `NONE` 으로 떨어진다.** 떨어지되 조용하지
    않다 — `reason` 이 왜인지 말하고, `tools_enabled` 가 False 라
    네트워크 툴이 등록되지 않는다.
    """
    if want is NetMode.NONE:
        return NetPlan(mode=NetMode.NONE, reason="네트워크를 요청하지 않았다")

    if proxy is None:
        # **프록시 없이 열지 않는다.** 열면 "프록시로만"이 아니라
        # "전부 열림"이고, 그것은 요청한 것과 다르다.
        return NetPlan(
            mode=NetMode.NONE,
            reason="egress 프록시 주소가 없다 — 네트워크를 열지 않는다",
        )

    runner = available()
    if runner is None:
        return NetPlan(
            mode=NetMode.NONE,
            reason=f"{PASTA} 도 {SLIRP} 도 없다 — 네트워크 툴을 등록하지 않는다",
        )

    if runner == SLIRP:
        return NetPlan(
            mode=NetMode.PROXY_ONLY,
            argv=_slirp_argv(sandbox_pid, proxy),
            reason=f"{SLIRP} 로 떨어졌다 — {PASTA} 보다 느리다",
            tools_enabled=True,
        )

    return NetPlan(
        mode=NetMode.PROXY_ONLY,
        argv=_pasta_argv(sandbox_pid, proxy),
        reason=f"{PASTA} · 프록시 {proxy.host}:{proxy.port} 로만",
        tools_enabled=True,
    )


def _pasta_argv(pid: int, proxy: ProxyEndpoint) -> tuple[str, ...]:
    """**나갈 수 있는 포트를 프록시 하나로 고정한다.**

    `--tcp-ports` 없이 띄우면 netns 안에서 아무 데나 붙을 수 있고,
    그러면 `--unshare-net` 을 푼 것과 같다.

    `--udp-ports none` 이 중요하다 — DNS 를 UDP 로 내보내면 **질의
    자체가 유출 채널**이다 (`evil.kr` 에 데이터를 실은 서브도메인을
    조회하면 그 호스트의 DNS 서버가 받는다).
    """
    return (
        PASTA,
        "--config-net",
        "--tcp-ports",
        f"{proxy.port}:{proxy.port}",
        "--udp-ports",
        "none",
        "--no-map-gw",
        str(pid),
    )


def _slirp_argv(pid: int, proxy: ProxyEndpoint) -> tuple[str, ...]:
    """대안. `slirp4netns` 는 포트 제한이 약해 **권장하지 않는다.**

    `--disable-host-loopback` 이 최소한 호스트 루프백으로의 접근을
    막는다 — 그것이 없으면 샌드박스가 워커의 로컬 포트에 붙는다.
    """
    return (SLIRP, "--configure", "--disable-host-loopback", str(pid), "tap0")


def resolv_conf(proxy: ProxyEndpoint) -> str:
    """게스트에 넣을 `/etc/resolv.conf`.

    **DNS 를 주지 않는다.** 프록시가 `CONNECT host:port` 로 이름을 받아
    자기가 해소하므로, 게스트는 이름을 풀 필요가 없다. 비워 두면 게스트의
    DNS 질의가 전부 실패하고, 그것이 의도다.
    """
    return (
        "# AWP: 게스트는 이름을 풀지 않는다 — 프록시가 해소한다.\n"
        f"# HTTPS_PROXY=http://{proxy.host}:{proxy.port}\n"
    )


__all__ = [
    "PASTA",
    "SLIRP",
    "NetMode",
    "NetPlan",
    "ProxyEndpoint",
    "available",
    "plan",
    "resolv_conf",
]
