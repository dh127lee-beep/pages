"""티어 P provider — **능력을 추측하지 않고 프로브한다**.

`plan/07-sandbox.md` §4 · `plan/08-infrastructure.md` §4 · `T-0304`.

티어 W 와 결정적으로 다른 점: **티어 W 는 구성상 `enforced` 이고, 티어 P 는
노드에 따라 다르다.** bwrap 이 있어야 하고, 커널이 비특권 user namespace 를
허용해야 하고, 그 둘이 노드마다 다르다.

그래서 `probe()` 가 **실제로 bwrap 을 띄워 본다.** 바이너리가 있는지만 보고
`enforced` 라고 말하면, user namespace 가 막힌 클러스터에서 **없는 보호를
믿게 된다** — seccomp 프로필이 `CLONE_NEWUSER` 를 막는 것은 흔한 설정이다.

프로브가 보는 것 넷 (`plan/08` §4 의 플래그가 실제로 먹는가):

```
1. 워크스페이스 밖에 쓸 수 있는가   → 쓸 수 있으면 격리가 없다
2. 워크스페이스 밖을 읽을 수 있는가 → 읽을 수 있으면 경계가 없다
3. 환경변수가 상속되는가            → 상속되면 DB DSN 이 샌다
4. 네트워크가 있는가                → 있으면 PostgreSQL 에 직접 붙는다
```

> **Landlock 에 대한 정정 (T-0304 구현, `IMPL-0017`)**: `plan/07` §4 의 티어
> 표는 enforcement 가 "Landlock ABI 에 따라 full/partial" 이라고 적었다.
> 그런데 **bwrap 은 Landlock 을 걸지 않는다** — namespace 와 capability
> drop 으로 막는다. 그리고 우리는 argv 를 감쌀 뿐 게스트 안에서 코드를
> 실행하지 않으므로 Landlock 을 걸 자리가 없다. 네트워크도 ABI 4 가
> 아니라 `--unshare-net` 이 막는다. 그래서 **enforcement 는 ABI 가 아니라
> 프로브 결과로 정해진다.** ABI 는 측정해서 `notes` 에 싣는다 — 2차
> 방어선을 나중에 붙일 때(`TODO(T-0402)`) 어디까지 되는지가 거기 있다.
"""

from __future__ import annotations

import os
import shutil
import subprocess
import tempfile
import threading
from collections.abc import Sequence
from dataclasses import dataclass, field
from pathlib import Path

from ma_domain.environments import Enforcement, SandboxTier
from ma_sandbox.argv import wrap
from ma_sandbox.ports import (
    ConfinedArgv,
    ProviderCapabilities,
    SandboxMode,
    SandboxPolicy,
)

from ma_sandbox_bwrap import flags, landlock
from ma_sandbox_bwrap.dialect import BWRAP_DENIAL_SIGNATURES, BWRAP_RUNNER_FAILURES

#: 프로브가 게스트에 띄우는 스크립트. **셸 한 줄짜리로 끝낸다** —
#: 게스트에 파이썬이 있다고 가정할 수 없다 (`--ro-bind /usr` 가 uv 가 관리하는
#: 인터프리터까지 데려오지는 않는다).
_PROBE_SCRIPT = """
printf 'write='; (echo x > %(outside)s/탈출.txt) 2>/dev/null && printf 'yes\\n' || printf 'no\\n'
printf 'read=';  cat %(sentinel)s 2>/dev/null | head -c 20 || printf 'no'
printf '\\n'
printf 'env=%%s\\n' "${AWP_PROBE_SECRET:-no}"
printf 'net='; (exec 3<>/dev/tcp/127.0.0.1/%(port)d) 2>/dev/null && printf 'yes\\n' || printf 'no\\n'
"""

#: 프로브에 주는 시간. 넘으면 **고장으로 본다** — 능력 탐지가 매달리면
#: 워커 기동 전체가 매달린다.
PROBE_TIMEOUT_SECONDS = 10.0

#: 프로브가 바깥 읽기를 시험할 때 쓰는 표식.
_SENTINEL = "밖에서만보이는값"

#: 환경 상속을 시험할 때 쓰는 값. 비밀이 아니라 **표식**이다 —
#: 게스트에서 이 문자열이 보이면 `--clearenv` 가 안 먹은 것이다.
_ENV_MARKER = "상속되면안되는값"


@dataclass(frozen=True, slots=True)
class ProbeResult:
    """프로브가 실제로 본 것. **`notes` 의 원천이다.**"""

    bwrap_path: str | None
    #: bwrap 이 떴는가. 뜨지 못하면 나머지는 전부 의미가 없다.
    ran: bool
    wrote_outside: bool | None = None
    read_outside: bool | None = None
    inherited_env: bool | None = None
    had_network: bool | None = None
    stderr: str = ""
    landlock: landlock.LandlockStatus = field(
        default_factory=lambda: landlock.LandlockStatus(abi=0, reason="프로브 전")
    )

    @property
    def isolates(self) -> bool:
        """네 가지가 **전부** 막혔는가. 하나라도 아니면 `enforced` 가 아니다."""
        return self.ran and not any(
            (self.wrote_outside, self.read_outside, self.inherited_env, self.had_network)
        )

    def failures(self) -> tuple[str, ...]:
        if not self.ran:
            return ()
        checks = (
            (self.wrote_outside, "워크스페이스 밖에 쓸 수 있다"),
            (self.read_outside, "워크스페이스 밖을 읽을 수 있다"),
            (self.inherited_env, "워커 환경변수가 상속된다"),
            (self.had_network, "네트워크가 살아 있다"),
        )
        return tuple(text for failed, text in checks if failed)


def run_probe(timeout: float = PROBE_TIMEOUT_SECONDS) -> ProbeResult:
    """**실제로 bwrap 을 띄운다.** 실패는 결과값이지 예외가 아니다."""
    status = landlock.probe()
    found = shutil.which(flags.BWRAP)
    if found is None:
        return ProbeResult(bwrap_path=None, ran=False, stderr="bwrap 이 없다", landlock=status)

    with tempfile.TemporaryDirectory() as tmp:
        base = Path(tmp)
        workspace = base / "work"
        workspace.mkdir()
        outside = base / "바깥"
        outside.mkdir()
        sentinel = outside / "표식.txt"
        sentinel.write_text(_SENTINEL, encoding="utf-8")

        policy = SandboxPolicy(mode=SandboxMode.WORKSPACE_WRITE, workspace_root=workspace)
        profile = flags.profile(policy)
        flags.verify(profile)

        # 포트는 열려 있을 필요가 없다 — `--unshare-net` 이 걸리면 연결
        # 시도 자체가 다른 오류로 끝나지만, 여기서 보는 것은 "ECONNREFUSED
        # 라도 나오는가"가 아니라 "성공하는가"다. 그래서 거의 확실히 닫힌
        # 포트를 고른다.
        script = _PROBE_SCRIPT % {
            "outside": str(outside),
            "sentinel": str(sentinel),
            "port": 9,
        }
        argv = wrap((found,), profile, ("/bin/sh", "-c", script))

        env = dict(os.environ)  # awp-env-ok — 상속되는지 **보려고** 넘긴다
        env["AWP_PROBE_SECRET"] = _ENV_MARKER
        try:
            done = subprocess.run(  # noqa: S603 — argv 리스트. 셸을 거치지 않는다
                argv,
                capture_output=True,
                text=True,
                timeout=timeout,
                env=env,
                check=False,
            )
        except (OSError, subprocess.SubprocessError) as exc:
            return ProbeResult(
                bwrap_path=found, ran=False, stderr=f"bwrap 실행 실패: {exc}", landlock=status
            )

        fields = dict(line.split("=", 1) for line in done.stdout.splitlines() if "=" in line)
        if not fields:
            return ProbeResult(
                bwrap_path=found,
                ran=False,
                stderr=(done.stderr or "프로브가 아무것도 출력하지 않았다").strip()[:500],
                landlock=status,
            )

        return ProbeResult(
            bwrap_path=found,
            ran=True,
            wrote_outside=fields.get("write") == "yes",
            # 표식을 **실제로 읽었는지**로 본다. 빈 출력은 못 읽은 것이다.
            read_outside=_SENTINEL in fields.get("read", ""),
            inherited_env=fields.get("env") == _ENV_MARKER,
            had_network=fields.get("net") == "yes",
            stderr=done.stderr.strip()[:500],
            landlock=status,
        )


@dataclass
class BwrapSandboxProvider:
    """`SandboxProvider` 구현. **프로브 결과가 `enforcement` 를 정한다.**"""

    name: str = "bwrap"
    probe_timeout: float = PROBE_TIMEOUT_SECONDS
    _probed: ProbeResult | None = field(default=None, repr=False)
    _lock: threading.Lock = field(default_factory=threading.Lock, repr=False)

    def measurement(self) -> ProbeResult:
        """프로브는 **한 번만** 돈다. 노드 능력은 프로세스 수명 안에서
        바뀌지 않고, bwrap 기동은 싸지 않다."""
        with self._lock:
            if self._probed is None:
                self._probed = run_probe(self.probe_timeout)
            return self._probed

    def confine(self, argv: Sequence[str], policy: SandboxPolicy) -> ConfinedArgv:
        """`bwrap [프로필] -- [원래 argv]`.

        **bwrap 이 없어도 argv 를 돌려준다** — 단 `enforcement` 가
        `unsupported` 이고 `caveats` 가 그 이유를 들고 있다. 여기서 예외를
        던지면 호출자가 "감금되지 않은 채로 실행"과 "실행하지 않음" 중
        무엇을 할지 고를 수 없다. 고르는 것은 `SandboxOrchestrator` 다.
        """
        measured = self.measurement()
        if measured.bwrap_path is None:
            return ConfinedArgv(
                argv=tuple(argv),
                enforcement=Enforcement.UNSUPPORTED,
                caveats=("bwrap 이 없다 — argv 를 감금하지 않았다",),
            )

        profile = flags.profile(policy)
        flags.verify(profile)
        return ConfinedArgv(
            argv=wrap((measured.bwrap_path,), profile, argv),
            enforcement=self._enforcement(measured),
            denial_signatures=BWRAP_DENIAL_SIGNATURES,
            runner_failure_rules=BWRAP_RUNNER_FAILURES,
            caveats=self._caveats(measured),
        )

    def probe(self) -> ProviderCapabilities:
        measured = self.measurement()
        notes = list(self._caveats(measured))
        notes.append(measured.landlock.reason)
        if measured.ran and measured.landlock.abi == 0:
            # Landlock 은 **2차 방어선**이다. 없다고 1차(namespace)가
            # 약해지지는 않지만, 있으면 좋은 것이 없다는 사실은 남긴다.
            notes.append("Landlock 2차 방어선 없음 — namespace 격리만으로 막는다")

        level = self._enforcement(measured)
        return ProviderCapabilities(
            provider=self.name,
            tier=SandboxTier.PROCESS,
            filesystem=level,
            # `--unshare-net` 은 네트워크를 **없앤다** — 프록시로 좁히는
            # 것이 아니다. 프로브가 그것을 확인했으면 `enforced` 다.
            network=level,
            # 티어 P 의 존재 이유가 셸이다. 단 **격리가 실제로 될 때만.**
            supports_shell=measured.isolates,
            notes=tuple(notes),
        )

    def tools_available(self) -> tuple[str, ...]:
        base = ("read", "write", "edit", "glob", "grep", "web_fetch", "web_search")
        # 격리가 안 되는데 `bash` 를 주면 **워커 호스트에 셸을 주는 것**이다.
        return (*base, "bash") if self.measurement().isolates else base

    # ── 판정 ─────────────────────────────────────────────
    def _enforcement(self, measured: ProbeResult) -> Enforcement:
        """**프로브가 전부 막혔다고 말할 때만 `enforced`.**

        `partial` 을 쓰는 경우: bwrap 이 떴는데 네 검사 중 일부만 막혔다.
        그런 노드가 실재한다 — 예를 들어 `/proc` 마운트가 막혀 `--unshare-pid`
        가 조용히 덜 먹는 경우.
        """
        if not measured.ran:
            return Enforcement.UNSUPPORTED
        if measured.isolates:
            return Enforcement.ENFORCED
        return Enforcement.PARTIAL

    def _caveats(self, measured: ProbeResult) -> tuple[str, ...]:
        if measured.bwrap_path is None:
            return ("bwrap 이 없다 — 이 노드에서 티어 P 를 쓸 수 없다",)
        if not measured.ran:
            return (
                "bwrap 이 기동하지 못했다 — 비특권 user namespace 가 막혔을 수 있다 "
                "(k8s 1.33 hostUsers:false 또는 커스텀 seccomp 필요)",
                f"stderr: {measured.stderr}" if measured.stderr else "stderr 없음",
            )
        failures = measured.failures()
        if failures:
            return (*(f"격리 실패: {f}" for f in failures),)
        return ()


__all__ = [
    "PROBE_TIMEOUT_SECONDS",
    "BwrapSandboxProvider",
    "ProbeResult",
    "run_probe",
]
