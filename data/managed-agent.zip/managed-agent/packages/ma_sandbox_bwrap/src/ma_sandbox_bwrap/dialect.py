"""bwrap/Landlock 의 stderr 방언 — **이 백엔드가 실제로 내는 문구만**.

`plan/07-sandbox.md` §4.2 · `task/M2-sandbox-tools/T-0304-tier-process.md`.

거부(denial)와 러너 고장(runner failure)을 가르는 것이 §4.2 의 요점이다.
인프라 장애를 "작업 실패"로 모델에 보고하면 **모델이 엉뚱한 재시도를 한다** —
같은 명령을 다시 쳐도 bwrap 이 없는 것은 여전히 없다.

| 종류 | 무엇 | 처리 |
|---|---|---|
| **거부** | 정책이 막았다 (`EROFS` · `EACCES` · `EPERM`) | 툴 결과로 모델에 전달 |
| **러너 고장** | bwrap 자신이 못 떴다 | `session.error`. 모델에 보고하지 않는다 |

**전 백엔드 합집합을 쓰지 않는다.** Wasmtime 의 `unknown import` 를 여기
섞으면, bwrap 이 내지 않는 거부를 자기 거부로 주장하게 된다.
"""

from __future__ import annotations

from ma_sandbox.ports import RunnerFailureRule

#: 정책이 막았을 때 커널·bwrap 이 내는 문구.
#:
#: POSIX errno 의 표준 `strerror` 문자열이 대부분이다 — 로케일이 바뀌면
#: 달라지므로, bwrap 은 `LC_ALL=C` 로 띄우는 것이 전제다
#: (`--clearenv` 가 로케일 변수를 지우므로 기본이 C 다).
BWRAP_DENIAL_SIGNATURES = (
    "Read-only file system",
    "Permission denied",
    "Operation not permitted",
    "No such file or directory",
    "Network is unreachable",
    "Name or service not known",
    "Temporary failure in name resolution",
)

#: bwrap **자신이** 못 떴을 때. 이것은 거부가 아니라 고장이다.
#:
#: `informational_lines` 가 중요하다 — bwrap 은 성공 경로에서도 안내를
#: 내는 일이 있고, 그 안에 "failed" 가 들어 있으면 치명으로 오판한다.
BWRAP_RUNNER_FAILURES = (
    RunnerFailureRule(
        fatal_signatures=(
            "bwrap: Creating new namespace failed",
            "bwrap: No permissions to creating new namespace",
            "bwrap: setting up uid map",
            "bwrap: Can't find source path",
            "bwrap: execvp",
            "bwrap: Unexpected capabilities",
            "Operation not permitted (are you root?)",
        ),
        informational_lines=(
            # user namespace 가 막힌 환경에서 bwrap 이 먼저 내는 안내.
            # 이 줄만 있고 뒤에 치명 문구가 없으면 **고장이 아니다.**
            "bwrap: Note that sandboxing",
        ),
        # 127 = command not found. **툴 자신의 실패**다 — 모델이 오타를
        # 쳤을 때 나오는 값이고, bwrap 이 고장난 것이 아니다.
        benign_exit_codes=(127,),
    ),
)

#: bwrap 바이너리 자체가 없을 때 파이썬이 내는 것. `confine()` 전에 걸러야
#: 하지만, 경쟁 상태(설치 중 삭제)로 여기까지 오면 러너 고장이다.
BWRAP_MISSING = "No such file or directory: 'bwrap'"


__all__ = [
    "BWRAP_DENIAL_SIGNATURES",
    "BWRAP_MISSING",
    "BWRAP_RUNNER_FAILURES",
]
