"""Landlock ABI 탐지 — **추측하지 않고 커널에 묻는다**.

`plan/07-sandbox.md` §4.3 · `task/M2-sandbox-tools/T-0304-tier-process.md`.

| ABI | 커널 | 얻는 것 |
|---|---|---|
| 1 | 5.13+ | 파일시스템 접근 제한 |
| 2 | 5.19 | 파일 재명명 |
| 3 | 6.2 | truncate |
| 4 | **6.7+** | **TCP bind/connect 제한 (포트 단위)** |
| 5 | 6.10+ | ioctl |

Landlock 의 결정적 장점은 **비특권**이라는 것이다. 어떤 프로세스든 자기
자신을 안전하게 제한할 수 있다 — BPF LSM 과 달리 로드에 권한이 필요 없다.

> **정확히**: Landlock 의 네트워크 규칙은 **포트 기반**이지 주소 기반이
> 아니다. "egress 프록시로만"을 Landlock 만으로 보장할 수 없다
> (`plan/07` §6 의 다층 방어가 필요하다).

ABI 를 묻는 방법은 `landlock_create_ruleset(NULL, 0, LANDLOCK_CREATE_RULESET_VERSION)`
시스템콜 하나다. 파이썬 표준 라이브러리에 래퍼가 없으므로 `ctypes` 로 직접
부른다. **파일을 읽어 추정하지 않는다** — `/proc/version` 의 커널 버전은
배포판이 백포트하면 틀리고, LSM 이 부팅 파라미터로 꺼져 있을 수도 있다.
"""

from __future__ import annotations

import ctypes
import ctypes.util
import platform
from dataclasses import dataclass

#: `linux/landlock.h` — ABI 버전을 묻는 플래그.
LANDLOCK_CREATE_RULESET_VERSION = 1 << 0

#: `asm/unistd_64.h`. 아키텍처마다 다르다.
_SYS_LANDLOCK_CREATE_RULESET = {
    "x86_64": 444,
    "aarch64": 444,
}

#: 네트워크 제한(TCP bind/connect)이 들어온 ABI.
NETWORK_ABI = 4


@dataclass(frozen=True, slots=True)
class LandlockStatus:
    """커널이 무엇을 해 주는가. **사유를 항상 들고 다닌다.**"""

    #: 사용 가능한 최고 ABI. 0 이면 Landlock 이 없다.
    abi: int
    #: 왜 이 값인가. `enforcement` 가 `enforced` 가 아닐 때 운영자가 읽는다.
    reason: str

    @property
    def available(self) -> bool:
        return self.abi > 0

    @property
    def restricts_network(self) -> bool:
        """ABI 4+ 여야 TCP 를 건다. **포트 단위이지 주소 단위가 아니다.**"""
        return self.abi >= NETWORK_ABI


def probe() -> LandlockStatus:
    """커널에 직접 묻는다. **실패는 `abi=0` 이지 예외가 아니다.**

    예외로 올리면 호출자가 `try/except` 를 빠뜨렸을 때 provider 조립이
    통째로 죽는다. 능력 탐지의 실패는 "능력이 없다"로 보고되어야 한다.
    """
    if platform.system() != "Linux":
        return LandlockStatus(abi=0, reason=f"Linux 가 아니다 ({platform.system()})")

    machine = platform.machine()
    syscall_no = _SYS_LANDLOCK_CREATE_RULESET.get(machine)
    if syscall_no is None:
        return LandlockStatus(abi=0, reason=f"이 아키텍처의 syscall 번호를 모른다 ({machine})")

    try:
        libc = ctypes.CDLL(ctypes.util.find_library("c") or "libc.so.6", use_errno=True)
    except OSError as exc:  # pragma: no cover — Linux 에서 libc 가 없을 리 없다
        return LandlockStatus(abi=0, reason=f"libc 를 열지 못했다: {exc}")

    ctypes.set_errno(0)
    result = libc.syscall(
        ctypes.c_long(syscall_no),
        ctypes.c_void_p(None),
        ctypes.c_size_t(0),
        ctypes.c_uint32(LANDLOCK_CREATE_RULESET_VERSION),
    )
    if result < 0:
        errno = ctypes.get_errno()
        # ENOSYS(38) = 커널에 Landlock 이 없다.
        # EOPNOTSUPP(95) = 컴파일은 됐지만 부팅 때 꺼졌다 (`lsm=` 파라미터).
        known = {38: "커널에 Landlock 이 없다", 95: "Landlock 이 부팅 시 비활성화됐다"}
        return LandlockStatus(abi=0, reason=known.get(errno, f"syscall 실패 errno={errno}"))

    return LandlockStatus(abi=int(result), reason=f"Landlock ABI {result}")


__all__ = [
    "LANDLOCK_CREATE_RULESET_VERSION",
    "NETWORK_ABI",
    "LandlockStatus",
    "probe",
]
