"""bwrap 인자 조립 — **`plan/08` §4 의 플래그 세트 그대로**.

`plan/08-infrastructure.md` §4 · `plan/07-sandbox.md` §4.

샌드박스가 워커 Pod **안에** 있다. 아무 조치 없이 subprocess 를 띄우면
Pod 의 네트워크 네임스페이스를 공유해 **PostgreSQL IP:5432 에 직접 붙을 수
있다.** 이것이 샌드박스를 워커 안에 넣을 때의 핵심 위험이다.

| 플래그 | 막는 것 |
|---|---|
| `--unshare-net` | **네트워크 전부.** DB · k8s API · 인터넷 |
| `--unshare-pid` | 워커 프로세스의 `/proc/<pid>/environ` 읽기 |
| `--clearenv` | 워커 환경변수(DB DSN, 모델 키) 상속 |
| `--die-with-parent` | 고아 프로세스 |
| `--new-session` | 터미널 재주입 (TIOCSTI) |

**세 플래그는 정책으로 끌 수 없다.** `--unshare-net` · `--unshare-pid` ·
`--clearenv` 는 `REQUIRED_FLAGS` 에 있고, 조립 결과에 전부 들어 있는지
`verify()` 가 확인한다. 정책 하나가 잘못 들어와 네트워크가 열리는 것이
이 티어의 가장 비싼 실패이기 때문이다.
"""

from __future__ import annotations

from collections.abc import Sequence
from pathlib import Path

from ma_sandbox.ports import SandboxPolicy

#: 기본 러너.
BWRAP = "bwrap"

#: 게스트에서 워크스페이스가 보이는 경로. 티어 W 와 **같게 맞춘다** —
#: 모델이 받는 프롬프트가 티어에 따라 달라지면 안 된다.
GUEST_WORKSPACE = "/workspace"
GUEST_MEMORY_ROOT = "/mnt/memory"

#: 읽기 전용으로 바인드할 시스템 경로. **있는 것만** 바인드한다 —
#: 없는 경로를 주면 bwrap 이 기동 자체를 실패한다(러너 고장).
SYSTEM_PATHS = ("/usr", "/lib", "/lib64", "/bin", "/sbin", "/etc/alternatives")

#: 게스트 `PATH`. 워커 것을 물려주지 않는다.
GUEST_PATH = "/usr/bin:/bin"

#: **정책으로 끌 수 없는** 플래그. 하나라도 빠지면 조립이 실패한다.
REQUIRED_FLAGS = ("--unshare-net", "--unshare-pid", "--clearenv")


class FlagAssemblyError(RuntimeError):
    """필수 플래그가 빠졌다. **조립 단계에서 죽는다** — 실행하지 않는다."""


def profile(policy: SandboxPolicy, *, allow_network: bool = False) -> tuple[str, ...]:
    """정책 하나를 bwrap 인자로.

    `allow_network` 는 **지금 쓰지 않는다** (T-0402 의 pasta 가 생긴 뒤).
    인자로 받아 두는 이유는 그때 이 함수의 시그니처가 바뀌지 않게 하려는
    것이고, 지금은 참이어도 `--unshare-net` 을 유지한다 — 열어 줄 경로가
    아직 없으므로 "열었다"고 말하면 거짓이 된다.
    """
    args: list[str] = [
        "--unshare-user",
        "--unshare-pid",
        "--unshare-ipc",
        "--unshare-uts",
        # ★ 자기 netns. 네트워크 없음.
        "--unshare-net",
        "--die-with-parent",
        "--new-session",
    ]

    for system in SYSTEM_PATHS:
        if Path(system).exists():
            args += ["--ro-bind", system, system]

    root = str(policy.workspace_root)
    args += ["--bind" if policy.writable else "--ro-bind", root, GUEST_WORKSPACE]

    for extra in policy.extra_readable:
        # 추가 경로는 **항상 읽기 전용**이다. 스킬·메모리 마운트가 여기
        # 오는데, 그것이 쓰기 가능해지면 세션이 자기 스킬을 고칠 수 있다.
        args += ["--ro-bind", str(extra), f"{GUEST_MEMORY_ROOT}/{extra.name}"]

    args += [
        # 게스트 안의 `/tmp` 다 — 호스트 `/tmp` 가 아니라 tmpfs 를 새로
        # 건다. 그것이 요점이다: 게스트는 호스트 `/tmp` 를 볼 수 없다.
        "--tmpfs",
        "/tmp",  # noqa: S108 — 게스트 경로. 호스트 파일을 열지 않는다
        "--proc",
        "/proc",
        "--dev",
        "/dev",
        "--chdir",
        GUEST_WORKSPACE,
        # 환경을 비우고 **우리가 고른 것만** 다시 넣는다.
        "--clearenv",
        "--setenv",
        "PATH",
        GUEST_PATH,
        "--setenv",
        "HOME",
        GUEST_WORKSPACE,
    ]
    return tuple(args)


def verify(args: Sequence[str]) -> None:
    """필수 플래그가 전부 있는가. **없으면 실행하지 않는다.**

    `profile()` 이 그것을 넣는데 왜 또 보는가: `profile()` 을 고치는 사람이
    한 줄을 지우는 것은 쉽고, 지워도 테스트가 "실행이 된다"로 통과한다.
    여기서 보면 **지우는 순간 깨진다**.
    """
    missing = [flag for flag in REQUIRED_FLAGS if flag not in args]
    if missing:
        raise FlagAssemblyError(f"필수 bwrap 플래그가 빠졌다: {', '.join(missing)}")


__all__ = [
    "BWRAP",
    "GUEST_MEMORY_ROOT",
    "GUEST_PATH",
    "GUEST_WORKSPACE",
    "REQUIRED_FLAGS",
    "SYSTEM_PATHS",
    "FlagAssemblyError",
    "profile",
    "verify",
]
