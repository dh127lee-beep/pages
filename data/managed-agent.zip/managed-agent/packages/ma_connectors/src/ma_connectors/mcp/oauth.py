"""MCP OAuth 갱신 (T-0601).

`plan/07-sandbox.md` §6 · `ADR-0009`.

> **갱신은 제어 평면에서 일어난다.** 루트 시크릿이 거기에만 있고
> (D5), 갱신 토큰은 access token 보다 센 권한이다 — 그것으로 토큰을
> **새로 만들 수 있다.** 워커도 프록시도 갱신 토큰을 보지 않는다.

흐름 (401-then-refresh):

```
워커: MCP 호출 → 프록시가 옛 access token 주입 → 서버가 401
  │
  ▼  `McpUnauthorized`
워커: 제어 평면에 "이 서버 자격증명을 갱신해 달라"
  │
  ▼
제어 평면: reveal_oauth → 토큰 엔드포인트 POST → record_refresh
  │
  ▼  성공이면 한 번만 재시도
워커: 같은 호출 다시 → 프록시가 새 token 주입 → 200
```

**재시도는 한 번뿐이다.** 두 번째도 401 이면 갱신이 문제를 못 고친
것이고, 계속 돌면 토큰 엔드포인트를 두드리다 레이트 리밋에 걸린다.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import timedelta
from typing import TYPE_CHECKING, Any

from ma_application.mcp import Refreshed, RefreshFailed
from ma_domain.vaults import OAuthTokens

if TYPE_CHECKING:
    from datetime import datetime

    import httpx

#: 만료 직전에 미리 갱신하는 여유. 0 이면 **만료된 뒤에야** 갱신하고,
#: 그 사이의 호출이 전부 401 로 한 번씩 헛돈다.
REFRESH_SKEW = timedelta(minutes=5)
#: 토큰 엔드포인트 타임아웃. 길게 잡으면 **툴 호출 하나가 그만큼 멈춘다.**
TOKEN_TIMEOUT = 10.0
#: 재시도 횟수. 한 번이다 — 위 docstring 참고.
MAX_RETRY = 1


@dataclass(frozen=True, slots=True)
class TokenEndpoint:
    """갱신을 보낼 곳. **토큰 자체는 여기 없다.**"""

    url: str
    client_id: str = ""
    #: 공개 클라이언트(PKCE)면 비어 있다. 있으면 Basic 으로 보낸다.
    client_secret: str = ""

    def __repr__(self) -> str:
        # 기본 `repr` 이 `client_secret` 을 출력한다.
        return f"TokenEndpoint(url={self.url!r}, client_id={self.client_id!r}, secret=<가림>)"


#: 결과 타입은 **L4 가 정의한다** (`ma_application.mcp`). 유스케이스가
#: 커넥터를 import 하면 의존이 위로 흐르므로, 계약을 아래 두고 구현이
#: 내려와 맞춘다 (`plan/03` §2).
type RefreshResult = Refreshed | RefreshFailed

#: 이 오류들은 **다시 시도해도 같다.** RFC 6749 §5.2.
PERMANENT_ERRORS = frozenset(
    {"invalid_grant", "invalid_client", "unauthorized_client", "unsupported_grant_type"}
)


@dataclass
class OAuthRefresher:
    """갱신 토큰 → 새 access token.

    **`client` 를 주입받는다.** 테스트가 가짜를 꽂고, 배포가 프록시와
    타임아웃을 정한다.
    """

    client: httpx.AsyncClient
    timeout: float = TOKEN_TIMEOUT

    async def refresh(self, tokens: OAuthTokens, now: datetime) -> RefreshResult:
        import httpx

        if not tokens.refreshable:
            # **갱신 토큰이 없으면 영구 실패다.** 수동 재연결뿐이다 —
            # 재시도 큐에 넣어 봐야 영원히 같은 답이 온다.
            return RefreshFailed(
                reason="갱신 토큰 또는 토큰 엔드포인트가 없다 — 수동 재연결이 필요하다",
                permanent=True,
            )

        form = {
            "grant_type": "refresh_token",
            "refresh_token": tokens.refresh_token,
        }
        if tokens.client_id:
            form["client_id"] = tokens.client_id
        if tokens.scope:
            form["scope"] = tokens.scope

        try:
            response = await self.client.post(
                tokens.token_endpoint,
                data=form,
                headers={"accept": "application/json"},
                timeout=self.timeout,
            )
        except httpx.HTTPError as exc:
            # **일시 실패다.** 네트워크가 끊긴 것과 토큰이 죽은 것은
            # 다르고, 전자를 영구로 적으면 멀쩡한 연결을 사람이 다시
            # 만들게 된다.
            return RefreshFailed(reason=f"토큰 엔드포인트에 못 닿았다: {type(exc).__name__}")

        body = _json_or_empty(response)
        if response.status_code >= 400:
            code = str(body.get("error") or f"http_{response.status_code}")
            return RefreshFailed(
                reason=f"토큰 엔드포인트가 거부했다: {code}",
                permanent=code in PERMANENT_ERRORS,
            )

        access = str(body.get("access_token") or "")
        if not access:
            return RefreshFailed(reason="응답에 access_token 이 없다", permanent=True)

        return Refreshed(
            tokens=OAuthTokens(
                access_token=access,
                # **갱신 토큰을 안 주면 옛 것을 유지한다.** RFC 6749
                # §6 — 로테이션하는 서버만 새로 준다. 빈 값으로
                # 덮으면 다음 갱신이 영구 실패가 된다.
                refresh_token=str(body.get("refresh_token") or tokens.refresh_token),
                token_endpoint=tokens.token_endpoint,
                client_id=tokens.client_id,
                scope=str(body.get("scope") or tokens.scope),
            ),
            expires_at=_expires_at(body.get("expires_in"), now),
        )


def _json_or_empty(response: Any) -> dict[str, Any]:
    try:
        got = response.json()
    except Exception:
        return {}
    return got if isinstance(got, dict) else {}


def _expires_at(raw: Any, now: datetime) -> datetime | None:
    """`expires_in` (초) → 절대 시각. **여유를 뺀다.**

    만료 시각 그대로 적으면 그 순간에 걸친 호출이 401 을 맞는다 —
    `REFRESH_SKEW` 만큼 일찍 만료로 쳐서 미리 갱신한다.
    """
    try:
        seconds = int(raw)
    except (TypeError, ValueError):
        return None
    if seconds <= 0:
        return None
    return now + max(timedelta(seconds=seconds) - REFRESH_SKEW, timedelta(seconds=1))


__all__ = [
    "MAX_RETRY",
    "PERMANENT_ERRORS",
    "REFRESH_SKEW",
    "TOKEN_TIMEOUT",
    "OAuthRefresher",
    "RefreshFailed",
    "RefreshResult",
    "Refreshed",
    "TokenEndpoint",
]
