"""MCP 커넥터 (T-0601).

`plan/04-api.md` §6.2 · `plan/07-sandbox.md` §6.

사내 시스템(위키·티켓·저장소)을 에이전트에 붙이는 표준 경로다.

**이 패키지는 토큰을 모른다.** `Authorization` 은 egress 프록시가
주입한다 (D5). 클라이언트가 할 일은 프록시를 지나는 것뿐이고, 그
사실이 `McpClient` 에 인증 인자가 **없다**는 것으로 드러난다.
"""

from ma_connectors.mcp.client import (
    McpClient,
    McpError,
    McpProtocolError,
    McpTool,
    McpTransportError,
    McpUnauthorized,
)
from ma_connectors.mcp.oauth import (
    OAuthRefresher,
    Refreshed,
    RefreshFailed,
    RefreshResult,
    TokenEndpoint,
)
from ma_connectors.mcp.toolset import (
    McpToolset,
    ServerUnreachable,
    build_mcp_toolset,
)

__all__ = [
    "McpClient",
    "McpError",
    "McpProtocolError",
    "McpTool",
    "McpToolset",
    "McpTransportError",
    "McpUnauthorized",
    "OAuthRefresher",
    "RefreshFailed",
    "RefreshResult",
    "Refreshed",
    "ServerUnreachable",
    "TokenEndpoint",
    "build_mcp_toolset",
]
