"""MCP 툴셋 — `tools/list` → 하네스 등록 (T-0601).

`plan/06-harness-and-model.md` §4.3.

`mcp__<server>__<tool>` 이름과 실행기를 만든다. 하네스는 이것을
**다른 툴과 똑같이** 다룬다 — 그래서 권한 정책·승인·`stop_reason` 이
MCP 툴에도 그대로 적용된다 (`ToolKind.MCP`).

> **서버가 늘린 툴이 자동으로 능력이 되지 않는다.** `tools/list` 가
> 10개를 줘도 에이전트의 `allowed_tools` 에 있는 것만 등록한다. 원격
> 서버가 위험한 툴을 하나 더 노출했을 때 그것이 조용히 켜지면 안 된다.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from ma_domain.agents import mcp_tool_name

from ma_connectors.mcp.client import (
    McpClient,
    McpError,
    McpProtocolError,
    McpTool,
    McpTransportError,
    McpUnauthorized,
)

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable

    import httpx
    from ma_domain.agents import McpServerSpec
    from ma_harness.hooks import ToolOutcome
    from ma_harness.model_port import ToolCall, ToolSchema

#: 서버 하나가 안 떠도 **나머지는 돈다**는 뜻으로 남기는 표식.
UNREACHABLE_PREFIX = "MCP 서버에 닿지 못했다"


class ServerUnreachable(McpError):
    """`tools/list` 가 실패했다. **에이전트를 죽이지 않는다.**"""


@dataclass
class McpToolset:
    """서버 여러 개의 툴을 모은 것.

    `schemas` 와 `executors` 를 `build_tools` 에 그대로 넘긴다.
    """

    schemas: dict[str, ToolSchema] = field(default_factory=dict)
    executors: dict[str, Callable[[ToolCall], Awaitable[ToolOutcome]]] = field(default_factory=dict)
    #: 못 닿은 서버. **조용히 비우지 않는다** — 운영자가 봐야 한다.
    unreachable: tuple[tuple[str, str], ...] = ()

    @property
    def names(self) -> tuple[str, ...]:
        return tuple(sorted(self.schemas))


async def build_mcp_toolset(
    servers: tuple[McpServerSpec, ...],
    client: httpx.AsyncClient,
    *,
    on_unauthorized: Callable[[str], Awaitable[bool]] | None = None,
) -> McpToolset:
    """서버들에 `tools/list` 를 묻고 툴셋을 만든다.

    `on_unauthorized(server_name) -> bool` 은 **갱신을 맡기는 길**이다.
    `True` 를 돌려주면 한 번 더 시도한다. 주지 않으면 401 은 그대로
    실패다 — 워커가 갱신을 직접 하지 않는 것이 요점이므로, 조립이
    제어 평면으로 가는 함수를 꽂는다 (D5).

    **한 서버가 안 떠도 나머지는 등록된다.** 위키가 점검 중이라고
    에이전트가 티켓도 못 보면 안 된다.
    """
    toolset = McpToolset()
    failures: list[tuple[str, str]] = []

    for spec in servers:
        mcp = McpClient(server_name=spec.name, url=spec.url, client=client)
        try:
            listed = await _list_with_refresh(mcp, on_unauthorized)
        except McpError as exc:
            failures.append((spec.name, str(exc)))
            continue

        wanted = set(spec.allowed_tools)
        by_name = {t.name: t for t in listed}
        for tool_name in spec.allowed_tools:
            # **서버가 안 주는 툴도 등록한다 — 스키마만 비운 채로.**
            #
            # 빼 버리면 에이전트 설정이 켠 능력이 조용히 사라지고,
            # 사용자는 "왜 안 하지"를 묻는다. 호출하면 서버가 모르는
            # 툴이라고 답하고, 그 답이 사실이다.
            tool = by_name.get(tool_name) or McpTool(name=tool_name)
            registered = mcp_tool_name(spec.name, tool_name)
            toolset.schemas[registered] = _schema_for(registered, tool)
            toolset.executors[registered] = _executor(mcp, tool_name, on_unauthorized)

        extra = sorted(set(by_name) - wanted)
        if extra:
            # 등록하지 않는다. 운영자가 알 수 있게만 남긴다.
            failures.append(
                (spec.name, f"허용 목록 밖의 툴 {len(extra)}개를 등록하지 않았다: {extra[:5]}")
            )

    toolset.unreachable = tuple(failures)
    return toolset


async def _list_with_refresh(
    mcp: McpClient, on_unauthorized: Callable[[str], Awaitable[bool]] | None
) -> tuple[McpTool, ...]:
    try:
        return await mcp.list_tools()
    except McpUnauthorized:
        if on_unauthorized is None or not await on_unauthorized(mcp.server_name):
            raise
        # **한 번만.** 두 번째도 401 이면 갱신이 문제를 못 고쳤다.
        return await mcp.list_tools()
    except McpTransportError as exc:
        raise ServerUnreachable(f"{UNREACHABLE_PREFIX}: {exc}") from exc


def _schema_for(registered: str, tool: McpTool) -> ToolSchema:
    from ma_harness.model_port import ToolSchema

    return ToolSchema(
        name=registered,
        description=tool.description,
        parameters=tool.schema_dict(),
    )


def _executor(
    mcp: McpClient,
    remote_name: str,
    on_unauthorized: Callable[[str], Awaitable[bool]] | None,
) -> Callable[[ToolCall], Awaitable[ToolOutcome]]:
    """실행기 하나. **원격 이름으로 부른다** — 접두는 우리 것이다."""

    async def run(call: ToolCall) -> ToolOutcome:
        from ma_harness.hooks import ToolOutcome

        try:
            args = _arguments(call)
            result = await _call_with_refresh(mcp, remote_name, args, on_unauthorized)
        except McpUnauthorized as exc:
            # **툴 실패로 모델에게 돌려준다.** 러너 고장이 아니다 —
            # 자격증명 문제이고, 모델이 다른 방법을 찾을 수 있다.
            return ToolOutcome(content=f"인증 실패: {exc}", is_error=True)
        except McpError as exc:
            return ToolOutcome(content=f"MCP 호출 실패: {exc}", is_error=True)
        return ToolOutcome(content=_render(result), is_error=bool(result.get("isError")))

    return run


async def _call_with_refresh(
    mcp: McpClient,
    remote_name: str,
    args: dict[str, Any],
    on_unauthorized: Callable[[str], Awaitable[bool]] | None,
) -> dict[str, Any]:
    try:
        return await mcp.call_tool(remote_name, args)
    except McpUnauthorized:
        if on_unauthorized is None or not await on_unauthorized(mcp.server_name):
            raise
        return await mcp.call_tool(remote_name, args)


def _arguments(call: ToolCall) -> dict[str, Any]:
    """`ToolCall.arguments` 는 **JSON 문자열**이다 (`model_port`).

    깨진 JSON 을 빈 인자로 바꾸지 않는다 — 인자 없이 호출하면 서버가
    기본값으로 뭔가를 **실제로 한다.** 모델이 잘못 쓴 것을 우리가
    "아무것도 안 준 것"으로 번역하면 안 된다.
    """
    raw = call.arguments.strip()
    if not raw:
        return {}
    try:
        got = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise McpProtocolError(f"툴 인자가 JSON 이 아니다: {exc}") from exc
    if not isinstance(got, dict):
        raise McpProtocolError("툴 인자가 객체가 아니다")
    return got


def _render(result: dict[str, Any]) -> str:
    """MCP `content` 블록 → 모델이 읽을 텍스트.

    `text` 블록만 펼친다. 이미지·리소스는 **참조만 남긴다** — 본문을
    펼치면 base64 가 컨텍스트를 통째로 먹는다.
    """
    content = result.get("content")
    if not isinstance(content, list):
        return json.dumps(result, ensure_ascii=False, sort_keys=True)

    parts: list[str] = []
    for block in content:
        if not isinstance(block, dict):
            continue
        kind = block.get("type")
        if kind == "text":
            parts.append(str(block.get("text", "")))
        elif kind == "resource":
            ref = block.get("resource")
            uri = ref.get("uri") if isinstance(ref, dict) else None
            parts.append(f"[리소스 {uri or '?'}]")
        else:
            parts.append(f"[{kind} 블록 — 본문 생략]")
    return "\n".join(parts) if parts else ""


__all__ = [
    "UNREACHABLE_PREFIX",
    "McpProtocolError",
    "McpToolset",
    "ServerUnreachable",
    "build_mcp_toolset",
]
