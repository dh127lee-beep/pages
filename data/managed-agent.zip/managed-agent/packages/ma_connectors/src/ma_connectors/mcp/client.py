"""MCP 클라이언트 — streamable HTTP, SSE 폴백 (T-0601).

`plan/04-api.md` §6.2 · `plan/07-sandbox.md` §6.

> **토큰을 모른다.** 생성자에 인증 인자가 없다. `Authorization` 은
> egress 프록시가 `(workspace, session, host)` 로 조회해 주입한다 (D5).
> 이 클래스가 토큰을 받을 수 있게 만들면, 언젠가 누군가 넘긴다.

전송은 두 가지다:

| | 언제 | 응답 |
|---|---|---|
| **streamable HTTP** | 기본 | `application/json` 한 방 |
| **SSE 폴백** | 서버가 `text/event-stream` 으로 답할 때 | `data:` 줄을 모아 마지막 JSON-RPC 응답 |

폴백을 **요청 헤더가 아니라 응답 content-type 으로** 정하는 이유:
서버가 무엇을 지원하는지 미리 물어보면 왕복이 한 번 더 들고, 그
왕복이 틀릴 수도 있다. `Accept` 에 둘 다 싣고 **서버가 고르게** 한다.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    import httpx

#: JSON-RPC 2.0.
JSONRPC = "2.0"
#: 둘 다 받는다고 알린다 — **서버가 고른다.**
ACCEPT = "application/json, text/event-stream"
#: MCP 프로토콜 버전. 서버가 다른 것을 주면 그대로 받아 적어 둔다 —
#: 협상 실패로 연결을 끊지 않는다 (대부분의 서버가 하위 호환이다).
PROTOCOL_VERSION = "2025-06-18"
#: 한 응답의 최대 바이트. **넘으면 끊는다.**
#:
#: 상한이 없으면 고장난(또는 악의적인) MCP 서버가 워커 메모리를
#: 채운다. 툴 결과는 어차피 컨텍스트에 실리므로 이보다 커 봐야
#: 모델에 못 넣는다.
MAX_RESPONSE_BYTES = 4 * 1024 * 1024
DEFAULT_TIMEOUT = 30.0


class McpError(Exception):
    """MCP 호출이 실패했다."""


class McpTransportError(McpError):
    """못 닿았다 · 타임아웃 · 5xx. **재시도할 만하다.**"""


class McpUnauthorized(McpError):
    """401/403. **OAuth 갱신을 부를 신호다.**

    별도 예외인 이유: 호출자가 "갱신하고 한 번 더"를 다른 실패와
    구분해서 해야 한다. 전부 `McpTransportError` 로 뭉치면 갱신이
    안 되거나, 반대로 모든 실패에 갱신을 시도한다.
    """

    def __init__(self, status: int, server: str) -> None:
        super().__init__(f"MCP 서버 {server} 가 {status} 를 돌려줬다")
        self.status = status
        self.server = server


class McpProtocolError(McpError):
    """JSON-RPC 가 아니거나 `error` 를 돌려줬다. **재시도해도 같다.**"""


@dataclass(frozen=True, slots=True)
class McpTool:
    """`tools/list` 의 한 항목."""

    name: str
    description: str = ""
    input_schema: tuple[tuple[str, Any], ...] = ()

    def schema_dict(self) -> dict[str, Any]:
        return dict(self.input_schema)


@dataclass
class McpClient:
    """원격 HTTP MCP 서버 하나.

    **`client` 를 주입받는다.** 프록시·타임아웃·CA 를 조립이 정한다 —
    여기서 만들면 워커가 프록시를 안 지나는 경로가 생긴다.
    """

    server_name: str
    url: str
    client: httpx.AsyncClient
    timeout: float = DEFAULT_TIMEOUT
    #: 서버가 준 세션 id. 있으면 다음 요청에 실어 준다.
    session_id: str | None = field(default=None, init=False)
    _next_id: int = field(default=0, init=False)

    async def list_tools(self) -> tuple[McpTool, ...]:
        result = await self.call("tools/list", {})
        raw = result.get("tools")
        if not isinstance(raw, list):
            raise McpProtocolError(f"{self.server_name}: tools/list 가 목록이 아니다")
        return tuple(_tool_from(item) for item in raw if isinstance(item, dict))

    async def call_tool(self, name: str, arguments: dict[str, Any]) -> dict[str, Any]:
        """`tools/call`. **서버가 부르는 이름 그대로 보낸다.**

        `mcp__<server>__` 접두는 우리 하네스의 것이지 서버의 것이
        아니다 — 붙여 보내면 서버가 모르는 툴이라고 답한다.
        """
        return await self.call("tools/call", {"name": name, "arguments": arguments})

    async def call(self, method: str, params: dict[str, Any]) -> dict[str, Any]:
        import httpx

        self._next_id += 1
        body = {"jsonrpc": JSONRPC, "id": self._next_id, "method": method, "params": params}
        headers = {
            "content-type": "application/json",
            "accept": ACCEPT,
            "mcp-protocol-version": PROTOCOL_VERSION,
        }
        if self.session_id:
            headers["mcp-session-id"] = self.session_id

        try:
            response = await self.client.post(
                self.url, json=body, headers=headers, timeout=self.timeout
            )
        except httpx.HTTPError as exc:
            # **프록시가 막은 것도 여기로 온다.** 그 경우 재시도해도
            # 같지만, 구분할 정보가 전송 계층에 없다 — 호출자가
            # `credential_events` 에서 본다.
            raise McpTransportError(f"{self.server_name}: {type(exc).__name__}: {exc}") from exc

        if response.status_code in (401, 403):
            raise McpUnauthorized(response.status_code, self.server_name)
        if response.status_code >= 500:
            raise McpTransportError(f"{self.server_name}: 업스트림 {response.status_code}")
        if response.status_code >= 400:
            raise McpProtocolError(f"{self.server_name}: {response.status_code}")

        got = response.headers.get("mcp-session-id")
        if got:
            self.session_id = got

        content_type = response.headers.get("content-type", "")
        payload = (
            _parse_sse(response.text, self.server_name)
            if "text/event-stream" in content_type
            else _parse_json(response.content, self.server_name)
        )
        return _result_of(payload, self.server_name)


def _parse_json(raw: bytes, server: str) -> dict[str, Any]:
    if len(raw) > MAX_RESPONSE_BYTES:
        # **상한을 넘으면 끊는다.** 고장난 서버가 워커 메모리를 채운다.
        raise McpProtocolError(f"{server}: 응답이 {MAX_RESPONSE_BYTES} 바이트를 넘는다")
    try:
        got = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise McpProtocolError(f"{server}: JSON 이 아니다") from exc
    if not isinstance(got, dict):
        raise McpProtocolError(f"{server}: JSON-RPC 객체가 아니다")
    return got


def _parse_sse(text: str, server: str) -> dict[str, Any]:
    """SSE 스트림에서 **마지막 JSON-RPC 응답**을 꺼낸다.

    서버가 진행 알림(`notifications/progress`)을 여러 개 보내고 마지막에
    응답을 준다. 알림에는 `id` 가 없으므로 **`id` 가 있는 것만** 본다 —
    첫 `data:` 를 집으면 진행 알림을 결과로 쓰게 된다.
    """
    if len(text) > MAX_RESPONSE_BYTES:
        raise McpProtocolError(f"{server}: 응답이 {MAX_RESPONSE_BYTES} 바이트를 넘는다")

    last: dict[str, Any] | None = None
    for line in text.splitlines():
        if not line.startswith("data:"):
            continue
        chunk = line[len("data:") :].strip()
        if not chunk or chunk == "[DONE]":
            continue
        try:
            got = json.loads(chunk)
        except json.JSONDecodeError:
            # **한 줄이 깨졌다고 전체를 버리지 않는다** — 뒤에 올바른
            # 응답이 올 수 있다. 끝까지 못 찾으면 그때 터진다.
            continue
        if isinstance(got, dict) and "id" in got:
            last = got
    if last is None:
        raise McpProtocolError(f"{server}: SSE 에 JSON-RPC 응답이 없다")
    return last


def _result_of(payload: dict[str, Any], server: str) -> dict[str, Any]:
    if "error" in payload:
        err = payload["error"]
        message = err.get("message") if isinstance(err, dict) else str(err)
        raise McpProtocolError(f"{server}: {message}")
    result = payload.get("result")
    if not isinstance(result, dict):
        raise McpProtocolError(f"{server}: result 가 객체가 아니다")
    return result


def _tool_from(item: dict[str, Any]) -> McpTool:
    schema = item.get("inputSchema") or item.get("input_schema") or {}
    return McpTool(
        name=str(item.get("name", "")),
        description=str(item.get("description", "")),
        input_schema=tuple(sorted(schema.items())) if isinstance(schema, dict) else (),
    )


__all__ = [
    "ACCEPT",
    "DEFAULT_TIMEOUT",
    "JSONRPC",
    "MAX_RESPONSE_BYTES",
    "PROTOCOL_VERSION",
    "McpClient",
    "McpError",
    "McpProtocolError",
    "McpTool",
    "McpTransportError",
    "McpUnauthorized",
]
