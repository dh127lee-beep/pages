"""Slack incoming webhook 알림 (T-0604).

`plan/04-api.md` §3.8.

**incoming webhook 만 쓴다** (봇 토큰이 아니라). 봇 토큰은 워크스페이스
전체에 대한 권한이고, 우리가 필요한 것은 **한 채널에 글을 쓰는 것**
뿐이다 — 최소 권한이다.

URL 자체가 비밀이다. `credentials` 볼트에 두고 조립이 꺼내 준다 —
이 코드는 URL 을 받기만 하고 어디서 왔는지 모른다 (D5).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    import httpx
    from ma_domain.webhooks import NotifyMessage

TIMEOUT_SECONDS = 10.0


class NotifyFailed(Exception):
    """보내지 못했다. **승인 흐름을 막지 않는다** — 호출자가 삼킨다."""


@dataclass
class SlackNotifier:
    client: httpx.AsyncClient
    webhook_url: str

    async def send(self, message: NotifyMessage) -> None:
        response = await self.client.post(
            self.webhook_url, json=_blocks(message), timeout=TIMEOUT_SECONDS
        )
        if response.status_code >= 400:
            raise NotifyFailed(f"Slack {response.status_code}: {response.text[:200]}")


def _blocks(message: NotifyMessage) -> dict[str, Any]:
    """Block Kit. **링크를 버튼으로 둔다** — 받은 사람이 바로 누른다.

    `text` 도 함께 넣는다: 알림 미리보기(모바일 잠금화면)가 blocks 를
    렌더하지 못하고 `text` 를 쓴다. 없으면 "이 메시지를 볼 수
    없습니다"가 뜬다.
    """
    prefix = "🔴 " if message.urgent else ""
    blocks: list[dict[str, Any]] = [
        {
            "type": "section",
            "text": {"type": "mrkdwn", "text": f"*{prefix}{message.title}*\n{message.body}"},
        }
    ]
    if message.fields:
        blocks.append(
            {
                "type": "section",
                "fields": [
                    {"type": "mrkdwn", "text": f"*{k}*\n{v}"} for k, v in message.fields[:10]
                ],
            }
        )
    if message.link:
        blocks.append(
            {
                "type": "actions",
                "elements": [
                    {
                        "type": "button",
                        "text": {"type": "plain_text", "text": "열기"},
                        "url": message.link,
                    }
                ],
            }
        )
    return {"text": f"{prefix}{message.title}", "blocks": blocks}


__all__ = ["TIMEOUT_SECONDS", "NotifyFailed", "SlackNotifier"]
