"""사내 알림 — Slack · 메일 (T-0604).

웹훅과 **다른 것이다**: 웹훅은 기계가 받고 이것은 사람이 읽는다.
그래서 모양이 다르고 **승인 링크가 들어간다** — 받은 사람이 바로
누를 수 있어야 한다.

> **auto-mirror 를 만들지 않는다** (작업 명세). 에이전트가 Slack 에
> 답장하려면 MCP 툴로 **명시적으로** 보내야 한다. 알림은 나가는
> 통지이지 대화 통로가 아니다.
"""

from ma_connectors.notify.email import SmtpNotifier
from ma_connectors.notify.slack import SlackNotifier

__all__ = ["SlackNotifier", "SmtpNotifier"]
