"""SMTP 알림 (T-0604).

**스레드로 묶는다.** 같은 세션의 알림이 하나의 메일 스레드가 되도록
`Message-ID` 와 `In-Reply-To` 를 세션 id 에서 만든다 — 안 묶으면
승인 하나에 메일 세 통이 따로 온다.

`aiosmtplib` 를 쓰지 않고 표준 `smtplib` 를 **스레드에서** 돌린다.
의존을 하나 줄이는 것이 이득이고, 알림은 초당 수백 건이 아니다.
"""

from __future__ import annotations

import hashlib
import logging
import smtplib
from dataclasses import dataclass, field
from email.message import EmailMessage
from typing import TYPE_CHECKING

import anyio

if TYPE_CHECKING:
    from ma_domain.webhooks import NotifyMessage

_log = logging.getLogger("ma_connectors.notify.email")

TIMEOUT_SECONDS = 20.0


class NotifyFailed(Exception):
    """보내지 못했다."""


@dataclass
class SmtpNotifier:
    host: str
    sender: str
    recipients: tuple[str, ...]
    port: int = 587
    username: str = ""
    password: str = ""
    use_tls: bool = True
    #: 스레드 묶음에 쓸 도메인. `Message-ID` 의 오른쪽이다.
    domain: str = "awp.invalid"
    _extra_headers: dict[str, str] = field(default_factory=dict)

    async def send(self, message: NotifyMessage, *, thread_key: str = "") -> None:
        """**스레드에서 돈다.** `smtplib` 는 동기이고, 이벤트 루프를
        멈추면 SSE 하트비트가 끊긴다."""
        mail = self._build(message, thread_key)
        await anyio.to_thread.run_sync(self._deliver, mail)

    def _build(self, message: NotifyMessage, thread_key: str) -> EmailMessage:
        mail = EmailMessage()
        mail["From"] = self.sender
        mail["To"] = ", ".join(self.recipients)
        mail["Subject"] = ("[긴급] " if message.urgent else "") + message.title

        if thread_key:
            # **같은 세션의 알림을 한 스레드로.** 안 묶으면 승인 하나에
            # 메일 세 통이 따로 온다.
            digest = hashlib.sha256(thread_key.encode()).hexdigest()[:24]
            root = f"<awp-{digest}@{self.domain}>"
            mail["References"] = root
            mail["In-Reply-To"] = root

        body = [message.body]
        for key, value in message.fields:
            body.append(f"{key}: {value}")
        if message.link:
            body.append(f"\n열기: {message.link}")
        mail.set_content("\n".join(body))
        return mail

    def _deliver(self, mail: EmailMessage) -> None:
        try:
            with smtplib.SMTP(self.host, self.port, timeout=TIMEOUT_SECONDS) as smtp:
                if self.use_tls:
                    smtp.starttls()
                if self.username:
                    smtp.login(self.username, self.password)
                smtp.send_message(mail)
        except Exception as exc:
            raise NotifyFailed(f"{type(exc).__name__}: {exc}") from exc


__all__ = ["TIMEOUT_SECONDS", "NotifyFailed", "SmtpNotifier"]
