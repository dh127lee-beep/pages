"""스킬 소스 로더 (T-0602)."""

from ma_connectors.skills.github import GitHubSkillLoader, SkillLoadError

__all__ = ["GitHubSkillLoader", "SkillLoadError"]
