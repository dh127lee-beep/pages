"""GitHub 저장소에서 스킬을 읽는다 (T-0602).

`plan/01-product-concept.md` §4 · `task/M5-extensions/T-0602-skills.md`.

**커밋을 박는다.** `ref` 로 읽되 응답의 실제 SHA 를 `SkillSource.commit`
에 넣는다 — 에이전트가 스킬 버전을 핀하므로, 같은 버전이 다른 내용을
보면 재현이 깨진다. 브랜치를 그대로 두면 **말없이 바뀐다.**

> **토큰을 직접 들지 않는다.** 사설 저장소는 egress 프록시가 주입한다
> (`plan/07` §6) — 여기서는 프록시를 거쳐 나가고, 클라이언트 코드는
> 토큰을 보지 않는다 (D5).

Git 프로토콜을 쓰지 않고 **Contents API** 를 쓴다. `git clone` 은
`.git` 전체를 가져오고 서브프로세스가 필요하며, 우리가 원하는 것은
디렉터리 하나의 파일 몇 개다.
"""

from __future__ import annotations

import base64
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from ma_domain.skills import (
    MAX_SKILL_BYTES,
    MAX_SKILL_FILES,
    SkillDocument,
    SkillFile,
    SkillSource,
)

if TYPE_CHECKING:
    import httpx

#: 읽어 올 파일 확장자. **코드를 가져오지 않는다** — 스킬은 읽을
#: 문서이고, 실행 가능한 것을 마운트하면 샌드박스 안에서 돌 수 있다.
TEXT_SUFFIXES = (".md", ".txt", ".json", ".yaml", ".yml", ".csv")

#: 설명을 찾을 파일. 없으면 첫 `.md` 의 첫 줄.
DESCRIPTION_FILES = ("SKILL.md", "README.md")

DEFAULT_API = "https://api.github.com"


class SkillLoadError(Exception):
    """읽지 못했다. **부분 저장을 만들지 않는다** — 유스케이스가
    `SourceUnavailable` 로 번역한다."""


@dataclass
class GitHubSkillLoader:
    """`SkillSourceLoader` 구현.

    `client` 를 주입받는다 — 조립이 **프록시를 거치는** httpx 클라이언트를
    꽂는다. 여기서 만들면 프록시 설정이 두 벌이 된다.
    """

    client: httpx.AsyncClient
    api_base: str = DEFAULT_API
    max_files: int = MAX_SKILL_FILES
    max_bytes: int = MAX_SKILL_BYTES
    _headers: dict[str, str] = field(
        default_factory=lambda: {"Accept": "application/vnd.github+json"}
    )

    async def load(self, source: SkillSource) -> SkillDocument:
        owner_repo = source.repo.strip("/")
        ref = source.commit or source.ref
        listing = await self._get(
            f"/repos/{owner_repo}/contents/{source.path.strip('/')}",
            params={"ref": ref},
        )
        if not isinstance(listing, list):
            raise SkillLoadError(f"디렉터리가 아니다: {source.path!r}")

        files: list[SkillFile] = []
        total = 0
        for entry in sorted(listing, key=lambda e: str(e.get("name", ""))):
            if entry.get("type") != "file":
                continue
            name = str(entry.get("name", ""))
            if not name.endswith(TEXT_SUFFIXES):
                # **코드를 가져오지 않는다.** 실행 가능한 것을 마운트하면
                # 샌드박스 안에서 돌 수 있다.
                continue
            if len(files) >= self.max_files:
                raise SkillLoadError(f"파일이 {self.max_files}개를 넘는다")
            content = await self._content(owner_repo, f"{source.path}/{name}", ref)
            total += len(content.encode("utf-8"))
            if total > self.max_bytes:
                raise SkillLoadError(f"스킬이 {self.max_bytes:,}바이트를 넘는다")
            files.append(SkillFile(path=name, content=content))

        if not files:
            raise SkillLoadError(f"읽을 파일이 없다: {source.repo}/{source.path}")

        # **실제 커밋을 박는다.** 브랜치로 읽었어도 결과는 고정된다.
        resolved = source.commit or await self._resolve_commit(owner_repo, source.ref)
        return SkillDocument(
            description=_description(files),
            files=tuple(files),
            source=SkillSource(repo=source.repo, path=source.path, commit=resolved, ref=source.ref),
        )

    async def _get(self, path: str, params: dict[str, str] | None = None) -> Any:
        response = await self.client.get(
            f"{self.api_base}{path}", params=params, headers=self._headers
        )
        if response.status_code == 404:
            raise SkillLoadError(f"없다: {path}")
        if response.status_code >= 400:
            raise SkillLoadError(f"{response.status_code} {path}")
        return response.json()

    async def _content(self, repo: str, path: str, ref: str) -> str:
        body = await self._get(f"/repos/{repo}/contents/{path.strip('/')}", {"ref": ref})
        if not isinstance(body, dict):  # pragma: no cover — 파일은 dict 다
            raise SkillLoadError(f"파일이 아니다: {path}")
        encoded = str(body.get("content", ""))
        if body.get("encoding") != "base64":
            return encoded
        try:
            return base64.b64decode(encoded).decode("utf-8")
        except (ValueError, UnicodeDecodeError) as exc:
            # **바이너리를 스킬로 만들지 않는다.** 모델이 읽을 수 없다.
            raise SkillLoadError(f"텍스트가 아니다: {path}") from exc

    async def _resolve_commit(self, repo: str, ref: str) -> str:
        try:
            body = await self._get(f"/repos/{repo}/commits/{ref}")
        except SkillLoadError:
            # 커밋을 못 알아내도 **파일은 읽었다.** 비워 두고 넘어간다 —
            # 재현성은 약해지지만 스킬은 동작한다.
            return ""
        return str(body.get("sha", "")) if isinstance(body, dict) else ""


def _description(files: list[SkillFile]) -> str:
    """카탈로그 한 줄. `SKILL.md`·`README.md` 의 첫 의미 있는 줄.

    못 찾으면 첫 파일 이름을 쓴다 — **빈 설명은 도메인이 거부한다**
    (카탈로그에 쓸 것이 없으면 스킬이 보이지 않는다).
    """
    by_name = {f.path: f for f in files}
    for candidate in DESCRIPTION_FILES:
        found = by_name.get(candidate)
        if found is None:
            continue
        for line in found.content.splitlines():
            text = line.strip().lstrip("#").strip()
            if text:
                return text[:200]
    return files[0].path


__all__ = [
    "DEFAULT_API",
    "DESCRIPTION_FILES",
    "TEXT_SUFFIXES",
    "GitHubSkillLoader",
    "SkillLoadError",
]
