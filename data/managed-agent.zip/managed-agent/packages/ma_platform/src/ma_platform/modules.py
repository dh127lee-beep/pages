"""도메인별 AppModule.

`plan/03-layers.md` §4 — 각 기능은 **좁은 Store Port만** 받는다.
범용 `Store` 서비스 로케이터는 없다 (R3).

`ma_platform`은 L6이므로 `ma_store`·`ma_application`을 import할 수 있다.
`PortToken[X]`는 런타임 서브스크립트라 문자열 전방참조가 풀리지 않는다 — 실제로 import한다.
"""

from __future__ import annotations

from typing import Any

from ma_application.agents import AgentsUseCases
from ma_store.agents import AgentStore

from ma_platform.capabilities import clock_port, id_generator_port, workspace_context_port
from ma_platform.kernel import AppModule, Binding, PortResolver, PortToken, bind, module

# ── Store Port 토큰 ─────────────────────────────────────────
# 타입이 붙은 것은 구현이 있는 것. `Any`는 해당 작업에서 좁혀진다.
agent_store_port = PortToken[AgentStore]("ma.store.agents")
workspace_store_port = PortToken[Any]("ma.store.workspaces")  # T-0103+
model_card_store_port = PortToken[Any]("ma.store.models")  # T-0204
environment_store_port = PortToken[Any]("ma.store.environments")  # T-0206
session_store_port = PortToken[Any]("ma.store.sessions")  # T-0203
event_store_port = PortToken[Any]("ma.store.events")  # T-0202
execution_store_port = PortToken[Any]("ma.store.executions")  # T-0201

# ── 유스케이스 Port 토큰 ────────────────────────────────────
agents_port = PortToken[AgentsUseCases]("ma.app.agents")


def agents_module() -> AppModule:
    """에이전트 유스케이스.

    `requires`에 없는 Port를 `port()`로 꺼내면 **조립 시점에** 실패한다 (규칙 R2).
    """

    def setup(port: PortResolver) -> list[Binding]:
        ids = port(id_generator_port)
        return [
            bind(
                agents_port,
                AgentsUseCases(
                    workspace_id=port(workspace_context_port),
                    clock=port(clock_port),
                    store=port(agent_store_port),
                    next_id=lambda: str(ids.next("agent")),
                ),
            )
        ]

    return module(
        name="ma:agents",
        provides=[agents_port],
        requires=[workspace_context_port, clock_port, id_generator_port, agent_store_port],
        setup=setup,
    )


#: 1단계에 켜는 모듈. 작업이 진행되면 늘어난다.
def default_modules() -> list[AppModule]:
    return [agents_module()]
