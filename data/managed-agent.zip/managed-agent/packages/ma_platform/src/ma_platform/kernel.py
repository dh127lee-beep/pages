"""조립 커널 — PortToken · AppModule · create_app.

`plan/03-layers.md` §3 L6 · §4.

외부 DI 프레임워크를 쓰지 않는다. 필요한 것은 네 가지뿐이고, 직접 쓰면 **실패 시점을
우리가 정할 수 있다** — 선언하지 않은 Port를 꺼내면 런타임이 아니라 **조립 시점에** 실패한다.

규칙 R2: 모듈은 선언한 의존성만 받는다. 앱 그래프·컨테이너·환경변수·전체 Store 묶음을
resolve할 수 없다.
"""

from __future__ import annotations

from collections.abc import Callable, Sequence
from dataclasses import dataclass, field
from typing import Any


class AssemblyError(Exception):
    """조립 시점 오류. 런타임까지 미루지 않는다."""


class PortToken[T]:
    """타입 있는 이름표. 구현을 모른다.

    같은 이름의 토큰을 두 번 만들면 서로 다른 토큰이다 — 모듈이 토큰 객체를
    공유해야 한다는 뜻이고, 그것이 의존을 명시적으로 만든다.
    """

    __slots__ = ("name",)

    def __init__(self, name: str) -> None:
        if not name or "." not in name:
            raise AssemblyError(f"Port 이름은 `ma.<레이어>.<도메인>` 형식이어야 한다: {name!r}")
        self.name = name

    def __repr__(self) -> str:
        return f"PortToken({self.name!r})"

    def __hash__(self) -> int:
        return id(self)

    def __eq__(self, other: object) -> bool:
        return self is other


@dataclass(frozen=True, slots=True)
class Binding:
    """토큰 → 값."""

    token: PortToken[Any]
    value: Any


def bind[T](token: PortToken[T], value: T) -> Binding:
    return Binding(token=token, value=value)


def provide[T](token: PortToken[T], value: T) -> Binding:
    """조립 루트가 밖에서 넣어 주는 것 (Store 구현, clock, id 생성기 …)."""
    return Binding(token=token, value=value)


#: 모듈 `setup`에 넘어가는 resolver. **선언한 토큰만** 꺼낼 수 있다.
type PortResolver = Callable[[PortToken[Any]], Any]


@dataclass(frozen=True, slots=True)
class AppModule:
    """하나의 기능 단위.

    `requires`에 없는 토큰을 `port()`로 꺼내면 `AssemblyError`가 난다 —
    선언과 실제가 어긋날 수 없다.
    """

    name: str
    provides: tuple[PortToken[Any], ...]
    requires: tuple[PortToken[Any], ...]
    setup: Callable[[PortResolver], Sequence[Binding]]
    start: Callable[[PortResolver], Any] | None = None
    stop: Callable[[PortResolver], Any] | None = None


def module(
    *,
    name: str,
    provides: Sequence[PortToken[Any]] = (),
    requires: Sequence[PortToken[Any]] = (),
    setup: Callable[[PortResolver], Sequence[Binding]],
    start: Callable[[PortResolver], Any] | None = None,
    stop: Callable[[PortResolver], Any] | None = None,
) -> AppModule:
    return AppModule(
        name=name,
        provides=tuple(provides),
        requires=tuple(requires),
        setup=setup,
        start=start,
        stop=stop,
    )


@dataclass
class App:
    """조립된 그래프. 워크스페이스 하나에 핀된다."""

    workspace_id: str
    _bindings: dict[PortToken[Any], Any] = field(default_factory=dict)
    _modules: tuple[AppModule, ...] = ()
    _started: list[AppModule] = field(default_factory=list)

    def port[T](self, token: PortToken[T]) -> T:
        if token not in self._bindings:
            raise AssemblyError(f"제공되지 않은 Port: {token.name}")
        return self._bindings[token]  # type: ignore[no-any-return]

    def has(self, token: PortToken[Any]) -> bool:
        return token in self._bindings

    async def start(self) -> None:
        """실패하면 **이미 시작한 것들을 역순으로** 정리한다."""
        for m in self._modules:
            if m.start is None:
                continue
            try:
                result = m.start(self._scoped(m))
                if hasattr(result, "__await__"):
                    await result
            except Exception:
                await self._stop_started()
                raise
            self._started.append(m)

    async def stop(self) -> None:
        await self._stop_started()

    async def _stop_started(self) -> None:
        errors: list[Exception] = []
        for m in reversed(self._started):
            if m.stop is None:
                continue
            try:
                result = m.stop(self._scoped(m))
                if hasattr(result, "__await__"):
                    await result
            except Exception as exc:
                errors.append(exc)
        self._started.clear()
        if errors:
            raise ExceptionGroup("모듈 정리 중 오류", errors)

    def _scoped(self, m: AppModule) -> PortResolver:
        allowed = set(m.requires) | set(m.provides)

        def resolve(token: PortToken[Any]) -> Any:
            if token not in allowed:
                raise AssemblyError(
                    f"모듈 {m.name!r}이 선언하지 않은 Port를 꺼내려 한다: {token.name}. "
                    f"requires 에 추가하라 (규칙 R2)"
                )
            return self.port(token)

        return resolve


def create_app(
    *,
    workspace_id: str,
    modules: Sequence[AppModule],
    provided: Sequence[Binding] = (),
) -> App:
    """의존 순서대로 모듈을 조립한다.

    순환 의존이나 미제공 Port는 **여기서** 실패한다.
    """
    app = App(workspace_id=workspace_id)
    for b in provided:
        app._bindings[b.token] = b.value

    pending = list(modules)
    ordered: list[AppModule] = []
    guard = 0
    while pending:
        guard += 1
        if guard > len(modules) + 1:
            names = ", ".join(m.name for m in pending)
            missing = {t.name for m in pending for t in m.requires if t not in app._bindings}
            raise AssemblyError(
                f"조립할 수 없다 — 순환 의존이거나 제공되지 않은 Port가 있다.\n"
                f"  남은 모듈: {names}\n  없는 Port: {sorted(missing)}"
            )
        progressed = False
        for m in list(pending):
            if any(t not in app._bindings for t in m.requires):
                continue
            for b in m.setup(app._scoped(m)):
                if b.token not in m.provides:
                    raise AssemblyError(
                        f"모듈 {m.name!r}이 provides에 없는 Port를 bind한다: {b.token.name}"
                    )
                app._bindings[b.token] = b.value
            missing_provides = [t.name for t in m.provides if t not in app._bindings]
            if missing_provides:
                raise AssemblyError(
                    f"모듈 {m.name!r}이 선언한 Port를 bind하지 않았다: {missing_provides}"
                )
            pending.remove(m)
            ordered.append(m)
            progressed = True
        if not progressed:
            guard = len(modules) + 2  # 다음 바퀴에서 자세한 메시지로 실패

    app._modules = tuple(ordered)
    return app
