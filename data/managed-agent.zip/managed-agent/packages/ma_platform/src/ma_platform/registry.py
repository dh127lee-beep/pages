"""WorkspaceAppRegistry — 테넌트 누수 방어선.

`plan/03-layers.md` §3 L6.

앱 그래프가 워크스페이스에 **핀**되어 있으므로, 요청 스코프 액터나 백그라운드 작업이
다른 워크스페이스의 캐시를 보는 일이 구조적으로 불가능하다.
"""

from __future__ import annotations

from collections.abc import Callable

from ma_platform.kernel import App


class WorkspaceAppRegistry:
    """`workspace_id → App` 하나."""

    def __init__(self, factory: Callable[[str], App]) -> None:
        self._factory = factory
        self._apps: dict[str, App] = {}

    async def get(self, workspace_id: str) -> App:
        app = self._apps.get(workspace_id)
        if app is None:
            app = self._factory(workspace_id)
            await app.start()
            self._apps[workspace_id] = app
        return app

    async def stop(self, workspace_id: str) -> None:
        app = self._apps.pop(workspace_id, None)
        if app is not None:
            await app.stop()

    async def stop_all(self) -> None:
        errors: list[Exception] = []
        for ws in list(self._apps):
            try:
                await self.stop(ws)
            except Exception as exc:
                errors.append(exc)
        if errors:
            raise ExceptionGroup("워크스페이스 앱 정리 중 오류", errors)

    def __len__(self) -> int:
        return len(self._apps)
