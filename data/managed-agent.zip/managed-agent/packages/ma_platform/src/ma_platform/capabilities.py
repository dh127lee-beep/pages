"""조립 루트가 밖에서 넣어 주는 기본 능력."""

from __future__ import annotations

from datetime import UTC, datetime

from ma_domain.clock import Clock, IdGenerator

from ma_platform.kernel import PortToken

workspace_context_port = PortToken[str]("ma.cap.workspace_context")
clock_port = PortToken[Clock]("ma.cap.clock")
id_generator_port = PortToken[IdGenerator]("ma.cap.id_generator")


class SystemClock:
    """유일하게 벽시계를 읽는 곳. 도메인·애플리케이션은 이것을 주입받는다."""

    def now(self) -> datetime:
        return datetime.now(UTC)


class UlidGenerator:
    """`<prefix>_<ULID>`. 시간 정렬이 되어 커서 페이지네이션과 맞는다."""

    _ALPHABET = "0123456789ABCDEFGHJKMNPQRSTVWXYZ"

    def __init__(self, clock: Clock) -> None:
        self._clock = clock

    def next(self, kind: str) -> str:
        import secrets

        from ma_domain.ids import PREFIXES

        prefix = PREFIXES.get(kind)
        if prefix is None:
            raise KeyError(f"모르는 리소스 종류: {kind}")
        ms = int(self._clock.now().timestamp() * 1000)
        body = self._encode(ms, 10) + "".join(secrets.choice(self._ALPHABET) for _ in range(16))
        return f"{prefix}_{body}"

    def _encode(self, value: int, length: int) -> str:
        out: list[str] = []
        for _ in range(length):
            out.append(self._ALPHABET[value % 32])
            value //= 32
        return "".join(reversed(out))
