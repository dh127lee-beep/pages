"""AWP · 조립 커널 — PortToken · AppModule · Registry"""
