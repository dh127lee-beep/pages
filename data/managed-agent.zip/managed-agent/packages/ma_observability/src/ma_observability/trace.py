"""Trace — **제어 평면 → 워커 → 모델 호출**이 하나로 이어진다.

`plan/08-infrastructure.md` §9 · `plan/06-harness-and-model.md` §6.

두 프로세스를 잇는 길이 하나뿐이다: **DB**. 제어 평면이 실행 행을
만들 때 trace 컨텍스트를 같이 넣고, 워커가 claim 할 때 꺼내 이어붙인다.
HTTP 헤더로 잇는 보통의 방법이 여기서는 안 된다 — 워커는 요청을 받지
않고 **큐를 긁어 간다.**

```
제어 평면                         워커
─────────                        ────
POST /sessions/{id}/events
  span: api.send_events
    └ inject(carrier) ──→ session_executions.trace_context
                                 │
                            claim 할 때 extract
                                 └ span: worker.turn   ← 같은 trace
                                     └ span: model.request
```

W3C `traceparent` 를 쓴다 — OTel 의 기본이고, 콜렉터가 그대로 읽는다.
"""

from __future__ import annotations

from contextlib import contextmanager
from typing import TYPE_CHECKING, Any

from opentelemetry import trace as _trace
from opentelemetry.propagate import extract, inject

if TYPE_CHECKING:
    from collections.abc import Iterator, Mapping

SCOPE = "awp"

#: DB 에 싣는 키. W3C 표준 이름 그대로 — 다른 도구가 읽을 수 있다.
TRACEPARENT = "traceparent"
TRACESTATE = "tracestate"


def tracer(name: str = SCOPE) -> Any:
    return _trace.get_tracer(name)


def carrier_for_db() -> dict[str, str]:
    """현재 span 을 **DB 에 실을 수 있는 모양**으로.

    빈 dict 를 돌려줄 수 있다 (span 이 없을 때). 그때 `restore` 는
    새 trace 를 시작한다 — 끊긴 것을 억지로 잇지 않는다.
    """
    carrier: dict[str, str] = {}
    inject(carrier)
    return carrier


@contextmanager
def restore(carrier: Mapping[str, str] | None, name: str, **attributes: Any) -> Iterator[Any]:
    """DB 에서 꺼낸 컨텍스트에 이어 span 을 연다.

    **`carrier` 가 비어도 돈다.** 그때는 새 trace 다 — 워커가 "앞이
    없다"고 멈추면 큐가 밀린다. 끊긴 trace 는 관측의 손실이지
    실행의 실패가 아니다.
    """
    parent = extract(dict(carrier)) if carrier else None
    with tracer().start_as_current_span(name, context=parent) as span:
        for key, value in attributes.items():
            span.set_attribute(key, value)
        yield span


@contextmanager
def span(name: str, **attributes: Any) -> Iterator[Any]:
    with tracer().start_as_current_span(name) as s:
        for key, value in attributes.items():
            s.set_attribute(key, value)
        yield s


def model_request(card_id: str, wire_model: str) -> Any:
    """모델 호출 span. `plan/06` §6 의 `model_request_start/end` 가 이것이다.

    **프롬프트를 속성에 넣지 않는다.** trace 는 샘플링돼 Tempo 로 가고,
    거기에는 레댁션이 없다 — 사내 문서가 통째로 들어갈 수 있다.
    """
    return span("model.request", **{"model.card": card_id, "model.wire": wire_model})


def in_memory() -> tuple[Any, Any]:
    """테스트용. `(provider, exporter)` — `exporter.get_finished_spans()`.

    **콜렉터를 띄우지 않는다** — `metrics.in_memory` 와 같은 이유다.
    """
    from opentelemetry.sdk.trace import TracerProvider
    from opentelemetry.sdk.trace.export import SimpleSpanProcessor
    from opentelemetry.sdk.trace.export.in_memory_span_exporter import (
        InMemorySpanExporter,
    )

    exporter = InMemorySpanExporter()
    provider = TracerProvider()
    provider.add_span_processor(SimpleSpanProcessor(exporter))
    return provider, exporter


__all__ = [
    "SCOPE",
    "TRACEPARENT",
    "TRACESTATE",
    "carrier_for_db",
    "in_memory",
    "model_request",
    "restore",
    "span",
    "tracer",
]
