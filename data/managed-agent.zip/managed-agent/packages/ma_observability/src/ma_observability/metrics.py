"""메트릭 — `plan/08-infrastructure.md` §9 · `plan/06` §6.

여덟 개를 정의한다. **이름과 라벨이 대시보드·알람의 계약이다** —
바꾸면 `deploy/grafana/*.json` 과 `deploy/prometheus/alerts.yaml` 이
같이 바뀌어야 하고, `tests/integration/test_metrics.py` 가 그 셋이
어긋나지 않는지 본다.

| 메트릭 | 종류 | 왜 |
|---|---|---|
| `model_cache_hit_ratio` | gauge | **비용의 지배 변수** (D12b). 1순위 알람 |
| `model_tokens` | counter | `kind` 가 hit · miss · output |
| `model_cost_cents` | counter | 부서별 지출 |
| `session_status` | gauge | 상태 분포 |
| `execution_queue_depth` | gauge | KEDA·워커 장애 |
| `lease_expired_total` | counter | 워커 크래시·DB 지연 |
| `sandbox_provision_duration` | histogram | 티어별 프로비저닝 지연 |
| `enforcement_level` | gauge | **보안 상태 변화** — 하향은 즉시 알람 |

작업 명세의 여덟 개에 **셋을 더했다.** 알람 7개 중 셋이 그것들을
필요로 하기 때문이다 — 없으면 그 알람은 **영원히 조용하고**, 조용한
알람은 "문제가 없다"와 구분되지 않는다.

| 메트릭 | 쓰는 알람 |
|---|---|
| `budget_spent_ratio` | 예산 소진 |
| `approval_age_ratio` | 승인 체류 |
| `runtime_orphans` | orphan 누적 |

대시보드 4개가 요구하는 일곱도 더했다. 같은 이유다 — 정의하지 않으면
**패널이 영원히 비어 있고**, 빈 패널은 "문제가 없다"처럼 보인다.

**OTLP 를 강요하지 않는다.** 내보내기는 조립이 정하고, 테스트는
인메모리 리더를 꽂는다 — 콜렉터를 띄우지 않고도 "무엇을 셌는가"를
볼 수 있어야 한다.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum
from typing import TYPE_CHECKING, Any

from ma_observability.cardinality import LabelBudget, check_labels

if TYPE_CHECKING:
    from collections.abc import Mapping

#: 계측 스코프 이름. 콜렉터가 이것으로 출처를 구분한다.
SCOPE = "awp"

#: 프로비저닝 지연 버킷 (초). **0.001 부터 시작한다** — 티어 W 의
#: 측정값이 0.003ms 라(`IMPL-0016`) 기본 버킷으로는 전부 첫 칸에 몰린다.
PROVISION_BUCKETS = (0.0005, 0.001, 0.005, 0.01, 0.05, 0.1, 0.5, 1.0, 5.0)


class TokenKind(StrEnum):
    HIT = "hit"
    MISS = "miss"
    OUTPUT = "output"


class EnforcementLevel(StrEnum):
    """숫자로 내보낸다 — **알람이 '하향'을 비교해야 하기 때문이다.**

    문자열 라벨만 있으면 "enforced 에서 advisory 로 바뀌었다"를
    PromQL 로 쓰기 어렵다. 숫자면 `< 2` 한 줄이다.
    """

    UNSUPPORTED = "unsupported"
    PARTIAL = "partial"
    ENFORCED = "enforced"

    @property
    def level(self) -> int:
        return {"unsupported": 0, "partial": 1, "enforced": 2}[self.value]


@dataclass
class Metrics:
    """여덟 개의 계측기. **조립이 하나 만들어 돌린다.**

    `meter` 를 주입받는 이유: 테스트가 인메모리 리더를 꽂고, 배포가
    OTLP 를 꽂는다. 여기서 exporter 를 고르면 테스트가 네트워크에
    묶인다.
    """

    meter: Any
    budget: LabelBudget = field(default_factory=LabelBudget)
    _instruments: dict[str, Any] = field(default_factory=dict, init=False)

    def __post_init__(self) -> None:
        m = self.meter
        self._instruments = {
            "model_cache_hit_ratio": m.create_gauge(
                "awp.model.cache_hit_ratio",
                description="캐시 히트 / (히트 + 미스). 비용의 지배 변수",
            ),
            "model_tokens": m.create_counter(
                "awp.model.tokens", unit="token", description="종류별 토큰 수"
            ),
            "model_cost_cents": m.create_counter(
                "awp.model.cost_cents", unit="cent", description="그 시점 요금 기준 비용"
            ),
            "session_status": m.create_gauge("awp.session.status", description="상태별 세션 수"),
            "execution_queue_depth": m.create_gauge(
                "awp.execution.queue_depth", description="queued 실행 수"
            ),
            "lease_expired_total": m.create_counter(
                "awp.execution.lease_expired", description="lease 만료로 재claim 된 수"
            ),
            "sandbox_provision_duration": m.create_histogram(
                "awp.sandbox.provision_duration",
                unit="s",
                description="티어별 프로비저닝 지연",
            ),
            "enforcement_level": m.create_gauge(
                "awp.sandbox.enforcement_level",
                description="0=unsupported 1=partial 2=enforced. 하향은 보안 사건",
            ),
            # ── 알람이 요구하는 셋 ──
            "budget_spent_ratio": m.create_gauge(
                "awp.budget.spent_ratio", description="선언 예산 대비 지출 (0~1+)"
            ),
            "approval_age_ratio": m.create_gauge(
                "awp.approval.age_ratio",
                description="대기 승인의 경과 / 만료. 0.8 에서 알람",
            ),
            "runtime_orphans": m.create_gauge(
                "awp.runtime.orphans", description="정리되지 않은 샌드박스 수"
            ),
            # ── 대시보드가 요구하는 일곱 ──
            "turn_total": m.create_counter("awp.turn", description="턴 수. 에러율의 분모"),
            "turn_duration": m.create_histogram(
                "awp.turn.duration", unit="s", description="턴 지연 p50/95/99"
            ),
            "session_errors_total": m.create_counter(
                "awp.session.errors", description="턴이 error 로 끝난 수"
            ),
            "session_stop_reason_total": m.create_counter(
                "awp.session.stop_reason", description="stop_reason 분포"
            ),
            "execution_claim_delay": m.create_histogram(
                "awp.execution.claim_delay",
                unit="s",
                description="queued → running 까지의 지연",
            ),
            "execution_settled_total": m.create_counter(
                "awp.execution.settled", description="settle 결과 분포"
            ),
            "sandbox_active": m.create_gauge(
                "awp.sandbox.active", description="티어별 활성 인스턴스"
            ),
        }

    def _labels(self, workspace_id: str, **extra: str) -> dict[str, str]:
        """**모든 라벨이 여기를 지난다.** 금지 라벨은 예외로 끊긴다."""
        labels = {"workspace": self.budget.workspace(workspace_id), **extra}
        return check_labels(labels)

    # ── 모델 ─────────────────────────────────────────────
    def record_usage(
        self,
        workspace_id: str,
        *,
        model_card: str,
        hit_tokens: int,
        miss_tokens: int,
        output_tokens: int,
        cost_cents: float,
        off_peak: bool,
    ) -> None:
        """턴 하나의 사용량. **적중률을 여기서 계산해 올린다.**

        Prometheus 에서 `rate(hit)/rate(hit+miss)` 로 유도할 수도 있지만,
        그러면 알람 식이 길어지고 **대시보드와 알람이 다른 식을 쓰게
        된다.** 하나의 숫자를 올리고 둘 다 그것을 본다.
        """
        base = self._labels(workspace_id, model_card=model_card)
        for kind, value in (
            (TokenKind.HIT, hit_tokens),
            (TokenKind.MISS, miss_tokens),
            (TokenKind.OUTPUT, output_tokens),
        ):
            if value:
                self._instruments["model_tokens"].add(value, {**base, "kind": kind.value})

        self._instruments["model_cost_cents"].add(
            cost_cents, {**base, "peak": "off" if off_peak else "on"}
        )

        cached = hit_tokens + miss_tokens
        if cached:
            self._instruments["model_cache_hit_ratio"].set(hit_tokens / cached, base)

    # ── 턴 ───────────────────────────────────────────────
    def turn_finished(
        self, workspace_id: str, *, stop_reason: str, seconds: float, errored: bool
    ) -> None:
        """턴 하나가 끝났다. **네 계측기를 한 번에 올린다.**

        따로 부르게 두면 호출자가 하나를 빠뜨리고, 그러면 에러율의
        분자와 분모가 어긋난다 — 그 비율은 조용히 틀린다.
        """
        base = self._labels(workspace_id)
        self._instruments["turn_total"].add(1, base)
        self._instruments["turn_duration"].record(seconds, base)
        self._instruments["session_stop_reason_total"].add(1, {**base, "stop_reason": stop_reason})
        if errored:
            self._instruments["session_errors_total"].add(1, base)

    def claimed(self, workspace_id: str, *, delay_seconds: float) -> None:
        self._instruments["execution_claim_delay"].record(delay_seconds, self._labels(workspace_id))

    def settled(self, workspace_id: str, *, state: str) -> None:
        self._instruments["execution_settled_total"].add(1, self._labels(workspace_id, state=state))

    def set_active_sandboxes(self, workspace_id: str, *, tier: str, count: int) -> None:
        self._instruments["sandbox_active"].set(count, self._labels(workspace_id, tier=tier))

    # ── 세션 · 실행 ──────────────────────────────────────
    def set_session_counts(self, workspace_id: str, counts: Mapping[str, int]) -> None:
        for status, n in counts.items():
            self._instruments["session_status"].set(n, self._labels(workspace_id, status=status))

    def set_queue_depth(self, workspace_id: str, depth: int) -> None:
        self._instruments["execution_queue_depth"].set(depth, self._labels(workspace_id))

    def lease_expired(self, workspace_id: str, n: int = 1) -> None:
        self._instruments["lease_expired_total"].add(n, self._labels(workspace_id))

    # ── 거버넌스 ─────────────────────────────────────────
    def set_budget_spent(self, workspace_id: str, *, scope: str, ratio: float) -> None:
        self._instruments["budget_spent_ratio"].set(ratio, self._labels(workspace_id, scope=scope))

    def set_oldest_approval_age(self, workspace_id: str, *, ratio: float) -> None:
        """**가장 오래된 것 하나만** 올린다.

        승인마다 시계열을 만들면 `approval_id` 가 라벨이 되고, 그것은
        열린 집합이다 (`cardinality.FORBIDDEN_LABELS`). 알람이 묻는
        것은 "놓친 것이 있는가"이고, 그 답은 최댓값이면 충분하다.
        """
        self._instruments["approval_age_ratio"].set(ratio, self._labels(workspace_id))

    def set_orphans(self, workspace_id: str, count: int) -> None:
        self._instruments["runtime_orphans"].set(count, self._labels(workspace_id))

    # ── 샌드박스 ─────────────────────────────────────────
    def provisioned(self, workspace_id: str, *, tier: str, seconds: float) -> None:
        self._instruments["sandbox_provision_duration"].record(
            seconds, self._labels(workspace_id, tier=tier)
        )

    def set_enforcement(
        self, workspace_id: str, *, tier: str, aspect: str, level: EnforcementLevel
    ) -> None:
        """**하향이 보안 사건이다.** 숫자로 올려 알람이 비교할 수 있게."""
        self._instruments["enforcement_level"].set(
            level.level, self._labels(workspace_id, tier=tier, aspect=aspect)
        )


def in_memory() -> tuple[Metrics, Any]:
    """테스트용. `(metrics, reader)` — `reader.get_metrics_data()` 로 본다.

    **콜렉터를 띄우지 않는다.** "무엇을 셌는가"를 보려고 네트워크를
    요구하면 그 테스트는 CI 에서 꺼진다.
    """
    from opentelemetry.sdk.metrics import MeterProvider
    from opentelemetry.sdk.metrics.export import InMemoryMetricReader

    reader = InMemoryMetricReader()
    provider = MeterProvider(metric_readers=[reader])
    return Metrics(meter=provider.get_meter(SCOPE)), reader


__all__ = [
    "PROVISION_BUCKETS",
    "SCOPE",
    "EnforcementLevel",
    "Metrics",
    "TokenKind",
    "in_memory",
]
