"""메트릭 라벨의 카디널리티 상한.

`plan/08-infrastructure.md` §9 · `task/M4-productization/T-0505-observability.md`.

> **메트릭은 라벨 조합마다 시계열 하나를 만든다.** `session_id` 를 라벨에
> 넣으면 세션 수만큼 시계열이 생기고, Prometheus 가 먼저 죽는다.

규칙은 둘이다.

1. **열린 집합은 라벨이 아니다.** `session_id`·`tool_call_id`·`event_id`
   는 trace 와 로그에 넣고 메트릭에는 넣지 않는다. 그것들은 "하나를
   찾는" 축이지 "세는" 축이 아니다.
2. **닫힌 집합도 상한을 둔다.** 워크스페이스는 부서 수라 유한하지만,
   실수로 테넌트를 늘리면 조용히 커진다. 상한을 넘으면 `other` 로
   접는다 — **메트릭이 사라지는 것보다 뭉개지는 편이 낫다.**
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field

_log = logging.getLogger("ma_observability.cardinality")

#: 라벨로 **절대 쓰지 않는** 이름. 열린 집합이다.
#:
#: 이 목록이 있는 이유: "이번 한 번만"이 쌓여서 터진다. 기계가 막는다.
FORBIDDEN_LABELS = frozenset(
    {
        "session_id",
        "execution_id",
        "event_id",
        "tool_call_id",
        "approval_id",
        "file_id",
        "memory_id",
        "user_id",
        "trace_id",
        "path",
        "url",
        "error_message",
    }
)

#: 워크스페이스 라벨의 상한. 넘으면 `other` 로 접는다.
#:
#: 200 인 이유: 사내 부서 수의 넉넉한 상한이고, 메트릭 8종 × 상태
#: 몇 개 × 200 이면 수천 시계열로 Prometheus 가 감당한다.
MAX_WORKSPACES = 200

#: 접힌 값.
OVERFLOW = "other"


class ForbiddenLabel(ValueError):
    """열린 집합을 라벨로 쓰려 했다."""


@dataclass
class LabelBudget:
    """워크스페이스 라벨의 카디널리티를 지킨다.

    **처음 본 순서대로 받는다.** LRU 가 아닌 이유: LRU 면 같은
    워크스페이스가 들어왔다 나갔다 하며 시계열이 계속 새로 생긴다 —
    카디널리티를 막으려다 더 늘리는 셈이다.
    """

    limit: int = MAX_WORKSPACES
    _seen: set[str] = field(default_factory=set)
    _warned: bool = False

    def workspace(self, workspace_id: str) -> str:
        if workspace_id in self._seen:
            return workspace_id
        if len(self._seen) >= self.limit:
            if not self._warned:
                _log.warning(
                    "워크스페이스 라벨이 %d개를 넘었다 — 나머지를 %r 로 접는다",
                    self.limit,
                    OVERFLOW,
                )
                self._warned = True
            return OVERFLOW
        self._seen.add(workspace_id)
        return workspace_id

    @property
    def tracked(self) -> int:
        return len(self._seen)


def check_labels(labels: dict[str, str]) -> dict[str, str]:
    """금지 라벨이 있으면 **예외**. 조용히 지우지 않는다.

    지우면 그 메트릭이 "왜 이 축이 없지"가 되고, 추가한 사람은 자기
    코드가 돈다고 믿는다.
    """
    bad = sorted(set(labels) & FORBIDDEN_LABELS)
    if bad:
        raise ForbiddenLabel(
            f"열린 집합을 메트릭 라벨로 쓸 수 없다: {', '.join(bad)} — trace 나 로그에 넣으십시오"
        )
    return labels


__all__ = [
    "FORBIDDEN_LABELS",
    "MAX_WORKSPACES",
    "OVERFLOW",
    "ForbiddenLabel",
    "LabelBudget",
    "check_labels",
]
