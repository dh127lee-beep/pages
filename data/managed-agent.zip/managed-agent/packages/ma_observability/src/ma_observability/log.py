"""구조화 로그 — **비밀이 로그로 새지 않는다.**

`plan/08-infrastructure.md` §9 · `plan/05-database.md` §7 · D5.

`structlog` 로 JSON 을 낸다. 그 자체는 평범하고, 여기서 중요한 것은
**레댁션 프로세서**다:

> 자격증명 평문이 로그에 한 번 들어가면 Loki 의 보존 기간 동안 거기
> 남는다. 그것을 지우는 절차는 없다 — 애초에 안 들어가야 한다.

`ma_governance.audit.redact` 와 **같은 판단**을 한다(키 이름으로
거른다). 두 벌인 이유는 레이어다: 감사 로그는 L4 이고 로그는 L6 라
서로 import 할 수 없다. 두 목록이 어긋나지 않는 것은
`tests/unit/test_log_redaction.py` 가 본다.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

import structlog

if TYPE_CHECKING:
    from collections.abc import MutableMapping

#: 이 조각이 **이름에 들어 있으면** 값을 가린다. 부분 일치다 —
#: `api_key`·`apiKey`·`x_api_key` 를 하나로 잡는다.
SECRET_HINTS = (
    "secret",
    "password",
    "passwd",
    "token",
    "api_key",
    "apikey",
    "authorization",
    "cookie",
    "credential",
    "private_key",
    "pepper",
    "nonce",
    "ciphertext",
)

REDACTED = "[레다크션됨]"


def _looks_secret(key: str) -> bool:
    lowered = key.lower().replace("-", "_")
    return any(hint in lowered for hint in SECRET_HINTS)


def redact(
    _logger: object, _name: str, event: MutableMapping[str, Any]
) -> MutableMapping[str, Any]:
    """키 이름으로 거른다. **값을 보지 않는다.**

    값으로 판단하면(엔트로피 등) 오탐이 생기고, 오탐은 **지워져선 안
    될 것을 지운다** — 디버깅에 필요한 id 가 사라지면 로그가 쓸모를
    잃는다. 키 이름은 우리가 정하는 것이라 믿을 수 있다.

    중첩 dict 도 훑는다 — `{"headers": {"authorization": "..."}}` 가
    가장 흔한 모양이다.
    """
    for key, value in list(event.items()):
        if _looks_secret(key):
            event[key] = REDACTED
        elif isinstance(value, dict):
            event[key] = {k: (REDACTED if _looks_secret(k) else v) for k, v in value.items()}
    return event


def add_trace_context(
    _logger: object, _name: str, event: MutableMapping[str, Any]
) -> MutableMapping[str, Any]:
    """현재 span 의 `trace_id` 를 싣는다. **로그와 trace 를 잇는다.**

    이것이 없으면 Grafana 에서 "이 trace 의 로그"를 못 찾고, 둘이 따로
    노는 관측이 된다.
    """
    from opentelemetry import trace

    span = trace.get_current_span()
    ctx = span.get_span_context()
    if ctx.is_valid:
        event["trace_id"] = format(ctx.trace_id, "032x")
        event["span_id"] = format(ctx.span_id, "016x")
    return event


def configure(*, level: str = "INFO", json_output: bool = True) -> None:
    """프로세스당 한 번. **조립이 부른다.**

    `json_output=False` 는 개발 머신용이다 — 색이 있는 사람용 출력.
    프로덕션에서 사람용 출력을 쓰면 Loki 가 파싱하지 못한다.
    """
    processors: list[Any] = [
        structlog.contextvars.merge_contextvars,
        structlog.processors.add_log_level,
        structlog.processors.TimeStamper(fmt="iso", utc=True),
        add_trace_context,
        # **레댁션은 렌더링 바로 앞이다.** 뒤에 프로세서가 더 있으면
        # 그것이 가린 값을 다시 펼칠 수 있다.
        redact,
    ]
    processors.append(
        structlog.processors.JSONRenderer() if json_output else structlog.dev.ConsoleRenderer()
    )

    structlog.configure(
        processors=processors,
        wrapper_class=structlog.make_filtering_bound_logger(
            logging.getLevelNamesMapping()[level.upper()]
        ),
        cache_logger_on_first_use=True,
    )


def bind(**values: Any) -> None:
    """이 컨텍스트의 모든 로그에 붙는다 (`session_id` 등).

    **메트릭 라벨과 다르다**: 로그는 카디널리티 걱정이 없으므로
    `session_id` 를 여기 넣는다 (`cardinality.FORBIDDEN_LABELS` 참고).
    """
    structlog.contextvars.bind_contextvars(**values)


def clear() -> None:
    structlog.contextvars.clear_contextvars()


def get(name: str) -> Any:
    return structlog.get_logger(name)


__all__ = [
    "REDACTED",
    "SECRET_HINTS",
    "add_trace_context",
    "bind",
    "clear",
    "configure",
    "get",
    "redact",
]
