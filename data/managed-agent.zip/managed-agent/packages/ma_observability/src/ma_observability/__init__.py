"""AWP · 구조화 로그 · OTel trace · 메트릭.

`plan/08-infrastructure.md` §9.

| 모듈 | 무엇 |
|---|---|
| `log` | structlog JSON + **레댁션** + trace_id 연결 |
| `trace` | span. 제어 평면 → 워커를 **DB 를 통해** 잇는다 |
| `metrics` | 여덟 개 계측기. 이름이 대시보드·알람의 계약이다 |
| `cardinality` | 라벨 상한. 열린 집합은 **예외로 끊는다** |

셋 다 **exporter 를 고르지 않는다.** 조립이 정하고, 테스트는 인메모리를
꽂는다 — 관측 테스트가 네트워크를 요구하면 CI 에서 꺼진다.
"""

from ma_observability.cardinality import ForbiddenLabel, LabelBudget
from ma_observability.metrics import EnforcementLevel, Metrics, TokenKind

__all__ = [
    "EnforcementLevel",
    "ForbiddenLabel",
    "LabelBudget",
    "Metrics",
    "TokenKind",
]
