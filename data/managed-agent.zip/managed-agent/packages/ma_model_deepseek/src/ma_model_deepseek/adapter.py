"""DeepSeek 공식 어댑터.

`plan/06-harness-and-model.md` §2 · `ADR-0005`.

DeepSeek 공식 엔드포인트는 **OpenAI 포맷**이다. SDK 도 base_url 만 바꿔 쓴다.
그래서 이 어댑터는 `OpenAICompatibleAdapter`를 거의 그대로 쓰고, DeepSeek 고유의
것만 더한다.

DeepSeek 고유:

- `reasoning_content` — 추론 블록. 정규화기가 `thinking_delta`로 바꾼다.
- `prompt_cache_hit_tokens` / `prompt_cache_miss_tokens` — 캐시 토큰을 **이미
  나눠서** 준다. OpenAI 는 합계만 주고 `prompt_tokens_details`에 세부를 둔다.
- peak/off-peak 요금. 요금은 카드의 `PricingSpec`이 들고 있으므로 어댑터는 모른다.

**모델 ID 는 이 파일에 없다.** `card.wire_model`이 전부다 — `deepseek-v4-pro`가
2026-09-14 부터 V4.1-Flash 로 라우팅된 것 같은 일이 또 일어나도, 고치는 것은
`model_cards` 행 하나다 (D12).
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from ma_domain.models import ModelCapabilities, ModelCard, ProviderKind
from ma_model_openai_compat.adapter import OpenAICompatibleAdapter

if TYPE_CHECKING:
    import httpx

#: 카드에 `base_url` 이 없을 때의 기본값. **모델 ID 가 아니라 엔드포인트다** —
#: 환경변수로 덮을 수 있고(`AWP_MODEL_BASE_URL`), 운영에서는 카드가 정한다.
DEFAULT_BASE_URL = "https://api.deepseek.com"


class DeepSeekOfficialAdapter(OpenAICompatibleAdapter):
    name = "deepseek_official"

    def __init__(
        self,
        client: httpx.AsyncClient,
        *,
        # `None` 이 **기본이자 운영 경로**다 — egress 프록시가 주입한다
        # (`plan/07` §6.3). 값을 주는 것은 개발 전용이고, 프로덕션에서는
        # 워커 설정이 그것을 거부한다 (`runtime_worker.config`).
        api_key: str | None = None,
        default_base_url: str = DEFAULT_BASE_URL,
    ) -> None:
        super().__init__(
            client,
            api_key=api_key,
            default_base_url=default_base_url,
            path="/v1/chat/completions",
        )

    def describe(self, card: ModelCard) -> ModelCapabilities:
        """DeepSeek 은 비전을 **같은 모델·같은 프롬프트 포맷**으로 지원한다.

        그래서 상위 어댑터가 일괄로 끄는 비전을 카드 선언대로 돌려놓는다
        (`plan/06` §2). 이것이 provider 별 어댑터를 따로 두는 이유다 —
        "카드가 희망, 어댑터가 사실"이라는 규칙은 같되 **사실이 다르다**.
        """
        caps = super().describe(card)
        caveats = tuple(c for c in caps.caveats if "비전" not in c)
        if card.provider is not ProviderKind.DEEPSEEK_OFFICIAL:
            caveats += (f"카드 provider 가 {card.provider.value} 인데 DeepSeek 어댑터로 호출된다",)
        return ModelCapabilities(
            max_input_tokens=caps.max_input_tokens,
            max_output_tokens=caps.max_output_tokens,
            supports_tools=caps.supports_tools,
            supports_vision=card.supports_vision,
            supports_prompt_cache=caps.supports_prompt_cache,
            reasoning=caps.reasoning,
            caveats=caveats,
        )


__all__ = ["DEFAULT_BASE_URL", "DeepSeekOfficialAdapter"]
