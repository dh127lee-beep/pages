"""AWP · DeepSeek 공식 어댑터"""
