"""SqlClient — 런타임 중립 SQL 포트.

`plan/03-layers.md` §3 L2c — **Agent를 전혀 모른다.** 방언 차이와 드라이버 에러
정규화만 담당한다. "Agent를 아는" SQL은 `ma_store_sql`에만 있다.

`batch()`가 **원자적**이라는 것이 중요하다 — CAS 2문장 배치가 이것에 의존한다
(`plan/03-layers.md` §6).
"""

from __future__ import annotations

from collections.abc import AsyncIterator, Sequence
from contextlib import AbstractAsyncContextManager
from dataclasses import dataclass
from typing import Any, Protocol


@dataclass(frozen=True, slots=True)
class Statement:
    """파라미터 바인딩만. 문자열 포매팅으로 SQL을 만들지 않는다."""

    sql: str
    args: tuple[Any, ...] = ()


@dataclass(frozen=True, slots=True)
class ExecResult:
    """영향 행 수. CAS가 `(1, 1)`인지 `(0, 0)`인지로 결과를 가른다."""

    rows_affected: int


type Row = dict[str, Any]


class SqlClient(Protocol):
    """드라이버 위의 얇은 포트."""

    async def fetch_all(self, stmt: Statement) -> list[Row]: ...

    async def fetch_one(self, stmt: Statement) -> Row | None: ...

    async def execute(self, stmt: Statement) -> ExecResult: ...

    async def batch(self, stmts: Sequence[Statement]) -> list[ExecResult]:
        """**하나의 트랜잭션**에서 전부 실행한다. 하나라도 실패하면 전부 롤백."""
        ...

    def transaction(self) -> AbstractAsyncContextManager[SqlClient]:
        """여러 문장을 하나의 트랜잭션으로 묶는다. 중첩은 savepoint."""
        ...

    def stream(self, stmt: Statement) -> AsyncIterator[Row]:
        """큰 결과를 메모리에 올리지 않고 흘린다.

        **`async def` 가 아니다.** 구현이 async generator 함수이므로 호출이
        코루틴이 아니라 `AsyncIterator` 를 바로 돌려준다. `async def` 로
        선언하면 어떤 구현도 이 Protocol 을 만족하지 못한다 (실제로
        `AsyncpgClient` 가 그랬고, `stream` 을 쓰는 코드가 없어서 조립 전까지
        드러나지 않았다).
        """
        ...
