"""asyncpg 어댑터.

`$1` 플레이스홀더를 쓴다 — 포트는 드라이버의 바인딩 문법을 그대로 노출한다.
방언을 하나만 지원하므로(PostgreSQL) 추상화를 더 얹지 않는다.
"""

from __future__ import annotations

from collections.abc import AsyncIterator, Sequence
from contextlib import asynccontextmanager
from typing import Any

import asyncpg

from ma_sql.errors import normalize
from ma_sql.ports import ExecResult, Row, Statement


def _rows_affected(tag: str) -> int:
    """`INSERT 0 3` · `UPDATE 2` → 정수."""
    parts = tag.split()
    return int(parts[-1]) if parts and parts[-1].isdigit() else 0


class AsyncpgClient:
    """풀 또는 단일 커넥션 위에서 동작한다."""

    def __init__(self, conn: asyncpg.Pool | asyncpg.Connection) -> None:
        self._conn = conn

    async def fetch_all(self, stmt: Statement) -> list[Row]:
        try:
            rows = await self._conn.fetch(stmt.sql, *stmt.args)
        except BaseException as exc:
            raise normalize(exc) or exc from exc
        return [dict(r) for r in rows]

    async def fetch_one(self, stmt: Statement) -> Row | None:
        try:
            row = await self._conn.fetchrow(stmt.sql, *stmt.args)
        except BaseException as exc:
            raise normalize(exc) or exc from exc
        return dict(row) if row is not None else None

    async def execute(self, stmt: Statement) -> ExecResult:
        try:
            tag = await self._conn.execute(stmt.sql, *stmt.args)
        except BaseException as exc:
            raise normalize(exc) or exc from exc
        return ExecResult(rows_affected=_rows_affected(tag))

    async def batch(self, stmts: Sequence[Statement]) -> list[ExecResult]:
        """**원자적.** CAS 2문장 배치가 이것에 의존한다."""
        async with self.transaction() as tx:
            return [await tx.execute(s) for s in stmts]

    @asynccontextmanager
    async def transaction(self) -> AsyncIterator[AsyncpgClient]:
        if isinstance(self._conn, asyncpg.Pool):
            async with self._conn.acquire() as conn, conn.transaction():
                yield AsyncpgClient(conn)
        else:
            async with self._conn.transaction():
                yield self

    async def stream(self, stmt: Statement) -> AsyncIterator[Row]:
        async with self.transaction() as tx:
            conn: Any = tx._conn
            async for row in conn.cursor(stmt.sql, *stmt.args):
                yield dict(row)


async def create_pool(dsn: str, *, min_size: int = 1, max_size: int = 10) -> asyncpg.Pool:
    """prepared statement 캐시를 끈다 — pgbouncer transaction 모드와 충돌한다."""
    pool = await asyncpg.create_pool(
        dsn, min_size=min_size, max_size=max_size, statement_cache_size=0
    )
    if pool is None:
        raise RuntimeError("커넥션 풀을 만들 수 없다")
    return pool
