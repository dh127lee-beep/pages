"""`SET LOCAL awp.workspace_id` — RLS 가 보는 값을 세운다.

`plan/05-database.md` §9 · `task/M3-security-governance/T-0406-security-suite-rls.md`.

> RLS 는 **추가** 안전장치다. 애플리케이션 필터를 빼도 되는 게 아니라,
> 빼먹었을 때 막아 주는 것이다.

**`SET LOCAL` 이지 `SET` 이 아니다.** `SET` 은 연결 수명 내내 남는데,
연결은 풀에서 재사용된다 — 한 워크스페이스의 값이 다음 요청으로 새어
**다른 부서의 데이터를 보게 된다.** `SET LOCAL` 은 트랜잭션이 끝나면
사라진다.

그래서 이 컨텍스트 매니저는 **트랜잭션 안에서만** 의미가 있다. 트랜잭션
밖에서 부르면 PostgreSQL 이 경고를 내고 값이 즉시 사라진다.
"""

from __future__ import annotations

from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import TYPE_CHECKING

from ma_sql.ports import Statement

if TYPE_CHECKING:
    from ma_sql.ports import SqlClient

#: 설정 키. 마이그레이션(`0008_rls`)의 정책과 **같아야 한다.**
SETTING = "awp.workspace_id"


class ScopeError(ValueError):
    """워크스페이스 id 가 설정에 쓸 수 없는 모양이다."""


def validate(workspace_id: str) -> str:
    """**`SET LOCAL` 은 파라미터 바인딩이 안 된다.**

    `set_config()` 함수를 쓰면 바인딩이 되지만, 그쪽은 `SET LOCAL` 과
    달리 세 번째 인자로 지역 여부를 넘겨야 하고 실수하기 쉽다. 여기서는
    **값을 검증해서** 문자열로 넣는다.

    워크스페이스 id 는 `wrkspc_` + ULID 이므로 영숫자와 밑줄뿐이다.
    그 밖의 문자가 오면 거부한다 — 인젝션 표면을 남기지 않는다.
    """
    if not workspace_id:
        raise ScopeError("워크스페이스 id 가 비었다")
    if len(workspace_id) > 64:
        raise ScopeError(f"워크스페이스 id 가 너무 길다: {len(workspace_id)}")
    if not all(c.isalnum() or c == "_" for c in workspace_id):
        raise ScopeError(f"워크스페이스 id 에 쓸 수 없는 문자가 있다: {workspace_id!r}")
    return workspace_id


@asynccontextmanager
async def scoped(sql: SqlClient, workspace_id: str) -> AsyncIterator[SqlClient]:
    """이 트랜잭션 동안 RLS 를 이 워크스페이스로 고정한다.

    ```python
    async with sql.transaction() as tx, scoped(tx, workspace_id) as scoped_tx:
        await scoped_tx.fetch_all(...)   # 다른 워크스페이스 행이 안 보인다
    ```

    **애플리케이션 필터를 빼지 않는다.** 둘 다 유지하는 것이 설계다 —
    RLS 는 버그를 받치는 그물이지 1차 경계가 아니다.
    """
    checked = validate(workspace_id)
    await sql.execute(Statement(f"SET LOCAL {SETTING} = '{checked}'"))
    yield sql


async def current_scope(sql: SqlClient) -> str | None:
    """지금 설정된 값. 디버깅과 테스트가 쓴다."""
    row = await sql.fetch_one(Statement(f"SELECT current_setting('{SETTING}', true) AS ws"))
    value = row["ws"] if row else None
    return value or None


__all__ = ["SETTING", "ScopeError", "current_scope", "scoped", "validate"]
