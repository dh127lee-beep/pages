"""AWP · Engine/Connection Port + 방언 어댑터."""

from ma_sql.errors import (
    CheckViolation,
    ConnectionLost,
    ForeignKeyViolation,
    SerializationFailure,
    SqlError,
    UniqueViolation,
)
from ma_sql.ports import ExecResult, Row, SqlClient, Statement

__all__ = [
    "CheckViolation",
    "ConnectionLost",
    "ExecResult",
    "ForeignKeyViolation",
    "Row",
    "SerializationFailure",
    "SqlClient",
    "SqlError",
    "Statement",
    "UniqueViolation",
]
