"""드라이버 에러를 도메인 중립 에러로 정규화한다.

호출자가 `asyncpg.UniqueViolationError`를 알면 드라이버가 바뀔 때 전부 고쳐야 한다.
"""

from __future__ import annotations


class SqlError(Exception):
    """모든 SQL 에러의 바닥."""


class UniqueViolation(SqlError):
    """유니크 제약 위반. 멱등 경로에서는 정상적인 결과일 수 있다."""

    def __init__(self, constraint: str | None = None) -> None:
        super().__init__(f"unique violation: {constraint or '?'}")
        self.constraint = constraint


class ForeignKeyViolation(SqlError):
    def __init__(self, constraint: str | None = None) -> None:
        super().__init__(f"foreign key violation: {constraint or '?'}")
        self.constraint = constraint


class CheckViolation(SqlError):
    def __init__(self, constraint: str | None = None) -> None:
        super().__init__(f"check violation: {constraint or '?'}")
        self.constraint = constraint


class SerializationFailure(SqlError):
    """직렬화 실패. 재시도 가능하다."""


class ConnectionLost(SqlError):
    """연결이 끊겼다. 재시도 가능하다."""


#: PostgreSQL SQLSTATE → 우리 예외.
SQLSTATE: dict[str, type[SqlError]] = {
    "23505": UniqueViolation,
    "23503": ForeignKeyViolation,
    "23514": CheckViolation,
    "40001": SerializationFailure,
    "40P01": SerializationFailure,  # deadlock
    "08000": ConnectionLost,
    "08003": ConnectionLost,
    "08006": ConnectionLost,
    "57P01": ConnectionLost,  # admin shutdown — failover 중
}


def normalize(exc: BaseException) -> SqlError | None:
    """asyncpg 예외를 우리 예외로. 모르는 것은 None(그대로 올린다)."""
    code = getattr(exc, "sqlstate", None)
    if code is None:
        return None
    cls = SQLSTATE.get(code)
    if cls is None:
        return None
    constraint = getattr(exc, "constraint_name", None)
    if cls in (UniqueViolation, ForeignKeyViolation, CheckViolation):
        return cls(constraint)
    return cls(str(exc))
