"""세션 → 자격증명 조회 — **프록시의 ③ 단계** (`plan/07` §6.1).

```
③ 제어 평면에 조회: (workspace, session, host) → credential
    · 세션의 vault_ids 범위 안에 있는 것만
    · fence generation 검증 — 소유권이 넘어간 세션은 거부
```

**fence 검증이 마지막 방어선이다.** 워커가 죽고 다른 워커가 그 세션을
가져갔는데 옛 샌드박스가 아직 살아 있으면, 그 샌드박스는 여전히 프록시에
붙을 수 있다. generation 이 맞지 않으면 자격증명을 주지 않는다 — 그러면
좀비 샌드박스가 할 수 있는 일이 "아무 데도 못 나감"이 된다.

> **캐시하지 않는다.** 캐시하면 fence 검증이 캐시 TTL 만큼 느슨해진다 —
> 그 창 동안 소유권이 넘어간 세션이 자격증명을 받는다. 조회는 DB 왕복
> 하나이고, egress 는 어차피 네트워크 왕복을 포함하므로 상대 비용이 작다
> (`IMPL-0021`).
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
from typing import TYPE_CHECKING, Protocol

if TYPE_CHECKING:
    from ma_domain.environments import NetworkPolicy
    from ma_domain.ids import SessionId, ThreadId, VaultId, WorkspaceId
    from ma_store.credentials import CredentialStore, InjectionSecret
    from ma_store.environments import EnvironmentStore
    from ma_store.executions import ExecutionStore
    from ma_store.sessions import SessionStore


class LookupFailure(StrEnum):
    UNKNOWN_SESSION = "unknown_session"
    #: 소유권이 넘어갔다. **좀비 샌드박스다.**
    FENCE_STALE = "fence_stale"
    #: 세션이 끝났다.
    SESSION_CLOSED = "session_closed"


@dataclass(frozen=True, slots=True)
class SessionContext:
    """프록시가 요청 하나를 판단하는 데 필요한 전부.

    **자격증명이 여기 없다.** 이것은 "무엇을 허용하는가"이고, 실제 비밀은
    `reveal_for_injection` 이 호출마다 따로 꺼낸다.
    """

    workspace_id: WorkspaceId
    session_id: SessionId
    generation: int
    networking: NetworkPolicy
    allowed_vault_ids: tuple[VaultId, ...] = ()


@dataclass(frozen=True, slots=True)
class ContextDenied:
    reason: LookupFailure
    detail: str = ""


type ContextResult = SessionContext | ContextDenied


class SessionContextSource(Protocol):
    """프록시가 제어 평면에 묻는 창구.

    Protocol 인 이유: 프록시가 **같은 프로세스에서 DB 를 읽을 수도**
    있고(단일 노드 배포) **HTTP 로 제어 평면에 물을 수도** 있다. 보안
    성질은 둘 다 같고, 바뀌는 것은 지연뿐이다.
    """

    async def context_for(
        self, session_token: str, *, claimed_generation: int | None = None
    ) -> ContextResult: ...


class SecretSource(Protocol):
    """`(workspace, session, host)` → 평문. **프록시 메모리에만 머문다.**"""

    async def secret_for(self, ctx: SessionContext, host: str) -> InjectionSecret | None: ...


@dataclass(frozen=True, slots=True)
class SessionTicket:
    """프록시가 세션 토큰에서 알아내는 것. **권한이 아니다.**

    여기에 `generation` 이 있지만 그것은 **샌드박스가 주장하는 값**이다.
    권한은 DB 의 `current_generation` 에 있고 (D3), 둘을 대조하는 것이
    fence 검증이다.
    """

    workspace_id: WorkspaceId
    session_id: SessionId
    lane_id: ThreadId
    claimed_generation: int | None = None


class TicketResolver(Protocol):
    """세션 토큰 → `SessionTicket`. 발급은 프록시 조립이 한다."""

    def resolve(self, session_token: str) -> SessionTicket | None: ...


@dataclass
class StoreBackedContextSource:
    """세션·환경·실행 권한을 직접 읽는 구현.

    **`executions.current_generation` 이 권한의 원천이다** (D3) — 세션
    레코드의 어떤 필드도 아니다. 그래서 그것을 본다.

    네트워크 정책은 **환경**에 있지 세션에 없다. 세션은 `environment_id`
    를 들고 있고, 환경 레코드가 `networking` 을 들고 있다 — 그래서 조회가
    세 번이다. 줄이고 싶어지지만, 줄이려면 세션 생성 시점에 정책을
    복사해야 하고 그러면 **환경을 좁혀도 기존 세션이 넓은 채로 남는다.**
    """

    sessions: SessionStore
    environments: EnvironmentStore
    executions: ExecutionStore
    tickets: TicketResolver

    async def context_for(
        self, session_token: str, *, claimed_generation: int | None = None
    ) -> ContextResult:
        ticket = self.tickets.resolve(session_token)
        if ticket is None:
            return ContextDenied(LookupFailure.UNKNOWN_SESSION, "모르는 세션 토큰")

        from ma_domain.executions import ExecutionScope
        from ma_store.environments import FindCurrentEnvironment
        from ma_store.sessions import FindSession

        session = await self.sessions.find(
            FindSession(workspace_id=ticket.workspace_id, id=ticket.session_id)
        )
        if session is None:
            return ContextDenied(LookupFailure.UNKNOWN_SESSION, "세션이 없다")

        scope = ExecutionScope(
            workspace_id=ticket.workspace_id,
            session_id=ticket.session_id,
            lane_id=ticket.lane_id,
        )
        current = await self.executions.current_generation(scope)
        if current is None:
            # 실행 중이 아니면 나갈 이유가 없다. 샌드박스가 아직 살아
            # 있더라도 그것은 **정리되지 않은 것**이지 권한이 아니다.
            return ContextDenied(LookupFailure.SESSION_CLOSED, "실행 중인 execution 이 없다")

        asserted = (
            claimed_generation if claimed_generation is not None else ticket.claimed_generation
        )
        if asserted is not None and asserted != current:
            # **좀비 샌드박스.** 옛 워커의 샌드박스가 아직 살아 있다.
            return ContextDenied(LookupFailure.FENCE_STALE, f"generation {asserted} ≠ {current}")

        env = await self.environments.find_current(
            FindCurrentEnvironment(workspace_id=ticket.workspace_id, id=session.environment_id)
        )
        if env is None:
            # **환경을 못 읽으면 정책이 없는 것이다.** `allowlist.decide` 가
            # `None` 을 거부로 다룬다.
            return ContextDenied(LookupFailure.UNKNOWN_SESSION, "환경을 찾을 수 없다")

        return SessionContext(
            workspace_id=ticket.workspace_id,
            session_id=ticket.session_id,
            generation=current,
            networking=env.config.networking,
            allowed_vault_ids=tuple(session.vault_ids),
        )


@dataclass
class StoreBackedSecretSource:
    """`reveal_for_injection` 한 번. **캐시하지 않는다.**

    캐시하면 fence 검증이 TTL 만큼 느슨해진다 — 그 창 동안 소유권이
    넘어간 세션이 자격증명을 받는다 (`IMPL-0021`).
    """

    credentials: CredentialStore

    async def secret_for(self, ctx: SessionContext, host: str) -> InjectionSecret | None:
        from ma_store.credentials import RevealForInjection

        return await self.credentials.reveal_for_injection(
            RevealForInjection(
                workspace_id=ctx.workspace_id,
                session_id=ctx.session_id,
                host=host,
                allowed_vault_ids=ctx.allowed_vault_ids,
                generation=ctx.generation,
            )
        )


__all__ = [
    "ContextDenied",
    "ContextResult",
    "LookupFailure",
    "SecretSource",
    "SessionContext",
    "SessionContextSource",
    "SessionTicket",
    "StoreBackedContextSource",
    "StoreBackedSecretSource",
    "TicketResolver",
]
