"""프록시 판단 파이프라인 — **①~⑥ 을 한 함수로** (`plan/07` §6.1).

```
① 세션 식별        → ContextDenied 면 403
② allowed_hosts    → Denied 면 403 + credential_events(denied)
③ 자격증명 조회     → 없으면 주입 없이 통과 (금지가 아니다)
④ 헤더 주입
⑤ 업스트림 포워드   ← 여기서는 하지 않는다. 호출자(앱)의 일이다
⑥ credential_events(injected)
```

**네트워크를 모른다.** 소켓도 TLS 도 여기 없다 — 그래서 이 판단 전체를
DB 와 가짜 소스만으로 테스트할 수 있고, `tests/security/test_egress_bypass.py`
가 그렇게 한다.

> **프록시가 죽으면 세션이 막히는 것이 올바른 동작이다.** 가용성보다
> 기밀성이 우선이다 (T-0402 구현 지침). 그래서 이 파이프라인의 모든
> 실패 경로가 `Refuse` 다 — "모르겠으니 통과"가 없다.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from ma_egress.allowlist import ALLOWED_PORTS, Allowed, Denial, Denied, decide
from ma_egress.inject import InjectionUnsupported, apply, strip_inbound_auth
from ma_egress.lookup import ContextDenied, SessionContext

if TYPE_CHECKING:
    from collections.abc import Mapping

    from ma_egress.audit import CredentialAudit
    from ma_egress.inject import Injection
    from ma_egress.lookup import SecretSource, SessionContextSource


@dataclass(frozen=True, slots=True)
class Forward:
    """업스트림으로 보내라. **헤더는 이미 주입돼 있다.**"""

    host: str
    port: int
    headers: Mapping[str, str]
    #: 주입된 자격증명. 없으면 `None` — 금지가 아니라 "줄 것이 없었다".
    injection: Injection | None = None

    @property
    def injected(self) -> bool:
        return self.injection is not None


@dataclass(frozen=True, slots=True)
class Refuse:
    """막아라. **403 이고 본문에 이유를 자세히 적지 않는다.**

    자세한 이유를 샌드박스에 주면 모델이 그것으로 목록을 더듬는다.
    `reason` 은 감사로 가고, 샌드박스는 코드만 본다.
    """

    reason: Denial | str
    detail: str = ""
    status: int = 403


type EgressDecision = Forward | Refuse


@dataclass
class EgressPipeline:
    contexts: SessionContextSource
    secrets: SecretSource
    audit: CredentialAudit
    #: 나갈 수 있는 포트. **배포 설정이다** — 코드에 박아 두면 9443 을
    #: 쓰는 시스템 하나 때문에 릴리스를 해야 하고, 그때 누군가 전부
    #: 허용으로 바꾼다.
    allowed_ports: frozenset[int] = ALLOWED_PORTS

    async def _authorize(
        self, session_token: str, target: str, claimed_generation: int | None
    ) -> tuple[SessionContext, Allowed] | Refuse:
        """①② — 세션 식별 + allowed_hosts. **자격증명은 보지 않는다.**"""
        ctx = await self.contexts.context_for(session_token, claimed_generation=claimed_generation)
        if isinstance(ctx, ContextDenied):
            # **세션을 모르면 감사에 남길 워크스페이스도 모른다.**
            # 그래도 막는 것이 먼저다 — 감사 공백은 프록시 로그가 덮는다.
            return Refuse(reason=ctx.reason.value, detail=ctx.detail)

        verdict = decide(target, ctx.networking, allowed_ports=self.allowed_ports)
        if isinstance(verdict, Denied):
            await self.audit.denied(
                workspace_id=ctx.workspace_id,
                session_id=ctx.session_id,
                host=target,
                generation=ctx.generation,
            )
            return Refuse(reason=verdict.reason, detail=verdict.detail)
        return ctx, verdict

    async def authorize(
        self, *, session_token: str, target: str, claimed_generation: int | None = None
    ) -> Allowed | Refuse:
        """**`CONNECT` 단계가 쓴다.** 터널을 뚫어도 되는가만 본다.

        안쪽 요청을 아직 모르므로 자격증명을 조회할 이유가 없다 —
        조회하면 `credential_events` 에 주입 기록이 **두 번** 남고,
        그 숫자를 세는 감사 집계가 전부 두 배가 된다.
        """
        got = await self._authorize(session_token, target, claimed_generation)
        return got if isinstance(got, Refuse) else got[1]

    async def decide(
        self,
        *,
        session_token: str,
        target: str,
        headers: Mapping[str, str],
        claimed_generation: int | None = None,
    ) -> EgressDecision:
        """**터널 안의 요청 하나마다.** ①~④⑥."""
        got = await self._authorize(session_token, target, claimed_generation)
        if isinstance(got, Refuse):
            return got
        ctx, verdict = got
        host = verdict.target.host

        secret = await self.secrets.secret_for(ctx, host)
        if secret is None:
            # **자격증명이 없는 것은 금지가 아니다.** 공개 API 를 부르는
            # 경우가 있고, 그때 막으면 allowlist 가 두 번 일한다.
            #
            # 다만 **인바운드 인증 헤더는 지운다** — 남기면 프록시가
            # "아무거나 전달하는 통로"가 된다.
            return Forward(host=host, port=verdict.target.port, headers=strip_inbound_auth(headers))

        try:
            injection = apply(headers, secret)
        except InjectionUnsupported as exc:
            # 주입할 수 없는 종류를 **조용히 통과시키지 않는다.**
            await self.audit.denied(
                workspace_id=ctx.workspace_id,
                session_id=ctx.session_id,
                host=host,
                generation=ctx.generation,
                credential_id=secret.credential_id,
            )
            return Refuse(reason="injection_unsupported", detail=str(exc))

        await self.audit.injected(
            workspace_id=ctx.workspace_id,
            session_id=ctx.session_id,
            credential_id=secret.credential_id,
            host=host,
            generation=ctx.generation,
        )
        return Forward(
            host=host,
            port=verdict.target.port,
            headers=injection.headers,
            injection=injection,
        )


__all__ = ["EgressDecision", "EgressPipeline", "Forward", "Refuse"]
