"""자격증명 헤더 주입 — **프록시의 ④ 단계** (`plan/07` §6.1).

```
④ 복호화 후 Authorization 헤더 주입 (프록시 메모리에만, 로그 금지)
```

**이 모듈이 평문을 만지는 유일한 곳이다.** 그래서 규칙이 셋이다.

1. **평문을 로그에 쓰지 않는다.** 로깅 호출이 이 파일에 없다.
2. **`repr` 에 싣지 않는다.** 예외 추적이 지역 변수를 출력하면 거기 실린다.
3. **기존 헤더를 덮어쓴다.** 샌드박스가 자기 `Authorization` 을 보내도
   우리 것으로 바뀐다 — 안 그러면 모델이 아무 값이나 넣어 업스트림에
   보낼 수 있다.
"""

from __future__ import annotations

import base64
from dataclasses import dataclass
from typing import TYPE_CHECKING

from ma_domain.vaults import CredentialKind

if TYPE_CHECKING:
    from collections.abc import Mapping

    from ma_store.credentials import InjectionSecret

#: 주입이 덮어쓰는 헤더. **대소문자를 무시하고 전부 지운다** — HTTP 헤더는
#: 대소문자를 구분하지 않으므로 `authorization` 과 `Authorization` 이
#: 둘 다 있으면 업스트림이 어느 것을 볼지 모른다.
OVERWRITTEN = ("authorization", "proxy-authorization")


class InjectionUnsupported(Exception):
    """이 종류는 헤더로 주입할 수 없다. **조용히 통과시키지 않는다.**"""


@dataclass(frozen=True, slots=True)
class Injection:
    """주입 결과. **`__repr__` 을 막아 둔다.**"""

    headers: Mapping[str, str]
    credential_id: str

    def __repr__(self) -> str:
        # 기본 `repr` 은 헤더 값을 그대로 출력한다. 예외 추적이 지역
        # 변수를 찍으면 거기에 토큰이 실린다.
        return f"Injection(credential_id={self.credential_id!r}, headers=<가림>)"


def header_for(secret: InjectionSecret) -> tuple[str, str]:
    """종류 → `(헤더 이름, 값)`.

    `environment_variable` 은 헤더가 아니다 — 샌드박스 환경에 넣는
    것이고, 그것은 **D5 위반**이다. T-0402 범위에서 `wasm`/`process`
    티어 모두 환경변수 자격증명을 주입하지 않는다. 예외로 알린다.
    """
    name, value = _header_value(secret)
    # **HTTP 헤더 값은 latin-1 이어야 한다** (RFC 9110 §5.5).
    #
    # 누군가 한글이 섞인 비밀을 저장하면 직렬화에서 `UnicodeEncodeError`
    # 가 나고 **연결이 통째로 죽는다.** 여기서 잡아 거부로 바꾼다 —
    # 거부는 감사에 남고, 예외는 스택 추적에 비밀을 싣는다.
    try:
        value.encode("latin-1")
        name.encode("ascii")
    except UnicodeEncodeError as exc:
        raise InjectionUnsupported(
            "자격증명을 HTTP 헤더에 실을 수 없다 — ASCII 가 아닌 문자가 있다"
        ) from exc
    # **제어 문자가 있으면 헤더 주입이다.** 개행 하나로 헤더를 하나 더
    # 만들 수 있다 (업스트림이 보기에는 우리가 보낸 것이다).
    if any(ch in value for ch in "\r\n\x00") or any(ch in name for ch in "\r\n\x00: "):
        raise InjectionUnsupported("자격증명에 제어 문자가 있다")
    return name, value


def _header_value(secret: InjectionSecret) -> tuple[str, str]:
    match secret.kind:
        case CredentialKind.BEARER:
            return "Authorization", f"Bearer {secret.secret}"
        case CredentialKind.BASIC:
            # 이미 `user:pass` 모양이라고 본다 — 분해는 저장 쪽 관심사다.
            encoded = base64.b64encode(secret.secret.encode("utf-8")).decode("ascii")
            return "Authorization", f"Basic {encoded}"
        case CredentialKind.API_KEY_HEADER:
            if not secret.header_name:
                raise InjectionUnsupported("api_key_header 인데 header_name 이 없다")
            return secret.header_name, secret.secret
        case CredentialKind.MCP_OAUTH:
            return "Authorization", f"Bearer {secret.secret}"
        case CredentialKind.ENVIRONMENT_VARIABLE:
            raise InjectionUnsupported(
                "environment_variable 은 프록시가 주입하지 않는다 — "
                "샌드박스 환경에 넣는 것은 D5 위반이다"
            )
    raise InjectionUnsupported(f"모르는 종류: {secret.kind}")  # pragma: no cover


def apply(headers: Mapping[str, str], secret: InjectionSecret) -> Injection:
    """업스트림에 보낼 헤더를 만든다. **원본을 바꾸지 않는다.**

    기존 인증 헤더는 **전부 지우고** 우리 것을 넣는다. 샌드박스가 보낸
    `Authorization` 을 남겨 두면, 모델이 아무 값이나 넣어 업스트림에
    보낼 수 있다 (업스트림 입장에서는 우리가 보낸 것이다).
    """
    name, value = header_for(secret)
    cleaned = {k: v for k, v in headers.items() if k.lower() not in OVERWRITTEN}
    cleaned[name] = value
    return Injection(headers=cleaned, credential_id=secret.credential_id)


def strip_inbound_auth(headers: Mapping[str, str]) -> dict[str, str]:
    """자격증명이 **없을 때**도 인바운드 인증 헤더를 지운다.

    주입할 것이 없다고 샌드박스가 보낸 헤더를 그대로 흘려보내면,
    프록시가 "아무거나 전달하는 통로"가 된다. 주입 여부와 무관하게
    **들어온 인증 헤더는 나가지 않는다.**
    """
    return {k: v for k, v in headers.items() if k.lower() not in OVERWRITTEN}


def redact(headers: Mapping[str, str]) -> dict[str, str]:
    """로그용. **인증 헤더 값을 가린다.**

    프록시 로그가 요청 헤더를 찍는 일은 흔하고, 그 한 번이 주입한 토큰을
    디스크에 남긴다.
    """
    return {
        k: ("<가림>" if k.lower() in OVERWRITTEN or "key" in k.lower() else v)
        for k, v in headers.items()
    }


__all__ = [
    "OVERWRITTEN",
    "Injection",
    "InjectionUnsupported",
    "apply",
    "header_for",
    "redact",
    "strip_inbound_auth",
]
