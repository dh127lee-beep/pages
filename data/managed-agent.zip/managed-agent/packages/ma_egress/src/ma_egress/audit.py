"""`credential_events` 적립 — **프록시의 ⑥ 단계** (`plan/07` §6.1).

"언제 누구에게 쓰였는가"다. **평문은 없다.**

> 세션별로 집계하면 "이 세션이 어떤 시스템에 몇 번 접근했는가"가 나온다.
> 그것이 T-0404 의 감사 요구를 직접 만족시킨다 (`plan/05` §3 G6).

**적립 실패가 요청을 막지 않는다.** 막으면 DB 가 느릴 때 egress 전체가
멈춘다. 대신 **경고로 남긴다** — 감사 공백은 조용히 지나가면 안 된다.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING

from ma_domain.ids import CredentialId
from ma_domain.vaults import CredentialAction

if TYPE_CHECKING:
    from ma_domain.clock import Clock
    from ma_domain.ids import SessionId, WorkspaceId
    from ma_store.credentials import CredentialStore

_log = logging.getLogger("ma_egress.audit")

#: 거부를 적립할 때 쓰는 가짜 자격증명 id.
#:
#: `credential_events.credential_id` 가 NOT NULL 인데, "어떤 자격증명도
#: 쓰이지 않았다"를 적어야 한다. NULL 을 허용하면 "주입됐는데 id 를
#: 빠뜨린 행"과 구분이 안 된다.
NO_CREDENTIAL = "cred_none"


@dataclass
class CredentialAudit:
    credentials: CredentialStore
    clock: Clock

    async def injected(
        self,
        *,
        workspace_id: WorkspaceId,
        session_id: SessionId,
        credential_id: CredentialId,
        host: str,
        generation: int,
    ) -> None:
        await self._record(
            workspace_id=workspace_id,
            session_id=session_id,
            credential_id=credential_id,
            action=CredentialAction.INJECTED,
            host=host,
            generation=generation,
        )

    async def denied(
        self,
        *,
        workspace_id: WorkspaceId,
        session_id: SessionId,
        host: str,
        generation: int | None = None,
        credential_id: CredentialId | None = None,
    ) -> None:
        """**막은 것도 남긴다.** 막힌 요청이 공격의 유일한 흔적일 수 있다."""
        await self._record(
            workspace_id=workspace_id,
            session_id=session_id,
            credential_id=credential_id or CredentialId(NO_CREDENTIAL),
            action=CredentialAction.DENIED,
            host=host,
            generation=generation,
        )

    async def _record(
        self,
        *,
        workspace_id: WorkspaceId,
        session_id: SessionId,
        credential_id: CredentialId,
        action: CredentialAction,
        host: str,
        generation: int | None,
    ) -> None:
        from ma_store.credentials import RecordCredentialEvent

        try:
            await self.credentials.record_event(
                RecordCredentialEvent(
                    workspace_id=workspace_id,
                    credential_id=credential_id,
                    action=action,
                    now=self.clock.now(),
                    session_id=session_id,
                    host=host,
                    generation=generation,
                )
            )
        except Exception as exc:
            # 감사 실패가 egress 를 막지 않는다 — 막으면 DB 가 느릴 때
            # egress 전체가 멈춘다. 대신 **경고로 남긴다**: 감사 공백은
            # 조용히 지나가면 안 된다.
            #
            # **호스트는 남기고 자격증명 내용은 남기지 않는다.**
            _log.warning(
                "credential_events 적립 실패 action=%s host=%s: %s",
                action.value,
                host,
                type(exc).__name__,
            )


__all__ = ["NO_CREDENTIAL", "CredentialAudit"]
