"""AWP · egress 프록시 라이브러리 — allowlist · 조회 · 주입 · 감사.

`plan/07-sandbox.md` §6 · `task/M3-security-governance/T-0402-egress-proxy.md`.

프록시의 **판단**이 여기 있고, TLS·소켓 같은 **기계**는 `apps/egress_proxy`
에 있다. 나눈 이유: 판단은 네트워크 없이 테스트할 수 있어야 한다.
"""

from ma_egress.allowlist import Allowed, Denial, Denied, Target, decide, parse_target
from ma_egress.audit import CredentialAudit
from ma_egress.inject import Injection, InjectionUnsupported, apply, redact
from ma_egress.lookup import (
    ContextDenied,
    LookupFailure,
    SessionContext,
    SessionTicket,
    StoreBackedContextSource,
    StoreBackedSecretSource,
)
from ma_egress.pipeline import EgressDecision, EgressPipeline, Forward, Refuse

__all__ = [
    "Allowed",
    "ContextDenied",
    "CredentialAudit",
    "Denial",
    "Denied",
    "EgressDecision",
    "EgressPipeline",
    "Forward",
    "Injection",
    "InjectionUnsupported",
    "LookupFailure",
    "Refuse",
    "SessionContext",
    "SessionTicket",
    "StoreBackedContextSource",
    "StoreBackedSecretSource",
    "Target",
    "apply",
    "decide",
    "parse_target",
    "redact",
]
