"""환경의 `allowed_hosts` 검사 — **프록시의 ② 단계** (`plan/07` §6.1).

규칙은 `ma_domain.hosts` 에 있다. 웹 툴(`ma_harness.tools._hosts`)과 같은
것을 쓴다 — 두 곳이 어긋나면 **프록시가 막는 것과 툴이 막는 것이 달라지고,
그 차이가 우회 경로가 된다.**

여기서 더하는 것은 **프록시 맥락**이다: CONNECT 의 호스트:포트 파싱,
기본 거부(fail-closed), 그리고 왜 막혔는지를 감사에 남길 사유.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum

from ma_domain.environments import NetworkKind, NetworkPolicy
from ma_domain.hosts import matches_exact_host, normalize_host

#: 프록시가 받아 주는 포트의 **기본값**. 443 만이 아니다 — 사내 시스템이
#: 8443 을 쓰는 일이 흔하다. 다만 아무 포트나 열지는 않는다.
#:
#: 배포마다 다를 수 있으므로 `decide(..., allowed_ports=...)` 로 바꿀 수
#: 있다. 코드에 박아 두면 9443 을 쓰는 시스템 하나 때문에 릴리스를 해야
#: 한다 — 그리고 그때 누군가 "전부 허용"으로 바꾼다.
ALLOWED_PORTS = frozenset({80, 443, 8080, 8443})


class Denial(StrEnum):
    """막힌 이유. **감사에 그대로 들어간다.**"""

    HOST_NOT_ALLOWED = "host_not_allowed"
    HOST_BLOCKED = "host_blocked"
    PORT_NOT_ALLOWED = "port_not_allowed"
    MALFORMED_TARGET = "malformed_target"
    #: 환경 설정을 못 읽었다. **거부가 기본값이다.**
    NO_POLICY = "no_policy"


@dataclass(frozen=True, slots=True)
class Target:
    host: str
    port: int

    def __str__(self) -> str:
        return f"{self.host}:{self.port}"


@dataclass(frozen=True, slots=True)
class Allowed:
    target: Target


@dataclass(frozen=True, slots=True)
class Denied:
    reason: Denial
    detail: str = ""


type Verdict = Allowed | Denied


def parse_target(raw: str) -> Target | None:
    """`CONNECT host:port` 의 대상을 뜯는다. **포트가 없으면 443.**

    IPv6 리터럴(`[::1]:443`)도 받는다 — 받아서 **거부하기 위해서**다.
    파싱에 실패해 `None` 이 되면 거부 사유가 `malformed_target` 이 되는데,
    그러면 "IP 로 직접 나가려 했다"가 감사에 안 남는다.
    """
    value = raw.strip()
    if not value:
        return None

    if value.startswith("["):
        close = value.find("]")
        if close < 0:
            return None
        host = value[1:close]
        rest = value[close + 1 :]
        port_part = rest[1:] if rest.startswith(":") else ""
    elif value.count(":") > 1:
        # 괄호 없는 IPv6. 포트를 가릴 수 없으므로 전체를 호스트로 본다.
        host, port_part = value, ""
    else:
        host, _, port_part = value.partition(":")

    host = normalize_host(host)
    if not host or "/" in host:
        return None

    if not port_part:
        return Target(host=host, port=443)
    if not port_part.isdigit():
        return None
    port = int(port_part)
    if not 1 <= port <= 65535:
        return None
    return Target(host=host, port=port)


def decide(
    raw_target: str,
    policy: NetworkPolicy | None,
    *,
    allowed_ports: frozenset[int] = ALLOWED_PORTS,
) -> Verdict:
    """**기본은 거부다.**

    `policy` 가 `None` 이면 환경 설정을 못 읽은 것이고, 그때 통과시키면
    "조회 실패 = 무제한"이 된다. 프록시가 죽는 것보다 나쁜 상태다 —
    죽으면 아무것도 안 나가지만, 이쪽은 **전부 나간다.**
    """
    if policy is None:
        return Denied(Denial.NO_POLICY, "환경 네트워크 정책을 읽지 못했다")

    target = parse_target(raw_target)
    if target is None:
        return Denied(Denial.MALFORMED_TARGET, f"대상을 해석할 수 없다: {raw_target!r}")

    if target.port not in allowed_ports:
        return Denied(Denial.PORT_NOT_ALLOWED, f"허용되지 않는 포트: {target.port}")

    if is_ip_literal(target.host):
        # **IP 로 직접 나가는 것을 막는다.** 호스트 목록은 이름 기반이라
        # IP 를 적을 수 없고, 그러면 IP 요청은 "목록에 없음"으로만 막힌다.
        # 사유를 따로 두어야 감사에서 "우회 시도"로 보인다.
        return Denied(Denial.HOST_NOT_ALLOWED, f"IP 주소로는 나갈 수 없다: {target.host}")

    if policy.blocked_hosts and any(
        matches_exact_host(e, target.host) for e in policy.blocked_hosts
    ):
        return Denied(Denial.HOST_BLOCKED, f"차단 목록: {target.host}")

    if policy.kind is NetworkKind.LIMITED:
        if not policy.allowed_hosts:
            # `NetworkPolicy.__post_init__` 이 막지만, 다른 경로로 만들어진
            # 객체가 올 수 있다. **거부가 기본값이다.**
            return Denied(Denial.NO_POLICY, "limited 인데 허용 목록이 비었다")
        if not any(matches_exact_host(e, target.host) for e in policy.allowed_hosts):
            return Denied(Denial.HOST_NOT_ALLOWED, f"허용 목록에 없다: {target.host}")

    return Allowed(target=target)


def is_ip_literal(host: str) -> bool:
    """IPv4 · IPv6 · 숫자 축약(`127.1`).

    **마지막 라벨이 숫자면 IP다** — 도메인의 최상위 라벨은 숫자로만 이뤄질
    수 없다 (RFC 1123). 이 한 줄이 `1.2.3.4` 도 `127.1` 도 잡는다.
    """
    if ":" in host:
        return True
    return host.rsplit(".", 1)[-1].isdigit()


__all__ = [
    "ALLOWED_PORTS",
    "Allowed",
    "Denial",
    "Denied",
    "Target",
    "Verdict",
    "decide",
    "is_ip_literal",
    "parse_target",
]
