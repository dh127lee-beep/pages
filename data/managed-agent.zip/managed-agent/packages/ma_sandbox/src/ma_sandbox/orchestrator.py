"""프로비저닝 순서 — **능력을 먼저 확인하고 그다음 만든다**.

`plan/07-sandbox.md` §4 · `plan/02-architecture.md` §10.

순서가 의미를 갖는다.

```
① probe        이 노드가 실제로 무엇을 하는가
② 요구 대조     환경이 요구하는 enforcement 를 만족하는가
③ 거부 또는 진행  못 만족하면 **세션을 열지 않는다**
```

②에서 거부하는 것이 핵심이다. `partial` 을 `enforced` 로 취급하면 운영자가
**없는 보호를 믿는다**. 세션이 안 열리는 것은 불편이지만, 보호가 없는데
있다고 믿는 것은 사고다.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from ma_domain.environments import Enforcement, SandboxTier

if TYPE_CHECKING:
    from ma_sandbox.ports import ProviderCapabilities, SandboxProvider


class SandboxUnavailable(Exception):
    """요구한 격리를 이 노드가 제공하지 못한다. **세션을 열지 않는다.**"""

    def __init__(self, required: Enforcement, actual: Enforcement, reason: str) -> None:
        super().__init__(
            f"요구 격리 {required.value} 를 만족하지 못한다 (실제 {actual.value}): {reason}"
        )
        self.required = required
        self.actual = actual
        self.reason = reason


@dataclass(frozen=True, slots=True)
class Provisioned:
    provider: SandboxProvider
    capabilities: ProviderCapabilities


@dataclass
class SandboxOrchestrator:
    """티어 → provider. **등록은 조립 시점에 끝난다.**"""

    providers: dict[SandboxTier, SandboxProvider]

    def provision(
        self,
        tier: SandboxTier,
        *,
        required: Enforcement = Enforcement.ENFORCED,
        needs_shell: bool = False,
    ) -> Provisioned:
        provider = self.providers.get(tier)
        if provider is None:
            raise SandboxUnavailable(
                required, Enforcement.UNSUPPORTED, f"티어 {tier.value} 의 provider 가 없다"
            )

        caps = provider.probe()  # ① 실제로 무엇이 되는가
        if not caps.satisfies(required):  # ② 요구 대조
            raise SandboxUnavailable(  # ③ 거부
                required, caps.filesystem, "; ".join(caps.notes) or provider.name
            )
        if needs_shell and not caps.supports_shell:
            # 티어 W 는 ambient authority 가 0 이라 shell 이 없다 — 에이전트가
            # `bash` 를 켜 두었으면 **조립 시점에** 막아야 한다. 런타임에
            # "툴이 없다"로 실패하면 사용자는 이유를 모른다.
            raise SandboxUnavailable(
                required,
                caps.filesystem,
                f"{provider.name} 는 shell 을 제공하지 않는다 — 티어 P 가 필요하다",
            )
        return Provisioned(provider=provider, capabilities=caps)


__all__ = ["Provisioned", "SandboxOrchestrator", "SandboxUnavailable"]
