"""정책 조립 — 환경 설정 → `SandboxPolicy`.

`plan/07-sandbox.md` §4.1.

**정책은 호출마다 만든다.** provider 에 고정하지 않는다.
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from ma_sandbox.ports import SandboxMode, SandboxPolicy

if TYPE_CHECKING:
    from ma_domain.ids import SessionId


def for_session(
    workspace_root: Path,
    *,
    session_id: SessionId | None = None,
    writable: bool = True,
    extra_readable: tuple[Path, ...] = (),
    allow_network: bool = False,
) -> SandboxPolicy:
    """흔한 경우의 지름길. 기본은 **쓰기 가능한 워크스페이스**다."""
    return SandboxPolicy(
        mode=SandboxMode.WORKSPACE_WRITE if writable else SandboxMode.READ_ONLY,
        workspace_root=workspace_root,
        session_id=session_id,
        extra_readable=extra_readable,
        allow_network=allow_network,
    )


def escalated(base: SandboxPolicy) -> SandboxPolicy:
    """승인된 1회 상향. **읽기 전용 → 쓰기 가능.**

    정책이 호출마다 실리므로 상향이 자연히 표현된다 — 같은 provider 에
    다른 정책을 실어 한 번 더 부르면 된다 (`plan/07` §4.1).

    `danger-full-access` 로는 올리지 않는다. 그것은 **confine 을 부르지 않는
    것**이지 더 넓은 정책이 아니다.
    """
    from dataclasses import replace

    return replace(base, mode=SandboxMode.WORKSPACE_WRITE)


__all__ = ["escalated", "for_session"]
