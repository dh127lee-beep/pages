"""argv 래핑 공통 — 러너 + 프로필 + **구분자** + 원래 argv.

`plan/07-sandbox.md` §4.1 §4.2.

구분자(`--`)가 중요하다. 없으면 원래 argv 의 첫 인자가 `-rf` 같은 모양일 때
**러너의 플래그로 먹힌다**. 러너가 그것을 해석하면 우리가 의도하지 않은
설정으로 돌아간다.
"""

from __future__ import annotations

from collections.abc import Sequence

#: 러너와 페이로드를 가르는 표준 구분자.
SEPARATOR = "--"


def wrap(runner: Sequence[str], profile: Sequence[str], argv: Sequence[str]) -> tuple[str, ...]:
    """`[러너] [프로필] -- [원래 argv]`.

    원래 argv 를 **변형하지 않는다.** 따옴표를 다시 붙이거나 셸을 거치면
    인젝션 표면이 생긴다 — 우리는 `exec` 으로 직접 띄운다.
    """
    if not argv:
        raise ValueError("감금할 argv 가 비었다")
    return (*runner, *profile, SEPARATOR, *argv)


def quote_for_log(argv: Sequence[str]) -> str:
    """로그용 한 줄. **실행에 쓰지 않는다** — 셸을 거치지 않기 때문이다."""
    import shlex

    return " ".join(shlex.quote(a) for a in argv)


__all__ = ["SEPARATOR", "quote_for_log", "wrap"]
