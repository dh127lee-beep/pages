"""SandboxPort — 런타임 중립 샌드박스 (D13).

`plan/07-sandbox.md` §4.1 · `plan/02-architecture.md` §10.

**이 패키지는 특정 런타임을 모른다.** `wasmtime` 도 `kubernetes` 도 import
하지 않는다 — `.importlinter` 의 `sandbox-neutral` 계약이 강제한다.

두 티어가 있다 (D13).

| 티어 | 격리 | 기본값 |
|---|---|---|
| **W** (Wasm) | Wasmtime + WASI p1. ambient authority 0, bash 없음 | ✅ |
| **P** (Process) | bubblewrap + Landlock argv 래핑 | 옵트인 |

**enforcement 는 보고되는 사실이다.** "막았다고 믿는다"가 아니라 "이 노드에서
실제로 무엇이 걸렸는가"를 돌려준다 — `partial` 이나 `unsupported` 가 와도
숨기지 않는다. 숨기면 운영자가 없는 보호를 믿게 된다.
"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass, field
from enum import StrEnum
from pathlib import Path
from typing import TYPE_CHECKING, Protocol

from ma_domain.environments import Enforcement, SandboxCapabilities, SandboxTier

if TYPE_CHECKING:
    from ma_domain.ids import SessionId


class SandboxMode(StrEnum):
    """파일 효과 수준. `plan/07-sandbox.md` §4.1."""

    READ_ONLY = "read-only"
    WORKSPACE_WRITE = "workspace-write"
    #: **provider 에 보내지 않는다.** 소비자가 원래 argv 를 그대로 실행하고
    #: `confine()` 을 부르지 않는다 — "감금 안 함"이 코드에서 보이게.
    DANGER_FULL_ACCESS = "danger-full-access"


class DenialKind(StrEnum):
    """왜 막혔는가. **거부와 러너 고장을 가르는 것이 §4.2 의 요점이다.**"""

    #: 정상. 툴 결과로 "권한 없음"을 모델에 전달한다.
    DENIED = "denied"
    #: **인프라 오류.** `session.error` 이고 모델에 작업 실패로 보고하지 않는다.
    RUNNER_FAILURE = "runner_failure"
    #: 둘 중 무엇인지 모른다. 보수적으로 러너 고장으로 다룬다.
    UNKNOWN = "unknown"


@dataclass(frozen=True, slots=True)
class SandboxPolicy:
    """한 번의 실행에 대한 완전한 파일 효과 정책.

    **provider 에 고정하지 않고 호출마다 싣는다.** 이유 둘:

    1. 동시에 두 소비자가 **다른 경계**로 돌 수 있다 (세션 둘이 한 워커에).
    2. 승인된 1회 상향(escalated retry)이 자연히 표현된다 — 같은 provider 에
       다른 정책을 실어 한 번 더 부르면 된다.

    고정하면 "이 provider 는 지금 어떤 정책인가"를 추적해야 하고, 그 추적이
    틀리면 **의도보다 넓은 권한으로 실행된다**.
    """

    mode: SandboxMode
    workspace_root: Path
    session_id: SessionId | None = None
    #: 읽기만 허용할 추가 경로 (스킬·메모리 마운트 등).
    extra_readable: tuple[Path, ...] = ()
    #: 네트워크 허용 여부. 티어 P 의 Landlock ABI 4 가 포트 단위로 건다 —
    #: **주소 기반이 아니다** (`plan/07` §4.3).
    allow_network: bool = False

    def __post_init__(self) -> None:
        from ma_domain.errors import InvariantViolation

        if self.mode is SandboxMode.DANGER_FULL_ACCESS:
            # 이 정책으로 `confine()` 을 부르는 것 자체가 설계 위반이다.
            raise InvariantViolation(
                "danger-full-access 는 provider 에 보내지 않는다 — "
                "소비자가 confine() 을 부르지 않아야 한다"
            )
        if not self.workspace_root.is_absolute():
            raise InvariantViolation(f"workspace_root 는 절대 경로여야 한다: {self.workspace_root}")

    @property
    def writable(self) -> bool:
        return self.mode is SandboxMode.WORKSPACE_WRITE


@dataclass(frozen=True, slots=True)
class RunnerFailureRule:
    """러너 고장을 가려내는 규칙. **백엔드별**이다.

    전 백엔드 합집합을 쓰면 **해당 백엔드가 내지 않는 거부를 주장하게 된다** —
    bwrap 의 `EROFS` 문구를 Wasmtime 출력에서 찾는 식.
    """

    #: 이 문자열이 stderr 에 있으면 러너 고장이다.
    fatal_signatures: tuple[str, ...] = ()
    #: 치명 판정 **전에** 지우는 양성 안내 라인.
    informational_lines: tuple[str, ...] = ()
    #: 이 종료 코드는 고장이 아니다 (툴 자신의 실패).
    benign_exit_codes: tuple[int, ...] = ()


@dataclass(frozen=True, slots=True)
class ConfinedArgv:
    """감금된 실행 명령. **러너 + 프로필 + 구분자 + 원래 argv.**"""

    argv: tuple[str, ...]
    enforcement: Enforcement
    #: 이 백엔드가 거부할 때 내는 stderr 방언.
    denial_signatures: tuple[str, ...] = ()
    runner_failure_rules: tuple[RunnerFailureRule, ...] = ()
    #: 왜 `enforced` 가 아닌가. 비어 있지 않으면 운영 로그에 남긴다.
    caveats: tuple[str, ...] = ()

    def classify(self, exit_code: int, stderr: str) -> DenialKind:
        """종료 코드 + stderr → 거부인가 러너 고장인가.

        **종료 코드만으로는 러너 고장을 증명하지 않는다.** 양성 안내 라인을
        먼저 지운 뒤 치명 시그니처를 본다 (`plan/07` §4.2).
        """
        if exit_code == 0:
            return DenialKind.DENIED if self._has_denial(stderr) else DenialKind.UNKNOWN

        cleaned = stderr
        for rule in self.runner_failure_rules:
            for line in rule.informational_lines:
                cleaned = cleaned.replace(line, "")

        for rule in self.runner_failure_rules:
            if exit_code in rule.benign_exit_codes:
                continue
            if any(sig in cleaned for sig in rule.fatal_signatures):
                return DenialKind.RUNNER_FAILURE

        if self._has_denial(cleaned):
            return DenialKind.DENIED
        # **모르면 러너 고장으로 다룬다.** 인프라 장애를 "작업 실패"로 모델에
        # 보고하면 모델이 엉뚱한 재시도를 한다 (`plan/07` §4.2).
        return DenialKind.UNKNOWN

    def _has_denial(self, stderr: str) -> bool:
        return any(sig in stderr for sig in self.denial_signatures)


class SandboxProvider(Protocol):
    """argv 를 감금한다. **파일시스템을 직접 만지지 않는다.**"""

    name: str

    def confine(self, argv: Sequence[str], policy: SandboxPolicy) -> ConfinedArgv: ...

    def probe(self) -> ProviderCapabilities:
        """이 노드에서 실제로 무엇이 되는가. **네트워크·커널을 본다.**"""
        ...


@dataclass(frozen=True, slots=True)
class ProviderCapabilities:
    """노드가 **실제로** 제공하는 것. `probe_capabilities` 가 수집한다.

    도메인의 `SandboxCapabilities` 와 다른 타입인 이유: 그쪽은 **환경이
    선언한 능력**이고(API 가 돌려준다), 이쪽은 **이 프로세스가 지금 이 노드에서
    측정한 것**이다. 둘이 어긋나는 것이 바로 운영이 알아야 할 사실이므로
    같은 타입으로 뭉개면 안 된다.
    """

    provider: str
    tier: SandboxTier
    filesystem: Enforcement
    network: Enforcement
    #: 이 provider 에서 shell 툴(`bash`)을 등록해도 되는가.
    #: 티어 W 는 **항상 False** — ambient authority 가 0 이라 shell 이 없다.
    supports_shell: bool
    notes: tuple[str, ...] = field(default_factory=tuple)

    def satisfies(self, required: Enforcement) -> bool:
        order = {
            Enforcement.UNSUPPORTED: 0,
            Enforcement.PARTIAL: 1,
            Enforcement.ENFORCED: 2,
        }
        return order[self.filesystem] >= order[required]

    def to_domain(self, tools: tuple[str, ...]) -> SandboxCapabilities:
        """API 가 돌려줄 모양으로. **측정값을 그대로 싣는다.**"""
        return SandboxCapabilities(
            tier=self.tier,
            sandbox_enforcement=self.filesystem,
            egress_enforcement=self.network,
            tools_available=tools,
            sandbox_enforcement_reason="; ".join(self.notes) or None,
        )


__all__ = [
    "ConfinedArgv",
    "DenialKind",
    "Enforcement",
    "ProviderCapabilities",
    "RunnerFailureRule",
    "SandboxMode",
    "SandboxPolicy",
    "SandboxProvider",
]
