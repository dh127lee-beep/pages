"""워크스페이스 경계 — **티어 W의 유일한 방어선** (D13).

`plan/07-sandbox.md` §8 · `task/M2-sandbox-tools/T-0301-sandbox-port.md`.

티어 W에서 `read/write/edit/glob/grep` 이 **호스트 프로세스에서** 돈다.
bwrap 도 Landlock 도 없다. 그래서 경계 검사가 샌드박스가 아니라 **우리 코드의
책임**이고, 그 코드가 이 파일 하나다.

티어 P 에서는 bwrap/Landlock 이 2차 방어선이 되어 준다. 티어 W 에서는 없다.
그래서 **테스트 밀도를 다르게 가져간다** — `tests/security/` 의 퍼징 코퍼스가
이 함수만 때린다.

규칙은 하나다.

> 파일 경로를 받는 모든 호스트 툴은 `resolve_in_workspace` 만 쓴다.

`tools/check_architecture.py` 가 `ma_harness.tools` 안의 `open(`·`Path(`
직접 사용을 금지해 이 규칙을 강제한다.
"""

from __future__ import annotations

import os
import unicodedata
from pathlib import Path, PurePosixPath

#: 경로 길이 상한. 리눅스 `PATH_MAX` 와 같다. 넘으면 OS 가 자르거나 거부하는데,
#: **자르는 쪽이 위험하다** — 자른 결과가 다른 파일을 가리킬 수 있다.
MAX_PATH_BYTES = 4096

#: 경로 한 구성요소의 상한. 리눅스 `NAME_MAX`.
MAX_COMPONENT_BYTES = 255


class PathEscape(Exception):
    """워크스페이스 밖을 가리켰다. **이유를 메시지에 담지 않는다.**

    "왜 막혔는지"를 자세히 알려 주면 탐색을 도와주는 셈이다. 모델에게는
    "경계 밖"만 알리고, 상세는 로그로 간다.
    """

    def __init__(self, candidate: str, reason: str = "") -> None:
        super().__init__(f"워크스페이스 경계 밖: {candidate!r}")
        self.candidate = candidate
        #: 로그·감사용. 모델에게 가는 메시지에는 넣지 않는다.
        self.reason = reason or "경계 밖"


def resolve_in_workspace(root: Path, candidate: str) -> Path:
    """`candidate` 를 `root` 안의 절대 경로로 바꾼다. 밖이면 `PathEscape`.

    **심볼릭 링크를 해소한 뒤에 검사한다.** 워크스페이스 안의 심링크가 밖을
    가리켜도 막힌다 — 그것이 가장 흔한 탈출 수법이다.

    `strict=False` 인 이유: 아직 없는 파일에도 써야 한다(`write` 툴). 존재하는
    조상까지 해소하고 나머지는 문자열로 붙으므로, **존재하는 심링크는 전부
    해소된다**.

    거르는 것:

    | 입력 | 왜 |
    |---|---|
    | 널바이트 | C 문자열이 거기서 잘린다 — `a.txt\\0../../etc` 가 `a.txt` 로 보인다 |
    | 절대 경로 | `root` 를 무시하고 어디든 가리킨다 |
    | 전각 변형 (`..／`) | POSIX 에선 그냥 파일명이지만, 다른 레이어가 NFKC 하면 `../` 가 된다 |
    | 퍼센트 인코딩 (`..%2f`) | 같은 이유 — 어딘가가 URL 디코드하면 `../` 가 된다 |
    | 4096바이트 초과 | OS 가 자르면 자른 결과가 다른 파일을 가리킨다 |

    `..` 는 **먼저 거부하지 않는다.** 해소 후 검사가 잡고, 그래야 `sub/../a.txt`
    처럼 **안에 머무는** 상대 경로가 통과한다 (모델이 자연히 만드는 모양이다).
    과잉 차단도 버그다 — 막기만 하면 툴이 아무것도 못 한다.

    `root` 는 **존재해야 한다** (`strict=True`). 없는 루트를 기준으로 검사하면
    `is_relative_to` 가 의미 없는 문자열 비교가 된다.
    """
    reason = _reject(candidate)
    if reason is not None:
        raise PathEscape(candidate, reason)

    try:
        base = root.resolve(strict=True)
    except OSError as exc:
        # 루트가 없으면 **검사 자체가 성립하지 않는다.** 통과시키지 않는다.
        raise PathEscape(candidate, f"워크스페이스 루트를 해소할 수 없다: {exc}") from exc

    target = (base / candidate).resolve(strict=False)
    if not target.is_relative_to(base):
        raise PathEscape(candidate, "해소 결과가 루트 밖")
    return target


#: 퍼센트 인코딩된 점·구분자. 소문자로 맞춰 비교한다.
_ENCODED = ("%2e", "%2f", "%5c", "%252e", "%252f")


def _reject(candidate: str) -> str | None:
    """해소 **전에** 거르는 것들. 통과하면 `None`.

    여기 있는 것들은 대부분 **POSIX 에서는 실제 탈출이 아니다** — `..／x` 도
    `..%2fx` 도 그냥 괴상한 파일명이고, 해소하면 워크스페이스 안에 머문다.

    그래도 거부하는 이유는 **다른 레이어**다. 경로가 HTTP 라우트·로그 뷰어·
    S3 키·윈도우 클라이언트를 거치면서 NFKC 정규화되거나 URL 디코드되면
    그때 진짜 `../` 가 된다. 우리 쪽에서 통과시키면 그 레이어가 마지막
    방어선이 되는데, 그 레이어는 보안을 책임지기로 한 적이 없다.

    즉 **의도적인 과잉 차단**이다. 비용은 "괴상한 파일명을 못 쓴다"이고,
    그 비용은 받아들일 만하다 (`IMPL-0014`).
    """
    if not candidate:
        return "빈 경로"
    if "\x00" in candidate:
        # C 문자열이 널에서 잘린다. 검사는 전체를 보고 `open()` 은 앞부분만 본다.
        return "널바이트"

    # **NFKC 로 본다.** NFC 는 전각 `／`(U+FF0F)를 그대로 두지만 NFKC 는
    # `/` 로 바꾼다 — 다른 레이어가 NFKC 하는 상황을 여기서 미리 본다.
    folded = unicodedata.normalize("NFKC", candidate)
    if len(candidate.encode("utf-8", "surrogatepass")) > MAX_PATH_BYTES:
        return "경로가 너무 길다"

    lowered = folded.lower()
    if any(token in lowered for token in _ENCODED):
        return "퍼센트 인코딩"

    # Windows 구분자. POSIX 에서는 평범한 글자지만 변환 레이어를 거치면 달라진다.
    if "\\" in folded:
        return "역슬래시"

    if PurePosixPath(folded).is_absolute():
        return "절대 경로"
    # 드라이브 문자(`C:`) — POSIX 에서는 상대경로로 보인다.
    if len(folded) >= 2 and folded[1] == ":" and folded[0].isalpha():
        return "드라이브 문자"

    # 전각이 ASCII 구분자로 접히면 경로 모양이 **바뀐다**. 그 변화 자체가 신호다.
    if folded != candidate and PurePosixPath(folded).parts != PurePosixPath(candidate).parts:
        return "전각 변형"

    for part in PurePosixPath(folded).parts:
        if len(part.encode("utf-8", "surrogatepass")) > MAX_COMPONENT_BYTES:
            return "경로 구성요소가 너무 길다"
    return None


def is_inside(root: Path, target: Path) -> bool:
    """이미 해소된 경로가 루트 안인지. **`resolve_in_workspace` 를 대신하지 않는다.**

    디렉터리 순회(`glob`)가 중간 결과를 거르는 데 쓴다 — 거기서는 후보가 이미
    `Path` 이고 해소도 끝났다.
    """
    try:
        return target.resolve(strict=False).is_relative_to(root.resolve(strict=True))
    except OSError:
        return False


def relative_label(root: Path, target: Path) -> str:
    """모델에게 보여줄 경로. **절대 경로를 노출하지 않는다.**

    `/var/lib/awp/sessions/sess_01J.../work/a.txt` 를 그대로 주면 호스트
    파일시스템 구조가 새고, 모델이 그 구조를 이용해 탐색을 시도한다.
    """
    try:
        return str(target.resolve(strict=False).relative_to(root.resolve(strict=True)))
    except (OSError, ValueError):  # pragma: no cover — 경계 안이면 항상 성립한다
        return os.path.basename(str(target))


__all__ = [
    "MAX_COMPONENT_BYTES",
    "MAX_PATH_BYTES",
    "PathEscape",
    "is_inside",
    "relative_label",
    "resolve_in_workspace",
]
