"""`ma_sandbox_local` — **격리 없음. 개발 전용.**

`plan/07-sandbox.md` §4 · `task/M2-sandbox-tools/T-0301-sandbox-port.md`.

이 provider 는 argv 를 **그대로 돌려준다**. 아무것도 막지 않는다.

존재 이유는 하나다: macOS 개발 머신에서 bubblewrap 도 Landlock 도 없이
툴 루프를 돌려 보기 위해서다. 그래서 **프로덕션에서는 기동을 거부한다** —
`AWP_ENV=production` 이면 `create()` 가 예외를 던진다.

거부가 "경고 로그"가 아니라 **예외**인 이유: 경고는 읽히지 않는다. 격리가
없는 채로 프로덕션이 돌면 그것을 알아챌 방법이 없고, 알아챘을 때는 이미
데이터가 나간 뒤다.
"""

from __future__ import annotations

import os
from collections.abc import Sequence
from dataclasses import dataclass

from ma_domain.environments import Enforcement, SandboxTier
from ma_sandbox.ports import (
    ConfinedArgv,
    ProviderCapabilities,
    SandboxPolicy,
)

#: 이 값이면 기동을 거부한다.
PRODUCTION = "production"


class SandboxNotAllowed(RuntimeError):
    """격리 없는 provider 를 프로덕션에서 쓰려 했다."""


@dataclass
class LocalSandboxProvider:
    """**아무것도 감금하지 않는다.** `enforcement` 가 그 사실을 말한다."""

    name: str = "local"

    def confine(self, argv: Sequence[str], policy: SandboxPolicy) -> ConfinedArgv:
        # 원래 argv 그대로. **래핑하지 않는다** — 감금하지 않으므로 러너가 없다.
        return ConfinedArgv(
            argv=tuple(argv),
            enforcement=Enforcement.UNSUPPORTED,
            caveats=(
                "격리 없음 — 이 provider 는 argv 를 그대로 실행한다",
                f"정책 {policy.mode.value} 가 **강제되지 않는다**",
            ),
        )

    def probe(self) -> ProviderCapabilities:
        """**정직하게 `unsupported` 를 보고한다.**

        여기서 `partial` 이라고 말하고 싶은 유혹이 있다 — 호스트 툴의
        `resolve_in_workspace` 가 경로는 막으니까. 하지만 그것은 **툴의
        방어선이지 이 provider 의 것이 아니다.** provider 가 자기 것이 아닌
        보호를 자기 능력으로 보고하면 `satisfies()` 판정이 거짓말이 된다.
        """
        return ProviderCapabilities(
            provider=self.name,
            tier=SandboxTier.PROCESS,
            filesystem=Enforcement.UNSUPPORTED,
            network=Enforcement.UNSUPPORTED,
            supports_shell=True,  # 막지 않으므로 shell 도 돈다 — 그래서 위험하다
            notes=("격리 없음 (개발 전용)",),
        )

    def tools_available(self) -> tuple[str, ...]:
        """**`bash` 를 포함한다.** 이 provider 의 존재 이유가 그것이다 —
        개발 머신에서 셸 툴 경로를 돌려 보는 것.

        위험해 보이는 것이 맞다. 그래서 `LocalSandboxFactory` 가
        `AWP_ENV=production` 에서 기동 자체를 거부한다.
        """
        return (
            "read",
            "write",
            "edit",
            "glob",
            "grep",
            "web_fetch",
            "web_search",
            "bash",
        )


@dataclass
class LocalSandboxFactory:
    """`create()` 가 환경을 보고 거부한다.

    환경변수를 여기서 읽는 것은 `config.py` 규칙의 예외다 — **보안 차단은
    조립이 실수로 빠뜨릴 수 없어야** 하기 때문이다. 설정으로 주입하면
    "주입을 빼먹으면 통과"가 되고, 그 실수가 정확히 막으려는 상황을 만든다.
    """

    env_var: str = "AWP_ENV"

    def create(self, env: dict[str, str] | None = None) -> LocalSandboxProvider:
        source = env if env is not None else os.environ  # awp-env-ok — 보안 차단
        current = source.get(self.env_var, "").strip().lower()
        if current == PRODUCTION:
            raise SandboxNotAllowed(
                f"{self.env_var}={PRODUCTION} 에서 격리 없는 샌드박스를 쓸 수 없다. "
                "티어 W(wasm) 또는 티어 P(process) 를 쓰십시오."
            )
        return LocalSandboxProvider()


__all__ = [
    "PRODUCTION",
    "LocalSandboxFactory",
    "LocalSandboxProvider",
    "SandboxNotAllowed",
]
