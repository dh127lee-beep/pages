"""배포 — cron 으로 도는 에이전트 (T-0603).

`plan/05-database.md` §3 G9 · `plan/06-harness-and-model.md` §5.4 ·
`ref/api/deployments/`.

> **off-peak 가 peak 의 1/2 이다.** 사내 플랫폼은 cron 배포(일일
> 리포트·야간 정리)가 많아 이 이동이 그대로 비용 절감이 된다.

```
cron 발화 시각
    │
    ├ off_peak_preferred=false → 그대로
    └ off_peak_preferred=true  → peak 안이면 **다음 off-peak 창 시작으로**
                                  단, 최대 지연을 넘으면 그대로 (아래)
```

**peak 창을 코드에 박지 않는다.** 모델 카드의 `pricing.peak_windows`
에서 읽는다 — provider 가 바뀌면 창도 바뀐다 (D12).
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from enum import StrEnum

from ma_domain.errors import InvariantViolation
from ma_domain.ids import AgentId, EnvironmentId, SessionId, WorkspaceId

#: off-peak 이동의 **최대 지연**. 넘으면 그냥 peak 에 돌린다.
#:
#: 6시간인 이유: 일일 리포트가 아침에 돌아야 하는데 저녁으로 밀리면
#: 그 리포트는 쓸모가 없다. **절반 아끼려다 결과를 못 쓰면 손해다.**
#: 배포가 더 기다릴 수 있으면 `max_shift` 로 늘린다.
DEFAULT_MAX_SHIFT = timedelta(hours=6)

#: 실행 실패 시 재시도 횟수. 0 이면 건너뛴다.
DEFAULT_RETRIES = 1

#: 연속 실패가 이만큼이면 **배포를 자동 일시정지한다.**
#:
#: 공식도 같은 동작이다 (`ref/api/deployments/list.md` —
#: "A scheduled fire recorded a failed run whose error auto-pauses").
#: 고장난 배포가 매시간 돌면서 돈을 쓰는 것을 막는다.
AUTO_PAUSE_AFTER = 3


class DeploymentState(StrEnum):
    ACTIVE = "active"
    PAUSED = "paused"
    ARCHIVED = "archived"

    @property
    def fires(self) -> bool:
        return self is DeploymentState.ACTIVE


class RunState(StrEnum):
    QUEUED = "queued"
    RUNNING = "running"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    #: 앞 실행이 아직 도는 중이라 건너뛰었다.
    SKIPPED = "skipped"

    @property
    def is_final(self) -> bool:
        return self in (RunState.SUCCEEDED, RunState.FAILED, RunState.SKIPPED)


class RunTrigger(StrEnum):
    SCHEDULE = "schedule"
    MANUAL = "manual"


@dataclass(frozen=True, slots=True)
class Schedule:
    """cron + IANA 타임존. **없으면 수동 실행만.**"""

    cron: str
    timezone: str = "UTC"
    #: peak 를 피해 민다. `plan/06` §5.4.
    off_peak_preferred: bool = False
    #: 이동 상한. 넘으면 **그대로 돌린다** — 절반 아끼려다 결과를
    #: 못 쓰면 손해다.
    max_shift: timedelta = DEFAULT_MAX_SHIFT

    def __post_init__(self) -> None:
        from ma_domain.cron import parse, zone

        # **생성자가 검증한다** — 저장 전에 터진다.
        parse(self.cron)
        zone(self.timezone)
        if self.max_shift < timedelta(0):
            raise InvariantViolation("max_shift 는 음수일 수 없다")


@dataclass(frozen=True, slots=True)
class Deployment:
    """에이전트를 자율 실행하는 설정.

    공식 정의 그대로: "binds the agent to everything needed to run it
    autonomously — an environment, credentials, initial events, and an
    optional schedule" (`ref/api/deployments/archive.md`).
    """

    id: str
    workspace_id: WorkspaceId
    name: str
    agent_id: AgentId
    agent_version: int
    state: DeploymentState
    created_at: datetime
    updated_at: datetime
    environment_id: EnvironmentId | None = None
    schedule: Schedule | None = None
    #: 세션 시작 이벤트. 보통 `user.message` 하나다.
    initial_events: tuple[tuple[tuple[str, object], ...], ...] = ()
    #: **실행 하나당** 상한. 배포는 사람이 안 보므로 상한이 특히 중요하다.
    budget_cents: int | None = None
    #: 연속 실패 수. `AUTO_PAUSE_AFTER` 에서 자동 일시정지.
    consecutive_failures: int = 0
    last_run_at: datetime | None = None
    next_fire_at: datetime | None = None
    paused_reason: str = ""
    archived_at: datetime | None = None

    def __post_init__(self) -> None:
        if not self.name.strip():
            raise InvariantViolation("배포 이름이 비었다")
        if self.budget_cents is not None and self.budget_cents <= 0:
            raise InvariantViolation("실행 예산은 양수여야 한다")

    @property
    def is_scheduled(self) -> bool:
        """**스케줄이 있어야 자동으로 돈다.** 없으면 수동 실행만."""
        return self.schedule is not None and self.state.fires


@dataclass(frozen=True, slots=True)
class DeploymentRun:
    id: str
    workspace_id: WorkspaceId
    deployment_id: str
    state: RunState
    trigger: RunTrigger
    #: 원래 발화했어야 할 시각. **이동 전**이다.
    scheduled_for: datetime
    created_at: datetime
    session_id: SessionId | None = None
    started_at: datetime | None = None
    ended_at: datetime | None = None
    #: off-peak 로 **얼마나 밀렸는가.** 0 이면 안 밀렸다.
    shifted_by: timedelta = timedelta(0)
    error: str = ""
    cost_cents: int = 0

    @property
    def was_shifted(self) -> bool:
        return self.shifted_by > timedelta(0)


@dataclass(frozen=True, slots=True)
class PeakWindowSpec:
    """`ModelCard.pricing.peak_windows` 에서 온 것.

    **도메인이 카드를 직접 들지 않는다** — `ma_domain.models` 를
    import 하면 배포가 모델을 알게 된다. 호출자가 변환해서 준다.
    """

    start_hour_utc: int
    end_hour_utc: int
    weekdays: tuple[int, ...] = (0, 1, 2, 3, 4)

    def covers(self, at: datetime) -> bool:
        utc = at.astimezone(UTC)
        if utc.weekday() not in self.weekdays:
            return False
        return self.start_hour_utc <= utc.hour < self.end_hour_utc


@dataclass(frozen=True, slots=True)
class Shift:
    """이동 결과. **왜 안 밀었는지도 말한다.**"""

    at: datetime
    shifted_by: timedelta = timedelta(0)
    reason: str = ""

    @property
    def moved(self) -> bool:
        return self.shifted_by > timedelta(0)


def shift_to_off_peak(
    fire_at: datetime,
    windows: tuple[PeakWindowSpec, ...],
    *,
    max_shift: timedelta = DEFAULT_MAX_SHIFT,
    step: timedelta = timedelta(minutes=15),
) -> Shift:
    """peak 안이면 **다음 off-peak 창 시작으로** 민다.

    `plan/06` §5.4. 세 가지가 이동을 막는다:

    | | 왜 |
    |---|---|
    | 창이 없다 | 이 카드에 peak 개념이 없다 — 밀 이유가 없다 |
    | 이미 off-peak | 밀면 **괜히 늦어진다** |
    | 상한 초과 | 절반 아끼려다 결과를 못 쓰면 손해다 |

    `step` 으로 훑는 이유: 창 경계를 계산으로 구하면 여러 창이
    겹칠 때(`01-04` 와 `06-10`) 틀리기 쉽다. 15분 단위면 하루가
    96번이고, 그 비용은 **스케줄러가 한 번 더 도는 것**뿐이다.
    """
    if not windows:
        return Shift(at=fire_at, reason="peak 창이 선언되지 않았다")
    if not any(w.covers(fire_at) for w in windows):
        return Shift(at=fire_at, reason="이미 off-peak")

    cursor = fire_at
    limit = fire_at + max_shift
    while cursor <= limit:
        cursor += step
        if not any(w.covers(cursor) for w in windows):
            return Shift(at=cursor, shifted_by=cursor - fire_at, reason="off-peak 로 이동")

    # **밀지 않는다.** 상한을 넘으면 결과가 늦어 쓸모없어진다.
    return Shift(
        at=fire_at,
        reason=f"다음 off-peak 가 상한({max_shift})을 넘는다 — 그대로 돌린다",
    )


__all__ = [
    "AUTO_PAUSE_AFTER",
    "DEFAULT_MAX_SHIFT",
    "DEFAULT_RETRIES",
    "Deployment",
    "DeploymentRun",
    "DeploymentState",
    "PeakWindowSpec",
    "RunState",
    "RunTrigger",
    "Schedule",
    "Shift",
    "shift_to_off_peak",
]
