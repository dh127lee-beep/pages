"""호스트 매칭 규칙 — **두 목록이 서로 다르게 매칭된다.**

`ref/claude-managed-agents/06-tools/tools-web-restrictions.md` ·
`plan/07-sandbox.md` §2 §6 · `IMPL-0018`.

| 목록 | 어디서 | `example.com` 항목이 덮는 것 |
|---|---|---|
| 툴 `allowed_domains` / `blocked_domains` | 에이전트 설정 | `example.com` **과 모든 서브도메인** |
| 환경 `allowed_hosts` / `blocked_hosts` | 환경 설정 | `example.com` **하나**. `*.` 로 시작해야 서브도메인 |

**도메인에 두는 이유**: 이 규칙을 쓰는 곳이 둘이다 — 웹 툴
(`ma_harness.tools._hosts`)과 egress 프록시(`ma_egress.allowlist`). 두
곳에 따로 쓰면 어긋나고, 어긋나면 **프록시가 막는 것과 툴이 막는 것이
달라진다.** 그 차이가 곧 우회 경로다.

도메인은 아무것도 import 하지 않으므로(`plan/03` §3 L1) 둘 다 여기에 닿을
수 있다.
"""

from __future__ import annotations


def normalize_host(host: str) -> str:
    """비교 전 정규화. 대소문자 무시 · 끝의 점(FQDN 표기) 제거."""
    return host.strip().lower().rstrip(".")


def covers_subdomains(entry: str, host: str) -> bool:
    """**툴 목록의 규칙.** 항목이 그 호스트와 모든 서브도메인을 덮는다.

    `example.com` 은 `docs.example.com` 을 덮지만, `docs.example.com` 은
    `example.com` 도 `api.example.com` 도 덮지 않는다.

    앞의 `www.` 도 평범한 서브도메인이다 — `www.example.com` 은
    `example.com` 을 덮지 않는다.

    점 경계를 본다: `example.com` 은 `notexample.com` 을 덮지 않는다.
    """
    host, entry = normalize_host(host), normalize_host(entry)
    return host == entry or host.endswith(f".{entry}")


def matches_exact_host(entry: str, host: str) -> bool:
    """**환경 목록의 규칙.** 정확히 그 호스트 하나.

    `*.` 로 시작할 때만 서브도메인을 덮고, 그때 **자기 자신은 덮지
    않는다** — `*.example.com` 은 `example.com` 이 아니다.
    """
    host, entry = normalize_host(host), normalize_host(entry)
    if entry.startswith("*."):
        return host.endswith(entry[1:])
    return host == entry


def within_env_list(tool_entry: str, env_allowed: tuple[str, ...]) -> bool:
    """툴 목록의 항목 하나가 환경 목록 **안에** 있는가.

    비대칭 때문에 직관과 다르다: `docs.example.com` 은 `["example.com"]`
    안에 **없고**, `["docs.example.com"]` 이나 `["*.example.com"]` 이어야
    안에 있다.
    """
    return any(matches_exact_host(env, tool_entry) for env in env_allowed)


__all__ = [
    "covers_subdomains",
    "matches_exact_host",
    "normalize_host",
    "within_env_list",
]
