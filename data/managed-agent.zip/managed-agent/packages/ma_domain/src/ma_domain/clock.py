"""시간과 ID 생성은 주입받는다.

`docs/conventions/python.md` §시간 — 도메인·애플리케이션에서 `datetime.now()`를
쓰지 않는다. `tools/check_architecture.py`가 검사한다.
"""

from __future__ import annotations

from datetime import datetime
from typing import Protocol


class Clock(Protocol):
    """지금을 알려준다. 항상 tz-aware UTC."""

    def now(self) -> datetime: ...


class IdGenerator(Protocol):
    """`<prefix>_<ULID>` 형태의 새 ID를 만든다.

    `kind`는 `ma_domain.ids.PREFIXES`의 키다.
    """

    def next(self, kind: str) -> str: ...
