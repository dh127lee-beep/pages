"""파일 · 산출물 · 스냅샷 (G8).

`plan/05-database.md` §3 G8 · `plan/08-infrastructure.md` §6 ·
`task/M4-productization/T-0502-files-outputs.md`.

**바이트는 여기 없다.** 도메인이 드는 것은 좌표와 메타데이터뿐이고,
내용은 오브젝트 스토어에 있다. 메모리(D10)와 정확히 반대다 — 그쪽은
100KB 이하 텍스트라 DB 가 진실이고, 이쪽은 수십 MB 임의 바이트다.

**`uploaded_at` 이 nullable 인 것이 설계다.** 행을 먼저 만들고 업로드가
끝나야 채운다. 순서를 뒤집으면(객체 먼저, 행 나중) 업로드 중에 죽었을 때
**주인 없는 객체**가 남고, 그것을 찾을 방법이 없다. 반대로 하면 미완성
행이 남지만 그것은 DB 안에 있으니 청소할 수 있다.
"""

from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass
from datetime import datetime

from ma_domain.errors import InvariantViolation
from ma_domain.ids import FileId, SessionId, WorkspaceId

#: 업로드 상한. `0010_files` 의 CHECK 과 **같은 값이어야 한다.**
MAX_FILE_BYTES = 100 * 1024 * 1024

#: 정규화 후 남길 수 있는 이름 길이. 대부분의 파일시스템이 255 바이트다.
MAX_NAME_LEN = 200

#: 마운트 경로 — 업로드 파일이 샌드박스에서 보이는 곳.
UPLOAD_MOUNT = "/mnt/files"

#: 산출물로 수거하는 디렉터리 (샌드박스 워크스페이스 기준).
OUTPUT_DIR = "outputs"

_UNSAFE = re.compile(r"[^A-Za-z0-9가-힣._-]")
_DOTS = re.compile(r"^\.+")


def safe_name(filename: str) -> str:
    """업로드 파일명 → 마운트에 쓸 안전한 이름.

    **원본을 버리지 않는다** — `files.filename` 에 그대로 남고, 이것은
    `safe_name` 으로 따로 들어간다. 다운로드 헤더에는 원본을 되돌려
    준다 (퍼센트 인코딩해서).

    비ASCII 를 **제거하지 않고 유지한다.** 한글 파일명이 `____.pdf` 가
    되면 사용자가 자기 파일을 알아볼 수 없다. NFC 로 정규화해 자소
    분리(macOS 의 NFD)를 합치고, 경로 구분자와 제어문자만 걷어낸다.

    경로 구분자를 막는 것이 핵심이다 — `../../etc/passwd` 가 마운트
    경로를 빠져나가면 샌드박스 경계가 무의미해진다.
    """
    normalized = unicodedata.normalize("NFC", filename).strip()
    # 경로 성분을 버린다. `a/b/c.txt` 는 `c.txt` 다.
    normalized = normalized.replace("\\", "/").rsplit("/", 1)[-1]
    cleaned = _UNSAFE.sub("_", normalized)
    # 앞의 점을 없앤다 — `..` 과 숨김 파일 둘 다 막는다.
    cleaned = _DOTS.sub("", cleaned)
    cleaned = cleaned[:MAX_NAME_LEN].strip("._") or "file"
    return cleaned


def validate_upload(filename: str, size_bytes: int) -> None:
    """업로드 전에 한 곳에서 본다. **두 구현이 같은 예외를 내게.**"""
    if not filename.strip():
        raise InvariantViolation("파일명이 비었다")
    if size_bytes < 0:
        raise InvariantViolation(f"크기가 음수다: {size_bytes}")
    if size_bytes > MAX_FILE_BYTES:
        raise InvariantViolation(f"파일이 {MAX_FILE_BYTES:,}바이트를 넘는다 ({size_bytes:,})")


def upload_key(workspace_id: str, file_id: str) -> str:
    """`plan/08` §6 표 그대로."""
    return f"files/{workspace_id}/{file_id}"


def output_key(workspace_id: str, session_id: str, path: str) -> str:
    return f"outputs/{workspace_id}/{session_id}/{path}"


def snapshot_key(workspace_id: str, session_id: str, generation: int) -> str:
    """**generation 이 들어간다** — fence 와 맞춘다 (D3).

    같은 세션의 두 세대가 같은 키를 쓰면 좀비 워커가 새 소유자의
    스냅샷을 덮는다. 그때 복원하면 **옛날 워크스페이스가 돌아온다.**
    """
    return f"snapshots/{workspace_id}/{session_id}/{generation}.tar.zst"


@dataclass(frozen=True, slots=True)
class FileMeta:
    """업로드된 파일. **`uploaded_at` 이 None 이면 미완성이다.**"""

    id: FileId
    workspace_id: WorkspaceId
    filename: str
    safe_name: str
    content_type: str
    size_bytes: int
    sha256: str
    storage_key: str
    created_by: str
    created_at: datetime
    uploaded_at: datetime | None = None
    deleted_at: datetime | None = None

    def __post_init__(self) -> None:
        if not self.safe_name:
            raise InvariantViolation("safe_name 이 비었다")
        if self.size_bytes < 0 or self.size_bytes > MAX_FILE_BYTES:
            raise InvariantViolation(f"파일 크기가 범위를 벗어났다: {self.size_bytes}")

    @property
    def is_complete(self) -> bool:
        """바이트가 실제로 올라갔는가. **마운트의 전제 조건이다.**"""
        return self.uploaded_at is not None and self.deleted_at is None

    def mount_path(self) -> str:
        return f"{UPLOAD_MOUNT}/{self.safe_name}"


@dataclass(frozen=True, slots=True)
class SessionOutput:
    """세션이 만든 것. 경로는 샌드박스 워크스페이스 기준 상대 경로다."""

    id: str
    workspace_id: WorkspaceId
    session_id: SessionId
    path: str
    content_type: str
    size_bytes: int
    sha256: str
    storage_key: str
    #: **어느 세대가 만들었는가.** 좀비가 쓴 산출물을 가려낸다.
    generation: int
    created_at: datetime
    deleted_at: datetime | None = None


@dataclass(frozen=True, slots=True)
class WorkspaceSnapshot:
    id: str
    workspace_id: WorkspaceId
    session_id: SessionId
    generation: int
    size_bytes: int
    sha256: str
    storage_key: str
    created_at: datetime
    expires_at: datetime
    deleted_at: datetime | None = None

    def is_expired(self, now: datetime) -> bool:
        return now >= self.expires_at


__all__ = [
    "MAX_FILE_BYTES",
    "MAX_NAME_LEN",
    "OUTPUT_DIR",
    "UPLOAD_MOUNT",
    "FileMeta",
    "SessionOutput",
    "WorkspaceSnapshot",
    "output_key",
    "safe_name",
    "snapshot_key",
    "upload_key",
    "validate_upload",
]
