"""self_hosted 워커 프로토콜 (T-0606).

`plan/04-api.md` §3.3 · `ref/claude-managed-agents/08-self-hosted/`.

> **데이터가 부서 경계를 넘을 수 없을 때** 쓴다 (법무·인사). 샌드박스를
> 부서 인프라에서 돌리고, 우리는 **무엇을 할지만** 큐에 넣는다.

`session_executions` 와 모양이 닮았지만 **신뢰 경계가 다르다**:

| | `session_executions` (D3) | `environment_work` |
|---|---|---|
| 누가 집는가 | 우리 워커 | **부서의 워커** |
| 어떻게 | DB `FOR UPDATE SKIP LOCKED` | HTTP long-poll |
| DB 접근 | 있다 | **없다** |
| fence | `current_generation` | `claim_generation` |

generation 이 둘 다에 있는 이유도 같다: **죽은 줄 알고 회수했는데
그 워커가 살아 돌아오는** 경우(네트워크 분단)에 옛 claim 의 쓰기를
거부해야 한다.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta
from enum import StrEnum

from ma_domain.errors import InvariantViolation
from ma_domain.ids import EnvironmentId, SessionId, WorkspaceId

#: 하트비트가 이보다 오래 끊기면 회수한다.
#:
#: 60초인 이유: 부서 워커는 사내 **다른 네트워크**에 있고, 그 경로의
#: 순단이 수초~수십초다. 더 짧게 잡으면 멀쩡한 워커의 일을 뺏고,
#: 그 워커는 자기가 뺏긴 줄 모른 채 계속 돈다.
DEFAULT_LEASE_TTL = timedelta(seconds=60)
#: 워커가 보낼 주기. **TTL 의 1/3** — 두 번 놓쳐도 한 번이 남는다.
DEFAULT_HEARTBEAT = timedelta(seconds=20)
#: long-poll 최대 대기. 공식 계약의 `block_ms` 상한(999ms)보다 길게
#: 잡는다 — 그쪽은 재폴링을 헬퍼가 하고, 우리는 서버가 기다린다.
MAX_BLOCK = timedelta(seconds=30)
#: 재시도 상한. 넘으면 `failed` 로 굳힌다.
#:
#: 3인 이유: 회수는 **워커 쪽 문제**(죽음·분단)를 뜻하고, 세 번
#: 연속이면 그 환경의 워커가 전부 고장났다고 보는 편이 맞다. 무한히
#: 돌면 큐가 그 하나로 막힌다.
MAX_ATTEMPTS = 3
#: 1회용 워커 시크릿 길이(바이트).
SECRET_BYTES = 32


class WorkState(StrEnum):
    QUEUED = "queued"
    CLAIMED = "claimed"
    DONE = "done"
    FAILED = "failed"
    #: 회수됐다. **재큐된 것이 아니라** 이 시도가 끝난 것이다 —
    #: 재시도는 새 행이 아니라 같은 행의 generation 을 올려 돈다.
    EXPIRED = "expired"

    @property
    def is_final(self) -> bool:
        return self in (WorkState.DONE, WorkState.FAILED)

    @property
    def is_open(self) -> bool:
        """아직 세션을 붙들고 있는가. **유니크 인덱스가 보는 것.**"""
        return self in (WorkState.QUEUED, WorkState.CLAIMED)


@dataclass(frozen=True, slots=True)
class WorkItem:
    """큐의 한 항목. **평문 시크릿이 없다.**

    시크릿은 claim 응답에만 한 번 실린다 (`ClaimedWork.secret`) —
    `credentials` 와 같은 규칙이다 (D5).
    """

    id: str
    workspace_id: WorkspaceId
    environment_id: EnvironmentId
    environment_version: int
    session_id: SessionId
    state: WorkState
    claim_generation: int
    created_at: datetime
    updated_at: datetime
    worker_id: str | None = None
    attempts: int = 0
    claimed_at: datetime | None = None
    heartbeat_at: datetime | None = None
    acked_at: datetime | None = None
    error: str = ""

    def __post_init__(self) -> None:
        if self.environment_version < 1:
            raise InvariantViolation("environment_version 은 1부터 시작한다")
        if self.claim_generation < 0:
            raise InvariantViolation("claim_generation 은 음수일 수 없다")
        if self.state is WorkState.CLAIMED and not self.worker_id:
            raise InvariantViolation("집힌 일에는 워커가 있어야 한다")

    def is_stale(self, now: datetime, *, ttl: timedelta = DEFAULT_LEASE_TTL) -> bool:
        """하트비트가 끊겼는가. **집힌 것만 해당한다.**"""
        if self.state is not WorkState.CLAIMED:
            return False
        last = self.heartbeat_at or self.claimed_at
        return last is None or now - last > ttl

    def accepts(self, generation: int) -> bool:
        """이 generation 의 쓰기를 받아도 되는가.

        **옛 generation 은 거부한다.** 회수된 뒤 살아 돌아온 워커의
        ack 가 새 워커의 결과를 덮으면 안 된다.
        """
        return generation == self.claim_generation


@dataclass(frozen=True, slots=True)
class WorkStats:
    """환경 하나의 큐 상태. 운영자가 "워커가 도는가"를 보는 수치."""

    environment_id: EnvironmentId
    queued: int = 0
    claimed: int = 0
    done: int = 0
    failed: int = 0
    expired: int = 0
    #: 가장 오래 큐에 있는 것의 나이(초). **워커가 멈췄는지의 신호다** —
    #: `queued` 수만 보면 트래픽이 적은 환경과 구분이 안 된다.
    oldest_queued_seconds: int = 0

    @property
    def total(self) -> int:
        return self.queued + self.claimed + self.done + self.failed + self.expired


__all__ = [
    "DEFAULT_HEARTBEAT",
    "DEFAULT_LEASE_TTL",
    "MAX_ATTEMPTS",
    "MAX_BLOCK",
    "SECRET_BYTES",
    "WorkItem",
    "WorkState",
    "WorkStats",
]
