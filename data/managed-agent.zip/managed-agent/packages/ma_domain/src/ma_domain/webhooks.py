"""웹훅 — **리소스 상태 변화를 밖으로** (T-0604).

`plan/04-api.md` §3.8 · `ref/api/webhooks/_types.md`.

> **승인 대기가 사람에게 닿지 않으면 승인 워크플로가 동작하지 않는다.**
> 그것이 이 작업의 이유이고, 웹훅은 그 길 중 하나다 (다른 하나는
> Slack·메일 직접 알림).

서명은 **타임스탬프를 포함한 HMAC** 이다:

```
awp-signature: t=1760000000,v1=<hex>
서명 대상:     "<t>.<body>"
```

타임스탬프가 없으면 **재전송 공격**이 된다 — 한 번 유효했던 요청을
그대로 다시 보내면 영원히 유효하다. `t` 를 서명에 넣고 수신 측이
허용 창(기본 5분)을 보면 그 창이 닫힌다.

**auto-mirror 를 만들지 않는다** (작업 명세). 에이전트가 외부에
답장하려면 MCP 툴로 **명시적으로** 보내야 한다 — 웹훅은 나가는
알림이지 양방향 통로가 아니다.
"""

from __future__ import annotations

import hashlib
import hmac
import json
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import StrEnum
from typing import Any

from ma_domain.errors import InvariantViolation
from ma_domain.ids import WorkspaceId

#: 서명 헤더.
SIGNATURE_HEADER = "awp-signature"

#: 수신 측이 받아 주는 타임스탬프 오차. **재전송 창이다.**
#:
#: 5분인 이유: 이보다 짧으면 시계가 조금만 틀어져도 정상 전송이
#: 거부되고, 길면 탈취된 요청의 재전송 창이 그만큼 열린다.
SIGNATURE_TOLERANCE = timedelta(minutes=5)

#: 시크릿 최소 길이. HMAC 은 짧은 키로도 돌지만, 짧으면 추측된다.
MIN_SECRET_BYTES = 32

#: 본문 상한. 넘으면 **잘라서 보내지 않고 거부한다** — 잘린 JSON 은
#: 수신 측에서 파싱 오류가 되고, 그것은 "웹훅이 깨졌다"로 보인다.
MAX_PAYLOAD_BYTES = 256 * 1024


class WebhookEvent(StrEnum):
    """내보내는 이벤트. **공식 타입 이름을 그대로 쓴다**
    (`ref/api/webhooks/_types.md`) — 수신 측이 공식 SDK 를 쓸 수 있다.

    전부 내보내지 않는다. 사람이 **행동해야 하는 것**과 **돈이 걸린
    것**부터다 — 나머지는 폴링으로 충분하고, 웹훅은 늘어날수록
    수신 측 부담이 된다.
    """

    SESSION_REQUIRES_ACTION = "session.requires_action"
    SESSION_IDLED = "session.idled"
    SESSION_TERMINATED = "session.status_terminated"
    SESSION_BUDGET_REACHED = "session.budget_reached"
    DEPLOYMENT_RUN_STARTED = "deployment_run.started"
    DEPLOYMENT_RUN_SUCCEEDED = "deployment_run.succeeded"
    DEPLOYMENT_RUN_FAILED = "deployment_run.failed"


class DeliveryState(StrEnum):
    PENDING = "pending"
    DELIVERED = "delivered"
    #: 재시도 중. 다음 시도 시각이 `next_attempt_at` 에 있다.
    RETRYING = "retrying"
    #: **포기했다.** DLQ 다 — 지우지 않고 남긴다.
    DEAD = "dead"

    @property
    def is_final(self) -> bool:
        return self in (DeliveryState.DELIVERED, DeliveryState.DEAD)


#: 재시도 횟수. 넘으면 DLQ.
#:
#: 6회인 이유: 아래 곡선으로 **약 1시간**을 덮는다. 수신 측의 짧은
#: 배포·재시작은 그 안에 끝나고, 그보다 긴 장애는 재시도로 풀 수
#: 없다 — 사람이 DLQ 를 보고 다시 쏘는 편이 맞다.
MAX_ATTEMPTS = 6

#: 재시도 지연 (초). 지수 + 상한.
RETRY_SCHEDULE = (10, 60, 300, 900, 1800, 3600)


def retry_delay(attempt: int) -> timedelta:
    """`attempt` 번째 실패 뒤의 지연. `attempt` 는 1부터.

    **지터를 여기서 넣지 않는다.** 웹훅은 엔드포인트마다 독립이고,
    같은 순간에 몰리는 것은 한 엔드포인트가 여러 이벤트를 받을 때다 —
    그때는 수신 측이 감당해야 할 부하이지 우리가 흩뿌릴 일이 아니다.
    (SSE 재연결은 반대다 — 거기서는 모든 탭이 **우리** 프록시로
    몰리므로 지터가 필요하다.)
    """
    index = min(max(attempt, 1), len(RETRY_SCHEDULE)) - 1
    return timedelta(seconds=RETRY_SCHEDULE[index])


@dataclass(frozen=True, slots=True)
class WebhookEndpoint:
    id: str
    workspace_id: WorkspaceId
    url: str
    #: 구독 이벤트. 비면 **전부** — 명시적으로 비우는 것은 의도다.
    events: tuple[WebhookEvent, ...] = ()
    description: str = ""
    created_at: datetime | None = None
    disabled_at: datetime | None = None

    def __post_init__(self) -> None:
        if not self.url.startswith("https://"):
            # **http 를 받지 않는다.** 서명이 있어도 본문이 평문으로
            # 나가고, 거기에 세션 id 와 에이전트 이름이 들어 있다.
            raise InvariantViolation(f"웹훅 URL 은 https 여야 한다: {self.url!r}")

    @property
    def is_active(self) -> bool:
        return self.disabled_at is None

    def wants(self, event: WebhookEvent) -> bool:
        return not self.events or event in self.events


@dataclass(frozen=True, slots=True)
class WebhookDelivery:
    id: str
    workspace_id: WorkspaceId
    endpoint_id: str
    event: WebhookEvent
    payload: tuple[tuple[str, Any], ...]
    state: DeliveryState
    attempts: int
    created_at: datetime
    next_attempt_at: datetime | None = None
    delivered_at: datetime | None = None
    #: 마지막 실패 이유. **DLQ 에서 이것을 읽는다.**
    last_error: str = ""
    last_status: int | None = None

    @property
    def is_dead(self) -> bool:
        return self.state is DeliveryState.DEAD


def envelope(
    event: WebhookEvent,
    *,
    delivery_id: str,
    workspace_id: str,
    at: datetime,
    data: dict[str, Any],
) -> dict[str, Any]:
    """나가는 본문. **공식 모양을 따른다** (`type` + `data`).

    `delivery_id` 를 싣는 이유: 수신 측이 **멱등 처리**를 할 수 있어야
    한다. 재시도는 같은 `delivery_id` 로 오므로, 두 번 처리하면 그것은
    수신 측 버그다 — 우리가 그 판단 재료를 줘야 한다.
    """
    return {
        "id": delivery_id,
        "type": event.value,
        "workspace_id": workspace_id,
        "created_at": at.isoformat(),
        "data": data,
    }


def serialize(body: dict[str, Any]) -> str:
    """서명 대상 문자열. **키 정렬이 고정이다.**

    JSON 직렬화가 호출마다 다르면 서명이 달라지고, 재시도가 다른
    서명을 보내 수신 측이 거부한다. `sort_keys` 와
    `separators` 를 박아 **같은 dict 는 같은 바이트**가 되게 한다.
    """
    return json.dumps(body, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def sign(secret: bytes, body: str, at: datetime) -> str:
    """`t=<unix>,v1=<hex>`.

    **타임스탬프를 서명에 넣는다.** 본문만 서명하면 한 번 유효했던
    요청이 영원히 유효하다 — 재전송 공격이다.
    """
    if len(secret) < MIN_SECRET_BYTES:
        raise InvariantViolation(f"웹훅 시크릿이 {MIN_SECRET_BYTES}바이트보다 짧다 ({len(secret)})")
    stamp = int(at.timestamp())
    mac = hmac.new(secret, f"{stamp}.{body}".encode(), hashlib.sha256).hexdigest()
    return f"t={stamp},v1={mac}"


def verify(
    secret: bytes,
    body: str,
    header: str,
    *,
    now: datetime,
    tolerance: timedelta = SIGNATURE_TOLERANCE,
) -> bool:
    """수신 측이 쓰는 검증. **우리 테스트도 이것을 쓴다.**

    구현을 여기 두는 이유: "서명 검증이 가능한 웹훅이 나간다"를
    증명하려면 **검증하는 쪽 코드**가 있어야 한다. 수신 측에 맡기고
    우리는 서명만 하면, 그 서명이 검증 가능한지 아무도 확인하지 않는다.
    """
    parts = dict(piece.split("=", 1) for piece in header.split(",") if "=" in piece)
    raw_stamp, mac = parts.get("t"), parts.get("v1")
    if not raw_stamp or not mac:
        return False
    try:
        stamp = int(raw_stamp)
    except ValueError:
        return False

    age = abs(now.timestamp() - stamp)
    if age > tolerance.total_seconds():
        # **재전송 창이 닫혔다.**
        return False

    expected = hmac.new(secret, f"{stamp}.{body}".encode(), hashlib.sha256).hexdigest()
    # **상수 시간 비교.** `==` 는 타이밍으로 한 바이트씩 새어 나간다.
    return hmac.compare_digest(expected, mac)


@dataclass(frozen=True, slots=True)
class NotifyMessage:
    """Slack·메일로 나가는 사람용 알림. 웹훅과 **다른 것이다.**

    웹훅은 기계가 받고, 이것은 사람이 읽는다. 그래서 모양이 다르고,
    **승인 링크가 들어간다** — 받은 사람이 바로 누를 수 있어야 한다.
    """

    title: str
    body: str
    #: 눌러서 갈 곳. 승인 알림이면 승인 인박스.
    link: str = ""
    urgent: bool = False
    fields: tuple[tuple[str, str], ...] = field(default_factory=tuple)


__all__ = [
    "MAX_ATTEMPTS",
    "MAX_PAYLOAD_BYTES",
    "MIN_SECRET_BYTES",
    "RETRY_SCHEDULE",
    "SIGNATURE_HEADER",
    "SIGNATURE_TOLERANCE",
    "DeliveryState",
    "NotifyMessage",
    "WebhookDelivery",
    "WebhookEndpoint",
    "WebhookEvent",
    "envelope",
    "retry_delay",
    "serialize",
    "sign",
    "verify",
]
