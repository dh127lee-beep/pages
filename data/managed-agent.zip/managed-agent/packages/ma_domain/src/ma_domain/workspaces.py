"""워크스페이스 — 부서 하나. 모든 리소스의 파티션 키이자 격리·예산 경계.

`plan/01-product-concept.md` §4 · `plan/05-database.md` §3 G1.

`slug`는 **k8s 네임스페이스 이름이 된다** (D7). 그래서 RFC1123 제약을 도메인이
강제한다 — Pod 생성 시점이 아니라 워크스페이스 생성 시점에 막는다.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import datetime
from enum import StrEnum

from ma_domain.errors import InvariantViolation
from ma_domain.ids import ApiKeyId, ModelCardId, UserId, WorkspaceId

#: RFC1123 라벨. k8s 네임스페이스가 받는 모양.
_SLUG = re.compile(r"^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?$")


class Role(StrEnum):
    """`plan/04-api.md` §2.2. 권한 판단은 L4 유스케이스에서 한다."""

    VIEWER = "viewer"
    OPERATOR = "operator"
    ADMIN = "admin"
    OWNER = "owner"

    @property
    def rank(self) -> int:
        return {"viewer": 0, "operator": 1, "admin": 2, "owner": 3}[self.value]

    def at_least(self, other: Role) -> bool:
        return self.rank >= other.rank


@dataclass(frozen=True, slots=True)
class WorkspaceSettings:
    default_model_card: ModelCardId | None = None
    max_concurrent_sessions: int = 10
    daily_session_quota: int = 200
    warm_pool_size: int = 0
    event_retention_days: int = 365

    def __post_init__(self) -> None:
        if self.max_concurrent_sessions < 1:
            raise InvariantViolation("max_concurrent_sessions는 1 이상이어야 한다")
        if self.daily_session_quota < 1:
            raise InvariantViolation("daily_session_quota는 1 이상이어야 한다")
        if self.warm_pool_size < 0:
            raise InvariantViolation("warm_pool_size는 음수일 수 없다")


@dataclass(frozen=True, slots=True)
class Workspace:
    id: WorkspaceId
    name: str
    slug: str
    settings: WorkspaceSettings
    created_at: datetime
    archived_at: datetime | None = None

    def __post_init__(self) -> None:
        if not _SLUG.match(self.slug):
            raise InvariantViolation(
                f"slug는 RFC1123 라벨이어야 한다 (k8s 네임스페이스가 된다): {self.slug!r}"
            )
        if not self.name.strip():
            raise InvariantViolation("워크스페이스 이름이 비었다")

    @property
    def namespace(self) -> str:
        """이 부서의 k8s 네임스페이스 (`plan/08` §2)."""
        return f"awp-runtime-{self.slug}"


@dataclass(frozen=True, slots=True)
class User:
    id: UserId
    email: str
    name: str
    created_at: datetime
    sso_subject: str | None = None


@dataclass(frozen=True, slots=True)
class Membership:
    workspace_id: WorkspaceId
    user_id: UserId
    role: Role
    created_at: datetime


@dataclass(frozen=True, slots=True)
class ApiKey:
    """평문은 발급 시 **한 번만** 돌려준다. 저장은 argon2id 해시."""

    id: ApiKeyId
    workspace_id: WorkspaceId
    name: str
    key_prefix: str
    role: Role
    created_by: UserId
    created_at: datetime
    last_used_at: datetime | None = None
    expires_at: datetime | None = None
    revoked_at: datetime | None = None

    def is_active(self, now: datetime) -> bool:
        if self.revoked_at is not None:
            return False
        return self.expires_at is None or now < self.expires_at
