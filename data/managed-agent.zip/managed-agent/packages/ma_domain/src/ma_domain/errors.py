"""도메인 예외.

**비즈니스 결과를 예외로 표현하지 않는다** (`docs/conventions/python.md` §에러).
`version_conflict`·`not_found`는 union 결과다. 예외는 불변식 위반에만 쓴다.
"""

from __future__ import annotations


class DomainError(Exception):
    """모든 도메인 예외의 바닥."""


class InvariantViolation(DomainError):
    """도메인 불변식이 깨졌다. 버그다 — 잡아서 흐름 제어에 쓰지 않는다."""
