"""스킬 — **부서 도메인 지식을 재사용 가능한 자산으로.**

`plan/01-product-concept.md` §4 · `plan/05-database.md` §3 G2 ·
`task/M5-extensions/T-0602-skills.md`.

스킬은 **파일 묶음 + 한 줄 설명**이다. 에이전트에 부착하면 세션 웜업이
`/mnt/skills/<slug>/` 에 풀어 주고, 시스템 프롬프트에는 **카탈로그만**
들어간다:

```
사용 가능한 스킬:
  contract-review  계약서 조항을 사내 기준과 대조한다
    /mnt/skills/contract-review/
```

> **점진적 공개가 요점이다.** 스킬 본문을 프롬프트에 넣으면 토큰이
> 스킬 수에 비례해 늘고, 그중 대부분은 그 턴에 쓰이지 않는다. 한 줄만
> 넣고 **필요하면 모델이 파일을 읽는다.**

카탈로그 문자열은 **매 턴 같아야 한다** (D12b). 캐시 접두사에
들어가므로, 순서가 흔들리면 그 뒤가 전부 miss 다.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import datetime

from ma_domain.errors import InvariantViolation
from ma_domain.ids import SkillId, WorkspaceId

#: 스킬 하나의 총 크기 상한. 넘으면 거부한다.
#:
#: 1MB 인 이유: 스킬은 **읽을 문서**이지 데이터가 아니다. 그보다 크면
#: 모델이 다 읽지 못하고, 읽지 못할 것을 마운트하면 디스크만 먹는다.
#: 큰 자료는 업로드 파일(G8)로 간다.
MAX_SKILL_BYTES = 1024 * 1024

#: 파일 수 상한. 수백 개면 모델이 `glob` 만 하다 턴을 쓴다.
MAX_SKILL_FILES = 100

#: 설명 길이. **카탈로그 한 줄에 들어가야 한다.**
MAX_DESCRIPTION = 200

#: 샌드박스에서 보이는 마운트 접두사.
SKILL_MOUNT = "/mnt/skills"

_SLUG = re.compile(r"^[a-z0-9][a-z0-9_-]{0,62}$")
_PATH = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._/-]{0,255}$")


def validate_slug(slug: str) -> None:
    if not _SLUG.match(slug):
        raise InvariantViolation(f"스킬 slug 가 잘못됐다: {slug!r}")


def validate_file(path: str) -> None:
    """`memory.validate_write` 와 **같은 이유로 한 곳에 둔다** — 두
    구현(메모리·SQL)이 같은 입력을 같은 예외로 거부해야 한다."""
    if not _PATH.match(path) or ".." in path:
        raise InvariantViolation(f"스킬 파일 경로가 잘못됐다: {path!r}")


@dataclass(frozen=True, slots=True)
class SkillFile:
    path: str
    content: str

    def __post_init__(self) -> None:
        validate_file(self.path)

    @property
    def size(self) -> int:
        return len(self.content.encode("utf-8"))


@dataclass(frozen=True, slots=True)
class SkillDocument:
    """버전에 저장되는 내용. `skill_versions.document` 의 JSONB 다."""

    #: 카탈로그 한 줄. **모델이 "이걸 열어볼까"를 여기서 정한다.**
    description: str
    files: tuple[SkillFile, ...] = ()
    #: GitHub 에서 로드했으면 그 좌표. 재로드에 쓴다.
    source: SkillSource | None = None

    def __post_init__(self) -> None:
        if not self.description.strip():
            raise InvariantViolation("스킬 설명이 비었다 — 카탈로그에 쓸 것이 없다")
        if len(self.description) > MAX_DESCRIPTION:
            raise InvariantViolation(
                f"스킬 설명이 {MAX_DESCRIPTION}자를 넘는다 ({len(self.description)})"
            )
        if len(self.files) > MAX_SKILL_FILES:
            raise InvariantViolation(
                f"스킬 파일이 {MAX_SKILL_FILES}개를 넘는다 ({len(self.files)})"
            )
        paths = [f.path for f in self.files]
        if len(paths) != len(set(paths)):
            raise InvariantViolation("스킬 파일 경로가 중복됐다")
        if self.total_bytes > MAX_SKILL_BYTES:
            raise InvariantViolation(
                f"스킬이 {MAX_SKILL_BYTES:,}바이트를 넘는다 ({self.total_bytes:,})"
            )

    @property
    def total_bytes(self) -> int:
        return sum(f.size for f in self.files)


@dataclass(frozen=True, slots=True)
class SkillSource:
    """GitHub 좌표. **커밋을 박는다** — 브랜치를 보면 내용이 말없이 바뀐다."""

    repo: str
    #: 저장소 안의 디렉터리.
    path: str = ""
    #: 커밋 SHA. **브랜치 이름이 아니다** — 스킬은 에이전트 버전에
    #: 핀되므로, 같은 버전이 다른 내용을 보면 재현이 깨진다.
    commit: str = ""
    ref: str = "main"

    def __post_init__(self) -> None:
        if "/" not in self.repo.strip("/"):
            raise InvariantViolation(f"저장소는 owner/name 모양이어야 한다: {self.repo!r}")


@dataclass(frozen=True, slots=True)
class SkillRecord:
    """`agents`·`environments` 와 **같은 버전 관리 모양**이다."""

    id: SkillId
    workspace_id: WorkspaceId
    name: str
    slug: str
    document: SkillDocument
    version: int
    created_at: datetime
    updated_at: datetime
    archived_at: datetime | None = None

    def __post_init__(self) -> None:
        validate_slug(self.slug)

    @property
    def is_archived(self) -> bool:
        return self.archived_at is not None

    @property
    def mount_path(self) -> str:
        return f"{SKILL_MOUNT}/{self.slug}"


@dataclass(frozen=True, slots=True)
class SkillCatalogEntry:
    """카탈로그 한 줄이 되는 것. **프롬프트 접두사에 들어간다.**"""

    slug: str
    description: str
    mount_path: str
    file_count: int = 0


def catalog_text(entries: tuple[SkillCatalogEntry, ...] | list[SkillCatalogEntry]) -> str:
    """시스템 프롬프트에 인라인되는 문자열.

    > **정렬한다.** 내용이 같으면 문자열도 같아야 한다 — 캐시 접두사에
    > 들어가므로 순서가 흔들리면 그 뒤가 전부 miss 다 (D12b, 히트가
    > 미스의 1/50).

    빈 목록이면 **빈 문자열**이다. "스킬 없음" 같은 줄을 넣으면 스킬이
    하나 생기는 순간 접두사가 바뀐다.
    """
    if not entries:
        return ""
    lines = ["사용 가능한 스킬 — 필요하면 파일을 직접 읽는다:"]
    for e in sorted(entries, key=lambda x: x.slug):
        lines.append(f"  {e.slug}  {e.description}")
        lines.append(f"    {e.mount_path}/")
    return "\n".join(lines)


@dataclass(frozen=True, slots=True)
class MountedSkill:
    """웜업이 푼 결과."""

    skill_id: SkillId
    slug: str
    mount_path: str
    files: tuple[str, ...] = field(default_factory=tuple)


__all__ = [
    "MAX_DESCRIPTION",
    "MAX_SKILL_BYTES",
    "MAX_SKILL_FILES",
    "SKILL_MOUNT",
    "MountedSkill",
    "SkillCatalogEntry",
    "SkillDocument",
    "SkillFile",
    "SkillRecord",
    "SkillSource",
    "catalog_text",
    "validate_file",
    "validate_slug",
]
