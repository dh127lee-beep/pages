"""5필드 POSIX cron — **외부 의존 없이** (T-0603).

`ref/api/deployments/list.md` · `task/M5-extensions/T-0603-deployments-cron.md`.

```
분  시  일  월  요일
*   9   *   *   1-5      평일 09:00
0   */2 *   *   *        2시간마다 정각
```

공식 계약이 **지원하지 않는 것**을 우리도 지원하지 않는다: 초·연도
필드, `L`·`W`·`#`·`?`, `@daily` 같은 단축어. 받아 주면 "되는 줄 알았는데
안 되는" 표면이 생기고, 그것은 cron 에서 **몇 달 뒤에** 드러난다.

> **타임존이 IANA 다.** 사내 배포는 한국시간으로 쓰고, DST 가 있는
> 지역도 있다. `zoneinfo` 가 그것을 안다 — 우리가 오프셋을 더하면
> 서머타임에 한 시간 어긋난다.

`croniter` 를 쓰지 않는 이유: 의존 하나를 아끼는 것도 있지만, 더 큰
것은 **우리가 지원 범위를 정해야 한다**는 것이다. croniter 는 확장
문법을 받아 주고, 그러면 공식 계약보다 넓어진다.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from ma_domain.errors import InvariantViolation

#: 필드별 허용 범위. 요일은 0~7 (0 과 7 둘 다 일요일 — POSIX).
_RANGES = ((0, 59), (0, 23), (1, 31), (1, 12), (0, 7))
_NAMES = ("분", "시", "일", "월", "요일")

#: 다음 발화를 찾을 때 훑을 상한 (분).
#:
#: 4년이다. `0 0 29 2 *` (2월 29일)이 가장 드물고 윤년은 4년마다 온다 —
#: 그보다 길게 두면 **불가능한 표현식**(`0 0 30 2 *`)에서 영원히 돈다.
MAX_SEARCH_MINUTES = 4 * 366 * 24 * 60

_FIELD = re.compile(r"^(\*|\d+)(?:-(\d+))?(?:/(\d+))?$")

#: 공식이 지원하지 않는다고 명시한 것들. **같이 거부한다.**
_UNSUPPORTED = ("@", "L", "W", "#", "?")


class CronError(InvariantViolation):
    """표현식이 잘못됐다. **저장 전에 터진다.**"""


def _parse_field(spec: str, index: int) -> frozenset[int]:
    low, high = _RANGES[index]
    allowed: set[int] = set()

    for piece in spec.split(","):
        match = _FIELD.match(piece)
        if match is None:
            raise CronError(f"{_NAMES[index]} 필드가 잘못됐다: {piece!r}")
        start_raw, end_raw, step_raw = match.groups()

        step = int(step_raw) if step_raw else 1
        if step < 1:
            raise CronError(f"{_NAMES[index]} 필드의 간격이 0 이하다: {piece!r}")

        if start_raw == "*":
            start, end = low, high
        else:
            start = int(start_raw)
            end = int(end_raw) if end_raw else start
        if not (low <= start <= high and low <= end <= high):
            raise CronError(f"{_NAMES[index]} 필드가 범위를 벗어났다 ({low}-{high}): {piece!r}")
        if start > end:
            raise CronError(f"{_NAMES[index]} 필드의 범위가 거꾸로다: {piece!r}")
        allowed.update(range(start, end + 1, step))

    if index == 4 and 7 in allowed:
        # **0 과 7 이 둘 다 일요일이다** (POSIX). 하나로 접는다.
        allowed.discard(7)
        allowed.add(0)
    return frozenset(allowed)


@dataclass(frozen=True, slots=True)
class CronExpression:
    """파싱된 cron. **생성자가 검증한다** — 저장 전에 터진다."""

    raw: str
    minutes: frozenset[int]
    hours: frozenset[int]
    days: frozenset[int]
    months: frozenset[int]
    weekdays: frozenset[int]
    #: 일·요일이 둘 다 제한됐는가. POSIX 는 그때 **OR** 로 본다.
    day_or_weekday: bool

    def matches(self, at: datetime) -> bool:
        if at.minute not in self.minutes or at.hour not in self.hours:
            return False
        if at.month not in self.months:
            return False
        # `datetime.weekday()` 는 월=0 이고 cron 은 일=0 이다.
        weekday = (at.weekday() + 1) % 7
        day_ok = at.day in self.days
        weekday_ok = weekday in self.weekdays
        if self.day_or_weekday:
            # **POSIX 의 기묘한 규칙**: 일과 요일이 둘 다 `*` 가 아니면
            # AND 가 아니라 **OR** 다. `0 0 1 * 1` 은 "1일이거나 월요일"
            # 이지 "1일인 월요일"이 아니다.
            return day_ok or weekday_ok
        return day_ok and weekday_ok


def parse(expression: str) -> CronExpression:
    """`"0 9 * * 1-5"` → `CronExpression`. 잘못되면 `CronError`."""
    text = expression.strip()
    for token in _UNSUPPORTED:
        if token in text:
            raise CronError(
                f"지원하지 않는 cron 문법이다: {token!r} — "
                "5필드 POSIX 만 받는다 (초·연도·L·W·#·?·@단축어 불가)"
            )
    fields = text.split()
    if len(fields) != 5:
        raise CronError(
            f"cron 은 5필드여야 한다 (분 시 일 월 요일), {len(fields)}개를 받았다: {text!r}"
        )

    parsed = [_parse_field(f, i) for i, f in enumerate(fields)]
    for i, allowed in enumerate(parsed):
        if not allowed:  # pragma: no cover — `_parse_field` 가 먼저 터진다
            raise CronError(f"{_NAMES[i]} 필드가 아무것도 고르지 않는다")

    return CronExpression(
        raw=text,
        minutes=parsed[0],
        hours=parsed[1],
        days=parsed[2],
        months=parsed[3],
        weekdays=parsed[4],
        day_or_weekday=fields[2] != "*" and fields[4] != "*",
    )


def zone(name: str) -> ZoneInfo:
    """IANA 타임존. 모르면 `CronError`.

    **UTC 로 떨어지지 않는다.** 오타 난 타임존을 UTC 로 받아 주면
    배포가 9시간 어긋난 시각에 돌고, 아무도 그 이유를 모른다.
    """
    try:
        return ZoneInfo(name)
    except (ZoneInfoNotFoundError, ValueError, KeyError) as exc:
        raise CronError(f"모르는 타임존이다: {name!r}") from exc


def next_fire(
    expression: CronExpression,
    after: datetime,
    *,
    timezone: str = "UTC",
    limit_minutes: int = MAX_SEARCH_MINUTES,
) -> datetime | None:
    """`after` **다음**의 첫 발화. 없으면 `None`.

    `after` 자신은 포함하지 않는다 — 포함하면 같은 분에 두 번 돈다.

    > **지역 시각으로 맞춘다.** `0 9 * * *` 가 서울 배포면 서울의
    > 9시다. 오프셋을 더하는 방식이면 서머타임에 한 시간 어긋나고,
    > 그 어긋남은 1년에 두 번만 보인다.

    `None` 을 돌려주는 경우: `0 0 30 2 *` 처럼 **영원히 오지 않는**
    표현식. 무한 루프 대신 `None` 이다 — 그래야 호출자가 "이 배포는
    안 돈다"고 말할 수 있다.
    """
    tz = zone(timezone)
    local = after.astimezone(tz).replace(second=0, microsecond=0) + timedelta(minutes=1)

    for _ in range(limit_minutes):
        if expression.matches(local):
            # **UTC 로 돌려준다.** DB 와 비교는 전부 UTC 다.
            return local.astimezone(after.tzinfo or tz)
        local += timedelta(minutes=1)
        # 분 단위로 도는 것이 느려 보이지만, 4년치가 210만 번이고
        # 실제로는 거의 항상 **몇 분 안에** 맞는다. 필드별로 건너뛰는
        # 최적화는 DST 경계에서 틀리기 쉽다 — 그 버그가 1년에 두 번만
        # 보이는 종류다.
    return None


def next_fires(
    expression: CronExpression, after: datetime, *, timezone: str = "UTC", count: int = 5
) -> tuple[datetime, ...]:
    """다음 `count` 개. 공식 계약의 `next_fire_times` 가 5개다."""
    out: list[datetime] = []
    cursor = after
    for _ in range(count):
        found = next_fire(expression, cursor, timezone=timezone)
        if found is None:
            break
        out.append(found)
        cursor = found
    return tuple(out)


def describe(expression: CronExpression, timezone: str) -> str:
    """사람이 읽을 한 줄. 콘솔이 쓴다."""
    return f"{expression.raw} ({timezone})"


__all__ = [
    "MAX_SEARCH_MINUTES",
    "CronError",
    "CronExpression",
    "describe",
    "next_fire",
    "next_fires",
    "parse",
    "zone",
]
