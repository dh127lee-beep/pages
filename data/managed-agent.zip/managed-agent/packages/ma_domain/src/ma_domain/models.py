"""모델 카드 — 모델은 코드가 아니라 설정이다 (D12).

`plan/06-harness-and-model.md` §1.

모델에 대해 아는 것을 **전부 이 선언에** 넣는다. 하네스는 선언을 읽어 적응하고,
코드 어디에도 모델 ID 문자열이 박히지 않는다. 실제로 `deepseek-v4-pro`는
2026-09-14부터 V4.1-Flash로 라우팅되고 `deepseek-v4-flash`는 은퇴했다 —
모델은 바뀐다.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime
from decimal import Decimal
from enum import StrEnum
from typing import Literal

from ma_domain.errors import InvariantViolation
from ma_domain.ids import CredentialId, ModelCardId, WorkspaceId


class ProviderKind(StrEnum):
    """어느 어댑터가 이 카드를 처리하는가."""

    DEEPSEEK_OFFICIAL = "deepseek_official"
    OPENAI_COMPATIBLE = "openai_compatible"
    ANTHROPIC_COMPATIBLE = "anthropic_compatible"


class EffortIntent(StrEnum):
    """추론 깊이의 **의도**.

    wire 파라미터 이름과 값은 provider마다 다르다 — 번역은 어댑터가
    `ReasoningSpec`을 보고 한다. 하네스는 의도만 갖는다.
    """

    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    MAX = "max"


@dataclass(frozen=True, slots=True)
class ReasoningSpec:
    """추론 깊이를 어떤 파라미터로, 어떤 값으로 조절하는가.

    DeepSeek은 `reasoning_effort: "high"`(enum)와 `thinking: {"type": "enabled"}`
    (object)를 둘 다 받는다. 다른 provider는 또 다르다.
    """

    param: str
    style: Literal["enum", "object"]
    levels: tuple[str, ...]
    #: EffortIntent → 이 provider가 받는 값. 빈 매핑이면 의도 이름을 그대로 쓴다.
    mapping: tuple[tuple[EffortIntent, str], ...] = ()

    def __post_init__(self) -> None:
        if not self.param:
            raise InvariantViolation("ReasoningSpec.param이 비었다")
        if not self.levels:
            raise InvariantViolation("ReasoningSpec.levels가 비었다")
        for _, wire in self.mapping:
            if wire not in self.levels:
                raise InvariantViolation(f"mapping 값 {wire!r}이 levels에 없다")

    def wire_value(self, intent: EffortIntent) -> str | None:
        """의도를 이 provider의 값으로 번역한다. 표현할 수 없으면 None."""
        for i, wire in self.mapping:
            if i is intent:
                return wire
        return intent.value if intent.value in self.levels else None


@dataclass(frozen=True, slots=True)
class PeakWindow:
    """요금이 비싼 구간. UTC 기준.

    DeepSeek peak은 UTC 01:00–04:00, 06:00–10:00 월–금(중국 공휴일 제외).
    `weekdays`는 0=월 … 6=일.
    """

    start_hour_utc: int
    end_hour_utc: int
    weekdays: tuple[int, ...] = (0, 1, 2, 3, 4)

    def __post_init__(self) -> None:
        if not 0 <= self.start_hour_utc < 24 or not 0 < self.end_hour_utc <= 24:
            raise InvariantViolation("PeakWindow 시각이 범위를 벗어났다")
        if self.start_hour_utc >= self.end_hour_utc:
            raise InvariantViolation("PeakWindow는 start < end 여야 한다")
        if not self.weekdays or any(d < 0 or d > 6 for d in self.weekdays):
            raise InvariantViolation("PeakWindow.weekdays가 잘못됐다")

    def covers(self, at: datetime) -> bool:
        """이 시각이 peak 구간 안인가. **UTC 로 판단한다.**

        tz 가 없는 시각은 거부한다 — 로컬 시각으로 요금을 계산하면 배포 지역에
        따라 청구액이 달라진다.
        """
        if at.tzinfo is None:
            raise InvariantViolation("peak 판정에는 tz 가 있는 시각이 필요하다")
        utc = at.astimezone(UTC)
        if utc.weekday() not in self.weekdays:
            return False
        return self.start_hour_utc <= utc.hour < self.end_hour_utc


@dataclass(frozen=True, slots=True)
class PricingSpec:
    """요금 선언. **비용 계산이 코드가 아니라 데이터다.**

    캐시 히트가 미스의 1/50이고 off-peak가 peak의 1/2이라는 것이
    `plan/06` §5의 지배 변수인데, 그 배수 자체도 여기 선언된 값이다.
    """

    currency: str
    unit_tokens: int
    input_cache_miss: Decimal
    input_cache_hit: Decimal
    output: Decimal
    off_peak_multiplier: Decimal
    peak_windows: tuple[PeakWindow, ...]

    def __post_init__(self) -> None:
        if self.unit_tokens <= 0:
            raise InvariantViolation("unit_tokens는 양수여야 한다")
        for name in ("input_cache_miss", "input_cache_hit", "output"):
            if getattr(self, name) < 0:
                raise InvariantViolation(f"{name}는 음수일 수 없다")
        if not Decimal(0) < self.off_peak_multiplier <= Decimal(1):
            raise InvariantViolation("off_peak_multiplier는 (0, 1] 범위여야 한다")


@dataclass(frozen=True, slots=True)
class ModelCapabilities:
    """어댑터가 **보고하는** 능력. 하네스가 이것을 보고 적응한다.

    카드의 선언과 다를 수 있다. 카드가 `supports_vision=True`라 해도 그
    엔드포인트가 실제로 못 하면 어댑터가 False 로 보고한다 — **카드는 희망이고
    이것은 사실이다.** 샌드박스의 `Enforcement`와 같은 태도다.
    """

    max_input_tokens: int
    max_output_tokens: int
    supports_tools: bool
    supports_vision: bool
    supports_prompt_cache: bool
    reasoning: ReasoningSpec | None
    #: 카드 선언과 어긋난 지점. 비어 있지 않으면 운영 로그에 남긴다.
    caveats: tuple[str, ...] = ()

    @property
    def supports_reasoning(self) -> bool:
        return self.reasoning is not None


@dataclass(frozen=True, slots=True)
class ModelCard:
    """에이전트가 참조하는 **핸들**과 그 뒤의 전부.

    `agents.document.model`에는 `id`만 들어간다. 모델을 바꾸는 것은 이 행을
    고치거나 새 카드를 만드는 일이고, 코드 변경이 0이다.
    """

    id: ModelCardId
    workspace_id: WorkspaceId
    provider: ProviderKind
    wire_model: str
    max_input_tokens: int
    max_output_tokens: int
    pricing: PricingSpec
    base_url: str | None = None
    credential_id: CredentialId | None = None
    supports_tools: bool = True
    supports_vision: bool = False
    supports_prompt_cache: bool = True
    reasoning: ReasoningSpec | None = None
    #: 어댑터에 그대로 넘기는 기본 파라미터. 예: {"max_tokens": 49152}
    defaults: tuple[tuple[str, str | int | float | bool], ...] = ()
    off_peak_preferred: bool = False
    enabled: bool = True

    def __post_init__(self) -> None:
        if not self.wire_model:
            raise InvariantViolation("wire_model이 비었다")
        if self.max_input_tokens <= 0 or self.max_output_tokens <= 0:
            raise InvariantViolation("토큰 한도는 양수여야 한다")

    @property
    def capabilities(self) -> ModelCapabilities:
        return ModelCapabilities(
            max_input_tokens=self.max_input_tokens,
            max_output_tokens=self.max_output_tokens,
            supports_tools=self.supports_tools,
            supports_vision=self.supports_vision,
            supports_prompt_cache=self.supports_prompt_cache,
            reasoning=self.reasoning,
        )


@dataclass(frozen=True, slots=True)
class TokenUsage:
    """한 번의 모델 호출이 쓴 토큰.

    **캐시 히트와 미스를 분리해 들고 있는다.** 합쳐 두면 `plan/06` §5의
    가장 큰 지렛대를 측정할 수 없다.
    """

    input_cache_hit: int = 0
    input_cache_miss: int = 0
    output: int = 0

    def __add__(self, other: TokenUsage) -> TokenUsage:
        return TokenUsage(
            input_cache_hit=self.input_cache_hit + other.input_cache_hit,
            input_cache_miss=self.input_cache_miss + other.input_cache_miss,
            output=self.output + other.output,
        )

    @property
    def total_input(self) -> int:
        return self.input_cache_hit + self.input_cache_miss

    @property
    def cache_hit_ratio(self) -> float:
        """0.0~1.0. 입력이 없으면 0.0.

        이 값이 반복 요청에서 0에 가까우면 **조용한 캐시 무효화**가 있는 것이다.
        """
        total = self.total_input
        return self.input_cache_hit / total if total else 0.0
