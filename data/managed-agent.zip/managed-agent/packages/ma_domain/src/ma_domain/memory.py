"""메모리 스토어 (D10).

`plan/02-architecture.md` §9 · `plan/05-database.md` §3 G7.

**전용 툴이 없다.** `/mnt/memory/<slug>`로 마운트되고 에이전트는 일반 파일 툴로
접근한다. SQL이 진실이고 샌드박스에는 사본이 간다.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import datetime

from ma_domain.errors import InvariantViolation
from ma_domain.ids import MemoryId, MemoryStoreId, MemoryVersionId, WorkspaceId

#: 메모리 하나의 상한. 넘으면 거부한다.
MAX_CONTENT_BYTES = 100 * 1024
_SLUG = re.compile(r"^[a-z0-9][a-z0-9_-]{0,62}$")
_PATH = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._/-]{0,511}$")


def validate_write(path: str, content: str) -> None:
    """경로와 내용의 규칙. **쓰기 전에 한 곳에서 본다.**

    `Memory.__post_init__` 도 같은 것을 보지만, 그것은 **읽어 온 행**을
    만들 때도 돈다. 쓰기 경로는 도메인 객체를 거치지 않을 수 있고
    (SQL 구현은 INSERT 로 바로 간다), 그러면 두 구현이 같은 입력을
    **다른 예외**로 거부한다 — 계약 테스트가 그것을 잡았다.
    """
    if not _PATH.match(path) or ".." in path:
        raise InvariantViolation(f"메모리 경로가 잘못됐다: {path!r}")
    size = len(content.encode("utf-8"))
    if size > MAX_CONTENT_BYTES:
        raise InvariantViolation(f"메모리 내용이 {MAX_CONTENT_BYTES:,}바이트를 넘는다 ({size:,})")


@dataclass(frozen=True, slots=True)
class MemoryStore:
    id: MemoryStoreId
    workspace_id: WorkspaceId
    name: str
    slug: str
    revision: int
    created_at: datetime
    archived_at: datetime | None = None

    def __post_init__(self) -> None:
        if not _SLUG.match(self.slug):
            raise InvariantViolation(f"메모리 스토어 slug가 잘못됐다: {self.slug!r}")

    @property
    def mount_path(self) -> str:
        return f"/mnt/memory/{self.slug}"


@dataclass(frozen=True, slots=True)
class Memory:
    """경로 하나의 내용. `content_sha256`이 CAS precondition이다."""

    id: MemoryId
    workspace_id: WorkspaceId
    store_id: MemoryStoreId
    path: str
    content: str
    content_sha256: str
    revision: int
    created_at: datetime
    updated_at: datetime
    deleted_at: datetime | None = None

    def __post_init__(self) -> None:
        if not _PATH.match(self.path) or ".." in self.path:
            raise InvariantViolation(f"메모리 경로가 잘못됐다: {self.path!r}")
        if len(self.content.encode()) > MAX_CONTENT_BYTES:
            raise InvariantViolation(f"메모리 내용이 {MAX_CONTENT_BYTES}바이트를 넘는다")


@dataclass(frozen=True, slots=True)
class MemoryVersion:
    """감사용. 레댁션되면 `content`가 None이 된다 — **live head는 거부한다**."""

    id: MemoryVersionId
    workspace_id: WorkspaceId
    store_id: MemoryStoreId
    memory_id: MemoryId
    path: str
    content_sha256: str
    author: str
    created_at: datetime
    content: str | None = None
    redacted_at: datetime | None = None
    redacted_by: str | None = None

    @property
    def is_redacted(self) -> bool:
        return self.redacted_at is not None
