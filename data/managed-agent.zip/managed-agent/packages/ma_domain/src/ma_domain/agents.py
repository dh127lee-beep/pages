"""에이전트 — 버전 관리되는 설정 자산.

`plan/01-product-concept.md` §4 · `plan/06-harness-and-model.md` §4.3.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import StrEnum

from ma_domain.errors import InvariantViolation
from ma_domain.ids import AgentId, ModelCardId, SkillId, WorkspaceId
from ma_domain.models import EffortIntent

#: 공식 CMA 내장 툴셋. 이름을 그대로 쓴다.
AGENT_TOOLSET = "agent_toolset_20260401"

#: 8개 중 7개는 샌드박스 셸이 필요 없다 (D13). `bash`만 프로세스 세계를 요구한다.
BUILTIN_TOOLS: tuple[str, ...] = (
    "bash",
    "read",
    "write",
    "edit",
    "glob",
    "grep",
    "web_fetch",
    "web_search",
)
#: 샌드박스 셸을 요구하는 툴.
SHELL_TOOLS: frozenset[str] = frozenset({"bash"})


class ToolKind(StrEnum):
    """툴의 종류를 **실체로** 들고 있는다.

    `stop_reason` 결정이 이름 매칭에 의존하지 않게 하는 것이 목적이다.
    레퍼런스는 하드코딩 이름 목록을 써서 `schedule_*`·`browser_*`를 오분류했다.
    """

    BUILTIN = "builtin"
    MCP = "mcp"
    CUSTOM = "custom"
    DELEGATION = "delegation"


class PermissionPolicy(StrEnum):
    """`auto`(서버 평가)는 1단계 비범위 — 우리가 위험 판정 모델을 운영하지 않는다."""

    ALWAYS_ALLOW = "always_allow"
    ALWAYS_ASK = "always_ask"


@dataclass(frozen=True, slots=True)
class ToolConfig:
    """툴셋 안의 개별 툴 설정."""

    name: str
    enabled: bool = True
    permission_policy: PermissionPolicy | None = None


@dataclass(frozen=True, slots=True)
class AgentToolset:
    """내장 툴셋. `configs`로 개별 비활성화·정책 지정."""

    type: str = AGENT_TOOLSET
    configs: tuple[ToolConfig, ...] = ()
    default_permission_policy: PermissionPolicy = PermissionPolicy.ALWAYS_ALLOW

    def enabled_tools(self) -> frozenset[str]:
        enabled = set(BUILTIN_TOOLS)
        for c in self.configs:
            if c.name not in BUILTIN_TOOLS:
                continue
            if c.enabled:
                enabled.add(c.name)
            else:
                enabled.discard(c.name)
        return frozenset(enabled)

    def policy_for(self, tool: str) -> PermissionPolicy:
        for c in self.configs:
            if c.name == tool and c.permission_policy is not None:
                return c.permission_policy
        return self.default_permission_policy


@dataclass(frozen=True, slots=True)
class CustomToolSpec:
    """애플리케이션이 실행하는 툴. 세션은 `requires_action`으로 멈춘다."""

    name: str
    description: str
    input_schema: str  # JSON Schema 직렬화. 도메인은 파싱하지 않는다.


#: MCP 툴 이름 접두. **서버 이름이 이름 안에 들어간다.**
#:
#: 두 서버가 둘 다 `search` 를 주는 일이 흔하고, 접두가 없으면 뒤에
#: 등록된 쪽이 앞을 덮는다 — 조용히. 그리고 권한 정책이
#: `mcp__github__*` 같은 패턴으로 서버 단위를 가리킬 수 있게 된다.
MCP_PREFIX = "mcp__"
#: 서버 이름과 툴 이름 사이. `__` 인 이유는 `_` 하나면 서버 이름에
#: `_` 가 들어갈 때 경계가 모호해지기 때문이다.
MCP_SEPARATOR = "__"


def mcp_tool_name(server: str, tool: str) -> str:
    """`(서버, 툴)` → `mcp__<server>__<tool>`."""
    return f"{MCP_PREFIX}{server}{MCP_SEPARATOR}{tool}"


def split_mcp_tool_name(name: str) -> tuple[str, str] | None:
    """`mcp__<server>__<tool>` → `(서버, 툴)`. 아니면 `None`.

    **첫 `__` 에서만 가른다.** 툴 이름에 `__` 가 들어갈 수 있다
    (`mcp__github__create__pr` 은 서버 `github`, 툴 `create__pr`).
    서버 이름 쪽은 생성 시 검증으로 `__` 를 막는다.
    """
    if not name.startswith(MCP_PREFIX):
        return None
    rest = name[len(MCP_PREFIX) :]
    server, sep, tool = rest.partition(MCP_SEPARATOR)
    if not sep or not server or not tool:
        return None
    return server, tool


@dataclass(frozen=True, slots=True)
class McpServerSpec:
    """원격 HTTP MCP 서버. 자격증명은 세션 생성 시 vault로 주입된다.

    `allowed_tools` 는 **서버가 부르는 이름 그대로**다 (`create_pr`).
    하네스에 등록될 때 `mcp__<server>__<tool>` 로 접두가 붙는다 —
    두 서버가 같은 툴 이름을 줘도 안 겹치게.

    비어 있으면 **아무 툴도 등록되지 않는다.** "전부 허용"이 아니다:
    원격 서버가 툴을 하나 더 늘렸을 때 그것이 자동으로 에이전트의
    능력이 되면 안 된다 (`tools/list` 는 서버가 통제한다).
    """

    name: str
    url: str
    allowed_tools: tuple[str, ...] = ()
    default_permission_policy: PermissionPolicy = PermissionPolicy.ALWAYS_ASK

    def __post_init__(self) -> None:
        if not self.name.strip():
            raise InvariantViolation("MCP 서버 이름이 비었다")
        if MCP_SEPARATOR in self.name:
            # 서버 이름에 `__` 가 있으면 `mcp__a__b__tool` 의 경계가
            # 모호해져 **다른 서버의 툴로 해석된다.**
            raise InvariantViolation(
                f"MCP 서버 이름에 {MCP_SEPARATOR!r} 를 쓸 수 없다: {self.name}"
            )

    def tool_names(self) -> tuple[str, ...]:
        """하네스에 등록될 이름들."""
        return tuple(mcp_tool_name(self.name, t) for t in self.allowed_tools)


@dataclass(frozen=True, slots=True)
class AgentDefinition:
    """에이전트 설정 문서. `agents.document`에 JSONB로 저장된다."""

    name: str
    model: ModelCardId
    system: str | None = None
    toolset: AgentToolset | None = field(default_factory=AgentToolset)
    custom_tools: tuple[CustomToolSpec, ...] = ()
    mcp_servers: tuple[McpServerSpec, ...] = ()
    skills: tuple[SkillId, ...] = ()
    harness: str = "default"
    effort: EffortIntent | None = None
    description: str | None = None
    metadata: tuple[tuple[str, str], ...] = ()

    def __post_init__(self) -> None:
        if not self.name.strip():
            raise InvariantViolation("에이전트 이름이 비었다")
        seen: set[str] = set()
        for t in self.custom_tools:
            if t.name in BUILTIN_TOOLS:
                raise InvariantViolation(f"커스텀 툴이 내장 툴 이름을 덮는다: {t.name}")
            if t.name in seen:
                raise InvariantViolation(f"커스텀 툴 이름이 중복됐다: {t.name}")
            seen.add(t.name)
        names = [s.name for s in self.mcp_servers]
        if len(names) != len(set(names)):
            raise InvariantViolation("MCP 서버 이름이 중복됐다")

    @property
    def enabled_builtin_tools(self) -> frozenset[str]:
        return self.toolset.enabled_tools() if self.toolset else frozenset()

    @property
    def needs_shell(self) -> bool:
        """티어 W에서 거부해야 하는지 판단하는 데 쓴다."""
        return bool(self.enabled_builtin_tools & SHELL_TOOLS)


@dataclass(frozen=True, slots=True)
class AgentRecord:
    id: AgentId
    workspace_id: WorkspaceId
    definition: AgentDefinition
    version: int
    created_by: str
    created_at: datetime
    updated_at: datetime
    archived_at: datetime | None = None

    def __post_init__(self) -> None:
        if self.version < 1:
            raise InvariantViolation("version은 1부터 시작한다")

    @property
    def is_archived(self) -> bool:
        return self.archived_at is not None
