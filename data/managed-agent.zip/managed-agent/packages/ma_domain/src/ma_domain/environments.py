"""환경 — 세션이 돌아갈 샌드박스 템플릿.

`plan/07-sandbox.md` §5 · `plan/01-product-concept.md` §4.

**능력(enforcement)은 보고되는 사실이다** (D6). `bool`로 두지 않는 이유가 여기 있다 —
`partial`을 `full`로 취급하면 보안 모델 전체가 거짓이 된다.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import StrEnum

from ma_domain.errors import InvariantViolation
from ma_domain.ids import EnvironmentId, WorkspaceId


class SandboxTier(StrEnum):
    """격리 수단. 기본은 WASM — `bash`는 옵트인이다 (D13)."""

    WASM = "wasm"
    PROCESS = "process"
    VM = "vm"

    @property
    def can_run_shell(self) -> bool:
        """이 티어에서 셸이 **원리상** 가능한가.

        **provider 의 `supports_shell` 과 다른 것이다.** 저쪽은 "이
        노드에서 실제로 되는가"(프로브 결과)이고, 이것은 "이 티어의
        구성상 가능한가"다. 편집 시점에는 노드를 모르므로 이쪽만 볼 수
        있다 — 그래서 린트는 **티어 W + `bash`** 같은 확실한 모순만
        잡고, 노드별 판정은 조립 시점의 `SandboxOrchestrator` 가 한다.

        티어 W 가 False 인 이유는 설정이 아니라 **구성**이다: ambient
        authority 가 0 이라 셸이 존재할 자리가 없다 (`plan/07` §3).
        """
        return self is not SandboxTier.WASM


class Enforcement(StrEnum):
    """백엔드가 **보고하는** 강제 수준.

    `PARTIAL`을 `ENFORCED`로 취급해서는 안 된다. 절대적 경계가 필요한 호출자는
    `PARTIAL`에서 거부해야 한다.
    """

    ENFORCED = "enforced"
    PARTIAL = "partial"
    UNSUPPORTED = "unsupported"

    @property
    def is_absolute(self) -> bool:
        return self is Enforcement.ENFORCED


class EgressRequirement(StrEnum):
    """환경이 egress 강제를 요구하는가."""

    REQUIRED = "required"
    BEST_EFFORT = "best_effort"


class NetworkKind(StrEnum):
    UNRESTRICTED = "unrestricted"
    LIMITED = "limited"


@dataclass(frozen=True, slots=True)
class NetworkPolicy:
    """웹 툴과 egress가 닿을 수 있는 곳.

    `allowed_hosts`와 `blocked_hosts`는 **둘 중 하나만** 쓴다 (공식 계약과 동일).
    """

    kind: NetworkKind = NetworkKind.UNRESTRICTED
    allowed_hosts: tuple[str, ...] = ()
    blocked_hosts: tuple[str, ...] = ()
    allow_mcp_servers: bool = True
    allow_package_managers: bool = False

    def __post_init__(self) -> None:
        if self.allowed_hosts and self.blocked_hosts:
            raise InvariantViolation("allowed_hosts와 blocked_hosts를 함께 지정할 수 없다")
        if self.kind is NetworkKind.LIMITED and not (self.allowed_hosts or self.blocked_hosts):
            raise InvariantViolation("limited 네트워크는 호스트 목록이 필요하다")


@dataclass(frozen=True, slots=True)
class PackageSpec:
    """티어 P에서만 의미가 있다. 티어 W는 패키지를 설치하지 않는다."""

    apt: tuple[str, ...] = ()
    pip: tuple[str, ...] = ()
    npm: tuple[str, ...] = ()

    @property
    def is_empty(self) -> bool:
        return not (self.apt or self.pip or self.npm)


@dataclass(frozen=True, slots=True)
class EnvironmentConfig:
    """`cloud`는 우리가 띄우고 `self_hosted`는 부서가 자기 워커를 붙인다."""

    tier: SandboxTier = SandboxTier.WASM
    self_hosted: bool = False
    networking: NetworkPolicy = field(default_factory=NetworkPolicy)
    packages: PackageSpec = field(default_factory=PackageSpec)
    egress: EgressRequirement = EgressRequirement.REQUIRED
    idle_timeout_seconds: int = 300

    def __post_init__(self) -> None:
        # 티어 W는 패키지를 설치하지 않는다 — 환경 생성 시점에 막는다
        if self.tier is SandboxTier.WASM and not self.packages.is_empty:
            raise InvariantViolation(
                "wasm 티어는 패키지를 설치하지 않는다. tier=process로 선언하거나 packages를 비운다"
            )
        if self.idle_timeout_seconds <= 0:
            raise InvariantViolation("idle_timeout_seconds는 양수여야 한다")


@dataclass(frozen=True, slots=True)
class SandboxCapabilities:
    """런타임이 **프로브해서** 보고한 사실. 추측이 아니다.

    `GET /api/v1/environments/{id}/capabilities`가 이것을 돌려준다.
    """

    tier: SandboxTier
    sandbox_enforcement: Enforcement
    egress_enforcement: Enforcement
    tools_available: tuple[str, ...]
    sandbox_enforcement_reason: str | None = None
    egress_conditions: tuple[tuple[str, str], ...] = ()

    def satisfies(self, requirement: EgressRequirement) -> bool:
        """이 능력으로 그 요구를 만족하는가."""
        if requirement is EgressRequirement.REQUIRED:
            return self.egress_enforcement.is_absolute
        return self.egress_enforcement is not Enforcement.UNSUPPORTED


@dataclass(frozen=True, slots=True)
class EnvironmentRecord:
    id: EnvironmentId
    workspace_id: WorkspaceId
    name: str
    config: EnvironmentConfig
    version: int
    created_at: datetime
    updated_at: datetime
    archived_at: datetime | None = None

    @property
    def is_archived(self) -> bool:
        return self.archived_at is not None
