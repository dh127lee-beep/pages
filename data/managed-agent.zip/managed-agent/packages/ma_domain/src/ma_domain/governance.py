"""승인 · 감사 · 예산 — 사내 운영을 위한 추가 개념.

`plan/02-architecture.md` §7 · `plan/05-database.md` §3 G10.

승인은 **fail-closed**다. DeepSeek Harness의 approval seam에서 가져온 4값 어휘를 쓴다.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal
from enum import StrEnum

from ma_domain.agents import ToolKind
from ma_domain.errors import InvariantViolation
from ma_domain.ids import (
    AgentId,
    ApprovalId,
    ApprovalPolicyId,
    EventId,
    ModelCardId,
    SessionId,
    ToolCallId,
    UserId,
    WorkspaceId,
)
from ma_domain.models import TokenUsage
from ma_domain.workspaces import Role


class ApprovalOutcome(StrEnum):
    """닫힌 집합이고 **fail-closed**.

    답변자가 없거나 예외를 던지거나 비정합이면 `UNAVAILABLE`이고,
    그것은 **게이트를 열지 않는다**. `ALLOWED_ONCE`는 물어본 그 행위만 허가한다.
    """

    ALLOWED_ONCE = "allowed-once"
    REJECTED = "rejected"
    CANCELLED = "cancelled"
    UNAVAILABLE = "unavailable"

    @property
    def permits(self) -> bool:
        return self is ApprovalOutcome.ALLOWED_ONCE


class ApprovalState(StrEnum):
    PENDING = "pending"
    APPROVED = "approved"
    DENIED = "denied"
    EXPIRED = "expired"


@dataclass(frozen=True, slots=True)
class ApprovalPolicy:
    """누가 승인할 수 있는가. 공식 계약 위에 얹는 사내 정책 레이어."""

    id: ApprovalPolicyId
    workspace_id: WorkspaceId
    tool_pattern: str
    required_role: Role
    created_at: datetime
    agent_id: AgentId | None = None
    required_approvals: int = 1
    self_approval: bool = False
    expires_after_seconds: int | None = None
    notify: tuple[tuple[str, str], ...] = ()
    priority: int = 0

    def __post_init__(self) -> None:
        if self.required_approvals < 1:
            raise InvariantViolation("required_approvals는 1 이상이어야 한다")
        if not self.tool_pattern:
            raise InvariantViolation("tool_pattern이 비었다")

    def matches(self, tool_name: str) -> bool:
        """`*` 와일드카드만 지원한다. 정규식을 쓰지 않는다 — 정책은 읽기 쉬워야 한다."""
        p = self.tool_pattern
        if p == "*":
            return True
        if p.endswith("*"):
            return tool_name.startswith(p[:-1])
        return tool_name == p


@dataclass(frozen=True, slots=True)
class Approval:
    """승인 요청.

    **툴 인자를 복사해 담지 않는다.** 이미 스트리밍된 `agent.tool_use` 이벤트에
    `tool_call_id`로 연결한다 — 두 번째 복사본은 drift한다.
    """

    id: ApprovalId
    workspace_id: WorkspaceId
    session_id: SessionId
    event_id: EventId
    tool_call_id: ToolCallId
    tool_name: str
    tool_kind: ToolKind
    state: ApprovalState
    requested_at: datetime
    input_summary: tuple[tuple[str, object], ...] = ()
    policy_id: ApprovalPolicyId | None = None
    decided_by: tuple[UserId, ...] = ()
    decided_at: datetime | None = None
    reason: str | None = None
    expires_at: datetime | None = None

    def __post_init__(self) -> None:
        if self.state in (ApprovalState.APPROVED, ApprovalState.DENIED):
            if not self.decided_by or self.decided_at is None:
                raise InvariantViolation("결정된 승인에 결정자·시각이 없다")

    def is_expired(self, now: datetime) -> bool:
        return (
            self.state is ApprovalState.PENDING
            and self.expires_at is not None
            and now >= self.expires_at
        )

    @property
    def outcome(self) -> ApprovalOutcome:
        match self.state:
            case ApprovalState.APPROVED:
                return ApprovalOutcome.ALLOWED_ONCE
            case ApprovalState.DENIED:
                return ApprovalOutcome.REJECTED
            case ApprovalState.EXPIRED:
                return ApprovalOutcome.CANCELLED
            case _:
                return ApprovalOutcome.UNAVAILABLE


class ActorKind(StrEnum):
    USER = "user"
    API_KEY = "api_key"
    SYSTEM = "system"
    AGENT = "agent"


@dataclass(frozen=True, slots=True)
class AuditEntry:
    """append-only. DB 레벨에서 UPDATE/DELETE 권한이 없다."""

    workspace_id: WorkspaceId
    actor_kind: ActorKind
    actor_id: str
    action: str
    resource_type: str
    resource_id: str
    created_at: datetime
    session_id: SessionId | None = None
    detail: tuple[tuple[str, object], ...] = ()
    request_id: str | None = None


class BudgetScope(StrEnum):
    WORKSPACE = "workspace"
    AGENT = "agent"
    USER = "user"


class BudgetPeriod(StrEnum):
    DAILY = "daily"
    MONTHLY = "monthly"
    TOTAL = "total"


@dataclass(frozen=True, slots=True)
class Budget:
    workspace_id: WorkspaceId
    scope: BudgetScope
    period: BudgetPeriod
    limit_cents: int
    scope_id: str | None = None
    session_default_cents: int | None = None
    hard: bool = True

    def __post_init__(self) -> None:
        if self.limit_cents <= 0:
            raise InvariantViolation("예산 상한은 양수여야 한다")
        if self.scope is not BudgetScope.WORKSPACE and not self.scope_id:
            raise InvariantViolation(f"{self.scope} 예산에 scope_id가 없다")


@dataclass(frozen=True, slots=True)
class UsageEvent:
    """사용량 적립.

    `list_cost_cents`를 **그 시점 값으로 저장한다** — 나중에 요금이 바뀌어도
    과거 비용이 재계산되지 않는다.
    """

    workspace_id: WorkspaceId
    session_id: SessionId
    model_card_id: ModelCardId
    wire_model: str
    usage: TokenUsage
    list_cost_cents: Decimal
    created_at: datetime
    thread_id: str | None = None
    #: 어느 에이전트가 썼는가. **`scope='agent'` 예산이 이것으로 센다.**
    #: 세션에서 유도할 수 있지만, 적립 시점에 박아 둔다 — 나중에 세션이
    #: 지워져도 집계가 남아야 한다 (보존 기간이 다르다).
    agent_id: str | None = None
    sandbox_seconds: int = 0
    #: 이 호출이 off-peak 였는가. **적립 시점에 박는다** —
    #: `list_cost_cents` 와 같은 이유다. peak 창이 바뀌면 질의 시점
    #: 계산은 과거를 소급해 다시 해석하고, "off-peak 로 옮겼더니
    #: 비용이 줄었다"는 측정이 틀려진다 (`plan/06` §5).
    off_peak: bool = False

    def __post_init__(self) -> None:
        if self.list_cost_cents < 0:
            raise InvariantViolation("비용은 음수일 수 없다")
