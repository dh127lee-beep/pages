"""식별자 타입과 prefix 규칙.

`docs/conventions/naming.md` §ID prefix.
형식은 `<prefix>_<ULID>`. ULID는 시간 정렬이 되어 커서 페이지네이션과 맞는다.

여기서 ID를 **생성하지 않는다**. 생성은 `IdGenerator` Port의 일이고, 도메인은
받은 문자열이 올바른 모양인지만 안다.
"""

from __future__ import annotations

from typing import Final, NewType

WorkspaceId = NewType("WorkspaceId", str)
UserId = NewType("UserId", str)
ApiKeyId = NewType("ApiKeyId", str)
AgentId = NewType("AgentId", str)
ModelCardId = NewType("ModelCardId", str)
EnvironmentId = NewType("EnvironmentId", str)
SessionId = NewType("SessionId", str)
ThreadId = NewType("ThreadId", str)
EventId = NewType("EventId", str)
ExecutionId = NewType("ExecutionId", str)
ResourceId = NewType("ResourceId", str)
VaultId = NewType("VaultId", str)
CredentialId = NewType("CredentialId", str)
MemoryStoreId = NewType("MemoryStoreId", str)
MemoryId = NewType("MemoryId", str)
MemoryVersionId = NewType("MemoryVersionId", str)
ApprovalId = NewType("ApprovalId", str)
ApprovalPolicyId = NewType("ApprovalPolicyId", str)
SkillId = NewType("SkillId", str)
DeploymentId = NewType("DeploymentId", str)
DeploymentRunId = NewType("DeploymentRunId", str)
FileId = NewType("FileId", str)
SandboxInstanceId = NewType("SandboxInstanceId", str)
WorkerId = NewType("WorkerId", str)
ToolCallId = NewType("ToolCallId", str)

#: 리소스 종류 → ID prefix. `docs/conventions/naming.md`의 표와 1:1이어야 한다.
PREFIXES: Final[dict[str, str]] = {
    "workspace": "wrkspc",
    "user": "user",
    "api_key": "apikey",
    "agent": "agent",
    "model_card": "mdc",
    "environment": "env",
    "session": "sess",
    "thread": "thrd",
    "event": "evt",
    "execution": "exec",
    "resource": "res",
    "vault": "vault",
    "credential": "cred",
    "memory_store": "memst",
    "memory": "mem",
    "memory_version": "memv",
    "approval": "appr",
    "approval_policy": "apol",
    "skill": "skill",
    "deployment": "dep",
    "deployment_run": "run",
    "file": "file",
    "sandbox_instance": "sbx",
    "worker": "wkr",
    "webhook": "whe",
    "webhook_delivery": "whd",
    "deployment_schedule": "sched",
    "environment_work": "work",
}

#: ULID는 Crockford base32 26자.
_ULID_LEN: Final = 26
_ULID_ALPHABET: Final = frozenset("0123456789ABCDEFGHJKMNPQRSTVWXYZ")


class MalformedId(ValueError):
    """ID가 `<prefix>_<ULID>` 모양이 아니다."""


def kind_of(value: str) -> str | None:
    """ID 문자열에서 리소스 종류를 되찾는다. 모르는 prefix면 None."""
    prefix, _, _ = value.partition("_")
    for kind, p in PREFIXES.items():
        if p == prefix:
            return kind
    return None


def is_well_formed(value: str, kind: str | None = None) -> bool:
    """모양 검사. `kind`를 주면 prefix까지 맞는지 본다."""
    prefix, sep, body = value.partition("_")
    if not sep or len(body) != _ULID_LEN:
        return False
    if not set(body) <= _ULID_ALPHABET:
        return False
    if kind is not None:
        return PREFIXES.get(kind) == prefix
    return kind_of(value) is not None


def require_well_formed(value: str, kind: str) -> str:
    """검사하고 그대로 돌려준다. 생성자 안에서 쓴다."""
    if not is_well_formed(value, kind):
        expected = PREFIXES.get(kind, "?")
        raise MalformedId(f"{kind} id는 {expected}_<ULID 26자> 모양이어야 한다: {value!r}")
    return value
