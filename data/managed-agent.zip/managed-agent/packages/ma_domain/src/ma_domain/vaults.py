"""볼트와 자격증명 (D5).

`plan/05-database.md` §3 G6.

**도메인에 평문이 없다.** 암호문도 없다 — 암복호화는 Store 구현의 cipher가 하고,
도메인은 "어떤 호스트에 어떤 종류의 자격증명이 있다"까지만 안다.
"""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from datetime import datetime
from enum import StrEnum

from ma_domain.errors import InvariantViolation
from ma_domain.ids import CredentialId, UserId, VaultId, WorkspaceId


class CredentialKind(StrEnum):
    BEARER = "bearer"
    BASIC = "basic"
    API_KEY_HEADER = "api_key_header"
    MCP_OAUTH = "mcp_oauth"
    ENVIRONMENT_VARIABLE = "environment_variable"


@dataclass(frozen=True, slots=True)
class Vault:
    id: VaultId
    workspace_id: WorkspaceId
    name: str
    version: int
    created_at: datetime
    archived_at: datetime | None = None


@dataclass(frozen=True, slots=True)
class CredentialMeta:
    """자격증명의 **메타데이터만**. API 응답에 쓰이는 모양이 이것이다.

    평문 필드가 아예 없으므로, 실수로 노출할 수 없다.
    """

    id: CredentialId
    workspace_id: WorkspaceId
    vault_id: VaultId
    kind: CredentialKind
    created_by: UserId
    created_at: datetime
    match_hosts: tuple[str, ...] = ()
    mcp_server_name: str | None = None
    header_name: str | None = None
    key_version: int = 1
    expires_at: datetime | None = None
    refresh_failed_at: datetime | None = None
    refresh_error: str | None = None
    rotated_at: datetime | None = None
    archived_at: datetime | None = None

    def __post_init__(self) -> None:
        if self.kind is CredentialKind.API_KEY_HEADER and not self.header_name:
            raise InvariantViolation("api_key_header 자격증명에 header_name이 없다")
        if self.kind is CredentialKind.MCP_OAUTH and not self.mcp_server_name:
            raise InvariantViolation("mcp_oauth 자격증명에 mcp_server_name이 없다")
        for h in self.match_hosts:
            if not h or h.startswith(".") or "/" in h:
                raise InvariantViolation(f"잘못된 호스트: {h!r}")

    def matches_host(self, host: str) -> bool:
        """서브도메인 포함 매칭. egress 프록시의 핫 경로."""
        h = host.lower()
        return any(h == m.lower() or h.endswith("." + m.lower()) for m in self.match_hosts)

    def needs_refresh(self, now: datetime) -> bool:
        return self.expires_at is not None and now >= self.expires_at


@dataclass(frozen=True, slots=True)
class OAuthTokens:
    """MCP OAuth 자격증명의 **내용물**.

    `mcp_oauth` 하나가 토큰 두 개를 들고 있어야 한다 — 쓰는 것
    (`access_token`)과 갱신하는 것(`refresh_token`). 행을 둘로 쪼개면
    둘의 수명이 어긋나고, 어긋난 순간을 아무도 못 본다.

    > **프록시는 `access_token` 만 받는다.** `reveal_for_injection` 이
    > 그것만 돌려준다 (`injectable_secret`). 갱신 토큰이 프록시에 가면
    > 프록시가 토큰을 **새로 만들 수 있게** 되고, 그것은 D5 가 막으려는
    > 것보다 더 센 권한이다.
    """

    access_token: str
    refresh_token: str = ""
    #: 갱신을 보낼 곳. 비면 **갱신할 수 없다** (수동 재연결만).
    token_endpoint: str = ""
    client_id: str = ""
    scope: str = ""

    @property
    def refreshable(self) -> bool:
        return bool(self.refresh_token and self.token_endpoint)


def encode_oauth_secret(tokens: OAuthTokens) -> str:
    """`OAuthTokens` → 저장할 문자열. **정렬해서 쓴다** — 같은 내용이
    같은 바이트가 되어야 재암호화 배치가 변경을 오판하지 않는다."""
    return json.dumps(asdict(tokens), sort_keys=True, separators=(",", ":"))


def decode_oauth_secret(raw: str) -> OAuthTokens:
    """저장된 문자열 → `OAuthTokens`.

    **JSON 이 아니면 전체를 access token 으로 본다.** 수동으로 붙여
    넣은 토큰(갱신 불가)이 그 모양이고, 그것도 쓸 수 있어야 한다 —
    모든 사내 MCP 서버가 OAuth 를 하지는 않는다.
    """
    try:
        got = json.loads(raw)
    except (json.JSONDecodeError, TypeError):
        return OAuthTokens(access_token=raw)
    if not isinstance(got, dict) or "access_token" not in got:
        return OAuthTokens(access_token=raw)
    return OAuthTokens(
        access_token=str(got.get("access_token") or ""),
        refresh_token=str(got.get("refresh_token") or ""),
        token_endpoint=str(got.get("token_endpoint") or ""),
        client_id=str(got.get("client_id") or ""),
        scope=str(got.get("scope") or ""),
    )


def injectable_secret(kind: CredentialKind, raw: str) -> str:
    """저장된 평문 → **프록시에 줄 값**.

    `mcp_oauth` 만 다르다: 저장은 봉투(JSON)이고 주입은 access token
    하나다. 이 함수가 **갱신 토큰이 프록시에 가지 않게 하는 선**이다.
    """
    if kind is CredentialKind.MCP_OAUTH:
        return decode_oauth_secret(raw).access_token
    return raw


class CredentialAction(StrEnum):
    """`credential_events`에 남는 것. **평문은 없다.**"""

    INJECTED = "injected"
    REFRESHED = "refreshed"
    REFRESH_FAILED = "refresh_failed"
    ROTATED = "rotated"
    DENIED = "denied"
