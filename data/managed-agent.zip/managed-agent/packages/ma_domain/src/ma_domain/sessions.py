"""세션 — 환경 안에서 특정 작업을 수행하는 에이전트 인스턴스.

`plan/01-product-concept.md` §4 · `plan/02-architecture.md` §5.

**정상 완료는 `IDLE`이고 `TERMINATED`가 아니다.** 이것을 헷갈리면 UI가 완료된 세션을
오류로 표시한다.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import StrEnum

from ma_domain.errors import InvariantViolation
from ma_domain.ids import (
    AgentId,
    CredentialId,
    EnvironmentId,
    MemoryStoreId,
    ModelCardId,
    ResourceId,
    SessionId,
    ThreadId,
    VaultId,
    WorkspaceId,
)
from ma_domain.models import EffortIntent, TokenUsage


class SessionStatus(StrEnum):
    IDLE = "idle"
    RUNNING = "running"
    RESCHEDULING = "rescheduling"
    TERMINATED = "terminated"

    @property
    def is_terminal(self) -> bool:
        return self is SessionStatus.TERMINATED

    @property
    def accepts_input(self) -> bool:
        """`terminated`만 입력을 거부한다 (409)."""
        return self is not SessionStatus.TERMINATED


#: 허용되는 상태 전이. 그 외는 불변식 위반이다.
_TRANSITIONS: dict[SessionStatus, frozenset[SessionStatus]] = {
    SessionStatus.IDLE: frozenset(
        {SessionStatus.RUNNING, SessionStatus.TERMINATED, SessionStatus.IDLE}
    ),
    SessionStatus.RUNNING: frozenset(
        {
            SessionStatus.IDLE,
            SessionStatus.RESCHEDULING,
            SessionStatus.TERMINATED,
        }
    ),
    SessionStatus.RESCHEDULING: frozenset(
        {SessionStatus.RUNNING, SessionStatus.IDLE, SessionStatus.TERMINATED}
    ),
    SessionStatus.TERMINATED: frozenset(),
}


def can_transition(src: SessionStatus, dst: SessionStatus) -> bool:
    return dst in _TRANSITIONS[src]


class StopReason(StrEnum):
    """턴이 왜 끝났는가. **툴의 `kind`로 결정하고 이름 매칭을 하지 않는다.**"""

    END_TURN = "end_turn"
    REQUIRES_ACTION = "requires_action"
    BUDGET_REACHED = "budget_reached"
    INTERRUPTED = "interrupted"
    MAX_TOKENS = "max_tokens"
    ERROR = "error"


class RequiredAction(StrEnum):
    """`REQUIRES_ACTION`일 때 클라이언트가 무엇을 보내야 하는가."""

    TOOL_CONFIRMATION = "tool_confirmation"
    CUSTOM_TOOL_RESULT = "custom_tool_result"


class ResourceKind(StrEnum):
    FILE = "file"
    GITHUB_REPOSITORY = "github_repository"
    MEMORY_STORE = "memory_store"
    ENV = "env"


@dataclass(frozen=True, slots=True)
class SessionResource:
    """세션에 붙는 자원. **평문 비밀은 여기 없다** — `secret_ref`만 있다."""

    id: ResourceId
    workspace_id: WorkspaceId
    session_id: SessionId
    kind: ResourceKind
    mount_path: str | None = None
    read_only: bool = False
    memory_store_id: MemoryStoreId | None = None
    secret_ref: CredentialId | None = None
    spec: tuple[tuple[str, object], ...] = ()
    removed_at: datetime | None = None

    def __post_init__(self) -> None:
        if self.kind is ResourceKind.MEMORY_STORE and self.memory_store_id is None:
            raise InvariantViolation("memory_store 리소스에 memory_store_id가 없다")


@dataclass(frozen=True, slots=True)
class ConfigOverride:
    """세션 단위 오버라이드.

    `model` 오버라이드는 카드 **전체를 대체**하므로 에이전트의 effort가 따라오지 않는다 —
    필요하면 `effort`도 함께 지정한다.
    """

    model: ModelCardId | None = None
    system: str | None = None
    effort: EffortIntent | None = None


@dataclass(frozen=True, slots=True)
class SessionBudget:
    """달러 하드 상한. **도달은 일시정지지 종료가 아니다.**"""

    limit_cents: int
    spent_cents: int = 0

    def __post_init__(self) -> None:
        if self.limit_cents <= 0:
            raise InvariantViolation("예산 상한은 양수여야 한다")
        if self.spent_cents < 0:
            raise InvariantViolation("지출은 음수일 수 없다")

    @property
    def is_exhausted(self) -> bool:
        return self.spent_cents >= self.limit_cents

    @property
    def remaining_cents(self) -> int:
        return max(0, self.limit_cents - self.spent_cents)


@dataclass(frozen=True, slots=True)
class SessionRecord:
    """세션 하나.

    `agent_version`을 **핀**하는 것이 중요하다. 운영자가 에이전트를 고치는 동안
    진행 중인 세션의 행동이 바뀌면 그 세션의 이벤트 로그를 재현할 수 없다.
    """

    id: SessionId
    workspace_id: WorkspaceId
    agent_id: AgentId
    agent_version: int
    environment_id: EnvironmentId
    environment_version: int
    status: SessionStatus
    revision: int
    created_by: str
    created_at: datetime
    updated_at: datetime
    stop_reason: StopReason | None = None
    required_action: RequiredAction | None = None
    config_override: ConfigOverride | None = None
    budget: SessionBudget | None = None
    usage: TokenUsage = field(default_factory=TokenUsage)
    vault_ids: tuple[VaultId, ...] = ()
    last_active_at: datetime | None = None
    archived_at: datetime | None = None
    deleted_at: datetime | None = None

    def __post_init__(self) -> None:
        if self.revision < 0:
            raise InvariantViolation("revision은 음수일 수 없다")
        if self.agent_version < 1:
            raise InvariantViolation("agent_version은 1부터 시작한다")
        if self.stop_reason is StopReason.REQUIRES_ACTION and self.required_action is None:
            raise InvariantViolation("requires_action 에는 어떤 입력이 필요한지가 함께 있어야 한다")
        if self.status is not SessionStatus.IDLE and self.stop_reason is not None:
            if self.status is not SessionStatus.TERMINATED:
                raise InvariantViolation("stop_reason은 idle 또는 terminated에서만 유효하다")

    @property
    def is_deleted(self) -> bool:
        return self.deleted_at is not None

    @property
    def is_archived(self) -> bool:
        return self.archived_at is not None

    @property
    def awaits_human(self) -> bool:
        """승인 대기는 **에러가 아니라 정상 상태**다."""
        return self.status is SessionStatus.IDLE and self.stop_reason is StopReason.REQUIRES_ACTION


@dataclass(frozen=True, slots=True)
class SessionThread:
    """lane. 1단계는 `primary` 하나만 쓴다."""

    id: ThreadId
    workspace_id: WorkspaceId
    session_id: SessionId
    created_at: datetime
    status: SessionStatus = SessionStatus.IDLE
    archived_at: datetime | None = None
