"""세션 이벤트 — append-only 로그의 단위.

`plan/04-api.md` §4.2의 표와 **1:1로 일치해야 한다**. `tests/unit/domain/test_event_taxonomy.py`가
그 문서를 읽어 비교한다 — 표를 고치면 테스트가 깨지고, 그때 여기도 함께 고친다.

`seq`는 **모델이 본 순서**다 (D4). 도착 순서가 아니다. promote 시점에 부여된다.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from enum import StrEnum

from ma_domain.errors import InvariantViolation
from ma_domain.ids import EventId, SessionId, ThreadId, ToolCallId, WorkspaceId

#: 1단계에서 쓰지 않는 이벤트. 타입은 정의하되 발행하지 않는다.
LATER_PHASE: frozenset[str] = frozenset()


class EventType(StrEnum):
    """`{domain}.{action}`. 스트림 전용 프레임은 `system.` 아래에 둔다."""

    # ── user ───────────────────────────────────────────────
    USER_MESSAGE = "user.message"
    USER_INTERRUPT = "user.interrupt"
    USER_TOOL_CONFIRMATION = "user.tool_confirmation"
    USER_CUSTOM_TOOL_RESULT = "user.custom_tool_result"
    USER_TOOL_RESULT = "user.tool_result"
    USER_DEFINE_OUTCOME = "user.define_outcome"

    # ── agent ──────────────────────────────────────────────
    AGENT_MESSAGE = "agent.message"
    AGENT_THINKING = "agent.thinking"
    AGENT_TOOL_USE = "agent.tool_use"
    AGENT_TOOL_RESULT = "agent.tool_result"
    AGENT_MCP_TOOL_USE = "agent.mcp_tool_use"
    AGENT_MCP_TOOL_RESULT = "agent.mcp_tool_result"
    AGENT_CUSTOM_TOOL_USE = "agent.custom_tool_use"
    AGENT_THREAD_CONTEXT_COMPACTED = "agent.thread_context_compacted"
    AGENT_THREAD_MESSAGE_SENT = "agent.thread_message_sent"
    AGENT_THREAD_MESSAGE_RECEIVED = "agent.thread_message_received"
    #: 우리 추가 — 실패·취소·스트림 오류 시도를 **로그에만** 남긴다.
    #: `derive_messages()`가 제외하므로 모델 히스토리에 들어가지 않는다.
    AGENT_MESSAGE_ATTEMPT = "agent.message_attempt"

    # ── session ────────────────────────────────────────────
    SESSION_STATUS_RUNNING = "session.status_running"
    SESSION_STATUS_IDLE = "session.status_idle"
    SESSION_STATUS_RESCHEDULED = "session.status_rescheduled"
    SESSION_STATUS_TERMINATED = "session.status_terminated"
    SESSION_DELETED = "session.deleted"
    SESSION_UPDATED = "session.updated"
    SESSION_ERROR = "session.error"
    SESSION_USAGE = "session.usage"
    SESSION_THREAD_CREATED = "session.thread_created"
    SESSION_THREAD_STATUS_RUNNING = "session.thread_status_running"
    SESSION_THREAD_STATUS_IDLE = "session.thread_status_idle"
    SESSION_THREAD_STATUS_RESCHEDULED = "session.thread_status_rescheduled"
    SESSION_THREAD_STATUS_TERMINATED = "session.thread_status_terminated"

    # ── workflow_run (3단계) ───────────────────────────────
    WORKFLOW_RUN_CREATED = "workflow_run.created"
    WORKFLOW_RUN_STATUS_RUNNING = "workflow_run.status_running"
    WORKFLOW_RUN_STATUS_IDLE = "workflow_run.status_idle"
    WORKFLOW_RUN_STATUS_ENDED = "workflow_run.status_ended"
    WORKFLOW_RUN_ERROR = "workflow_run.error"
    WORKFLOW_RUN_PHASE_STARTED = "workflow_run.phase_started"
    WORKFLOW_RUN_PHASE_ENDED = "workflow_run.phase_ended"

    # ── span ───────────────────────────────────────────────
    SPAN_MODEL_REQUEST_START = "span.model_request_start"
    SPAN_MODEL_REQUEST_END = "span.model_request_end"
    SPAN_OUTCOME_EVALUATION_START = "span.outcome_evaluation_start"
    SPAN_OUTCOME_EVALUATION_ONGOING = "span.outcome_evaluation_ongoing"
    SPAN_OUTCOME_EVALUATION_END = "span.outcome_evaluation_end"

    # ── system ─────────────────────────────────────────────
    SYSTEM_MESSAGE = "system.message"


class StreamFrameType(StrEnum):
    """**영속되지 않는** 스트림 전용 프레임.

    `session_events`에 들어가지 않는다. UI가 '대기 중'·'생성 중'을 보여주기 위한 것이다.
    """

    USER_MESSAGE_PENDING = "system.user_message_pending"
    USER_MESSAGE_PROMOTED = "system.user_message_promoted"
    USER_MESSAGE_CANCELLED = "system.user_message_cancelled"
    AGENT_MESSAGE_CHUNK = "agent.message_chunk"
    EVENT_START = "event_start"
    EVENT_DELTA = "event_delta"


#: 클라이언트가 보낼 수 있는 이벤트. 그 외는 400이다.
SENDABLE: frozenset[EventType] = frozenset(
    {
        EventType.USER_MESSAGE,
        EventType.USER_INTERRUPT,
        EventType.USER_TOOL_CONFIRMATION,
        EventType.USER_CUSTOM_TOOL_RESULT,
        EventType.USER_TOOL_RESULT,
        EventType.USER_DEFINE_OUTCOME,
        EventType.SYSTEM_MESSAGE,
    }
)

#: lane(thread)을 소비하는 실행 단위가 **아닌** 이벤트.
#: 이것들은 outbox에 execution을 만들지 않는다 (`plan/02` §6).
NOT_EXECUTION_UNIT: frozenset[EventType] = frozenset(
    {EventType.USER_INTERRUPT, EventType.SYSTEM_MESSAGE}
)

#: `derive_messages()`가 모델 히스토리에서 **제외**하는 이벤트.
#: 실패 시도와 관측 스팬은 모델이 본 적 없다.
NOT_MODEL_VISIBLE: frozenset[EventType] = frozenset(
    {
        EventType.AGENT_MESSAGE_ATTEMPT,
        EventType.AGENT_THINKING,
        EventType.SESSION_STATUS_RUNNING,
        EventType.SESSION_STATUS_IDLE,
        EventType.SESSION_STATUS_RESCHEDULED,
        EventType.SESSION_STATUS_TERMINATED,
        EventType.SESSION_DELETED,
        EventType.SESSION_UPDATED,
        EventType.SESSION_ERROR,
        EventType.SESSION_USAGE,
        EventType.SESSION_THREAD_CREATED,
        EventType.SESSION_THREAD_STATUS_RUNNING,
        EventType.SESSION_THREAD_STATUS_IDLE,
        EventType.SESSION_THREAD_STATUS_RESCHEDULED,
        EventType.SESSION_THREAD_STATUS_TERMINATED,
        EventType.SPAN_MODEL_REQUEST_START,
        EventType.SPAN_MODEL_REQUEST_END,
        EventType.SPAN_OUTCOME_EVALUATION_START,
        EventType.SPAN_OUTCOME_EVALUATION_ONGOING,
        EventType.SPAN_OUTCOME_EVALUATION_END,
        EventType.WORKFLOW_RUN_CREATED,
        EventType.WORKFLOW_RUN_STATUS_RUNNING,
        EventType.WORKFLOW_RUN_STATUS_IDLE,
        EventType.WORKFLOW_RUN_STATUS_ENDED,
        EventType.WORKFLOW_RUN_ERROR,
        EventType.WORKFLOW_RUN_PHASE_STARTED,
        EventType.WORKFLOW_RUN_PHASE_ENDED,
    }
)

PRIMARY_THREAD: ThreadId = ThreadId("primary")


@dataclass(frozen=True, slots=True)
class SessionEvent:
    """정본 이벤트.

    `payload`는 직렬화된 JSON 문자열이 아니라 **불변 매핑의 튜플**이다 — 도메인은
    JSON을 모르고, 직렬화는 `ma_api`와 `ma_store_sql`의 일이다.
    """

    id: EventId
    workspace_id: WorkspaceId
    session_id: SessionId
    thread_id: ThreadId
    type: EventType
    payload: tuple[tuple[str, object], ...]
    created_at: datetime
    #: promote 시점에 부여된다. pending 상태에서는 None.
    seq: int | None = None
    #: 어느 fence generation에서 커밋됐는가 (감사용).
    generation: int | None = None

    def __post_init__(self) -> None:
        if self.seq is not None and self.seq < 0:
            raise InvariantViolation("seq는 음수일 수 없다")

    @property
    def is_promoted(self) -> bool:
        return self.seq is not None

    @property
    def is_model_visible(self) -> bool:
        return self.type not in NOT_MODEL_VISIBLE

    @property
    def is_execution_unit(self) -> bool:
        return self.type not in NOT_EXECUTION_UNIT

    def get(self, key: str) -> object | None:
        for k, v in self.payload:
            if k == key:
                return v
        return None


@dataclass(frozen=True, slots=True)
class PendingEvent:
    """아직 모델이 보지 않은 입력. `session_pending_events`의 한 행.

    promote되면 `SessionEvent`가 되고 그때 `seq`를 받는다.
    """

    id: EventId
    workspace_id: WorkspaceId
    session_id: SessionId
    thread_id: ThreadId
    type: EventType
    payload: tuple[tuple[str, object], ...]
    enqueued_at: datetime
    pending_seq: int
    cancelled_at: datetime | None = None

    @property
    def is_cancelled(self) -> bool:
        return self.cancelled_at is not None

    def promote(self, *, seq: int, generation: int, at: datetime) -> SessionEvent:
        if self.is_cancelled:
            raise InvariantViolation("취소된 pending을 promote할 수 없다")
        return SessionEvent(
            id=self.id,
            workspace_id=self.workspace_id,
            session_id=self.session_id,
            thread_id=self.thread_id,
            type=self.type,
            payload=self.payload,
            created_at=at,
            seq=seq,
            generation=generation,
        )


@dataclass(frozen=True, slots=True)
class ToolUse:
    """`agent.tool_use` payload의 타입 있는 뷰."""

    tool_call_id: ToolCallId
    tool_name: str
    input_summary: tuple[tuple[str, object], ...] = ()
