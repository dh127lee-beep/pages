"""실행 권한 — outbox · lease · fence (D3).

`plan/02-architecture.md` §3.

**권한의 증거는 fence다.** `(generation, attempt_id, expires_at)` 세 쌍.
워커는 "claim한 lane의 host"일 뿐이고, 권한은 DB에 있다.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta
from enum import StrEnum
from uuid import UUID

from ma_domain.errors import DomainError, InvariantViolation
from ma_domain.ids import EventId, ExecutionId, SessionId, ThreadId, WorkerId, WorkspaceId

#: 기본 lease TTL. PostgreSQL failover(~30s)보다 **길어야 한다**.
DEFAULT_LEASE_TTL = timedelta(seconds=90)
#: 하트비트 주기. TTL의 1/3.
DEFAULT_HEARTBEAT = timedelta(seconds=30)


class ExecutionState(StrEnum):
    QUEUED = "queued"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"

    @property
    def is_settled(self) -> bool:
        return self in (
            ExecutionState.COMPLETED,
            ExecutionState.FAILED,
            ExecutionState.CANCELLED,
        )


class ExecutionFenceLost(DomainError):
    """소유권이 넘어갔다. 이 워커는 아무것도 커밋할 수 없다.

    좀비 워커(느리게 죽는 프로세스)가 자기 결과를 쓰는 것을 막는 마지막 방어선이다.
    """

    def __init__(self, *, expected: int, actual: int) -> None:
        super().__init__(f"fence generation 불일치: 보유 {expected}, 현재 {actual}")
        self.expected = expected
        self.actual = actual


@dataclass(frozen=True, slots=True)
class ExecutionScope:
    """FIFO 단위. `lane_id`는 `thread_id`와 같다."""

    workspace_id: WorkspaceId
    session_id: SessionId
    lane_id: ThreadId

    @property
    def key(self) -> str:
        return f"{self.workspace_id}:{self.session_id}:{self.lane_id}"


@dataclass(frozen=True, slots=True)
class ExecutionFence:
    """claim이 돌려주는 권한 증거.

    이벤트 append·메모리 동기화·샌드박스 호출 **전에** `assert_current()`로 검증한다.
    """

    scope: ExecutionScope
    generation: int
    attempt_id: UUID
    owner: WorkerId
    expires_at: datetime

    def __post_init__(self) -> None:
        if self.generation < 1:
            raise InvariantViolation("generation은 1부터 시작한다")

    def assert_current(self, db_generation: int) -> None:
        """DB의 현재 generation과 같은지 확인한다. 다르면 `ExecutionFenceLost`."""
        if db_generation != self.generation:
            raise ExecutionFenceLost(expected=self.generation, actual=db_generation)

    def is_expired(self, now: datetime) -> bool:
        return now >= self.expires_at


@dataclass(frozen=True, slots=True)
class ExecutionRecord:
    """`session_executions`의 한 행."""

    id: int
    scope: ExecutionScope
    execution_id: ExecutionId
    state: ExecutionState
    event_ids: tuple[EventId, ...]
    generation: int
    created_at: datetime
    attempt_id: UUID | None = None
    attempt_count: int = 0
    lease_owner: WorkerId | None = None
    lease_expires_at: datetime | None = None
    interrupt_requested_at: datetime | None = None
    deadline_at: datetime | None = None
    error: tuple[tuple[str, object], ...] | None = None
    settled_at: datetime | None = None
    #: W3C `traceparent` 등. **제어 평면과 워커를 잇는 유일한 길이다**
    #: (워커는 요청을 받지 않고 큐를 긁어 간다). 비면 워커가 새 trace 를
    #: 시작한다 — 끊긴 것을 억지로 잇지 않는다.
    trace_context: tuple[tuple[str, str], ...] = ()

    def __post_init__(self) -> None:
        if self.state is ExecutionState.RUNNING and self.lease_owner is None:
            raise InvariantViolation("running execution에 lease_owner가 없다")
        if self.state.is_settled and self.settled_at is None:
            raise InvariantViolation("settled execution에 settled_at이 없다")
        if not self.event_ids:
            raise InvariantViolation("execution에 이벤트가 하나도 없다")

    @property
    def is_interrupted(self) -> bool:
        return self.interrupt_requested_at is not None

    def is_reclaimable(self, now: datetime) -> bool:
        """lease가 만료되어 다른 워커가 가져갈 수 있는가."""
        if self.state is ExecutionState.QUEUED:
            return True
        if self.state is not ExecutionState.RUNNING:
            return False
        return self.lease_expires_at is None or now >= self.lease_expires_at


@dataclass(frozen=True, slots=True)
class WorkerInstance:
    """`worker_instances`의 한 행. drain 상태를 들고 있다."""

    id: WorkerId
    kind: str
    version: str
    started_at: datetime
    heartbeat_at: datetime
    draining: bool = False
