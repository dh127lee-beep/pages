"""AWP 도메인 타입 — 외부 의존성 0.

`plan/03-layers.md` §3 L1.

여기 있는 것: `frozen=True, slots=True` dataclass · Enum · 값 객체 · 불변식 검사.
여기 **없는** 것: 직렬화 · DB · HTTP · 네트워크 · `datetime.now()`.

시간과 ID 생성은 `clock.Clock` · `clock.IdGenerator`로 주입받는다.
`tools/check_architecture.py`가 이 규칙을 검사한다.
"""

from ma_domain import (
    agents,
    clock,
    environments,
    errors,
    events,
    executions,
    governance,
    ids,
    memory,
    models,
    sessions,
    vaults,
    workspaces,
)

__all__ = [
    "agents",
    "clock",
    "environments",
    "errors",
    "events",
    "executions",
    "governance",
    "ids",
    "memory",
    "models",
    "sessions",
    "vaults",
    "workspaces",
]
