"""파일 · 산출물 · 스냅샷 유스케이스 (G8).

`plan/04-api.md` §3.4 · §3.8 · `plan/08-infrastructure.md` §6 ·
`task/M4-productization/T-0502-files-outputs.md`.

**행과 객체를 둘 다 만지는 유일한 레이어다.** Store 는 행만, `BlobPort`
는 객체만 안다. 둘의 순서를 정하는 것이 여기 있는 이유다:

```
업로드                              삭제
──────                             ────
① 행 (uploaded_at NULL)            ① 행 soft delete
② blob.put                         ② blob.delete
③ mark_uploaded                    (②에서 죽으면 고아 객체 → 청소 잡)
```

**업로드는 행이 먼저, 삭제는 행이 먼저.** 둘 다 "DB 가 알고 있는 상태"
쪽으로 치우친다 — DB 에 흔적이 있으면 나중에 찾아서 치울 수 있지만,
객체만 남으면 그것이 무엇이었는지 알 방법이 없다.

**다운로드는 서명 URL 이다.** 제어 평면이 바이트를 중계하면 대용량에서
막힌다. `BlobPort.signed_url` 이 `BlobUnsupported` 를 던지면 그대로
위로 올린다 — 중계로 대체하지 않는다.
"""

from __future__ import annotations

import hashlib
from collections.abc import Mapping
from dataclasses import dataclass, field
from datetime import timedelta
from typing import TYPE_CHECKING

from ma_domain.errors import InvariantViolation
from ma_domain.files import (
    MAX_FILE_BYTES,
    FileMeta,
    SessionOutput,
    WorkspaceSnapshot,
    output_key,
    safe_name,
    snapshot_key,
    upload_key,
    validate_upload,
)
from ma_domain.ids import FileId
from ma_governance.quota import QuotaKind
from ma_store._results import ListQuery

if TYPE_CHECKING:
    from ma_domain.clock import Clock, IdGenerator
    from ma_domain.ids import SessionId, WorkspaceId
    from ma_store._results import Cursor, Page
    from ma_store.files import FileStore, SessionOutputStore, SnapshotStore

    from ma_application.blob import BlobPort

#: 스냅샷 보존. `plan/08` §6 — 7일.
SNAPSHOT_RETENTION = timedelta(days=7)

#: 기본 content-type. 브라우저가 추측하지 못하게 **실행 가능한 타입을
#: 주지 않는다** — `text/html` 이면 저장된 파일이 같은 오리진에서 돈다.
DEFAULT_CONTENT_TYPE = "application/octet-stream"


# ── 결과 ─────────────────────────────────────────────────
@dataclass(frozen=True, slots=True)
class FileUploaded:
    file: FileMeta


@dataclass(frozen=True, slots=True)
class FileInvalid:
    reasons: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class FileTooLarge:
    """**쿼터 위반이지 잘못된 요청이 아니다** → 409.

    `ma_governance.quota` 와 같은 자리다: "재시도해도 안 되는 것"이고,
    고치려면 파일을 줄이거나 워크스페이스 상한을 올려야 한다.
    """

    size_bytes: int
    limit: int


@dataclass(frozen=True, slots=True)
class QuotaExceeded:
    """일일 업로드 상한 (수 또는 바이트). **날이 바뀌어야 풀린다** → 409."""

    kind: str
    used: int
    limit: int


@dataclass(frozen=True, slots=True)
class FileMissing:
    file_id: FileId


@dataclass(frozen=True, slots=True)
class UploadFailed:
    """행은 만들었는데 **바이트가 안 올라갔다.**

    행 id 를 돌려준다 — 클라이언트가 재시도할 수 있고, 청소 잡이
    미완성 행을 찾을 때 이 id 가 로그에 있다.
    """

    file_id: FileId
    reason: str


type UploadResult = FileUploaded | FileInvalid | FileTooLarge | QuotaExceeded | UploadFailed


@dataclass(frozen=True, slots=True)
class DownloadRedirect:
    url: str


@dataclass(frozen=True, slots=True)
class DownloadUnavailable:
    """서명 URL 을 못 만든다 (개발 백엔드). **바이트로 대체하지 않는다.**"""

    reason: str


type DownloadResult = DownloadRedirect | DownloadUnavailable | FileMissing


@dataclass(frozen=True, slots=True)
class SnapshotSaved:
    snapshot: WorkspaceSnapshot


@dataclass(frozen=True, slots=True)
class SnapshotRefused:
    """**같은 세대가 이미 있다** — 좀비 워커일 수 있다 (D3)."""

    generation: int


type SaveSnapshotResult = SnapshotSaved | SnapshotRefused


# ── 입력 ─────────────────────────────────────────────────
@dataclass(frozen=True, slots=True)
class UploadFile:
    workspace_id: WorkspaceId
    filename: str
    content: bytes
    created_by: str
    content_type: str = DEFAULT_CONTENT_TYPE


@dataclass(frozen=True, slots=True)
class RecordOutput:
    workspace_id: WorkspaceId
    session_id: SessionId
    path: str
    content: bytes
    generation: int
    content_type: str = DEFAULT_CONTENT_TYPE


@dataclass(frozen=True, slots=True)
class SaveSnapshot:
    workspace_id: WorkspaceId
    session_id: SessionId
    generation: int
    archive: bytes


# ── 유스케이스 ───────────────────────────────────────────
@dataclass
class FilesUseCases:
    files: FileStore
    outputs: SessionOutputStore
    snapshots: SnapshotStore
    blob: BlobPort
    clock: Clock
    ids: IdGenerator
    retention: timedelta = SNAPSHOT_RETENTION
    #: 워크스페이스별 상한. 비면 `ma_governance.quota.DEFAULT_LIMITS`.
    quota_limits: Mapping[QuotaKind, int] = field(default_factory=dict)

    # 업로드 ----------------------------------------------
    async def upload(self, cmd: UploadFile) -> UploadResult:
        """`plan/08` §6 의 `files/<ws>/<file_id>` 로 올린다."""
        from ma_store.files import InsertFile

        size = len(cmd.content)
        # **크기를 먼저 본다.** `validate_upload` 가 이름과 크기를 같이
        # 보지만, 둘은 다른 HTTP 상태다 — 이름은 400, 크기는 409.
        if size > MAX_FILE_BYTES:
            return FileTooLarge(size_bytes=size, limit=MAX_FILE_BYTES)
        try:
            validate_upload(cmd.filename, size)
        except InvariantViolation as exc:
            return FileInvalid(reasons=(str(exc),))

        quota = await self._check_quota(cmd.workspace_id, size)
        if quota is not None:
            return quota

        file_id = FileId(self.ids.next("file"))
        key = upload_key(cmd.workspace_id, file_id)
        row = await self.files.insert(
            InsertFile(
                id=file_id,
                workspace_id=cmd.workspace_id,
                # **원본 이름을 버리지 않는다.** 다운로드 헤더에 되돌린다.
                filename=cmd.filename,
                safe_name=safe_name(cmd.filename),
                content_type=cmd.content_type,
                size_bytes=len(cmd.content),
                sha256=hashlib.sha256(cmd.content).hexdigest(),
                storage_key=key,
                created_by=cmd.created_by,
                now=self.clock.now(),
            )
        )

        try:
            await self.blob.put(key, cmd.content, content_type=cmd.content_type)
        except Exception as exc:
            # **행을 지우지 않는다.** 객체가 부분적으로 올라갔을 수 있고,
            # 행이 남아 있어야 청소 잡이 그 키를 안다.
            return UploadFailed(file_id=row.id, reason=f"{type(exc).__name__}: {exc}")

        done = await self.files.mark_uploaded(cmd.workspace_id, row.id, self.clock.now())
        if done is None:  # pragma: no cover — 업로드 중에 지워졌다
            return UploadFailed(file_id=row.id, reason="업로드 중에 파일이 삭제됐다")
        return FileUploaded(file=done)

    async def _check_quota(self, workspace_id: WorkspaceId, size: int) -> QuotaExceeded | None:
        """일일 업로드 쿼터. **개수와 바이트를 둘 다 본다.**

        개수만 막으면 100MB 짜리로, 바이트만 막으면 작은 파일 수십만
        개로 빠져나간다.

        카운터를 `quota_counters` 가 아니라 `files` 에서 센다 — 두 벌의
        진실을 만들지 않기 위해서다. 집계 비용은 `idx_files_created` 가
        감당한다.
        """
        from ma_governance.quota import QuotaKind, check

        now = self.clock.now()
        midnight = now.replace(hour=0, minute=0, second=0, microsecond=0)
        count, total = await self.files.usage_since(workspace_id, midnight)

        for kind, used, increment in (
            (QuotaKind.DAILY_UPLOAD_COUNT, count, 1),
            (QuotaKind.DAILY_UPLOAD_BYTES, total, size),
        ):
            limit = self.quota_limits.get(kind)
            got = check(kind, used=used, limit=limit, increment=increment)
            if not got.ok:
                return QuotaExceeded(kind=kind.value, used=got.used, limit=got.limit)
        return None

    async def find(self, workspace_id: WorkspaceId, file_id: FileId) -> FileMeta | None:
        return await self.files.find(workspace_id, file_id)

    async def list_files(
        self, workspace_id: WorkspaceId, *, limit: int = 50, after: Cursor | None = None
    ) -> Page[FileMeta]:
        return await self.files.list_files(
            ListQuery(workspace_id=workspace_id, limit=limit, after=after)
        )

    async def download_url(self, workspace_id: WorkspaceId, file_id: FileId) -> DownloadResult:
        from ma_application.blob import BlobUnsupported

        got = await self.files.find(workspace_id, file_id)
        if got is None or not got.is_complete:
            # **미완성도 404 다.** 바이트가 없는 파일을 200 으로 내보내면
            # 클라이언트가 빈 파일을 받고 "손상됐다"고 읽는다.
            return FileMissing(file_id=file_id)
        try:
            url = await self.blob.signed_url(got.storage_key)
        except BlobUnsupported as exc:
            return DownloadUnavailable(reason=str(exc))
        return DownloadRedirect(url=url)

    async def delete(self, workspace_id: WorkspaceId, file_id: FileId) -> bool:
        """**행을 먼저 지운다.** 객체 삭제가 실패해도 보이지 않는다.

        반대로 하면 객체는 없는데 행이 남아 "있다고 하는데 못 받는"
        상태가 된다.
        """
        got = await self.files.find(workspace_id, file_id)
        if got is None:
            return False
        if not await self.files.delete(workspace_id, file_id, self.clock.now()):
            return False  # pragma: no cover — 방금 찾았다
        await self.blob.delete(got.storage_key)
        return True

    # 산출물 ----------------------------------------------
    async def record_output(self, cmd: RecordOutput) -> SessionOutput:
        """세션이 만든 것을 수거한다. **세대를 함께 남긴다** (D3)."""
        from ma_store.files import InsertOutput

        key = output_key(cmd.workspace_id, cmd.session_id, cmd.path)
        # 같은 경로를 여러 턴이 내면 키가 겹친다 — **세대를 섞는다.**
        key = f"{key}.g{cmd.generation}"
        await self.blob.put(key, cmd.content, content_type=cmd.content_type)
        return await self.outputs.insert(
            InsertOutput(
                id=self.ids.next("file"),
                workspace_id=cmd.workspace_id,
                session_id=cmd.session_id,
                path=cmd.path,
                content_type=cmd.content_type,
                size_bytes=len(cmd.content),
                sha256=hashlib.sha256(cmd.content).hexdigest(),
                storage_key=key,
                generation=cmd.generation,
                now=self.clock.now(),
            )
        )

    async def list_outputs(
        self,
        workspace_id: WorkspaceId,
        session_id: SessionId,
        *,
        limit: int = 50,
        after: Cursor | None = None,
    ) -> Page[SessionOutput]:
        return await self.outputs.list_for_session(
            ListQuery(workspace_id=workspace_id, limit=limit, after=after), session_id
        )

    async def output_url(self, workspace_id: WorkspaceId, output_id: str) -> DownloadResult:
        from ma_application.blob import BlobUnsupported

        got = await self.outputs.find(workspace_id, output_id)
        if got is None:
            return FileMissing(file_id=FileId(output_id))
        try:
            url = await self.blob.signed_url(got.storage_key)
        except BlobUnsupported as exc:
            return DownloadUnavailable(reason=str(exc))
        return DownloadRedirect(url=url)

    # 스냅샷 ----------------------------------------------
    async def save_snapshot(self, cmd: SaveSnapshot) -> SaveSnapshotResult:
        """**행을 먼저 만든다.** 세대 충돌을 객체를 올리기 전에 잡는다.

        순서를 뒤집으면 좀비 워커가 객체를 덮은 뒤에야 거부되고, 그때는
        이미 새 소유자의 스냅샷이 사라졌다.
        """
        from ma_store.files import InsertSnapshot, SnapshotExists

        key = snapshot_key(cmd.workspace_id, cmd.session_id, cmd.generation)
        now = self.clock.now()
        made = await self.snapshots.insert(
            InsertSnapshot(
                id=self.ids.next("file"),
                workspace_id=cmd.workspace_id,
                session_id=cmd.session_id,
                generation=cmd.generation,
                size_bytes=len(cmd.archive),
                sha256=hashlib.sha256(cmd.archive).hexdigest(),
                storage_key=key,
                now=now,
                expires_at=now + self.retention,
            )
        )
        if isinstance(made, SnapshotExists):
            return SnapshotRefused(generation=made.generation)

        await self.blob.put(key, cmd.archive, content_type="application/zstd")
        return SnapshotSaved(snapshot=made)

    async def restore_snapshot(
        self, workspace_id: WorkspaceId, session_id: SessionId
    ) -> bytes | None:
        """가장 **높은 세대**를 되돌린다. 없으면 `None`."""
        from ma_application.blob import BlobNotFound

        got = await self.snapshots.latest(workspace_id, session_id)
        if got is None:
            return None
        try:
            return await self.blob.get(got.storage_key)
        except BlobNotFound:
            # 행은 있는데 객체가 없다 — 보존 기간이 지나 청소됐을 수 있다.
            return None

    async def purge_expired(self, workspace_id: WorkspaceId, *, limit: int = 100) -> int:
        """만료 스냅샷 청소. **행을 먼저, 객체를 나중.**

        반대로 하면 객체는 지웠는데 행이 남아 `restore_snapshot` 이
        "있다"고 말하고 `BlobNotFound` 로 떨어진다.
        """
        now = self.clock.now()
        expired = await self.snapshots.list_expired(workspace_id, now, limit)
        purged = 0
        for snapshot in expired:
            if await self.snapshots.delete(workspace_id, snapshot.id, now):
                await self.blob.delete(snapshot.storage_key)
                purged += 1
        return purged


__all__ = [
    "DEFAULT_CONTENT_TYPE",
    "SNAPSHOT_RETENTION",
    "DownloadRedirect",
    "DownloadResult",
    "DownloadUnavailable",
    "FileInvalid",
    "FileMissing",
    "FileTooLarge",
    "FileUploaded",
    "FilesUseCases",
    "QuotaExceeded",
    "RecordOutput",
    "SaveSnapshot",
    "SaveSnapshotResult",
    "SnapshotRefused",
    "SnapshotSaved",
    "UploadFailed",
    "UploadFile",
    "UploadResult",
]
