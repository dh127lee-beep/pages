"""MCP OAuth 갱신 유스케이스 (T-0601).

`plan/07-sandbox.md` §6 · `ADR-0009`.

> **갱신은 제어 평면에서만 일어난다.** 루트 시크릿이 거기에만 있고
> (D5), 갱신 토큰은 access token 보다 센 권한이다 — 그것으로 토큰을
> **새로 만들 수 있다.**

워커는 401 을 만나면 이 유스케이스를 **HTTP 로** 부른다
(`POST /api/v1/vaults/{vault}/credentials/{cred}/mcp-oauth/validate`).
워커가 갱신 토큰을 보지 않는 것이 요점이다.

`Refresher` 와 그 결과 타입이 **여기(L4)에 있는 이유**: `ma_connectors`
는 L5 다 (`plan/03` §2). 유스케이스가 커넥터를 import 하면 의존이 위로
흐른다. 그래서 계약은 아래에 두고 구현이 내려와 맞춘다.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Protocol

from ma_domain.vaults import CredentialAction, CredentialKind, OAuthTokens

if TYPE_CHECKING:
    from datetime import datetime

    from ma_domain.clock import Clock
    from ma_domain.ids import CredentialId, SessionId, VaultId, WorkspaceId
    from ma_domain.vaults import CredentialMeta
    from ma_store.credentials import CredentialStore


# ── 갱신 계약 (구현은 L5) ────────────────────────────────
@dataclass(frozen=True, slots=True)
class Refreshed:
    tokens: OAuthTokens
    expires_at: datetime | None = None

    def __repr__(self) -> str:
        # 기본 `repr` 이 토큰을 출력한다 — 예외 추적이 지역 변수를
        # 찍으면 거기 실린다.
        return f"Refreshed(expires_at={self.expires_at!r}, tokens=<가림>)"


@dataclass(frozen=True, slots=True)
class RefreshFailed:
    """갱신이 안 됐다. **사유가 남아야 사람이 고친다.**"""

    reason: str
    #: `True` 면 다시 시도해도 같다 — 사람이 재연결해야 한다.
    permanent: bool = False


type RefreshOutcome = Refreshed | RefreshFailed


class Refresher(Protocol):
    """갱신 토큰 → 새 토큰. 구현은 `ma_connectors.mcp.OAuthRefresher`."""

    async def refresh(self, tokens: OAuthTokens, now: datetime) -> RefreshOutcome: ...


# ── 결과 ─────────────────────────────────────────────────
@dataclass(frozen=True, slots=True)
class StillValid:
    """갱신이 필요 없었다. **호출자는 그냥 다시 시도하면 된다.**"""

    credential: CredentialMeta


@dataclass(frozen=True, slots=True)
class RefreshSucceeded:
    credential: CredentialMeta


@dataclass(frozen=True, slots=True)
class RefreshRejected:
    """갱신이 안 됐다. `permanent` 면 **사람이 재연결해야 한다.**"""

    credential_id: CredentialId
    reason: str
    permanent: bool = False


@dataclass(frozen=True, slots=True)
class CredentialNotOauth:
    """`mcp_oauth` 가 아니다. 갱신할 것이 없다."""

    credential_id: CredentialId


@dataclass(frozen=True, slots=True)
class CredentialGone:
    """없거나 범위 밖이다. **둘을 구분하지 않는다** — 존재를 누설하지 않는다.

    `credential_id` 가 `str` 인 이유: 서버 이름으로 찾았는데 없을 때는
    자격증명 id 자체가 없다. 그때 가짜 id 를 지어내면 로그에서
    실재하는 것처럼 보인다.
    """

    credential_id: str


type ValidateResult = (
    StillValid | RefreshSucceeded | RefreshRejected | CredentialNotOauth | CredentialGone
)


@dataclass(frozen=True, slots=True)
class ValidateOauth:
    workspace_id: WorkspaceId
    vault_id: VaultId
    credential_id: CredentialId
    #: `True` 면 만료 전이어도 갱신한다. 워커가 401 을 받았을 때 쓴다 —
    #: **서버가 먼저 거절했으면 우리 만료 시각이 틀린 것이다.**
    force: bool = False
    session_id: SessionId | None = None


@dataclass
class McpUseCases:
    credentials: CredentialStore
    refresher: Refresher
    clock: Clock

    async def validate_oauth(self, cmd: ValidateOauth) -> ValidateResult:
        """자격증명이 아직 쓸 수 있는지 보고, 아니면 갱신한다.

        `force=False` 면 **만료 전에는 아무것도 하지 않는다.** 매 호출마다
        갱신하면 토큰 엔드포인트가 레이트 리밋을 건다.
        """
        from ma_store.credentials import RecordCredentialEvent, RecordRefresh, RevealOAuth

        now = self.clock.now()
        meta = await self.credentials.find(cmd.workspace_id, cmd.credential_id)
        if meta is None or meta.archived_at is not None:
            return CredentialGone(credential_id=cmd.credential_id)
        if meta.vault_id != cmd.vault_id:
            # **볼트가 다르면 없는 것과 같다.** 경로의 볼트를 무시하면
            # 볼트 범위로 준 권한이 새어 나간다.
            return CredentialGone(credential_id=cmd.credential_id)
        if meta.kind is not CredentialKind.MCP_OAUTH:
            return CredentialNotOauth(credential_id=cmd.credential_id)
        if not cmd.force and not meta.needs_refresh(now):
            return StillValid(credential=meta)

        tokens = await self.credentials.reveal_oauth(
            RevealOAuth(workspace_id=cmd.workspace_id, id=cmd.credential_id)
        )
        if tokens is None:  # pragma: no cover — 바로 위에서 확인했다
            return CredentialGone(credential_id=cmd.credential_id)

        got = await self.refresher.refresh(tokens, now)

        if isinstance(got, RefreshFailed):
            # **실패를 기록한다.** 안 적으면 "MCP 가 안 된다"는 문의에
            # 답할 자료가 없다 — 토큰이 죽은 것인지 서버가 죽은 것인지.
            await self.credentials.record_refresh(
                RecordRefresh(
                    workspace_id=cmd.workspace_id,
                    id=cmd.credential_id,
                    now=now,
                    tokens=None,
                    error=got.reason,
                )
            )
            await self.credentials.record_event(
                RecordCredentialEvent(
                    workspace_id=cmd.workspace_id,
                    credential_id=cmd.credential_id,
                    action=CredentialAction.REFRESH_FAILED,
                    now=now,
                    session_id=cmd.session_id,
                )
            )
            return RefreshRejected(
                credential_id=cmd.credential_id, reason=got.reason, permanent=got.permanent
            )

        updated = await self.credentials.record_refresh(
            RecordRefresh(
                workspace_id=cmd.workspace_id,
                id=cmd.credential_id,
                now=now,
                tokens=got.tokens,
                expires_at=got.expires_at,
            )
        )
        if updated is None:  # pragma: no cover — 경합으로 그 사이 아카이브됐다
            return CredentialGone(credential_id=cmd.credential_id)
        await self.credentials.record_event(
            RecordCredentialEvent(
                workspace_id=cmd.workspace_id,
                credential_id=cmd.credential_id,
                action=CredentialAction.REFRESHED,
                now=now,
                session_id=cmd.session_id,
            )
        )
        return RefreshSucceeded(credential=updated)

    async def validate_for_server(
        self,
        workspace_id: WorkspaceId,
        server_name: str,
        vault_ids: tuple[VaultId, ...],
        *,
        force: bool = True,
        session_id: SessionId | None = None,
    ) -> ValidateResult:
        """**서버 이름으로** 자격증명을 찾아 갱신한다.

        워커가 쓰는 길이다. 워커는 **서버 이름만** 안다
        (`mcp__github__*` 의 `github`) — 자격증명 id 를 알 이유가
        없고, 알면 그것으로 할 수 있는 일이 늘어난다. 워커 DB 역할은
        `credentials` 를 아예 못 읽는다 (`plan/05` §7).

        **세션의 볼트 범위 안에서만** 찾는다. 세션이 쓸 수 없는 볼트의
        자격증명을 갱신해 주면 볼트 범위가 장식이 된다.
        """
        meta = await self.find_for_server(workspace_id, server_name, vault_ids)
        if meta is None:
            return CredentialGone(credential_id=f"mcp_oauth:{server_name}")
        return await self.validate_oauth(
            ValidateOauth(
                workspace_id=workspace_id,
                vault_id=meta.vault_id,
                credential_id=meta.id,
                force=force,
                session_id=session_id,
            )
        )

    async def find_for_server(
        self, workspace_id: WorkspaceId, server_name: str, vault_ids: tuple[VaultId, ...]
    ) -> CredentialMeta | None:
        """서버 이름 → `mcp_oauth` 자격증명. **볼트 범위 안에서만.**

        여러 볼트에 같은 서버 이름이 있으면 **첫 볼트의 것**을 쓴다.
        세션의 `vault_ids` 순서가 우선순위다 — 그쪽이 명시적이다.
        """
        from ma_store._results import ListQuery

        for vault_id in vault_ids:
            page = await self.credentials.list_in_vault(
                ListQuery(workspace_id=workspace_id, limit=200), vault_id
            )
            for meta in page.items:
                if (
                    meta.kind is CredentialKind.MCP_OAUTH
                    and meta.mcp_server_name == server_name
                    and meta.archived_at is None
                ):
                    return meta
        return None


__all__ = [
    "CredentialGone",
    "CredentialNotOauth",
    "McpUseCases",
    "RefreshFailed",
    "RefreshOutcome",
    "RefreshRejected",
    "RefreshSucceeded",
    "Refreshed",
    "Refresher",
    "StillValid",
    "ValidateOauth",
    "ValidateResult",
]
