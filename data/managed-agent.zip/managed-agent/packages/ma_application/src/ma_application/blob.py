"""BlobPort — 오브젝트 스토어 창구.

`plan/08-infrastructure.md` §6 · `plan/03-layers.md` §2.

**L4 에 있는 이유**: `ma_api`(다운로드가 서명 URL 로 리다이렉트한다)와
`ma_adapters_blob`(S3 구현)은 같은 레이어라 서로 import 할 수 없다.
`RealtimePort` 와 같은 자리다.

**서명 URL 이 포트에 있다.** "제어 평면이 바이트를 중계하지 않는다"가
설계 결정이고 (`T-0502` 구현 지침), 그것을 포트가 강제한다 — 구현이
서명을 못 하면 거기서 드러나지 더 위에서 드러나지 않는다.

```
업로드                         다운로드
──────                        ────────
① files 행 (uploaded_at NULL)  ① 행 조회 (워크스페이스 경계)
② put(key, bytes)              ② signed_url(key)
③ uploaded_at 채움              ③ 302 리다이렉트
```

②에서 죽으면 미완성 행이 남는다. **그쪽이 낫다** — 주인 없는 객체보다
청소할 수 있다.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import timedelta
from typing import Protocol

#: 서명 URL 기본 수명. 짧게 잡는다 — 링크가 로그·채팅에 남는다.
#:
#: 5분인 이유: 브라우저가 302 를 따라가는 데 걸리는 시간은 1초 미만이고,
#: 사용자가 "다운로드" 를 누르고 실제로 받기까지의 지연(프록시·VPN)을
#: 넉넉히 덮으면서도 유출된 링크의 수명을 짧게 둔다.
DEFAULT_URL_TTL = timedelta(minutes=5)


class BlobNotFound(Exception):
    """키가 없다. **"권한 없음"과 구분하지 않는다** — 둘 다 404 다."""


class BlobUnsupported(Exception):
    """구현이 그 동작을 못 한다 (예: 서명 URL 을 못 만드는 로컬 백엔드).

    **조용히 대체하지 않는다.** 로컬 백엔드가 서명 대신 바이트를
    중계하기 시작하면 프로덕션에서도 그렇게 될 수 있고, 그것이 정확히
    막으려던 것이다.
    """


@dataclass(frozen=True, slots=True)
class BlobInfo:
    key: str
    size_bytes: int
    sha256: str


class BlobPort(Protocol):
    async def put(self, key: str, data: bytes, *, content_type: str) -> BlobInfo:
        """바이트를 올린다. 같은 키에 쓰면 **덮어쓴다.**"""
        ...

    async def get(self, key: str) -> bytes:
        """**테스트와 작은 객체 전용.** 다운로드 경로는 서명 URL 을 쓴다."""
        ...

    async def delete(self, key: str) -> bool:
        """없으면 `False`. 없다고 예외를 내지 않는다 — 삭제는 멱등해야 한다."""
        ...

    async def exists(self, key: str) -> bool: ...

    async def signed_url(self, key: str, *, ttl: timedelta = DEFAULT_URL_TTL) -> str:
        """다운로드용 임시 URL. 못 만들면 `BlobUnsupported`."""
        ...


__all__ = [
    "DEFAULT_URL_TTL",
    "BlobInfo",
    "BlobNotFound",
    "BlobPort",
    "BlobUnsupported",
]
