"""스킬 유스케이스 (T-0602).

`plan/01-product-concept.md` §4 · `plan/05-database.md` §3 G2.

여기 있는 것: slug 충돌 · 크기 검증 · 카탈로그 조립 · 결과 union.
여기 **없는** 것: 파일시스템 · GitHub 네트워크.

**GitHub 로더를 포트로 받는다.** 유스케이스가 `httpx` 를 들면 L4 가
드라이버를 아는 셈이고(`plan/03` §5.1), 스킬 테스트가 네트워크에
묶인다. 조립이 구현을 꽂는다.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Protocol

from ma_domain.errors import InvariantViolation
from ma_domain.ids import SkillId
from ma_domain.skills import (
    SkillCatalogEntry,
    SkillDocument,
    SkillFile,
    SkillRecord,
    SkillSource,
    catalog_text,
    validate_slug,
)
from ma_store._results import ListQuery

if TYPE_CHECKING:
    from ma_domain.clock import Clock, IdGenerator
    from ma_domain.ids import WorkspaceId
    from ma_store._results import Cursor, Page
    from ma_store.skills import SkillStore

#: 스킬 이름 상한.
MAX_NAME = 100


class SkillSourceLoader(Protocol):
    """GitHub 등에서 스킬 파일을 읽어 온다.

    **포트인 이유**: 네트워크를 L4 에 두지 않는다. 그리고 테스트가
    가짜 로더를 꽂아 "커밋이 박히는가"를 네트워크 없이 볼 수 있다.
    """

    async def load(self, source: SkillSource) -> SkillDocument: ...


# ── 결과 ─────────────────────────────────────────────────
@dataclass(frozen=True, slots=True)
class SkillCreated:
    skill: SkillRecord


@dataclass(frozen=True, slots=True)
class SkillUpdated:
    skill: SkillRecord


@dataclass(frozen=True, slots=True)
class SkillArchived:
    skill: SkillRecord


@dataclass(frozen=True, slots=True)
class SkillSlugTaken:
    """**마운트 경로가 겹친다** — 409 다."""

    slug: str


@dataclass(frozen=True, slots=True)
class SkillMissing:
    skill_id: SkillId


@dataclass(frozen=True, slots=True)
class SkillConflict:
    actual_version: int


@dataclass(frozen=True, slots=True)
class SkillInvalid:
    reasons: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class SourceUnavailable:
    """GitHub 에서 못 읽었다. **부분 저장을 만들지 않는다.**"""

    reason: str


type CreateSkillResult = SkillCreated | SkillSlugTaken | SkillInvalid | SourceUnavailable
type UpdateSkillResult = SkillUpdated | SkillMissing | SkillConflict | SkillInvalid | SkillSlugTaken
type ArchiveSkillResult = SkillArchived | SkillMissing | SkillConflict


# ── 입력 ─────────────────────────────────────────────────
@dataclass(frozen=True, slots=True)
class CreateSkill:
    workspace_id: WorkspaceId
    name: str
    slug: str
    description: str = ""
    files: tuple[tuple[str, str], ...] = ()
    #: 주면 **GitHub 에서 읽어 온다.** `files` 는 무시된다.
    source: SkillSource | None = None


@dataclass(frozen=True, slots=True)
class UpdateSkill:
    workspace_id: WorkspaceId
    skill_id: SkillId
    name: str
    slug: str
    description: str
    files: tuple[tuple[str, str], ...] = ()
    expected_version: int = 1
    source: SkillSource | None = None


# ── 유스케이스 ───────────────────────────────────────────
@dataclass
class SkillsUseCases:
    skills: SkillStore
    clock: Clock
    ids: IdGenerator
    #: GitHub 로더. 없으면 `source` 를 준 요청이 거부된다 — **조용히
    #: 빈 스킬을 만들지 않는다.**
    loader: SkillSourceLoader | None = None

    async def create(self, cmd: CreateSkill) -> CreateSkillResult:
        from ma_store.skills import InsertSkill, SlugTaken

        built = await self._document(cmd.description, cmd.files, cmd.source)
        if not isinstance(built, SkillDocument):
            return built

        invalid = self._check_name_and_slug(cmd.name, cmd.slug)
        if invalid is not None:
            return invalid

        made = await self.skills.insert(
            InsertSkill(
                id=SkillId(self.ids.next("skill")),
                workspace_id=cmd.workspace_id,
                name=cmd.name.strip(),
                slug=cmd.slug,
                document=built,
                now=self.clock.now(),
            )
        )
        if isinstance(made, SlugTaken):
            return SkillSlugTaken(slug=made.slug)
        return SkillCreated(skill=made)

    async def update(self, cmd: UpdateSkill) -> UpdateSkillResult:
        from ma_store._results import Replaced, VersionConflict
        from ma_store.skills import ReplaceSkill

        built = await self._document(cmd.description, cmd.files, cmd.source)
        if isinstance(built, SourceUnavailable):
            return SkillInvalid(reasons=(built.reason,))
        if not isinstance(built, SkillDocument):
            return built

        invalid = self._check_name_and_slug(cmd.name, cmd.slug)
        if invalid is not None:
            return invalid

        res = await self.skills.replace_current(
            ReplaceSkill(
                workspace_id=cmd.workspace_id,
                id=cmd.skill_id,
                name=cmd.name.strip(),
                slug=cmd.slug,
                document=built,
                expected_version=cmd.expected_version,
                now=self.clock.now(),
            )
        )
        if isinstance(res, Replaced):
            return SkillUpdated(skill=res.record)
        if isinstance(res, VersionConflict):
            return SkillConflict(actual_version=res.actual_version)
        # 남은 것은 `NotFound` 뿐이다 — 없거나 아카이브됐다.
        return SkillMissing(skill_id=cmd.skill_id)

    async def archive(
        self, workspace_id: WorkspaceId, skill_id: SkillId, *, expected_version: int
    ) -> ArchiveSkillResult:
        from ma_store._results import Archived, VersionConflict
        from ma_store.skills import ArchiveSkill

        res = await self.skills.archive(
            ArchiveSkill(
                workspace_id=workspace_id,
                id=skill_id,
                expected_version=expected_version,
                now=self.clock.now(),
            )
        )
        if isinstance(res, Archived):
            return SkillArchived(skill=res.record)
        if isinstance(res, VersionConflict):
            return SkillConflict(actual_version=res.actual_version)
        return SkillMissing(skill_id=skill_id)

    async def find(self, workspace_id: WorkspaceId, skill_id: SkillId) -> SkillRecord | None:
        from ma_store.skills import FindCurrentSkill

        return await self.skills.find_current(FindCurrentSkill(workspace_id, skill_id))

    async def find_version(
        self, workspace_id: WorkspaceId, skill_id: SkillId, version: int
    ) -> SkillRecord | None:
        from ma_store.skills import FindSkillVersion

        return await self.skills.find_version(FindSkillVersion(workspace_id, skill_id, version))

    async def list_skills(
        self, workspace_id: WorkspaceId, *, limit: int = 50, after: Cursor | None = None
    ) -> Page[SkillRecord]:
        return await self.skills.list_skills(
            ListQuery(workspace_id=workspace_id, limit=limit, after=after)
        )

    # ── 카탈로그 ─────────────────────────────────────────
    async def catalog(
        self, workspace_id: WorkspaceId, skill_ids: tuple[SkillId, ...]
    ) -> tuple[SkillCatalogEntry, ...]:
        """에이전트가 부착한 스킬들의 카탈로그 항목.

        **한 번에 읽는다** (`find_many`) — 하나씩이면 스킬 수만큼
        왕복이 생기고, 그것이 세션 웜업의 지연이 된다.
        """
        records = await self.skills.find_many(workspace_id, skill_ids)
        return tuple(
            SkillCatalogEntry(
                slug=r.slug,
                description=r.document.description,
                mount_path=r.mount_path,
                file_count=len(r.document.files),
            )
            for r in records
        )

    async def catalog_prompt(
        self, workspace_id: WorkspaceId, skill_ids: tuple[SkillId, ...]
    ) -> str:
        """프롬프트 접두사에 인라인될 문자열. **매 턴 같아야 한다.**"""
        return catalog_text(await self.catalog(workspace_id, skill_ids))

    # ── 내부 ─────────────────────────────────────────────
    async def _document(
        self,
        description: str,
        files: tuple[tuple[str, str], ...],
        source: SkillSource | None,
    ) -> SkillDocument | SkillInvalid | SourceUnavailable:
        if source is not None:
            if self.loader is None:
                # **조용히 빈 스킬을 만들지 않는다.** 로더가 없는데
                # `source` 를 받으면 사용자는 로드됐다고 믿는다.
                return SourceUnavailable(reason="GitHub 로더가 설정되지 않았다")
            try:
                return await self.loader.load(source)
            except Exception as exc:
                return SourceUnavailable(reason=f"{type(exc).__name__}: {exc}")
        try:
            return SkillDocument(
                description=description,
                files=tuple(SkillFile(path=p, content=c) for p, c in files),
            )
        except InvariantViolation as exc:
            return SkillInvalid(reasons=(str(exc),))

    def _check_name_and_slug(self, name: str, slug: str) -> SkillInvalid | None:
        if not name.strip() or len(name) > MAX_NAME:
            return SkillInvalid(reasons=(f"이름은 1~{MAX_NAME}자다",))
        try:
            validate_slug(slug)
        except InvariantViolation as exc:
            return SkillInvalid(reasons=(str(exc),))
        return None


__all__ = [
    "MAX_NAME",
    "ArchiveSkillResult",
    "CreateSkill",
    "CreateSkillResult",
    "SkillArchived",
    "SkillConflict",
    "SkillCreated",
    "SkillInvalid",
    "SkillMissing",
    "SkillSlugTaken",
    "SkillSourceLoader",
    "SkillUpdated",
    "SkillsUseCases",
    "SourceUnavailable",
    "UpdateSkill",
    "UpdateSkillResult",
]
