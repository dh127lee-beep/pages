"""RealtimePort — "이 세션에 새 이벤트가 있다"를 전하는 창구.

`plan/04-api.md` §5 · `plan/03-layers.md` §2.

**L4 에 있는 이유**: `ma_api`(SSE 가 구독)와 `ma_adapters_runtime`(PostgreSQL
구현)은 같은 레이어라 서로 import 할 수 없다. 둘 다 아래를 볼 수 있으므로
포트는 L4 에 둔다.

**payload 에 이벤트를 싣지 않는다.** id 와 seq 만 보내고 구독자가 다시 읽는다.
이유는 셋이다.

1. PostgreSQL `NOTIFY` payload 는 **8000바이트 한계**가 있다. 긴 툴 결과 하나로
   넘는다 (`IMPL-0011`).
2. 실려 온 것과 DB 의 것이 다를 수 있다 — 두 벌의 진실이 생긴다.
3. 구독자가 `after_seq` 로 다시 읽으면 **놓친 것도 같이** 받는다. 알림을 놓쳐도
   다음 알림에서 따라잡는다.

즉 알림은 **"깨우는 신호"이지 데이터가 아니다.**
"""

from __future__ import annotations

from collections.abc import AsyncIterator
from contextlib import AbstractAsyncContextManager
from dataclasses import dataclass
from typing import Protocol


@dataclass(frozen=True, slots=True)
class Wake:
    """세션에 변화가 있다는 신호. **데이터가 아니다.**"""

    workspace_id: str
    session_id: str
    #: 알림 시점에 알려진 최대 seq. 구독자는 자기 커서와 비교만 한다.
    up_to_seq: int | None = None


class RealtimePort(Protocol):
    async def publish(self, wake: Wake) -> None: ...

    def subscribe(
        self, workspace_id: str, session_id: str
    ) -> AbstractAsyncContextManager[AsyncIterator[Wake]]:
        """구독을 열고 신호를 흘린다. 컨텍스트를 벗어나면 정리된다."""
        ...


__all__ = ["RealtimePort", "Wake"]
