"""환경 티어 × 에이전트 설정 → 등록할 툴.

`plan/06-harness-and-model.md` §4.3 · `plan/07-sandbox.md` §2 ·
`task/M2-sandbox-tools/T-0305-tool-registry.md` · `IMPL-0019`.

```
에이전트가 켠 것  ∩  provider 가 줄 수 있는 것  =  등록할 것
```

둘이 어긋나면 **세션 생성에서 거부한다.** 런타임에 조용히 빼면 에이전트가
할 수 있다고 믿는 일을 못 하고, 그 이유가 어디에도 없다.

> **이 모듈은 이름만 다룬다.** `ToolRegistry` 를 만들지 않는다 —
> 그것은 `ma_harness.registry.build_tools` 의 일이고, `ma_harness` 는
> L5 라 L4 인 여기서 import 할 수 없다 (`.importlinter` 의 `layers`).
>
> 작업 명세(`T-0305`)는 이 파일이 `build_tools(agent, sandbox, grants)` 를
> 들기를 기대했지만, 그러면 레이어가 깨진다. 책임을 쪼갰다:
>
> | 레이어 | 무엇 |
> |---|---|
> | L4 여기 | **어떤 툴이 허용되는가** — 환경과 에이전트를 맞춰 보고 거부한다 |
> | L5 `ma_harness.registry` | **그 이름들로 레지스트리를 조립한다** — 실행기·스키마·승인 |
>
> 쪼개고 나니 더 맞는다. 세션 생성은 실행기를 들고 있지 않다 — 그것은
> 워커가 조립할 때 생긴다. 생성 시점에 할 수 있는 것은 **이름 판정뿐**이다.

| 티어 | `bash` | `run_code` | 호스트 툴 5개 | 웹 툴 |
|---|---|---|---|---|
| **W** (wasm) | ✗ ambient authority 0 | ✓ 에셋 있을 때 | ✓ | ✓ (신뢰 영역) |
| **P** (process) | ✓ 격리가 측정됐을 때만 | ✗ | ✓ | ✓ |
| local (개발) | ✓ (막는 것 없음) | ✗ | ✓ | ✓ |

웹 툴이 모든 티어에 있는 것이 핵심이다 — **신뢰 영역에서 돌기 때문에**
샌드박스에 네트워크가 없어도 에이전트는 웹을 본다 (T-0306).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Protocol

from ma_domain.agents import SHELL_TOOLS

if TYPE_CHECKING:
    from ma_domain.agents import AgentDefinition


class ToolSource(Protocol):
    """provider 가 "이 티어에서 등록해도 되는 툴"을 말한다.

    `ma_sandbox.ports.SandboxProvider` 를 그대로 받지 않는 이유: 그 Protocol
    에는 `tools_available` 이 없고, 넣으면 **감금과 툴 목록이 한 타입에
    묶인다.** 둘은 같이 바뀌지 않는다.
    """

    name: str

    def tools_available(self) -> tuple[str, ...]: ...


@dataclass(frozen=True, slots=True)
class ToolsetMismatch(Exception):
    """에이전트가 켠 툴을 이 환경이 줄 수 없다. **세션 생성이 400 이다.**

    예외인 이유: 경고로 두면 읽히지 않고, 조용히 빼면 디버깅할 수 없다.
    """

    requested: tuple[str, ...]
    provider: str
    available: tuple[str, ...]

    def __str__(self) -> str:
        return (
            f"이 환경({self.provider})이 줄 수 없는 툴이 켜져 있다: "
            f"{', '.join(self.requested)} — 사용 가능: {', '.join(self.available)}"
        )


def enabled_tool_names(agent: AgentDefinition) -> frozenset[str]:
    """에이전트가 켠 내장 툴. 커스텀·MCP 는 티어와 무관하므로 빼고 본다."""
    toolset = agent.toolset
    return toolset.enabled_tools() if toolset is not None else frozenset()


def check_toolset(agent: AgentDefinition, source: ToolSource) -> None:
    """**세션 생성 시점에** 부른다. 맞지 않으면 예외.

    `plan/07` §2 의 "티어 W 환경에서 `bash` 를 켜면 거부" 가 이것이다.
    셸만 특별 취급하지 않는다 — provider 가 못 주겠다는 것은 전부 같다.
    """
    available = set(source.tools_available())
    requested = enabled_tool_names(agent)
    missing = tuple(sorted(requested - available))
    if missing:
        raise ToolsetMismatch(
            requested=missing,
            provider=source.name,
            available=tuple(sorted(available)),
        )


def shell_requested(agent: AgentDefinition) -> bool:
    """`bash` 를 켰는가. 환경 선택(티어 W vs P)의 입력이다."""
    return bool(enabled_tool_names(agent) & SHELL_TOOLS)


def registrable_tools(agent: AgentDefinition, source: ToolSource) -> frozenset[str]:
    """등록해도 되는 **내장 툴 이름**. 교집합이다.

    `check_toolset` 을 통과한 뒤라면 이것은 `enabled_tool_names` 와 같다.
    통과하지 않은 채로 부르면(승인 재개처럼 이미 생성된 세션) 환경이 줄
    수 있는 것으로 좁혀진다 — **넓히지는 않는다**.
    """
    return enabled_tool_names(agent) & frozenset(source.tools_available())


__all__ = [
    "ToolSource",
    "ToolsetMismatch",
    "check_toolset",
    "enabled_tool_names",
    "registrable_tools",
    "shell_requested",
]
