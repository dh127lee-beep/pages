"""모델 카드 해석 — 결정 순서 5단계 (D12).

`plan/06-harness-and-model.md` §1.

```
① 환경변수 기본값     AWP_DEFAULT_MODEL_CARD        ← 부트스트랩용
② 모델 카드 (DB)      model_cards 행
③ 워크스페이스 기본값  workspaces.settings.default_model_card
④ 에이전트 설정        agents.document.model
⑤ 세션 오버라이드      sessions.config_override.model
```

**뒤로 갈수록 이긴다.** ①은 빈 DB에서 첫 카드를 만들 때만 쓰고, 운영에서는
②~⑤만 쓴다. 코드 어디에도 모델 문자열이 없다.

effort 도 같은 순서를 탄다. 다만 `config_override.model`을 주면 카드 **전체**가
바뀌므로 에이전트의 effort 가 따라오지 않는다 — 필요하면 `effort`도 함께 줘야
한다 (`ConfigOverride` 주석과 같은 이야기).
"""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from typing import TYPE_CHECKING

from ma_domain.models import EffortIntent, ModelCard, TokenUsage

if TYPE_CHECKING:
    from datetime import datetime

    from ma_domain.agents import AgentDefinition
    from ma_domain.ids import ModelCardId, WorkspaceId
    from ma_domain.sessions import ConfigOverride
    from ma_domain.workspaces import WorkspaceSettings
    from ma_store.models import ModelCardStore


# ── 결과 ───────────────────────────────────────────────────
@dataclass(frozen=True, slots=True)
class ResolvedModel:
    card: ModelCard
    effort: EffortIntent | None
    #: 어느 단계가 이겼는가. 관측과 디버깅용 — "왜 이 모델이 쓰였나"의 답.
    source: str  # "session" | "agent" | "workspace" | "env"


@dataclass(frozen=True, slots=True)
class ModelNotConfigured:
    """어느 단계도 카드를 정하지 못했다. **조립 실패로 다룬다.**"""

    tried: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class ModelCardMissing:
    """핸들은 정해졌는데 그 카드가 없거나 꺼져 있다."""

    card_id: ModelCardId
    source: str
    disabled: bool = False


type ResolveResult = ResolvedModel | ModelNotConfigured | ModelCardMissing


@dataclass(frozen=True, slots=True)
class ResolveModel:
    workspace_id: WorkspaceId
    #: ⑤ 세션 오버라이드
    override: ConfigOverride | None = None
    #: ④ 에이전트 설정
    agent: AgentDefinition | None = None
    #: ③ 워크스페이스 기본값
    settings: WorkspaceSettings | None = None
    #: ① 환경변수 기본값. 부트스트랩용 — 호출자가 읽어서 넣는다.
    env_default: ModelCardId | None = None


@dataclass
class ModelResolver:
    """`ModelCardStore` 하나만 안다. 환경변수를 **직접 읽지 않는다** —
    환경 접근은 설정 모듈 한 곳에만 있어야 한다 (`tools/check_architecture.py`)."""

    cards: ModelCardStore

    async def resolve(self, q: ResolveModel) -> ResolveResult:
        tried: list[str] = []

        for source, handle in self._candidates(q):
            tried.append(source)
            if handle is None:
                continue
            card = await self.cards.find(q.workspace_id, handle)
            if card is None:
                return ModelCardMissing(card_id=handle, source=source)
            if not card.enabled:
                return ModelCardMissing(card_id=handle, source=source, disabled=True)
            return ResolvedModel(card=card, effort=self._effort(q), source=source)

        return ModelNotConfigured(tried=tuple(tried))

    def _candidates(self, q: ResolveModel) -> tuple[tuple[str, ModelCardId | None], ...]:
        """**뒤로 갈수록 이기므로, 찾을 때는 뒤에서부터 본다.**"""
        return (
            ("session", q.override.model if q.override else None),
            ("agent", q.agent.model if q.agent else None),
            ("workspace", q.settings.default_model_card if q.settings else None),
            ("env", q.env_default),
        )

    def _effort(self, q: ResolveModel) -> EffortIntent | None:
        """effort 도 같은 순서. 세션이 이기고, 없으면 에이전트."""
        if q.override is not None and q.override.effort is not None:
            return q.override.effort
        if q.agent is not None:
            return q.agent.effort
        return None


# ── 비용 ───────────────────────────────────────────────────
def is_peak(card: ModelCard, at: datetime) -> bool:
    """요금 시간대는 **카드가 선언한다**. 코드에 UTC 시각을 박지 않는다."""
    return any(w.covers(at) for w in card.pricing.peak_windows)


def cost_cents(card: ModelCard, usage: TokenUsage, at: datetime) -> int:
    """사용량 → 센트. **카드의 요금 선언만 본다** — 요금 개정이 코드 변경이 아니다.

    올림한다. 반올림하면 작은 호출 수천 건이 조용히 0원이 되어 예산이 새고,
    "덜 청구하는 쪽"의 오차는 예산 한도를 무력화한다.
    """
    p = card.pricing
    unit = Decimal(p.unit_tokens)
    rate = Decimal(1) if is_peak(card, at) else p.off_peak_multiplier

    dollars = (
        Decimal(usage.input_cache_hit) / unit * p.input_cache_hit
        + Decimal(usage.input_cache_miss) / unit * p.input_cache_miss
        + Decimal(usage.output) / unit * p.output
    ) * rate

    cents = dollars * 100
    whole = int(cents)
    return whole + 1 if cents > whole else whole


__all__ = [
    "ModelCardMissing",
    "ModelNotConfigured",
    "ModelResolver",
    "ResolveModel",
    "ResolveResult",
    "ResolvedModel",
    "cost_cents",
    "is_peak",
]
