"""승인 유스케이스 — 요청 생성 · 결정 · 재개 · 만료 (D8).

`plan/02-architecture.md` §7 · `task/M3-security-governance/T-0403-approval-workflow.md`
· `IMPL-0022`.

흐름 (plan §7):

```
1. 턴이 requires_action 으로 멈춤  → approvals 행 생성 + 알림
2. 권한 있는 사람이 결정           → POST /api/v1/approvals/{id}
3. user.tool_confirmation 을 세션에 수용 (T-0203 의 같은 경로)
4. 워커가 claim 해서 재개. 승인된 툴은 **실행 함수가 붙은 상태로** 재구성
5. 거부면 "Denied: {reason}" 을 tool_result 로 주입하고 재개
6. 모든 단계가 audit_log 에 (T-0404)
```

**3번이 핵심이다.** 승인이 "DB 의 상태"로만 남으면 워커는 그것을 모른다.
세션 이벤트로 수용해야 워커가 claim 하고, 그래야 **재개가 일어난다.**

> **`approval/asked`·`approval/decided` 는 log-only 다** — 모델 전사에
> 들어가지 않는다. 승인 사실이 모델 컨텍스트를 오염시키면, 모델이
> "다음에는 승인을 피하는 방법"을 학습할 재료가 된다.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from ma_domain.events import EventType
from ma_domain.governance import Approval, ApprovalState
from ma_domain.ids import ApprovalId
from ma_governance.approval import (
    Refusal,
    denial_message,
    is_satisfied,
    may_decide,
    resolve,
)

if TYPE_CHECKING:
    from datetime import datetime

    from ma_domain.agents import ToolKind
    from ma_domain.ids import EventId, SessionId, ToolCallId, UserId, WorkspaceId
    from ma_domain.workspaces import Role
    from ma_store._results import Cursor, Page
    from ma_store.governance import ApprovalPolicyStore, ApprovalStore
    from ma_store.sessions import SessionStore

    from ma_application.session_events import SessionEventsUseCases

#: 승인 요약에 담을 최대 길이. **전체 입력을 담지 않는다** — 비밀이
#: 섞이고, 담은 순간 그것이 두 번째 복사본이 되어 drift 한다.
MAX_SUMMARY_CHARS = 200


# ── 결과 ─────────────────────────────────────────────────
@dataclass(frozen=True, slots=True)
class ApprovalRequested:
    approval: Approval


@dataclass(frozen=True, slots=True)
class ApprovalDecided:
    approval: Approval
    #: 표가 차서 세션이 재개됐는가. `required_approvals=2` 의 첫 표는 False.
    resumed: bool


@dataclass(frozen=True, slots=True)
class ApprovalNotFound:
    approval_id: ApprovalId


@dataclass(frozen=True, slots=True)
class ApprovalForbidden:
    """**왜 안 되는지 말한다.** 403 의 본문에 들어간다."""

    refusal: Refusal


type DecideResult = ApprovalDecided | ApprovalNotFound | ApprovalForbidden


# ── 입력 ─────────────────────────────────────────────────
@dataclass(frozen=True, slots=True)
class RequestApproval:
    """턴이 `requires_action` 으로 멈췄을 때 제어 평면이 부른다."""

    workspace_id: WorkspaceId
    session_id: SessionId
    event_id: EventId
    tool_call_id: ToolCallId
    tool_name: str
    tool_kind: ToolKind
    #: **요약이다.** 전체 입력이 아니다.
    input_summary: tuple[tuple[str, object], ...] = ()
    agent_id: str | None = None


@dataclass(frozen=True, slots=True)
class Decide:
    workspace_id: WorkspaceId
    approval_id: ApprovalId
    actor: UserId
    actor_role: Role
    approve: bool
    reason: str | None = None


@dataclass
class ApprovalsUseCases:
    approvals: ApprovalStore
    policies: ApprovalPolicyStore
    sessions: SessionStore
    events: SessionEventsUseCases
    clock: object
    ids: object

    # ── 1. 요청 ──────────────────────────────────────────
    async def request(self, cmd: RequestApproval) -> ApprovalRequested:
        """승인 행을 만든다. **이미 있으면 그것을 돌려준다.**

        재claim 된 턴이 같은 호출을 다시 멈추는 일이 있고, 그때 두 번째
        행을 만들면 인박스에 중복이 뜬다.
        """
        now = self.clock.now()  # type: ignore[attr-defined]
        resolved = resolve(
            await self.policies.list_policies(cmd.workspace_id),
            tool_name=cmd.tool_name,
            agent_id=cmd.agent_id,  # type: ignore[arg-type]
        )
        made = await self.approvals.insert(
            Approval(
                id=ApprovalId(self.ids.next("approval")),  # type: ignore[attr-defined]
                workspace_id=cmd.workspace_id,
                session_id=cmd.session_id,
                event_id=cmd.event_id,
                tool_call_id=cmd.tool_call_id,
                tool_name=cmd.tool_name,
                tool_kind=cmd.tool_kind,
                state=ApprovalState.PENDING,
                requested_at=now,
                input_summary=truncate_summary(cmd.input_summary),
                policy_id=resolved.policy_id,  # type: ignore[arg-type]
                expires_at=resolved.expires_at(now),
            )
        )
        return ApprovalRequested(approval=made)

    # ── 2·3. 결정과 재개 ─────────────────────────────────
    async def decide(self, cmd: Decide) -> DecideResult:
        """정책을 보고 결정한다. **fail-closed.**"""
        found = await self.approvals.find(cmd.workspace_id, cmd.approval_id)
        if found is None:
            return ApprovalNotFound(approval_id=cmd.approval_id)

        now = self.clock.now()  # type: ignore[attr-defined]
        resolved = resolve(
            await self.policies.list_policies(cmd.workspace_id),
            tool_name=found.tool_name,
        )
        verdict = may_decide(
            found,
            resolved,
            actor=cmd.actor,
            actor_role=cmd.actor_role,
            session_owner=await self._session_owner(found),
            now=now,
        )
        if not verdict:
            assert verdict.refusal is not None
            return ApprovalForbidden(refusal=verdict.refusal)

        from ma_store.governance import DecideApproval

        after = await self.approvals.decide(
            DecideApproval(
                workspace_id=cmd.workspace_id,
                approval_id=cmd.approval_id,
                decided_by=cmd.actor,
                approve=cmd.approve,
                now=now,
                reason=cmd.reason,
            )
        )
        if after is None:
            # 경합으로 졌다 — 그 사이 누가 거부했거나 만료됐다.
            return ApprovalForbidden(refusal=Refusal.NOT_PENDING)

        if not cmd.approve:
            await self._resume(after, approved=False, reason=cmd.reason)
            return ApprovalDecided(approval=after, resumed=True)

        if not is_satisfied(after, resolved):
            # **표가 모자란다.** `required_approvals=2` 의 첫 표다.
            return ApprovalDecided(approval=after, resumed=False)

        final = await self.approvals.finalize(cmd.workspace_id, cmd.approval_id, now)
        if final is None:  # pragma: no cover — 방금 표를 더했다
            return ApprovalForbidden(refusal=Refusal.NOT_PENDING)

        await self._resume(final, approved=True, reason=cmd.reason)
        return ApprovalDecided(approval=final, resumed=True)

    async def _resume(self, approval: Approval, *, approved: bool, reason: str | None) -> None:
        """**세션에 이벤트를 수용해 재개를 일으킨다.**

        이것이 없으면 승인은 DB 의 상태일 뿐이고 워커는 모른다 — 세션이
        `requires_action` 에 영원히 남는다.

        거부도 **같은 경로**로 간다. 턴을 죽이지 않고 `Denied: {reason}`
        을 `tool_result` 로 주입해 모델이 이어 가게 한다 (`plan/02` §7 ⑤).
        """
        from ma_domain.workspaces import Role as _Role

        from ma_application.session_events import InboundEvent, SendEvents

        payload: tuple[tuple[str, object], ...] = (
            ("tool_call_id", approval.tool_call_id),
            ("approved", approved),
        )
        if not approved:
            payload = (*payload, ("content", denial_message(reason)))

        await self.events.send(
            SendEvents(
                workspace_id=approval.workspace_id,
                session_id=approval.session_id,
                events=(InboundEvent(type=EventType.USER_TOOL_CONFIRMATION, payload=payload),),
                # **승인 id 가 멱등키다.** 같은 승인이 두 번 재개를 일으키면
                # 툴이 두 번 실행된다.
                idempotency_key=f"approval:{approval.id}",
                actor_role=_Role.OWNER,
            )
        )

    # ── 6. 만료 ──────────────────────────────────────────
    async def expire_due(self, workspace_id: WorkspaceId) -> int:
        """기한이 지난 대기 건을 자동 거부한다.

        **재개까지 한다.** 상태만 바꾸고 말면 세션이 `requires_action` 에
        남고, 그 세션이 잡고 있는 자원도 함께 남는다.
        """
        now = self.clock.now()  # type: ignore[attr-defined]
        due = await self._due(workspace_id, now)
        count = await self.approvals.expire_due(workspace_id, now)
        for approval in due:
            await self._resume(approval, approved=False, reason="승인 기한이 지났다")
        return count

    async def _due(self, workspace_id: WorkspaceId, now: datetime) -> tuple[Approval, ...]:
        from ma_store._results import ListQuery

        page = await self.approvals.list_inbox(
            ListQuery(workspace_id=workspace_id, limit=200), ApprovalState.PENDING
        )
        return tuple(a for a in page.items if a.is_expired(now))

    # ── 인박스 ───────────────────────────────────────────
    async def inbox(
        self,
        workspace_id: WorkspaceId,
        *,
        state: ApprovalState = ApprovalState.PENDING,
        limit: int = 50,
        after: Cursor | None = None,
    ) -> Page[Approval]:
        from ma_store._results import ListQuery

        return await self.approvals.list_inbox(
            ListQuery(workspace_id=workspace_id, limit=limit, after=after), state
        )

    async def find(self, workspace_id: WorkspaceId, approval_id: ApprovalId) -> Approval | None:
        return await self.approvals.find(workspace_id, approval_id)

    async def _session_owner(self, approval: Approval) -> UserId | None:
        """`self_approval=false` 판정의 재료.

        세션을 못 읽으면 **`None` 을 돌려주고, 그러면 자기 승인 검사가
        통과한다.** 모순처럼 보이지만 아니다 — 세션이 없으면 "본인이 올린
        세션"이라는 개념 자체가 없고, 역할 검사는 그대로 걸린다.
        """
        from ma_store.sessions import FindSession

        session = await self.sessions.find(
            FindSession(workspace_id=approval.workspace_id, id=approval.session_id)
        )
        return getattr(session, "created_by", None) if session else None


def truncate_summary(
    summary: tuple[tuple[str, object], ...],
) -> tuple[tuple[str, object], ...]:
    """**요약을 자른다.** 전체 입력이 들어오는 것을 구조적으로 막는다.

    호출자가 실수로 전체를 넘겨도 여기서 잘린다. 자르는 것이 완벽한
    비밀 차단은 아니지만, `bash` 의 명령 전체가 인박스에 그대로 뜨는
    것과는 다르다.
    """
    out: list[tuple[str, object]] = []
    for key, value in summary:
        text = str(value)
        if len(text) > MAX_SUMMARY_CHARS:
            text = text[:MAX_SUMMARY_CHARS] + f"… ({len(str(value)):,}자)"
        out.append((key, text))
    return tuple(out)


__all__ = [
    "MAX_SUMMARY_CHARS",
    "ApprovalDecided",
    "ApprovalForbidden",
    "ApprovalNotFound",
    "ApprovalRequested",
    "ApprovalsUseCases",
    "Decide",
    "DecideResult",
    "RequestApproval",
    "truncate_summary",
]
