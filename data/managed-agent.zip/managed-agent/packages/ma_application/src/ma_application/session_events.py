"""이벤트 수용 — 멱등성 · lane 분할 · 역할 검사.

`plan/02-architecture.md` §3 규칙 1 · §6 · `plan/04-api.md` §2.4 §4.

수용은 **한 트랜잭션**이다. 이 유스케이스가 하는 일은 그 트랜잭션에 무엇을 넣을지
정하는 것이다:

1. **멱등 id 생성** — `sha256(idempotency_key + index)`. 재시도가 이벤트를 두 번
   만들지 않는다.
2. **lane 분할** — `thread_id`별로 실행 단위를 나눈다. `user.interrupt`와
   `system.message`는 실행 단위가 **아니다** (`IMPL-0008`).
3. **역할 검사** — `system.message`는 admin 이상.
4. **revision CAS 재시도** — 다른 요청과 경합하면 최대 3회 다시 읽고 시도한다.

Store 가 아니라 여기서 하는 이유: 셋 다 **정책**이고, 정책은 교체 가능해야 한다.
Store 는 "원자적으로 써라"만 안다.
"""

from __future__ import annotations

import hashlib
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from ma_domain.events import (
    NOT_EXECUTION_UNIT,
    PRIMARY_THREAD,
    SENDABLE,
    EventType,
    PendingEvent,
)
from ma_domain.ids import EventId, SessionId, ThreadId, WorkspaceId
from ma_domain.workspaces import Role
from ma_store._results import NotFound, VersionConflict
from ma_store.events import AdmitEvents, Admitted
from ma_store.sessions import FindSession

if TYPE_CHECKING:
    from ma_domain.clock import Clock
    from ma_store.events import PendingEventStore, SessionEventStore
    from ma_store.sessions import SessionStore

#: revision 경합 재시도 횟수. 근거는 `IMPL-0008`.
MAX_CAS_RETRIES = 3

#: `system.message`를 보낼 수 있는 최소 역할. 에이전트에게 시스템 발화로
#: 보이므로 operator 가 쓰면 프롬프트 주입과 구별되지 않는다.
SYSTEM_MESSAGE_ROLE = Role.ADMIN


@dataclass(frozen=True, slots=True)
class InboundEvent:
    """클라이언트가 보낸 이벤트 하나. 아직 id 가 없다 — 멱등키에서 만든다."""

    type: EventType
    payload: tuple[tuple[str, object], ...] = ()
    thread_id: ThreadId = PRIMARY_THREAD


@dataclass(frozen=True, slots=True)
class SendEvents:
    workspace_id: WorkspaceId
    session_id: SessionId
    events: tuple[InboundEvent, ...]
    idempotency_key: str
    actor_role: Role
    expected_revision: int | None = None


# ── 결과 ───────────────────────────────────────────────────
@dataclass(frozen=True, slots=True)
class EventsAccepted:
    accepted: tuple[EventId, ...]
    revision: int
    #: 이미 수용돼 있던 것을 그대로 돌려준 경우. 202 로 응답한다.
    replayed: bool = False


@dataclass(frozen=True, slots=True)
class SessionNotFound:
    session_id: SessionId


@dataclass(frozen=True, slots=True)
class RevisionConflict:
    actual_revision: int


@dataclass(frozen=True, slots=True)
class IdempotencyConflict:
    """같은 키인데 내용이 다르다. 409 — 조용히 덮어쓰면 안 된다."""

    event_id: EventId


@dataclass(frozen=True, slots=True)
class EventsRejected:
    reason: str
    detail: str = ""


type SendResult = (
    EventsAccepted | SessionNotFound | RevisionConflict | IdempotencyConflict | EventsRejected
)


def event_id_for(idempotency_key: str, index: int) -> EventId:
    """`sha256(key + index)` — 결정적이다.

    같은 키로 재시도하면 같은 id 가 나오고, pending 의 유니크 인덱스가 중복을
    막는다. **클라이언트가 id 를 정하지 않는 이유**는 두 클라이언트가 같은 id 를
    주장할 수 있기 때문이다.
    """
    digest = hashlib.sha256(f"{idempotency_key}:{index}".encode()).hexdigest()
    return EventId(f"evt_{digest[:26].upper()}")


def split_lanes(
    events: tuple[PendingEvent, ...],
) -> tuple[tuple[tuple[ThreadId, EventId, tuple[EventId, ...]], ...], tuple[ThreadId, ...]]:
    """lane 별 실행 단위와 인터럽트 대상 lane 을 가른다.

    `execution_id`는 그 lane 의 **첫 이벤트 id**다 — 멱등키 역할을 겸한다.
    같은 요청을 재시도하면 같은 첫 이벤트 id 가 나오므로 실행도 하나다.

    `user.interrupt`는 실행을 만들지 않는다. 이미 도는 것을 멈추라는 뜻이지
    새로 일을 시키라는 뜻이 아니다. `system.message`도 마찬가지로 — 기록이지
    턴의 시작이 아니다 (`NOT_EXECUTION_UNIT`).
    """
    by_lane: dict[ThreadId, list[EventId]] = {}
    interrupts: list[ThreadId] = []

    for e in events:
        if e.type is EventType.USER_INTERRUPT:
            if e.thread_id not in interrupts:
                interrupts.append(e.thread_id)
            continue
        if e.type in NOT_EXECUTION_UNIT:
            continue
        by_lane.setdefault(e.thread_id, []).append(e.id)

    batches = tuple((lane, ids[0], tuple(ids)) for lane, ids in by_lane.items() if ids)
    return batches, tuple(interrupts)


@dataclass
class SessionEventsUseCases:
    events: SessionEventStore
    pending_events: PendingEventStore
    sessions: SessionStore
    clock: Clock
    max_retries: int = field(default=MAX_CAS_RETRIES)
    #: 현재 trace 를 outbox 에 실을 모양으로 돌려준다.
    #:
    #: **주입받는 이유**: `ma_application` 은 L4 이고 `ma_observability`
    #: 는 L6 다 (`plan/03` §2). 유스케이스가 관측 패키지를 들면 의존이
    #: 위로 흐른다. 기본값은 빈 tuple — 관측 없이도 돈다.
    trace_carrier: Callable[[], tuple[tuple[str, str], ...]] = lambda: ()

    async def send(self, cmd: SendEvents) -> SendResult:
        rejected = self._validate(cmd)
        if rejected is not None:
            return rejected

        now = self.clock.now()
        pending = tuple(
            PendingEvent(
                id=event_id_for(cmd.idempotency_key, i),
                workspace_id=cmd.workspace_id,
                session_id=cmd.session_id,
                thread_id=e.thread_id,
                type=e.type,
                payload=e.payload,
                enqueued_at=now,
                pending_seq=0,
            )
            for i, e in enumerate(cmd.events)
        )

        replay = await self._check_idempotency(cmd, pending)
        if replay is not None:
            return replay

        batches, interrupts = split_lanes(pending)

        # revision CAS 재시도 — 경합은 흔하고(콘솔과 워커가 같이 쓴다),
        # 진 쪽이 아무것도 남기지 않으므로 그냥 다시 읽고 시도하면 된다.
        expected = cmd.expected_revision
        for attempt in range(self.max_retries):
            if expected is None:
                found = await self.sessions.find(
                    FindSession(workspace_id=cmd.workspace_id, id=cmd.session_id)
                )
                if found is None:
                    return SessionNotFound(session_id=cmd.session_id)
                expected = found.revision

            result = await self.events.admit(
                AdmitEvents(
                    workspace_id=cmd.workspace_id,
                    session_id=cmd.session_id,
                    expected_revision=expected,
                    events=pending,
                    lane_batches=batches,
                    interrupt_lanes=interrupts,
                    now=now,
                    # **여기서 trace 를 outbox 에 싣는다.** 워커는 요청을
                    # 받지 않고 큐를 긁어 가므로 헤더로는 이을 수 없다
                    # (`ma_observability.trace` · `IMPL-0029`).
                    trace_context=self.trace_carrier(),
                )
            )
            match result:
                case Admitted():
                    return EventsAccepted(accepted=result.accepted, revision=result.revision)
                case NotFound():
                    return SessionNotFound(session_id=cmd.session_id)
                case VersionConflict():
                    # 클라이언트가 명시적으로 준 revision 이면 재시도하지 않는다 —
                    # 낙관적 동시성의 뜻이 "내가 본 상태 위에서만 써라"이므로,
                    # 몰래 최신 상태 위에 쓰면 그 보장을 깨는 것이다.
                    if cmd.expected_revision is not None:
                        return RevisionConflict(actual_revision=result.actual_version)
                    expected = None  # 다시 읽는다
                    if attempt == self.max_retries - 1:
                        return RevisionConflict(actual_revision=result.actual_version)

        return RevisionConflict(actual_revision=-1)  # pragma: no cover — 위에서 반환된다

    # ── 내부 ───────────────────────────────────────────────
    def _validate(self, cmd: SendEvents) -> EventsRejected | None:
        if not cmd.events:
            return EventsRejected(reason="empty", detail="이벤트가 없다")
        if not cmd.idempotency_key:
            return EventsRejected(reason="missing_idempotency_key")
        for e in cmd.events:
            if e.type not in SENDABLE:
                return EventsRejected(
                    reason="not_sendable",
                    detail=f"{e.type.value}는 클라이언트가 보낼 수 없다",
                )
            if e.type is EventType.SYSTEM_MESSAGE and not cmd.actor_role.at_least(
                SYSTEM_MESSAGE_ROLE
            ):
                return EventsRejected(
                    reason="forbidden",
                    detail=f"{EventType.SYSTEM_MESSAGE.value}는 "
                    f"{SYSTEM_MESSAGE_ROLE.value} 이상이어야 한다",
                )
        return None

    async def _find_anywhere(
        self, workspace_id: WorkspaceId, session_id: SessionId, event_id: EventId
    ) -> tuple[tuple[tuple[str, object], ...], EventType] | None:
        """**수용됐는지**를 묻는다 — 정본이든 pending 이든 수용된 것은 수용된 것이다.

        정본만 보면 아직 승격되지 않은 입력을 못 보고, 재시도가 통과해 버린다.
        행은 유니크 인덱스가 막지만 `revision`은 한 번 더 올라간다 — 클라이언트가
        보기에 "같은 요청을 두 번 보냈더니 상태가 두 번 바뀐" 것이 된다.
        """
        promoted = await self.events.find_by_id(workspace_id, session_id, event_id)
        if promoted is not None:
            return promoted.payload, promoted.type
        queued = await self.pending_events.find_by_id(workspace_id, session_id, event_id)
        if queued is not None:
            return queued.payload, queued.type
        return None

    async def _check_idempotency(
        self, cmd: SendEvents, pending: tuple[PendingEvent, ...]
    ) -> SendResult | None:
        """이미 있는 id 를 만나면 payload 를 비교한다.

        같으면 **기존 결과를 재반환**(202), 다르면 409. 재시도 길이가 다른
        경우(3개 보냈다가 2개로)를 잡기 위해 `prefix+N`(다음 위치)도 본다 —
        그 자리에 뭔가 있으면 이전 시도가 더 길었다는 뜻이다.
        """
        seen = 0
        for p in pending:
            existing = await self._find_anywhere(cmd.workspace_id, cmd.session_id, p.id)
            if existing is None:
                continue
            if existing[0] != p.payload or existing[1] is not p.type:
                return IdempotencyConflict(event_id=p.id)
            seen += 1

        next_id = event_id_for(cmd.idempotency_key, len(pending))
        tail = await self._find_anywhere(cmd.workspace_id, cmd.session_id, next_id)
        if tail is not None:
            # 이전 시도가 더 많이 보냈다. 지금 요청은 그 일부라 재현할 수 없다.
            return IdempotencyConflict(event_id=next_id)

        if seen and seen == len(pending):
            found = await self.sessions.find(
                FindSession(workspace_id=cmd.workspace_id, id=cmd.session_id)
            )
            return EventsAccepted(
                accepted=tuple(p.id for p in pending),
                revision=found.revision if found else -1,
                replayed=True,
            )
        return None


__all__ = [
    "MAX_CAS_RETRIES",
    "EventsAccepted",
    "EventsRejected",
    "IdempotencyConflict",
    "InboundEvent",
    "RevisionConflict",
    "SendEvents",
    "SendResult",
    "SessionEventsUseCases",
    "SessionNotFound",
    "event_id_for",
    "split_lanes",
]
