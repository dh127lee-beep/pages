"""웹훅 유스케이스 — **이벤트를 구독자에게 펼친다** (T-0604).

`plan/04-api.md` §3.8.

```
세션 상태 변화
  └ publish(event, data)
      └ subscribers(event)       구독 필터
          └ enqueue × N           전송 큐에 넣기만 한다
                                  (보내는 것은 스케줄러다)
```

**여기서 HTTP 를 치지 않는다.** 세션이 끝나는 경로에 네트워크를 넣으면
수신 측이 느릴 때 턴이 느려진다 — 큐에 넣고 돌아온다.

승인 알림(Slack·메일)은 **다른 길**이다. 그쪽은 사람이 읽고, 웹훅은
기계가 받는다.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Protocol

from ma_domain.errors import InvariantViolation
from ma_domain.webhooks import (
    MIN_SECRET_BYTES,
    NotifyMessage,
    WebhookEndpoint,
    WebhookEvent,
)
from ma_store._results import ListQuery

if TYPE_CHECKING:
    from ma_domain.clock import Clock, IdGenerator
    from ma_domain.ids import WorkspaceId
    from ma_domain.webhooks import WebhookDelivery
    from ma_store._results import Cursor, Page
    from ma_store.webhooks import WebhookStore


class Notifier(Protocol):
    """Slack·메일. **실패가 승인 흐름을 막지 않는다.**"""

    async def send(self, message: NotifyMessage) -> None: ...


# ── 결과 ─────────────────────────────────────────────────
@dataclass(frozen=True, slots=True)
class EndpointCreated:
    endpoint: WebhookEndpoint
    #: **생성 직후 한 번만** 돌려준다. DB 에는 봉해서 들어간다.
    secret: str


@dataclass(frozen=True, slots=True)
class EndpointInvalid:
    reasons: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class EndpointMissing:
    endpoint_id: str


type CreateEndpointResult = EndpointCreated | EndpointInvalid


@dataclass(frozen=True, slots=True)
class Published:
    """몇 곳에 넣었는가. **0 이 정상일 수 있다** — 구독자가 없으면."""

    event: WebhookEvent
    queued: int
    delivery_ids: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class CreateEndpoint:
    workspace_id: WorkspaceId
    url: str
    events: tuple[WebhookEvent, ...] = ()
    description: str = ""
    created_by: str = ""


@dataclass
class WebhooksUseCases:
    webhooks: WebhookStore
    clock: Clock
    ids: IdGenerator
    #: 승인 알림을 보낼 곳들. **비어 있어도 된다** — 웹훅만 쓸 수 있다.
    notifiers: tuple[Notifier, ...] = ()
    #: 콘솔 주소. 알림의 "열기" 링크가 여기로 간다.
    console_base_url: str = ""
    _log: Any = field(default=None, repr=False)

    def __post_init__(self) -> None:
        if self._log is None:
            import logging as _logging

            self._log = _logging.getLogger("ma_application.webhooks")

    # ── 엔드포인트 ───────────────────────────────────────
    async def create_endpoint(self, cmd: CreateEndpoint) -> CreateEndpointResult:
        """시크릿을 **우리가 만든다.**

        클라이언트가 고르게 하면 약한 것이 들어온다 — 그리고 그
        약함은 서명 위조로 바로 이어진다.
        """
        import secrets as _secrets

        from ma_store.webhooks import InsertEndpoint

        try:
            # 도메인이 https 를 강제한다 — 여기서 다시 쓰지 않는다.
            WebhookEndpoint(id="probe", workspace_id=cmd.workspace_id, url=cmd.url)
        except InvariantViolation as exc:
            return EndpointInvalid(reasons=(str(exc),))

        secret = _secrets.token_urlsafe(MIN_SECRET_BYTES)
        made = await self.webhooks.insert_endpoint(
            InsertEndpoint(
                id=self.ids.next("webhook"),
                workspace_id=cmd.workspace_id,
                url=cmd.url,
                secret=secret.encode("latin-1"),
                events=cmd.events,
                description=cmd.description,
                created_by=cmd.created_by,
                now=self.clock.now(),
            )
        )
        # **한 번만 돌려준다.** 다시 물어볼 길이 없다 — 잃으면 새로
        # 만든다 (`credentials` 와 같은 규칙).
        return EndpointCreated(endpoint=made, secret=secret)

    async def list_endpoints(
        self, workspace_id: WorkspaceId, *, limit: int = 50, after: Cursor | None = None
    ) -> Page[WebhookEndpoint]:
        return await self.webhooks.list_endpoints(
            ListQuery(workspace_id=workspace_id, limit=limit, after=after)
        )

    async def disable_endpoint(self, workspace_id: WorkspaceId, endpoint_id: str) -> bool:
        return await self.webhooks.disable_endpoint(workspace_id, endpoint_id, self.clock.now())

    # ── 발행 ─────────────────────────────────────────────
    async def publish(
        self, workspace_id: WorkspaceId, event: WebhookEvent, data: dict[str, Any]
    ) -> Published:
        """구독자마다 전송을 **큐에 넣는다.** HTTP 를 치지 않는다.

        세션이 끝나는 경로에 네트워크를 넣으면 수신 측이 느릴 때 턴이
        느려진다.
        """
        from ma_store.webhooks import EnqueueDelivery

        endpoints = await self.webhooks.subscribers(workspace_id, event)
        now = self.clock.now()
        ids: list[str] = []
        for endpoint in endpoints:
            delivery = await self.webhooks.enqueue(
                EnqueueDelivery(
                    id=self.ids.next("webhook_delivery"),
                    workspace_id=workspace_id,
                    endpoint_id=endpoint.id,
                    event=event,
                    payload=data,
                    now=now,
                )
            )
            ids.append(delivery.id)
        return Published(event=event, queued=len(ids), delivery_ids=tuple(ids))

    async def list_dead(
        self, workspace_id: WorkspaceId, *, limit: int = 50
    ) -> Page[WebhookDelivery]:
        """DLQ. **사람이 보고 다시 쏜다.**"""
        return await self.webhooks.list_dead(ListQuery(workspace_id=workspace_id, limit=limit))

    async def retry_dead(self, workspace_id: WorkspaceId, delivery_id: str) -> bool:
        """DLQ 의 것을 다시 큐에 올린다.

        **새 전송을 만들지 않고 같은 것을 되살린다** — 새로 만들면
        수신 측의 멱등 키(`delivery_id`)가 달라져 두 번 처리된다.
        """
        from ma_domain.webhooks import DeliveryState
        from ma_store.webhooks import RecordAttempt

        got = await self.webhooks.find_delivery(workspace_id, delivery_id)
        if got is None or not got.is_dead:
            return False
        now = self.clock.now()
        await self.webhooks.record_attempt(
            RecordAttempt(
                workspace_id=workspace_id,
                delivery_id=delivery_id,
                state=DeliveryState.PENDING,
                # **시도 횟수를 0 으로 되돌린다.** 안 되돌리면 한 번
                # 보내고 바로 다시 죽는다.
                attempts=0,
                now=now,
                next_attempt_at=now,
                last_error="",
            )
        )
        return True

    # ── 사람 알림 ────────────────────────────────────────
    async def notify_approval(
        self,
        workspace_id: WorkspaceId,
        *,
        approval_id: str,
        session_id: str,
        tool_name: str,
        requested_by: str = "",
    ) -> int:
        """승인 요청을 사람에게. **실패가 승인 흐름을 막지 않는다.**

        알림이 안 가는 것은 나쁘지만, 알림 때문에 승인이 **생성되지
        않는 것**은 더 나쁘다 — 그러면 세션이 영원히 멈춘다.
        """
        message = NotifyMessage(
            title=f"승인 대기: {tool_name}",
            body=f"세션 {session_id} 이 `{tool_name}` 실행 승인을 기다립니다.",
            link=f"{self.console_base_url}/approvals" if self.console_base_url else "",
            urgent=True,
            fields=(
                ("세션", session_id),
                ("도구", tool_name),
                *((("요청자", requested_by),) if requested_by else ()),
            ),
        )
        return await self._fan_out(message)

    async def notify_budget(self, workspace_id: WorkspaceId, *, scope: str, ratio: float) -> int:
        message = NotifyMessage(
            title=f"예산 {ratio:.0%} 소진",
            body=f"{scope} 예산의 {ratio:.0%} 를 썼습니다.",
            link=f"{self.console_base_url}/costs" if self.console_base_url else "",
            urgent=ratio >= 1.0,
            fields=(("스코프", scope), ("소진율", f"{ratio:.1%}")),
        )
        return await self._fan_out(message)

    async def notify_session_failed(
        self, workspace_id: WorkspaceId, *, session_id: str, error: str
    ) -> int:
        message = NotifyMessage(
            title="세션 실패",
            body=error[:500],
            link=(
                f"{self.console_base_url}/sessions/{session_id}" if self.console_base_url else ""
            ),
            fields=(("세션", session_id),),
        )
        return await self._fan_out(message)

    async def _fan_out(self, message: NotifyMessage) -> int:
        """**하나가 실패해도 나머지를 보낸다.**

        Slack 이 죽었다고 메일까지 안 가면, 중복으로 둔 의미가 없다.
        """
        sent = 0
        for notifier in self.notifiers:
            try:
                await notifier.send(message)
                sent += 1
            except Exception as exc:
                self._log.warning("알림 실패 %s: %s", type(notifier).__name__, exc)
        return sent


__all__ = [
    "CreateEndpoint",
    "CreateEndpointResult",
    "EndpointCreated",
    "EndpointInvalid",
    "EndpointMissing",
    "Notifier",
    "Published",
    "WebhooksUseCases",
]
