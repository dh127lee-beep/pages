"""메모리 스토어 유스케이스 (D10).

`plan/02-architecture.md` §9 · `plan/04-api.md` §3.6 · `plan/03-layers.md` §3 L4.

여기 있는 것: slug 충돌 · 경로 검증 · CAS 결과 union · 레댁션 권한 경계.
여기 **없는** 것: 파일시스템 · 마운트 · 디프. 그것은 L5 (`ma_harness`) 다.

**마운트를 이 레이어가 모른다.** 유스케이스는 "경로에 무엇이 있는가"만
안다. `/mnt/memory/<slug>` 라는 사실은 도메인의 `MemoryStore.mount_path`
와 하네스가 안다 — 여기에 마운트가 들어오면 "SQL 이 진실"이라는 D10 의
방향이 뒤집힌다.

**레댁션은 live head 를 거부한다.** 그것은 Store 계약이고 (DB 가 강제한다),
이 레이어는 그 거부를 **결과 타입으로 번역한다** — 404 가 아니라 409 다.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from ma_domain.errors import InvariantViolation
from ma_domain.ids import MemoryId, MemoryStoreId
from ma_domain.memory import Memory, MemoryVersion, validate_write
from ma_domain.memory import MemoryStore as MemoryStoreEntity
from ma_store._results import ListQuery

if TYPE_CHECKING:
    from ma_domain.clock import Clock, IdGenerator
    from ma_domain.ids import MemoryVersionId, WorkspaceId
    from ma_store._results import Cursor, Page
    from ma_store.memory import MemoryDocumentStore, MemoryStoreStore

#: 스토어 이름 상한.
MAX_STORE_NAME = 100

#: 한 워크스페이스의 스토어 수 상한. slug 충돌 검사를 한 페이지로 끝내기
#: 위한 값이기도 하다 — 넘으면 검사가 **조용히 불완전해진다**.
MAX_STORES = 200


# ── 결과 — 예외가 아니라 union ───────────────────────────
@dataclass(frozen=True, slots=True)
class StoreCreated:
    store: MemoryStoreEntity


@dataclass(frozen=True, slots=True)
class StoreArchived:
    store: MemoryStoreEntity


@dataclass(frozen=True, slots=True)
class SlugTaken:
    slug: str


@dataclass(frozen=True, slots=True)
class StoreMissing:
    store_id: MemoryStoreId


@dataclass(frozen=True, slots=True)
class StoreInvalid:
    reasons: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class MemoryWritten:
    memory: Memory
    version: MemoryVersion


@dataclass(frozen=True, slots=True)
class MemoryConflict:
    """CAS 가 어긋났다. **지금 내용을 함께 준다** — 클라이언트가 다시
    GET 하면 그 사이에 또 바뀐다."""

    path: str
    current: Memory | None


@dataclass(frozen=True, slots=True)
class MemoryInvalid:
    reasons: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class MemoryMissing:
    memory_id: MemoryId


@dataclass(frozen=True, slots=True)
class VersionRedacted:
    version_id: MemoryVersionId


@dataclass(frozen=True, slots=True)
class RedactionRefused:
    """**live head 는 레댁션하지 않는다.**

    지우려면 먼저 덮어써서 head 를 옮긴다. 그 두 단계를 한 번에 해 주면
    "감사 기록을 지웠더니 현재 값도 사라졌다"가 된다.
    """

    version_id: MemoryVersionId
    reason: str = "live head 는 레댁션할 수 없다"


type CreateStoreResult = StoreCreated | SlugTaken | StoreInvalid
type ArchiveStoreResult = StoreArchived | StoreMissing
type WriteResult = MemoryWritten | MemoryConflict | MemoryInvalid | StoreMissing
type DeleteResult = MemoryMissing | None
type RedactResult = VersionRedacted | RedactionRefused


# ── 입력 ─────────────────────────────────────────────────
@dataclass(frozen=True, slots=True)
class CreateStore:
    workspace_id: WorkspaceId
    name: str
    slug: str


@dataclass(frozen=True, slots=True)
class WriteMemoryInput:
    workspace_id: WorkspaceId
    store_id: MemoryStoreId
    path: str
    content: str
    author: str
    #: `None` 이면 "신규여야 한다". 생략이 아니라 **주장**이다.
    precondition_sha256: str | None = None


# ── 유스케이스 ───────────────────────────────────────────
@dataclass
class MemoryUseCases:
    stores: MemoryStoreStore
    docs: MemoryDocumentStore
    clock: Clock
    ids: IdGenerator

    # 스토어 ----------------------------------------------
    async def create_store(self, cmd: CreateStore) -> CreateStoreResult:
        name = cmd.name.strip()
        if not name or len(name) > MAX_STORE_NAME:
            return StoreInvalid(reasons=(f"이름은 1~{MAX_STORE_NAME}자다",))

        existing = await self.stores.find_by_slug(cmd.workspace_id, cmd.slug)
        if existing is not None:
            return SlugTaken(slug=cmd.slug)

        from ma_store.memory import InsertMemoryStore

        try:
            made = await self.stores.insert(
                InsertMemoryStore(
                    id=MemoryStoreId(self.ids.next("memory_store")),
                    workspace_id=cmd.workspace_id,
                    name=name,
                    slug=cmd.slug,
                    now=self.clock.now(),
                )
            )
        except InvariantViolation as exc:
            # slug 규칙은 도메인이 쥐고 있다. **여기서 정규식을 다시 쓰지
            # 않는다** — 두 벌이 되면 갈라진다.
            return StoreInvalid(reasons=(str(exc),))
        return StoreCreated(store=made)

    async def find_store(
        self, workspace_id: WorkspaceId, store_id: MemoryStoreId
    ) -> MemoryStoreEntity | None:
        return await self.stores.find(workspace_id, store_id)

    async def list_stores(
        self, workspace_id: WorkspaceId, *, limit: int = 50, after: Cursor | None = None
    ) -> Page[MemoryStoreEntity]:
        return await self.stores.list_stores(
            ListQuery(workspace_id=workspace_id, limit=limit, after=after)
        )

    async def archive_store(
        self, workspace_id: WorkspaceId, store_id: MemoryStoreId
    ) -> ArchiveStoreResult:
        ok = await self.stores.archive(workspace_id, store_id, self.clock.now())
        if not ok:
            return StoreMissing(store_id=store_id)
        got = await self.stores.find(workspace_id, store_id)
        if got is None:  # pragma: no cover — 방금 아카이브한 것이 사라졌다
            return StoreMissing(store_id=store_id)
        return StoreArchived(store=got)

    # 문서 ------------------------------------------------
    async def write(self, cmd: WriteMemoryInput) -> WriteResult:
        try:
            validate_write(cmd.path, cmd.content)
        except InvariantViolation as exc:
            # **Store 에 닿기 전에 번역한다.** Store 가 던지면 그것은
            # 500 이 되고, 경로 오타가 서버 장애로 보고된다.
            return MemoryInvalid(reasons=(str(exc),))

        store = await self.stores.find(cmd.workspace_id, cmd.store_id)
        if store is None or store.archived_at is not None:
            return StoreMissing(store_id=cmd.store_id)

        from ma_store.memory import WriteMemory, WrittenMemory

        result = await self.docs.write(
            WriteMemory(
                id=MemoryId(self.ids.next("memory")),
                workspace_id=cmd.workspace_id,
                store_id=cmd.store_id,
                path=cmd.path,
                content=cmd.content,
                author=cmd.author,
                now=self.clock.now(),
                precondition_sha256=cmd.precondition_sha256,
            )
        )
        if isinstance(result, WrittenMemory):
            return MemoryWritten(memory=result.memory, version=result.version)

        # `PathConflict` · `VersionConflict` · `NotFound` 를 **하나로 접는다.**
        # 셋 다 "네가 아는 상태가 지금 상태가 아니다"이고, 클라이언트가
        # 할 일은 셋 다 같다 — 지금 내용을 보고 다시 쓴다. 구분해서
        # 돌려주면 그 셋이 API 계약이 되고, 구현을 못 바꾸게 된다.
        current = await self.docs.find_by_path(cmd.workspace_id, cmd.store_id, cmd.path)
        return MemoryConflict(path=cmd.path, current=current)

    async def find(self, workspace_id: WorkspaceId, memory_id: MemoryId) -> Memory | None:
        return await self.docs.find(workspace_id, memory_id)

    async def find_by_path(
        self, workspace_id: WorkspaceId, store_id: MemoryStoreId, path: str
    ) -> Memory | None:
        return await self.docs.find_by_path(workspace_id, store_id, path)

    async def list_in_store(
        self,
        workspace_id: WorkspaceId,
        store_id: MemoryStoreId,
        *,
        limit: int = 50,
        after: Cursor | None = None,
    ) -> Page[Memory]:
        return await self.docs.list_in_store(
            ListQuery(workspace_id=workspace_id, limit=limit, after=after), store_id
        )

    async def delete(self, workspace_id: WorkspaceId, memory_id: MemoryId) -> DeleteResult:
        ok = await self.docs.delete(workspace_id, memory_id, self.clock.now())
        return None if ok else MemoryMissing(memory_id=memory_id)

    # 감사 ------------------------------------------------
    async def list_versions(
        self,
        workspace_id: WorkspaceId,
        store_id: MemoryStoreId,
        *,
        limit: int = 50,
        after: Cursor | None = None,
    ) -> Page[MemoryVersion]:
        return await self.docs.list_versions(
            ListQuery(workspace_id=workspace_id, limit=limit, after=after), store_id
        )

    async def redact_version(
        self, workspace_id: WorkspaceId, version_id: MemoryVersionId, by: str
    ) -> RedactResult:
        ok = await self.docs.redact_version(workspace_id, version_id, by, self.clock.now())
        if not ok:
            # **없는 버전과 live head 를 같은 결과로 묶는다.** 구분하면
            # "이 해시의 head 가 존재하는가"를 묻는 오라클이 된다.
            return RedactionRefused(version_id=version_id)
        return VersionRedacted(version_id=version_id)


__all__ = [
    "MAX_STORES",
    "MAX_STORE_NAME",
    "ArchiveStoreResult",
    "CreateStore",
    "CreateStoreResult",
    "DeleteResult",
    "MemoryConflict",
    "MemoryInvalid",
    "MemoryMissing",
    "MemoryUseCases",
    "MemoryWritten",
    "RedactResult",
    "RedactionRefused",
    "SlugTaken",
    "StoreArchived",
    "StoreCreated",
    "StoreInvalid",
    "StoreMissing",
    "VersionRedacted",
    "WriteMemoryInput",
    "WriteResult",
]
