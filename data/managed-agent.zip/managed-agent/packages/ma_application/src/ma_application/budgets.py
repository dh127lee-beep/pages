"""예산·사용량·쿼터 유스케이스 (P4).

`plan/05-database.md` §3 G10 · `plan/06-harness-and-model.md` §5 ·
`plan/04-api.md` §7 · `task/M3-security-governance/T-0405-budget-usage.md`
· `IMPL-0023`.

세 가지를 한다.

```
세션 생성 전  admit()    쿼터 + 워크스페이스 예산 → 409 아니면 세션 상한
턴이 끝날 때  accrue()   usage_events 적립 + 세션 상한 판정
조회          summary()  기간·에이전트별 집계
```

> **상한 도달은 일시정지지 종료가 아니다.** `accrue()` 가 돌려주는
> `budget_reached` 를 하네스가 `StopReason.BUDGET_REACHED` 로 쓴다.
> 예산을 올리면 **같은 세션이 이어서** 돈다.
"""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from typing import TYPE_CHECKING

from ma_domain.governance import Budget, BudgetPeriod, BudgetScope, UsageEvent
from ma_governance.budget import (
    Check,
    Verdict,
    evaluate,
    period_window,
    session_limit,
    strictest,
)
from ma_governance.quota import QuotaCheck, QuotaKind
from ma_governance.quota import check as quota_check

if TYPE_CHECKING:
    from datetime import datetime

    from ma_domain.clock import Clock
    from ma_domain.ids import AgentId, ModelCardId, SessionId, WorkspaceId
    from ma_domain.models import TokenUsage
    from ma_store._results import Cursor, Page
    from ma_store.governance import BudgetStore, UsageStore


# ── 결과 ─────────────────────────────────────────────────
@dataclass(frozen=True, slots=True)
class Admitted:
    """세션을 열어도 된다. **상한이 함께 온다.**"""

    session_limit_cents: int
    #: 80% 를 넘은 예산들. 막지는 않지만 알린다.
    warnings: tuple[Check, ...] = ()


@dataclass(frozen=True, slots=True)
class BudgetExceeded:
    """**409 다** (429 아님) — 재시도해도 안 된다."""

    check: Check


@dataclass(frozen=True, slots=True)
class QuotaExceeded:
    check: QuotaCheck


type AdmitResult = Admitted | BudgetExceeded | QuotaExceeded


@dataclass(frozen=True, slots=True)
class Accrued:
    """적립 결과. **`budget_reached` 가 하네스에게 가는 신호다.**"""

    cost_cents: Decimal
    session_spent_cents: int
    budget_reached: bool
    warning: Check | None = None


@dataclass(frozen=True, slots=True)
class UsageSummary:
    since: datetime
    until: datetime
    total_cents: Decimal
    #: 캐시 히트/미스를 나눠 보여 준다 — `plan/06` §5 의 지렛대다.
    cache_hit_tokens: int = 0
    cache_miss_tokens: int = 0
    output_tokens: int = 0
    events: int = 0
    #: off-peak 로 쓴 비용. **토큰이 아니라 돈이다** — 할인이 토큰 수가
    #: 아니라 단가에 붙으므로, 토큰 비율은 절감액을 말해 주지 않는다.
    off_peak_cents: Decimal = Decimal(0)

    @property
    def off_peak_ratio(self) -> Decimal:
        """off-peak 지출 비율. **off-peak 가 peak 의 1/2 이다** (D12b).

        이 비율을 올리는 것이 캐시 다음가는 지렛대이고, 그래서 대시보드에
        1급으로 올린다.
        """
        return Decimal(0) if self.total_cents == 0 else self.off_peak_cents / self.total_cents

    @property
    def cache_hit_ratio(self) -> Decimal:
        """**이 숫자가 비용 설계의 핵심이다.**

        캐시 히트가 미스의 1/50 이므로, 이 비율이 0.9 와 0.5 일 때
        같은 토큰 수의 비용이 몇 배 차이난다.
        """
        total = self.cache_hit_tokens + self.cache_miss_tokens
        return Decimal(0) if total == 0 else Decimal(self.cache_hit_tokens) / Decimal(total)


# ── 입력 ─────────────────────────────────────────────────
@dataclass(frozen=True, slots=True)
class AdmitSession:
    workspace_id: WorkspaceId
    #: 지금 돌고 있는 세션 수. 호출자가 센다 — 세는 방법이 배포마다 다르다.
    concurrent_sessions: int = 0
    sessions_today: int = 0
    agent_id: AgentId | None = None
    #: 클라이언트가 요청한 세션 상한. **예산의 기본값을 넘을 수 없다.**
    requested_limit_cents: int | None = None


@dataclass(frozen=True, slots=True)
class Accrue:
    workspace_id: WorkspaceId
    session_id: SessionId
    model_card_id: ModelCardId
    wire_model: str
    usage: TokenUsage
    #: **그 시점 요금으로 계산한 값.** 여기서 다시 계산하지 않는다 —
    #: 호출자(하네스)가 카드를 들고 있다.
    cost_cents: Decimal
    session_limit_cents: int
    session_spent_cents: int
    agent_id: AgentId | None = None
    thread_id: str | None = None
    sandbox_seconds: int = 0
    #: 이 턴이 off-peak 였는가. **호출자가 카드를 들고 판단한다** —
    #: `cost_cents` 와 같은 이유다 (여기서 다시 계산하면 peak 창이
    #: 바뀌었을 때 과거가 소급해 재해석된다).
    off_peak: bool = False


@dataclass
class BudgetsUseCases:
    budgets: BudgetStore
    usage: UsageStore
    clock: Clock

    # ── 세션 생성 전 ─────────────────────────────────────
    async def admit(self, cmd: AdmitSession) -> AdmitResult:
        """쿼터와 예산을 보고 세션을 열지 정한다.

        **순서가 의미를 갖는다.** 쿼터를 먼저 본다 — 쿼터는 세는 것이
        싸고(이미 가진 숫자), 예산은 집계 질의가 필요하다.
        """
        for kind, used in (
            (QuotaKind.CONCURRENT_SESSIONS, cmd.concurrent_sessions),
            (QuotaKind.DAILY_SESSIONS, cmd.sessions_today),
        ):
            got = quota_check(kind, used=used)
            if not got.ok:
                return QuotaExceeded(check=got)

        declared = await self.budgets.list_budgets(cmd.workspace_id)
        checks = await self._spend_checks(cmd.workspace_id, declared, cmd.agent_id)
        worst = strictest(checks)
        if worst.verdict is Verdict.EXCEEDED:
            return BudgetExceeded(check=worst)

        return Admitted(
            session_limit_cents=session_limit(declared, requested=cmd.requested_limit_cents),
            warnings=tuple(c for c in checks if c.verdict is Verdict.WARN),
        )

    async def _spend_checks(
        self,
        workspace_id: WorkspaceId,
        declared: tuple[Budget, ...],
        agent_id: AgentId | None,
    ) -> tuple[Check, ...]:
        """선언된 예산마다 현재 지출을 재어 판정한다.

        **`hard=False` 는 판정에서 뺀다** — 경고만 하는 예산이고, 막으면
        그 플래그가 의미를 잃는다.
        """
        now = self.clock.now()
        out: list[Check] = []
        for budget in declared:
            if budget.scope is BudgetScope.AGENT and budget.scope_id != agent_id:
                continue
            if budget.scope is BudgetScope.USER:
                # 사용자 스코프는 **호출자가 누구인지** 알아야 한다.
                # `admit` 에 그 정보가 없으므로 지금은 건너뛴다.
                # TODO(T-0504): principal 을 받아 사용자 예산도 본다.
                continue

            since, until = period_window(budget.period, now)
            spent = await self.usage.sum_cost_cents(
                workspace_id,
                since,
                until,
                agent_id=budget.scope_id if budget.scope is BudgetScope.AGENT else None,
            )
            got = evaluate(
                limit_cents=budget.limit_cents,
                spent_cents=int(spent),
                scope=f"{budget.scope.value}/{budget.period.value}",
            )
            if got.verdict is Verdict.EXCEEDED and not budget.hard:
                # soft 예산은 **경고로 낮춘다.** 막지 않는 것이 그 뜻이다.
                got = Check(
                    verdict=Verdict.WARN,
                    limit_cents=got.limit_cents,
                    spent_cents=got.spent_cents,
                    scope=got.scope + " (soft)",
                )
            out.append(got)
        return tuple(out)

    # ── 턴이 끝날 때 ─────────────────────────────────────
    async def accrue(self, cmd: Accrue) -> Accrued:
        """사용량을 적립하고 **세션 상한에 닿았는지** 돌려준다.

        적립이 먼저다. 판정만 하고 적립을 건너뛰면 그 턴의 비용이
        사라지고, 다음 판정이 느슨해진다.
        """
        now = self.clock.now()
        await self.usage.record(
            UsageEvent(
                workspace_id=cmd.workspace_id,
                session_id=cmd.session_id,
                model_card_id=cmd.model_card_id,
                wire_model=cmd.wire_model,
                usage=cmd.usage,
                list_cost_cents=cmd.cost_cents,
                created_at=now,
                thread_id=cmd.thread_id,
                agent_id=cmd.agent_id,
                sandbox_seconds=cmd.sandbox_seconds,
                off_peak=cmd.off_peak,
            )
        )
        spent = cmd.session_spent_cents + int(cmd.cost_cents)
        got = evaluate(limit_cents=cmd.session_limit_cents, spent_cents=spent, scope="session")
        return Accrued(
            cost_cents=cmd.cost_cents,
            session_spent_cents=spent,
            # **도달은 일시정지지 종료가 아니다.**
            budget_reached=got.verdict is Verdict.EXCEEDED,
            warning=got if got.verdict is Verdict.WARN else None,
        )

    # ── 설정과 조회 ──────────────────────────────────────
    async def set_budget(self, budget: Budget) -> Budget:
        return await self.budgets.upsert(budget)

    async def list_budgets(self, workspace_id: WorkspaceId) -> tuple[Budget, ...]:
        return await self.budgets.list_budgets(workspace_id)

    async def summary(
        self,
        workspace_id: WorkspaceId,
        *,
        period: BudgetPeriod = BudgetPeriod.MONTHLY,
        agent_id: AgentId | None = None,
    ) -> UsageSummary:
        """기간 집계. **캐시 히트/미스를 나눠 돌려준다.**"""
        from ma_store._results import ListQuery

        since, until = period_window(period, self.clock.now())
        total = await self.usage.sum_cost_cents(workspace_id, since, until, agent_id=agent_id)

        page = await self.usage.list_events(
            ListQuery(
                workspace_id=workspace_id,
                limit=200,
                created_at_gte=since,
                created_at_lte=until,
            )
        )
        rows = [e for e in page.items if agent_id is None or e.agent_id == agent_id]
        return UsageSummary(
            since=since,
            until=until,
            total_cents=total,
            cache_hit_tokens=sum(e.usage.input_cache_hit for e in rows),
            cache_miss_tokens=sum(e.usage.input_cache_miss for e in rows),
            output_tokens=sum(e.usage.output for e in rows),
            # **행에 박힌 값을 쓴다.** 여기서 peak 창으로 다시 계산하면
            # 창이 바뀌었을 때 과거가 소급해 재해석된다.
            off_peak_cents=sum((e.list_cost_cents for e in rows if e.off_peak), Decimal(0)),
            events=len(rows),
        )

    async def list_events(
        self,
        workspace_id: WorkspaceId,
        *,
        limit: int = 50,
        after: Cursor | None = None,
        since: datetime | None = None,
        until: datetime | None = None,
    ) -> Page[UsageEvent]:
        from ma_store._results import ListQuery

        return await self.usage.list_events(
            ListQuery(
                workspace_id=workspace_id,
                limit=limit,
                after=after,
                created_at_gte=since,
                created_at_lte=until,
            )
        )


__all__ = [
    "Accrue",
    "Accrued",
    "AdmitResult",
    "AdmitSession",
    "Admitted",
    "BudgetExceeded",
    "BudgetsUseCases",
    "QuotaExceeded",
    "UsageSummary",
]
