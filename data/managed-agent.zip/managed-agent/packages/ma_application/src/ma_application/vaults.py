"""볼트·자격증명 유스케이스 — **평문이 이 레이어를 "지나가기만" 한다.**

`plan/04-api.md` §3.5 · `plan/05-database.md` §3 G6 · `plan/03-layers.md` §3 L4.

여기 있는 것: 검증 · 이름 충돌 · 결과 union.
여기 **없는** 것: 암복호화 · SQL · HTTP · cipher.

**cipher 를 들지 않는 것이 요점이다** (`plan/03` §3 L2). 유스케이스가 평문을
받아 Store 에 넘기고 끝이다 — 암호화는 Store 구현이 생성자로 받은 cipher 가
한다. 이 레이어에 cipher 가 들어오면 "어떤 유스케이스가 평문을 만질 수
있는가"가 추적 불가능해진다. `.importlinter` 가 `ma_application` →
`cryptography` 를 금지해 그것을 기계적으로 막는다.

**돌려주는 것에 평문이 없다.** 입력 dataclass 에만 `secret` 이 있고, 결과
타입에는 필드 자체가 없다.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from ma_domain.ids import CredentialId, VaultId
from ma_domain.vaults import CredentialKind, CredentialMeta, Vault
from ma_store._results import ListQuery

if TYPE_CHECKING:
    from datetime import datetime

    from ma_domain.clock import Clock, IdGenerator
    from ma_domain.ids import UserId, WorkspaceId
    from ma_store._results import Cursor, Page
    from ma_store.credentials import CredentialStore
    from ma_store.vaults import VaultStore

#: 볼트 이름 상한. DB 는 TEXT 지만 UI 와 로그가 감당할 길이는 따로 있다.
MAX_VAULT_NAME = 100

#: 자격증명 하나가 가질 수 있는 호스트 수. 넘으면 보통 설정 실수다
#: ("전부 매칭"을 호스트 나열로 흉내 내려는 것).
MAX_MATCH_HOSTS = 32


# ── 결과 — 예외가 아니라 union ───────────────────────────
@dataclass(frozen=True, slots=True)
class VaultCreated:
    vault: Vault


@dataclass(frozen=True, slots=True)
class VaultArchived:
    """**아카이브된 레코드를 돌려준다.** id 만 주지 않는다.

    클라이언트가 `archived_at` 을 보려면 다시 GET 해야 하고, 그 왕복에서
    다른 사람의 변경이 끼어든다. 에이전트 아카이브와 같은 모양이다.
    """

    vault: Vault


@dataclass(frozen=True, slots=True)
class VaultNameTaken:
    name: str


@dataclass(frozen=True, slots=True)
class VaultMissing:
    vault_id: VaultId


@dataclass(frozen=True, slots=True)
class CredentialCreated:
    """**평문 필드가 없다.** 만든 직후에도 돌려주지 않는다.

    "방금 만들었으니 한 번은 보여 줘도 되지 않나"가 가장 흔한 누출 경로다 —
    그 응답이 로그·프록시 캐시·브라우저 히스토리에 남는다.
    """

    credential: CredentialMeta


@dataclass(frozen=True, slots=True)
class CredentialRotated:
    credential: CredentialMeta


@dataclass(frozen=True, slots=True)
class CredentialArchivedResult:
    credential: CredentialMeta


@dataclass(frozen=True, slots=True)
class CredentialMissing:
    credential_id: CredentialId


@dataclass(frozen=True, slots=True)
class CredentialInvalid:
    reasons: tuple[str, ...]


type CreateVaultResult = VaultCreated | VaultNameTaken
type ArchiveVaultResult = VaultArchived | VaultMissing
type CreateCredentialResult = CredentialCreated | VaultMissing | CredentialInvalid
type RotateCredentialResult = CredentialRotated | CredentialMissing | CredentialInvalid
type ArchiveCredentialResult = CredentialArchivedResult | CredentialMissing


# ── 입력 ─────────────────────────────────────────────────
@dataclass(frozen=True, slots=True)
class CreateVault:
    workspace_id: WorkspaceId
    name: str


@dataclass(frozen=True, slots=True)
class CreateCredential:
    """**평문을 받는 유일한 입력.** 그대로 Store 에 넘기고 잊는다."""

    workspace_id: WorkspaceId
    vault_id: VaultId
    kind: CredentialKind
    secret: str
    created_by: UserId
    match_hosts: tuple[str, ...] = ()
    mcp_server_name: str | None = None
    header_name: str | None = None
    expires_at: datetime | None = None


@dataclass(frozen=True, slots=True)
class RotateCredentialInput:
    workspace_id: WorkspaceId
    credential_id: CredentialId
    secret: str
    expires_at: datetime | None = None


# ── 유스케이스 ───────────────────────────────────────────
@dataclass
class VaultsUseCases:
    vaults: VaultStore
    credentials: CredentialStore
    clock: Clock
    ids: IdGenerator

    # 볼트 ------------------------------------------------
    async def create_vault(self, cmd: CreateVault) -> CreateVaultResult:
        name = cmd.name.strip()
        if not name or len(name) > MAX_VAULT_NAME:
            return VaultNameTaken(name=cmd.name)

        # 이름 충돌을 **미리 본다.** DB 의 부분 유니크 인덱스가 최종
        # 방어선이지만, 거기서 걸리면 409 가 아니라 500 이 된다.
        existing = await self.vaults.list_vaults(
            ListQuery(workspace_id=cmd.workspace_id, limit=200)
        )
        if any(v.name == name for v in existing.items):
            return VaultNameTaken(name=name)

        from ma_store.vaults import InsertVault

        made = await self.vaults.insert(
            InsertVault(
                id=VaultId(self.ids.next("vault")),
                workspace_id=cmd.workspace_id,
                name=name,
                now=self.clock.now(),
            )
        )
        return VaultCreated(vault=made)

    async def find_vault(self, workspace_id: WorkspaceId, vault_id: VaultId) -> Vault | None:
        return await self.vaults.find(workspace_id, vault_id)

    async def list_vaults(
        self, workspace_id: WorkspaceId, *, limit: int = 50, after: Cursor | None = None
    ) -> Page[Vault]:
        return await self.vaults.list_vaults(
            ListQuery(workspace_id=workspace_id, limit=limit, after=after)
        )

    async def archive_vault(
        self, workspace_id: WorkspaceId, vault_id: VaultId
    ) -> ArchiveVaultResult:
        ok = await self.vaults.archive(workspace_id, vault_id, self.clock.now())
        if not ok:
            return VaultMissing(vault_id=vault_id)
        # 아카이브 **직후**를 다시 읽는다. `archive()` 가 bool 인 것은
        # Store 계약이고, 거기에 레코드를 얹으면 두 구현이 "무엇을 돌려
        # 주는가"로 또 갈린다.
        got = await self.vaults.find(workspace_id, vault_id)
        if got is None:  # pragma: no cover — 방금 아카이브한 것이 사라졌다
            return VaultMissing(vault_id=vault_id)
        return VaultArchived(vault=got)

    # 자격증명 --------------------------------------------
    async def create_credential(self, cmd: CreateCredential) -> CreateCredentialResult:
        reasons = validate_credential(
            kind=cmd.kind,
            match_hosts=cmd.match_hosts,
            header_name=cmd.header_name,
            mcp_server_name=cmd.mcp_server_name,
            secret=cmd.secret,
        )
        if reasons:
            return CredentialInvalid(reasons=reasons)

        vault = await self.vaults.find(cmd.workspace_id, cmd.vault_id)
        if vault is None or vault.archived_at is not None:
            return VaultMissing(vault_id=cmd.vault_id)

        from ma_store.credentials import InsertCredential

        made = await self.credentials.insert(
            InsertCredential(
                id=CredentialId(self.ids.next("credential")),
                workspace_id=cmd.workspace_id,
                vault_id=cmd.vault_id,
                kind=cmd.kind,
                secret=cmd.secret,
                created_by=cmd.created_by,
                now=self.clock.now(),
                match_hosts=cmd.match_hosts,
                mcp_server_name=cmd.mcp_server_name,
                header_name=cmd.header_name,
                expires_at=cmd.expires_at,
            )
        )
        return CredentialCreated(credential=made)

    async def list_credentials(
        self,
        workspace_id: WorkspaceId,
        vault_id: VaultId,
        *,
        limit: int = 50,
        after: Cursor | None = None,
    ) -> Page[CredentialMeta]:
        return await self.credentials.list_in_vault(
            ListQuery(workspace_id=workspace_id, limit=limit, after=after), vault_id
        )

    async def rotate_credential(self, cmd: RotateCredentialInput) -> RotateCredentialResult:
        if not cmd.secret:
            return CredentialInvalid(reasons=("비밀이 비었다",))

        from ma_store.credentials import RotateCredential

        got = await self.credentials.rotate(
            RotateCredential(
                workspace_id=cmd.workspace_id,
                id=cmd.credential_id,
                secret=cmd.secret,
                now=self.clock.now(),
                expires_at=cmd.expires_at,
            )
        )
        if got is None:
            return CredentialMissing(credential_id=cmd.credential_id)
        return CredentialRotated(credential=got)

    async def archive_credential(
        self, workspace_id: WorkspaceId, credential_id: CredentialId
    ) -> ArchiveCredentialResult:
        ok = await self.credentials.archive(workspace_id, credential_id, self.clock.now())
        if not ok:
            return CredentialMissing(credential_id=credential_id)
        got = await self.credentials.find(workspace_id, credential_id)
        if got is None:  # pragma: no cover
            return CredentialMissing(credential_id=credential_id)
        return CredentialArchivedResult(credential=got)


def validate_credential(
    *,
    kind: CredentialKind,
    match_hosts: tuple[str, ...],
    header_name: str | None,
    mcp_server_name: str | None,
    secret: str,
) -> tuple[str, ...]:
    """**생성 시점에 막는다.** 런타임에 조용히 안 맞으면 추적할 수 없다.

    `CredentialMeta.__post_init__` 도 일부를 보지만 그것은 `InvariantViolation`
    (500)이다. 사용자 입력 오류는 400 이어야 하므로 여기서 먼저 본다.
    """
    reasons: list[str] = []
    if not secret:
        reasons.append("비밀이 비었다")
    if kind is CredentialKind.API_KEY_HEADER and not header_name:
        reasons.append("api_key_header 에는 header_name 이 필요하다")
    if kind is CredentialKind.MCP_OAUTH and not mcp_server_name:
        reasons.append("mcp_oauth 에는 mcp_server_name 이 필요하다")
    if len(match_hosts) > MAX_MATCH_HOSTS:
        reasons.append(f"match_hosts 는 최대 {MAX_MATCH_HOSTS}개다")
    for host in match_hosts:
        if not host or host.startswith(".") or "/" in host or ":" in host:
            reasons.append(f"잘못된 호스트: {host!r}")
    # **환경변수 자격증명에 호스트를 거는 것은 의미가 없다.** 주입 대상이
    # 호스트가 아니라 프로세스 환경이다. 받아 주면 설정한 사람이 그것으로
    # 범위가 좁혀진다고 믿는다.
    if kind is CredentialKind.ENVIRONMENT_VARIABLE and match_hosts:
        reasons.append("environment_variable 에는 match_hosts 를 걸 수 없다")
    return tuple(reasons)


__all__ = [
    "MAX_MATCH_HOSTS",
    "MAX_VAULT_NAME",
    "ArchiveCredentialResult",
    "ArchiveVaultResult",
    "CreateCredential",
    "CreateCredentialResult",
    "CreateVault",
    "CreateVaultResult",
    "CredentialArchivedResult",
    "CredentialCreated",
    "CredentialInvalid",
    "CredentialMissing",
    "CredentialRotated",
    "RotateCredentialInput",
    "RotateCredentialResult",
    "VaultArchived",
    "VaultCreated",
    "VaultMissing",
    "VaultNameTaken",
    "VaultsUseCases",
    "validate_credential",
]
