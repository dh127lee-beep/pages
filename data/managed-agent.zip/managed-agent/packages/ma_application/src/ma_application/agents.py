"""에이전트 유스케이스.

`plan/03-layers.md` §3 L4.

여기 있는 것: 검증 · 페이지네이션 커서 · CAS 결과 해석.
여기 **없는** 것: SQL · HTTP · pydantic · 특정 DB 방언.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass

from ma_domain.agents import AgentDefinition, AgentRecord
from ma_domain.clock import Clock
from ma_domain.environments import SandboxTier
from ma_domain.errors import InvariantViolation
from ma_domain.ids import AgentId, WorkspaceId
from ma_store._results import (
    Archived,
    Cursor,
    ListQuery,
    NotFound,
    Page,
    Replaced,
    VersionConflict,
)
from ma_store.agents import (
    AgentStore,
    ArchiveAgent,
    FindAgentVersion,
    FindCurrentAgent,
    InsertAgent,
    ListAgentVersions,
    ReplaceAgent,
)


# ── 유스케이스 결과 — 예외가 아니라 union ────────────────────
@dataclass(frozen=True, slots=True)
class AgentCreated:
    agent: AgentRecord


@dataclass(frozen=True, slots=True)
class AgentUpdated:
    agent: AgentRecord


@dataclass(frozen=True, slots=True)
class AgentArchived:
    agent: AgentRecord


@dataclass(frozen=True, slots=True)
class AgentNotFound:
    agent_id: AgentId


@dataclass(frozen=True, slots=True)
class AgentConflict:
    actual_version: int


@dataclass(frozen=True, slots=True)
class AgentInvalid:
    """설정 자체가 틀렸다. `POST /agents/{id}/validate`가 이것만 돌려준다."""

    reasons: tuple[str, ...]


type CreateResult = AgentCreated | AgentInvalid
type UpdateResult = AgentUpdated | AgentNotFound | AgentConflict | AgentInvalid
type ArchiveResult = AgentArchived | AgentNotFound | AgentConflict


class AgentsUseCases:
    """`plan/03-layers.md` §4 — 좁은 Store Port 하나만 받는다."""

    def __init__(
        self,
        *,
        workspace_id: WorkspaceId,
        clock: Clock,
        store: AgentStore,
        next_id: Callable[[], str],
    ) -> None:
        self._ws = workspace_id
        self._clock = clock
        self._store = store
        self._next_id = next_id

    # ── 검증 ────────────────────────────────────────────────
    def validate(
        self, definition: AgentDefinition, *, tier: SandboxTier | None = None
    ) -> tuple[str, ...]:
        """저장 전 린트. 도메인 불변식은 생성자가 이미 막았으므로,
        여기서는 **생성자가 모르는 것**(다른 리소스와의 관계)만 본다.

        `tier` 를 주면 **샌드박스 티어와의 모순**까지 본다. 그것이
        `POST /agents/{id}/validate` 의 존재 이유다: 티어 W 에 `bash` 를
        켜 두면 세션 **생성 시점**에 `SandboxUnavailable` 로 죽는데,
        그때는 이미 사용자가 "왜 안 되지"를 쫓고 있다. 편집 시점에
        잡아야 고칠 자리가 눈앞에 있다 (`T-0504` 구현 지침).
        """
        reasons: list[str] = []
        if definition.toolset is None and not definition.custom_tools:
            reasons.append("툴이 하나도 없다 — 에이전트가 아무것도 할 수 없다")
        if definition.harness not in ("default", "dsh", "acp"):
            reasons.append(f"모르는 하네스: {definition.harness}")
        for s in definition.mcp_servers:
            if not s.url.startswith("https://"):
                reasons.append(f"MCP 서버 URL은 https 여야 한다: {s.name}")
        if tier is not None and definition.needs_shell and not tier.can_run_shell:
            reasons.append(
                f"티어 {tier.value} 는 셸을 제공하지 않는다 — "
                "`bash` 를 끄거나 티어 P(process) 를 쓰십시오"
            )
        return tuple(reasons)

    # ── 명령 ────────────────────────────────────────────────
    async def create(self, definition: AgentDefinition, *, created_by: str) -> CreateResult:
        reasons = self.validate(definition)
        if reasons:
            return AgentInvalid(reasons=reasons)
        rec = await self._store.insert(
            InsertAgent(
                id=AgentId(self._next_id()),
                workspace_id=self._ws,
                definition=definition,
                created_by=created_by,
                now=self._clock.now(),
            )
        )
        return AgentCreated(agent=rec)

    async def update(
        self, agent_id: AgentId, definition: AgentDefinition, *, expected_version: int
    ) -> UpdateResult:
        reasons = self.validate(definition)
        if reasons:
            return AgentInvalid(reasons=reasons)
        res = await self._store.replace_current(
            ReplaceAgent(
                workspace_id=self._ws,
                id=agent_id,
                definition=definition,
                expected_version=expected_version,
                now=self._clock.now(),
            )
        )
        match res:
            case Replaced(record=rec):
                return AgentUpdated(agent=rec)
            case VersionConflict(actual_version=v):
                return AgentConflict(actual_version=v)
            case NotFound():
                return AgentNotFound(agent_id=agent_id)
        raise InvariantViolation(f"처리하지 않은 Store 결과: {res!r}")  # pragma: no cover

    async def archive(self, agent_id: AgentId, *, expected_version: int) -> ArchiveResult:
        res = await self._store.archive_current(
            ArchiveAgent(
                workspace_id=self._ws,
                id=agent_id,
                expected_version=expected_version,
                now=self._clock.now(),
            )
        )
        match res:
            case Archived(record=rec):
                return AgentArchived(agent=rec)
            case VersionConflict(actual_version=v):
                return AgentConflict(actual_version=v)
            case NotFound():
                return AgentNotFound(agent_id=agent_id)
        raise InvariantViolation(f"처리하지 않은 Store 결과: {res!r}")  # pragma: no cover

    # ── 조회 ────────────────────────────────────────────────
    async def get(self, agent_id: AgentId) -> AgentRecord | None:
        return await self._store.find_current(FindCurrentAgent(self._ws, agent_id))

    async def get_version(self, agent_id: AgentId, version: int) -> AgentRecord | None:
        return await self._store.find_version(FindAgentVersion(self._ws, agent_id, version))

    async def list(
        self, *, limit: int = 50, after: str | None = None, include_archived: bool = False
    ) -> Page[AgentRecord]:
        cursor = Cursor.decode(after) if after else None
        return await self._store.list_current(
            ListQuery(
                workspace_id=self._ws,
                limit=limit,
                after=cursor,
                include_archived=include_archived,
            )
        )

    async def list_versions(self, agent_id: AgentId, *, limit: int = 50) -> Page[AgentRecord]:
        return await self._store.list_versions(ListAgentVersions(self._ws, agent_id, limit))
