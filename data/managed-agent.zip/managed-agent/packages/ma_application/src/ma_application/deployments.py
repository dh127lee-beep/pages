"""배포 유스케이스 — cron · off-peak (T-0603).

`plan/06-harness-and-model.md` §5.4 · `plan/05-database.md` §3 G9.

> **peak 창을 코드에 박지 않는다.** 배포 → 핀한 에이전트 → `ModelResolver`
> → 모델 카드의 `pricing.peak_windows` 로 읽는다. provider 가 요금 시간대를
> 바꾸면 카드만 고친다 (D12).

여기 있는 것: cron 해석 · off-peak 이동 결정 · 발화 조율.
여기 **없는** 것: 세션 생성 자체. 그것은 호출자(스케줄러)가 하고, 이
유스케이스는 **무엇을 언제 돌릴지**만 정한다.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import TYPE_CHECKING, Any

from ma_domain.cron import CronError, next_fire, next_fires, parse
from ma_domain.deployments import (
    AUTO_PAUSE_AFTER,
    Deployment,
    DeploymentRun,
    DeploymentState,
    PeakWindowSpec,
    RunState,
    RunTrigger,
    Schedule,
    Shift,
    shift_to_off_peak,
)
from ma_store._results import ListQuery
from ma_store.agents import FindAgentVersion
from ma_store.deployments import (
    AlreadyFired,
    ClaimedFire,
    ClaimFire,
    FinishRun,
    InsertDeployment,
    UpdateDeploymentState,
)

from ma_application.models import ModelResolver, ResolvedModel, ResolveModel

if TYPE_CHECKING:
    from ma_domain.clock import Clock, IdGenerator
    from ma_domain.ids import AgentId, EnvironmentId, SessionId, WorkspaceId
    from ma_domain.models import ModelCard
    from ma_store._results import Cursor, Page
    from ma_store.agents import AgentStore
    from ma_store.deployments import DeploymentStore


def windows_from_card(card: ModelCard) -> tuple[PeakWindowSpec, ...]:
    """`ModelCard.pricing.peak_windows` → 도메인 타입.

    **도메인이 카드를 직접 들지 않게** 하는 변환이다. `ma_domain.deployments`
    가 `ma_domain.models` 를 import 하면 배포가 모델을 알게 되고, 모델 카드
    모양이 바뀔 때마다 스케줄링이 흔들린다.
    """
    return tuple(
        PeakWindowSpec(
            start_hour_utc=w.start_hour_utc,
            end_hour_utc=w.end_hour_utc,
            weekdays=tuple(w.weekdays),
        )
        for w in card.pricing.peak_windows
    )


# ── 결과 ─────────────────────────────────────────────────
@dataclass(frozen=True, slots=True)
class DeploymentCreated:
    deployment: Deployment


@dataclass(frozen=True, slots=True)
class DeploymentUpdated:
    deployment: Deployment


@dataclass(frozen=True, slots=True)
class DeploymentMissing:
    deployment_id: str


@dataclass(frozen=True, slots=True)
class DeploymentInvalid:
    reasons: tuple[str, ...]


type CreateDeploymentResult = DeploymentCreated | DeploymentInvalid
type StateChangeResult = DeploymentUpdated | DeploymentMissing


@dataclass(frozen=True, slots=True)
class Fired:
    """발화했다. **세션은 아직 없다** — 호출자가 만든다."""

    deployment: Deployment
    run: DeploymentRun
    shift: Shift


@dataclass(frozen=True, slots=True)
class Deferred:
    """아직 때가 아니다 — off-peak 창으로 밀었다."""

    fire_at: datetime
    reason: str


@dataclass(frozen=True, slots=True)
class Skipped:
    """건너뛰었다. **앞 실행이 아직 돈다.**"""

    reason: str


@dataclass(frozen=True, slots=True)
class AlreadyRan:
    scheduled_for: datetime


type FireResult = Fired | Deferred | Skipped | AlreadyRan | DeploymentMissing


# ── 입력 ─────────────────────────────────────────────────
@dataclass(frozen=True, slots=True)
class CreateDeployment:
    workspace_id: WorkspaceId
    name: str
    agent_id: AgentId
    agent_version: int
    environment_id: EnvironmentId | None = None
    cron: str | None = None
    timezone: str = "UTC"
    off_peak_preferred: bool = False
    max_shift_hours: int = 6
    initial_events: tuple[dict[str, Any], ...] = ()
    #: **실행별** 예산. 워크스페이스 예산과 별개로 이 배포 한 번에 쓸 상한.
    budget_cents: int | None = None
    created_by: str = ""


# ── 유스케이스 ───────────────────────────────────────────
@dataclass
class DeploymentsUseCases:
    deployments: DeploymentStore
    agents: AgentStore
    resolver: ModelResolver
    clock: Clock
    ids: IdGenerator
    #: 겹침 허용 여부. 기본은 **건너뛴다** — 일일 리포트가 겹쳐 돌면 두 통이 간다.
    allow_overlap: bool = False

    async def create(self, cmd: CreateDeployment) -> CreateDeploymentResult:
        reasons: list[str] = []
        if not cmd.name.strip():
            reasons.append("배포 이름이 비었다")
        if cmd.budget_cents is not None and cmd.budget_cents <= 0:
            reasons.append("실행 예산은 양수여야 한다")

        schedule: Schedule | None = None
        if cmd.cron:
            try:
                schedule = Schedule(
                    cron=cmd.cron,
                    timezone=cmd.timezone,
                    off_peak_preferred=cmd.off_peak_preferred,
                    max_shift=timedelta(hours=cmd.max_shift_hours),
                )
            except CronError as exc:
                # **저장 전에 터진다.** cron 오타가 발화 시각에 드러나면
                # 아무도 안 보고 있을 때 조용히 안 돈다.
                reasons.append(str(exc))

        rec = await self.agents.find_version(
            FindAgentVersion(cmd.workspace_id, cmd.agent_id, cmd.agent_version)
        )
        if rec is None:
            # **핀한 버전이 있어야 한다.** 배포는 "현재 버전"이 아니라
            # 특정 버전을 돌린다 — 안 그러면 에이전트를 고친 순간
            # 새벽 3시 배포의 행동이 바뀐다.
            reasons.append(f"에이전트 {cmd.agent_id} v{cmd.agent_version} 를 찾을 수 없다")

        if reasons:
            return DeploymentInvalid(reasons=tuple(reasons))

        now = self.clock.now()
        first = (
            next_fire(parse(schedule.cron), now, timezone=schedule.timezone) if schedule else None
        )
        made = await self.deployments.insert(
            InsertDeployment(
                id=self.ids.next("deployment"),
                workspace_id=cmd.workspace_id,
                name=cmd.name.strip(),
                agent_id=cmd.agent_id,
                agent_version=cmd.agent_version,
                now=now,
                environment_id=cmd.environment_id,
                schedule=schedule,
                initial_events=cmd.initial_events,
                budget_cents=cmd.budget_cents,
                created_by=cmd.created_by,
                next_fire_at=first,
            )
        )
        return DeploymentCreated(deployment=made)

    async def find(self, workspace_id: WorkspaceId, deployment_id: str) -> Deployment | None:
        return await self.deployments.find(workspace_id, deployment_id)

    async def list_deployments(
        self, workspace_id: WorkspaceId, *, limit: int = 50, after: Cursor | None = None
    ) -> Page[Deployment]:
        return await self.deployments.list_deployments(
            ListQuery(workspace_id=workspace_id, limit=limit, after=after)
        )

    async def list_runs(
        self,
        workspace_id: WorkspaceId,
        deployment_id: str,
        *,
        limit: int = 50,
        after: Cursor | None = None,
    ) -> Page[DeploymentRun]:
        return await self.deployments.list_runs(
            ListQuery(workspace_id=workspace_id, limit=limit, after=after), deployment_id
        )

    # ── 상태 ─────────────────────────────────────────────
    async def pause(
        self, workspace_id: WorkspaceId, deployment_id: str, *, reason: str = ""
    ) -> StateChangeResult:
        return await self._set_state(
            workspace_id, deployment_id, DeploymentState.PAUSED, reason=reason
        )

    async def unpause(self, workspace_id: WorkspaceId, deployment_id: str) -> StateChangeResult:
        """다시 켠다. **다음 발화를 지금 기준으로 다시 계산한다.**

        멈춰 있던 동안의 발화를 몰아서 돌리지 않는다 — 일주일 멈췄던
        일일 리포트가 켜는 순간 7통 가면 안 된다.
        """
        got = await self.deployments.find(workspace_id, deployment_id)
        if got is None:
            return DeploymentMissing(deployment_id=deployment_id)
        return await self._set_state(
            workspace_id,
            deployment_id,
            DeploymentState.ACTIVE,
            next_fire_at=self._next_for(got, self.clock.now()),
        )

    async def archive(self, workspace_id: WorkspaceId, deployment_id: str) -> StateChangeResult:
        return await self._set_state(workspace_id, deployment_id, DeploymentState.ARCHIVED)

    async def _set_state(
        self,
        workspace_id: WorkspaceId,
        deployment_id: str,
        state: DeploymentState,
        *,
        reason: str = "",
        next_fire_at: datetime | None = None,
    ) -> StateChangeResult:
        got = await self.deployments.set_state(
            UpdateDeploymentState(
                workspace_id=workspace_id,
                deployment_id=deployment_id,
                state=state,
                now=self.clock.now(),
                reason=reason,
                next_fire_at=next_fire_at,
            )
        )
        if got is None:
            return DeploymentMissing(deployment_id=deployment_id)
        return DeploymentUpdated(deployment=got)

    # ── 발화 ─────────────────────────────────────────────
    async def due(self, limit: int = 50) -> tuple[Deployment, ...]:
        return await self.deployments.due(self.clock.now(), limit=limit)

    async def fire(
        self, deployment: Deployment, *, trigger: RunTrigger = RunTrigger.SCHEDULE
    ) -> FireResult:
        """한 배포를 발화한다. **off-peak 이동이 여기서 일어난다.**

        순서가 의미를 갖는다:

        1. **겹침 검사** — 앞 실행이 도는 중이면 건너뛴다
        2. **off-peak 이동** — peak 안이면 민다 (상한 안에서)
        3. **claim** — 멱등 키로 집는다

        2를 1보다 먼저 하면 겹친 배포의 `next_fire_at` 을 밀어 놓고
        건너뛰게 되어, 다음 창을 한 번 더 잃는다.
        """
        now = self.clock.now()
        scheduled_for = deployment.next_fire_at or now

        if not self.allow_overlap:
            running = await self.deployments.running_count(deployment.workspace_id, deployment.id)
            if running:
                await self._record_skip(deployment, scheduled_for, now)
                return Skipped(reason=f"앞 실행 {running}건이 아직 돈다")

        shift = await self._shift_for(deployment, scheduled_for)
        if shift.moved and shift.at > now:
            # **아직 때가 아니다.** 다음 주기에 다시 본다. 이동한 시각을
            # `next_fire_at` 에 써 두므로 `due()` 가 그때까지 집지 않는다.
            await self._set_state(
                deployment.workspace_id,
                deployment.id,
                DeploymentState.ACTIVE,
                next_fire_at=shift.at,
            )
            return Deferred(fire_at=shift.at, reason=shift.reason)

        res = await self.deployments.claim_fire(
            ClaimFire(
                workspace_id=deployment.workspace_id,
                deployment_id=deployment.id,
                scheduled_for=scheduled_for,
                run_id=self.ids.next("deployment_run"),
                now=now,
                shifted=shift.shifted_by,
                trigger=trigger,
                next_fire_at=self._next_for(deployment, now),
            )
        )
        if isinstance(res, AlreadyFired):
            return AlreadyRan(scheduled_for=res.scheduled_for)
        if not isinstance(res, ClaimedFire):
            return DeploymentMissing(deployment_id=deployment.id)
        return Fired(deployment=res.deployment, run=res.run, shift=shift)

    async def attach_session(
        self, workspace_id: WorkspaceId, run_id: str, session_id: SessionId
    ) -> DeploymentRun | None:
        """발화된 실행에 세션을 붙인다. **끝내는 것이 아니다.**

        `finish()` 를 `RunState.RUNNING` 으로 부르면 돌아가기는 하지만
        읽는 사람이 "끝났다"로 읽는다. `RUNNING` 은 final 이 아니라
        `ended_at` 이 비고 연속 실패 집계도 움직이지 않는다 — 이름이
        그것을 말해야 한다.
        """
        return await self.deployments.finish_run(
            FinishRun(
                workspace_id=workspace_id,
                run_id=run_id,
                state=RunState.RUNNING,
                now=self.clock.now(),
                session_id=session_id,
            )
        )

    async def finish(
        self,
        workspace_id: WorkspaceId,
        run_id: str,
        *,
        state: RunState,
        session_id: SessionId | None = None,
        error: str = "",
        cost_cents: int = 0,
    ) -> DeploymentRun | None:
        """실행을 끝낸다. **연속 실패가 상한에 닿으면 일시정지한다.**"""
        got = await self.deployments.finish_run(
            FinishRun(
                workspace_id=workspace_id,
                run_id=run_id,
                state=state,
                now=self.clock.now(),
                session_id=session_id,
                error=error,
                cost_cents=cost_cents,
            )
        )
        if got is None:
            return None

        deployment = await self.deployments.find(workspace_id, got.deployment_id)
        if (
            deployment is not None
            and deployment.consecutive_failures >= AUTO_PAUSE_AFTER
            and deployment.state is DeploymentState.ACTIVE
        ):
            # **고장난 배포가 매시간 돈과 시간을 쓴다.** 세 번 연속 실패면
            # 고쳐야 하는 것이지 더 돌려야 하는 것이 아니다.
            await self.pause(
                workspace_id,
                got.deployment_id,
                reason=f"연속 {deployment.consecutive_failures}회 실패로 자동 일시정지",
            )
        return got

    def upcoming(self, deployment: Deployment, *, count: int = 5) -> tuple[datetime, ...]:
        """공식 계약의 `next_fire_times`. **이동 전 시각이다** — off-peak
        이동은 발화 시점의 peak 창을 봐야 정해지므로 미리 말할 수 없다."""
        schedule = deployment.schedule
        if schedule is None:
            return ()
        return next_fires(
            parse(schedule.cron),
            self.clock.now(),
            timezone=schedule.timezone,
            count=count,
        )

    # ── 내부 ─────────────────────────────────────────────
    async def _shift_for(self, deployment: Deployment, fire_at: datetime) -> Shift:
        schedule = deployment.schedule
        if schedule is None or not schedule.off_peak_preferred:
            return Shift(at=fire_at, reason="off-peak 이동을 쓰지 않는다")

        windows = await self.peak_windows(deployment)
        return shift_to_off_peak(fire_at, windows, max_shift=schedule.max_shift)

    async def peak_windows(self, deployment: Deployment) -> tuple[PeakWindowSpec, ...]:
        """**카드에서 읽는다.** 코드에 시각을 박으면 provider 가 요금
        시간대를 바꿀 때 조용히 틀린다 — 비싼 시간에 돌면서 싸다고 믿는다.

        배포가 핀한 에이전트의 `model` 을 탄다 (결정 순서 ④). 워크스페이스
        기본값(③)은 **여기서 안 본다** — `WorkspaceStore` 에 SQL 구현이
        아직 없다. 에이전트의 `model` 은 필수 필드라 ④ 로 항상 정해진다.

        카드를 못 정하면 **빈 튜플**이다. 창이 없으면 `shift_to_off_peak`
        은 아무것도 안 민다 — 모르는 채로 미는 것보다 안 미는 쪽이 낫다.
        """
        rec = await self.agents.find_version(
            FindAgentVersion(deployment.workspace_id, deployment.agent_id, deployment.agent_version)
        )
        got = await self.resolver.resolve(
            ResolveModel(
                workspace_id=deployment.workspace_id,
                agent=rec.definition if rec else None,
            )
        )
        if not isinstance(got, ResolvedModel):
            return ()
        return windows_from_card(got.card)

    def _next_for(self, deployment: Deployment, after: datetime) -> datetime | None:
        schedule = deployment.schedule
        if schedule is None:
            return None
        try:
            return next_fire(parse(schedule.cron), after, timezone=schedule.timezone)
        except CronError:  # pragma: no cover — 저장 시 검증했다
            return None

    async def _record_skip(
        self, deployment: Deployment, scheduled_for: datetime, now: datetime
    ) -> None:
        """건너뛴 것도 **기록한다.** 안 남기면 "왜 어제는 안 왔지"에
        답할 수 없고, 겹침 때문인지 고장인지도 구분되지 않는다.

        집자마자 `skipped` 로 닫는다 — 열어 두면 `running_count` 에 잡혀
        다음 발화까지 연쇄로 건너뛴다.
        """
        res = await self.deployments.claim_fire(
            ClaimFire(
                workspace_id=deployment.workspace_id,
                deployment_id=deployment.id,
                scheduled_for=scheduled_for,
                run_id=self.ids.next("deployment_run"),
                now=now,
                next_fire_at=self._next_for(deployment, now),
            )
        )
        if not isinstance(res, ClaimedFire):
            return
        await self.deployments.finish_run(
            FinishRun(
                workspace_id=deployment.workspace_id,
                run_id=res.run.id,
                state=RunState.SKIPPED,
                now=now,
                error="앞 실행이 아직 돈다",
            )
        )


__all__ = [
    "AlreadyRan",
    "CreateDeployment",
    "CreateDeploymentResult",
    "Deferred",
    "DeploymentCreated",
    "DeploymentInvalid",
    "DeploymentMissing",
    "DeploymentUpdated",
    "DeploymentsUseCases",
    "FireResult",
    "Fired",
    "Skipped",
    "StateChangeResult",
    "windows_from_card",
]
