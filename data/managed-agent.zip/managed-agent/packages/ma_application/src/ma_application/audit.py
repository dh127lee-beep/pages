"""감사 조회와 **세션 타임라인 재구성**.

`plan/05-database.md` §3 G10 · `plan/04-api.md` §3.7 ·
`task/M3-security-governance/T-0404-audit-log.md` · `IMPL-0023`.

성공 기준 하나가 이것이다:

> 임의의 세션에 대해 **어떤 명령이 어떤 승인으로 실행됐는지**를 UI 에서
> 3클릭 내에 재구성한다.

그 백엔드가 여기다. 네 소스를 `created_at` 으로 머지한다.

| 소스 | 무엇을 준다 |
|---|---|
| `session_events` | 모델이 한 말, 툴 호출, 툴 결과 |
| `approvals` | 누가 언제 무엇을 승인·거부했는가 |
| `credential_events` | 어떤 자격증명이 어느 호스트에 쓰였는가 |
| `audit_log` | 사람이 한 행위 (세션 생성·인터럽트·승인 결정) |

**머지가 조인이 아닌 이유**: 네 테이블의 생애주기가 다르다. 감사 로그는
3년 보존이고 세션 이벤트는 세션과 함께 사라진다. 조인하면 오래된 세션의
타임라인이 **반쪽만** 나오는데, 그것을 "일이 없었다"로 읽게 된다.
그래서 **각 소스가 무엇을 줬는지 세어서 함께 돌려준다.**
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from collections.abc import Sequence
    from datetime import datetime

    from ma_domain.events import SessionEvent
    from ma_domain.governance import Approval, AuditEntry
    from ma_domain.ids import SessionId, WorkspaceId
    from ma_store._results import Cursor, Page
    from ma_store.credentials import CredentialStore
    from ma_store.events import SessionEventStore
    from ma_store.governance import ApprovalStore, AuditStore

#: 한 타임라인의 최대 길이. 넘으면 **잘렸다고 말한다** — 조용히 자르면
#: 조사하는 사람이 "그게 전부"라고 믿는다.
MAX_TIMELINE = 2_000


class Source(StrEnum):
    """이 줄이 어디서 왔는가. **UI 가 색으로 가른다.**"""

    EVENT = "session_event"
    APPROVAL = "approval"
    CREDENTIAL = "credential_event"
    AUDIT = "audit_log"


@dataclass(frozen=True, slots=True)
class TimelineItem:
    at: datetime
    source: Source
    #: 사람이 읽는 한 줄. UI 가 그대로 쓴다.
    summary: str
    #: 기계가 쓰는 것. 필터·링크에 쓴다.
    kind: str
    actor: str | None = None
    tool_call_id: str | None = None
    detail: tuple[tuple[str, Any], ...] = ()


@dataclass(frozen=True, slots=True)
class Timeline:
    session_id: SessionId
    items: tuple[TimelineItem, ...]
    #: 소스별로 몇 줄이 왔는가. **0 이면 "일이 없었다"가 아니라
    #: "그 소스가 비었다"** 일 수 있다 — 보존 기간이 다르기 때문이다.
    counts: tuple[tuple[Source, int], ...] = ()
    truncated: bool = False

    @property
    def approvals(self) -> tuple[TimelineItem, ...]:
        return tuple(i for i in self.items if i.source is Source.APPROVAL)


@dataclass
class AuditUseCases:
    audit: AuditStore
    events: SessionEventStore
    approvals: ApprovalStore
    credentials: CredentialStore

    async def list_entries(
        self,
        workspace_id: WorkspaceId,
        *,
        limit: int = 50,
        after: Cursor | None = None,
        since: datetime | None = None,
        until: datetime | None = None,
        actor_id: str | None = None,
        action_prefix: str | None = None,
        resource_type: str | None = None,
    ) -> Page[AuditEntry]:
        """감사 목록. **필터를 애플리케이션에서 건다.**

        Store 에 필터를 넣지 않는 이유: 필터 조합이 늘 때마다 두 구현을
        고쳐야 하고, 둘이 어긋나면 **조회 결과가 백엔드마다 다르다** —
        감사에서 그것은 치명적이다.

        비용은 한 페이지를 더 읽는 것이고, 감사 조회는 핫 경로가 아니다.
        """
        from ma_store._results import ListQuery, Page

        page = await self.audit.list_entries(
            ListQuery(
                workspace_id=workspace_id,
                limit=limit,
                after=after,
                created_at_gte=since,
                created_at_lte=until,
            )
        )
        kept = tuple(
            e
            for e in page.items
            if (actor_id is None or e.actor_id == actor_id)
            and (action_prefix is None or e.action.startswith(action_prefix))
            and (resource_type is None or e.resource_type == resource_type)
        )
        return Page(items=kept, next_cursor=page.next_cursor)

    async def timeline(self, workspace_id: WorkspaceId, session_id: SessionId) -> Timeline:
        """**네 소스를 시간순으로 합친다.**

        한 소스가 비어도 나머지를 돌려준다 — 그 사실이 `counts` 에 남는다.
        """
        items: list[TimelineItem] = []
        counts: dict[Source, int] = {s: 0 for s in Source}

        for entry in await self.audit.list_for_session(workspace_id, session_id):
            items.append(_from_audit(entry))
            counts[Source.AUDIT] += 1

        for event in await self._session_events(workspace_id, session_id):
            items.append(_from_event(event))
            counts[Source.EVENT] += 1

        for approval in await self._session_approvals(workspace_id, session_id):
            items.extend(_from_approval(approval))
            counts[Source.APPROVAL] += 1

        for used in await self._credential_uses(workspace_id, session_id):
            items.append(used)
            counts[Source.CREDENTIAL] += 1

        # **같은 시각이면 소스 순서로 가른다** — 정렬이 흔들리면 같은
        # 세션의 타임라인이 조회마다 달라지고, 조사하는 사람이 자기가
        # 본 것을 다시 못 찾는다.
        items.sort(key=lambda i: (i.at, i.source.value, i.kind))
        truncated = len(items) > MAX_TIMELINE
        return Timeline(
            session_id=session_id,
            items=tuple(items[:MAX_TIMELINE]),
            counts=tuple(sorted(counts.items(), key=lambda kv: kv[0].value)),
            truncated=truncated,
        )

    # ── 소스별 읽기 ──────────────────────────────────────
    async def _session_events(
        self, workspace_id: WorkspaceId, session_id: SessionId
    ) -> Sequence[SessionEvent]:
        from ma_store.events import ReadEvents

        return await self.events.read(
            ReadEvents(workspace_id=workspace_id, session_id=session_id, limit=MAX_TIMELINE)
        )

    async def _session_approvals(
        self, workspace_id: WorkspaceId, session_id: SessionId
    ) -> Sequence[Approval]:
        """**모든 상태를 본다.** 거부와 만료가 조사의 핵심이다."""
        from ma_domain.governance import ApprovalState
        from ma_store._results import ListQuery

        out: list[Approval] = []
        for state in ApprovalState:
            page = await self.approvals.list_inbox(
                ListQuery(workspace_id=workspace_id, limit=200), state
            )
            out.extend(a for a in page.items if a.session_id == session_id)
        return out

    async def _credential_uses(
        self, workspace_id: WorkspaceId, session_id: SessionId
    ) -> Sequence[TimelineItem]:
        """`credential_events` 는 아직 읽기 경로가 없다.

        `CredentialStore` 에 `record_event` 만 있고 조회가 없다 — 쓰는
        쪽(T-0402)이 먼저 생겼기 때문이다. **빈 것을 돌려주되 `counts`
        가 0 을 보여** 주어, 조사하는 사람이 "자격증명을 안 썼다"와
        "아직 못 읽는다"를 구분할 수 있게 한다.

        TODO(T-0406): `list_credential_events` 를 Store 에 더한다.
        """
        _ = (workspace_id, session_id)
        return ()


# ── 변환 ─────────────────────────────────────────────────
def _from_audit(entry: AuditEntry) -> TimelineItem:
    return TimelineItem(
        at=entry.created_at,
        source=Source.AUDIT,
        kind=entry.action,
        summary=f"{entry.actor_id} 가 {entry.action} ({entry.resource_type} {entry.resource_id})",
        actor=entry.actor_id,
        detail=entry.detail,
    )


def _from_event(event: SessionEvent) -> TimelineItem:
    payload = dict(event.payload)
    tool_call_id = payload.get("tool_call_id")
    return TimelineItem(
        at=event.created_at,
        source=Source.EVENT,
        kind=event.type.value,
        summary=_event_summary(event.type.value, payload),
        tool_call_id=str(tool_call_id) if tool_call_id else None,
        # **payload 를 통째로 싣지 않는다.** 툴 인자에 비밀이 있을 수 있고,
        # 감사는 3년 보존이다.
        detail=(("seq", event.seq),),
    )


def _event_summary(kind: str, payload: dict[str, Any]) -> str:
    name = payload.get("name") or payload.get("tool_name")
    match kind:
        case "agent.tool_use":
            return f"에이전트가 {name} 를 호출"
        case "agent.tool_result":
            failed = payload.get("is_error") is True
            return f"{name or '툴'} 결과 ({'실패' if failed else '성공'})"
        case "user.message":
            return "사용자 메시지"
        case "agent.message":
            return "에이전트 응답"
        case _:
            return kind


def _from_approval(approval: Approval) -> list[TimelineItem]:
    """**요청과 결정을 두 줄로 나눈다.**

    한 줄로 합치면 "언제 물었고 언제 답했는가" 사이의 시간이 사라진다 —
    그 간격이 조사에서 가장 자주 보는 값이다 (왜 세션이 멈춰 있었나).
    """
    out = [
        TimelineItem(
            at=approval.requested_at,
            source=Source.APPROVAL,
            kind="approval.ask",
            summary=f"{approval.tool_name} 승인 요청",
            tool_call_id=approval.tool_call_id,
            detail=approval.input_summary,
        )
    ]
    if approval.decided_at is not None:
        who = ", ".join(approval.decided_by) or "시스템"
        out.append(
            TimelineItem(
                at=approval.decided_at,
                source=Source.APPROVAL,
                kind=f"approval.{approval.state.value}",
                summary=f"{who} 가 {approval.tool_name} 을 {approval.state.value}",
                actor=who,
                tool_call_id=approval.tool_call_id,
                detail=(("reason", approval.reason),) if approval.reason else (),
            )
        )
    return out


__all__ = [
    "MAX_TIMELINE",
    "AuditUseCases",
    "Source",
    "Timeline",
    "TimelineItem",
]
