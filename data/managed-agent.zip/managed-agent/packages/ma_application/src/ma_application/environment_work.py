"""self_hosted 워커 유스케이스 (T-0606).

`plan/04-api.md` §3.3 · `ref/claude-managed-agents/08-self-hosted/`.

> **데이터가 부서 경계를 넘을 수 없을 때** 쓴다 (법무·인사). 샌드박스를
> 부서 인프라에서 돌리고, 우리는 **무엇을 할지만** 큐에 넣는다.

워커가 부르는 다섯 가지 — poll · ack · heartbeat · stop · stats.
전부 HTTP 이고, **워커는 DB 에 닿지 않는다.**

`user.tool_result` 가 결과가 돌아오는 길이다. 워커가 툴을 실행하고
그 결과를 세션 이벤트로 올리면, 턴이 거기서부터 이어진다 — `always_ask`
승인이 재개되는 것과 **같은 경로**다. 경로를 따로 두면 멱등성과 순서
보장을 두 벌 유지해야 한다.
"""

from __future__ import annotations

import secrets
from dataclasses import dataclass
from datetime import timedelta
from typing import TYPE_CHECKING, Any

from ma_domain.environment_work import (
    DEFAULT_LEASE_TTL,
    MAX_ATTEMPTS,
    SECRET_BYTES,
    WorkItem,
    WorkState,
    WorkStats,
)
from ma_domain.events import PRIMARY_THREAD, EventType
from ma_domain.workspaces import Role
from ma_store.environment_work import (
    AckWork,
    ClaimWork,
    EnqueueWork,
    FenceLost,
    Heartbeat,
    NoWork,
    WorkGone,
)

if TYPE_CHECKING:
    from ma_domain.clock import Clock, IdGenerator
    from ma_domain.ids import EnvironmentId, SessionId, WorkspaceId
    from ma_store._results import Cursor, Page
    from ma_store.environment_work import EnvironmentWorkStore

    from ma_application.session_events import SessionEventsUseCases


# ── 결과 ─────────────────────────────────────────────────
@dataclass(frozen=True, slots=True)
class WorkQueued:
    item: WorkItem


@dataclass(frozen=True, slots=True)
class SessionBusy:
    """이 세션에 이미 열린 일이 있다. **정상이다** — 앞 턴이 안 끝났다."""

    work_id: str


@dataclass(frozen=True, slots=True)
class Granted:
    """일을 집었다. **시크릿이 여기에만 한 번 실린다** (D5)."""

    item: WorkItem
    secret: str
    #: 워커가 보낼 주기. 서버가 정한다 — 워커가 정하면 자기 TTL 을 늘린다.
    heartbeat_seconds: int

    def __repr__(self) -> str:
        return f"Granted(item={self.item.id!r}, secret=<가림>)"


@dataclass(frozen=True, slots=True)
class QueueEmpty:
    """오류가 아니다. long-poll 이 정상적으로 끝난 것."""


@dataclass(frozen=True, slots=True)
class WorkAccepted:
    item: WorkItem


@dataclass(frozen=True, slots=True)
class ClaimLost:
    """회수됐다. **진행 중인 일을 버려야 한다** — 새 워커가 이미 돌고 있다."""

    actual_generation: int


@dataclass(frozen=True, slots=True)
class WorkMissing:
    work_id: str


@dataclass(frozen=True, slots=True)
class ResultRejected:
    """결과를 세션에 넣지 못했다. **ack 도 하지 않는다.**

    넣지 못했는데 ack 하면 일이 사라지고 세션은 영원히 기다린다.
    """

    reason: str


type EnqueueResult = WorkQueued | SessionBusy
type PollResult = Granted | QueueEmpty
type AckResult = WorkAccepted | ClaimLost | WorkMissing | ResultRejected


# ── 입력 ─────────────────────────────────────────────────
@dataclass(frozen=True, slots=True)
class PollWork:
    workspace_id: WorkspaceId
    environment_id: EnvironmentId
    worker_id: str
    #: 하트비트가 이보다 오래 끊긴 것도 함께 회수한다.
    reclaim_after: timedelta = DEFAULT_LEASE_TTL


@dataclass(frozen=True, slots=True)
class CompleteWork:
    """일을 끝낸다. **결과를 함께 올린다.**

    둘을 나누면 "결과는 올렸는데 ack 를 못 한" 창이 생기고, 그 창에
    회수가 일어나면 같은 결과가 두 번 들어간다.
    """

    workspace_id: WorkspaceId
    work_id: str
    worker_id: str
    generation: int
    #: 툴 결과들. 비어 있으면 **이벤트를 안 넣는다** — 실패 ack 가 그렇다.
    results: tuple[dict[str, Any], ...] = ()
    failed: bool = False
    error: str = ""


@dataclass
class EnvironmentWorkUseCases:
    work: EnvironmentWorkStore
    events: SessionEventsUseCases
    clock: Clock
    ids: IdGenerator
    #: 하트비트 TTL. **서버가 정한다** — 워커가 정하면 자기 lease 를 늘린다.
    lease_ttl: timedelta = DEFAULT_LEASE_TTL
    max_attempts: int = MAX_ATTEMPTS

    # ── 제어 평면 쪽 ─────────────────────────────────────
    async def enqueue(
        self,
        workspace_id: WorkspaceId,
        environment_id: EnvironmentId,
        environment_version: int,
        session_id: SessionId,
    ) -> EnqueueResult:
        """세션이 돌 차례가 됐다고 큐에 넣는다.

        **세션 하나당 열린 일은 하나**다. 이미 있으면 그것을 돌려준다 —
        오류가 아니다. 앞 턴이 아직 안 끝난 것뿐이다.
        """
        from ma_domain.errors import InvariantViolation

        existing = await self.work.find_for_session(workspace_id, session_id)
        if existing is not None:
            return SessionBusy(work_id=existing.id)

        try:
            made = await self.work.enqueue(
                EnqueueWork(
                    id=self.ids.next("environment_work"),
                    workspace_id=workspace_id,
                    environment_id=environment_id,
                    environment_version=environment_version,
                    session_id=session_id,
                    now=self.clock.now(),
                )
            )
        except InvariantViolation:
            # **경합.** 위 조회와 INSERT 사이에 다른 요청이 넣었다.
            again = await self.work.find_for_session(workspace_id, session_id)
            return SessionBusy(work_id=again.id if again else "")
        return WorkQueued(item=made)

    # ── 워커 쪽 ──────────────────────────────────────────
    async def poll(self, cmd: PollWork) -> PollResult:
        """일 하나를 집는다. **시크릿을 여기서 만든다.**

        Store 가 만들지 않는 이유: 난수 생성이 Store 안에 있으면
        테스트가 결정적이지 않고, "어디서 시크릿이 나오는가"가
        구현마다 달라진다.
        """
        got = await self.work.claim(
            ClaimWork(
                workspace_id=cmd.workspace_id,
                environment_id=cmd.environment_id,
                worker_id=cmd.worker_id,
                now=self.clock.now(),
                secret=secrets.token_urlsafe(SECRET_BYTES),
                reclaim_after=cmd.reclaim_after,
                max_attempts=self.max_attempts,
            )
        )
        if isinstance(got, NoWork):
            return QueueEmpty()
        return Granted(
            item=got.item,
            secret=got.secret,
            # **TTL 의 1/3.** 두 번 놓쳐도 한 번이 남는다.
            heartbeat_seconds=max(int(self.lease_ttl.total_seconds()) // 3, 1),
        )

    async def heartbeat(
        self, workspace_id: WorkspaceId, work_id: str, worker_id: str, generation: int
    ) -> AckResult:
        got = await self.work.heartbeat(
            Heartbeat(
                workspace_id=workspace_id,
                work_id=work_id,
                worker_id=worker_id,
                generation=generation,
                now=self.clock.now(),
            )
        )
        return _to_result(got, work_id)

    async def complete(self, cmd: CompleteWork) -> AckResult:
        """결과를 세션에 넣고 일을 끝낸다. **순서가 중요하다.**

        결과를 **먼저** 넣고 ack 한다. 반대로 하면 ack 와 결과 삽입
        사이에 워커가 죽었을 때 일이 사라지고 **세션은 영원히 기다린다.**
        둘 사이에서 죽으면 회수가 일어나 다른 워커가 같은 일을 돌리는데,
        그쪽은 멱등키가 막는다 — 잃는 것보다 중복이 낫다.
        """
        item = await self.work.find(cmd.workspace_id, cmd.work_id)
        if item is None:
            return WorkMissing(work_id=cmd.work_id)
        if not item.accepts(cmd.generation) or item.worker_id != cmd.worker_id:
            return ClaimLost(actual_generation=item.claim_generation)

        if cmd.results:
            sent = await self._send_results(item, cmd)
            if sent is not None:
                return sent

        got = await self.work.ack(
            AckWork(
                workspace_id=cmd.workspace_id,
                work_id=cmd.work_id,
                worker_id=cmd.worker_id,
                generation=cmd.generation,
                state=WorkState.FAILED if cmd.failed else WorkState.DONE,
                now=self.clock.now(),
                error=cmd.error,
            )
        )
        return _to_result(got, cmd.work_id)

    async def _send_results(self, item: WorkItem, cmd: CompleteWork) -> ResultRejected | None:
        """`user.tool_result` 로 올린다. **승인 재개와 같은 경로다.**

        따로 두면 멱등성과 순서 보장을 두 벌 유지해야 하고, 두 벌은
        반드시 어긋난다.
        """
        from ma_application.session_events import (
            EventsAccepted,
            InboundEvent,
            SendEvents,
        )

        inbound = tuple(
            InboundEvent(
                type=EventType.USER_TOOL_RESULT,
                payload=tuple(sorted(result.items())),
                thread_id=PRIMARY_THREAD,
            )
            for result in cmd.results
        )
        res = await self.events.send(
            SendEvents(
                workspace_id=item.workspace_id,
                session_id=item.session_id,
                events=inbound,
                # **일 id + generation 이 멱등키다.** 회수 뒤 두 워커가
                # 같은 결과를 올려도 한 번만 들어간다.
                idempotency_key=f"work:{item.id}:{cmd.generation}",
                actor_role=Role.OPERATOR,
            )
        )
        if isinstance(res, EventsAccepted):
            return None
        # **ack 하지 않는다.** 넣지 못했는데 끝냈다고 하면 일이
        # 사라지고 세션은 영원히 기다린다.
        return ResultRejected(reason=f"{type(res).__name__}: {res!r}")

    async def stop(self, workspace_id: WorkspaceId, work_id: str, *, reason: str = "") -> AckResult:
        """운영자가 일을 멈춘다. **워커의 generation 을 안 본다.**

        여기만 fence 를 건너뛰는 이유: 멈추는 것은 "이 일을 더 돌리지
        말라"이고, 그 판단은 워커의 상태와 무관하다. 워커는 다음
        하트비트에서 `FenceLost` 를 받고 멈춘다.
        """
        item = await self.work.find(workspace_id, work_id)
        if item is None:
            return WorkMissing(work_id=work_id)
        got = await self.work.ack(
            AckWork(
                workspace_id=workspace_id,
                work_id=work_id,
                worker_id=item.worker_id or "",
                generation=item.claim_generation,
                state=WorkState.FAILED,
                now=self.clock.now(),
                error=reason or "운영자가 멈췄다",
            )
        )
        return _to_result(got, work_id)

    # ── 조회 ─────────────────────────────────────────────
    async def stats(self, workspace_id: WorkspaceId, environment_id: EnvironmentId) -> WorkStats:
        return await self.work.stats(workspace_id, environment_id, self.clock.now())

    async def list_work(
        self,
        workspace_id: WorkspaceId,
        environment_id: EnvironmentId,
        *,
        limit: int = 50,
        after: Cursor | None = None,
    ) -> Page[WorkItem]:
        from ma_store._results import ListQuery

        return await self.work.list_work(
            ListQuery(workspace_id=workspace_id, limit=limit, after=after), environment_id
        )

    async def find(self, workspace_id: WorkspaceId, work_id: str) -> WorkItem | None:
        return await self.work.find(workspace_id, work_id)


def _to_result(got: object, work_id: str) -> AckResult:
    if isinstance(got, FenceLost):
        return ClaimLost(actual_generation=got.actual_generation)
    if isinstance(got, WorkGone):
        return WorkMissing(work_id=work_id)
    if isinstance(got, WorkItem):
        return WorkAccepted(item=got)
    return WorkMissing(work_id=work_id)  # pragma: no cover


__all__ = [
    "AckResult",
    "ClaimLost",
    "CompleteWork",
    "EnqueueResult",
    "EnvironmentWorkUseCases",
    "Granted",
    "PollResult",
    "PollWork",
    "QueueEmpty",
    "ResultRejected",
    "SessionBusy",
    "WorkAccepted",
    "WorkMissing",
    "WorkQueued",
]
