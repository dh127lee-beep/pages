"""세션·이벤트 wire ↔ 도메인."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from ma_domain.events import SessionEvent
    from ma_domain.sessions import SessionRecord


def session_out(rec: SessionRecord) -> dict[str, Any]:
    return {
        "id": rec.id,
        "agent_id": rec.agent_id,
        "agent_version": rec.agent_version,
        "environment_id": rec.environment_id,
        "environment_version": rec.environment_version,
        "status": rec.status.value,
        "revision": rec.revision,
        "stop_reason": rec.stop_reason.value if rec.stop_reason else None,
        "required_action": rec.required_action.value if rec.required_action else None,
        "budget_cents": rec.budget.limit_cents if rec.budget else None,
        "spent_cents": rec.budget.spent_cents if rec.budget else 0,
        "created_by": rec.created_by,
        "created_at": rec.created_at,
        "updated_at": rec.updated_at,
    }


def event_out(ev: SessionEvent) -> dict[str, Any]:
    return {
        "id": ev.id,
        "seq": ev.seq if ev.seq is not None else -1,
        "type": ev.type.value,
        "thread_id": ev.thread_id,
        "content": dict(ev.payload),
        "created_at": ev.created_at,
    }


__all__ = ["event_out", "session_out"]
