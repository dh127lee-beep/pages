"""`/healthz` `/readyz` — **인증 없이** 응답한다.

`plan/09-codebase.md` §4 — 미들웨어 4단계에서 분기한다.

인증을 요구하면 k8s 프로브가 실패하고, 프로브가 실패하면 파드가 죽는다.
`/readyz` 만 의존성을 확인한다 — `/healthz` 는 "프로세스가 살아 있는가"다.
"""

from __future__ import annotations

from fastapi import APIRouter, Request, Response

from ma_api.internal.schemas import HealthOut
from ma_api.shared.revalidate import revalidate

router = APIRouter(tags=["health"])


@router.get("/healthz", response_model=HealthOut)
async def healthz() -> dict[str, object]:
    """**의존성을 보지 않는다.** DB 가 내려가도 프로세스는 살아 있다 —
    여기서 실패하면 k8s 가 파드를 죽이고, DB 복구 후에도 파드가 없다."""
    return revalidate(HealthOut, {"status": "ok"})


@router.get("/readyz", response_model=HealthOut)
async def readyz(request: Request, response: Response) -> dict[str, object]:
    """트래픽을 받을 준비가 됐는가. **의존성을 본다.**"""
    checks: dict[str, str] = {}
    probe = getattr(request.app.state, "readiness", None)
    if probe is not None:
        checks = await probe()
    degraded = any(v != "ok" for v in checks.values())
    if degraded:
        response.status_code = 503
    return revalidate(HealthOut, {"status": "degraded" if degraded else "ok", "checks": checks})
