"""self_hosted 워커 엔드포인트 (T-0606).

`plan/04-api.md` §3.3 · `ref/claude-managed-agents/08-self-hosted/`.

> 부서의 워커가 **HTTP 로만** 닿는다. DB 에 닿지 않고, 닿아서도 안
> 된다 — 그 워커는 사내 다른 네트워크에 있고, 그것이 self_hosted 를
> 쓰는 이유다 (데이터가 부서 경계를 안 넘는다).

다섯 가지: `poll` · `heartbeat` · `ack` · `stop` · `stats`.

| | 누가 | 권한 |
|---|---|---|
| poll · heartbeat · ack | 부서의 워커 | `operator` |
| stop | 운영자 | `operator` |
| stats | 운영자·대시보드 | `viewer` |

**`stop` 만 fence 를 안 본다.** 멈추는 것은 "더 돌리지 말라"이고 그
판단은 워커의 상태와 무관하다 — 워커는 다음 하트비트에서 알게 된다.
"""

from __future__ import annotations

import asyncio
from typing import Annotated, Any

from fastapi import APIRouter, Query, status
from ma_application.environment_work import (
    ClaimLost,
    CompleteWork,
    Granted,
    PollWork,
    QueueEmpty,
    ResultRejected,
    WorkAccepted,
    WorkMissing,
)
from ma_domain.ids import EnvironmentId
from ma_domain.workspaces import Role

from ma_api.internal.deps import CurrentGraph, CurrentPrincipal
from ma_api.internal.schemas import (
    PageOut,
    WorkAckIn,
    WorkGrantOut,
    WorkHeartbeatIn,
    WorkOut,
    WorkPollIn,
    WorkStatsOut,
)
from ma_api.shared.errors import conflict, forbidden, not_found
from ma_api.shared.pagination import page_body
from ma_api.shared.revalidate import revalidate

router = APIRouter(prefix="/api/v1/environments", tags=["environment_work"])

#: long-poll 한 바퀴. 이 간격으로 큐를 다시 본다.
#:
#: 250ms 인 이유: 더 짧으면 빈 큐에 질의가 쌓이고, 더 길면 일이
#: 들어온 뒤 그만큼 늦게 집힌다. `block_ms` 가 0 이면 한 번만 본다.
POLL_INTERVAL = 0.25


def _require(principal: Any, role: Role) -> None:
    if not principal.role.at_least(role):
        raise forbidden(f"{role.value} 이상이 필요하다")


def _work_out(w: Any) -> dict[str, Any]:
    return {
        "id": w.id,
        "environment_id": w.environment_id,
        "environment_version": w.environment_version,
        "session_id": w.session_id,
        "state": w.state.value,
        "claim_generation": w.claim_generation,
        "attempts": w.attempts,
        "worker_id": w.worker_id,
        "created_at": w.created_at,
        "updated_at": w.updated_at,
        "claimed_at": w.claimed_at,
        "heartbeat_at": w.heartbeat_at,
        "acked_at": w.acked_at,
        "error": w.error,
    }


@router.post(
    "/{environment_id}/work/poll",
    response_model=WorkGrantOut,
    status_code=status.HTTP_200_OK,
    responses={204: {"description": "큐가 비었다"}},
)
async def poll_work(
    environment_id: str,
    body: WorkPollIn,
    graph: CurrentGraph,
    principal: CurrentPrincipal,
) -> Any:
    """일 하나를 집는다. **없으면 204 다 — 404 가 아니다.**

    404 는 "환경이 없다"로 읽히고, 워커가 설정을 의심하게 된다. 빈
    큐는 **정상이다.**

    `block_ms` 동안 기다린다. 긴 폴링을 서버가 받는 이유: 워커가
    촘촘히 재시도하면 그 트래픽이 부서 네트워크 경계를 매번 넘는다.
    """
    _require(principal, Role.OPERATOR)
    from fastapi import Response

    deadline = body.block_ms / 1000.0
    waited = 0.0
    while True:
        res = await graph.environment_work.poll(
            PollWork(
                workspace_id=principal.workspace_id,
                environment_id=EnvironmentId(environment_id),
                worker_id=body.worker_id,
            )
        )
        if isinstance(res, Granted):
            return revalidate(
                WorkGrantOut,
                {
                    "work": revalidate(WorkOut, _work_out(res.item)),
                    "secret": res.secret,
                    "heartbeat_seconds": res.heartbeat_seconds,
                },
            )
        if not isinstance(res, QueueEmpty) or waited >= deadline:
            return Response(status_code=status.HTTP_204_NO_CONTENT)
        await asyncio.sleep(min(POLL_INTERVAL, deadline - waited))
        waited += POLL_INTERVAL


@router.post("/{environment_id}/work/{work_id}/heartbeat", response_model=WorkOut)
async def heartbeat_work(
    environment_id: str,
    work_id: str,
    body: WorkHeartbeatIn,
    graph: CurrentGraph,
    principal: CurrentPrincipal,
) -> dict[str, Any]:
    """**살아 있다고 알린다.** 끊기면 다른 워커가 집는다."""
    _require(principal, Role.OPERATOR)
    res = await graph.environment_work.heartbeat(
        principal.workspace_id, work_id, body.worker_id, body.claim_generation
    )
    return _ack_out(res, work_id)


@router.post("/{environment_id}/work/{work_id}/ack", response_model=WorkOut)
async def ack_work(
    environment_id: str,
    work_id: str,
    body: WorkAckIn,
    graph: CurrentGraph,
    principal: CurrentPrincipal,
) -> dict[str, Any]:
    """일을 끝내고 **결과를 함께 올린다.**

    둘을 나누면 "결과는 올렸는데 ack 를 못 한" 창이 생기고, 그 창에
    회수가 일어나면 같은 결과가 두 번 들어간다.
    """
    _require(principal, Role.OPERATOR)
    res = await graph.environment_work.complete(
        CompleteWork(
            workspace_id=principal.workspace_id,
            work_id=work_id,
            worker_id=body.worker_id,
            generation=body.claim_generation,
            results=tuple(
                {
                    "tool_use_id": r.tool_use_id,
                    "content": r.content,
                    "is_error": r.is_error,
                }
                for r in body.results
            ),
            failed=body.failed,
            error=body.error,
        )
    )
    return _ack_out(res, work_id)


@router.post("/{environment_id}/work/{work_id}/stop", response_model=WorkOut)
async def stop_work(
    environment_id: str,
    work_id: str,
    graph: CurrentGraph,
    principal: CurrentPrincipal,
) -> dict[str, Any]:
    """운영자가 멈춘다. **워커의 generation 을 안 본다.**

    워커는 다음 하트비트에서 `409 claim_lost` 를 받고 멈춘다.
    """
    _require(principal, Role.OPERATOR)
    res = await graph.environment_work.stop(principal.workspace_id, work_id)
    return _ack_out(res, work_id)


@router.get("/{environment_id}/work/stats", response_model=WorkStatsOut)
async def work_stats(
    environment_id: str, graph: CurrentGraph, principal: CurrentPrincipal
) -> dict[str, Any]:
    """**"워커가 도는가"의 답.**

    `oldest_queued_seconds` 가 핵심이다 — `queued` 수만 보면 트래픽이
    적은 환경과 워커가 멈춘 환경이 구분되지 않는다.
    """
    _require(principal, Role.VIEWER)
    got = await graph.environment_work.stats(principal.workspace_id, EnvironmentId(environment_id))
    return revalidate(
        WorkStatsOut,
        {
            "environment_id": got.environment_id,
            "queued": got.queued,
            "claimed": got.claimed,
            "done": got.done,
            "failed": got.failed,
            "expired": got.expired,
            "oldest_queued_seconds": got.oldest_queued_seconds,
        },
    )


@router.get("/{environment_id}/work", response_model=PageOut)
async def list_work(
    environment_id: str,
    graph: CurrentGraph,
    principal: CurrentPrincipal,
    limit: Annotated[int, Query(ge=1, le=200)] = 50,
    page: str | None = None,
) -> dict[str, Any]:
    _require(principal, Role.VIEWER)
    from ma_api.shared.pagination import decode

    got = await graph.environment_work.list_work(
        principal.workspace_id,
        EnvironmentId(environment_id),
        limit=limit,
        after=decode(page),
    )
    items = [revalidate(WorkOut, _work_out(w)) for w in got.items]
    return revalidate(PageOut, page_body(got, items))


def _ack_out(res: Any, work_id: str) -> dict[str, Any]:
    match res:
        case WorkAccepted(item=item):
            return revalidate(WorkOut, _work_out(item))
        case ClaimLost(actual_generation=actual):
            # **409 다.** 요청이 틀린 것이 아니라 이 워커가 더 이상
            # 주인이 아니다 — 진행 중인 일을 버려야 한다.
            raise conflict(f"claim 을 잃었다 (현재 generation {actual})", code="claim_lost")
        case ResultRejected(reason=reason):
            # **ack 하지 않았다.** 결과를 못 넣었는데 끝냈다고 하면
            # 일이 사라지고 세션은 영원히 기다린다.
            raise conflict(f"결과를 세션에 넣지 못했다: {reason}", code="result_rejected")
        case WorkMissing():
            raise not_found("Work", work_id)
    raise not_found("Work", work_id)  # pragma: no cover


__all__ = ["POLL_INTERVAL", "router"]
