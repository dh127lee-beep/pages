"""감사 조회와 세션 타임라인. `plan/04-api.md` §3.7.

성공 기준: **임의의 세션에 대해 어떤 명령이 어떤 승인으로 실행됐는지를
3클릭 내에 재구성한다.** `GET /api/v1/audit/sessions/{id}` 가 그 한 번이다.
"""

from __future__ import annotations

from datetime import datetime
from typing import Annotated, Any

from fastapi import APIRouter, Query
from ma_application.audit import Timeline, TimelineItem
from ma_domain.governance import AuditEntry
from ma_domain.ids import SessionId
from ma_domain.workspaces import Role

from ma_api.internal.deps import CurrentGraph, CurrentPrincipal
from ma_api.internal.schemas import AuditEntryOut, PageOut, TimelineOut
from ma_api.shared.errors import forbidden
from ma_api.shared.pagination import page_body
from ma_api.shared.revalidate import revalidate

router = APIRouter(prefix="/api/v1/audit", tags=["audit"])


def _require_auditor(principal: Any) -> None:
    """**감사는 admin 이상만 본다.**

    감사 로그에는 "누가 무엇을 했는가"가 전부 있다 — operator 에게
    열어 주면 그것으로 동료를 감시할 수 있다.
    """
    if not principal.role.at_least(Role.ADMIN):
        raise forbidden("감사 조회는 admin 이상이 필요하다")


def entry_out(e: AuditEntry) -> dict[str, Any]:
    return {
        "actor_type": e.actor_kind.value,
        "actor_id": e.actor_id,
        "action": e.action,
        "resource_type": e.resource_type,
        "resource_id": e.resource_id,
        "session_id": e.session_id,
        "detail": dict(e.detail),
        "request_id": e.request_id,
        "created_at": e.created_at,
    }


def item_out(i: TimelineItem) -> dict[str, Any]:
    return {
        "at": i.at,
        "source": i.source.value,
        "kind": i.kind,
        "summary": i.summary,
        "actor": i.actor,
        "tool_call_id": i.tool_call_id,
        "detail": dict(i.detail),
    }


def timeline_out(t: Timeline) -> dict[str, Any]:
    return {
        "session_id": t.session_id,
        "timeline": [item_out(i) for i in t.items],
        "counts": {source.value: n for source, n in t.counts},
        "truncated": t.truncated,
    }


@router.get("", response_model=PageOut)
async def list_audit(
    graph: CurrentGraph,
    principal: CurrentPrincipal,
    limit: Annotated[int, Query(ge=1, le=200)] = 50,
    since: Annotated[datetime | None, Query()] = None,
    until: Annotated[datetime | None, Query()] = None,
    actor_id: Annotated[str | None, Query()] = None,
    action: Annotated[str | None, Query(description="접두사. 'approval.' 처럼")] = None,
    resource_type: Annotated[str | None, Query()] = None,
) -> dict[str, Any]:
    _require_auditor(principal)
    got = await graph.audit.list_entries(
        principal.workspace_id,
        limit=limit,
        since=since,
        until=until,
        actor_id=actor_id,
        action_prefix=action,
        resource_type=resource_type,
    )
    items = [revalidate(AuditEntryOut, entry_out(e)) for e in got.items]
    return revalidate(PageOut, page_body(got, items))


@router.get("/sessions/{session_id}", response_model=TimelineOut)
async def session_timeline(
    session_id: str, graph: CurrentGraph, principal: CurrentPrincipal
) -> dict[str, Any]:
    """**네 소스를 시간순으로 합친 하나의 타임라인.**

    세션이 없어도 404 를 내지 않는다 — 오래된 세션은 이벤트가 지워지고
    감사만 남는다. 그때 "없다"고 하면 **그 세션에 아무 일도 없었다**로
    읽히는데, 사실은 반대다.
    """
    _require_auditor(principal)
    got = await graph.audit.timeline(principal.workspace_id, SessionId(session_id))
    return revalidate(TimelineOut, timeline_out(got))
