"""파일 · 산출물 wire 변환. `plan/04-api.md` §3.4 · §3.8.

**`mount_path` 는 서버가 계산한다** — `mappers/memory.py` 와 같은 이유.
클라이언트가 `/mnt/files/` + 이름을 조립하게 두면 경로 규칙이 두 벌이
되고, 바뀔 때 콘솔이 조용히 틀린 경로를 보여 준다.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from ma_domain.files import FileMeta, SessionOutput


def file_out(f: FileMeta) -> dict[str, Any]:
    # 필드를 하나하나 적는다 — `asdict` 면 도메인에 필드가 늘 때 wire 가
    # 조용히 넓어진다. `storage_key` 가 나가지 않는 것이 특히 중요하다:
    # 버킷 구조가 드러나면 키를 추측해 다른 워크스페이스를 노린다.
    return {
        "id": f.id,
        "filename": f.filename,
        "safe_name": f.safe_name,
        "content_type": f.content_type,
        "size_bytes": f.size_bytes,
        "sha256": f.sha256,
        "created_by": f.created_by,
        "created_at": f.created_at,
        "uploaded_at": f.uploaded_at,
        "mount_path": f.mount_path(),
    }


def output_out(o: SessionOutput) -> dict[str, Any]:
    """**`storage_key` 가 없다** — `file_out` 과 같은 이유."""
    return {
        "id": o.id,
        "session_id": o.session_id,
        "path": o.path,
        "content_type": o.content_type,
        "size_bytes": o.size_bytes,
        "sha256": o.sha256,
        "generation": o.generation,
        "created_at": o.created_at,
    }


__all__ = ["file_out", "output_out"]
