"""세션 CRUD. `plan/04-api.md` §3.

세션 생성이 **에이전트 버전을 핀한다.** 운영자가 에이전트를 고치는 동안 진행 중인
세션의 행동이 바뀌면 그 세션의 이벤트 로그를 재현할 수 없다.
"""

from __future__ import annotations

# **런타임 import 다.** FastAPI 가 쿼리 파라미터 타입을 실제로 풀어야
# `?created_after=2026-10-16T00:00:00Z` 를 `datetime` 으로 바꿔 준다 —
# `TYPE_CHECKING` 아래 두면 문자열 그대로 들어온다.
from datetime import datetime
from typing import Annotated, Any

from fastapi import APIRouter, Query, status
from ma_domain.ids import AgentId, EnvironmentId, ModelCardId, SessionId, WorkspaceId
from ma_domain.sessions import ConfigOverride, SessionBudget, SessionRecord, SessionStatus
from ma_domain.workspaces import Role
from ma_store._results import NotFound, VersionConflict
from ma_store.sessions import FindSession, InsertSession, ListSessions, UpdateSessionStatus

from ma_api.internal.deps import CurrentGraph, CurrentPrincipal
from ma_api.internal.mappers.sessions import session_out
from ma_api.internal.schemas import PageOut, SessionIn, SessionOut
from ma_api.shared.errors import forbidden, invalid, not_found
from ma_api.shared.pagination import page_body
from ma_api.shared.revalidate import revalidate

router = APIRouter(prefix="/api/v1/sessions", tags=["sessions"])


def _require(principal: Any, role: Role) -> None:
    if not principal.role.at_least(role):
        raise forbidden(f"{role.value} 이상이 필요하다")


@router.post("", response_model=SessionOut, status_code=status.HTTP_201_CREATED)
async def create_session(
    body: SessionIn, graph: CurrentGraph, principal: CurrentPrincipal
) -> dict[str, Any]:
    _require(principal, Role.OPERATOR)

    agent = await graph.agents.get(AgentId(body.agent_id))
    if agent is None:
        raise not_found("Agent", body.agent_id)
    if agent.is_archived:
        # 아카이브된 에이전트로 **새 세션을 열 수 없다**. 기존 세션은 계속 돈다
        # (`plan/04-api.md` §2.8 — "조회는 되지만 새 사용이 불가").
        raise invalid(f"아카이브된 에이전트다: {body.agent_id}")

    from ma_domain.models import EffortIntent

    override = (
        ConfigOverride(
            model=ModelCardId(body.model) if body.model else None,
            effort=EffortIntent(body.effort) if body.effort else None,
        )
        if (body.model or body.effort)
        else None
    )

    now = graph.clock.now()
    rec = await graph.sessions.insert(
        InsertSession(
            record=SessionRecord(
                id=SessionId(graph.ids.next("session")),
                workspace_id=WorkspaceId(principal.workspace_id),
                agent_id=agent.id,
                # **버전을 핀한다** — 재현성의 근거다.
                agent_version=agent.version,
                environment_id=EnvironmentId(body.environment_id),
                environment_version=1,
                status=SessionStatus.IDLE,
                revision=0,
                created_by=principal.id,
                created_at=now,
                updated_at=now,
                config_override=override,
                budget=(
                    SessionBudget(limit_cents=body.budget_cents)
                    if body.budget_cents is not None
                    else None
                ),
            )
        )
    )
    return revalidate(SessionOut, session_out(rec))


@router.get("/{session_id}", response_model=SessionOut)
async def get_session(
    session_id: str, graph: CurrentGraph, principal: CurrentPrincipal
) -> dict[str, Any]:
    _require(principal, Role.VIEWER)
    rec = await graph.sessions.find(
        FindSession(workspace_id=WorkspaceId(principal.workspace_id), id=SessionId(session_id))
    )
    if rec is None:
        raise not_found("Session", session_id)
    return revalidate(SessionOut, session_out(rec))


@router.get("", response_model=PageOut)
async def list_sessions(
    graph: CurrentGraph,
    principal: CurrentPrincipal,
    limit: Annotated[int, Query(ge=1, le=200)] = 50,
    page: str | None = None,
    status: str | None = None,
    agent_id: str | None = None,
    created_by: str | None = None,
    created_after: datetime | None = None,
    created_before: datetime | None = None,
    session_status: str | None = None,
) -> dict[str, Any]:
    """상태·에이전트·생성자·기간 필터 (`T-0503`).

    **`session_status` 는 옛 이름이다.** 받아 주되 `status` 가 이긴다 —
    이미 나간 링크를 깨지 않으면서 콘솔이 자연스러운 이름을 쓰게 한다.
    """
    _require(principal, Role.VIEWER)
    from ma_api.shared.pagination import decode

    wanted = status or session_status
    try:
        parsed = SessionStatus(wanted) if wanted else None
    except ValueError:
        # **모르는 상태는 400 이다.** 빈 목록을 돌려주면 사용자는
        # "세션이 없다"고 읽는데, 실제로는 오타다.
        raise invalid(f"모르는 세션 상태: {wanted!r}") from None

    got = await graph.sessions.list_sessions(
        ListSessions(
            workspace_id=WorkspaceId(principal.workspace_id),
            limit=limit,
            after=decode(page),
            status=parsed,
            agent_id=agent_id,
            created_by=created_by,
            created_at_gte=created_after,
            created_at_lte=created_before,
        )
    )
    items = [revalidate(SessionOut, session_out(r)) for r in got.items]
    return revalidate(PageOut, page_body(got, items))


@router.post("/{session_id}/archive", response_model=SessionOut)
async def archive_session(
    session_id: str, graph: CurrentGraph, principal: CurrentPrincipal
) -> dict[str, Any]:
    _require(principal, Role.OPERATOR)
    res = await graph.sessions.archive(
        WorkspaceId(principal.workspace_id), SessionId(session_id), graph.clock.now()
    )
    if isinstance(res, NotFound):
        raise not_found("Session", session_id)
    if isinstance(res, VersionConflict):  # pragma: no cover — archive 는 CAS 하지 않는다
        from ma_api.shared.errors import version_conflict

        raise version_conflict(res.actual_version)
    return revalidate(SessionOut, session_out(res.record))


@router.post("/{session_id}/terminate", response_model=SessionOut)
async def terminate_session(
    session_id: str, graph: CurrentGraph, principal: CurrentPrincipal
) -> dict[str, Any]:
    """**정상 완료는 `idle` 이지 `terminated` 가 아니다** (CMA 계약).

    `terminated` 는 "더 이상 쓸 수 없다"는 뜻이고, 이 엔드포인트는 사람이
    명시적으로 그렇게 만드는 유일한 길이다.
    """
    _require(principal, Role.OPERATOR)
    res = await graph.sessions.update_status(
        UpdateSessionStatus(
            workspace_id=WorkspaceId(principal.workspace_id),
            id=SessionId(session_id),
            status=SessionStatus.TERMINATED,
            now=graph.clock.now(),
        )
    )
    if isinstance(res, NotFound):
        raise not_found("Session", session_id)
    if isinstance(res, VersionConflict):  # pragma: no cover
        from ma_api.shared.errors import version_conflict

        raise version_conflict(res.actual_version)
    return revalidate(SessionOut, session_out(res.record))
