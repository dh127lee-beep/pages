"""내부 lane 의 wire 스키마. **전부 `StrictModel`** — 모르는 필드를 거부한다.

`plan/04-api.md` §3 · `plan/09-codebase.md` §5.

여기 없는 필드는 나가지 않는다. 그래서 유스케이스에 내부 필드를 추가해도
wire 가 조용히 넓어지지 않는다.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import Field

from ma_api.shared.revalidate import StrictModel


# ── 에이전트 ───────────────────────────────────────────────
class ToolConfigIn(StrictModel):
    name: str
    enabled: bool = True
    permission_policy: Literal["always_allow", "always_ask"] | None = None


class ToolsetIn(StrictModel):
    type: Literal["agent_toolset"] = "agent_toolset"
    configs: tuple[ToolConfigIn, ...] = ()
    default_permission_policy: Literal["always_allow", "always_ask"] = "always_allow"


class AgentIn(StrictModel):
    name: str = Field(min_length=1, max_length=200)
    model: str = Field(min_length=1)
    system: str | None = None
    toolset: ToolsetIn | None = None
    harness: str = "default"
    effort: Literal["low", "medium", "high", "max"] | None = None
    description: str | None = None


class AgentOut(StrictModel):
    id: str
    version: int
    name: str
    model: str
    system: str | None = None
    harness: str = "default"
    effort: str | None = None
    description: str | None = None
    created_at: datetime
    updated_at: datetime
    archived_at: datetime | None = None


# ── 세션 ───────────────────────────────────────────────────
class SessionIn(StrictModel):
    agent_id: str = Field(min_length=1)
    environment_id: str = "env_default"
    model: str | None = None
    effort: Literal["low", "medium", "high", "max"] | None = None
    budget_cents: int | None = Field(default=None, ge=0)


class SessionOut(StrictModel):
    id: str
    agent_id: str
    agent_version: int
    environment_id: str
    environment_version: int
    status: str
    revision: int
    stop_reason: str | None = None
    required_action: str | None = None
    budget_cents: int | None = None
    spent_cents: int = 0
    created_by: str
    created_at: datetime
    updated_at: datetime


# ── 이벤트 ─────────────────────────────────────────────────
class EventIn(StrictModel):
    type: str = Field(min_length=1)
    content: dict[str, Any] = Field(default_factory=dict)
    thread_id: str = "primary"


class SendEventsIn(StrictModel):
    events: tuple[EventIn, ...] = Field(min_length=1)
    expected_revision: int | None = None


class SendEventsOut(StrictModel):
    accepted: tuple[str, ...]
    revision: int
    replayed: bool = False


class EventOut(StrictModel):
    id: str
    seq: int
    type: str
    thread_id: str
    content: dict[str, Any]
    created_at: datetime


# ── 모델 카드 ──────────────────────────────────────────────
class ModelCardOut(StrictModel):
    """**`credential_id` 는 나가지 않는다.** 스키마에 없으므로 구조적으로 막힌다."""

    id: str
    provider: str
    wire_model: str
    max_input_tokens: int
    max_output_tokens: int
    supports_tools: bool
    supports_vision: bool
    supports_prompt_cache: bool
    enabled: bool


# ── 볼트 · 자격증명 (T-0401) ───────────────────────────────
#
# **평문 필드가 나가는 스키마에 아예 없다.** `extra="forbid"` + `revalidate`
# 가 "실수로 넣지 않기"에 의존하지 않게 만든다 — 유스케이스가 담아도 500 이
# 나지 200 이 나지 않는다 (`plan/04-api.md` §3.5).
class VaultIn(StrictModel):
    name: str = Field(min_length=1, max_length=100)


class VaultOut(StrictModel):
    id: str
    name: str
    version: int
    created_at: datetime
    archived_at: datetime | None = None


class CredentialIn(StrictModel):
    """**평문을 받는 유일한 wire 스키마.** 대응하는 Out 은 없다."""

    kind: Literal["bearer", "basic", "api_key_header", "mcp_oauth", "environment_variable"]
    secret: str = Field(min_length=1, max_length=8192, repr=False)
    match_hosts: tuple[str, ...] = ()
    mcp_server_name: str | None = None
    header_name: str | None = None
    expires_at: datetime | None = None


class CredentialRotateIn(StrictModel):
    secret: str = Field(min_length=1, max_length=8192, repr=False)
    expires_at: datetime | None = None


# ── self_hosted 워커 (T-0606) ──────────────────────────────
class WorkPollIn(StrictModel):
    """워커가 일을 달라고 한다. **TTL 을 못 정한다** — 서버가 정한다."""

    worker_id: str = Field(min_length=1, max_length=200)
    #: long-poll 대기(ms). 0 이면 바로 돌아온다.
    block_ms: int = Field(default=0, ge=0, le=30_000)


class WorkOut(StrictModel):
    """큐 항목. **시크릿이 없다** — `WorkGrantOut` 에만 한 번 실린다."""

    id: str
    environment_id: str
    environment_version: int
    session_id: str
    state: str
    claim_generation: int
    attempts: int
    worker_id: str | None = None
    created_at: datetime
    updated_at: datetime
    claimed_at: datetime | None = None
    heartbeat_at: datetime | None = None
    acked_at: datetime | None = None
    error: str = ""


class WorkGrantOut(StrictModel):
    """집은 결과. **시크릿이 한 번만 실린다** (`credentials` 와 같은 규칙).

    다시 물어볼 길이 없다 — 잃으면 하트비트를 끊고 다시 집는다.
    """

    work: WorkOut
    secret: str
    heartbeat_seconds: int


class WorkHeartbeatIn(StrictModel):
    worker_id: str = Field(min_length=1, max_length=200)
    #: **집을 때 받은 값.** 틀리면 거부된다 — 회수된 워커다.
    claim_generation: int = Field(ge=0)


class WorkToolResultIn(StrictModel):
    """툴 하나의 결과. `user.tool_result` 페이로드가 된다."""

    tool_use_id: str = Field(min_length=1)
    content: str = ""
    is_error: bool = False


class WorkAckIn(StrictModel):
    worker_id: str = Field(min_length=1, max_length=200)
    claim_generation: int = Field(ge=0)
    results: tuple[WorkToolResultIn, ...] = ()
    failed: bool = False
    error: str = Field(default="", max_length=1000)


class WorkStatsOut(StrictModel):
    environment_id: str
    queued: int
    claimed: int
    done: int
    failed: int
    expired: int
    #: 큐에 가장 오래 있는 것의 나이. **워커가 멈췄는지의 신호다** —
    #: `queued` 수만 보면 트래픽이 적은 환경과 구분이 안 된다.
    oldest_queued_seconds: int


class McpOauthValidateIn(StrictModel):
    """갱신 요청. **토큰을 받지 않는다** — 받을 수 있게 만들면 넘긴다."""

    #: `True` 면 만료 전이어도 갱신한다. 워커가 401 을 받았을 때 쓴다.
    force: bool = False
    session_id: str | None = None


class McpOauthValidateOut(StrictModel):
    """**새 토큰이 여기 없다.** 결과만 말한다.

    호출자(워커)가 알아야 하는 것은 "다시 시도해도 되는가"뿐이다.
    토큰은 프록시가 주입한다 (D5).
    """

    credential_id: str
    #: `still_valid` | `refreshed` | `rejected` | `not_oauth`
    outcome: str
    #: 다시 시도할 만한가. `rejected` + `permanent` 면 `False`.
    retryable: bool
    expires_at: datetime | None = None
    #: 실패 사유. **토큰 값이 실리지 않는다.**
    reason: str = ""


class CredentialOut(StrictModel):
    """**메타데이터만.** `secret`·`ciphertext`·`nonce` 필드가 없다.

    만든 직후에도 평문을 돌려주지 않는다 — "한 번은 보여 줘도 되지 않나"가
    가장 흔한 누출 경로이고, 그 응답이 로그·프록시 캐시·브라우저 히스토리에
    남는다.
    """

    id: str
    vault_id: str
    kind: str
    match_hosts: tuple[str, ...] = ()
    mcp_server_name: str | None = None
    header_name: str | None = None
    key_version: int
    created_by: str
    created_at: datetime
    expires_at: datetime | None = None
    rotated_at: datetime | None = None
    archived_at: datetime | None = None


# ── 메모리 (T-0501) ────────────────────────────────────────
#
# **`content` 가 양방향으로 다닌다.** 비밀이 아니라 에이전트의 메모이고,
# 돌려주지 않으면 콘솔이 편집기를 만들 수 없다. 대신 **버전 본문은
# 레댁션될 수 있어** `MemoryVersionOut.content` 가 `None` 을 허용한다.
class MemoryStoreIn(StrictModel):
    name: str = Field(min_length=1, max_length=100)
    slug: str = Field(min_length=1, max_length=63, pattern=r"^[a-z0-9][a-z0-9_-]*$")


class MemoryStoreOut(StrictModel):
    id: str
    name: str
    slug: str
    #: `/mnt/memory/<slug>`. **서버가 계산해서 준다** — 클라이언트가
    #: 조립하면 경로 규칙이 두 벌이 된다.
    mount_path: str
    revision: int
    created_at: datetime
    archived_at: datetime | None = None


class MemoryWriteIn(StrictModel):
    """CAS 는 `precondition_sha256` 으로.

    **필드를 생략하는 것과 `null` 을 보내는 것이 같은 뜻이다** — 둘 다
    "신규여야 한다"는 주장이다. 이미 있으면 409 가 난다. 덮어쓰려면
    지금 해시를 실어야 한다.
    """

    path: str = Field(min_length=1, max_length=512)
    content: str = Field(max_length=100 * 1024)
    precondition_sha256: str | None = Field(default=None, pattern=r"^[0-9a-f]{64}$")


class MemoryOut(StrictModel):
    id: str
    store_id: str
    path: str
    content: str
    content_sha256: str
    revision: int
    created_at: datetime
    updated_at: datetime


class MemoryVersionOut(StrictModel):
    """감사용. **`content` 가 `None` 이면 레댁션된 것이다** —
    `content_sha256` 은 남아서 "무엇이 지워졌는가"를 추적할 수 있다."""

    id: str
    store_id: str
    memory_id: str
    path: str
    content: str | None
    content_sha256: str
    author: str
    created_at: datetime
    redacted_at: datetime | None = None
    redacted_by: str | None = None


# ── 에이전트 린트 · 버전 (T-0504) ─────────────────────────
class AgentValidateIn(StrictModel):
    """저장 전 린트 입력.

    `tier` 를 주면 **샌드박스와의 모순**까지 본다 — 티어 W 에 `bash` 를
    켜 두는 것 같은 오류를 세션 생성 시점이 아니라 **편집 시점에** 잡는다.
    """

    agent: AgentIn
    tier: Literal["wasm", "process", "vm"] | None = None


class AgentValidateOut(StrictModel):
    """**린트는 200 이다.** 문제가 있어도 400 이 아니다.

    400 으로 하면 클라이언트의 에러 처리가 "저장 실패"와 "린트 결과"를
    구분하지 못한다. 린트는 **물어본 것에 답한 것**이고, 답이 "문제가
    있다"일 뿐이다.
    """

    ok: bool
    reasons: tuple[str, ...] = ()


class AgentRevertIn(StrictModel):
    """되돌릴 버전. **새 버전을 만든다** — 이력을 지우지 않는다."""

    to_version: int = Field(ge=1)
    expected_version: int = Field(ge=1)


# ── 웹훅 (T-0604) ──────────────────────────────────────────
class WebhookIn(StrictModel):
    """**https 만 받는다.** 서명이 있어도 본문이 평문으로 나간다."""

    url: str = Field(min_length=8, pattern=r"^https://")
    #: 비면 **전부** 구독. 명시적으로 비우는 것이 의도다.
    events: tuple[str, ...] = ()
    description: str = Field(default="", max_length=200)


class WebhookOut(StrictModel):
    """**`secret` 이 없다.** 생성 응답에만 한 번 실린다."""

    id: str
    url: str
    events: tuple[str, ...] = ()
    description: str
    active: bool
    created_at: datetime | None = None
    disabled_at: datetime | None = None


class WebhookCreatedOut(StrictModel):
    """생성 직후 **한 번만**. 다시 물어볼 길이 없다 — 잃으면 새로 만든다."""

    endpoint: WebhookOut
    secret: str
    #: 서명 검증 방법. 수신 측 구현자가 이것만 보고 쓸 수 있어야 한다.
    signature_header: str
    signature_scheme: str


class DeliveryOut(StrictModel):
    id: str
    endpoint_id: str
    event: str
    state: str
    attempts: int
    created_at: datetime
    next_attempt_at: datetime | None = None
    delivered_at: datetime | None = None
    #: **왜 죽었는가.** DLQ 에서 이것을 읽는다.
    last_error: str = ""
    last_status: int | None = None


# ── 스킬 (T-0602) ──────────────────────────────────────────
class SkillFileIn(StrictModel):
    path: str = Field(min_length=1, max_length=256)
    content: str = Field(max_length=1024 * 1024)


class SkillSourceIn(StrictModel):
    """GitHub 좌표. 주면 **서버가 읽어 온다** — `files` 는 무시된다."""

    repo: str = Field(min_length=3, pattern=r"^[^/]+/[^/]+$")
    path: str = ""
    ref: str = "main"
    #: 비면 서버가 `ref` 의 현재 SHA 를 박는다.
    commit: str = Field(default="", max_length=40)


class SkillIn(StrictModel):
    name: str = Field(min_length=1, max_length=100)
    #: `/mnt/skills/<slug>` 가 된다. **겹치면 409.**
    slug: str = Field(min_length=1, max_length=63, pattern=r"^[a-z0-9][a-z0-9_-]*$")
    description: str = Field(default="", max_length=200)
    files: tuple[SkillFileIn, ...] = ()
    source: SkillSourceIn | None = None


class SkillOut(StrictModel):
    id: str
    name: str
    slug: str
    description: str
    version: int
    #: `/mnt/skills/<slug>`. **서버가 계산해서 준다.**
    mount_path: str
    file_count: int
    total_bytes: int
    #: GitHub 에서 왔으면 그 커밋. **브랜치가 아니다.**
    source_repo: str | None = None
    source_commit: str | None = None
    created_at: datetime
    updated_at: datetime
    archived_at: datetime | None = None


class SkillFileOut(StrictModel):
    path: str
    content: str


class SkillCatalogOut(StrictModel):
    """프롬프트 접두사에 들어갈 문자열. **매 턴 같아야 한다** (D12b)."""

    text: str
    entries: int


# ── 파일 · 산출물 (T-0502) ─────────────────────────────────
#
# **업로드 입력 스키마가 없다.** multipart 는 pydantic 본문이 아니라
# `UploadFile` 로 들어온다. 대신 나가는 쪽은 전부 검증한다.
class FileOut(StrictModel):
    id: str
    #: 사용자가 올린 이름 그대로.
    filename: str
    #: 마운트에 쓰이는 정규화 이름. **둘 다 준다** — 에이전트가 보는
    #: 이름과 사람이 올린 이름이 다를 수 있다는 것을 숨기지 않는다.
    safe_name: str
    content_type: str
    size_bytes: int
    sha256: str
    created_by: str
    created_at: datetime
    #: `null` 이면 **바이트가 아직 없다.** 마운트되지 않는다.
    uploaded_at: datetime | None = None
    mount_path: str


class OutputOut(StrictModel):
    id: str
    session_id: str
    path: str
    content_type: str
    size_bytes: int
    sha256: str
    #: 어느 세대가 만들었는가. 좀비가 쓴 산출물을 가려낸다 (D3).
    generation: int
    created_at: datetime


# ── 승인 (T-0403) ──────────────────────────────────────────
class ApprovalOut(StrictModel):
    """인박스에 뜨는 것. **툴 인자 전체가 없다** — `input_summary` 만.

    전체를 담으면 비밀이 섞이고, 담은 순간 그것이 `agent.tool_use`
    이벤트의 두 번째 복사본이 되어 drift 한다 (`plan/02` §7).
    """

    id: str
    session_id: str
    event_id: str
    tool_call_id: str
    tool_name: str
    tool_kind: str
    state: Literal["pending", "approved", "denied", "expired"]
    input_summary: dict[str, Any] = Field(default_factory=dict)
    policy_id: str | None = None
    decided_by: tuple[str, ...] = ()
    decided_at: datetime | None = None
    reason: str | None = None
    requested_at: datetime
    expires_at: datetime | None = None


class ApprovalDecisionIn(StrictModel):
    approve: bool
    reason: str | None = Field(default=None, max_length=1000)


# ── 감사 (T-0404) ──────────────────────────────────────────
class AuditEntryOut(StrictModel):
    """`detail` 은 **가려진 뒤**다 (`ma_governance.audit.redact`)."""

    actor_type: Literal["user", "api_key", "system", "agent"]
    actor_id: str
    action: str
    resource_type: str
    resource_id: str
    session_id: str | None = None
    detail: dict[str, Any] = Field(default_factory=dict)
    request_id: str | None = None
    created_at: datetime


class TimelineItemOut(StrictModel):
    at: datetime
    source: Literal["session_event", "approval", "credential_event", "audit_log"]
    kind: str
    summary: str
    actor: str | None = None
    tool_call_id: str | None = None
    detail: dict[str, Any] = Field(default_factory=dict)


class TimelineOut(StrictModel):
    """세션 하나의 전체 감사.

    `counts` 가 0 이면 **"일이 없었다"가 아니라 "그 소스가 비었다"** 일 수
    있다 — 네 소스의 보존 기간이 다르기 때문이다.
    """

    session_id: str
    timeline: tuple[TimelineItemOut, ...]
    counts: dict[str, int] = Field(default_factory=dict)
    truncated: bool = False


# ── 예산 · 사용량 (T-0405) ────────────────────────────────
class BudgetIn(StrictModel):
    scope: Literal["workspace", "agent", "user"] = "workspace"
    scope_id: str | None = None
    period: Literal["daily", "monthly", "total"] = "monthly"
    limit_cents: int = Field(gt=0)
    session_default_cents: int | None = Field(default=None, gt=0)
    #: `False` 면 경고만 하고 막지 않는다.
    hard: bool = True


class BudgetOut(StrictModel):
    scope: str
    scope_id: str | None = None
    period: str
    limit_cents: int
    session_default_cents: int | None = None
    hard: bool


class UsageSummaryOut(StrictModel):
    """**캐시 히트/미스를 나눠 보여 준다** (`plan/06` §5 의 지렛대)."""

    since: datetime
    until: datetime
    total_cents: str
    cache_hit_tokens: int
    cache_miss_tokens: int
    output_tokens: int
    cache_hit_ratio: str
    #: off-peak 지출과 비율. **캐시 다음가는 지렛대다** (D12b).
    off_peak_cents: str
    off_peak_ratio: str
    events: int


class UsageEventOut(StrictModel):
    session_id: str
    thread_id: str | None = None
    agent_id: str | None = None
    model_card_id: str
    wire_model: str
    input_cache_hit_tokens: int
    input_cache_miss_tokens: int
    output_tokens: int
    list_cost_cents: str
    sandbox_seconds: int
    created_at: datetime


# ── 공통 ───────────────────────────────────────────────────
class PageOut(StrictModel):
    data: tuple[Any, ...]
    has_more: bool
    next_page: str | None = None


class HealthOut(StrictModel):
    status: Literal["ok", "degraded"]
    checks: dict[str, str] = Field(default_factory=dict)


# ── 배포 ───────────────────────────────────────────────────
class DeploymentIn(StrictModel):
    """배포 생성. **에이전트 버전을 반드시 핀한다.**

    "현재 버전"을 돌리면 누군가 에이전트를 고친 다음 날 새벽 3시에
    다른 것이 돈다 — 그리고 아무도 보고 있지 않다.
    """

    name: str = Field(min_length=1, max_length=200)
    agent_id: str = Field(min_length=1)
    agent_version: int = Field(ge=1)
    environment_id: str | None = None
    #: 5-필드 POSIX cron. 없으면 **수동 실행만** 한다.
    cron: str | None = Field(default=None, max_length=200)
    timezone: str = Field(default="UTC", max_length=64)
    off_peak_preferred: bool = False
    #: off-peak 이동 상한. 넘으면 **안 민다** — 결과가 늦어 쓸모없어진다.
    max_shift_hours: int = Field(default=6, ge=0, le=24)
    initial_events: tuple[dict[str, Any], ...] = ()
    #: **실행 하나당** 상한. 사람이 안 보므로 특히 중요하다.
    budget_cents: int | None = Field(default=None, gt=0)


class DeploymentOut(StrictModel):
    id: str
    name: str
    agent_id: str
    agent_version: int
    state: str
    environment_id: str | None = None
    cron: str | None = None
    timezone: str | None = None
    off_peak_preferred: bool = False
    budget_cents: int | None = None
    consecutive_failures: int = 0
    created_at: datetime
    updated_at: datetime
    last_run_at: datetime | None = None
    next_fire_at: datetime | None = None
    #: 다음 발화 5개. **이동 전 시각이다** — off-peak 이동은 발화
    #: 시점의 peak 창을 봐야 정해지므로 미리 말할 수 없다.
    next_fire_times: tuple[datetime, ...] = ()
    paused_reason: str = ""


class DeploymentPauseIn(StrictModel):
    reason: str = Field(default="", max_length=500)


class DeploymentRunIn(StrictModel):
    """수동 실행. **off-peak 로 밀지 않는다** — 사람이 지금 눌렀다."""

    reason: str = Field(default="", max_length=500)


class DeploymentRunOut(StrictModel):
    id: str
    deployment_id: str
    state: str
    trigger: str
    scheduled_for: datetime
    created_at: datetime
    session_id: str | None = None
    started_at: datetime | None = None
    ended_at: datetime | None = None
    #: off-peak 로 **몇 초** 밀렸는가. 0 이면 안 밀렸다.
    shifted_by_seconds: int = 0
    error: str = ""
    cost_cents: int = 0


__all__ = [
    "AgentIn",
    "AgentOut",
    "AgentRevertIn",
    "AgentValidateIn",
    "AgentValidateOut",
    "ApprovalDecisionIn",
    "ApprovalOut",
    "AuditEntryOut",
    "BudgetIn",
    "BudgetOut",
    "CredentialIn",
    "CredentialOut",
    "CredentialRotateIn",
    "DeliveryOut",
    "DeploymentIn",
    "DeploymentOut",
    "DeploymentPauseIn",
    "DeploymentRunIn",
    "DeploymentRunOut",
    "EventIn",
    "EventOut",
    "FileOut",
    "HealthOut",
    "McpOauthValidateIn",
    "McpOauthValidateOut",
    "MemoryOut",
    "MemoryStoreIn",
    "MemoryStoreOut",
    "MemoryVersionOut",
    "MemoryWriteIn",
    "ModelCardOut",
    "OutputOut",
    "PageOut",
    "SendEventsIn",
    "SendEventsOut",
    "SessionIn",
    "SessionOut",
    "SkillCatalogOut",
    "SkillFileIn",
    "SkillFileOut",
    "SkillIn",
    "SkillOut",
    "SkillSourceIn",
    "TimelineItemOut",
    "TimelineOut",
    "ToolConfigIn",
    "ToolsetIn",
    "UsageEventOut",
    "UsageSummaryOut",
    "VaultIn",
    "VaultOut",
    "WebhookCreatedOut",
    "WebhookIn",
    "WebhookOut",
    "WorkAckIn",
    "WorkGrantOut",
    "WorkHeartbeatIn",
    "WorkOut",
    "WorkPollIn",
    "WorkStatsOut",
    "WorkToolResultIn",
]
