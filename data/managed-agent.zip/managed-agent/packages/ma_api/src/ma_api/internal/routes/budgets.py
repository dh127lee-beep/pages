"""예산과 사용량. `plan/04-api.md` §7 · `plan/06-harness-and-model.md` §5.

**쿼터·예산 초과는 409 다** (429 아님). 429 는 "잠시 뒤 다시"인데, 예산
초과는 재시도해도 안 된다 — 클라이언트가 지수 백오프로 두드리면 그 자체가
부하다.
"""

from __future__ import annotations

from typing import Annotated, Any

from fastapi import APIRouter, Query, status
from ma_application.budgets import UsageSummary
from ma_domain.governance import Budget, BudgetPeriod, BudgetScope, UsageEvent
from ma_domain.ids import AgentId
from ma_domain.workspaces import Role

from ma_api.internal.deps import CurrentGraph, CurrentPrincipal
from ma_api.internal.schemas import (
    BudgetIn,
    BudgetOut,
    PageOut,
    UsageEventOut,
    UsageSummaryOut,
)
from ma_api.shared.errors import forbidden, invalid
from ma_api.shared.pagination import page_body
from ma_api.shared.revalidate import revalidate

router = APIRouter(prefix="/api/v1", tags=["budgets"])


def _require(principal: Any, role: Role) -> None:
    if not principal.role.at_least(role):
        raise forbidden(f"{role.value} 이상이 필요하다")


def budget_out(b: Budget) -> dict[str, Any]:
    return {
        "scope": b.scope.value,
        "scope_id": b.scope_id,
        "period": b.period.value,
        "limit_cents": b.limit_cents,
        "session_default_cents": b.session_default_cents,
        "hard": b.hard,
    }


def usage_out(e: UsageEvent) -> dict[str, Any]:
    return {
        "session_id": e.session_id,
        "thread_id": e.thread_id,
        "agent_id": e.agent_id,
        "model_card_id": e.model_card_id,
        "wire_model": e.wire_model,
        "input_cache_hit_tokens": e.usage.input_cache_hit,
        "input_cache_miss_tokens": e.usage.input_cache_miss,
        "output_tokens": e.usage.output,
        # **문자열로 내보낸다.** JSON 의 float 는 소수점을 잃고, 비용에서
        # 그 손실은 누적된다.
        "list_cost_cents": str(e.list_cost_cents),
        "sandbox_seconds": e.sandbox_seconds,
        "created_at": e.created_at,
    }


def summary_out(s: UsageSummary) -> dict[str, Any]:
    return {
        "since": s.since,
        "until": s.until,
        "total_cents": str(s.total_cents),
        "cache_hit_tokens": s.cache_hit_tokens,
        "cache_miss_tokens": s.cache_miss_tokens,
        "output_tokens": s.output_tokens,
        "cache_hit_ratio": str(s.cache_hit_ratio),
        "off_peak_cents": str(s.off_peak_cents),
        "off_peak_ratio": str(s.off_peak_ratio),
        "events": s.events,
    }


@router.put("/budgets", response_model=BudgetOut, status_code=status.HTTP_200_OK)
async def set_budget(
    body: BudgetIn, graph: CurrentGraph, principal: CurrentPrincipal
) -> dict[str, Any]:
    """예산을 세운다. **같은 스코프·기간이면 덮어쓴다.**

    `POST` 가 아니라 `PUT` 인 이유: 스코프와 기간이 곧 키다. 같은 것을
    두 번 만들 수 없으므로 생성과 수정이 같은 연산이다.
    """
    _require(principal, Role.ADMIN)
    from ma_domain.errors import InvariantViolation

    try:
        budget = Budget(
            workspace_id=principal.workspace_id,
            scope=BudgetScope(body.scope),
            period=BudgetPeriod(body.period),
            limit_cents=body.limit_cents,
            scope_id=body.scope_id,
            session_default_cents=body.session_default_cents,
            hard=body.hard,
        )
    except InvariantViolation as exc:
        raise invalid(str(exc)) from exc

    return revalidate(BudgetOut, budget_out(await graph.budgets.set_budget(budget)))


@router.get("/budgets", response_model=PageOut)
async def list_budgets(graph: CurrentGraph, principal: CurrentPrincipal) -> dict[str, Any]:
    _require(principal, Role.OPERATOR)
    got = await graph.budgets.list_budgets(principal.workspace_id)
    items = [revalidate(BudgetOut, budget_out(b)) for b in got]
    return revalidate(PageOut, {"data": tuple(items), "has_more": False})


@router.get("/usage", response_model=UsageSummaryOut)
async def usage_summary(
    graph: CurrentGraph,
    principal: CurrentPrincipal,
    period: Annotated[str, Query()] = "monthly",
    agent_id: Annotated[str | None, Query()] = None,
) -> dict[str, Any]:
    _require(principal, Role.OPERATOR)
    try:
        wanted = BudgetPeriod(period)
    except ValueError:
        raise invalid(f"모르는 기간: {period!r}") from None

    got = await graph.budgets.summary(
        principal.workspace_id,
        period=wanted,
        agent_id=AgentId(agent_id) if agent_id else None,
    )
    return revalidate(UsageSummaryOut, summary_out(got))


@router.get("/usage/events", response_model=PageOut)
async def list_usage(
    graph: CurrentGraph,
    principal: CurrentPrincipal,
    limit: Annotated[int, Query(ge=1, le=200)] = 50,
) -> dict[str, Any]:
    _require(principal, Role.OPERATOR)
    got = await graph.budgets.list_events(principal.workspace_id, limit=limit)
    items = [revalidate(UsageEventOut, usage_out(e)) for e in got.items]
    return revalidate(PageOut, page_body(got, items))
