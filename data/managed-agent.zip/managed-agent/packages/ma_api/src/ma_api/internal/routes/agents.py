"""에이전트 CRUD. `plan/04-api.md` §3.

수정은 `PATCH` 가 아니라 `POST /agents/{id}` 다 (§2.7) — 공식 계약을 따르고,
두 lane 의 모양을 다르게 할 이유가 없다.
"""

from __future__ import annotations

from typing import Annotated, Any

from fastapi import APIRouter, Query, Response, status
from ma_application.agents import (
    AgentArchived,
    AgentConflict,
    AgentCreated,
    AgentInvalid,
    AgentNotFound,
    AgentUpdated,
)
from ma_domain.environments import SandboxTier
from ma_domain.ids import AgentId
from ma_domain.workspaces import Role

from ma_api.internal.deps import CurrentGraph, CurrentPrincipal
from ma_api.internal.mappers.agents import definition_from, record_out
from ma_api.internal.schemas import (
    AgentIn,
    AgentOut,
    AgentRevertIn,
    AgentValidateIn,
    AgentValidateOut,
    PageOut,
)
from ma_api.shared.errors import forbidden, invalid, not_found, version_conflict
from ma_api.shared.pagination import page_body
from ma_api.shared.revalidate import revalidate

router = APIRouter(prefix="/api/v1/agents", tags=["agents"])


def _require(principal: Any, role: Role) -> None:
    """**얇은 게이트다.** 실제 권한 판단은 유스케이스가 한다 — 여기는
    명백히 잘못된 호출을 일찍 끊어 유스케이스가 헛일하지 않게 하는 것뿐이다."""
    if not principal.role.at_least(role):
        raise forbidden(f"{role.value} 이상이 필요하다")


@router.post("", response_model=AgentOut, status_code=status.HTTP_201_CREATED)
async def create_agent(
    body: AgentIn, graph: CurrentGraph, principal: CurrentPrincipal
) -> dict[str, Any]:
    _require(principal, Role.ADMIN)
    res = await graph.agents.create(definition_from(body), created_by=principal.id)
    match res:
        case AgentCreated(agent=rec):
            return revalidate(AgentOut, record_out(rec))
        case AgentInvalid(reasons=reasons):
            raise invalid("; ".join(reasons))
    raise invalid("처리하지 않은 결과")  # pragma: no cover


@router.post("/{agent_id}", response_model=AgentOut)
async def update_agent(
    agent_id: str,
    body: AgentIn,
    graph: CurrentGraph,
    principal: CurrentPrincipal,
    expected_version: Annotated[int, Query(ge=1)],
) -> dict[str, Any]:
    _require(principal, Role.ADMIN)
    res = await graph.agents.update(
        AgentId(agent_id), definition_from(body), expected_version=expected_version
    )
    match res:
        case AgentUpdated(agent=rec):
            return revalidate(AgentOut, record_out(rec))
        case AgentNotFound():
            raise not_found("Agent", agent_id)
        case AgentConflict(actual_version=v):
            raise version_conflict(v)
        case AgentInvalid(reasons=reasons):
            raise invalid("; ".join(reasons))
    raise invalid("처리하지 않은 결과")  # pragma: no cover


@router.post("/{agent_id}/archive", response_model=AgentOut)
async def archive_agent(
    agent_id: str,
    graph: CurrentGraph,
    principal: CurrentPrincipal,
    expected_version: Annotated[int, Query(ge=1)],
) -> dict[str, Any]:
    """**하드 삭제가 없다.** 과거 세션이 이 버전을 참조하므로 지우면
    감사 추적이 끊긴다 (`plan/04-api.md` §2.8)."""
    _require(principal, Role.ADMIN)
    res = await graph.agents.archive(AgentId(agent_id), expected_version=expected_version)
    match res:
        case AgentArchived(agent=rec):
            return revalidate(AgentOut, record_out(rec))
        case AgentNotFound():
            raise not_found("Agent", agent_id)
        case AgentConflict(actual_version=v):
            raise version_conflict(v)
    raise invalid("처리하지 않은 결과")  # pragma: no cover


# ── 린트 · 버전 (T-0504) ──────────────────────────────────
@router.post("/{agent_id}/validate", response_model=AgentValidateOut)
async def validate_agent(
    agent_id: str, body: AgentValidateIn, graph: CurrentGraph, principal: CurrentPrincipal
) -> dict[str, Any]:
    """**저장 전 린트.** 문제가 있어도 200 이다.

    400 으로 하면 클라이언트가 "저장 실패"와 "린트 결과"를 구분하지
    못한다 — 린트는 물어본 것에 답한 것이고, 답이 "문제가 있다"일 뿐이다.

    `agent_id` 를 받지만 **읽지 않는다.** 본문의 정의만 본다 — 아직
    저장되지 않은 초안을 검사하는 것이 목적이기 때문이다. 경로에 두는
    것은 "이 에이전트를 이렇게 고치려 한다"는 맥락을 남기려는 것이다.
    """
    _require(principal, Role.ADMIN)
    del agent_id
    reasons = graph.agents.validate(
        definition_from(body.agent),
        tier=SandboxTier(body.tier) if body.tier else None,
    )
    return revalidate(AgentValidateOut, {"ok": not reasons, "reasons": reasons})


@router.get("/{agent_id}/versions", response_model=PageOut)
async def list_agent_versions(
    agent_id: str,
    graph: CurrentGraph,
    principal: CurrentPrincipal,
    limit: Annotated[int, Query(ge=1, le=200)] = 50,
) -> dict[str, Any]:
    """버전 이력. **비교와 되돌리기의 입력이다.**"""
    _require(principal, Role.VIEWER)
    got = await graph.agents.list_versions(AgentId(agent_id), limit=limit)
    items = [revalidate(AgentOut, record_out(r)) for r in got.items]
    return revalidate(PageOut, page_body(got, items))


@router.get("/{agent_id}/versions/{version}", response_model=AgentOut)
async def get_agent_version(
    agent_id: str, version: int, graph: CurrentGraph, principal: CurrentPrincipal
) -> dict[str, Any]:
    _require(principal, Role.VIEWER)
    got = await graph.agents.get_version(AgentId(agent_id), version)
    if got is None:
        raise not_found("에이전트 버전", f"{agent_id}@{version}")
    return revalidate(AgentOut, record_out(got))


@router.post("/{agent_id}/revert", response_model=AgentOut)
async def revert_agent(
    agent_id: str, body: AgentRevertIn, graph: CurrentGraph, principal: CurrentPrincipal
) -> dict[str, Any]:
    """옛 버전의 내용으로 **새 버전을 만든다.**

    이력을 지우거나 되감지 않는다. 진행 중인 세션은 자기가 핀한 버전을
    계속 쓰고(`plan/04` §3), 되돌린 결과는 **그 뒤에 생기는 세션**부터
    적용된다 — 되감으면 진행 중인 세션의 행동이 중간에 바뀐다.
    """
    _require(principal, Role.ADMIN)
    old = await graph.agents.get_version(AgentId(agent_id), body.to_version)
    if old is None:
        raise not_found("에이전트 버전", f"{agent_id}@{body.to_version}")

    res = await graph.agents.update(
        AgentId(agent_id),
        old.definition,
        expected_version=body.expected_version,
    )
    match res:
        case AgentUpdated(agent=rec):
            return revalidate(AgentOut, record_out(rec))
        case AgentNotFound():
            raise not_found("Agent", agent_id)
        case AgentConflict(actual_version=actual):
            raise version_conflict(actual)
        case AgentInvalid(reasons=reasons):
            # 옛 버전이 **지금 규칙으로는 틀릴 수 있다.** 그때 조용히
            # 저장하면 린트가 장식이 된다.
            raise invalid("; ".join(reasons))
    raise invalid("처리하지 않은 결과")  # pragma: no cover


@router.get("/{agent_id}", response_model=AgentOut)
async def get_agent(
    agent_id: str, graph: CurrentGraph, principal: CurrentPrincipal
) -> dict[str, Any]:
    _require(principal, Role.VIEWER)
    rec = await graph.agents.get(AgentId(agent_id))
    if rec is None:
        # **없음과 다른 워크스페이스를 구분하지 않는다.**
        raise not_found("Agent", agent_id)
    return revalidate(AgentOut, record_out(rec))


@router.get("", response_model=PageOut)
async def list_agents(
    graph: CurrentGraph,
    principal: CurrentPrincipal,
    response: Response,
    limit: Annotated[int, Query(ge=1, le=200)] = 50,
    page: str | None = None,
    include_archived: bool = False,
) -> dict[str, Any]:
    _require(principal, Role.VIEWER)
    got = await graph.agents.list(limit=limit, after=page, include_archived=include_archived)
    items = [revalidate(AgentOut, record_out(r)) for r in got.items]
    return revalidate(PageOut, page_body(got, items))
