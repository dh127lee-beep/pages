"""MCP — 워커가 갱신을 맡기는 길 (T-0601).

`plan/07-sandbox.md` §6 · `ADR-0009`.

> 라우터가 하나뿐이고, 그 하나가 **D5 의 경첩**이다.

워커는 MCP 서버에서 401 을 받으면 여기를 부른다. 왜 워커가 직접
갱신하지 않는가:

| | |
|---|---|
| 갱신 토큰은 access token 보다 세다 | 그것으로 토큰을 **새로 만들 수 있다** |
| 루트 시크릿이 제어 평면에만 있다 | 워커는 복호화할 수 없다 (`ADR-0009`) |
| 워커 DB 역할은 `credentials` 를 못 읽는다 | 메타데이터조차 (`plan/05` §7) |

**경로에 자격증명 id 가 없다.** 워커는 서버 이름만 알고, 제어 평면이
세션의 볼트 범위 안에서 찾는다 — 워커가 id 를 알면 그것으로 할 수
있는 일이 늘어난다.
"""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter
from ma_application.mcp import (
    CredentialGone,
    CredentialNotOauth,
    RefreshRejected,
    RefreshSucceeded,
    StillValid,
)
from ma_domain.ids import SessionId
from ma_domain.workspaces import Role
from ma_store.sessions import FindSession

from ma_api.internal.deps import CurrentGraph, CurrentPrincipal
from ma_api.internal.schemas import McpOauthValidateIn, McpOauthValidateOut
from ma_api.shared.errors import forbidden, invalid, not_found
from ma_api.shared.revalidate import revalidate

router = APIRouter(prefix="/api/v1/sessions", tags=["mcp"])


@router.post("/{session_id}/mcp/{server_name}/refresh", response_model=McpOauthValidateOut)
async def refresh_session_mcp(
    session_id: str,
    server_name: str,
    body: McpOauthValidateIn,
    graph: CurrentGraph,
    principal: CurrentPrincipal,
) -> dict[str, Any]:
    """세션이 쓰는 MCP 서버의 OAuth 자격증명을 갱신한다.

    **세션의 볼트 범위 안에서만** 찾는다. 범위 밖의 것을 갱신해 주면
    볼트로 준 경계가 장식이 된다.

    **응답에 토큰이 없다.** 워커가 알아야 하는 것은 "다시 시도해도
    되는가"뿐이고, 토큰은 egress 프록시가 주입한다 (D5).
    """
    if not principal.role.at_least(Role.OPERATOR):
        raise forbidden("operator 이상이 필요하다")

    session = await graph.sessions.find(
        FindSession(workspace_id=principal.workspace_id, id=SessionId(session_id))
    )
    if session is None:
        raise not_found("Session", session_id)

    res = await graph.mcp.validate_for_server(
        principal.workspace_id,
        server_name,
        tuple(session.vault_ids),
        # 워커는 **서버가 먼저 401 을 줬을 때** 부른다 — 우리 만료
        # 시각이 틀린 것이므로 강제로 갱신한다.
        force=body.force,
        session_id=SessionId(session_id),
    )
    match res:
        case StillValid(credential=c):
            out = {"outcome": "still_valid", "retryable": True, "expires_at": c.expires_at}
        case RefreshSucceeded(credential=c):
            out = {"outcome": "refreshed", "retryable": True, "expires_at": c.expires_at}
        case RefreshRejected(reason=reason, permanent=permanent):
            out = {
                "outcome": "rejected",
                "retryable": not permanent,
                "expires_at": None,
                "reason": reason,
            }
        case CredentialNotOauth():
            out = {
                "outcome": "not_oauth",
                "retryable": False,
                "expires_at": None,
                "reason": "mcp_oauth 자격증명이 아니다",
            }
        case CredentialGone():
            # **없는 것도 404 가 아니다.** 자격증명 없이 도는 공개 MCP
            # 서버가 있고, 그 경우 401 은 다른 문제다 — 워커가 그것을
            # 구분할 수 있어야 한다.
            out = {
                "outcome": "not_found",
                "retryable": False,
                "expires_at": None,
                "reason": f"MCP 서버 {server_name} 에 묶인 OAuth 자격증명이 없다",
            }
        case _:  # pragma: no cover
            raise invalid("처리하지 않은 결과")
    return revalidate(McpOauthValidateOut, {"credential_id": f"mcp_oauth:{server_name}", **out})


__all__ = ["router"]
