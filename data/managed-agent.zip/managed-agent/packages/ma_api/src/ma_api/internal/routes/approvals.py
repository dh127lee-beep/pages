"""승인 인박스와 결정. `plan/04-api.md` §3.7 · `plan/02-architecture.md` §7.

**권한 판단은 여기서 하지 않는다.** 정책 해석(`ma_governance.approval`)과
그 적용(`ma_application.approvals`)이 한다 — 라우터에서 하면 CLI·웹훅·
스케줄러가 같은 규칙을 우회한다.

여기서 하는 일은 wire 번역과 **거부 사유 → HTTP 상태** 매핑뿐이다.
"""

from __future__ import annotations

from typing import Annotated, Any

from fastapi import APIRouter, Query
from ma_application.approvals import (
    ApprovalDecided,
    ApprovalForbidden,
    ApprovalNotFound,
    Decide,
)
from ma_domain.governance import Approval, ApprovalState
from ma_domain.ids import ApprovalId, UserId
from ma_governance.approval import Refusal

from ma_api.internal.deps import CurrentGraph, CurrentPrincipal
from ma_api.internal.schemas import ApprovalDecisionIn, ApprovalOut, PageOut
from ma_api.shared.errors import ApiError, ErrorType, forbidden, invalid, not_found
from ma_api.shared.pagination import page_body
from ma_api.shared.revalidate import revalidate

router = APIRouter(prefix="/api/v1/approvals", tags=["approvals"])

#: 거부 사유 → HTTP. **403 과 409 를 가른다.**
#:
#: "권한이 없다"는 403 이고 "이미 결정됐다"는 409 다. 둘을 뭉치면
#: 클라이언트가 재시도해야 할지 포기해야 할지 모른다.
_CONFLICTS = frozenset({Refusal.NOT_PENDING, Refusal.EXPIRED, Refusal.ALREADY_DECIDED_BY_YOU})


def approval_out(a: Approval) -> dict[str, Any]:
    return {
        "id": a.id,
        "session_id": a.session_id,
        "event_id": a.event_id,
        "tool_call_id": a.tool_call_id,
        "tool_name": a.tool_name,
        "tool_kind": a.tool_kind.value,
        "state": a.state.value,
        "input_summary": dict(a.input_summary),
        "policy_id": a.policy_id,
        "decided_by": a.decided_by,
        "decided_at": a.decided_at,
        "reason": a.reason,
        "requested_at": a.requested_at,
        "expires_at": a.expires_at,
    }


@router.get("", response_model=PageOut)
async def list_approvals(
    graph: CurrentGraph,
    principal: CurrentPrincipal,
    state: Annotated[str, Query()] = "pending",
    limit: Annotated[int, Query(ge=1, le=200)] = 50,
) -> dict[str, Any]:
    try:
        wanted = ApprovalState(state)
    except ValueError:
        raise invalid(f"모르는 상태: {state!r}") from None

    got = await graph.approvals.inbox(principal.workspace_id, state=wanted, limit=limit)
    items = [revalidate(ApprovalOut, approval_out(a)) for a in got.items]
    return revalidate(PageOut, page_body(got, items))


@router.get("/{approval_id}", response_model=ApprovalOut)
async def get_approval(
    approval_id: str, graph: CurrentGraph, principal: CurrentPrincipal
) -> dict[str, Any]:
    got = await graph.approvals.find(principal.workspace_id, ApprovalId(approval_id))
    if got is None:
        raise not_found("Approval", approval_id)
    return revalidate(ApprovalOut, approval_out(got))


@router.post("/{approval_id}", response_model=ApprovalOut)
async def decide_approval(
    approval_id: str,
    body: ApprovalDecisionIn,
    graph: CurrentGraph,
    principal: CurrentPrincipal,
) -> dict[str, Any]:
    """승인하거나 거부한다.

    **승인이 표를 채우면 세션이 재개된다** — 그 재개는 유스케이스가
    세션 이벤트를 수용해 일으킨다. 라우터는 그것을 모른다.
    """
    res = await graph.approvals.decide(
        Decide(
            workspace_id=principal.workspace_id,
            approval_id=ApprovalId(approval_id),
            actor=UserId(principal.id),
            actor_role=principal.role,
            approve=body.approve,
            reason=body.reason,
        )
    )
    match res:
        case ApprovalDecided(approval=a):
            return revalidate(ApprovalOut, approval_out(a))
        case ApprovalNotFound():
            raise not_found("Approval", approval_id)
        case ApprovalForbidden(refusal=refusal):
            raise _refusal_error(refusal)
    raise invalid("처리하지 않은 결과")  # pragma: no cover


def _refusal_error(refusal: Refusal) -> ApiError:
    """**사유를 코드로 싣는다.** 클라이언트가 분기할 수 있어야 한다."""
    if refusal in _CONFLICTS:
        return ApiError(
            ErrorType.CONFLICT,
            _MESSAGES[refusal],
            extra=(("code", refusal.value),),
        )
    return forbidden(_MESSAGES[refusal])


_MESSAGES = {
    Refusal.ROLE_TOO_LOW: "이 툴을 승인할 권한이 없다",
    Refusal.SELF_APPROVAL: "본인이 올린 세션은 본인이 승인할 수 없다",
    Refusal.ALREADY_DECIDED_BY_YOU: "이미 결정했다 — 혼자 두 표를 채울 수 없다",
    Refusal.NOT_PENDING: "이미 결정된 승인이다",
    Refusal.EXPIRED: "승인 기한이 지났다",
}
