"""스킬 wire 변환. `plan/01-product-concept.md` §4.

**파일 내용은 목록에 싣지 않는다.** 스킬 하나가 1MB 까지 가능하고,
목록이 20개면 응답이 20MB 다. 내용은 `GET /skills/{id}/files` 로만
나간다 — 점진적 공개가 API 에도 적용된다.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from ma_domain.skills import SkillRecord


def skill_out(s: SkillRecord) -> dict[str, Any]:
    source = s.document.source
    return {
        "id": s.id,
        "name": s.name,
        "slug": s.slug,
        "description": s.document.description,
        "version": s.version,
        # **서버가 계산한다** — 클라이언트가 조립하면 규칙이 두 벌이 된다.
        "mount_path": s.mount_path,
        "file_count": len(s.document.files),
        "total_bytes": s.document.total_bytes,
        # **커밋이지 브랜치가 아니다.** 브랜치를 보여 주면 "이 버전이
        # 무엇을 담고 있는가"를 말해 주지 못한다.
        "source_repo": source.repo if source else None,
        "source_commit": source.commit if source else None,
        "created_at": s.created_at,
        "updated_at": s.updated_at,
        "archived_at": s.archived_at,
    }


def files_out(s: SkillRecord) -> list[dict[str, Any]]:
    return [{"path": f.path, "content": f.content} for f in s.document.files]


__all__ = ["files_out", "skill_out"]
