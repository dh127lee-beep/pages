"""배포. `plan/04-api.md` §3 · `ref/api/deployments/`.

배포는 **사람이 안 보는 동안 도는 것**이다. 그래서 다른 리소스와 다른
점이 셋 있다:

| | 왜 |
|---|---|
| 에이전트 버전을 핀한다 | 고친 다음 날 새벽 3시에 다른 것이 돌면 안 된다 |
| 실행별 예산이 있다 | 멈출 사람이 없다 |
| 세 번 연속 실패하면 자동으로 멈춘다 | 고장난 배포가 매시간 돈을 쓴다 |
"""

from __future__ import annotations

from typing import Annotated, Any

from fastapi import APIRouter, Query, Response, status
from ma_application.deployments import (
    AlreadyRan,
    CreateDeployment,
    Deferred,
    DeploymentCreated,
    DeploymentInvalid,
    DeploymentMissing,
    DeploymentUpdated,
    Fired,
    Skipped,
)
from ma_domain.deployments import RunTrigger
from ma_domain.ids import AgentId, EnvironmentId
from ma_domain.workspaces import Role

from ma_api.internal.deps import CurrentGraph, CurrentPrincipal
from ma_api.internal.schemas import (
    DeploymentIn,
    DeploymentOut,
    DeploymentPauseIn,
    DeploymentRunIn,
    DeploymentRunOut,
    PageOut,
)
from ma_api.shared.errors import conflict, forbidden, invalid, not_found
from ma_api.shared.pagination import page_body
from ma_api.shared.revalidate import revalidate

router = APIRouter(prefix="/api/v1/deployments", tags=["deployments"])


def _require(principal: Any, role: Role) -> None:
    if not principal.role.at_least(role):
        raise forbidden(f"{role.value} 이상이 필요하다")


def _out(d: Any, *, next_fire_times: tuple[Any, ...] = ()) -> dict[str, Any]:
    schedule = d.schedule
    return {
        "id": d.id,
        "name": d.name,
        "agent_id": d.agent_id,
        "agent_version": d.agent_version,
        "state": d.state.value,
        "environment_id": d.environment_id,
        "cron": schedule.cron if schedule else None,
        "timezone": schedule.timezone if schedule else None,
        "off_peak_preferred": bool(schedule and schedule.off_peak_preferred),
        "budget_cents": d.budget_cents,
        "consecutive_failures": d.consecutive_failures,
        "created_at": d.created_at,
        "updated_at": d.updated_at,
        "last_run_at": d.last_run_at,
        "next_fire_at": d.next_fire_at,
        "next_fire_times": next_fire_times,
        "paused_reason": d.paused_reason,
    }


def _run_out(r: Any) -> dict[str, Any]:
    return {
        "id": r.id,
        "deployment_id": r.deployment_id,
        "state": r.state.value,
        "trigger": r.trigger.value,
        "scheduled_for": r.scheduled_for,
        "created_at": r.created_at,
        "session_id": r.session_id,
        "started_at": r.started_at,
        "ended_at": r.ended_at,
        "shifted_by_seconds": int(r.shifted_by.total_seconds()),
        "error": r.error,
        "cost_cents": r.cost_cents,
    }


@router.post("", response_model=DeploymentOut, status_code=status.HTTP_201_CREATED)
async def create_deployment(
    body: DeploymentIn, graph: CurrentGraph, principal: CurrentPrincipal
) -> dict[str, Any]:
    res = await graph.deployments.create(
        CreateDeployment(
            workspace_id=principal.workspace_id,
            name=body.name,
            agent_id=AgentId(body.agent_id),
            agent_version=body.agent_version,
            environment_id=EnvironmentId(body.environment_id) if body.environment_id else None,
            cron=body.cron,
            timezone=body.timezone,
            off_peak_preferred=body.off_peak_preferred,
            max_shift_hours=body.max_shift_hours,
            initial_events=body.initial_events,
            budget_cents=body.budget_cents,
            created_by=f"{principal.kind}:{principal.id}",
        )
    )
    match res:
        case DeploymentCreated(deployment=made):
            return revalidate(
                DeploymentOut, _out(made, next_fire_times=graph.deployments.upcoming(made))
            )
        case DeploymentInvalid(reasons=reasons):
            # **cron 오타를 여기서 잡는다.** 저장하면 발화 시각에야
            # 드러나고, 그때는 아무도 안 보고 있다.
            raise invalid("; ".join(reasons))
    raise invalid("처리하지 않은 결과")  # pragma: no cover


@router.get("", response_model=PageOut)
async def list_deployments(
    graph: CurrentGraph,
    principal: CurrentPrincipal,
    limit: Annotated[int, Query(ge=1, le=200)] = 50,
    page: str | None = None,
) -> dict[str, Any]:
    _require(principal, Role.VIEWER)
    from ma_api.shared.pagination import decode

    got = await graph.deployments.list_deployments(
        principal.workspace_id, limit=limit, after=decode(page)
    )
    items = [revalidate(DeploymentOut, _out(d)) for d in got.items]
    return revalidate(PageOut, page_body(got, items))


@router.get("/{deployment_id}", response_model=DeploymentOut)
async def get_deployment(
    deployment_id: str, graph: CurrentGraph, principal: CurrentPrincipal
) -> dict[str, Any]:
    _require(principal, Role.VIEWER)
    got = await graph.deployments.find(principal.workspace_id, deployment_id)
    if got is None:
        raise not_found("Deployment", deployment_id)
    return revalidate(DeploymentOut, _out(got, next_fire_times=graph.deployments.upcoming(got)))


@router.get("/{deployment_id}/runs", response_model=PageOut)
async def list_runs(
    deployment_id: str,
    graph: CurrentGraph,
    principal: CurrentPrincipal,
    limit: Annotated[int, Query(ge=1, le=200)] = 50,
    page: str | None = None,
) -> dict[str, Any]:
    """실행 이력. **건너뛴 것도 보인다** — "왜 어제는 안 왔지"의 답이다."""
    _require(principal, Role.VIEWER)
    from ma_api.shared.pagination import decode

    got = await graph.deployments.list_runs(
        principal.workspace_id, deployment_id, limit=limit, after=decode(page)
    )
    items = [revalidate(DeploymentRunOut, _run_out(r)) for r in got.items]
    return revalidate(PageOut, page_body(got, items))


@router.post("/{deployment_id}/pause", response_model=DeploymentOut)
async def pause_deployment(
    deployment_id: str,
    body: DeploymentPauseIn,
    graph: CurrentGraph,
    principal: CurrentPrincipal,
) -> dict[str, Any]:
    _require(principal, Role.OPERATOR)
    return _changed(
        await graph.deployments.pause(principal.workspace_id, deployment_id, reason=body.reason),
        deployment_id,
    )


@router.post("/{deployment_id}/unpause", response_model=DeploymentOut)
async def unpause_deployment(
    deployment_id: str, graph: CurrentGraph, principal: CurrentPrincipal
) -> dict[str, Any]:
    """**밀린 발화를 몰아서 돌리지 않는다.** 다음 발화를 지금 기준으로
    다시 계산한다 — 일주일 멈췄던 일일 리포트가 7통 가면 안 된다."""
    _require(principal, Role.OPERATOR)
    return _changed(
        await graph.deployments.unpause(principal.workspace_id, deployment_id), deployment_id
    )


@router.post("/{deployment_id}/archive", response_model=DeploymentOut)
async def archive_deployment(
    deployment_id: str, graph: CurrentGraph, principal: CurrentPrincipal
) -> dict[str, Any]:
    _require(principal, Role.ADMIN)
    return _changed(
        await graph.deployments.archive(principal.workspace_id, deployment_id), deployment_id
    )


@router.post(
    "/{deployment_id}/run", response_model=DeploymentRunOut, status_code=status.HTTP_201_CREATED
)
async def run_deployment(
    deployment_id: str,
    body: DeploymentRunIn,
    graph: CurrentGraph,
    principal: CurrentPrincipal,
) -> dict[str, Any]:
    """지금 돌린다. **off-peak 로 밀지 않는다** — 사람이 지금 눌렀다.

    `trigger=manual` 이므로 멱등 유니크 인덱스에도 걸리지 않는다
    (그 인덱스는 `trigger='schedule'` 부분 인덱스다). 같은 분에 두 번
    누르면 두 번 돈다 — 그것이 의도다.
    """
    _require(principal, Role.OPERATOR)
    got = await graph.deployments.find(principal.workspace_id, deployment_id)
    if got is None:
        raise not_found("Deployment", deployment_id)

    res = await graph.deployments.fire(got, trigger=RunTrigger.MANUAL)
    match res:
        case Fired(run=run):
            return revalidate(DeploymentRunOut, _run_out(run))
        case Skipped(reason=why):
            raise conflict(f"실행하지 않았다: {why}")
        case AlreadyRan(scheduled_for=at):
            raise conflict(f"{at.isoformat()} 발화는 이미 집혔다")
        case Deferred(fire_at=at):  # pragma: no cover — 수동은 밀지 않는다
            raise conflict(f"{at.isoformat()} 로 미뤄졌다")
        case DeploymentMissing():
            raise not_found("Deployment", deployment_id)
    raise invalid("처리하지 않은 결과")  # pragma: no cover


@router.delete("/{deployment_id}", response_model=None, status_code=status.HTTP_204_NO_CONTENT)
async def delete_deployment(
    deployment_id: str, graph: CurrentGraph, principal: CurrentPrincipal
) -> Response:
    """**아카이브다.** 실행 이력이 FK 로 묶여 있고, 그 이력이 감사 자료다."""
    _require(principal, Role.ADMIN)
    res = await graph.deployments.archive(principal.workspace_id, deployment_id)
    if isinstance(res, DeploymentMissing):
        raise not_found("Deployment", deployment_id)
    return Response(status_code=status.HTTP_204_NO_CONTENT)


def _changed(res: Any, deployment_id: str) -> dict[str, Any]:
    if isinstance(res, DeploymentUpdated):
        return revalidate(DeploymentOut, _out(res.deployment))
    raise not_found("Deployment", deployment_id)


__all__ = ["router"]
