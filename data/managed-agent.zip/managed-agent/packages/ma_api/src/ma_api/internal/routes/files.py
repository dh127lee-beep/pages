"""파일 업로드 · 산출물. `plan/04-api.md` §3.4 · §3.8.

> **다운로드는 302 리다이렉트입니다.** 제어 평면이 바이트를 중계하지
> 않습니다 — 대용량에서 막히고, 워커 한 대의 대역폭이 전체 처리량의
> 상한이 됩니다.

서명 URL 을 못 만드는 백엔드(개발용)에서는 **501 로 거절한다.** 바이트
중계로 대체하지 않는다 — 대체하면 그 경로가 프로덕션에도 남는다.

**비ASCII 파일명이 깨지지 않는다.** 원본은 `files.filename` 에 그대로
있고, 헤더에는 RFC 5987 의 `filename*=UTF-8''...` 로 싣는다.
"""

from __future__ import annotations

from typing import Annotated, Any
from urllib.parse import quote

from fastapi import APIRouter, File, Query, Request, Response, UploadFile, status
from fastapi.responses import RedirectResponse
from ma_application.files import (
    DownloadRedirect,
    DownloadUnavailable,
    FileInvalid,
    FileMissing,
    FileTooLarge,
    FileUploaded,
    QuotaExceeded,
    UploadFailed,
)
from ma_application.files import (
    UploadFile as UploadFileCmd,
)
from ma_domain.files import MAX_FILE_BYTES
from ma_domain.ids import FileId, SessionId
from ma_domain.workspaces import Role

from ma_api.internal.deps import CurrentGraph, CurrentPrincipal
from ma_api.internal.mappers.files import file_out, output_out
from ma_api.internal.schemas import FileOut, OutputOut, PageOut
from ma_api.shared.errors import ApiError, ErrorType, forbidden, invalid, not_found
from ma_api.shared.pagination import page_body
from ma_api.shared.revalidate import revalidate

router = APIRouter(prefix="/api/v1", tags=["files"])

#: 기본 content-type. **실행 가능한 타입을 추측해 주지 않는다** —
#: `text/html` 이면 저장된 파일이 같은 오리진에서 돈다.
FALLBACK_TYPE = "application/octet-stream"


def _require(principal: Any, role: Role) -> None:
    if not principal.role.at_least(role):
        raise forbidden(f"{role.value} 이상이 필요하다")


def _too_large(size: int, limit: int) -> ApiError:
    """**409 지 400 이 아니다.**

    재시도해도 안 되고, 파일을 줄이거나 워크스페이스 상한을 올려야
    한다 — `ma_governance.quota` 가 쿼터 초과를 409 로 두는 것과 같은
    판단이다.
    """
    return ApiError(
        ErrorType.CONFLICT,
        f"파일이 {limit:,}바이트를 넘는다 ({size:,})",
        extra=(("code", "file_too_large"), ("limit", limit), ("size", size)),
    )


def _unavailable(reason: str) -> ApiError:
    """서명 URL 을 못 만든다. **500 이 아니라 501 급 사실이다.**

    `ErrorType.API` 로 올리되 코드를 실어 클라이언트가 "서버 고장"과
    "이 배포에는 그 기능이 없다"를 구분할 수 있게 한다.
    """
    return ApiError(
        ErrorType.API,
        f"이 배포는 다운로드 URL 을 만들지 못한다: {reason}",
        extra=(("code", "download_unsupported"),),
    )


def _redirect(url: str, filename: str) -> RedirectResponse:
    """302 + RFC 5987 파일명.

    **ASCII 대체본과 UTF-8 본을 둘 다 싣는다.** 옛 클라이언트는 앞을
    읽고 현대 브라우저는 뒤를 읽는다. 앞만 실으면 한글 이름이
    `____.pdf` 가 되고, 뒤만 실으면 옛 클라이언트가 헤더를 버린다.
    """
    ascii_fallback = filename.encode("ascii", "replace").decode("ascii").replace('"', "")
    response = RedirectResponse(url=url, status_code=status.HTTP_302_FOUND)
    response.headers["Content-Disposition"] = (
        f"attachment; filename=\"{ascii_fallback}\"; filename*=UTF-8''{quote(filename, safe='')}"
    )
    return response


# ── 업로드 ───────────────────────────────────────────────
@router.post("/files", response_model=FileOut, status_code=status.HTTP_201_CREATED)
async def upload_file(
    graph: CurrentGraph,
    principal: CurrentPrincipal,
    request: Request,
    file: Annotated[UploadFile, File()],
) -> dict[str, Any]:
    """multipart 업로드.

    **전체를 메모리에 읽는다.** 상한이 100MB 라 괜찮고, 스트리밍
    업로드는 오브젝트 스토어의 multipart API 와 함께 와야 의미가
    있다 (M5). 지금 반쯤 스트리밍하면 상한 검사가 바이트를 다 읽은
    뒤에야 돌아 아무것도 막지 못한다.
    """
    _require(principal, Role.OPERATOR)

    # **읽기 전에 끊는다.** `Content-Length` 는 클라이언트가 보낸
    # 값이라 신뢰할 수 없지만, **정직한 큰 업로드**가 메모리를 먹는
    # 것은 이것으로 막힌다. 거짓말하는 쪽은 아래 `len(content)` 가
    # 잡는다 — 두 검사가 다른 위협을 본다.
    declared = request.headers.get("content-length")
    if declared and declared.isdigit() and int(declared) > MAX_FILE_BYTES:
        raise _too_large(int(declared), MAX_FILE_BYTES)

    content = await file.read()
    res = await graph.files.upload(
        UploadFileCmd(
            workspace_id=principal.workspace_id,
            filename=file.filename or "file",
            content=content,
            created_by=f"{principal.kind}:{principal.id}",
            content_type=file.content_type or FALLBACK_TYPE,
        )
    )
    match res:
        case FileUploaded(file=made):
            return revalidate(FileOut, file_out(made))
        case FileInvalid(reasons=reasons):
            # **이름 문제는 400.** 고치면 통과한다.
            raise invalid("; ".join(reasons))
        case FileTooLarge(size_bytes=size, limit=limit):
            raise _too_large(size, limit)
        case QuotaExceeded(kind=kind, used=used, limit=limit):
            raise ApiError(
                ErrorType.CONFLICT,
                f"일일 업로드 상한에 도달했다 ({used}/{limit})",
                extra=(("code", kind), ("limit", limit), ("used", used)),
            )
        case UploadFailed(file_id=fid, reason=reason):
            raise ApiError(
                ErrorType.API,
                f"업로드가 끝나지 못했다: {reason}",
                extra=(("code", "upload_failed"), ("file_id", fid)),
            )
    raise invalid("처리하지 않은 결과")  # pragma: no cover


@router.get("/files", response_model=PageOut)
async def list_files(
    graph: CurrentGraph,
    principal: CurrentPrincipal,
    limit: Annotated[int, Query(ge=1, le=200)] = 50,
) -> dict[str, Any]:
    got = await graph.files.list_files(principal.workspace_id, limit=limit)
    items = [revalidate(FileOut, file_out(f)) for f in got.items]
    return revalidate(PageOut, page_body(got, items))


@router.get("/files/{file_id}", response_model=FileOut)
async def get_file(
    file_id: str, graph: CurrentGraph, principal: CurrentPrincipal
) -> dict[str, Any]:
    got = await graph.files.find(principal.workspace_id, FileId(file_id))
    if got is None:
        raise not_found("파일", file_id)
    return revalidate(FileOut, file_out(got))


@router.get("/files/{file_id}/content", response_model=None)
async def download_file(
    file_id: str, graph: CurrentGraph, principal: CurrentPrincipal
) -> RedirectResponse:
    """**302 리다이렉트.** 바이트가 제어 평면을 지나지 않는다."""
    meta = await graph.files.find(principal.workspace_id, FileId(file_id))
    res = await graph.files.download_url(principal.workspace_id, FileId(file_id))
    match res:
        case DownloadRedirect(url=url):
            return _redirect(url, meta.filename if meta else file_id)
        case DownloadUnavailable(reason=reason):
            raise _unavailable(reason)
        case FileMissing():
            raise not_found("파일", file_id)
    raise invalid("처리하지 않은 결과")  # pragma: no cover


@router.delete("/files/{file_id}", response_model=None, status_code=status.HTTP_204_NO_CONTENT)
async def delete_file(file_id: str, graph: CurrentGraph, principal: CurrentPrincipal) -> Response:
    _require(principal, Role.OPERATOR)
    if not await graph.files.delete(principal.workspace_id, FileId(file_id)):
        raise not_found("파일", file_id)
    return Response(status_code=status.HTTP_204_NO_CONTENT)


# ── 산출물 ───────────────────────────────────────────────
@router.get("/sessions/{session_id}/outputs", response_model=PageOut)
async def list_outputs(
    session_id: str,
    graph: CurrentGraph,
    principal: CurrentPrincipal,
    limit: Annotated[int, Query(ge=1, le=200)] = 50,
) -> dict[str, Any]:
    got = await graph.files.list_outputs(principal.workspace_id, SessionId(session_id), limit=limit)
    items = [revalidate(OutputOut, output_out(o)) for o in got.items]
    return revalidate(PageOut, page_body(got, items))


@router.get("/sessions/{session_id}/outputs/{output_id}/content", response_model=None)
async def download_output(
    session_id: str, output_id: str, graph: CurrentGraph, principal: CurrentPrincipal
) -> RedirectResponse:
    meta = await graph.files.outputs.find(principal.workspace_id, output_id)
    # **세션이 맞는지 본다.** id 만으로 찾으면 다른 세션의 산출물을
    # 이 세션의 URL 로 받을 수 있다 — 워크스페이스는 같아도 세션
    # 단위 권한을 나중에 넣을 때 그 구멍이 남는다.
    if meta is None or meta.session_id != session_id:
        raise not_found("산출물", output_id)

    res = await graph.files.output_url(principal.workspace_id, output_id)
    match res:
        case DownloadRedirect(url=url):
            return _redirect(url, meta.path.rsplit("/", 1)[-1])
        case DownloadUnavailable(reason=reason):
            raise _unavailable(reason)
        case FileMissing():
            raise not_found("산출물", output_id)
    raise invalid("처리하지 않은 결과")  # pragma: no cover


__all__ = ["router"]
