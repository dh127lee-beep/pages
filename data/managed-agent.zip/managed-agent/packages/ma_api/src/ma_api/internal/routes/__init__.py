"""내부 lane 라우터.

`plan/04-api.md` §3 · `plan/09-codebase.md` §5.

**권한 판단은 여기서 하지 않는다.** L4 유스케이스가 한다 — 라우터에서 하면
CLI·웹훅·스케줄러가 같은 규칙을 우회한다. 라우터가 하는 일은 wire ↔ 애플리케이션
번역과 결과 → HTTP 상태 매핑뿐이다.

**나가는 것도 재검증한다** (`revalidate`). `response_model` 은 OpenAPI 와
FastAPI 검증을 위한 것이고, `revalidate` 는 실패를 우리 envelope 으로 통제하고
**샌 필드 이름을 본문에 싣지 않기** 위한 것이다.
"""

from __future__ import annotations

from ma_api.internal.routes.agents import router as agents_router
from ma_api.internal.routes.approvals import router as approvals_router
from ma_api.internal.routes.audit import router as audit_router
from ma_api.internal.routes.budgets import router as budgets_router
from ma_api.internal.routes.deployments import router as deployments_router
from ma_api.internal.routes.environment_work import router as work_router
from ma_api.internal.routes.events import router as events_router
from ma_api.internal.routes.files import router as files_router
from ma_api.internal.routes.health import router as health_router
from ma_api.internal.routes.mcp import router as mcp_router
from ma_api.internal.routes.memory import router as memory_router
from ma_api.internal.routes.models import router as models_router
from ma_api.internal.routes.sessions import router as sessions_router
from ma_api.internal.routes.skills import router as skills_router
from ma_api.internal.routes.vaults import router as vaults_router
from ma_api.internal.routes.webhooks import router as webhooks_router

#: 마운트 순서. health 가 가장 먼저 — 인증 없이 응답해야 한다.
ROUTERS = (
    health_router,
    agents_router,
    models_router,
    sessions_router,
    events_router,
    vaults_router,
    approvals_router,
    audit_router,
    budgets_router,
    memory_router,
    files_router,
    skills_router,
    webhooks_router,
    deployments_router,
    mcp_router,
    work_router,
)

__all__ = ["ROUTERS"]
