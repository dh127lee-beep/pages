"""볼트와 자격증명. `plan/04-api.md` §3.5.

> **자격증명 평문은 어떤 GET 으로도 돌아오지 않습니다.** 응답 스키마에 필드
> 자체가 없습니다 (`extra="forbid"` + egress 재검증이 이를 기계적으로 보장).

이 파일에 `secret` 이라는 글자가 나오는 곳은 **입력 본문을 유스케이스에
넘기는 한 줄뿐**이고, 그것도 매퍼 안에 있다. 라우터는 평문을 변수에 담지
않는다 — 담으면 예외 추적(traceback)의 지역 변수로 로그에 실린다.
"""

from __future__ import annotations

from typing import Annotated, Any

from fastapi import APIRouter, Query, status
from ma_application.mcp import (
    CredentialGone,
    CredentialNotOauth,
    RefreshRejected,
    RefreshSucceeded,
    StillValid,
    ValidateOauth,
)
from ma_application.vaults import (
    CreateVault,
    CredentialArchivedResult,
    CredentialCreated,
    CredentialInvalid,
    CredentialMissing,
    CredentialRotated,
    VaultArchived,
    VaultCreated,
    VaultMissing,
    VaultNameTaken,
)
from ma_domain.ids import CredentialId, SessionId, UserId, VaultId
from ma_domain.workspaces import Role

from ma_api.internal.deps import CurrentGraph, CurrentPrincipal
from ma_api.internal.mappers.vaults import (
    create_credential_from,
    credential_out,
    rotate_from,
    vault_out,
)
from ma_api.internal.schemas import (
    CredentialIn,
    CredentialOut,
    CredentialRotateIn,
    McpOauthValidateIn,
    McpOauthValidateOut,
    PageOut,
    VaultIn,
    VaultOut,
)
from ma_api.shared.errors import forbidden, invalid, name_taken, not_found
from ma_api.shared.pagination import page_body
from ma_api.shared.revalidate import revalidate

router = APIRouter(prefix="/api/v1/vaults", tags=["vaults"])


def _require(principal: Any, role: Role) -> None:
    if not principal.role.at_least(role):
        raise forbidden(f"{role.value} 이상이 필요하다")


# ── 볼트 ─────────────────────────────────────────────────
@router.post("", response_model=VaultOut, status_code=status.HTTP_201_CREATED)
async def create_vault(
    body: VaultIn, graph: CurrentGraph, principal: CurrentPrincipal
) -> dict[str, Any]:
    _require(principal, Role.ADMIN)
    res = await graph.vaults.create_vault(
        CreateVault(workspace_id=principal.workspace_id, name=body.name)
    )
    match res:
        case VaultCreated(vault=v):
            return revalidate(VaultOut, vault_out(v))
        case VaultNameTaken(name=name):
            raise name_taken("볼트", name)
    raise invalid("처리하지 않은 결과")  # pragma: no cover


@router.get("", response_model=PageOut)
async def list_vaults(
    graph: CurrentGraph,
    principal: CurrentPrincipal,
    limit: Annotated[int, Query(ge=1, le=200)] = 50,
) -> dict[str, Any]:
    got = await graph.vaults.list_vaults(principal.workspace_id, limit=limit)
    items = [revalidate(VaultOut, vault_out(v)) for v in got.items]
    return revalidate(PageOut, page_body(got, items))


@router.get("/{vault_id}", response_model=VaultOut)
async def get_vault(
    vault_id: str, graph: CurrentGraph, principal: CurrentPrincipal
) -> dict[str, Any]:
    got = await graph.vaults.find_vault(principal.workspace_id, VaultId(vault_id))
    if got is None:
        raise not_found("Vault", vault_id)
    return revalidate(VaultOut, vault_out(got))


@router.post("/{vault_id}/archive", response_model=VaultOut)
async def archive_vault(
    vault_id: str, graph: CurrentGraph, principal: CurrentPrincipal
) -> dict[str, Any]:
    """**하드 삭제가 없다.** 과거 세션이 이 볼트를 참조한다."""
    _require(principal, Role.ADMIN)
    res = await graph.vaults.archive_vault(principal.workspace_id, VaultId(vault_id))
    match res:
        case VaultArchived(vault=v):
            return revalidate(VaultOut, vault_out(v))
        case VaultMissing():
            raise not_found("Vault", vault_id)
    raise invalid("처리하지 않은 결과")  # pragma: no cover


# ── 자격증명 ─────────────────────────────────────────────
@router.post(
    "/{vault_id}/credentials",
    response_model=CredentialOut,
    status_code=status.HTTP_201_CREATED,
)
async def create_credential(
    vault_id: str,
    body: CredentialIn,
    graph: CurrentGraph,
    principal: CurrentPrincipal,
) -> dict[str, Any]:
    """**평문 입력, 응답에 없음** (`plan/04` §3.5).

    201 이 돌려주는 것은 메타데이터다. 방금 만든 비밀도 보여 주지 않는다.
    """
    _require(principal, Role.ADMIN)
    res = await graph.vaults.create_credential(
        create_credential_from(
            body,
            workspace_id=principal.workspace_id,
            vault_id=VaultId(vault_id),
            created_by=UserId(principal.id),
        )
    )
    match res:
        case CredentialCreated(credential=c):
            return revalidate(CredentialOut, credential_out(c))
        case VaultMissing():
            raise not_found("Vault", vault_id)
        case CredentialInvalid(reasons=reasons):
            raise invalid("; ".join(reasons))
    raise invalid("처리하지 않은 결과")  # pragma: no cover


@router.get("/{vault_id}/credentials", response_model=PageOut)
async def list_credentials(
    vault_id: str,
    graph: CurrentGraph,
    principal: CurrentPrincipal,
    limit: Annotated[int, Query(ge=1, le=200)] = 50,
) -> dict[str, Any]:
    """**메타데이터만.** 평문을 담을 필드가 `CredentialOut` 에 없다."""
    got = await graph.vaults.list_credentials(
        principal.workspace_id, VaultId(vault_id), limit=limit
    )
    items = [revalidate(CredentialOut, credential_out(c)) for c in got.items]
    return revalidate(PageOut, page_body(got, items))


@router.post("/{vault_id}/credentials/{credential_id}", response_model=CredentialOut)
async def rotate_credential(
    vault_id: str,
    credential_id: str,
    body: CredentialRotateIn,
    graph: CurrentGraph,
    principal: CurrentPrincipal,
) -> dict[str, Any]:
    _require(principal, Role.ADMIN)
    res = await graph.vaults.rotate_credential(
        rotate_from(
            body,
            workspace_id=principal.workspace_id,
            credential_id=CredentialId(credential_id),
        )
    )
    match res:
        case CredentialRotated(credential=c):
            return revalidate(CredentialOut, credential_out(c))
        case CredentialMissing():
            raise not_found("Credential", credential_id)
        case CredentialInvalid(reasons=reasons):
            raise invalid("; ".join(reasons))
    raise invalid("처리하지 않은 결과")  # pragma: no cover


@router.post("/{vault_id}/credentials/{credential_id}/archive", response_model=CredentialOut)
async def archive_credential(
    vault_id: str,
    credential_id: str,
    graph: CurrentGraph,
    principal: CurrentPrincipal,
) -> dict[str, Any]:
    """**하드 삭제가 없다.** `credential_events` 가 이 id 를 참조한다."""
    _require(principal, Role.ADMIN)
    res = await graph.vaults.archive_credential(principal.workspace_id, CredentialId(credential_id))
    match res:
        case CredentialArchivedResult(credential=c):
            return revalidate(CredentialOut, credential_out(c))
        case CredentialMissing():
            raise not_found("Credential", credential_id)
    raise invalid("처리하지 않은 결과")  # pragma: no cover


@router.post(
    "/{vault_id}/credentials/{credential_id}/mcp-oauth/validate",
    response_model=McpOauthValidateOut,
)
async def validate_mcp_oauth(
    vault_id: str,
    credential_id: str,
    body: McpOauthValidateIn,
    graph: CurrentGraph,
    principal: CurrentPrincipal,
) -> dict[str, Any]:
    """MCP OAuth 자격증명이 아직 쓸 수 있는지 보고, 아니면 갱신한다 (T-0601).

    **워커가 401 을 받으면 이것을 부른다.** 갱신 자체를 워커가 하지
    않는 이유는 D5 다 — 갱신 토큰은 access token 보다 센 권한이고
    (그것으로 토큰을 **새로 만들 수 있다**), 루트 시크릿은 제어
    평면에만 있다 (`ADR-0009`).

    **응답에 토큰이 없다.** 워커가 알아야 하는 것은 "다시 시도해도
    되는가"뿐이고, 토큰은 프록시가 주입한다.
    """
    _require(principal, Role.OPERATOR)
    res = await graph.mcp.validate_oauth(
        ValidateOauth(
            workspace_id=principal.workspace_id,
            vault_id=VaultId(vault_id),
            credential_id=CredentialId(credential_id),
            force=body.force,
            session_id=SessionId(body.session_id) if body.session_id else None,
        )
    )
    match res:
        case StillValid(credential=c):
            out = {"outcome": "still_valid", "retryable": True, "expires_at": c.expires_at}
        case RefreshSucceeded(credential=c):
            out = {"outcome": "refreshed", "retryable": True, "expires_at": c.expires_at}
        case RefreshRejected(reason=reason, permanent=permanent):
            # **영구 실패면 재시도하지 말라고 말한다.** 안 말하면
            # 워커가 매 턴 토큰 엔드포인트를 두드리고 레이트 리밋에 걸린다.
            out = {
                "outcome": "rejected",
                "retryable": not permanent,
                "expires_at": None,
                "reason": reason,
            }
        case CredentialNotOauth():
            out = {
                "outcome": "not_oauth",
                "retryable": False,
                "expires_at": None,
                "reason": "mcp_oauth 자격증명이 아니다",
            }
        case CredentialGone():
            raise not_found("Credential", credential_id)
        case _:  # pragma: no cover
            raise invalid("처리하지 않은 결과")
    return revalidate(McpOauthValidateOut, {"credential_id": credential_id, **out})
