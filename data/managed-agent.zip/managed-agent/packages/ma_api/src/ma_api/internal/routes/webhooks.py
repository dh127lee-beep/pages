"""웹훅. `plan/04-api.md` §3.8.

> **시크릿은 생성 응답에만 한 번 실린다.** 다시 물어볼 길이 없고,
> 잃으면 새로 만든다 — `credentials` 와 같은 규칙이다 (D5).

DLQ 조회와 재시도가 여기 있다. 포기한 전송을 지우지 않는 이유:
"웹훅이 안 왔다"는 문의에 답할 자료가 그것뿐이다.
"""

from __future__ import annotations

from typing import Annotated, Any

from fastapi import APIRouter, Query, Response, status
from ma_application.webhooks import (
    CreateEndpoint,
    EndpointCreated,
    EndpointInvalid,
)
from ma_domain.webhooks import SIGNATURE_HEADER, WebhookEvent
from ma_domain.workspaces import Role

from ma_api.internal.deps import CurrentGraph, CurrentPrincipal
from ma_api.internal.schemas import (
    DeliveryOut,
    PageOut,
    WebhookCreatedOut,
    WebhookIn,
    WebhookOut,
)
from ma_api.shared.errors import forbidden, invalid, not_found
from ma_api.shared.pagination import page_body
from ma_api.shared.revalidate import revalidate

router = APIRouter(prefix="/api/v1/webhooks", tags=["webhooks"])

#: 수신 측 구현자에게 알려 주는 서명 방식.
SIGNATURE_SCHEME = "HMAC-SHA256 over '<t>.<body>'; header 'awp-signature: t=..,v1=..'"


def _require(principal: Any, role: Role) -> None:
    if not principal.role.at_least(role):
        raise forbidden(f"{role.value} 이상이 필요하다")


def _endpoint_out(e: Any) -> dict[str, Any]:
    # **`secret` 을 담을 자리가 없다.** 담으려 해도 `extra="forbid"` 가
    # 500 을 낸다 (`credentials` 와 같은 방어).
    return {
        "id": e.id,
        "url": e.url,
        "events": tuple(ev.value for ev in e.events),
        "description": e.description,
        "active": e.is_active,
        "created_at": e.created_at,
        "disabled_at": e.disabled_at,
    }


def _delivery_out(d: Any) -> dict[str, Any]:
    return {
        "id": d.id,
        "endpoint_id": d.endpoint_id,
        "event": d.event.value,
        "state": d.state.value,
        "attempts": d.attempts,
        "created_at": d.created_at,
        "next_attempt_at": d.next_attempt_at,
        "delivered_at": d.delivered_at,
        "last_error": d.last_error,
        "last_status": d.last_status,
    }


@router.post("", response_model=WebhookCreatedOut, status_code=status.HTTP_201_CREATED)
async def create_webhook(
    body: WebhookIn, graph: CurrentGraph, principal: CurrentPrincipal
) -> dict[str, Any]:
    """**시크릿을 서버가 만든다.**

    클라이언트가 고르게 하면 약한 것이 들어오고, 그 약함은 서명
    위조로 바로 이어진다.
    """
    _require(principal, Role.ADMIN)
    try:
        events = tuple(WebhookEvent(e) for e in body.events)
    except ValueError as exc:
        # **모르는 이벤트는 400 이다.** 조용히 무시하면 사용자는
        # 구독했다고 믿는데 아무것도 안 온다.
        raise invalid(f"모르는 웹훅 이벤트: {exc}") from None

    res = await graph.webhooks.create_endpoint(
        CreateEndpoint(
            workspace_id=principal.workspace_id,
            url=body.url,
            events=events,
            description=body.description,
            created_by=f"{principal.kind}:{principal.id}",
        )
    )
    match res:
        case EndpointCreated(endpoint=made, secret=secret):
            return revalidate(
                WebhookCreatedOut,
                {
                    "endpoint": revalidate(WebhookOut, _endpoint_out(made)),
                    "secret": secret,
                    "signature_header": SIGNATURE_HEADER,
                    "signature_scheme": SIGNATURE_SCHEME,
                },
            )
        case EndpointInvalid(reasons=reasons):
            raise invalid("; ".join(reasons))
    raise invalid("처리하지 않은 결과")  # pragma: no cover


@router.get("", response_model=PageOut)
async def list_webhooks(
    graph: CurrentGraph,
    principal: CurrentPrincipal,
    limit: Annotated[int, Query(ge=1, le=200)] = 50,
) -> dict[str, Any]:
    _require(principal, Role.ADMIN)
    got = await graph.webhooks.list_endpoints(principal.workspace_id, limit=limit)
    items = [revalidate(WebhookOut, _endpoint_out(e)) for e in got.items]
    return revalidate(PageOut, page_body(got, items))


@router.delete("/{endpoint_id}", response_model=None, status_code=status.HTTP_204_NO_CONTENT)
async def disable_webhook(
    endpoint_id: str, graph: CurrentGraph, principal: CurrentPrincipal
) -> Response:
    """**끄는 것이지 지우는 것이 아니다.** 전송 이력이 FK 로 묶여 있다."""
    _require(principal, Role.ADMIN)
    if not await graph.webhooks.disable_endpoint(principal.workspace_id, endpoint_id):
        raise not_found("웹훅", endpoint_id)
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.get("/deliveries/dead", response_model=PageOut)
async def list_dead_deliveries(
    graph: CurrentGraph,
    principal: CurrentPrincipal,
    limit: Annotated[int, Query(ge=1, le=200)] = 50,
) -> dict[str, Any]:
    """DLQ. **지우지 않고 남긴다** — 사람이 보고 다시 쏜다."""
    _require(principal, Role.ADMIN)
    got = await graph.webhooks.list_dead(principal.workspace_id, limit=limit)
    items = [revalidate(DeliveryOut, _delivery_out(d)) for d in got.items]
    return revalidate(PageOut, page_body(got, items))


@router.post(
    "/deliveries/{delivery_id}/retry",
    response_model=None,
    status_code=status.HTTP_204_NO_CONTENT,
)
async def retry_delivery(
    delivery_id: str, graph: CurrentGraph, principal: CurrentPrincipal
) -> Response:
    """DLQ 의 것을 다시 큐에 올린다.

    **같은 `delivery_id` 로 되살린다** — 새로 만들면 수신 측의 멱등
    키가 달라져 두 번 처리된다.
    """
    _require(principal, Role.ADMIN)
    if not await graph.webhooks.retry_dead(principal.workspace_id, delivery_id):
        raise not_found("DLQ 전송", delivery_id)
    return Response(status_code=status.HTTP_204_NO_CONTENT)


__all__ = ["SIGNATURE_SCHEME", "router"]
