"""요청 컨텍스트 — 라우터가 유스케이스에 닿는 유일한 길.

`plan/09-codebase.md` §4.

미들웨어가 `request.state` 에 채우고, 라우터는 이 의존성으로 꺼낸다.
**`ma_api` 는 Store 구현을 모른다** — `UseCases` 묶음만 안다.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Annotated

from fastapi import Depends, Request

from ma_api.shared.errors import unauthenticated

if TYPE_CHECKING:
    from ma_application.agents import AgentsUseCases
    from ma_application.approvals import ApprovalsUseCases
    from ma_application.audit import AuditUseCases
    from ma_application.budgets import BudgetsUseCases
    from ma_application.deployments import DeploymentsUseCases
    from ma_application.environment_work import EnvironmentWorkUseCases
    from ma_application.files import FilesUseCases
    from ma_application.mcp import McpUseCases
    from ma_application.memory import MemoryUseCases
    from ma_application.realtime import RealtimePort
    from ma_application.session_events import SessionEventsUseCases
    from ma_application.skills import SkillsUseCases
    from ma_application.vaults import VaultsUseCases
    from ma_application.webhooks import WebhooksUseCases
    from ma_auth.principal import Principal
    from ma_domain.clock import Clock, IdGenerator
    from ma_store.events import SessionEventStore
    from ma_store.models import ModelCardStore
    from ma_store.sessions import SessionStore


@dataclass(frozen=True, slots=True)
class AppGraph:
    """워크스페이스 하나가 쓰는 조립 결과.

    `WorkspaceAppRegistry` 가 워크스페이스별로 들고 있고, 미들웨어가 꽂는다.
    """

    agents: AgentsUseCases
    approvals: ApprovalsUseCases
    audit: AuditUseCases
    budgets: BudgetsUseCases
    deployments: DeploymentsUseCases
    environment_work: EnvironmentWorkUseCases
    files: FilesUseCases
    mcp: McpUseCases
    memory: MemoryUseCases
    session_events: SessionEventsUseCases
    skills: SkillsUseCases
    vaults: VaultsUseCases
    webhooks: WebhooksUseCases
    sessions: SessionStore
    events: SessionEventStore
    models: ModelCardStore
    realtime: RealtimePort
    clock: Clock
    ids: IdGenerator


def get_principal(request: Request) -> Principal:
    principal = getattr(request.state, "principal", None)
    if principal is None:
        raise unauthenticated()
    return principal  # type: ignore[no-any-return]


def get_graph(request: Request) -> AppGraph:
    graph = getattr(request.state, "graph", None)
    if graph is None:  # pragma: no cover — 미들웨어가 항상 채운다
        raise unauthenticated()
    return graph  # type: ignore[no-any-return]


CurrentPrincipal = Annotated["Principal", Depends(get_principal)]
CurrentGraph = Annotated[AppGraph, Depends(get_graph)]

__all__ = ["AppGraph", "CurrentGraph", "CurrentPrincipal", "get_graph", "get_principal"]
