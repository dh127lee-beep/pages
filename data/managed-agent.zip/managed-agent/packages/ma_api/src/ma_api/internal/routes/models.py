"""모델 카드 조회. `plan/06-harness-and-model.md` §1.

**`credential_id`·`base_url` 이 나가지 않는다.** `ModelCardOut` 에 그 필드가
없으므로 구조적으로 막힌다 — 유스케이스가 실수로 담아도 `revalidate` 가 500 을
낸다. 그것이 이 설계의 요점이다 (`plan/03-layers.md` §3 L5a).
"""

from __future__ import annotations

from typing import Annotated, Any

from fastapi import APIRouter, Query
from ma_domain.ids import ModelCardId
from ma_store._results import ListQuery

from ma_api.internal.deps import CurrentGraph, CurrentPrincipal
from ma_api.internal.schemas import ModelCardOut, PageOut
from ma_api.shared.errors import not_found
from ma_api.shared.pagination import page_body
from ma_api.shared.revalidate import revalidate

router = APIRouter(prefix="/api/v1/models", tags=["models"])


def _card_out(card: Any) -> dict[str, Any]:
    return {
        "id": card.id,
        "provider": card.provider.value,
        "wire_model": card.wire_model,
        "max_input_tokens": card.max_input_tokens,
        "max_output_tokens": card.max_output_tokens,
        "supports_tools": card.supports_tools,
        "supports_vision": card.supports_vision,
        "supports_prompt_cache": card.supports_prompt_cache,
        "enabled": card.enabled,
    }


@router.get("", response_model=PageOut)
async def list_models(
    graph: CurrentGraph,
    principal: CurrentPrincipal,
    limit: Annotated[int, Query(ge=1, le=200)] = 50,
) -> dict[str, Any]:
    got = await graph.models.list_enabled(
        ListQuery(workspace_id=principal.workspace_id, limit=limit)
    )
    items = [revalidate(ModelCardOut, _card_out(c)) for c in got.items]
    return revalidate(PageOut, page_body(got, items))


@router.get("/{card_id}", response_model=ModelCardOut)
async def get_model(
    card_id: str, graph: CurrentGraph, principal: CurrentPrincipal
) -> dict[str, Any]:
    card = await graph.models.find(principal.workspace_id, ModelCardId(card_id))
    if card is None:
        raise not_found("Model card", card_id)
    return revalidate(ModelCardOut, _card_out(card))
