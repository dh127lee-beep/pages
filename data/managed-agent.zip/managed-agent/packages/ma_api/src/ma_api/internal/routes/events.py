"""이벤트 전송과 SSE 스트림. `plan/04-api.md` §4 §5.

SSE 계약 네 가지가 여기 있다.

**재연결**: `after_seq` 로 이어받는다. `Last-Event-ID` 헤더도 같은 의미다 —
브라우저 `EventSource` 가 자동으로 붙이는 헤더라 둘 다 받아야 한다.

**replay 먼저, 실시간 나중**: 연결하면 `after_seq` 이후 영속 이벤트를 **전부**
보낸 뒤 실시간으로 전환한다. 순서를 바꾸면 그 사이에 난 이벤트가 사라진다.

**at-least-once**: 클라이언트가 `event.id` 로 dedupe 한다. 중복을 보내는 것이
빠뜨리는 것보다 낫다 — 중복은 클라이언트가 지울 수 있지만 빠진 것은 모른다.

**백프레셔**: 느린 클라이언트는 **끊는다**. 버퍼를 무한히 키우면 느린 구독자
하나가 서버 메모리를 먹는다. 끊긴 클라이언트는 `after_seq` 로 재연결해 replay
받는다 — 잃는 것이 없다 (`IMPL-0011`).
"""

from __future__ import annotations

import json
from collections.abc import AsyncIterator
from typing import Annotated, Any

import anyio
from fastapi import APIRouter, Header, Query, Request, status
from fastapi.responses import StreamingResponse
from ma_application.session_events import (
    EventsAccepted,
    EventsRejected,
    IdempotencyConflict,
    InboundEvent,
    RevisionConflict,
    SendEvents,
    SessionNotFound,
)
from ma_domain.events import EventType
from ma_domain.ids import SessionId, ThreadId, WorkspaceId
from ma_domain.workspaces import Role
from ma_store.events import ReadEvents
from ma_store.sessions import FindSession

from ma_api.internal.deps import AppGraph, CurrentGraph, CurrentPrincipal
from ma_api.internal.mappers.sessions import event_out
from ma_api.internal.schemas import EventOut, SendEventsIn, SendEventsOut
from ma_api.shared.errors import (
    forbidden,
    idempotency_conflict,
    invalid,
    not_found,
    version_conflict,
)
from ma_api.shared.revalidate import revalidate

router = APIRouter(prefix="/api/v1/sessions", tags=["events"])

#: 하트비트 주기. 프록시 타임아웃(보통 30~60s)보다 짧아야 한다.
HEARTBEAT_SECONDS = 15.0

#: 한 번에 읽어 보낼 이벤트 수.
REPLAY_PAGE = 500

#: 느린 클라이언트를 끊는 기준. 이만큼 쓰지 못하고 쌓이면 연결을 닫는다.
SLOW_CLIENT_TIMEOUT = 30.0


@router.post(
    "/{session_id}/events",
    response_model=SendEventsOut,
    status_code=status.HTTP_202_ACCEPTED,
)
async def send_events(
    session_id: str,
    body: SendEventsIn,
    graph: CurrentGraph,
    principal: CurrentPrincipal,
    idempotency_key: Annotated[str | None, Header(alias="Idempotency-Key")] = None,
) -> dict[str, Any]:
    """**202 다.** 수용했을 뿐 아직 처리하지 않았다 — 워커가 claim 해서 돈다."""
    if not principal.role.at_least(Role.OPERATOR):
        raise forbidden("operator 이상이 필요하다")
    if not idempotency_key:
        raise invalid("Idempotency-Key 헤더가 필요하다")

    events = []
    for e in body.events:
        try:
            type_ = EventType(e.type)
        except ValueError as exc:
            raise invalid(f"모르는 이벤트 타입: {e.type}") from exc
        events.append(
            InboundEvent(
                type=type_,
                payload=tuple(e.content.items()),
                thread_id=ThreadId(e.thread_id),
            )
        )

    res = await graph.session_events.send(
        SendEvents(
            workspace_id=WorkspaceId(principal.workspace_id),
            session_id=SessionId(session_id),
            events=tuple(events),
            idempotency_key=idempotency_key,
            actor_role=principal.role,
            expected_revision=body.expected_revision,
        )
    )

    match res:
        case EventsAccepted():
            # 워커를 깨운다. **실패해도 수용은 유효하다** — 워커가 폴링으로도
            # 집는다 (D3). 알림은 지연을 줄이는 최적화이지 정확성이 아니다.
            from ma_application.realtime import Wake

            await graph.realtime.publish(
                Wake(workspace_id=principal.workspace_id, session_id=session_id)
            )
            return revalidate(
                SendEventsOut,
                {
                    "accepted": res.accepted,
                    "revision": res.revision,
                    "replayed": res.replayed,
                },
            )
        case SessionNotFound():
            raise not_found("Session", session_id)
        case RevisionConflict(actual_revision=v):
            raise version_conflict(v)
        case IdempotencyConflict(event_id=eid):
            raise idempotency_conflict(eid)
        case EventsRejected(reason=reason, detail=detail):
            if reason == "forbidden":
                raise forbidden(detail)
            raise invalid(detail or reason)
    raise invalid("처리하지 않은 결과")  # pragma: no cover


@router.get("/{session_id}/events", response_model=dict)
async def list_events(
    session_id: str,
    graph: CurrentGraph,
    principal: CurrentPrincipal,
    after_seq: Annotated[int | None, Query(ge=-1)] = None,
    limit: Annotated[int, Query(ge=1, le=1000)] = 100,
) -> dict[str, Any]:
    """`ORDER BY seq` — 모델이 본 순서 그대로."""
    if not principal.role.at_least(Role.VIEWER):
        raise forbidden("viewer 이상이 필요하다")
    await _require_session(graph, principal.workspace_id, session_id)

    events = await graph.events.read(
        ReadEvents(
            workspace_id=WorkspaceId(principal.workspace_id),
            session_id=SessionId(session_id),
            after_seq=after_seq,
            limit=limit,
        )
    )
    return {"data": [revalidate(EventOut, event_out(e)) for e in events]}


@router.get("/{session_id}/events/stream", response_model=None)
async def stream_events(
    session_id: str,
    request: Request,
    graph: CurrentGraph,
    principal: CurrentPrincipal,
    after_seq: Annotated[int | None, Query(ge=-1)] = None,
    last_event_id: Annotated[str | None, Header(alias="Last-Event-ID")] = None,
) -> StreamingResponse:
    """SSE. **replay 먼저, 실시간 나중.**

    `response_model=None` 인 이유: 스트리밍 응답은 본문이 프레임의 연속이라
    단일 스키마로 검증할 수 없다. 각 프레임의 `data` 는 `EventOut` 으로
    재검증하므로 **프레임 단위로는 검증된다**.
    """
    if not principal.role.at_least(Role.VIEWER):
        raise forbidden("viewer 이상이 필요하다")
    await _require_session(graph, principal.workspace_id, session_id)

    # `Last-Event-ID` 는 브라우저 `EventSource` 가 자동으로 붙인다.
    # 명시적 `after_seq` 가 있으면 그쪽이 이긴다 — 클라이언트의 의도가 더 구체적이다.
    cursor = after_seq
    if cursor is None and last_event_id:
        try:
            cursor = int(last_event_id)
        except ValueError:
            cursor = None

    return StreamingResponse(
        _frames(graph, principal.workspace_id, session_id, cursor, request),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            # nginx 가 버퍼링하면 하트비트가 묶여서 의미가 없어진다
            "X-Accel-Buffering": "no",
        },
    )


async def _require_session(graph: AppGraph, workspace_id: str, session_id: str) -> None:
    rec = await graph.sessions.find(
        FindSession(workspace_id=WorkspaceId(workspace_id), id=SessionId(session_id))
    )
    if rec is None:
        raise not_found("Session", session_id)


def _frame(event: dict[str, Any]) -> str:
    """`id:` 에 `seq` 를 싣는다 — 그것이 재연결 커서가 된다."""
    return (
        f"id: {event['seq']}\n"
        f"event: {event['type']}\n"
        f"data: {json.dumps(event, ensure_ascii=False, default=str)}\n\n"
    )


async def _frames(
    graph: AppGraph,
    workspace_id: str,
    session_id: str,
    after_seq: int | None,
    request: Request,
) -> AsyncIterator[str]:
    cursor = after_seq

    async def drain() -> AsyncIterator[str]:
        """커서 이후를 **전부** 비운다. 한 페이지로 끝내면 뒤가 잘린다."""
        nonlocal cursor
        while True:
            batch = await graph.events.read(
                ReadEvents(
                    workspace_id=WorkspaceId(workspace_id),
                    session_id=SessionId(session_id),
                    after_seq=cursor,
                    limit=REPLAY_PAGE,
                )
            )
            if not batch:
                return
            for e in batch:
                yield _frame(revalidate(EventOut, event_out(e)))
                if e.seq is not None:
                    cursor = e.seq
            if len(batch) < REPLAY_PAGE:
                return

    # ① replay — 실시간 구독 **전에** 연다면 그 사이 이벤트를 놓친다.
    #    그래서 구독을 **먼저** 열고 replay 한다. 겹치는 것은 at-least-once 라
    #    클라이언트가 `event.id` 로 지운다.
    async with graph.realtime.subscribe(workspace_id, session_id) as wakes:
        async for frame in drain():
            yield frame

        # ② 실시간
        while True:
            if await request.is_disconnected():
                return
            try:
                with anyio.fail_after(HEARTBEAT_SECONDS):
                    await wakes.receive()  # type: ignore[attr-defined]
            except TimeoutError:
                # 프록시 타임아웃 방지. 주석 프레임은 클라이언트가 무시한다.
                yield ": keepalive\n\n"
                continue
            except anyio.EndOfStream:  # pragma: no cover — 구독이 닫혔다
                return

            async for frame in drain():
                yield frame


__all__ = [
    "HEARTBEAT_SECONDS",
    "REPLAY_PAGE",
    "SLOW_CLIENT_TIMEOUT",
    "router",
]
