"""내부 lane (`/api/v1/*`) — 사내 개념을 포함한다.

`plan/09-codebase.md` §5 · D9.

**`ma_api.compat` 을 import 하지 않는다.** `.importlinter` 의 `api-lanes`
계약이 강제한다. 공유가 필요한 것은 `ma_api.shared` 에 두고, 거기에는
비즈니스 규칙을 넣지 않는다.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from fastapi import FastAPI


def mount_internal(app: FastAPI) -> None:
    """내부 lane 라우터를 전부 마운트한다."""
    from ma_api.internal.routes import ROUTERS

    for router in ROUTERS:
        app.include_router(router)


__all__ = ["mount_internal"]
