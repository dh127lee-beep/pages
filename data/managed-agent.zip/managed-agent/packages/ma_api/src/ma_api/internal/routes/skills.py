"""스킬. `plan/01-product-concept.md` §4 · `plan/05-database.md` §3 G2.

> **`slug` 가 마운트 경로다** (`/mnt/skills/<slug>`). 겹치면 409 —
> 두 스킬이 같은 곳에 마운트되는 것은 데이터 손실이다.

카탈로그 엔드포인트가 따로 있는 이유: 콘솔이 "이 에이전트의 프롬프트에
무엇이 들어가는가"를 보여 줄 수 있어야 하고, 그 문자열은 **서버가
만드는 것**이다 (클라이언트가 조립하면 실제와 달라진다).
"""

from __future__ import annotations

from typing import Annotated, Any

from fastapi import APIRouter, Query, status
from ma_application.skills import (
    CreateSkill,
    SkillArchived,
    SkillConflict,
    SkillCreated,
    SkillInvalid,
    SkillMissing,
    SkillSlugTaken,
    SkillUpdated,
    SourceUnavailable,
    UpdateSkill,
)
from ma_domain.ids import SkillId
from ma_domain.skills import SkillSource
from ma_domain.workspaces import Role

from ma_api.internal.deps import CurrentGraph, CurrentPrincipal
from ma_api.internal.mappers.skills import files_out, skill_out
from ma_api.internal.schemas import (
    PageOut,
    SkillCatalogOut,
    SkillFileOut,
    SkillIn,
    SkillOut,
)
from ma_api.shared.errors import ApiError, ErrorType, forbidden, invalid, name_taken, not_found
from ma_api.shared.pagination import page_body
from ma_api.shared.revalidate import revalidate

router = APIRouter(prefix="/api/v1/skills", tags=["skills"])


def _require(principal: Any, role: Role) -> None:
    if not principal.role.at_least(role):
        raise forbidden(f"{role.value} 이상이 필요하다")


def _source_of(body: SkillIn) -> SkillSource | None:
    if body.source is None:
        return None
    return SkillSource(
        repo=body.source.repo,
        path=body.source.path,
        commit=body.source.commit,
        ref=body.source.ref,
    )


def _unavailable(reason: str) -> ApiError:
    """GitHub 에서 못 읽었다. **부분 저장을 만들지 않았다.**"""
    return ApiError(
        ErrorType.API,
        f"스킬 소스를 읽지 못했다: {reason}",
        extra=(("code", "skill_source_unavailable"),),
    )


@router.post("", response_model=SkillOut, status_code=status.HTTP_201_CREATED)
async def create_skill(
    body: SkillIn, graph: CurrentGraph, principal: CurrentPrincipal
) -> dict[str, Any]:
    _require(principal, Role.ADMIN)
    res = await graph.skills.create(
        CreateSkill(
            workspace_id=principal.workspace_id,
            name=body.name,
            slug=body.slug,
            description=body.description,
            files=tuple((f.path, f.content) for f in body.files),
            source=_source_of(body),
        )
    )
    match res:
        case SkillCreated(skill=made):
            return revalidate(SkillOut, skill_out(made))
        case SkillSlugTaken(slug=slug):
            raise name_taken("스킬 slug", slug)
        case SkillInvalid(reasons=reasons):
            raise invalid("; ".join(reasons))
        case SourceUnavailable(reason=reason):
            raise _unavailable(reason)
    raise invalid("처리하지 않은 결과")  # pragma: no cover


@router.post("/{skill_id}", response_model=SkillOut)
async def update_skill(
    skill_id: str,
    body: SkillIn,
    graph: CurrentGraph,
    principal: CurrentPrincipal,
    expected_version: Annotated[int, Query(ge=1)],
) -> dict[str, Any]:
    _require(principal, Role.ADMIN)
    res = await graph.skills.update(
        UpdateSkill(
            workspace_id=principal.workspace_id,
            skill_id=SkillId(skill_id),
            name=body.name,
            slug=body.slug,
            description=body.description,
            files=tuple((f.path, f.content) for f in body.files),
            expected_version=expected_version,
            source=_source_of(body),
        )
    )
    match res:
        case SkillUpdated(skill=made):
            return revalidate(SkillOut, skill_out(made))
        case SkillMissing():
            raise not_found("스킬", skill_id)
        case SkillConflict(actual_version=actual):
            from ma_api.shared.errors import version_conflict

            raise version_conflict(actual)
        case SkillSlugTaken(slug=slug):
            raise name_taken("스킬 slug", slug)
        case SkillInvalid(reasons=reasons):
            raise invalid("; ".join(reasons))
    raise invalid("처리하지 않은 결과")  # pragma: no cover


@router.post("/{skill_id}/archive", response_model=SkillOut)
async def archive_skill(
    skill_id: str,
    graph: CurrentGraph,
    principal: CurrentPrincipal,
    expected_version: Annotated[int, Query(ge=1)],
) -> dict[str, Any]:
    """아카이브하면 **slug 가 풀린다** — 이름을 재사용할 수 있다."""
    _require(principal, Role.ADMIN)
    res = await graph.skills.archive(
        principal.workspace_id, SkillId(skill_id), expected_version=expected_version
    )
    match res:
        case SkillArchived(skill=made):
            return revalidate(SkillOut, skill_out(made))
        case SkillMissing():
            raise not_found("스킬", skill_id)
        case SkillConflict(actual_version=actual):
            from ma_api.shared.errors import version_conflict

            raise version_conflict(actual)
    raise invalid("처리하지 않은 결과")  # pragma: no cover


@router.get("", response_model=PageOut)
async def list_skills(
    graph: CurrentGraph,
    principal: CurrentPrincipal,
    limit: Annotated[int, Query(ge=1, le=200)] = 50,
) -> dict[str, Any]:
    """**파일 내용이 없다.** 스킬 하나가 1MB 까지 가능하다."""
    got = await graph.skills.list_skills(principal.workspace_id, limit=limit)
    items = [revalidate(SkillOut, skill_out(s)) for s in got.items]
    return revalidate(PageOut, page_body(got, items))


@router.get("/{skill_id}", response_model=SkillOut)
async def get_skill(
    skill_id: str, graph: CurrentGraph, principal: CurrentPrincipal
) -> dict[str, Any]:
    got = await graph.skills.find(principal.workspace_id, SkillId(skill_id))
    if got is None:
        raise not_found("스킬", skill_id)
    return revalidate(SkillOut, skill_out(got))


@router.get("/{skill_id}/versions/{version}", response_model=SkillOut)
async def get_skill_version(
    skill_id: str, version: int, graph: CurrentGraph, principal: CurrentPrincipal
) -> dict[str, Any]:
    """**에이전트가 스킬 버전을 핀한다** — 그 버전을 볼 수 있어야 한다."""
    got = await graph.skills.find_version(principal.workspace_id, SkillId(skill_id), version)
    if got is None:
        raise not_found("스킬 버전", f"{skill_id}@{version}")
    return revalidate(SkillOut, skill_out(got))


@router.get("/{skill_id}/files", response_model=PageOut)
async def get_skill_files(
    skill_id: str, graph: CurrentGraph, principal: CurrentPrincipal
) -> dict[str, Any]:
    """파일 내용. **목록에는 없고 여기에만 있다** (점진적 공개)."""
    got = await graph.skills.find(principal.workspace_id, SkillId(skill_id))
    if got is None:
        raise not_found("스킬", skill_id)
    items = [revalidate(SkillFileOut, f) for f in files_out(got)]
    return revalidate(PageOut, {"data": items, "has_more": False, "next_page": None})


@router.get("/catalog/preview", response_model=SkillCatalogOut)
async def catalog_preview(
    graph: CurrentGraph,
    principal: CurrentPrincipal,
    skill_id: Annotated[list[str] | None, Query()] = None,
) -> dict[str, Any]:
    """프롬프트 접두사에 들어갈 **실제 문자열**.

    콘솔이 "이 에이전트의 프롬프트에 무엇이 들어가는가"를 보여 줄 수
    있어야 하고, 그 문자열은 서버가 만드는 것이다 — 클라이언트가
    조립하면 실제와 달라지고, 그 차이는 캐시 적중률로 나타난다.
    """
    ids = tuple(SkillId(s) for s in (skill_id or []))
    text = await graph.skills.catalog_prompt(principal.workspace_id, ids)
    entries = await graph.skills.catalog(principal.workspace_id, ids)
    return revalidate(SkillCatalogOut, {"text": text, "entries": len(entries)})


__all__ = ["router"]
