"""에이전트 wire ↔ 도메인."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from ma_domain.agents import (
    AgentDefinition,
    AgentToolset,
    PermissionPolicy,
    ToolConfig,
)
from ma_domain.ids import ModelCardId
from ma_domain.models import EffortIntent

if TYPE_CHECKING:
    from ma_domain.agents import AgentRecord

    from ma_api.internal.schemas import AgentIn


def definition_from(body: AgentIn) -> AgentDefinition:
    toolset = (
        AgentToolset(
            configs=tuple(
                ToolConfig(
                    name=c.name,
                    enabled=c.enabled,
                    permission_policy=(
                        PermissionPolicy(c.permission_policy) if c.permission_policy else None
                    ),
                )
                for c in body.toolset.configs
            ),
            default_permission_policy=PermissionPolicy(body.toolset.default_permission_policy),
        )
        if body.toolset is not None
        else AgentToolset()
    )
    return AgentDefinition(
        name=body.name,
        model=ModelCardId(body.model),
        system=body.system,
        toolset=toolset,
        harness=body.harness,
        effort=EffortIntent(body.effort) if body.effort else None,
        description=body.description,
    )


def record_out(rec: AgentRecord) -> dict[str, Any]:
    """**스키마에 있는 것만 담는다.** `revalidate` 가 나머지를 막지만,
    애초에 담지 않는 것이 1차 방어다."""
    d = rec.definition
    return {
        "id": rec.id,
        "version": rec.version,
        "name": d.name,
        "model": d.model,
        "system": d.system,
        "harness": d.harness,
        "effort": d.effort.value if d.effort else None,
        "description": d.description,
        "created_at": rec.created_at,
        "updated_at": rec.updated_at,
        "archived_at": rec.archived_at,
    }


__all__ = ["definition_from", "record_out"]
