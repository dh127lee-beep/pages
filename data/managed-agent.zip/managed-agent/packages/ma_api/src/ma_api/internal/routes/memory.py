"""메모리 스토어 (D10). `plan/04-api.md` §3.6.

> `/mnt/memory/<slug>` 로 마운트되고 **에이전트는 일반 파일 툴로 씁니다.**
> 이 API 는 사람과 콘솔을 위한 것이고, 에이전트의 쓰기는 턴 종료에
> 하네스가 같은 유스케이스로 반영합니다 (`ma_harness.memory_sync`).

**CAS 충돌이 409 이고 본문에 지금 해시가 실린다.** 404 로 하면 클라이언트가
"없어졌나" 하고 다시 만들고, 그러면 경로 유니크 인덱스에 또 부딪힌다.
"""

from __future__ import annotations

from typing import Annotated, Any

from fastapi import APIRouter, Query, Response, status
from ma_application.memory import (
    CreateStore,
    MemoryConflict,
    MemoryInvalid,
    MemoryMissing,
    MemoryWritten,
    RedactionRefused,
    SlugTaken,
    StoreArchived,
    StoreCreated,
    StoreInvalid,
    StoreMissing,
    VersionRedacted,
    WriteMemoryInput,
)
from ma_domain.ids import MemoryId, MemoryStoreId, MemoryVersionId
from ma_domain.workspaces import Role

from ma_api.internal.deps import CurrentGraph, CurrentPrincipal
from ma_api.internal.mappers.memory import memory_out, store_out, version_out
from ma_api.internal.schemas import (
    MemoryOut,
    MemoryStoreIn,
    MemoryStoreOut,
    MemoryVersionOut,
    MemoryWriteIn,
    PageOut,
)
from ma_api.shared.errors import ApiError, ErrorType, forbidden, invalid, name_taken, not_found
from ma_api.shared.pagination import page_body
from ma_api.shared.revalidate import revalidate

router = APIRouter(prefix="/api/v1/memory", tags=["memory"])


def _require(principal: Any, role: Role) -> None:
    if not principal.role.at_least(role):
        raise forbidden(f"{role.value} 이상이 필요하다")


def _cas_conflict(res: MemoryConflict) -> ApiError:
    """**지금 해시를 실어 준다.**

    클라이언트가 다시 GET 하면 그 왕복에서 또 바뀔 수 있고, 그러면
    재시도가 영원히 끝나지 않는다 (`version_conflict` 과 같은 이유).
    """
    current = res.current
    return ApiError(
        ErrorType.CONFLICT,
        f"메모리가 그 사이에 바뀌었다: {res.path}",
        extra=(
            ("code", "memory_conflict"),
            ("path", res.path),
            ("actual_sha256", current.content_sha256 if current else None),
            ("actual_revision", current.revision if current else None),
        ),
    )


# ── 스토어 ───────────────────────────────────────────────
@router.post("/stores", response_model=MemoryStoreOut, status_code=status.HTTP_201_CREATED)
async def create_store(
    body: MemoryStoreIn, graph: CurrentGraph, principal: CurrentPrincipal
) -> dict[str, Any]:
    _require(principal, Role.ADMIN)
    res = await graph.memory.create_store(
        CreateStore(workspace_id=principal.workspace_id, name=body.name, slug=body.slug)
    )
    match res:
        case StoreCreated(store=s):
            return revalidate(MemoryStoreOut, store_out(s))
        case SlugTaken(slug=slug):
            raise name_taken("메모리 스토어", slug)
        case StoreInvalid(reasons=reasons):
            raise invalid("; ".join(reasons))
    raise invalid("처리하지 않은 결과")  # pragma: no cover


@router.get("/stores", response_model=PageOut)
async def list_stores(
    graph: CurrentGraph,
    principal: CurrentPrincipal,
    limit: Annotated[int, Query(ge=1, le=200)] = 50,
) -> dict[str, Any]:
    got = await graph.memory.list_stores(principal.workspace_id, limit=limit)
    items = [revalidate(MemoryStoreOut, store_out(s)) for s in got.items]
    return revalidate(PageOut, page_body(got, items))


@router.get("/stores/{store_id}", response_model=MemoryStoreOut)
async def get_store(
    store_id: str, graph: CurrentGraph, principal: CurrentPrincipal
) -> dict[str, Any]:
    got = await graph.memory.find_store(principal.workspace_id, MemoryStoreId(store_id))
    if got is None:
        raise not_found("메모리 스토어", store_id)
    return revalidate(MemoryStoreOut, store_out(got))


@router.delete("/stores/{store_id}", response_model=MemoryStoreOut)
async def archive_store(
    store_id: str, graph: CurrentGraph, principal: CurrentPrincipal
) -> dict[str, Any]:
    _require(principal, Role.ADMIN)
    res = await graph.memory.archive_store(principal.workspace_id, MemoryStoreId(store_id))
    match res:
        case StoreArchived(store=s):
            return revalidate(MemoryStoreOut, store_out(s))
        case StoreMissing():
            raise not_found("메모리 스토어", store_id)
    raise invalid("처리하지 않은 결과")  # pragma: no cover


# ── 문서 ─────────────────────────────────────────────────
@router.put("/stores/{store_id}/entries", response_model=MemoryOut)
async def write_memory(
    store_id: str, body: MemoryWriteIn, graph: CurrentGraph, principal: CurrentPrincipal
) -> dict[str, Any]:
    """**PUT 이고 멱등하지 않다.**

    같은 본문을 두 번 보내면 두 번째는 409 다 — precondition 이 맞지
    않기 때문이다. 그것이 의도다: "내가 본 상태 위에 쓴다"는 주장이
    매번 새로 검사돼야 CAS 다.
    """
    _require(principal, Role.OPERATOR)
    res = await graph.memory.write(
        WriteMemoryInput(
            workspace_id=principal.workspace_id,
            store_id=MemoryStoreId(store_id),
            path=body.path,
            content=body.content,
            author=f"{principal.kind}:{principal.id}",
            precondition_sha256=body.precondition_sha256,
        )
    )
    match res:
        case MemoryWritten(memory=m):
            return revalidate(MemoryOut, memory_out(m))
        case StoreMissing():
            raise not_found("메모리 스토어", store_id)
        case MemoryInvalid(reasons=reasons):
            raise invalid("; ".join(reasons))
        case MemoryConflict():
            raise _cas_conflict(res)
    raise invalid("처리하지 않은 결과")  # pragma: no cover


@router.get("/stores/{store_id}/entries", response_model=PageOut)
async def list_memories(
    store_id: str,
    graph: CurrentGraph,
    principal: CurrentPrincipal,
    limit: Annotated[int, Query(ge=1, le=200)] = 50,
) -> dict[str, Any]:
    got = await graph.memory.list_in_store(
        principal.workspace_id, MemoryStoreId(store_id), limit=limit
    )
    items = [revalidate(MemoryOut, memory_out(m)) for m in got.items]
    return revalidate(PageOut, page_body(got, items))


@router.get("/entries/{memory_id}", response_model=MemoryOut)
async def get_memory(
    memory_id: str, graph: CurrentGraph, principal: CurrentPrincipal
) -> dict[str, Any]:
    got = await graph.memory.find(principal.workspace_id, MemoryId(memory_id))
    if got is None:
        raise not_found("메모리", memory_id)
    return revalidate(MemoryOut, memory_out(got))


@router.delete(
    "/entries/{memory_id}",
    response_model=None,
    status_code=status.HTTP_204_NO_CONTENT,
)
async def delete_memory(
    memory_id: str, graph: CurrentGraph, principal: CurrentPrincipal
) -> Response:
    _require(principal, Role.OPERATOR)
    res = await graph.memory.delete(principal.workspace_id, MemoryId(memory_id))
    if isinstance(res, MemoryMissing):
        raise not_found("메모리", memory_id)
    return Response(status_code=status.HTTP_204_NO_CONTENT)


# ── 감사·레댁션 ──────────────────────────────────────────
@router.get("/stores/{store_id}/versions", response_model=PageOut)
async def list_versions(
    store_id: str,
    graph: CurrentGraph,
    principal: CurrentPrincipal,
    limit: Annotated[int, Query(ge=1, le=200)] = 50,
) -> dict[str, Any]:
    _require(principal, Role.ADMIN)
    got = await graph.memory.list_versions(
        principal.workspace_id, MemoryStoreId(store_id), limit=limit
    )
    items = [revalidate(MemoryVersionOut, version_out(v)) for v in got.items]
    return revalidate(PageOut, page_body(got, items))


@router.post(
    "/versions/{version_id}/redact",
    response_model=None,
    status_code=status.HTTP_204_NO_CONTENT,
)
async def redact_version(
    version_id: str, graph: CurrentGraph, principal: CurrentPrincipal
) -> Response:
    """**live head 는 거부한다** — 409 지 404 가 아니다.

    `OWNER` 를 요구한다. 레댁션은 감사 기록을 지우는 유일한 길이고,
    그 권한을 ADMIN 까지 넓히면 "감사 로그가 append-only 다"가 약해진다.
    """
    _require(principal, Role.OWNER)
    res = await graph.memory.redact_version(
        principal.workspace_id, MemoryVersionId(version_id), f"{principal.kind}:{principal.id}"
    )
    match res:
        case VersionRedacted():
            return Response(status_code=status.HTTP_204_NO_CONTENT)
        case RedactionRefused(reason=reason):
            raise ApiError(
                ErrorType.CONFLICT,
                reason,
                extra=(("code", "redaction_refused"), ("version_id", version_id)),
            )
    raise invalid("처리하지 않은 결과")  # pragma: no cover


__all__ = ["router"]
