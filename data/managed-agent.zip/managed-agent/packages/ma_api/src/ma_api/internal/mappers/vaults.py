"""볼트·자격증명 wire 변환.

`plan/09-codebase.md` §5 · `plan/04-api.md` §3.5.

**평문은 들어오기만 하고 나가지 않는다.** `credential_out` 에 `secret` 을
담을 자리가 없고, 담으려 해도 `CredentialOut` 이 `extra="forbid"` 라
`revalidate` 가 500 을 낸다.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from ma_application.vaults import CreateCredential, RotateCredentialInput
from ma_domain.vaults import CredentialKind

if TYPE_CHECKING:
    from ma_domain.ids import CredentialId, UserId, VaultId, WorkspaceId
    from ma_domain.vaults import CredentialMeta, Vault

    from ma_api.internal.schemas import CredentialIn, CredentialRotateIn


def vault_out(v: Vault) -> dict[str, Any]:
    return {
        "id": v.id,
        "name": v.name,
        "version": v.version,
        "created_at": v.created_at,
        "archived_at": v.archived_at,
    }


def credential_out(c: CredentialMeta) -> dict[str, Any]:
    """**필드를 하나하나 적는다.** `asdict` 를 쓰지 않는다.

    `asdict` 면 도메인에 필드가 늘 때마다 wire 가 **조용히 넓어진다.**
    그중 하나가 비밀이면 그 한 번으로 끝이다. 적어 두면 늘어난 필드는
    여기 없으므로 나가지 않는다.
    """
    return {
        "id": c.id,
        "vault_id": c.vault_id,
        "kind": c.kind.value,
        "match_hosts": c.match_hosts,
        "mcp_server_name": c.mcp_server_name,
        "header_name": c.header_name,
        "key_version": c.key_version,
        "created_by": c.created_by,
        "created_at": c.created_at,
        "expires_at": c.expires_at,
        "rotated_at": c.rotated_at,
        "archived_at": c.archived_at,
    }


def create_credential_from(
    body: CredentialIn,
    *,
    workspace_id: WorkspaceId,
    vault_id: VaultId,
    created_by: UserId,
) -> CreateCredential:
    return CreateCredential(
        workspace_id=workspace_id,
        vault_id=vault_id,
        kind=CredentialKind(body.kind),
        secret=body.secret,
        created_by=created_by,
        match_hosts=tuple(body.match_hosts),
        mcp_server_name=body.mcp_server_name,
        header_name=body.header_name,
        expires_at=body.expires_at,
    )


def rotate_from(
    body: CredentialRotateIn, *, workspace_id: WorkspaceId, credential_id: CredentialId
) -> RotateCredentialInput:
    return RotateCredentialInput(
        workspace_id=workspace_id,
        credential_id=credential_id,
        secret=body.secret,
        expires_at=body.expires_at,
    )


__all__ = ["create_credential_from", "credential_out", "rotate_from", "vault_out"]
