"""메모리 wire 변환. `plan/04-api.md` §3.6 · `plan/09-codebase.md` §5.

**`mount_path` 는 서버가 계산한다.** 도메인의 `MemoryStore.mount_path` 를
그대로 싣는다 — 클라이언트가 `/mnt/memory/` + slug 를 조립하게 두면 경로
규칙이 두 벌이 되고, D10 을 바꿀 때 콘솔이 조용히 틀린 경로를 보여 준다.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from ma_domain.memory import Memory, MemoryStore, MemoryVersion


def store_out(s: MemoryStore) -> dict[str, Any]:
    return {
        "id": s.id,
        "name": s.name,
        "slug": s.slug,
        "mount_path": s.mount_path,
        "revision": s.revision,
        "created_at": s.created_at,
        "archived_at": s.archived_at,
    }


def memory_out(m: Memory) -> dict[str, Any]:
    # 필드를 하나하나 적는다 (`mappers/vaults.py` 와 같은 이유) —
    # `asdict` 면 도메인에 필드가 늘 때 wire 가 조용히 넓어진다.
    return {
        "id": m.id,
        "store_id": m.store_id,
        "path": m.path,
        "content": m.content,
        "content_sha256": m.content_sha256,
        "revision": m.revision,
        "created_at": m.created_at,
        "updated_at": m.updated_at,
    }


def version_out(v: MemoryVersion) -> dict[str, Any]:
    """**레댁션된 버전도 나간다.** `content` 가 `None` 일 뿐이다.

    숨기면 "몇 개가 지워졌는가"를 알 수 없고, 그것은 감사 로그의 존재
    이유를 지운다.
    """
    return {
        "id": v.id,
        "store_id": v.store_id,
        "memory_id": v.memory_id,
        "path": v.path,
        "content": v.content,
        "content_sha256": v.content_sha256,
        "author": v.author,
        "created_at": v.created_at,
        "redacted_at": v.redacted_at,
        "redacted_by": v.redacted_by,
    }


__all__ = ["memory_out", "store_out", "version_out"]
