"""AWP · FastAPI 라우터 + wire 스키마 (internal / compat)"""
