"""에러 envelope — **두 lane 이 같은 모양을 쓴다**.

`plan/04-api.md` §2.3.

Console 이 내부 lane 과 공식 lane 을 특별 취급하지 않게 하려는 것이다. 모양이
다르면 클라이언트가 두 벌의 에러 처리를 들고 있어야 한다.

```json
{ "type": "error",
  "error": { "type": "not_found_error", "message": "..." } }
```

**404 는 "없음"과 "다른 워크스페이스에 있음"을 구분하지 않는다.** 구분하면
존재 여부가 누설되고, 그것만으로 다른 부서의 리소스 id 를 열거할 수 있다.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
from typing import Any


class ErrorType(StrEnum):
    """`plan/04-api.md` §2.3 의 표 그대로."""

    INVALID_REQUEST = "invalid_request_error"
    AUTHENTICATION = "authentication_error"
    PERMISSION = "permission_error"
    NOT_FOUND = "not_found_error"
    CONFLICT = "conflict_error"
    RATE_LIMIT = "rate_limit_error"
    BUDGET_EXCEEDED = "budget_exceeded_error"
    APPROVAL_REQUIRED = "approval_required_error"
    API = "api_error"


#: `error.type` → HTTP 상태. **한 곳에만 둔다** — 라우터마다 정하면 어긋난다.
STATUS: dict[ErrorType, int] = {
    ErrorType.INVALID_REQUEST: 400,
    ErrorType.AUTHENTICATION: 401,
    ErrorType.PERMISSION: 403,
    ErrorType.NOT_FOUND: 404,
    ErrorType.CONFLICT: 409,
    ErrorType.RATE_LIMIT: 429,
    ErrorType.BUDGET_EXCEEDED: 409,
    ErrorType.APPROVAL_REQUIRED: 409,
    ErrorType.API: 500,
}


@dataclass(frozen=True, slots=True)
class ApiError(Exception):
    """라우터가 올리는 유일한 예외. 미들웨어가 envelope 으로 바꾼다."""

    type: ErrorType
    message: str
    #: 409 에 실리는 추가 정보 (`actual_version` 등).
    extra: tuple[tuple[str, Any], ...] = ()

    def __post_init__(self) -> None:
        super().__init__(self.message)

    @property
    def status(self) -> int:
        return STATUS[self.type]

    def envelope(self) -> dict[str, Any]:
        body: dict[str, Any] = {"type": self.type.value, "message": self.message}
        body.update(dict(self.extra))
        return {"type": "error", "error": body}


def not_found(what: str, ident: str) -> ApiError:
    """**없음과 다른 워크스페이스를 구분하지 않는다.**"""
    return ApiError(ErrorType.NOT_FOUND, f"{what} {ident} was not found")


def invalid(message: str) -> ApiError:
    return ApiError(ErrorType.INVALID_REQUEST, message)


def forbidden(message: str) -> ApiError:
    return ApiError(ErrorType.PERMISSION, message)


def unauthenticated(message: str = "자격증명이 없거나 무효하다") -> ApiError:
    return ApiError(ErrorType.AUTHENTICATION, message)


def conflict(message: str, *, code: str = "conflict") -> ApiError:
    """지금 상태에서 할 수 없다. **요청이 틀린 것이 아니다.**

    `invalid`(400) 와 가르는 선: 400 은 "고쳐서 다시 보내라"이고 409 는
    "그대로 나중에 다시 보내라"다. 겹친 실행 때문에 건너뛴 배포는 후자다.
    """
    return ApiError(ErrorType.CONFLICT, message, extra=(("code", code),))


def version_conflict(actual: int) -> ApiError:
    """클라이언트가 다시 읽을 수 있게 **실제 버전을 실어 준다**."""
    return ApiError(
        ErrorType.CONFLICT,
        "버전이 어긋났다",
        extra=(("code", "version_conflict"), ("actual_version", actual)),
    )


def name_taken(what: str, name: str) -> ApiError:
    """같은 이름이 이미 있다. **버전 충돌과 다른 사실이다.**

    `version_conflict` 는 "다시 읽고 다시 보내라"이고, 이것은 "다른 이름을
    쓰라"다. 코드를 실어 클라이언트가 구분할 수 있게 한다.
    """
    return ApiError(
        ErrorType.CONFLICT,
        f"같은 이름의 {what} 이 있다: {name}",
        extra=(("code", "name_taken"),),
    )


def idempotency_conflict(event_id: str) -> ApiError:
    return ApiError(
        ErrorType.CONFLICT,
        "같은 Idempotency-Key 로 다른 내용이 왔다",
        extra=(("code", "idempotency_conflict"), ("event_id", event_id)),
    )


__all__ = [
    "STATUS",
    "ApiError",
    "ErrorType",
    "conflict",
    "forbidden",
    "idempotency_conflict",
    "invalid",
    "name_taken",
    "not_found",
    "unauthenticated",
    "version_conflict",
]
