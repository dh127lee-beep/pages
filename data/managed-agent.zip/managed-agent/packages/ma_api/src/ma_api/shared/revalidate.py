"""응답 재검증 — **나가는 것도 strict 스키마를 통과해야 한다**.

`plan/03-layers.md` §3 L5a · `plan/09-codebase.md` §4.

들어오는 것만 검증하면 내부 필드가 조용히 wire 로 샌다. 한번 새면 클라이언트가
그것에 의존하기 시작하고, **사실상 공개 API 가 된다** — 지울 수 없게 된다.

실패하면 **500 이다.** 200 으로 내보내지 않는다. "응답을 못 만들었다"는 서버
문제이고, 잘못된 모양을 내보내는 것보다 실패하는 편이 낫다. 특히 샌 필드가
비밀이면 그 한 번으로 끝이다.

`tools/check_architecture.py` 가 라우터의 반환이 이 함수를 거치는지 검사한다.
"""

from __future__ import annotations

import logging
from typing import Any, TypeVar

from pydantic import BaseModel, ValidationError

from ma_api.shared.errors import ApiError, ErrorType

_log = logging.getLogger("ma_api.revalidate")

M = TypeVar("M", bound=BaseModel)


def revalidate[M: BaseModel](model: type[M], value: Any) -> dict[str, Any]:
    """유스케이스 결과 → 응답 본문. 스키마에 없는 필드가 있으면 500.

    `model_config` 에 `extra="forbid"` 가 있어야 의미가 있다 — `StrictModel`
    을 상속하면 자동이다.
    """
    try:
        checked = model.model_validate(value)
    except ValidationError as exc:
        # **본문에 상세를 싣지 않는다.** 샌 필드 이름 자체가 내부 구조의
        # 누설이다. 상세는 로그로만 간다.
        _log.error("응답 재검증 실패 model=%s errors=%s", model.__name__, exc.errors())
        raise ApiError(ErrorType.API, "응답을 만들지 못했다") from exc
    return checked.model_dump(mode="json", exclude_none=True)


class StrictModel(BaseModel):
    """모든 응답 스키마의 바닥. **모르는 필드를 거부한다.**"""

    model_config = {"extra": "forbid", "frozen": True}


__all__ = ["StrictModel", "revalidate"]
