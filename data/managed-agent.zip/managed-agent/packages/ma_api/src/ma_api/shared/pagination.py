"""커서 인코딩과 페이지 응답 — **두 lane 이 공유한다**.

`plan/04-api.md` §2.5.

offset 을 쓰지 않는 이유: 이벤트가 계속 들어오는 테이블에서 offset 은 틀린다.
`(created_at, id)` 복합키를 base64url 로 싣고, 인덱스가 정확히 그 순서다.
"""

from __future__ import annotations

from typing import Any

from ma_store._results import Cursor, Page


def encode(cursor: Cursor | None) -> str | None:
    return cursor.encode() if cursor is not None else None


def decode(raw: str | None) -> Cursor | None:
    """잘못된 커서는 **400 이다** — 조용히 처음부터 돌려주면 클라이언트가
    무한 루프에 빠진다."""
    if not raw:
        return None
    from ma_api.shared.errors import invalid

    try:
        return Cursor.decode(raw)
    except (ValueError, TypeError) as exc:
        raise invalid(f"커서를 읽을 수 없다: {raw}") from exc


def page_body[T](page: Page[T], items: list[Any]) -> dict[str, Any]:
    return {
        "data": items,
        "has_more": page.next_cursor is not None,
        "next_page": encode(page.next_cursor),
    }


__all__ = ["decode", "encode", "page_body"]
