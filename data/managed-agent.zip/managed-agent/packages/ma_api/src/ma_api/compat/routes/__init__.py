"""공식 호환 lane 라우터 (`/v1/*`) — T-0605.

`plan/04-api.md` §6 · D9.

**`ma_api.internal` 을 import 하지 않는다.** `.importlinter` 의
`api-lanes` 계약이 강제한다. `shared`(의존성 주입·재검증)만 공유한다.
"""

from __future__ import annotations

from ma_api.compat.routes.agents import router as agents_router
from ma_api.compat.routes.sessions import router as sessions_router
from ma_api.compat.routes.unsupported import router as unsupported_router

#: 마운트 순서. **미지원이 마지막** — 구체 경로가 먼저 잡혀야 한다.
COMPAT_ROUTERS = (agents_router, sessions_router, unsupported_router)

__all__ = ["COMPAT_ROUTERS"]
