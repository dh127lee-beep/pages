"""공식 호환 lane (`/v1/*`) — T-0605.

`plan/04-api.md` §6 · `plan/09-codebase.md` §5 · D9.

> **데이터·실행은 사내에 두면서 공식 SDK 생태계를 쓴다.** 코드가
> 이미 분리돼 있으므로(D9) 이것은 '켜는' 작업이다.

세 가지가 내부 lane 과 다르다:

| | 내부 (`/api/v1/*`) | 공식 (`/v1/*`) |
|---|---|---|
| 스키마 | 사내 개념을 포함 | **공식 shape 만** — 필드 추가 금지 |
| 에러 | `code`·`actual_version` 확장 | `type` + `message` 뿐 |
| beta 헤더 | 없음 | **리소스별 게이트** |

`.importlinter` 의 `api-lanes` 계약이 `internal` ↔ `compat` 상호
import 를 막는다. 섞이면 사내 개념이 공식 wire 로 새고, 공식 계약은
**필드 추가가 금지**라 한 번 새면 되돌릴 수 없다.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from ma_api.compat.beta import (
    DREAMING_BETA,
    MANAGED_AGENTS_BETA,
    MCP_TUNNELS_BETA,
    Resource,
)
from ma_api.compat.errors import CompatError, CompatErrorType

if TYPE_CHECKING:
    from fastapi import FastAPI

_log = logging.getLogger("ma_api.compat")


def mount_compat(app: FastAPI) -> None:
    """`/v1/*` 라우터와 **공식 모양 에러 핸들러**를 붙인다.

    에러 핸들러가 따로 있는 이유: 앱의 `ApiError` 핸들러는 내부
    envelope(`code`·`request_id` 확장)을 쓴다. 그것이 공식 lane 응답에
    실리면 **'필드 추가 금지'가 깨진다.**
    """
    from fastapi import Request
    from fastapi.responses import JSONResponse

    from ma_api.compat.routes import COMPAT_ROUTERS

    @app.exception_handler(CompatError)
    async def _compat_error(request: Request, exc: Exception) -> JSONResponse:
        err = (
            exc
            if isinstance(exc, CompatError)
            else CompatError(CompatErrorType.API, "internal error")
        )
        if err.status >= 500:  # pragma: no cover — 내부 오류는 테스트가 안 만든다
            _log.exception("compat api_error path=%s", request.url.path)
        # **`request_id` 를 싣지 않는다.** 공식 envelope 에 그 자리가 없다.
        return JSONResponse(status_code=err.status, content=err.envelope())

    for router in COMPAT_ROUTERS:
        app.include_router(router)


__all__ = [
    "DREAMING_BETA",
    "MANAGED_AGENTS_BETA",
    "MCP_TUNNELS_BETA",
    "CompatError",
    "Resource",
    "mount_compat",
]
