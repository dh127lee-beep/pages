"""공식 wire 스키마 — **공식 shape 만** (T-0605).

`plan/04-api.md` §6 · `ref/api/*/_types.md`.

> **필드를 더하지 않는다.** 하나라도 더하면 '호환'이 거짓이 된다 —
> 공식 SDK 는 모르는 필드를 무시하지만, 그 필드에 의존하는 코드가
> 생기면 우리는 공식으로 옮겨 갈 수 없게 된다.

`internal` 의 스키마를 재사용하지 않는 이유도 같다. 재사용하는 순간
사내 개념(`revision`·`stop_reason`·`required_action`)이 공식 wire 로
샌다 (D9).

**나가는 것도 strict 로 재검증한다** (`plan/04` §6.1 ③). 공식 shape 에
없는 필드가 새면 500 이다 — 조용히 나가는 것보다 낫다.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import Field

from ma_api.shared.revalidate import StrictModel

#: 공식 id 접두 (`ref/api/*/retrieve.md` 의 예제에서 읽었다).
#:
#: | 공식 | 우리 (`ma_domain.ids.PREFIXES`) | |
#: |---|---|---|
#: | `agent_` | `agent_` | 같다 |
#: | `env_` | `env_` | 같다 |
#: | `sesn_` | `sess_` | **다르다** |
#: | `vlt_` | `vault_` | **다르다** |
#: | `memsto_` | `memst_` | **다르다** |
#:
#: 다른 것만 매퍼가 번역한다 (`compat.mappers._ID_MAP`).
OFFICIAL_PREFIXES = {
    "agent": "agent_",
    "session": "sesn_",
    "environment": "env_",
    "vault": "vlt_",
    "memory_store": "memsto_",
}


# ── 공통 ───────────────────────────────────────────────────
class EffortOut(StrictModel):
    """`{"type": "low"}` — **문자열이 아니라 객체다.**"""

    type: Literal["low", "medium", "high", "xhigh", "max"]


class ModelConfigOut(StrictModel):
    id: str
    effort: EffortOut | None = None
    inference_geo: str | None = None
    speed: Literal["standard", "fast"] | None = None


class McpServerOut(StrictModel):
    type: Literal["url"] = "url"
    name: str
    url: str


class PermissionPolicyOut(StrictModel):
    type: Literal["always_allow", "always_ask"]


class ToolConfigOut(StrictModel):
    name: str
    enabled: bool
    permission_policy: PermissionPolicyOut | None = None


class DefaultToolConfigOut(StrictModel):
    enabled: bool
    permission_policy: PermissionPolicyOut


class AgentToolsetOut(StrictModel):
    type: Literal["agent_toolset_20260401"] = "agent_toolset_20260401"
    configs: tuple[ToolConfigOut, ...] = ()
    default_config: DefaultToolConfigOut


class AgentOut(StrictModel):
    """`BetaManagedAgentsAgent`. **`type` 이 있다** — 공식은 태그를 싣는다."""

    type: Literal["agent"] = "agent"
    id: str
    name: str
    version: int
    model: ModelConfigOut
    created_at: datetime
    updated_at: datetime
    description: str | None = None
    system: str | None = None
    mcp_servers: tuple[McpServerOut, ...] = ()
    metadata: dict[str, str] = Field(default_factory=dict)
    skills: tuple[dict[str, Any], ...] = ()
    tools: tuple[AgentToolsetOut, ...] = ()
    multiagent: dict[str, Any] | None = None
    archived_at: datetime | None = None


class AgentListOut(StrictModel):
    """**`has_more` 가 없다.** 공식은 `next_page` 하나만 쓴다."""

    data: tuple[AgentOut, ...] = ()
    next_page: str | None = None


# ── 입력 ───────────────────────────────────────────────────
class EffortIn(StrictModel):
    type: Literal["low", "medium", "high", "xhigh", "max"]


class ModelConfigIn(StrictModel):
    id: str = Field(min_length=1)
    effort: EffortIn | None = None
    inference_geo: str | None = None
    speed: Literal["standard", "fast"] | None = None


class McpServerIn(StrictModel):
    type: Literal["url"] = "url"
    name: str = Field(min_length=1)
    url: str = Field(min_length=1)


class PermissionPolicyIn(StrictModel):
    #: **`auto` 를 받지 않는다** (`plan/04` §6.3). 공식은 서버가 호출마다
    #: 위험을 평가하지만 우리는 그 모델이 없다 — 받아 놓고 안 하면
    #: 사용자가 평가되고 있다고 믿는다.
    type: Literal["always_allow", "always_ask"]


class ToolConfigIn(StrictModel):
    name: str = Field(min_length=1)
    enabled: bool = True
    permission_policy: PermissionPolicyIn | None = None


class DefaultToolConfigIn(StrictModel):
    enabled: bool = True
    permission_policy: PermissionPolicyIn | None = None


class AgentToolsetIn(StrictModel):
    type: Literal["agent_toolset_20260401"] = "agent_toolset_20260401"
    configs: tuple[ToolConfigIn, ...] = ()
    default_config: DefaultToolConfigIn | None = None


class AgentIn(StrictModel):
    """`POST /v1/agents`. **`model` 이 문자열 또는 객체다.**"""

    name: str = Field(min_length=1, max_length=200)
    model: str | ModelConfigIn
    system: str | None = None
    description: str | None = None
    mcp_servers: tuple[McpServerIn, ...] = ()
    metadata: dict[str, str] = Field(default_factory=dict)
    tools: tuple[AgentToolsetIn, ...] = ()
    skills: tuple[dict[str, Any], ...] = ()


class AgentUpdateIn(StrictModel):
    """`POST /v1/agents/{id}` — **PATCH 가 아니다** (`ref/api/README.md`)."""

    name: str | None = Field(default=None, min_length=1, max_length=200)
    model: str | ModelConfigIn | None = None
    system: str | None = None
    description: str | None = None
    mcp_servers: tuple[McpServerIn, ...] | None = None
    metadata: dict[str, str] | None = None
    tools: tuple[AgentToolsetIn, ...] | None = None


# ── 세션 ───────────────────────────────────────────────────
class MoneyOut(StrictModel):
    """`{"amount": "2500", "currency": "USD"}` — **문자열 금액이다.**

    부동소수로 보내면 반올림이 클라이언트마다 다르게 난다.
    """

    amount: str
    currency: str


class BudgetOut(StrictModel):
    type: Literal["limit"] = "limit"
    max_list_cost: MoneyOut


class CacheCreationOut(StrictModel):
    ephemeral_1h_input_tokens: int = 0
    ephemeral_5m_input_tokens: int = 0


class ServerToolUseOut(StrictModel):
    web_fetch_requests: int = 0
    web_search_requests: int = 0


class UsageOut(StrictModel):
    active_seconds: int = 0
    cache_creation: CacheCreationOut = Field(default_factory=CacheCreationOut)
    cache_read_input_tokens: int = 0
    input_tokens: int = 0
    output_tokens: int = 0
    list_cost: MoneyOut
    server_tool_use: ServerToolUseOut = Field(default_factory=ServerToolUseOut)


class StatsOut(StrictModel):
    active_seconds: int = 0
    duration_seconds: int = 0


class SessionOut(StrictModel):
    """`BetaManagedAgentsSession`.

    **`revision`·`stop_reason`·`required_action` 이 없다.** 전부 사내
    개념이다 — 공식 계약에 자리가 없고, 더하면 호환이 거짓이 된다.
    """

    type: Literal["session"] = "session"
    id: str
    agent: dict[str, Any]
    environment_id: str
    status: Literal["idle", "running", "rescheduled", "terminated"]
    created_at: datetime
    updated_at: datetime
    stats: StatsOut = Field(default_factory=StatsOut)
    usage: UsageOut
    metadata: dict[str, str] = Field(default_factory=dict)
    vault_ids: tuple[str, ...] = ()
    resources: tuple[dict[str, Any], ...] = ()
    outcome_evaluations: tuple[dict[str, Any], ...] = ()
    budget: BudgetOut | None = None
    title: str | None = None
    deployment_id: str | None = None
    archived_at: datetime | None = None


class SessionListOut(StrictModel):
    data: tuple[SessionOut, ...] = ()
    next_page: str | None = None


class BudgetIn(StrictModel):
    type: Literal["limit"] = "limit"
    max_list_cost: MoneyOut


class SessionIn(StrictModel):
    """`POST /v1/sessions`. **`agent` 가 문자열 또는 객체다.**"""

    agent: str | dict[str, Any]
    environment_id: str = Field(min_length=1)
    budget: BudgetIn | None = None
    metadata: dict[str, str] = Field(default_factory=dict)
    title: str | None = None
    vault_ids: tuple[str, ...] = ()
    initial_events: tuple[dict[str, Any], ...] = ()
    resources: tuple[dict[str, Any], ...] = ()


__all__ = [
    "OFFICIAL_PREFIXES",
    "AgentIn",
    "AgentListOut",
    "AgentOut",
    "AgentToolsetIn",
    "AgentToolsetOut",
    "AgentUpdateIn",
    "BudgetIn",
    "BudgetOut",
    "CacheCreationOut",
    "DefaultToolConfigIn",
    "DefaultToolConfigOut",
    "EffortIn",
    "EffortOut",
    "McpServerIn",
    "McpServerOut",
    "ModelConfigIn",
    "ModelConfigOut",
    "MoneyOut",
    "PermissionPolicyIn",
    "PermissionPolicyOut",
    "ServerToolUseOut",
    "SessionIn",
    "SessionListOut",
    "SessionOut",
    "StatsOut",
    "ToolConfigIn",
    "ToolConfigOut",
    "UsageOut",
]
