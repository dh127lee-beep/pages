"""공식 모양 에러 — **`ma_api.shared` 를 쓰지 않는다** (T-0605).

`plan/04-api.md` §2.3 §6 · D9.

envelope 모양은 같지만(`{"type":"error","error":{...}}`) **코드가
다르다**: 내부 lane 은 `code`·`actual_version` 같은 사내 확장을
싣고, 공식 lane 은 공식에 있는 것만 싣는다.

`shared.errors` 를 재사용하면 그 확장이 공식 응답에 섞인다 — 그러면
"필드 추가 금지"가 깨지고, 깨진 것을 아무도 못 본다.

> `.importlinter` 의 `api-lanes` 계약이 `internal` ↔ `compat` 상호
> import 를 막지만, `shared` 는 둘 다 쓸 수 있다. 그래서 **의도적으로**
> 여기 한 벌 더 쓴다.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum


class CompatErrorType(StrEnum):
    """공식 `error.type`. **사내 확장이 없다.**

    `budget_exceeded_error` · `approval_required_error` 는 내부 lane
    에만 있다 (`plan/04` §2.3 의 "사내 확장" 표시). 공식 클라이언트는
    그 값을 모르므로 `invalid_request_error` 로 접어 보낸다.
    """

    INVALID_REQUEST = "invalid_request_error"
    AUTHENTICATION = "authentication_error"
    PERMISSION = "permission_error"
    NOT_FOUND = "not_found_error"
    CONFLICT = "conflict_error"
    RATE_LIMIT = "rate_limit_error"
    API = "api_error"


STATUS: dict[CompatErrorType, int] = {
    CompatErrorType.INVALID_REQUEST: 400,
    CompatErrorType.AUTHENTICATION: 401,
    CompatErrorType.PERMISSION: 403,
    CompatErrorType.NOT_FOUND: 404,
    CompatErrorType.CONFLICT: 409,
    CompatErrorType.RATE_LIMIT: 429,
    CompatErrorType.API: 500,
}


@dataclass(frozen=True, slots=True)
class CompatError(Exception):
    type: CompatErrorType
    message: str

    def __post_init__(self) -> None:
        super().__init__(self.message)

    @property
    def status(self) -> int:
        return STATUS[self.type]

    def envelope(self) -> dict[str, object]:
        """**`error` 안에 `type` 과 `message` 뿐이다.**

        내부 lane 은 여기에 `code`·`actual_version` 을 더하지만 공식
        계약에는 그 자리가 없다.
        """
        return {"type": "error", "error": {"type": self.type.value, "message": self.message}}


def not_found(what: str, ident: str) -> CompatError:
    """**없음과 다른 워크스페이스를 구분하지 않는다** — 존재를 누설하지 않는다."""
    return CompatError(CompatErrorType.NOT_FOUND, f"{what} {ident} was not found")


def invalid(message: str) -> CompatError:
    return CompatError(CompatErrorType.INVALID_REQUEST, message)


def permission(message: str) -> CompatError:
    return CompatError(CompatErrorType.PERMISSION, message)


def unauthenticated(message: str = "missing or invalid credentials") -> CompatError:
    return CompatError(CompatErrorType.AUTHENTICATION, message)


def conflict(message: str) -> CompatError:
    return CompatError(CompatErrorType.CONFLICT, message)


def beta_required(beta: str) -> CompatError:
    """beta 헤더가 없다. **400 이다.**

    공식과 같은 문구를 쓴다 — SDK 가 문구로 분기하지는 않지만, 사람이
    공식 문서를 검색해 답을 찾을 수 있어야 한다.
    """
    return CompatError(
        CompatErrorType.INVALID_REQUEST,
        f"The beta header '{beta}' is required to use this endpoint.",
    )


def unsupported(what: str) -> CompatError:
    """우리가 구현하지 않는 리소스. **404 다** (`plan/04` §6.2)."""
    return CompatError(CompatErrorType.NOT_FOUND, f"{what} is not supported by this deployment")


__all__ = [
    "STATUS",
    "CompatError",
    "CompatErrorType",
    "beta_required",
    "conflict",
    "invalid",
    "not_found",
    "permission",
    "unauthenticated",
    "unsupported",
]
