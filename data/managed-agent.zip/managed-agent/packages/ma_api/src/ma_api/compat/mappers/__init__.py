"""우리 도메인 ↔ 공식 wire (T-0605).

`plan/04-api.md` §6.3.

**번역이 한곳에 모여 있다.** 라우터에 흩어지면 같은 번역이 여러 벌이
되고, 그중 하나가 어긋나도 테스트가 그것을 못 본다.

모양이 다른 지점 (`plan/04` §6.3):

| 항목 | 공식 | 우리 | 처리 |
|---|---|---|---|
| id 접두 | `sesn_` `vlt_` `memsto_` | `sess_` `vault_` `memst_` | **양방향 번역** |
| effort | `{"type":"low"}` | `"low"` | 객체로 감싼다 |
| 모델 | 실제 모델 문자열 | 모델 카드 핸들 | **둘 다 받는다** |
| 권한 `auto` | 서버가 평가 | 미지원 | 400 |
"""

from __future__ import annotations

from decimal import Decimal
from typing import TYPE_CHECKING, Any

from ma_domain.agents import (
    AgentDefinition,
    AgentToolset,
    McpServerSpec,
    PermissionPolicy,
    ToolConfig,
)
from ma_domain.ids import ModelCardId
from ma_domain.models import EffortIntent

from ma_api.compat.errors import invalid

if TYPE_CHECKING:
    from ma_domain.agents import AgentRecord
    from ma_domain.sessions import SessionRecord

    from ma_api.compat.schemas import AgentIn, AgentUpdateIn

#: 공식 접두 → 우리 접두 (`ma_domain.ids.PREFIXES`). **다른 것만 적는다.**
#:
#: `agent_` 와 `env_` 는 **우연히 같다** — 그래서 여기 없다. 같은
#: 것을 적어 두면 "번역했다"고 읽히고, 나중에 한쪽이 바뀌었을 때
#: 이 표가 거짓이 된다.
_ID_MAP = (
    ("sesn_", "sess_"),
    ("vlt_", "vault_"),
    ("memsto_", "memst_"),
)


def to_internal_id(official: str) -> str:
    """`agent_xxx` → `agt_xxx`. 모르는 접두는 **그대로 둔다.**

    그대로 두는 이유: 공식 접두가 아닌 것을 넘기는 경우가 있고
    (우리 콘솔이 만든 id 를 공식 lane 으로 조회), 그때 거부하면
    같은 리소스를 lane 에 따라 다른 이름으로 불러야 한다.
    """
    for public, internal in _ID_MAP:
        if official.startswith(public):
            return internal + official[len(public) :]
    return official


def to_official_id(internal: str) -> str:
    """`agt_xxx` → `agent_xxx`."""
    for public, internal_prefix in _ID_MAP:
        if internal.startswith(internal_prefix):
            return public + internal[len(internal_prefix) :]
    return internal


# ── 에이전트 ───────────────────────────────────────────────
def model_handle(raw: Any) -> tuple[str, EffortIntent | None]:
    """`model` 입력 → `(카드 핸들, effort)`.

    **문자열과 객체를 둘 다 받는다.** 공식 SDK 는 둘 다 보낸다
    (`BetaManagedAgentsModel or BetaManagedAgentsModelConfigParams`).

    공식 lane 에서는 **카드 핸들과 실제 모델 ID 를 둘 다 허용한다**
    (`plan/04` §6.3) — 해석은 `ModelResolver` 가 하고, 여기서는
    문자열을 그대로 넘긴다.
    """
    if isinstance(raw, str):
        return raw, None
    handle = getattr(raw, "id", None)
    if not handle:
        raise invalid("model.id is required")
    effort_obj = getattr(raw, "effort", None)
    effort = None
    if effort_obj is not None:
        try:
            effort = EffortIntent(effort_obj.type)
        except ValueError:
            # **`xhigh` 가 우리에게 없다.** 조용히 `high` 로 접지 않는다 —
            # 사용자는 더 깊이 생각한다고 믿는데 아니다.
            raise invalid(f"effort '{effort_obj.type}' is not supported") from None
    return handle, effort


def _policy(raw: Any) -> PermissionPolicy:
    if raw is None:
        return PermissionPolicy.ALWAYS_ALLOW
    try:
        return PermissionPolicy(raw.type)
    except ValueError:
        # `auto` 가 여기로 온다 (`plan/04` §6.3).
        raise invalid(f"permission policy '{raw.type}' is not supported") from None


def definition_from(body: AgentIn) -> AgentDefinition:
    """공식 생성 본문 → 우리 `AgentDefinition`."""
    handle, effort = model_handle(body.model)

    toolset = None
    if body.tools:
        if len(body.tools) > 1:
            # 공식은 배열이지만 우리는 툴셋 하나다. **조용히 첫 것만
            # 쓰지 않는다** — 나머지가 무시된 것을 사용자가 모른다.
            raise invalid("only one agent_toolset is supported")
        spec = body.tools[0]
        default = spec.default_config
        toolset = AgentToolset(
            configs=tuple(
                ToolConfig(
                    name=c.name,
                    enabled=c.enabled,
                    permission_policy=_policy(c.permission_policy) if c.permission_policy else None,
                )
                for c in spec.configs
            ),
            default_permission_policy=_policy(default.permission_policy if default else None),
        )

    return AgentDefinition(
        name=body.name,
        model=ModelCardId(handle),
        system=body.system,
        toolset=toolset if toolset is not None else AgentToolset(),
        mcp_servers=tuple(McpServerSpec(name=s.name, url=s.url) for s in body.mcp_servers),
        effort=effort,
        description=body.description,
        metadata=tuple(sorted(body.metadata.items())),
    )


def merged_definition(current: AgentDefinition, body: AgentUpdateIn) -> AgentDefinition:
    """부분 갱신. **`POST` 지만 의미는 머지다** (`ref/api/README.md`)."""
    from dataclasses import replace

    changes: dict[str, Any] = {}
    if body.name is not None:
        changes["name"] = body.name
    if body.model is not None:
        handle, effort = model_handle(body.model)
        changes["model"] = ModelCardId(handle)
        if effort is not None:
            changes["effort"] = effort
    if body.system is not None:
        changes["system"] = body.system
    if body.description is not None:
        changes["description"] = body.description
    if body.mcp_servers is not None:
        changes["mcp_servers"] = tuple(
            McpServerSpec(name=s.name, url=s.url) for s in body.mcp_servers
        )
    if body.metadata is not None:
        changes["metadata"] = tuple(sorted(body.metadata.items()))
    return replace(current, **changes)


def agent_out(rec: AgentRecord) -> dict[str, Any]:
    """우리 레코드 → 공식 shape. **없는 것은 공식 기본값으로 채운다.**

    `multiagent` 가 `None` 인 것이 그 예다 — 우리는 멀티에이전트를
    지원하지 않고, 공식은 그때 `null` 이다.
    """
    d = rec.definition
    toolset = d.toolset or AgentToolset()
    return {
        "type": "agent",
        "id": to_official_id(rec.id),
        "name": d.name,
        "version": rec.version,
        "model": {
            "id": d.model,
            "effort": {"type": d.effort.value} if d.effort else None,
            "inference_geo": None,
            "speed": None,
        },
        "created_at": rec.created_at,
        "updated_at": rec.updated_at,
        "description": d.description,
        "system": d.system,
        "mcp_servers": tuple({"type": "url", "name": s.name, "url": s.url} for s in d.mcp_servers),
        "metadata": dict(d.metadata),
        "skills": (),
        "tools": (
            {
                "type": "agent_toolset_20260401",
                "configs": tuple(
                    {
                        "name": c.name,
                        "enabled": c.enabled,
                        "permission_policy": (
                            {"type": c.permission_policy.value} if c.permission_policy else None
                        ),
                    }
                    for c in toolset.configs
                ),
                "default_config": {
                    "enabled": True,
                    "permission_policy": {"type": toolset.default_permission_policy.value},
                },
            },
        ),
        # **우리는 멀티에이전트를 지원하지 않는다.** 공식은 그때 `null`.
        "multiagent": None,
        "archived_at": rec.archived_at,
    }


# ── 세션 ───────────────────────────────────────────────────
#: 우리 상태 → 공식 상태. **`requires_action` 이 공식에 없다.**
#:
#: 공식 계약에 그 상태가 없으므로 `idle` 로 보낸다 — 거짓말에 가깝지만
#: 모르는 값을 보내면 SDK 가 파싱에 실패한다. 내부 lane 에는 그대로 있다.
_STATUS = {
    "idle": "idle",
    "running": "running",
    "rescheduled": "rescheduled",
    "terminated": "terminated",
}


def session_status(ours: str) -> str:
    return _STATUS.get(ours, "idle")


def _money(cents: int | None) -> dict[str, str]:
    """센트 → 공식 금액. **문자열이다** — 부동소수는 반올림이 갈린다."""
    return {"amount": str(cents or 0), "currency": "USD"}


def session_out(rec: SessionRecord, agent: dict[str, Any]) -> dict[str, Any]:
    """우리 세션 → 공식 shape.

    **`revision`·`stop_reason`·`required_action` 을 싣지 않는다.**
    전부 사내 개념이고, 공식 계약에 자리가 없다. 실으면 '호환'이
    거짓이 된다 — 그리고 그 필드에 의존하는 코드가 생기면 되돌릴 수 없다.
    """
    usage = rec.usage
    return {
        "type": "session",
        "id": to_official_id(rec.id),
        "agent": agent,
        "environment_id": rec.environment_id,
        "status": session_status(rec.status.value),
        "created_at": rec.created_at,
        "updated_at": rec.updated_at,
        "stats": {"active_seconds": 0, "duration_seconds": 0},
        "usage": {
            "active_seconds": 0,
            "cache_creation": {
                "ephemeral_1h_input_tokens": 0,
                "ephemeral_5m_input_tokens": 0,
            },
            "cache_read_input_tokens": usage.input_cache_hit,
            "input_tokens": usage.input_cache_miss,
            "output_tokens": usage.output,
            "list_cost": _money(None),
            "server_tool_use": {"web_fetch_requests": 0, "web_search_requests": 0},
        },
        "metadata": {},
        "vault_ids": tuple(to_official_id(v) for v in rec.vault_ids),
        "resources": (),
        "outcome_evaluations": (),
        "budget": (
            {"type": "limit", "max_list_cost": _money(rec.budget.limit_cents)}
            if rec.budget
            else None
        ),
        "title": None,
        "deployment_id": None,
        "archived_at": rec.archived_at,
    }


def budget_cents(budget: Any) -> int | None:
    """공식 금액 → 센트. **문자열이므로 `Decimal` 로 읽는다.**"""
    if budget is None:
        return None
    try:
        amount = Decimal(budget.max_list_cost.amount)
    except Exception:
        raise invalid("budget.max_list_cost.amount must be a decimal string") from None
    if amount <= 0:
        raise invalid("budget.max_list_cost.amount must be positive")
    return int(amount)


__all__ = [
    "agent_out",
    "budget_cents",
    "definition_from",
    "merged_definition",
    "model_handle",
    "session_out",
    "session_status",
    "to_internal_id",
    "to_official_id",
]
