"""`/v1/sessions` — 공식 shape (T-0605).

`ref/api/sessions/` · `plan/04-api.md` §6.

**사내 개념이 응답에 없다**: `revision`·`stop_reason`·`required_action`.
전부 공식 계약에 자리가 없고, 실으면 '호환'이 거짓이 된다 — 그리고
그 필드에 의존하는 코드가 생기면 되돌릴 수 없다.
"""

from __future__ import annotations

from typing import Annotated, Any

from fastapi import APIRouter, Query, status
from ma_domain.ids import AgentId, EnvironmentId, SessionId, VaultId, WorkspaceId
from ma_domain.sessions import SessionRecord, SessionStatus
from ma_domain.workspaces import Role
from ma_store.sessions import FindSession, InsertSession, ListSessions

from ma_api.compat.beta import Resource
from ma_api.compat.deps import CurrentGraph, CurrentPrincipal, require_beta
from ma_api.compat.errors import invalid, not_found, permission
from ma_api.compat.mappers import (
    agent_out,
    budget_cents,
    session_out,
    to_internal_id,
    to_official_id,
)
from ma_api.compat.schemas import SessionIn, SessionListOut, SessionOut
from ma_api.shared.revalidate import revalidate

router = APIRouter(
    prefix="/v1/sessions",
    tags=["compat:sessions"],
    dependencies=[require_beta(Resource.SESSIONS)],
)


def _require(principal: Any, role: Role) -> None:
    if not principal.role.at_least(role):
        raise permission(f"{role.value} or higher is required")


def _agent_id_of(raw: Any) -> str:
    """`agent` 가 **문자열 또는 객체**다 (`ref/api/sessions/create.md`)."""
    if isinstance(raw, str):
        return to_internal_id(raw)
    if isinstance(raw, dict) and isinstance(raw.get("id"), str):
        return to_internal_id(raw["id"])
    raise invalid("agent must be an agent id or an object with an id")


async def _session_out(graph: Any, rec: SessionRecord) -> dict[str, Any]:
    """세션 하나를 공식 shape 으로. **에이전트를 함께 싣는다.**

    공식은 `agent` 를 **펼쳐서** 준다 (id 하나가 아니다). 세션이
    핀한 버전을 읽어야 한다 — 현재 버전을 실으면 "이 세션이 무엇으로
    돌았나"의 답이 시간에 따라 바뀐다.
    """
    pinned = await graph.agents.get_version(AgentId(rec.agent_id), rec.agent_version)
    agent = agent_out(pinned) if pinned is not None else {"id": to_official_id(rec.agent_id)}
    return session_out(rec, agent)


@router.post("", response_model=SessionOut, status_code=status.HTTP_200_OK)
async def create_session(
    body: SessionIn, graph: CurrentGraph, principal: CurrentPrincipal
) -> dict[str, Any]:
    _require(principal, Role.OPERATOR)

    agent_id = AgentId(_agent_id_of(body.agent))
    agent = await graph.agents.get(agent_id)
    if agent is None:
        raise not_found("Agent", str(body.agent))
    if agent.is_archived:
        raise invalid(f"The agent {agent_id} is archived")

    from ma_domain.sessions import SessionBudget

    limit = budget_cents(body.budget)
    now = graph.clock.now()
    rec = await graph.sessions.insert(
        InsertSession(
            record=SessionRecord(
                id=SessionId(graph.ids.next("session")),
                workspace_id=WorkspaceId(principal.workspace_id),
                agent_id=agent.id,
                # **버전을 핀한다** — 재현성의 근거다 (내부 lane 과 같다).
                agent_version=agent.version,
                environment_id=EnvironmentId(to_internal_id(body.environment_id)),
                environment_version=1,
                status=SessionStatus.IDLE,
                revision=0,
                created_by=principal.id,
                created_at=now,
                updated_at=now,
                budget=SessionBudget(limit_cents=limit) if limit is not None else None,
                vault_ids=tuple(VaultId(to_internal_id(v)) for v in body.vault_ids),
            )
        )
    )
    return revalidate(SessionOut, await _session_out(graph, rec))


@router.get("", response_model=SessionListOut)
async def list_sessions(
    graph: CurrentGraph,
    principal: CurrentPrincipal,
    limit: Annotated[int, Query(ge=1, le=200)] = 50,
    page: str | None = None,
) -> dict[str, Any]:
    _require(principal, Role.VIEWER)
    from ma_api.shared.pagination import decode

    got = await graph.sessions.list_sessions(
        ListSessions(
            workspace_id=WorkspaceId(principal.workspace_id), limit=limit, after=decode(page)
        )
    )
    items = [revalidate(SessionOut, await _session_out(graph, r)) for r in got.items]
    return revalidate(
        SessionListOut,
        {
            "data": tuple(items),
            "next_page": got.next_cursor.encode() if got.next_cursor else None,
        },
    )


@router.get("/{session_id}", response_model=SessionOut)
async def get_session(
    session_id: str, graph: CurrentGraph, principal: CurrentPrincipal
) -> dict[str, Any]:
    _require(principal, Role.VIEWER)
    rec = await graph.sessions.find(
        FindSession(
            workspace_id=WorkspaceId(principal.workspace_id),
            id=SessionId(to_internal_id(session_id)),
        )
    )
    if rec is None:
        raise not_found("Session", session_id)
    return revalidate(SessionOut, await _session_out(graph, rec))


__all__ = ["router"]
