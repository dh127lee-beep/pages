"""`/v1/agents` — 공식 shape (T-0605).

`ref/api/agents/` · `plan/04-api.md` §6.

**수정이 `PATCH` 가 아니라 `POST /v1/agents/{id}` 다** — 공식 규약이다
(`ref/api/README.md`). 우리 내부 lane 은 `PUT` 을 쓰지만 여기서는
공식을 따른다.
"""

from __future__ import annotations

from typing import Annotated, Any

from fastapi import APIRouter, Query, status
from ma_application.agents import (
    AgentArchived,
    AgentConflict,
    AgentCreated,
    AgentInvalid,
    AgentNotFound,
    AgentUpdated,
)
from ma_domain.ids import AgentId
from ma_domain.workspaces import Role

from ma_api.compat.beta import Resource
from ma_api.compat.deps import CurrentGraph, CurrentPrincipal, require_beta
from ma_api.compat.errors import conflict, invalid, not_found, permission
from ma_api.compat.mappers import (
    agent_out,
    definition_from,
    merged_definition,
    to_internal_id,
)
from ma_api.compat.schemas import AgentIn, AgentListOut, AgentOut, AgentUpdateIn
from ma_api.shared.revalidate import revalidate

router = APIRouter(
    prefix="/v1/agents", tags=["compat:agents"], dependencies=[require_beta(Resource.AGENTS)]
)


def _require(principal: Any, role: Role) -> None:
    if not principal.role.at_least(role):
        raise permission(f"{role.value} or higher is required")


@router.post("", response_model=AgentOut, status_code=status.HTTP_200_OK)
async def create_agent(
    body: AgentIn, graph: CurrentGraph, principal: CurrentPrincipal
) -> dict[str, Any]:
    """**201 이 아니라 200 이다** — 공식이 그렇다 (`ref/api/agents/create.md`)."""
    _require(principal, Role.OPERATOR)
    res = await graph.agents.create(
        definition_from(body), created_by=f"{principal.kind}:{principal.id}"
    )
    match res:
        case AgentCreated(agent=rec):
            return revalidate(AgentOut, agent_out(rec))
        case AgentInvalid(reasons=reasons):
            raise invalid("; ".join(reasons))
    raise invalid("unhandled result")  # pragma: no cover


@router.get("", response_model=AgentListOut)
async def list_agents(
    graph: CurrentGraph,
    principal: CurrentPrincipal,
    limit: Annotated[int, Query(ge=1, le=200)] = 50,
    page: str | None = None,
) -> dict[str, Any]:
    """**`has_more` 가 없다.** 공식은 `next_page` 하나만 쓴다."""
    _require(principal, Role.VIEWER)
    got = await graph.agents.list(limit=limit, after=page)
    return revalidate(
        AgentListOut,
        {
            "data": tuple(revalidate(AgentOut, agent_out(r)) for r in got.items),
            "next_page": got.next_cursor.encode() if got.next_cursor else None,
        },
    )


@router.get("/{agent_id}", response_model=AgentOut)
async def get_agent(
    agent_id: str, graph: CurrentGraph, principal: CurrentPrincipal
) -> dict[str, Any]:
    _require(principal, Role.VIEWER)
    rec = await graph.agents.get(AgentId(to_internal_id(agent_id)))
    if rec is None:
        raise not_found("Agent", agent_id)
    return revalidate(AgentOut, agent_out(rec))


@router.post("/{agent_id}", response_model=AgentOut)
async def update_agent(
    agent_id: str, body: AgentUpdateIn, graph: CurrentGraph, principal: CurrentPrincipal
) -> dict[str, Any]:
    """**부분 갱신이다.** 공식은 `POST` 로 머지한다.

    버전을 본문으로 받지 않는 이유: 공식 계약에 그 자리가 없다. 우리
    내부 lane 은 CAS 를 요구하지만, 여기서는 **읽고 바로 쓴다** —
    경합하면 마지막 쓰기가 이긴다. 공식과 같은 동작이다.
    """
    _require(principal, Role.OPERATOR)
    internal = AgentId(to_internal_id(agent_id))
    current = await graph.agents.get(internal)
    if current is None:
        raise not_found("Agent", agent_id)

    res = await graph.agents.update(
        internal,
        merged_definition(current.definition, body),
        expected_version=current.version,
    )
    match res:
        case AgentUpdated(agent=rec):
            return revalidate(AgentOut, agent_out(rec))
        case AgentInvalid(reasons=reasons):
            raise invalid("; ".join(reasons))
        case AgentConflict():
            # **공식 envelope 에 `actual_version` 자리가 없다.** 싣지
            # 않는다 — 실으면 '필드 추가 금지'가 깨진다.
            raise conflict("The agent was modified concurrently. Retry the request.")
        case AgentNotFound():
            raise not_found("Agent", agent_id)
    raise invalid("unhandled result")  # pragma: no cover


@router.post("/{agent_id}/archive", response_model=AgentOut)
async def archive_agent(
    agent_id: str, graph: CurrentGraph, principal: CurrentPrincipal
) -> dict[str, Any]:
    """**소프트 삭제.** 조회는 되지만 새 세션을 못 연다."""
    _require(principal, Role.ADMIN)
    internal = AgentId(to_internal_id(agent_id))
    current = await graph.agents.get(internal)
    if current is None:
        raise not_found("Agent", agent_id)

    res = await graph.agents.archive(internal, expected_version=current.version)
    match res:
        case AgentArchived(agent=rec):
            return revalidate(AgentOut, agent_out(rec))
        case AgentConflict():
            raise conflict("The agent was modified concurrently. Retry the request.")
        case AgentNotFound():
            raise not_found("Agent", agent_id)
    raise invalid("unhandled result")  # pragma: no cover


__all__ = ["router"]
