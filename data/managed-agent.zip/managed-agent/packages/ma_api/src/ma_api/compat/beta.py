"""beta 헤더 게이트 — **리소스별**이다 (T-0605).

`plan/04-api.md` §6.1 · `ref/api/README.md`.

전역 게이트가 아닌 이유: 공식은 리소스마다 다른 beta 를 요구한다.
전역으로 하나만 보면 Dreams 전용 키를 가진 클라이언트가 Agents 를
부를 수 있게 되고, 그것은 **우리가 공식보다 느슨하다**는 뜻이다.

헤더는 **쉼표로 여럿** 올 수 있다 (`anthropic-beta: a,b`). 공식 SDK 가
그렇게 보낸다.
"""

from __future__ import annotations

from enum import StrEnum

#: Managed Agents 공통.
MANAGED_AGENTS_BETA = "managed-agents-2026-04-01"
#: Dreams 전용.
DREAMING_BETA = "dreaming-2026-04-21"
#: Tunnels 전용 (research preview).
MCP_TUNNELS_BETA = "mcp-tunnels-2026-06-22"

#: 필수 버전 헤더. 공식이 `2023-06-01` 하나만 받는다.
ANTHROPIC_VERSION = "2023-06-01"


class Resource(StrEnum):
    """게이트가 붙는 단위. **엔드포인트가 아니라 리소스다.**"""

    AGENTS = "agents"
    SESSIONS = "sessions"
    ENVIRONMENTS = "environments"
    VAULTS = "vaults"
    MEMORY_STORES = "memory_stores"
    DEPLOYMENTS = "deployments"
    DREAMS = "dreams"
    TUNNELS = "tunnels"


#: 리소스 → 요구하는 beta.
REQUIRED: dict[Resource, str] = {
    Resource.AGENTS: MANAGED_AGENTS_BETA,
    Resource.SESSIONS: MANAGED_AGENTS_BETA,
    Resource.ENVIRONMENTS: MANAGED_AGENTS_BETA,
    Resource.VAULTS: MANAGED_AGENTS_BETA,
    Resource.MEMORY_STORES: MANAGED_AGENTS_BETA,
    Resource.DEPLOYMENTS: MANAGED_AGENTS_BETA,
    Resource.DREAMS: DREAMING_BETA,
    Resource.TUNNELS: MCP_TUNNELS_BETA,
}

#: 우리가 **구현하지 않는** 리소스. 404 를 낸다 (`plan/04` §6.2).
#:
#: 400 이 아닌 이유: 공식에는 있는 경로이므로 "요청이 틀렸다"가 아니라
#: "여기에는 없다"가 사실이다. 그리고 404 면 SDK 가 기능 탐지를 할 수 있다.
UNSUPPORTED = frozenset({Resource.DREAMS, Resource.TUNNELS})


def parse_betas(header: str | None) -> frozenset[str]:
    """`anthropic-beta` 헤더 → 집합. **쉼표로 여럿** 올 수 있다."""
    if not header:
        return frozenset()
    return frozenset(part.strip() for part in header.split(",") if part.strip())


def missing_beta(resource: Resource, header: str | None) -> str | None:
    """없으면 **요구하는 beta 이름**을 돌려준다. 있으면 `None`."""
    needed = REQUIRED[resource]
    return None if needed in parse_betas(header) else needed


__all__ = [
    "ANTHROPIC_VERSION",
    "DREAMING_BETA",
    "MANAGED_AGENTS_BETA",
    "MCP_TUNNELS_BETA",
    "REQUIRED",
    "UNSUPPORTED",
    "Resource",
    "missing_beta",
    "parse_betas",
]
