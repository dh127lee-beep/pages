"""미지원 리소스 — **명확한 에러** (T-0605).

`plan/04-api.md` §6.2.

| 리소스 | 왜 없는가 | 무엇을 내는가 |
|---|---|---|
| Dreams | 3단계 | `not_found_error` |
| Tunnels | research preview, 미지원 | `not_found_error` |

**404 를 내는 이유.** 400 은 "요청이 틀렸다"인데 요청은 멀쩡하다 —
공식에 있는 경로를 공식 모양으로 불렀다. 404 면 SDK 가 **기능 탐지**를
할 수 있다: 있으면 쓰고 없으면 우회한다.

조용히 빈 목록을 돌려주지 않는 이유가 더 중요하다. 빈 목록은 "없다"로
읽히고, 사용자는 **만들었는데 사라졌다**고 생각한다.
"""

from __future__ import annotations

from fastapi import APIRouter

from ma_api.compat.errors import unsupported

router = APIRouter(tags=["compat:unsupported"])

#: 경로 접두 → 사람이 읽을 이름.
UNSUPPORTED_PATHS = {
    "/v1/dreams": "Dreams",
    "/v1/tunnels": "Tunnels",
}


@router.api_route(
    "/v1/dreams/{rest:path}", methods=["GET", "POST", "DELETE"], include_in_schema=False
)
@router.api_route("/v1/dreams", methods=["GET", "POST"], include_in_schema=False)
async def dreams(rest: str = "") -> None:
    """3단계. **그전에는 404 다** (`plan/04` §6.2)."""
    raise unsupported("Dreams")


@router.api_route(
    "/v1/tunnels/{rest:path}", methods=["GET", "POST", "DELETE"], include_in_schema=False
)
@router.api_route("/v1/tunnels", methods=["GET", "POST"], include_in_schema=False)
async def tunnels(rest: str = "") -> None:
    """공식도 research preview 다. **우리는 안 한다.**"""
    raise unsupported("Tunnels")


__all__ = ["UNSUPPORTED_PATHS", "router"]
