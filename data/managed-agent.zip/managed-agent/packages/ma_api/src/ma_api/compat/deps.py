"""공식 lane 의 요청 컨텍스트 — **`internal.deps` 와 별개다** (D9).

`plan/04-api.md` §6 · `plan/09-codebase.md` §5.

미들웨어가 채우는 `request.state` 는 같은 것을 본다 (인증은 한 벌이다).
다른 것은 **에러 모양**이다 — 공식 lane 은 공식 envelope 을 쓰므로
`internal.deps` 의 `unauthenticated()` 를 쓸 수 없다.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Annotated, Any

from fastapi import Depends, Header, Request

from ma_api.compat.beta import Resource, missing_beta
from ma_api.compat.errors import beta_required, unauthenticated

if TYPE_CHECKING:
    from ma_auth.principal import Principal


def get_principal(request: Request) -> Principal:
    principal = getattr(request.state, "principal", None)
    if principal is None:
        raise unauthenticated()
    return principal  # type: ignore[no-any-return]


def get_graph(request: Request) -> Any:
    graph = getattr(request.state, "graph", None)
    if graph is None:  # pragma: no cover — 미들웨어가 항상 채운다
        raise unauthenticated()
    return graph


def require_beta(resource: Resource) -> Any:
    """리소스별 beta 게이트. **전역이 아니다** (`plan/04` §6.1 ②).

    전역으로 하나만 보면 Dreams 전용 키를 가진 클라이언트가 Agents 를
    부를 수 있게 되고, 그것은 우리가 **공식보다 느슨하다**는 뜻이다.
    """

    def check(
        anthropic_beta: Annotated[str | None, Header(alias="anthropic-beta")] = None,
    ) -> None:
        needed = missing_beta(resource, anthropic_beta)
        if needed is not None:
            raise beta_required(needed)

    return Depends(check)


CurrentPrincipal = Annotated["Principal", Depends(get_principal)]
CurrentGraph = Annotated[Any, Depends(get_graph)]

__all__ = [
    "CurrentGraph",
    "CurrentPrincipal",
    "get_graph",
    "get_principal",
    "require_beta",
]
