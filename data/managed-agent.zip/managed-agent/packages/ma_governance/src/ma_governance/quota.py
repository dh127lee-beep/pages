"""쿼터 — 동시 실행 세션과 일일 생성 수.

`plan/04-api.md` §7 · `task/M3-security-governance/T-0405-budget-usage.md`.

예산은 **돈**을 막고 쿼터는 **수**를 막는다. 둘 다 필요한 이유: 돈이
남아도 세션 1000개가 동시에 뜨면 워커가 무너지고, 세션이 한 개여도
그것이 비싸면 예산이 난다.

> **초과는 409 다** (429 아님). 재시도해도 안 되는 것이다 — 동시 상한은
> 다른 세션이 끝나야 풀리고, 일일 상한은 날이 바뀌어야 풀린다.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime
from enum import StrEnum


class QuotaKind(StrEnum):
    CONCURRENT_SESSIONS = "concurrent_sessions"
    DAILY_SESSIONS = "daily_sessions"
    #: 업로드 **개수** 상한 (T-0502). 작은 파일을 무한히 올리는 것을 막는다.
    DAILY_UPLOAD_COUNT = "daily_upload_count"
    #: 업로드 **바이트** 상한. 개수만 막으면 100MB 짜리 50개가 통과한다.
    DAILY_UPLOAD_BYTES = "daily_upload_bytes"


#: 기본 상한. **워크스페이스가 올릴 수 있지만 기본이 무한이면 안 된다.**
DEFAULT_LIMITS: dict[QuotaKind, int] = {
    QuotaKind.CONCURRENT_SESSIONS: 20,
    QuotaKind.DAILY_SESSIONS: 500,
    QuotaKind.DAILY_UPLOAD_COUNT: 1_000,
    # 20GB/일. 100MB 짜리 200개 — 한 부서가 하루에 쓸 양을 넘는다.
    QuotaKind.DAILY_UPLOAD_BYTES: 20 * 1024 * 1024 * 1024,
}


@dataclass(frozen=True, slots=True)
class QuotaCheck:
    kind: QuotaKind
    limit: int
    used: int

    #: 이번에 더할 양. 세션은 1, 업로드 바이트는 파일 크기다.
    increment: int = 1

    @property
    def ok(self) -> bool:
        """**더한 뒤에도 상한 이하인가.**

        `used < limit` 만 보면 20GB 상한에 19.9GB 를 쓴 뒤 100MB 를
        올릴 수 있다. 세션 카운터는 `increment=1` 이라 기존과 같다.
        """
        return self.used + self.increment <= self.limit

    @property
    def message(self) -> str:
        label = {
            QuotaKind.CONCURRENT_SESSIONS: "동시 실행 세션",
            QuotaKind.DAILY_SESSIONS: "일일 세션 생성",
            QuotaKind.DAILY_UPLOAD_COUNT: "일일 업로드 개수",
            QuotaKind.DAILY_UPLOAD_BYTES: "일일 업로드 바이트",
        }[self.kind]
        return f"{label} 상한에 도달했다 ({self.used + self.increment}/{self.limit})"


def window_for(kind: QuotaKind, now: datetime) -> date:
    """카운터의 창.

    `concurrent_sessions` 는 **창이 없다** — 지금 몇 개가 도는가다.
    그래도 같은 테이블을 쓰려고 고정 날짜를 준다 (에포크). 날짜별로
    쪼개면 자정에 카운터가 0 이 되어 상한이 사라진다.
    """
    if kind is QuotaKind.CONCURRENT_SESSIONS:
        return date(1970, 1, 1)
    return now.date()


#: 업로드 쿼터 두 가지. **둘 다 봐야 한다** — 개수만 막으면 큰 파일로,
#: 바이트만 막으면 작은 파일 수십만 개로 빠져나간다.
UPLOAD_KINDS = (QuotaKind.DAILY_UPLOAD_COUNT, QuotaKind.DAILY_UPLOAD_BYTES)


def check(
    kind: QuotaKind, *, used: int, limit: int | None = None, increment: int = 1
) -> QuotaCheck:
    return QuotaCheck(
        kind=kind,
        limit=limit if limit is not None else DEFAULT_LIMITS[kind],
        used=used,
        increment=increment,
    )


__all__ = [
    "DEFAULT_LIMITS",
    "UPLOAD_KINDS",
    "QuotaCheck",
    "QuotaKind",
    "check",
    "window_for",
]
