"""승인 정책 해석 — **누가 승인할 수 있는가** (D8).

`plan/02-architecture.md` §7 · `plan/05-database.md` §3 G10 ·
`task/M3-security-governance/T-0403-approval-workflow.md` · `IMPL-0022`.

메커니즘은 T-0305 가 만들었다: `always_ask` 툴은 실행 함수 없이 등록되고,
모델이 그것을 부르면 턴이 `requires_action` 으로 끊긴다. **에이전트는
"승인이 필요하다"를 배우지 않는다** — 실행할 수 없는 툴을 호출했을 뿐이다.

여기서 얹는 것은 **정책**이다.

```
approval_policies
  tool_pattern        'bash' · 'mcp__github__*' · '*'
  required_role       viewer | operator | admin | owner
  required_approvals  1 (기본) · 2 (4-eyes)
  self_approval       본인이 올린 세션을 본인이 승인할 수 있는가 (기본 false)
  priority            높은 것이 이긴다
```

> **fail-closed.** 정책을 못 읽거나, 맞는 정책이 없거나, 판단이 애매하면
> **열지 않는다.** `ApprovalOutcome.UNAVAILABLE` 이 그 값이고, `permits`
> 가 False 다.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import timedelta
from enum import StrEnum
from typing import TYPE_CHECKING

from ma_domain.governance import ApprovalPolicy, ApprovalState
from ma_domain.workspaces import Role

if TYPE_CHECKING:
    from collections.abc import Sequence
    from datetime import datetime

    from ma_domain.governance import Approval
    from ma_domain.ids import AgentId, UserId

#: 맞는 정책이 하나도 없을 때 쓰는 것. **가장 보수적인 값이다.**
#:
#: "정책이 없으니 아무나"가 아니다 — 정책을 안 만든 워크스페이스에서
#: `always_ask` 툴이 나오면 **admin 이 승인해야** 한다. 느슨하게 하려면
#: 명시적으로 정책을 만들어야 하고, 그 행위가 곧 기록이다.
DEFAULT_ROLE = Role.ADMIN
DEFAULT_REQUIRED_APPROVALS = 1
DEFAULT_SELF_APPROVAL = False

#: 기본 만료. 응답이 없으면 자동 거부된다.
#:
#: 무한 대기를 기본값으로 두면 세션이 영영 `requires_action` 에 남고,
#: 그 세션이 잡고 있는 자원(샌드박스·워크스페이스 디스크)도 함께 남는다.
DEFAULT_EXPIRES_AFTER = timedelta(hours=24)


class Refusal(StrEnum):
    """왜 승인할 수 없는가. **감사에 그대로 들어간다.**"""

    ROLE_TOO_LOW = "role_too_low"
    #: 본인이 올린 세션을 본인이 승인하려 했다.
    SELF_APPROVAL = "self_approval"
    #: 같은 사람이 두 번 승인하려 했다 (4-eyes 를 혼자 채울 수 없다).
    ALREADY_DECIDED_BY_YOU = "already_decided_by_you"
    NOT_PENDING = "not_pending"
    EXPIRED = "expired"


@dataclass(frozen=True, slots=True)
class Resolved:
    """이 툴 호출에 적용되는 정책. **정책 행이 없어도 값이 있다.**"""

    required_role: Role
    required_approvals: int
    self_approval: bool
    expires_after: timedelta | None
    policy_id: str | None = None
    notify: tuple[tuple[str, str], ...] = ()

    def expires_at(self, requested_at: datetime) -> datetime | None:
        return None if self.expires_after is None else requested_at + self.expires_after


@dataclass(frozen=True, slots=True)
class MayDecide:
    allowed: bool
    refusal: Refusal | None = None

    def __bool__(self) -> bool:
        return self.allowed


def resolve(
    policies: Sequence[ApprovalPolicy],
    *,
    tool_name: str,
    agent_id: AgentId | None = None,
) -> Resolved:
    """어느 정책이 이기는가.

    **우선순위 규칙** (`IMPL-0022`):

    1. `agent_id` 가 맞는 정책이 워크스페이스 전체 정책을 이긴다
    2. 그다음 `priority` 가 높은 것
    3. 그다음 **더 구체적인 패턴** — `mcp__github__*` 이 `*` 를 이긴다
    4. 그래도 같으면 **더 엄격한 것** (높은 역할 · 많은 승인 수)

    4번이 중요하다. 동률일 때 임의로 고르면 같은 입력에 다른 답이 나오고,
    그 차이가 보안 경계다. **동률이면 조이는 쪽**으로 간다.
    """
    matching = [p for p in policies if p.matches(tool_name)]
    if agent_id is not None:
        scoped = [p for p in matching if p.agent_id == agent_id]
        matching = scoped or [p for p in matching if p.agent_id is None]
    else:
        matching = [p for p in matching if p.agent_id is None]

    if not matching:
        return Resolved(
            required_role=DEFAULT_ROLE,
            required_approvals=DEFAULT_REQUIRED_APPROVALS,
            self_approval=DEFAULT_SELF_APPROVAL,
            expires_after=DEFAULT_EXPIRES_AFTER,
        )

    best = max(matching, key=_rank)
    return Resolved(
        required_role=best.required_role,
        required_approvals=best.required_approvals,
        self_approval=best.self_approval,
        expires_after=(
            None
            if best.expires_after_seconds is None
            else timedelta(seconds=best.expires_after_seconds)
        ),
        policy_id=best.id,
        notify=best.notify,
    )


def _rank(policy: ApprovalPolicy) -> tuple[int, int, int, int, int]:
    """정렬 키. **큰 것이 이긴다.**

    마지막 둘이 "동률이면 조이는 쪽" 이다.
    """
    return (
        policy.priority,
        _specificity(policy.tool_pattern),
        _ROLE_ORDER.get(policy.required_role, 0),
        policy.required_approvals,
        0 if policy.self_approval else 1,
    )


#: 역할의 엄격함. `Role.at_least` 와 같은 순서여야 한다.
_ROLE_ORDER = {Role.VIEWER: 0, Role.OPERATOR: 1, Role.ADMIN: 2, Role.OWNER: 3}


def _specificity(pattern: str) -> int:
    """패턴이 얼마나 구체적인가. `*` 가 가장 낮다."""
    if pattern == "*":
        return 0
    if pattern.endswith("*"):
        return len(pattern)  # 접두사가 길수록 구체적
    return 10_000  # 정확 일치가 늘 이긴다


def may_decide(
    approval: Approval,
    resolved: Resolved,
    *,
    actor: UserId,
    actor_role: Role,
    session_owner: UserId | None,
    now: datetime,
) -> MayDecide:
    """이 사람이 이 승인을 결정할 수 있는가. **fail-closed.**

    순서가 의미를 가진다 — 상태를 먼저 본다. 만료된 건에 대해
    "권한이 없다"고 답하면, 권한을 올려서 다시 시도하게 된다.
    """
    if approval.is_expired(now):
        return MayDecide(False, Refusal.EXPIRED)
    if approval.state is not ApprovalState.PENDING:
        return MayDecide(False, Refusal.NOT_PENDING)
    if not actor_role.at_least(resolved.required_role):
        return MayDecide(False, Refusal.ROLE_TOO_LOW)
    if not resolved.self_approval and session_owner is not None and actor == session_owner:
        return MayDecide(False, Refusal.SELF_APPROVAL)
    if actor in approval.decided_by:
        # **4-eyes 를 혼자 채울 수 없다.** 두 번 눌러 2를 만들면
        # `required_approvals=2` 가 의미를 잃는다.
        return MayDecide(False, Refusal.ALREADY_DECIDED_BY_YOU)
    return MayDecide(True)


def is_satisfied(approval: Approval, resolved: Resolved) -> bool:
    """승인 수가 찼는가. `required_approvals=2` 면 둘이 눌러야 한다."""
    return len(approval.decided_by) >= resolved.required_approvals


def denial_message(reason: str | None) -> str:
    """거부를 모델에게 돌려줄 `tool_result` 내용.

    **턴을 죽이지 않는다** — 모델이 다른 방법을 찾거나 사용자에게 설명할
    수 있어야 한다 (`plan/02` §7 ⑤).

    사유를 그대로 싣는 이유: 승인자가 쓴 말이고, 그것이 모델에게 가장
    쓸모 있는 정보다. 비밀이 섞일 수 있지만 그것은 **승인자가 쓴 것**이지
    우리가 샌 것이 아니다.
    """
    return f"Denied: {reason}" if reason else "Denied"


__all__ = [
    "DEFAULT_EXPIRES_AFTER",
    "DEFAULT_REQUIRED_APPROVALS",
    "DEFAULT_ROLE",
    "DEFAULT_SELF_APPROVAL",
    "MayDecide",
    "Refusal",
    "Resolved",
    "denial_message",
    "is_satisfied",
    "may_decide",
    "resolve",
]
