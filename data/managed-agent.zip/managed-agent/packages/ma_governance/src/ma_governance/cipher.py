"""자격증명 암호화 — AES-256-GCM + HKDF 파생.

`plan/05-database.md` §7 · `plan/03-layers.md` §3 L2 ·
`task/M3-security-governance/T-0401-vault-credentials.md`.

```
루트 시크릿 (제어 평면만 안다)
   └── HKDF-SHA256(root, info=b"<레이블>", salt=b"awp/v1", length=32)
        └── AES-256-GCM 키  ← key_version 마다 다르다
```

**cipher 는 Port 가 아니라 생성자 인자다** (`plan/03` §3 L2). Port 그래프에
들어가면 어떤 유스케이스가 평문을 만질 수 있는지 추적할 수 없게 된다. Store
구현이 생성자로 받고, 주입은 `ma_platform` 조립 시점에만 일어난다.

## 로테이션

새 자격증명은 **현재 버전**으로 쓰고, 기존 것은 저장된 `key_version` 으로
복호화한다. 두 경로가 분리돼 있으므로 버전을 올리는 순간 서비스가 끊기지
않는다 — 백그라운드 작업이 점진적으로 재암호화한다.

## AAD 로 묶는 것

암호문에 `(workspace_id, credential_id)` 를 **추가 인증 데이터**로 묶는다.
묶지 않으면 DB 쓰기 권한이 있는 사람이 **한 워크스페이스의 암호문을 다른
워크스페이스 행에 복사**해 넣을 수 있고, 복호화가 성공한다. 묶으면 그
시도가 복호화 실패로 끝난다.
"""

from __future__ import annotations

from dataclasses import dataclass

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

#: AES-256.
KEY_BYTES = 32

#: GCM 권장 nonce 길이. **재사용하면 키가 깨진다** — 매번 새로 뽑는다.
NONCE_BYTES = 12

#: 루트 시크릿 최소 길이. 짧으면 파생 키의 엔트로피가 그만큼이다.
MIN_ROOT_BYTES = 32

#: HKDF salt. 고정값이어도 된다 — salt 의 역할은 도메인 분리이고,
#: 비밀은 `root` 가 들고 있다.
HKDF_SALT = b"awp/v1"

#: 파생 레이블. **대상마다 다른 레이블을 쓴다** (`IMPL-0020`).
#:
#: 한 레이블을 여러 대상이 공유하면, 한 곳의 암호문을 다른 곳에 옮겨도
#: 복호화가 된다. 레이블이 다르면 키가 다르므로 그 이동이 막힌다.
LABEL_CREDENTIAL = "credential"
LABEL_ENVIRONMENT_WORK = "environment_work"

KNOWN_LABELS = frozenset({LABEL_CREDENTIAL, LABEL_ENVIRONMENT_WORK})


class CipherError(Exception):
    """암복호화가 실패했다. **메시지에 평문도 암호문도 넣지 않는다.**"""


class RootSecretTooShort(ValueError):
    pass


@dataclass(frozen=True, slots=True)
class Sealed:
    """저장되는 모양. **평문이 없다.**"""

    ciphertext: bytes
    nonce: bytes
    key_version: int


def derive_key(root: bytes, label: str, key_version: int) -> bytes:
    """`HKDF(root, "<레이블>", key_version)`.

    `key_version` 을 `info` 에 넣는 것이 로테이션의 전부다 — 버전이 다르면
    키가 다르고, 옛 암호문은 옛 버전으로만 열린다.
    """
    if len(root) < MIN_ROOT_BYTES:
        raise RootSecretTooShort(
            f"루트 시크릿이 {MIN_ROOT_BYTES}바이트보다 짧다 ({len(root)}바이트)"
        )
    if key_version < 1:
        raise ValueError(f"key_version 은 1 이상이어야 한다: {key_version}")
    return HKDF(
        algorithm=hashes.SHA256(),
        length=KEY_BYTES,
        salt=HKDF_SALT,
        info=f"{label}/v{key_version}".encode(),
    ).derive(root)


@dataclass
class CredentialCipher:
    """한 레이블에 대한 암복호화기.

    **루트 시크릿을 들고 있다.** 그래서 이 객체가 사는 프로세스가 곧
    "평문을 만들 수 있는 프로세스"다 — 제어 평면만이다 (`plan/05` §7).
    워커와 프록시는 파생 키나 대행 호출만 쓴다.
    """

    root: bytes
    label: str = LABEL_CREDENTIAL
    #: 새로 쓸 때 쓰는 버전. 로테이션은 이것을 올린다.
    current_version: int = 1

    def __post_init__(self) -> None:
        if len(self.root) < MIN_ROOT_BYTES:
            raise RootSecretTooShort(
                f"루트 시크릿이 {MIN_ROOT_BYTES}바이트보다 짧다 ({len(self.root)}바이트)"
            )
        if self.label not in KNOWN_LABELS:
            # 오타 하나가 **조용히 다른 키 공간**을 만든다. 그러면 그 자격증명은
            # 영영 열리지 않고, 원인은 레이블 문자열 하나다.
            raise ValueError(f"모르는 파생 레이블이다: {self.label!r} — {sorted(KNOWN_LABELS)}")

    def seal(self, plaintext: str, *, aad: bytes) -> Sealed:
        """암호화한다. **현재 버전으로.**

        `aad` 는 `associated_data()` 가 만든다 — 호출자가 직접 조립하면
        쓰기와 읽기가 다른 값을 쓰게 될 수 있다.
        """
        import os

        key = derive_key(self.root, self.label, self.current_version)
        nonce = os.urandom(NONCE_BYTES)  # awp-env-ok — 환경변수가 아니라 난수다
        ciphertext = AESGCM(key).encrypt(nonce, plaintext.encode("utf-8"), aad)
        return Sealed(ciphertext=ciphertext, nonce=nonce, key_version=self.current_version)

    def open(self, sealed: Sealed, *, aad: bytes) -> str:
        """복호화한다. **저장된 버전으로** — 현재 버전이 아니다.

        이 한 줄이 로테이션을 가능하게 한다. 현재 버전으로 열려고 하면
        버전을 올리는 순간 기존 자격증명이 전부 죽는다.
        """
        key = derive_key(self.root, self.label, sealed.key_version)
        try:
            raw = AESGCM(key).decrypt(sealed.nonce, sealed.ciphertext, aad)
        except InvalidTag as exc:
            # **메시지에 아무것도 싣지 않는다.** 복호화 실패의 원인(틀린 키 /
            # 변조된 암호문 / 틀린 AAD)을 구분해 주면 공격자에게 정보가 된다.
            raise CipherError("복호화 실패") from exc
        return raw.decode("utf-8")

    def needs_rewrap(self, sealed: Sealed) -> bool:
        """재암호화 대상인가. 백그라운드 작업이 이것으로 고른다."""
        return sealed.key_version < self.current_version

    def rewrap(self, sealed: Sealed, *, aad: bytes) -> Sealed:
        """옛 키로 열어 새 키로 다시 봉한다. **평문이 메모리에만 있다.**"""
        return self.seal(self.open(sealed, aad=aad), aad=aad)

    def rotated(self) -> CredentialCipher:
        """버전을 하나 올린 새 cipher. **원본을 바꾸지 않는다.**

        제자리에서 바꾸면 같은 객체를 들고 있는 다른 곳이 조용히 영향을
        받는다 — 그중 하나가 지금 복호화 중일 수 있다.
        """
        from dataclasses import replace

        return replace(self, current_version=self.current_version + 1)


def associated_data(workspace_id: str, credential_id: str) -> bytes:
    """암호문을 **그 행에** 묶는 값.

    DB 쓰기 권한이 있는 사람이 한 워크스페이스의 암호문을 다른 워크스페이스
    행에 복사해 넣어도 복호화가 실패하게 한다.

    구분자가 필요하다: `("a", "bc")` 와 `("ab", "c")` 가 같은 바이트가 되면
    두 행이 서로의 암호문을 받아들인다.
    """
    return f"{workspace_id}\x1f{credential_id}".encode()


@dataclass(frozen=True, slots=True)
class CipherBundle:
    """조립이 주입하는 묶음. `ma_platform.build_sql_app(ciphers=...)`."""

    credential: CredentialCipher
    environment_work: CredentialCipher

    @classmethod
    def from_root(cls, root: bytes, *, key_version: int = 1) -> CipherBundle:
        """**루트 하나에서 레이블별로 갈라진다.**

        파생이 레이블로 갈리므로, 한쪽 암호문을 다른 쪽에 옮겨도 열리지
        않는다. 루트를 둘로 나눠 관리하는 것보다 운영이 단순하다.
        """
        return cls(
            credential=CredentialCipher(
                root=root, label=LABEL_CREDENTIAL, current_version=key_version
            ),
            environment_work=CredentialCipher(
                root=root, label=LABEL_ENVIRONMENT_WORK, current_version=key_version
            ),
        )


__all__ = [
    "HKDF_SALT",
    "KEY_BYTES",
    "KNOWN_LABELS",
    "LABEL_CREDENTIAL",
    "LABEL_ENVIRONMENT_WORK",
    "MIN_ROOT_BYTES",
    "NONCE_BYTES",
    "CipherBundle",
    "CipherError",
    "CredentialCipher",
    "RootSecretTooShort",
    "Sealed",
    "associated_data",
    "derive_key",
]
