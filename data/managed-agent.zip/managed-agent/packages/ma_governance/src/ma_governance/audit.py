"""감사 기록 — **append-only 이고, 실패하면 작업도 실패한다**.

`plan/05-database.md` §3 G10 · `ADR-0011` ·
`task/M3-security-governance/T-0404-audit-log.md`.

> **기록 없는 실행을 허용하지 않는다.** 감사 기록이 실패하면 그 작업도
> 실패한다 (`ADR-0011`). 성공 기준이 "임의의 세션에 대해 어떤 명령이 어떤
> 승인으로 실행됐는지를 재구성"인데, 구멍이 하나라도 있으면 그 재구성이
> 거짓이 된다.

이것이 `ma_egress.CredentialAudit` 과 **반대 방향**인 것에 주의한다.
거기서는 적립 실패가 egress 를 막지 않는다 — DB 가 느릴 때 외부 호출
전체가 멈추면 안 되기 때문이다. 여기서는 막는다. 차이는 "그 작업이
무엇인가"다: egress 는 이미 허가된 요청의 **기록**이고, 여기서 기록하는
것은 **허가 자체**다.

## action 어휘

문자열이지만 **아무 문자열이나 쓰지 않는다.** `ACTIONS` 에 없는 값은
`record()` 가 거부한다 — 오타 하나가 감사 조회에서 조용히 빠지는 행을
만든다.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Final

from ma_domain.governance import ActorKind, AuditEntry

if TYPE_CHECKING:
    from ma_domain.clock import Clock
    from ma_domain.ids import SessionId, WorkspaceId
    from ma_store.governance import AuditStore

#: 기록하는 행위. **닫힌 집합이다.**
#:
#: `resource_type` 과 짝이 되는 접두사를 쓴다 (`agent.*` 는 `agent` 를
#: 건드린다). 조회가 접두사로 필터링하므로 그 규칙이 깨지면 필터가
#: 엉뚱한 것을 집는다.
ACTIONS: Final[frozenset[str]] = frozenset(
    {
        # 에이전트·환경 설정
        "agent.create",
        "agent.update",
        "agent.archive",
        "environment.create",
        "environment.update",
        # 세션
        "session.create",
        "session.interrupt",
        "session.cancel",
        "session.resume",
        # 승인 (D8)
        "approval.ask",
        "approval.decide",
        "approval.expire",
        # 자격증명 (D5)
        "credential.create",
        "credential.rotate",
        "credential.archive",
        "credential.inject",
        "credential.deny",
        "vault.create",
        "vault.archive",
        # 예산·쿼터
        "budget.set",
        "budget.exceeded",
        # 접근
        "apikey.create",
        "apikey.revoke",
        "member.add",
        "member.remove",
    }
)


class UnknownAction(ValueError):
    """`ACTIONS` 에 없는 행위. **오타가 감사 구멍을 만든다.**"""


class AuditFailed(RuntimeError):
    """감사 기록이 실패했다. **작업도 실패해야 한다** (`ADR-0011`)."""


@dataclass(frozen=True, slots=True)
class Actor:
    kind: ActorKind
    id: str

    @classmethod
    def user(cls, user_id: str) -> Actor:
        return cls(kind=ActorKind.USER, id=user_id)

    @classmethod
    def system(cls, name: str = "awp") -> Actor:
        """스케줄러·만료 스윕처럼 **사람이 없는** 행위."""
        return cls(kind=ActorKind.SYSTEM, id=name)

    @classmethod
    def agent(cls, session_id: str) -> Actor:
        """에이전트가 한 일. **세션 id 가 주체다** — 모델은 주체가 아니다."""
        return cls(kind=ActorKind.AGENT, id=session_id)


@dataclass
class Auditor:
    """유스케이스가 쓰는 창구. **실패를 삼키지 않는다.**"""

    store: AuditStore
    clock: Clock

    async def record(
        self,
        *,
        workspace_id: WorkspaceId,
        actor: Actor,
        action: str,
        resource_type: str,
        resource_id: str,
        session_id: SessionId | None = None,
        detail: tuple[tuple[str, object], ...] = (),
        request_id: str | None = None,
    ) -> None:
        """한 줄 남긴다. **실패하면 `AuditFailed` 를 올린다.**

        호출자가 잡아서 무시하면 그것은 호출자의 선택이고, 그 선택이
        코드에 보인다 — 조용히 삼키는 것과 다르다.
        """
        if action not in ACTIONS:
            raise UnknownAction(
                f"모르는 action: {action!r} — ma_governance.audit.ACTIONS 에 추가하십시오"
            )
        try:
            await self.store.append(
                AuditEntry(
                    workspace_id=workspace_id,
                    actor_kind=actor.kind,
                    actor_id=actor.id,
                    action=action,
                    resource_type=resource_type,
                    resource_id=resource_id,
                    created_at=self.clock.now(),
                    session_id=session_id,
                    detail=redact(detail),
                    request_id=request_id,
                )
            )
        except Exception as exc:
            raise AuditFailed(f"감사 기록 실패 action={action}") from exc


#: `detail` 에 들어오면 가릴 키. **감사가 비밀 유출 경로가 되면 안 된다.**
#:
#: 감사는 "무엇을 했는가"를 남기지 "무엇으로 했는가"를 남기지 않는다.
SENSITIVE_HINTS = ("secret", "token", "password", "key", "credential_value", "authorization")


def redact(detail: tuple[tuple[str, object], ...]) -> tuple[tuple[str, object], ...]:
    """민감해 보이는 키의 값을 가린다.

    키 **이름**으로 거른다 — 값을 보고 판단하면 놓치고, 놓친 하나가
    3년치 감사에 남는다 (보존 기간이 길다는 것이 여기서는 위험이다).

    `credential_id` 같은 **식별자는 남긴다.** 그것이 추적의 재료다.
    """
    out: list[tuple[str, object]] = []
    for key, value in detail:
        low = key.lower()
        hidden = any(h in low for h in SENSITIVE_HINTS) and not low.endswith("_id")
        out.append((key, "<가림>" if hidden else value))
    return tuple(out)


__all__ = [
    "ACTIONS",
    "SENSITIVE_HINTS",
    "Actor",
    "AuditFailed",
    "Auditor",
    "UnknownAction",
    "redact",
]
