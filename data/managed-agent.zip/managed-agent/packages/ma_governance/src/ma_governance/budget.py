"""예산 판정 — **도달은 일시정지지 종료가 아니다**.

`plan/05-database.md` §3 G10 · `plan/04-api.md` §7 ·
`task/M3-security-governance/T-0405-budget-usage.md` · `IMPL-0023`.

세 층이 있다.

| 층 | 무엇 | 넘으면 |
|---|---|---|
| **세션 하드 상한** | 이 세션이 쓸 수 있는 돈 | `budget_reached` 로 **일시정지** |
| **워크스페이스 예산** | 부서의 일·월 한도 | 새 세션 생성 거부 (409) |
| **쿼터** | 동시 세션 수, 일일 생성 수 | 세션 생성 거부 (409) |

> **상한 도달은 일시정지지 종료가 아니다.** 예산을 올리면 **같은 세션이
> 이어서** 돈다. 종료시키면 거기까지의 작업이 버려지고, 사용자는 처음부터
> 다시 시킨다 — 그 재실행이 또 돈이다.

> **쿼터 초과는 429 가 아니라 409 다.** 429 는 "잠시 뒤 다시"인데,
> 예산 초과는 **재시도해도 안 된다.** 클라이언트가 지수 백오프로 두드리면
> 그 자체가 부하다.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from decimal import Decimal
from enum import StrEnum
from typing import TYPE_CHECKING

from ma_domain.governance import BudgetPeriod

if TYPE_CHECKING:
    from collections.abc import Sequence

    from ma_domain.governance import Budget

#: 경고를 내는 지점. 넘으면 **운영자에게 알린다** (막지는 않는다).
WARN_AT = Decimal("0.8")

#: 세션 기본 상한(센트). 예산이 선언하지 않았을 때 쓴다.
#:
#: **무한이 기본이면 안 된다.** 무한 루프에 빠진 에이전트 하나가 부서
#: 예산을 하루에 태운다. 5천원은 "실수로 태워도 아픈데 치명적이지는
#: 않은" 선이다.
DEFAULT_SESSION_LIMIT_CENTS = 500


class Verdict(StrEnum):
    OK = "ok"
    #: 80% 를 넘었다. **막지 않는다** — 알리기만 한다.
    WARN = "warn"
    #: 상한에 도달했다.
    EXCEEDED = "exceeded"


@dataclass(frozen=True, slots=True)
class Check:
    verdict: Verdict
    limit_cents: int
    spent_cents: int
    #: 어느 예산이 걸렸는가. 경고·거부 메시지에 쓴다.
    scope: str = ""

    @property
    def ok(self) -> bool:
        return self.verdict is not Verdict.EXCEEDED

    @property
    def remaining_cents(self) -> int:
        return max(0, self.limit_cents - self.spent_cents)

    @property
    def ratio(self) -> Decimal:
        if self.limit_cents <= 0:  # pragma: no cover — 도메인이 막는다
            return Decimal(1)
        return Decimal(self.spent_cents) / Decimal(self.limit_cents)


def evaluate(*, limit_cents: int, spent_cents: int, scope: str = "") -> Check:
    """한 예산의 판정. **`>=` 다** — 정확히 한도에 닿으면 도달이다.

    `>` 로 두면 한도가 1000원일 때 1000원을 쓰고도 한 번 더 돈다. 그
    "한 번 더"가 얼마일지는 모델이 정한다.
    """
    if spent_cents >= limit_cents:
        verdict = Verdict.EXCEEDED
    elif Decimal(spent_cents) >= Decimal(limit_cents) * WARN_AT:
        verdict = Verdict.WARN
    else:
        verdict = Verdict.OK
    return Check(verdict=verdict, limit_cents=limit_cents, spent_cents=spent_cents, scope=scope)


def session_limit(budgets: Sequence[Budget], *, requested: int | None = None) -> int:
    """이 세션에 걸 상한.

    **요청값이 예산의 기본값을 넘을 수 없다.** 넘게 두면 세션 생성 때
    큰 숫자를 적는 것으로 부서 통제를 우회한다.
    """
    declared = [b.session_default_cents for b in budgets if b.session_default_cents is not None]
    ceiling = min(declared) if declared else DEFAULT_SESSION_LIMIT_CENTS
    if requested is None:
        return ceiling
    return min(requested, ceiling)


def period_window(period: BudgetPeriod, now: datetime) -> tuple[datetime, datetime]:
    """이 기간의 `[시작, 끝)`. **UTC 기준이다.**

    사내 시간대(KST)로 하고 싶어지지만, 그러면 워크스페이스마다 다른
    시간대를 지원해야 하고 집계가 테넌트별로 갈린다. UTC 로 고정하고
    **표시할 때** 변환한다.
    """
    match period:
        case BudgetPeriod.DAILY:
            start = now.replace(hour=0, minute=0, second=0, microsecond=0)
            return start, start + timedelta(days=1)
        case BudgetPeriod.MONTHLY:
            start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
            ny, nm = (start.year, start.month + 1) if start.month < 12 else (start.year + 1, 1)
            return start, start.replace(year=ny, month=nm)
        case BudgetPeriod.TOTAL:
            return datetime(1970, 1, 1, tzinfo=UTC), now + timedelta(days=1)
    raise ValueError(f"모르는 기간: {period}")  # pragma: no cover


def strictest(checks: Sequence[Check]) -> Check:
    """여러 예산 중 **가장 조이는 것**이 이긴다.

    하나라도 초과면 초과다. 전부 OK 여야 OK 다 — "평균적으로 괜찮다"는
    예산이 아니다.
    """
    if not checks:
        return Check(verdict=Verdict.OK, limit_cents=0, spent_cents=0)
    order = {Verdict.OK: 0, Verdict.WARN: 1, Verdict.EXCEEDED: 2}
    return max(checks, key=lambda c: (order[c.verdict], c.ratio))


__all__ = [
    "DEFAULT_SESSION_LIMIT_CENTS",
    "WARN_AT",
    "Check",
    "Verdict",
    "evaluate",
    "period_window",
    "session_limit",
    "strictest",
]
