{{/*
공통 헬퍼. **이름 규칙이 한 곳에 있다** — 여러 템플릿이 각자 이름을
만들면 NetworkPolicy 의 selector 가 Deployment 의 label 과 어긋나고,
그 어긋남은 **정책이 조용히 아무도 선택하지 않는 것**으로 나타난다.
*/}}

{{- define "awp.image" -}}
{{ .Values.image.repository }}:{{ .Values.image.tag | default .Chart.AppVersion }}
{{- end -}}

{{- define "awp.labels" -}}
app.kubernetes.io/name: awp
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end -}}

{{/* 부서 네임스페이스 이름. `awp-runtime-<slug>` */}}
{{- define "awp.runtimeNamespace" -}}
{{ .prefix }}-{{ .dept.slug }}
{{- end -}}

{{/*
워커가 쓰는 공통 환경변수. **DSN 은 Secret 에서 온다** — values 에
두면 git 에 남는다.
*/}}
{{- define "awp.commonEnv" -}}
- name: AWP_LOG_LEVEL
  value: INFO
- name: OTEL_EXPORTER_OTLP_ENDPOINT
  value: {{ .Values.observability.otlpEndpoint | quote }}
- name: AWP_BLOB_BUCKET
  value: {{ .Values.blob.bucket | quote }}
- name: AWP_BLOB_ENDPOINT
  value: {{ .Values.blob.endpoint | quote }}
- name: AWP_BLOB_REGION
  value: {{ .Values.blob.region | quote }}
{{- end -}}

{{/*
Restricted PSS 를 그대로 통과하는 Pod securityContext.
`plan/08` §4 — **티어 W 는 특별 권한이 하나도 필요 없다.**
*/}}
{{- define "awp.podSecurity" -}}
runAsNonRoot: true
runAsUser: 10001
runAsGroup: 10001
fsGroup: 10001
seccompProfile:
  type: RuntimeDefault
{{- end -}}

{{- define "awp.containerSecurity" -}}
allowPrivilegeEscalation: false
readOnlyRootFilesystem: true
capabilities:
  drop: ["ALL"]
{{- end -}}
