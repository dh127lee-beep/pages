#!/usr/bin/env python3
"""AWP 설계 문서용 SVG 다이어그램 생성기."""
from __future__ import annotations
import pathlib, sys

OUT = pathlib.Path("/Users/leedonghyeon/Work/managed-agent/plan/svg")
OUT.mkdir(parents=True, exist_ok=True)

STYLE = """
<style>
svg{--bg:#ffffff;--fg:#1b1f27;--mut:#5c6675;--line:#c3cad4;--card:#f4f6f9;--card2:#e9edf3;
    --ac:#1f9e86;--ac2:#d8f0ea;--bl:#2563eb;--bl2:#dde8fe;--pu:#7c3aed;--pu2:#eae2fd;
    --wa:#c2410c;--wa2:#fdead8;--da:#b42318;--da2:#fde4e1;--ok:#15803d;--ok2:#dcf5e3}
@media (prefers-color-scheme:dark){
svg{--bg:#0f1116;--fg:#e7e9ee;--mut:#99a3b2;--line:#39414e;--card:#191c23;--card2:#22262f;
    --ac:#33c3a6;--ac2:#10342c;--bl:#6aa6fb;--bl2:#132542;--pu:#a98cfa;--pu2:#241a40;
    --wa:#fb923c;--wa2:#3a2412;--da:#f87171;--da2:#3d1a18;--ok:#4ade80;--ok2:#12301d}}
.bg{fill:var(--bg)}
text{font-family:ui-sans-serif,-apple-system,"Segoe UI",Roboto,"Noto Sans KR","Malgun Gothic",sans-serif;
     fill:var(--fg);font-size:13px}
.mono{font-family:ui-monospace,SFMono-Regular,Menlo,"Cascadia Code",monospace;font-size:11.5px}
.h{font-size:17px;font-weight:650}
.sh{font-size:13.5px;font-weight:600;fill:var(--mut)}
.lb{font-size:12px;font-weight:600}
.sm{font-size:11px;fill:var(--mut)}
.xs{font-size:10px;fill:var(--mut)}
.c{fill:var(--card);stroke:var(--line);stroke-width:1.2;rx:8}
.c2{fill:var(--card2);stroke:var(--line);stroke-width:1;rx:6}
.ac{fill:var(--ac2);stroke:var(--ac);stroke-width:1.4;rx:8}
.bl{fill:var(--bl2);stroke:var(--bl);stroke-width:1.4;rx:8}
.pu{fill:var(--pu2);stroke:var(--pu);stroke-width:1.4;rx:8}
.wa{fill:var(--wa2);stroke:var(--wa);stroke-width:1.4;rx:8}
.da{fill:var(--da2);stroke:var(--da);stroke-width:1.4;rx:8}
.ok{fill:var(--ok2);stroke:var(--ok);stroke-width:1.4;rx:8}
.ln{stroke:var(--line);stroke-width:1.4;fill:none}
.ar{stroke:var(--mut);stroke-width:1.5;fill:none;marker-end:url(#a)}
.ar-ac{stroke:var(--ac);stroke-width:1.8;fill:none;marker-end:url(#aac)}
.ar-da{stroke:var(--da);stroke-width:1.8;fill:none;marker-end:url(#ada)}
.ar-bl{stroke:var(--bl);stroke-width:1.6;fill:none;marker-end:url(#abl)}
.dash{stroke-dasharray:5 4}
.tb{fill:var(--ac)}.tr{fill:var(--da)}.tm{fill:var(--mut)}.tw{fill:var(--wa)}.tk{fill:var(--ok)}.tp{fill:var(--pu)}.tl{fill:var(--bl)}
.bold{font-weight:650}
</style>
<defs>
<marker id="a" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
  <path d="M0 0 L10 5 L0 10 z" fill="var(--mut)"/></marker>
<marker id="aac" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
  <path d="M0 0 L10 5 L0 10 z" fill="var(--ac)"/></marker>
<marker id="ada" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
  <path d="M0 0 L10 5 L0 10 z" fill="var(--da)"/></marker>
<marker id="abl" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
  <path d="M0 0 L10 5 L0 10 z" fill="var(--bl)"/></marker>
</defs>
"""


def svg(name: str, w: int, h: int, title: str, desc: str, body: str) -> None:
    doc = (
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {w} {h}" width="{w}" height="{h}" '
        f'role="img" aria-labelledby="ti de">\n'
        f'<title id="ti">{title}</title>\n<desc id="de">{desc}</desc>\n'
        f'{STYLE}\n<rect class="bg" x="0" y="0" width="{w}" height="{h}"/>\n{body}\n</svg>\n'
    )
    (OUT / name).write_text(doc, encoding="utf-8")
    print(f"  {name:34s} {w}x{h}  {len(doc):>6d}B")


def box(x, y, w, h, cls="c"):
    return f'<rect class="{cls}" x="{x}" y="{y}" width="{w}" height="{h}"/>'


def esc(s: str) -> str:
    """이미 이스케이프된 엔티티를 되돌린 뒤 한 번만 이스케이프한다."""
    s = s.replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def t(x, y, s, cls="", anchor="start"):
    a = f' text-anchor="{anchor}"' if anchor != "start" else ""
    c = f' class="{cls}"' if cls else ""
    return f'<text x="{x}" y="{y}"{c}{a}>{esc(s)}</text>'


def lines(x, y, items, dy=15, cls="sm"):
    return "\n".join(t(x, y + i * dy, s, cls) for i, s in enumerate(items))


# ────────────────────────────────────────────────────────────── 01 컨텍스트
svg("01-context.svg", 1000, 560,
    "AWP 시스템 컨텍스트",
    "사내 사용자 4역할이 Console을 통해 AWP를 쓰고, AWP가 사내 경계 안에서 데이터를 보관하며 모델 추론만 외부로 나간다",
    f"""
{t(28, 34, "시스템 컨텍스트 — 무엇이 사내에 남고 무엇이 나가는가", "h")}
{t(28, 54, "데이터·세션·샌드박스는 사내 경계 안. 외부로 나가는 것은 모델 추론과 허용된 호스트 호출뿐", "sm")}

<rect x="24" y="76" width="640" height="446" rx="12" fill="none" stroke="var(--ac)" stroke-width="1.6" stroke-dasharray="7 5"/>
{t(40, 98, "사내 경계 (on-premise / private cloud)", "lb tb")}

{box(48, 118, 592, 86, "c2")}
{t(64, 140, "사내 사용자", "lb")}
{box(64, 150, 134, 44, "ac")}{t(131, 168, "업무 담당자", "lb", "middle")}{t(131, 184, "세션 실행·승인 응답", "xs", "middle")}
{box(208, 150, 134, 44, "ac")}{t(275, 168, "에이전트 운영자", "lb", "middle")}{t(275, 184, "설정·버전·스킬", "xs", "middle")}
{box(352, 150, 134, 44, "ac")}{t(419, 168, "플랫폼 관리자", "lb", "middle")}{t(419, 184, "환경·모델·예산", "xs", "middle")}
{box(496, 150, 128, 44, "ac")}{t(560, 168, "감사 · 보안", "lb", "middle")}{t(560, 184, "감사 로그·승인 이력", "xs", "middle")}

<path class="ar" d="M344 206 L344 232"/>
{box(220, 232, 248, 40, "bl")}
{t(344, 257, "Console (React SPA)  ·  aw CLI", "lb", "middle")}

<path class="ar" d="M344 274 L344 298"/>
{t(352, 292, "/api/v1/*", "mono tm")}

{box(48, 298, 592, 206, "c")}
{t(64, 322, "AWP", "h")}
{box(64, 334, 180, 52, "ok")}{t(154, 354, "control-plane", "lb mono", "middle")}{t(154, 370, "API·인증·승인·감사·예산", "xs", "middle")}
{box(254, 334, 180, 52, "bl")}{t(344, 354, "runtime-worker", "lb mono", "middle")}{t(344, 370, "하네스 + 샌드박스", "xs", "middle")}
{box(444, 334, 180, 52, "wa")}{t(534, 354, "egress-proxy", "lb mono", "middle")}{t(534, 370, "allowlist + 자격증명 주입", "xs", "middle")}

{box(64, 398, 266, 44, "c2")}{t(197, 418, "PostgreSQL", "lb mono", "middle")}{t(197, 434, "세션·이벤트·감사·자격증명(암호문)", "xs", "middle")}
{box(344, 398, 280, 44, "c2")}{t(484, 418, "Object store", "lb mono", "middle")}{t(484, 434, "스냅샷·업로드·산출물", "xs", "middle")}

{t(64, 468, "여기에 남는 것 — 대화 이력 전체 · 샌드박스 파일 · 산출물 · 승인 이력 · 자격증명", "sm")}
{t(64, 486, "공용 SaaS 에이전트가 ZDR/BAA 대상이 아닌 이유를 이 경계로 해결한다", "sm tb")}

<path class="ar-da" d="M640 356 L724 356"/>
{t(682, 348, "추론만", "xs tr", "middle")}
<path class="ar-da" d="M640 420 L724 420"/>
{t(682, 412, "allowlist", "xs tr", "middle")}

{box(724, 196, 252, 64, "pu")}
{t(850, 220, "DeepSeek API", "lb", "middle")}
{t(850, 238, "deepseek-flash (V4.1-Flash)", "mono xs", "middle")}
{t(850, 252, "모델 키는 프록시만 안다", "xs", "middle")}

{box(724, 284, 252, 58, "c2")}
{t(850, 308, "MCP 서버", "lb", "middle")}
{t(850, 326, "사내 위키 · 티켓 · 코드 저장소", "xs", "middle")}

{box(724, 366, 252, 58, "c2")}
{t(850, 390, "사내 시스템", "lb", "middle")}
{t(850, 408, "ERP · HR · 그룹웨어 (허용 호스트)", "xs", "middle")}

{box(724, 448, 252, 74, "da")}
{t(850, 470, "나가지 않는 것", "lb tr", "middle")}
{t(850, 488, "세션 이력 · 샌드박스 파일", "xs", "middle")}
{t(850, 503, "자격증명 평문 · 감사 로그", "xs", "middle")}
{t(850, 517, "업로드 파일 · 산출물", "xs", "middle")}
""")

# ────────────────────────────────────────────────────────────── 02 핵심 개념
svg("02-core-concepts.svg", 1000, 620,
    "AWP 핵심 개념 10개의 관계",
    "Workspace가 모든 리소스의 파티션이고, Agent와 Environment가 Session을 만들고, Session이 Event를 낳는다",
    f"""
{t(28, 34, "핵심 개념과 관계", "h")}
{t(28, 54, "위 7개는 Claude Managed Agents 계약을 그대로. 아래 3개는 사내 운영을 위한 추가", "sm")}

{box(24, 72, 952, 42, "ac")}
{t(500, 99, "① Workspace — 부서 하나. 모든 테이블 행의 파티션 키이자 격리·예산 경계", "lb", "middle")}

{box(60, 142, 200, 82, "bl")}
{t(160, 166, "② Agent", "lb", "middle")}
{t(160, 184, "모델 핸들 · 시스템 프롬프트", "xs", "middle")}
{t(160, 198, "툴 · MCP · 스킬", "xs", "middle")}
{t(160, 214, "버전 관리됨 (v1, v2 …)", "xs tl", "middle")}

{box(300, 142, 200, 82, "bl")}
{t(400, 166, "③ Environment", "lb", "middle")}
{t(400, 184, "샌드박스 티어 (wasm/process)", "xs", "middle")}
{t(400, 198, "패키지 · 네트워크 정책", "xs", "middle")}
{t(400, 214, "egress: required | best_effort", "xs tl", "middle")}

{box(540, 142, 180, 82, "c2")}
{t(630, 166, "Model card", "lb", "middle")}
{t(630, 184, "실제 모델 ID · 한도", "xs", "middle")}
{t(630, 198, "추론 파라미터 · 요금", "xs", "middle")}
{t(630, 214, "모델 = 설정 (D12)", "xs tb", "middle")}

{box(760, 142, 180, 82, "c2")}
{t(850, 166, "Skill", "lb", "middle")}
{t(850, 184, "도메인 지식 묶음", "xs", "middle")}
{t(850, 206, "파일로 마운트", "xs", "middle")}

<path class="ar-bl" d="M160 226 L300 282"/>
<path class="ar-bl" d="M400 226 L400 282"/>
<path class="ln dash" d="M630 226 L470 282"/>
<path class="ln dash" d="M850 226 L240 180"/>

{box(300, 282, 200, 92, "ac")}
{t(400, 306, "④ Session", "lb", "middle")}
{t(400, 324, "agent_version 핀 + 환경", "xs", "middle")}
{t(400, 338, "idle / running /", "mono xs", "middle")}
{t(400, 352, "rescheduling / terminated", "mono xs", "middle")}
{t(400, 368, "정상 완료는 idle (terminated 아님)", "xs tb", "middle")}

{box(60, 282, 200, 92, "c")}
{t(160, 306, "⑥ Vault / Credential", "lb", "middle")}
{t(160, 324, "평문은 제어 평면만", "xs", "middle")}
{t(160, 338, "API 응답에 필드 자체가 없다", "xs", "middle")}
{t(160, 360, "샌드박스는 존재조차 모른다", "xs tr", "middle")}

{box(540, 282, 180, 92, "c")}
{t(630, 306, "⑦ Memory store", "lb", "middle")}
{t(630, 324, "/mnt/memory/&lt;name&gt;", "mono xs", "middle")}
{t(630, 342, "전용 툴 없음 —", "xs", "middle")}
{t(630, 356, "일반 파일 툴로 접근", "xs", "middle")}

{box(760, 282, 180, 92, "c")}
{t(850, 306, "Deployment", "lb", "middle")}
{t(850, 324, "재실행 가능한 세션 템플릿", "xs", "middle")}
{t(850, 342, "cron 스케줄", "xs", "middle")}
{t(850, 360, "off_peak_preferred", "mono xs", "middle")}

<path class="ar" d="M260 328 L300 328"/>
<path class="ar" d="M540 328 L500 328"/>
<path class="ar" d="M760 328 L724 328"/>

<path class="ar-ac" d="M400 376 L400 414"/>
{box(240, 414, 320, 74, "ok")}
{t(400, 438, "⑤ Event — append-only", "lb", "middle")}
{t(400, 456, "seq = 모델이 본 순서 (도착 순서가 아니다)", "xs", "middle")}
{t(400, 476, "user.* / agent.* / session.* / span.* / system.*", "mono xs", "middle")}

{box(24, 508, 952, 42, "wa")}
{t(500, 534, "⑧ Approval  ·  ⑨ Budget  ·  ⑩ Audit entry   — 사내 운영을 위한 추가 개념", "lb", "middle")}

<path class="ar" d="M300 450 L120 450 L120 508"/>
{t(128, 444, "툴 호출이 승인을 요구", "xs", "middle")}
<path class="ar" d="M500 450 L700 450 L700 508"/>
{t(712, 444, "usage 적립 · 모든 변화 기록", "xs")}

{t(28, 578, "읽는 순서: Workspace 안에서 Agent와 Environment를 정의 → 둘을 묶어 Session을 만들면 Event가 쌓인다.", "sm")}
{t(28, 598, "Vault·Memory·Skill은 Session에 붙는 자원이고, Approval·Budget·Audit은 그 실행을 감독한다.", "sm")}
""")

# ────────────────────────────────────────────────────────────── 03 평면
svg("03-planes.svg", 1000, 620,
    "세 평면과 신뢰 경계",
    "제어 평면은 신뢰, 실행 평면은 준신뢰, 샌드박스 평면은 비신뢰. 경계를 넘는 화살표만 표시",
    f"""
{t(28, 34, "세 평면과 신뢰 경계", "h")}
{t(28, 54, "경계를 넘는 것이 무엇인지가 아키텍처의 전부다. 샌드박스에서 DB·제어 평면으로 가는 화살표는 없다", "sm")}

{box(24, 76, 620, 128, "ok")}
{t(44, 100, "제어 평면  control-plane", "lb")}
{t(630, 100, "신뢰", "lb tk", "end")}
{lines(44, 122, [
  "인증·인가 · 리소스 CRUD · 이벤트 수용(admission) · 승인 · 감사 · 예산",
  "자격증명 평문을 아는 유일한 곳 · 전 테이블 접근 · 모든 워크스페이스",
])}
{box(44, 150, 180, 40, "c2")}{t(134, 175, "FastAPI · HPA 3~20", "mono xs", "middle")}
{box(234, 150, 180, 40, "c2")}{t(324, 175, "DB 역할 awp_app", "mono xs", "middle")}
{box(424, 150, 200, 40, "c2")}{t(524, 175, "audit_log은 INSERT/SELECT만", "mono xs", "middle")}

{box(24, 230, 620, 146, "bl")}
{t(44, 254, "실행 평면  runtime-worker", "lb")}
{t(630, 254, "준신뢰", "lb tl", "end")}
{lines(44, 276, [
  "claim → fence → 하네스 루프 → 이벤트 append → settle",
  "모르는 것: 사용자 자격증명 평문 · 모델 API 키 · 다른 워크스페이스",
])}
{box(44, 304, 180, 60, "c2")}{t(134, 326, "하네스 턴 루프", "lb", "middle")}{t(134, 344, "DeepSeek 호출", "xs", "middle")}{t(134, 358, "(프록시 경유)", "xs", "middle")}
{box(234, 304, 180, 60, "c2")}{t(324, 326, "호스트 툴 5개", "lb", "middle")}{t(324, 344, "read/write/edit", "mono xs", "middle")}{t(324, 358, "glob/grep", "mono xs", "middle")}
{box(424, 304, 200, 60, "c2")}{t(524, 326, "DB 역할 awp_worker", "mono xs", "middle")}{t(524, 344, "execution·event만", "xs", "middle")}{t(524, 358, "credentials 권한 없음", "xs tr", "middle")}

{box(24, 402, 620, 146, "da")}
{t(44, 426, "샌드박스 평면", "lb")}
{t(630, 426, "비신뢰", "lb tr", "end")}
{t(44, 448, "아는 것: /workspace 파일 · 자기 세션 ID · (티어 P만) 프록시 주소", "sm")}
{box(44, 464, 286, 68, "c2")}
{t(187, 486, "티어 W — Wasmtime + WASI p1", "lb", "middle")}
{t(187, 504, "소켓 없음 · ambient authority 0", "xs", "middle")}
{t(187, 520, "bash 없음 · 기동 수 ms", "mono xs", "middle")}
{box(340, 464, 286, 68, "c2")}
{t(483, 486, "티어 P — bubblewrap + Landlock", "lb", "middle")}
{t(483, 504, "--unshare-net (네트워크 없음)", "mono xs", "middle")}
{t(483, 520, "bash 있음 · 비특권 userns 필요", "mono xs", "middle")}

{box(684, 76, 292, 472, "c")}
{t(700, 100, "경계를 넘는 것 — 전부", "lb")}
{lines(700, 126, [
  "Console → 제어 평면",
  "  쿠키 세션 또는 API 키",
  "",
  "제어 평면 → PostgreSQL",
  "  전 테이블",
  "",
  "실행 평면 → PostgreSQL",
  "  자기 lane의 execution/event만",
  "",
  "실행 평면 → 제어 평면",
  "  credential 대행 요청",
  "  (워크스페이스, 세션, 호스트)",
  "  응답은 '주입 완료'뿐",
  "",
  "실행 평면 → 샌드박스",
  "  같은 프로세스. k8s API 없음",
  "",
  "샌드박스 → egress-proxy",
  "  티어 P + pasta일 때만",
], dy=17)}
{box(700, 462, 260, 72, "da")}
{t(830, 484, "없는 화살표", "lb tr", "middle")}
{t(830, 502, "샌드박스 → DB", "mono xs", "middle")}
{t(830, 516, "샌드박스 → 제어 평면", "mono xs", "middle")}
{t(830, 530, "샌드박스 → 인터넷 직접", "mono xs", "middle")}

<path class="ar-ac" d="M334 204 L334 230"/>
{t(342, 222, "PostgreSQL: outbox + lease + fence 가 유일한 실행 권한", "xs tb")}
<path class="ar-ac" d="M334 376 L334 402"/>
{t(342, 394, "in-process confine", "xs tb")}

{t(28, 578, "실행 평면을 따로 두는 이유: ① HPA 신호가 API 요청 수와 전혀 다른 축이다 ② API 롤링 업데이트가 실행 중인 턴을 끊는다", "sm")}
{t(28, 598, "③ 하네스는 모델 응답을 신뢰할 수 없는 입력으로 다루는 코드다. 그 프로세스가 전체 자격증명을 들고 있으면 안 된다.", "sm")}
""")

# ────────────────────────────────────────────────────────────── 04 메타 하네스
svg("04-meta-harness.svg", 1000, 560,
    "메타-하네스 3계층",
    "플랫폼은 무엇이 사용 가능한지 준비하고, 하네스는 그것을 모델에게 어떻게 전달할지 결정한다",
    f"""
{t(28, 34, "메타-하네스 — 플랫폼이 준비하고, 하네스가 결정한다", "h")}
{t(28, 54, "하네스는 교체 가능해야 한다. 경계선은 하나: 준비(what is available) vs 전달 방식(how)", "sm")}

{box(24, 76, 952, 150, "pu")}
{t(44, 100, "하네스 (교체 가능한 에이전트 루프)", "lb")}
{t(956, 100, "default · dsh · acp", "mono sm", "end")}
{t(44, 122, "무상태 — 이벤트 로그 · 에이전트 설정 · 샌드박스 파일시스템에서 모든 것을 얻는다", "sm")}
{box(44, 136, 174, 76, "c2")}{t(131, 158, "시스템 프롬프트 구성", "lb", "middle")}{t(131, 178, "캐시 breakpoint 배치", "xs", "middle")}{t(131, 196, "툴 전달 방식", "xs", "middle")}
{box(228, 136, 174, 76, "c2")}{t(315, 158, "컨텍스트 엔지니어링", "lb", "middle")}{t(315, 178, "derive_messages()", "mono xs", "middle")}{t(315, 196, "압축 시점과 방식", "xs", "middle")}
{box(412, 136, 174, 76, "c2")}{t(499, 158, "재시도 전략", "lb", "middle")}{t(499, 178, "실패 시도는 로그에만", "xs", "middle")}{t(499, 196, "agent.message_attempt", "mono xs", "middle")}
{box(596, 136, 174, 76, "c2")}{t(683, 158, "모델 호출 파라미터", "lb", "middle")}{t(683, 178, "reasoning_effort 의도", "mono xs", "middle")}{t(683, 196, "max_tokens", "mono xs", "middle")}
{box(780, 136, 176, 76, "c2")}{t(868, 158, "턴 종료 판단", "lb", "middle")}{t(868, 178, "stop_reason 후보", "mono xs", "middle")}{t(868, 196, "스텝별 broadcast", "xs", "middle")}

<path class="ar-ac" d="M500 226 L500 252"/>
{t(512, 246, "HarnessContext", "mono tb")}

{box(24, 252, 952, 164, "ac")}
{t(44, 276, "플랫폼 (실행 평면 호스트)", "lb")}
{t(956, 276, "Port 10개", "mono sm", "end")}
{t(44, 298, "무엇이 사용 가능한지 준비한다. 하네스가 어떻게 쓸지는 간섭하지 않는다", "sm")}
{box(44, 312, 148, 44, "c2")}{t(118, 332, "EventLogPort", "mono lb", "middle")}{t(118, 348, "append · read · promote", "xs", "middle")}
{box(200, 312, 148, 44, "c2")}{t(274, 332, "ExecutionStorePort", "mono lb", "middle")}{t(274, 348, "claim · renew · settle", "xs", "middle")}
{box(356, 312, 148, 44, "c2")}{t(430, 332, "SandboxPort", "mono lb", "middle")}{t(430, 348, "confine · exec · mount", "xs", "middle")}
{box(512, 312, 148, 44, "c2")}{t(586, 332, "ModelPort", "mono lb", "middle")}{t(586, 348, "카드 → 어댑터 → 스트림", "xs", "middle")}
{box(668, 312, 148, 44, "c2")}{t(742, 332, "CredentialEgressPort", "mono lb", "middle")}{t(742, 348, "prepare · attach · revoke", "xs", "middle")}
{box(824, 312, 132, 44, "c2")}{t(890, 332, "RealtimePort", "mono lb", "middle")}{t(890, 348, "publish · subscribe", "xs", "middle")}
{box(44, 364, 220, 40, "c2")}{t(154, 389, "ApprovalPort · AuditPort · BudgetPort", "mono xs", "middle")}
{box(272, 364, 220, 40, "c2")}{t(382, 389, "ObjectStorePort", "mono xs", "middle")}
{box(500, 364, 456, 40, "wa")}
{t(728, 389, "툴 레지스트리 구성 · 스킬 마운트 · 메모리 동기화 · running/idle 쌍 불변식 · fence 검증", "xs", "middle")}

<path class="ar-ac" d="M500 416 L500 442"/>

{box(24, 442, 952, 78, "c")}
{t(44, 466, "인프라", "lb")}
{box(44, 478, 174, 32, "c2")}{t(131, 499, "PostgreSQL 17", "mono xs", "middle")}
{box(228, 478, 174, 32, "c2")}{t(315, 499, "Object store (S3/MinIO)", "mono xs", "middle")}
{box(412, 478, 174, 32, "c2")}{t(499, 499, "Wasmtime · bubblewrap", "mono xs", "middle")}
{box(596, 478, 174, 32, "c2")}{t(683, 499, "Kubernetes · KEDA", "mono xs", "middle")}
{box(780, 478, 176, 32, "c2")}{t(868, 499, "egress-proxy", "mono xs", "middle")}

{t(28, 546, "하네스가 크래시하면: 다음 claim이 새 인스턴스를 만들고 이벤트 로그를 다시 읽어 컨텍스트를 재구성한다. 잃을 메모리가 없다.", "sm")}
""")

# ────────────────────────────────────────────────────────────── 05 턴 시퀀스
svg("05-turn-sequence.svg", 1040, 720,
    "턴 하나의 실행 시퀀스",
    "이벤트 수용부터 모델 스트리밍, 툴 실행, idle 종료, settle까지의 메시지 순서",
    f"""
{t(28, 34, "턴 하나의 생애주기", "h")}
{t(28, 54, "수용(202)과 실행이 분리되어 있다. 실행 권한은 claim으로 얻는 fence다", "sm")}

{t(80, 88, "Console", "lb", "middle")}
{t(248, 88, "control-plane", "lb", "middle")}
{t(432, 88, "PostgreSQL", "lb", "middle")}
{t(628, 88, "runtime-worker", "lb", "middle")}
{t(820, 88, "샌드박스", "lb", "middle")}
{t(968, 88, "DeepSeek", "lb", "middle")}
<path class="ln dash" d="M80 98 L80 686"/>
<path class="ln dash" d="M248 98 L248 686"/>
<path class="ln dash" d="M432 98 L432 686"/>
<path class="ln dash" d="M628 98 L628 686"/>
<path class="ln dash" d="M820 98 L820 686"/>
<path class="ln dash" d="M968 98 L968 686"/>

<path class="ar" d="M80 118 L244 118"/>
{t(86, 112, "POST /sessions/:id/events  (Idempotency-Key)", "mono xs")}

{box(256, 128, 240, 72, "ac")}
{t(266, 146, "한 트랜잭션", "lb tb")}
{lines(266, 162, [
  "revision CAS (expected=12)",
  "pending INSERT · interrupt UPDATE",
  "executions INSERT (queued)",
], dy=14, cls="mono xs")}
<path class="ar-ac" d="M248 210 L428 210"/>

<path class="ar" d="M244 232 L84 232"/>
{t(90, 226, "202 accepted { revision: 13 }", "mono xs")}
<path class="ar-bl" d="M244 254 L84 254"/>
{t(90, 248, "SSE system.user_message_pending", "mono xs tl")}

<path class="ar-ac" d="M624 282 L436 282"/>
{t(444, 276, "claim  FOR UPDATE SKIP LOCKED  →  fence{{gen:5}}", "mono xs tb")}
<path class="ln dash" d="M624 300 L436 300"/>
{t(444, 296, "heartbeat 30s (TTL 90s)", "mono xs")}
<path class="ar-ac" d="M624 322 L436 322"/>
{t(444, 316, "promote pending → events  (seq 부여)", "mono xs tb")}
<path class="ar-bl" d="M244 344 L84 344"/>
{t(90, 338, "SSE user_message_promoted + status_running", "mono xs tl")}

<path class="ar" d="M632 370 L816 370"/>
{t(640, 364, "샌드박스 확보 (티어 W: 수 ms)", "mono xs")}
<path class="ln dash" d="M816 388 L632 388"/>
{t(640, 384, "스냅샷 복원 · 메모리/스킬 마운트", "mono xs")}

{box(540, 404, 180, 44, "pu")}
{t(630, 424, "derive_messages(events)", "mono xs", "middle")}
{t(630, 440, "프롬프트 조립 → 요청 동결", "xs", "middle")}

<path class="ar-da" d="M632 464 L964 464"/>
{t(700, 458, "stream (프롬프트 prefix 고정 — 캐시 적중)", "mono xs tr")}
<path class="ar-da" d="M964 486 L632 486"/>
{t(700, 480, "text_delta · thinking_delta · tool_call", "mono xs")}
<path class="ar-bl" d="M624 508 L84 508"/>
{t(90, 502, "SSE agent.message_chunk… (영속 안 함)", "mono xs tl")}
<path class="ar-ac" d="M624 530 L436 530"/>
{t(444, 524, "append agent.message · agent.tool_use", "mono xs tb")}

{box(700, 546, 180, 40, "wa")}
{t(790, 571, "fence generation 검증", "mono xs", "middle")}
<path class="ar" d="M632 598 L816 598"/>
{t(640, 592, "exec / 호스트 툴", "mono xs")}
<path class="ar" d="M816 616 L632 616"/>
{t(640, 612, "stdout (100K자 초과 → spill)", "mono xs")}
<path class="ar-ac" d="M624 638 L436 638"/>
{t(444, 632, "append agent.tool_result   … 루프 …", "mono xs tb")}

{box(500, 650 ,250, 36, "ok")}
{t(625, 672, "메모리 동기화 · usage 적립 · stop_reason", "xs", "middle")}
<path class="ar-bl" d="M244 684 L84 684"/>
{t(90, 678, "SSE session.status_idle{{stop_reason}}  →  settle", "mono xs tl")}

{box(24, 700, 992, 0, "c")}
{t(28, 712, "순서가 중요한 세 가지: ① 메모리 동기화는 idle 이전에 끝난다 ② running과 idle은 반드시 짝을 이룬다 ③ settle은 마지막 — lease 안에서 커밋이 끝나야 fence가 의미를 갖는다", "xs")}
""")

# ────────────────────────────────────────────────────────────── 06 실행 권한
svg("06-execution-authority.svg", 1000, 600,
    "실행 권한 상태기계 — outbox + lease + fence",
    "session_executions 테이블이 유일한 실행 권한. claim마다 generation이 올라가 좀비 워커의 커밋을 막는다",
    f"""
{t(28, 34, "실행 권한은 DB에 있다 — outbox + lease + fence", "h")}
{t(28, 54, "워커는 claim한 lane의 host일 뿐이다. 권한의 증거는 (generation, attempt_id, lease_expires_at)", "sm")}

{box(24, 76, 952, 86, "c")}
{t(44, 100, "session_executions", "lb mono")}
{t(956, 100, "(workspace_id, session_id, lane_id) 안에서 FIFO", "sm", "end")}
{lines(44, 122, [
  "execution_id = 이 lane의 첫 이벤트 id  (멱등키)        generation  단조 증가. claim마다 +1   ← fence의 핵심",
  "state  queued → running → completed | failed | cancelled      lease_owner / lease_expires_at  TTL 90s, 하트비트 30s",
], dy=18, cls="mono sm")}

{box(60, 200, 150, 56, "c2")}
{t(135, 224, "queued", "lb mono", "middle")}
{t(135, 242, "outbox INSERT", "xs", "middle")}

<path class="ar-ac" d="M212 228 L330 228"/>
{t(271, 206, "claim", "lb tb", "middle")}
{t(271, 222, "FOR UPDATE", "mono xs", "middle")}
{t(271, 250, "SKIP LOCKED", "mono xs", "middle")}

{box(332, 200, 170, 56, "bl")}
{t(417, 224, "running", "lb mono", "middle")}
{t(417, 242, "generation + 1", "mono xs", "middle")}

<path class="ar-ac" d="M504 214 L640 190"/>
{box(642, 164, 150, 50, "ok")}
{t(717, 186, "completed", "lb mono", "middle")}
{t(717, 204, "settle", "mono xs", "middle")}

<path class="ar-da" d="M504 232 L640 240"/>
{box(642, 222, 150, 50, "da")}
{t(717, 244, "failed", "lb mono", "middle")}
{t(717, 262, "session.error", "mono xs", "middle")}

<path class="ar" d="M504 250 L640 298"/>
{box(642, 280, 150, 50, "wa")}
{t(717, 302, "cancelled", "lb mono", "middle")}
{t(717, 320, "user.interrupt", "mono xs", "middle")}

<path class="ar-da" d="M417 258 L417 300 L135 300 L135 262"/>
{t(276, 318, "lease 만료 (90s) → 다른 워커가 재claim. generation 또 +1", "sm tr", "middle")}

{box(24, 356, 466, 220, "wa")}
{t(44, 380, "fence 가 막는 것 — 좀비 워커", "lb")}
{lines(44, 404, [
  "워커 A가 느리게 죽는 중 (lease 만료)",
  "워커 B가 같은 lane을 claim → generation 5 → 6",
  "",
  "워커 A가 뒤늦게 이벤트를 append 시도",
  "  → fence.generation(5) ≠ DB(6)",
  "  → ExecutionFenceLost 발생, 턴 중단",
  "",
  "결과: 좀비는 자기 결과를 커밋할 수 없다",
], dy=19)}
{box(44, 538, 426, 26, "c2")}
{t(257, 556, "at-least-once 실행 · at-most-once 커밋", "lb mono", "middle")}

{box(510, 356, 466, 220, "ac")}
{t(530, 380, "DB가 직접 보장하는 것", "lb")}
{lines(530, 404, [
  "① FOR UPDATE SKIP LOCKED",
  "    여러 워커의 동시 claim을 자연히 직렬화",
  "",
  "② 부분 유니크 인덱스 (마지막 방어선)",
  "    UNIQUE (workspace_id, session_id, lane_id)",
  "    WHERE state = 'running'",
  "    → 애플리케이션 버그로도 두 running을 못 만든다",
  "",
  "③ 부분 인덱스로 claim이 상수 시간에 가깝다",
  "    idx_exec_claimable  WHERE state='queued'",
  "    idx_exec_reclaim    WHERE state='running'",
], dy=18, cls="mono sm")}

{t(28, 592, "이 설계의 결과: 세션은 어느 워커에서도 이어서 실행된다. 워커를 늘리고 줄이고 죽여도 복구는 '다음 claim'이고, 별도 복구 코드가 거의 없다.", "sm")}
""")

# ────────────────────────────────────────────────────────────── 07 이중 테이블
svg("07-event-dual-table.svg", 1000, 600,
    "이벤트 이중 테이블과 순서 보장",
    "입력은 pending에 쌓이고 드레인 시점에 events로 promote되며 seq를 받는다. seq는 모델이 본 순서다",
    f"""
{t(28, 34, "이벤트 로그 이중 테이블 — seq는 모델이 본 순서다", "h")}
{t(28, 54, "도착 시점에 seq를 매기면, 에이전트 스트리밍 중 들어온 사용자 입력이 이전 턴 중간에 꽂힌다", "sm")}

{box(24, 76, 466, 112, "da")}
{t(44, 100, "✗ 단일 테이블 — 레퍼런스가 겪은 버그", "lb tr")}
{t(44, 124, "seq  type                            문제", "mono sm")}
{lines(44, 142, [
  "41   agent.message       (턴 1 스트리밍 중)",
  "42   user.message        ← 여기 꽂힌다",
  "43   agent.tool_use      (턴 1 계속)",
], dy=15, cls="mono sm")}
{t(300, 142, "ORDER BY seq 로", "xs tr")}
{t(300, 157, "모델 메시지를 만들면", "xs tr")}
{t(300, 172, "캐시 drift + 잘못된 추론", "xs tr")}

{box(510, 76, 466, 112, "ok")}
{t(530, 100, "✓ 이중 테이블 — AWP", "lb tk")}
{t(530, 124, "seq  type", "mono sm")}
{lines(530, 142, [
  "41   agent.message       (턴 1)",
  "42   agent.tool_use      (턴 1)",
  "43   user.message        ← 턴 1이 끝난 뒤 promote",
], dy=15, cls="mono sm")}

{box(60, 226, 300, 180, "wa")}
{t(80, 250, "session_pending_events", "lb mono")}
{t(80, 268, "아직 모델이 보지 않은 입력. 큐.", "sm")}
{lines(80, 292, [
  "pending_seq  BIGSERIAL  — 큐 순서",
  "             (구멍이 생겨도 무해)",
  "id           evt_01H…   UNIQUE",
  "thread_id    lane",
  "enqueued_at",
  "cancelled_at ← user.interrupt가 표시",
], dy=17, cls="mono sm")}

{box(400, 226, 240, 180, "ac")}
{t(420, 250, "드레인 (claim 안에서)", "lb")}
{box(416, 266, 208, 34, "c2")}{t(520, 288, "① peek  (pending_seq 순)", "mono sm", "middle")}
<path class="ar-ac" d="M520 302 L520 318"/>
{box(416, 318, 208, 34, "ok")}{t(520, 340, "② INSERT INTO events", "mono sm", "middle")}
{t(520, 334, "", "", "middle")}
<path class="ar-ac" d="M520 354 L520 370"/>
{box(416, 370, 208, 30, "c2")}{t(520, 390, "③ DELETE FROM pending", "mono sm", "middle")}

{box(680, 226, 296, 180, "ok")}
{t(700, 250, "session_events", "lb mono")}
{t(700, 268, "승격된 정본. seq = 모델이 본 순서.", "sm")}
{lines(700, 292, [
  "PK (workspace_id, session_id, seq)",
  "seq       promote 시점에 부여  ★",
  "id        UNIQUE  ← 중복 promote 방지",
  "generation 어느 fence에서 커밋됐나",
  "payload   JSONB",
  "PARTITION BY RANGE (created_at)",
], dy=17, cls="mono sm")}

<path class="ar-ac" d="M362 316 L412 316"/>
<path class="ar-ac" d="M628 316 L676 316"/>

{box(24, 428, 952, 96, "bl")}
{t(44, 452, "왜 peek → INSERT → DELETE 순서인가", "lb")}
{lines(44, 476, [
  "반대 순서(DELETE 먼저)면 크래시 시 이벤트가 사라진다 — 복구 불가.",
  "이 순서면 크래시는 중복을 만들고, 중복은 events.id 유니크 인덱스가 막는다 — 복구 가능.",
  "일반 규칙: 유실과 중복 중 선택해야 하면 중복을 택하고, 중복은 멱등성으로 지운다.",
], dy=18)}

{box(24, 544, 952, 44, "c")}
{t(44, 564, "스트림 전용 프레임 (영속되지 않음) — UI가 '대기 중'을 보여주기 위해", "lb")}
{t(44, 582, "system.user_message_pending   ·   system.user_message_promoted   ·   system.user_message_cancelled", "mono sm")}
""")

print("part 1 done", file=sys.stderr)

# ────────────────────────────────────────────────────────────── 08 레이어
svg("08-layers.svg", 1000, 660,
    "7계층 의존 구조",
    "의존은 아래로만 흐른다. 각 레이어의 금지 사항이 CI 규칙이 된다",
    f"""
{t(28, 34, "7계층 — 의존은 아래로만", "h")}
{t(28, 54, "위 레이어를 import하면 CI(import-linter)가 실패한다. 금지 목록이 책임 목록보다 중요하다", "sm")}

{box(24, 76, 700, 58, "pu")}
{t(44, 100, "L7  apps", "lb mono")}
{t(150, 100, "조립과 호스팅 (composition root)", "sm")}
{t(44, 122, "control_plane · runtime_worker · scheduler · egress_proxy · cli", "mono sm")}
{t(712, 100, "환경변수를 읽는 유일한 레이어", "sm tp", "end")}
{t(712, 122, "config → components → assembly → serve", "mono xs", "end")}

<path class="ar" d="M374 134 L374 156"/>
{box(24, 156, 700, 54, "ac")}
{t(44, 180, "L6  ma_platform", "lb mono")}
{t(200, 180, "워크스페이스별 앱 그래프 조립 SDK", "sm")}
{t(44, 200, "WorkspaceAppRegistry: workspace_id → App 1개  ← 테넌트 누수 방어선", "mono sm")}

<path class="ar" d="M250 210 L250 232"/>
<path class="ar" d="M500 210 L500 232"/>
{box(24, 232, 340, 62, "bl")}
{t(44, 256, "L5a  ma_api", "lb mono")}
{t(44, 276, "FastAPI 라우터 · pydantic wire", "sm")}
{t(44, 290, "internal lane / compat lane 독립", "xs tl")}
{box(384, 232, 340, 62, "bl")}
{t(404, 256, "L5b  ma_adapters_* · ma_harness · ma_sandbox", "lb mono")}
{t(404, 276, "외부 자원을 application Port 모양으로", "sm")}
{t(404, 290, "ma_model_* · ma_sandbox_wasm · ma_sandbox_bwrap", "mono xs tl")}

<path class="ar" d="M374 294 L374 316"/>
{box(24, 316, 700, 58, "ok")}
{t(44, 340, "L4  ma_application", "lb mono")}
{t(230, 340, "유스케이스", "sm")}
{t(44, 362, "검증 · 권한 · 페이지네이션 · CAS · 결과는 discriminated union (예외 아님)", "sm")}

<path class="ar" d="M374 374 L374 396"/>
{box(24, 396, 700, 54, "wa")}
{t(44, 420, "L3  ma_store", "lb mono")}
{t(190, 420, "도메인별 Store 인터페이스 (Protocol)", "sm")}
{t(44, 440, "모든 메서드 입력에 workspace_id · 서로 다른 Store끼리 import 금지", "mono sm")}

<path class="ar" d="M190 450 L190 472"/>
<path class="ar" d="M470 450 L470 472"/>
{box(24, 472, 300, 54, "c")}
{t(44, 496, "L2a  ma_store_memory", "lb mono")}
{t(44, 516, "dict + deepcopy. 테스트·로컬", "sm")}
{box(344, 472, 380, 54, "c")}
{t(364, 496, "L2b  ma_store_sql", "lb mono")}
{t(364, 516, "SQLAlchemy Core. 'Agent를 아는' SQL은 여기만", "sm")}

<path class="ar" d="M534 526 L534 548"/>
{box(344, 548, 380, 44, "c2")}
{t(364, 572, "L2c  ma_sql", "lb mono")}
{t(470, 572, "Engine/Connection Port. Agent를 전혀 모른다", "sm")}

<path class="ar" d="M374 592 L374 612"/>
{box(24, 612, 700, 40, "c2")}
{t(44, 637, "L1  ma_domain", "lb mono")}
{t(170, 637, "순수 타입. 외부 의존성 0. frozen dataclass. datetime.now()도 없다 (시간은 주입)", "sm")}

{box(744, 232, 232, 420, "c")}
{t(760, 256, "CI가 막는 세 가지", "lb")}
{box(756, 272, 206, 110, "da")}
{t(766, 292, "✗ ma_api → Store 직접", "mono xs tr")}
{t(766, 308, "유스케이스 우회 =", "xs")}
{t(766, 322, "권한 검사 우회", "xs")}
{t(766, 346, "✗ ma_application → SQL", "mono xs tr")}
{t(766, 362, "런타임 이식성 상실", "xs")}
{box(756, 392, 206, 76, "da")}
{t(766, 412, "✗ ma_sandbox → wasmtime", "mono xs tr")}
{t(766, 428, "provider 중립성 상실.", "xs")}
{t(766, 442, "런타임 지식은", "xs")}
{t(766, 456, "어댑터에만", "xs")}

{t(760, 494, "추가 검사", "lb")}
{lines(760, 516, [
  "스키마 단일 출처",
  "  CREATE TABLE 발견 → 실패",
  "환경변수 단일 출처",
  "  apps/*/config.py 밖 os.environ",
  "시간 주입",
  "  domain/application의 now()",
  "Store 계약 커버리지",
  "  memory·sql 양쪽 통과 확인",
  "응답 재검증",
  "  response_model 없는 핸들러",
], dy=14, cls="xs")}
""")

# ────────────────────────────────────────────────────────────── 09 Port/Module
svg("09-port-module.svg", 1000, 600,
    "Port / Module 조립",
    "모듈은 필요·제공 Port를 선언하고, 선언하지 않은 Port를 꺼내면 조립 시점에 실패한다",
    f"""
{t(28, 34, "Port / Module DI — 선언한 것만 받는다", "h")}
{t(28, 54, "범용 Store 서비스 로케이터는 없다. 각 기능은 자기가 쓰는 좁은 Port만 받는다 (규칙 R3)", "sm")}

{box(24, 80, 300, 184, "ok")}
{t(44, 104, "① Port 토큰 선언", "lb")}
{lines(44, 128, [
  "agent_store_port =",
  "  PortToken[AgentStore](",
  '    "ma.store.agents")',
  "",
  "agents_port =",
  "  PortToken[AgentsUseCases](",
  '    "ma.app.agents")',
  "",
  "토큰은 타입 + 이름.",
  "구현을 모른다.",
], dy=15, cls="mono sm")}

{box(348, 80, 328, 184, "bl")}
{t(368, 104, "② AppModule 선언", "lb")}
{lines(368, 128, [
  "AppModule(",
  '  name="ma:agents",',
  "  provides=[agents_port],",
  "  requires=[workspace_context_port,",
  "            clock_port, id_generator_port,",
  "            agent_store_port, audit_port],",
  "  setup=lambda port: [",
  "    bind(agents_port, AgentsUseCases(",
  "      store=port(agent_store_port), …))",
  "  ])",
], dy=15, cls="mono sm")}
{t(368, 254, "requires에 없는 Port를 port()로 꺼내면 조립 시점 실패", "xs tl")}

{box(700, 80, 276, 184, "ac")}
{t(720, 104, "③ 플랫폼 조립", "lb")}
{lines(720, 128, [
  "build_sql_app(",
  "  workspace_id=ws,",
  "  sql=SqlClient(engine),",
  "  ciphers=bundle,",
  ")",
  "  stores.agents =",
  "    SqlAgentStore(sql)",
  "  provide(agent_store_port,",
  "          stores.agents)",
  "  create_app(modules=[…])",
], dy=15, cls="mono sm")}

<path class="ar-ac" d="M326 172 L344 172"/>
<path class="ar-ac" d="M678 172 L696 172"/>

{box(24, 292, 952, 150, "pu")}
{t(44, 316, "WorkspaceAppRegistry — 테넌트 누수 방어선", "lb")}
{t(44, 338, "앱 그래프가 워크스페이스에 핀되어 있으므로, 요청 스코프 액터나 백그라운드 작업이 다른 워크스페이스의 캐시를 보는 일이 구조적으로 불가능하다", "sm")}
{box(44, 354, 280, 72, "c2")}
{t(184, 376, "workspace_id = wrkspc_법무", "mono sm", "middle")}
{t(184, 396, "App 그래프 1개", "lb", "middle")}
{t(184, 414, "agents · sessions · vaults · …", "mono xs", "middle")}
{box(344, 354, 280, 72, "c2")}
{t(484, 376, "workspace_id = wrkspc_재경", "mono sm", "middle")}
{t(484, 396, "App 그래프 1개", "lb", "middle")}
{t(484, 414, "완전히 분리된 인스턴스", "xs", "middle")}
{box(644, 354, 312, 72, "wa")}
{t(800, 376, "샤딩이 필요해지면", "lb", "middle")}
{t(800, 396, "ShardDirectory.resolve(ws) → DSN", "mono xs", "middle")}
{t(800, 414, "SqlClient 구성 시점에 끝난다. 도메인은 샤드를 모른다", "xs", "middle")}

{box(24, 470, 466, 110, "da")}
{t(44, 494, "✗ 레퍼런스 v0의 서비스 로케이터", "lb tr")}
{lines(44, 518, [
  "interface Services {{ agents, sessions, vaults,",
  "  credentials, memory, files, evals, modelCards,",
  "  environments, dreams, … 16개 필드 }}",
], dy=15, cls="mono xs")}
{t(44, 568, "미들웨어가 요청마다 만들어 주입 → 어떤 라우트가 무엇에 의존하는지 코드에서 읽을 수 없다", "xs")}

{box(510, 470, 466, 110, "ok")}
{t(530, 494, "✓ 교차 도메인은 조립 시점의 좁은 Port로", "lb tk")}
{lines(530, 518, [
  "def credential_vault_source(vaults: VaultStore):",
  "    async def exists(ws, vault_id) -> bool: …",
  "    return CredentialVaultSource(exists=exists)",
], dy=15, cls="mono xs")}
{t(530, 568, "CredentialStore가 VaultStore를 import하지 않는다. 필요한 한 가지 질문만 받는다", "xs")}
""")

# ────────────────────────────────────────────────────────────── 10 API 표면
svg("10-api-surface.svg", 1000, 660,
    "API 표면 — 두 lane",
    "내부 lane과 공식 호환 lane이 wire 레이어에서만 갈라지고 같은 유스케이스를 호출한다",
    f"""
{t(28, 34, "API 표면 — 두 lane, 하나의 유스케이스", "h")}
{t(28, 54, "분리는 wire 레이어에서만. 그래서 비즈니스 규칙이 두 벌로 갈라지지 않는다 (D9)", "sm")}

{box(24, 80, 466, 300, "ac")}
{t(44, 104, "내부 lane   /api/v1/*", "lb mono")}
{t(470, 104, "1단계", "lb tb", "end")}
{t(44, 124, "Console SPA · aw CLI · 사내 서비스", "sm")}
{box(44, 138, 206, 54, "c2")}
{t(147, 158, "워크스페이스 · 사용자", "lb", "middle")}
{t(147, 176, "workspaces · members · api_keys", "mono xs", "middle")}
{box(264, 138, 206, 54, "c2")}
{t(367, 158, "에이전트 자산", "lb", "middle")}
{t(367, 176, "agents · skills · models", "mono xs", "middle")}
{box(44, 200, 206, 54, "c2")}
{t(147, 220, "환경 · 세션", "lb", "middle")}
{t(147, 238, "environments · sessions · events", "mono xs", "middle")}
{box(264, 200, 206, 54, "c2")}
{t(367, 220, "자격증명 · 메모리", "lb", "middle")}
{t(367, 238, "vaults · memory_stores", "mono xs", "middle")}
{box(44, 262, 426, 54, "wa")}
{t(257, 282, "거버넌스 — 사내 확장", "lb", "middle")}
{t(257, 300, "approvals · approval_policies · budgets · usage · audit", "mono xs", "middle")}
{box(44, 324, 426, 42, "c2")}
{t(257, 350, "운영 — deployments · files · webhooks · health · metrics", "mono xs", "middle")}

{box(510, 80, 466, 300, "bl")}
{t(530, 104, "공식 호환 lane   /v1/*", "lb mono")}
{t(956, 104, "2단계", "lb tl", "end")}
{t(530, 124, "공식 SDK가 baseURL만 바꿔 붙는다. 공식 wire 계약 그대로. 필드 추가 금지", "sm")}
{t(530, 148, "리소스                    엔드포인트   1단계 유스케이스로 덮임", "mono sm")}
{lines(530, 170, [
  "Agents                           6      ✓",
  "Sessions                        20      ✓ (threads는 빈 목록)",
  "Environments                    15      ✓ (work/*는 2단계)",
  "Vaults                          13      ✓",
  "Memory Stores                   14      ✓",
  "Deployments / Runs             8 / 2    2단계",
  "Dreams                           5      3단계 — 그전엔 404",
  "Tunnels                         10      미지원 — not_found_error",
], dy=17, cls="mono sm")}
{box(530, 318, 426, 48, "c2")}
{t(743, 338, "beta 헤더를 리소스별로 게이트한다 (전역 게이트 아님)", "sm", "middle")}
{t(743, 356, "managed-agents-2026-04-01 · dreaming-2026-04-21 · mcp-tunnels-2026-06-22", "mono xs", "middle")}

<path class="ar-ac" d="M257 380 L257 418"/>
<path class="ar-bl" d="M743 380 L743 418"/>
{t(500, 404, "같은 유스케이스. wire 매퍼만 다르다", "lb", "middle")}

{box(240, 418, 520, 56, "ok")}
{t(500, 442, "ma_application  —  AgentsUseCases · SessionsUseCases · …", "lb mono", "middle")}
{t(500, 462, "검증 · 권한 · 페이지네이션 · CAS. HTTP를 모른다", "sm", "middle")}

{box(24, 498, 466, 142, "c")}
{t(44, 522, "공통 규약", "lb")}
{lines(44, 546, [
  "수정은 POST /resource/{{id}}  (PATCH 아님)",
  "아카이브는 소프트 삭제가 기본. DELETE는 일부만",
  "커서 페이지네이션 — offset 안 쓴다",
  "낙관적 동시성 — expected_version → 409 + actual",
  "멱등성 — Idempotency-Key → 결정적 event id",
  "에러 envelope — 두 lane이 같은 모양",
], dy=17, cls="sm")}

{box(510, 498, 466, 142, "wa")}
{t(530, 522, "인증 우선순위 — 워크스페이스는 한 번만 결정된다", "lb")}
{lines(530, 546, [
  "① x-api-key                     워크스페이스 고정",
  "② Authorization: Bearer         서비스·워커 토큰",
  "③ 쿠키 + x-active-workspace     멤버십 검증",
  "④ 없음                           401",
], dy=17, cls="mono sm")}
{t(530, 622, "API 키는 x-active-workspace를 무시한다 — 허용하면 키 탈취 시 횡적 이동이 된다", "xs tw")}
""")

# ────────────────────────────────────────────────────────────── 11 ERD core
svg("11-erd-core.svg", 1000, 640,
    "핵심 ERD — 워크스페이스 · 자산 · 자격증명 · 거버넌스",
    "모든 테이블이 workspace_id로 파티션되고, 버전 관리 리소스는 current/versions 쌍을 갖는다",
    f"""
{t(28, 34, "핵심 ERD — 워크스페이스 · 에이전트 자산 · 자격증명 · 거버넌스", "h")}
{t(28, 54, "모든 테이블에 workspace_id. 버전 관리 리소스는 current 테이블 + versions 테이블 쌍 (S3)", "sm")}

{box(24, 80, 232, 108, "ac")}
{t(140, 104, "workspaces", "lb mono", "middle")}
{lines(40, 126, [
  "id  PK            slug ← k8s ns",
  "max_concurrent_sessions",
  "daily_session_quota",
  "warm_pool_size · settings",
], dy=15, cls="mono xs")}

{box(24, 208, 232, 92, "c")}
{t(140, 230, "workspace_members", "lb mono", "middle")}
{lines(40, 252, [
  "PK (workspace_id, user_id)",
  "role  viewer|operator|",
  "      admin|owner",
], dy=15, cls="mono xs")}
{box(24, 316, 232, 84, "c")}
{t(140, 338, "api_keys", "lb mono", "middle")}
{lines(40, 360, [
  "key_hash  argon2id  UNIQUE",
  "workspace_id ← 키는 고정",
  "role · expires_at · revoked_at",
], dy=15, cls="mono xs")}
{box(24, 416, 232, 72, "c")}
{t(140, 438, "users", "lb mono", "middle")}
{t(40, 460, "id PK · email · name", "mono xs")}
{t(40, 476, "sso_subject", "mono xs")}

<path class="ar" d="M140 188 L140 206"/>
<path class="ar" d="M140 300 L140 314"/>
<path class="ar" d="M140 400 L140 414"/>

{box(288, 80, 224, 92, "bl")}
{t(400, 102, "agents", "lb mono", "middle")}
{lines(302, 124, [
  "PK (workspace_id, id)",
  "document JSONB · version INT",
  "archived_at",
], dy=15, cls="mono xs")}
{box(288, 188, 224, 58, "c2")}
{t(400, 210, "agent_versions", "lb mono", "middle")}
{t(302, 232, "PK (ws, agent_id, version)", "mono xs")}
<path class="ar-bl" d="M400 172 L400 186"/>
{t(410, 184, "CAS 2문장 배치", "xs tl")}

{box(288, 266, 224, 92, "c2")}
{t(400, 288, "skills / skill_versions", "lb mono", "middle")}
{t(302, 310, "같은 모양 (S3 패턴)", "xs")}
{t(302, 330, "environments /", "mono xs")}
{t(302, 346, "environment_versions", "mono xs")}

{box(288, 374, 224, 114, "pu")}
{t(400, 396, "model_cards", "lb mono", "middle")}
{lines(302, 418, [
  "provider · wire_model",
  "max_input/output_tokens",
  "reasoning JSONB",
  "pricing JSONB  ★ 요금도 데이터",
  "off_peak_preferred",
], dy=15, cls="mono xs")}
{t(400, 504, "모델 = 설정 (D12)", "xs tp", "middle")}

{box(544, 80, 216, 92, "wa")}
{t(652, 102, "vaults", "lb mono", "middle")}
{lines(556, 124, [
  "PK (workspace_id, id)",
  "document · version",
  "archived_at",
], dy=15, cls="mono xs")}
{box(544, 188, 216, 170, "da")}
{t(652, 210, "credentials", "lb mono", "middle")}
{lines(556, 232, [
  "kind  bearer|basic|",
  "      api_key_header|",
  "      mcp_oauth|env_var",
  "match_hosts TEXT[]  GIN",
  "ciphertext BYTEA  ★ 평문 없음",
  "nonce · key_version",
  "expires_at",
  "refresh_failed_at",
], dy=15, cls="mono xs")}
<path class="ar" d="M652 172 L652 186"/>

{box(544, 374, 216, 114, "c")}
{t(652, 396, "credential_events", "lb mono", "middle")}
{lines(556, 418, [
  "action  injected|refreshed|",
  "        refresh_failed|",
  "        rotated|denied",
  "host · session_id · generation",
], dy=15, cls="mono xs")}
{t(652, 480, "감사 요구를 직접 만족", "xs tb", "middle")}
<path class="ar" d="M652 358 L652 372"/>

{box(792, 80, 184, 118, "ok")}
{t(884, 102, "memory_stores", "lb mono", "middle")}
{lines(802, 124, [
  "slug UNIQUE per ws",
  "  → /mnt/memory/<slug>",
  "revision BIGINT",
], dy=15, cls="mono xs")}
{box(802, 168, 164, 22, "c2")}
{t(884, 184, "archived_at", "mono xs", "middle")}

{box(792, 214, 184, 104, "c")}
{t(884, 236, "memories", "lb mono", "middle")}
{lines(802, 258, [
  "path  UNIQUE per store",
  "content  ≤100KB",
  "content_sha256  ← CAS",
  "revision",
], dy=15, cls="mono xs")}
<path class="ar" d="M884 198 L884 212"/>

{box(792, 334, 184, 76, "c")}
{t(884, 356, "memory_versions", "lb mono", "middle")}
{t(802, 378, "author  user|session|dream", "mono xs")}
{t(802, 394, "redacted_at · redacted_by", "mono xs")}
<path class="ar" d="M884 318 L884 332"/>

{box(792, 426, 184, 62, "wa")}
{t(884, 448, "budgets", "lb mono", "middle")}
{t(802, 470, "scope ws|agent|user", "mono xs")}
{t(802, 482, "period · limit_cents", "mono xs")}

{box(24, 512, 952, 110, "c")}
{t(44, 536, "거버넌스 — 사내 확장", "lb")}
{box(44, 550, 216, 60, "wa")}
{t(152, 572, "approval_policies", "lb mono", "middle")}
{t(152, 590, "tool_pattern · required_role", "mono xs", "middle")}
{t(152, 604, "required_approvals · priority", "mono xs", "middle")}
{box(274, 550, 216, 60, "wa")}
{t(382, 572, "approvals", "lb mono", "middle")}
{t(382, 590, "UNIQUE (ws, session, tool_call_id)", "mono xs", "middle")}
{t(382, 604, "input_summary · decided_by[]", "mono xs", "middle")}
{box(504, 550, 216, 60, "da")}
{t(612, 572, "audit_log", "lb mono", "middle")}
{t(612, 590, "append-only (REVOKE UPDATE/DELETE)", "mono xs", "middle")}
{t(612, 604, "PARTITION BY RANGE · 3년", "mono xs", "middle")}
{box(734, 550, 222, 60, "c2")}
{t(845, 572, "usage_events", "lb mono", "middle")}
{t(845, 590, "input/output/cache 토큰", "mono xs", "middle")}
{t(845, 604, "list_cost_cents ← 그 시점 값 저장", "mono xs", "middle")}
""")

# ────────────────────────────────────────────────────────────── 12 ERD session
svg("12-erd-session.svg", 1000, 620,
    "세션 ERD — 이벤트와 실행 권한",
    "sessions/revision이 수용 CAS, session_executions가 실행 권한, pending→events가 순서 보장",
    f"""
{t(28, 34, "세션 ERD — 이벤트와 실행 권한", "h")}
{t(28, 54, "한 트랜잭션 안에서 revision CAS + pending INSERT + interrupt UPDATE + outbox INSERT가 함께 일어난다", "sm")}

{box(24, 80, 300, 182, "ac")}
{t(174, 104, "sessions", "lb mono", "middle")}
{lines(38, 126, [
  "PK (workspace_id, id)",
  "agent_id + agent_version   ← 버전 핀",
  "environment_id + version",
  "status  idle|running|",
  "        rescheduling|terminated",
  "stop_reason",
  "revision BIGINT  ★ 수용 CAS",
  "budget_cents / spent_cents / usage",
], dy=16, cls="mono xs")}

{box(24, 282, 300, 96, "c")}
{t(174, 304, "session_resources", "lb mono", "middle")}
{lines(38, 326, [
  "kind  file|github_repository|",
  "      memory_store|env",
  "spec JSONB · mount_path",
  "secret_ref → credentials  (평문 없음)",
], dy=15, cls="mono xs")}
<path class="ar" d="M174 262 L174 280"/>

{box(24, 398, 300, 72, "c2")}
{t(174, 420, "session_threads", "lb mono", "middle")}
{t(38, 442, "lane 단위. 1단계는 'primary' 하나", "mono xs")}
{t(38, 458, "3단계에 멀티에이전트로 확장", "mono xs")}
<path class="ar" d="M174 378 L174 396"/>

{box(352, 80, 290, 150, "wa")}
{t(497, 104, "session_pending_events", "lb mono", "middle")}
{lines(366, 126, [
  "PK (ws, session, pending_seq)",
  "pending_seq BIGSERIAL  ← 큐 순서",
  "id  UNIQUE  ← 중복 수용 방지",
  "thread_id · type · payload",
  "enqueued_at",
  "cancelled_at  ← user.interrupt",
], dy=16, cls="mono xs")}
{t(497, 222, "아직 모델이 보지 않은 입력", "xs tw", "middle")}

<path class="ar-ac" d="M497 230 L497 256"/>
{t(507, 250, "promote: peek → INSERT → DELETE", "xs tb")}

{box(352, 266, 290, 164, "ok")}
{t(497, 290, "session_events", "lb mono", "middle")}
{lines(366, 312, [
  "PK (ws, session, seq)",
  "seq  promote 시점 부여  ★ 모델 순서",
  "id  UNIQUE  ← 중복 promote 방지",
  "thread_id · type · payload",
  "generation  ← 어느 fence에서 커밋",
  "created_at",
  "PARTITION BY RANGE (created_at)",
], dy=16, cls="mono xs")}
{t(497, 422, "정본. append-only. 월 파티션", "xs tk", "middle")}

{box(352, 450, 290, 70, "c2")}
{t(497, 472, "session_streams", "lb mono", "middle")}
{t(366, 494, "stream_id · kind · partial", "mono xs")}
{t(366, 510, "재연결 시 '진행 중' 복원용. 영속 이벤트 아님", "mono xs")}

{box(670, 80, 306, 290, "bl")}
{t(823, 104, "session_executions", "lb mono", "middle")}
{t(823, 122, "실행 권한의 유일한 원천 (D3)", "xs tl", "middle")}
{lines(684, 146, [
  "id BIGSERIAL PK",
  "workspace_id · session_id · lane_id",
  "execution_id  = lane 첫 이벤트 id (멱등키)",
  "   UNIQUE (ws, session, execution_id)",
  "state  queued|running|completed|",
  "       failed|cancelled",
  "event_ids TEXT[]",
  "generation INT   ★ claim마다 +1",
  "attempt_id UUID · attempt_count",
  "lease_owner · lease_expires_at",
  "interrupt_requested_at",
  "deadline_at · error JSONB · settled_at",
], dy=16, cls="mono xs")}
{box(684, 334, 278, 28, "da")}
{t(823, 353, "UNIQUE (ws, session, lane) WHERE running", "mono xs", "middle")}

{box(670, 386, 306, 134, "c")}
{t(823, 410, "인덱스 — 전부 부분 인덱스", "lb", "middle")}
{lines(684, 434, [
  "idx_exec_claimable (created_at)",
  "   WHERE state = 'queued'",
  "idx_exec_reclaim (lease_expires_at)",
  "   WHERE state = 'running'",
  "→ 완료 행이 쌓여도 claim은 상수 시간에 가깝다",
], dy=16, cls="mono xs")}

<path class="ar-bl" d="M324 150 L348 110"/>
<path class="ar-bl" d="M644 140 L666 140"/>
{t(650, 134, "outbox", "xs tl")}

{box(24, 540, 952, 68, "pu")}
{t(44, 564, "한 트랜잭션 — 경합에서 진 쪽은 아무것도 남기지 않는다", "lb")}
{t(44, 586, "UPDATE sessions SET revision=revision+1 WHERE revision=:expected   →   INSERT pending   →   UPDATE executions(interrupt)   →   INSERT executions(queued)", "mono xs")}
{t(44, 602, "revision CAS가 실패하면 롤백되므로 이벤트·인터럽트·outbox 중 어느 것도 새지 않는다", "xs")}
""")

# ────────────────────────────────────────────────────────────── 13 하네스 루프
svg("13-harness-turn-loop.svg", 1000, 680,
    "하네스 턴 루프와 waterfall 훅",
    "DeepSeek Harness의 turn/step 구조를 AWP 이벤트 어휘로 옮긴 루프. 정책은 훅으로 끼운다",
    f"""
{t(28, 34, "하네스 턴 루프 — turn / step 과 waterfall 훅", "h")}
{t(28, 54, "DeepSeek Harness의 turn/step 구조를 가져와 AWP 이벤트 어휘로 옮겼다. 루프를 고치지 않고 정책을 끼운다", "sm")}

{box(24, 80, 620, 540, "c")}
{t(44, 104, "claim(fence) 획득 후", "lb mono")}

{box(44, 118, 580, 36, "ok")}
{t(334, 141, "turn 시작  →  session.status_running", "lb mono", "middle")}

{box(44, 164, 580, 50, "wa")}
{t(56, 184, "① pre_step 훅", "lb mono")}
{t(56, 202, "pending → promote → events (seq 부여) · 입력 재작성/거부 가능", "xs")}
{t(612, 184, "waterfall", "xs tw", "end")}

{box(44, 224, 580, 50, "bl")}
{t(56, 244, "② 프롬프트 조립", "lb mono")}
{t(56, 262, "시스템 섹션 + 툴 스키마(정렬 고정) + 스킬·메모리 안내문  ← 캐시 prefix가 여기서 결정된다", "xs")}

{box(44, 284, 580, 44, "bl")}
{t(56, 304, "③ derive_messages(events)", "lb mono")}
{t(56, 320, "압축 경계부터. 실패 시도(agent.message_attempt)는 제외", "xs")}

{box(44, 338, 580, 36, "pu")}
{t(56, 361, "④ 요청 동결 — 이후 재시도는 ②③을 반복하지 않는다  (캐시 보존)", "lb mono")}

{box(44, 384, 580, 86, "ac")}
{t(56, 404, "⑤ step  →  span.model_request_start", "lb mono")}
{t(56, 422, "ModelPort.stream(card, messages, tools, effort, max_tokens)", "mono xs")}
{lines(68, 440, [
  "text_delta      → agent.message_chunk   (스트림 전용)",
  "thinking_delta  → agent.thinking        (진행 신호)",
], dy=14, cls="mono xs")}
{t(340, 440, "tool_call_*  → agent.tool_use", "mono xs")}
{t(340, 454, "usage/finish → span.model_request_end", "mono xs")}

{box(44, 480, 580, 86, "wa")}
{t(56, 500, "⑥ 툴 실행 파이프라인", "lb mono")}
{lines(68, 518, [
  "pre_execute   권한 정책 판정 → 승인 필요 시 pending 적재 후 중단 · 예산 · 감사",
  "execute       fence 검증 → SandboxPort 또는 호스트 함수",
  "post_execute  100K자 초과 spill · 비밀 레다크션 · 감사   → agent.tool_result",
], dy=16, cls="mono xs")}

{box(44, 576, 580, 32, "c2")}
{t(334, 597, "⑦ 툴이 다음 요청을 요구하거나 새 입력이 도착 → ⑤로 (다음 step)", "sm", "middle")}

<path class="ar-ac" d="M630 592 L646 592 L646 400 L630 400" />

{box(668, 80, 308, 206, "pu")}
{t(822, 104, "waterfall 훅 — next() 위임형", "lb", "middle")}
{lines(682, 128, [
  "pre_step      입력 재작성/거부",
  "pre_request   캐시 진단 · 요청 크기",
  "pre_execute   ★ 권한·예산·감사",
  "execute       샌드박스 / MCP",
  "post_execute  spill · 레다크션",
  "turn_stopping 메모리 동기화 (serial)",
], dy=22, cls="mono sm")}
{t(682, 268, "정책 추가 = 리스너 추가. 루프 무변경", "xs tp")}

{box(668, 300, 308, 150, "ok")}
{t(822, 324, "dsh에서 가져온 것", "lb", "middle")}
{lines(682, 346, [
  "“Model-visible means logged”",
  "deriveMessages() 투영",
  "assistant/attempt  → 실패를 로그에만",
  "turn / step 구분",
  "요청 freeze — 재시도가 assembly 반복 안 함",
  "capability seam = 정의+구현+소비 3역할",
], dy=17, cls="sm")}

{box(668, 464, 308, 156, "ac")}
{t(822, 488, "턴 종료 — 순서가 중요하다", "lb", "middle")}
{lines(682, 512, [
  "① 메모리 동기화 (fence 재검증)",
  "    idle 이전에 끝나야 한다",
  "② usage_events 적립 · 예산 확인",
  "③ stop_reason 결정",
  "    requires_action | budget_reached",
  "    interrupted | end_turn",
  "④ session.status_idle  ← 정확히 한 번",
  "⑤ settle(completed|failed|cancelled)",
], dy=17, cls="sm")}

{t(28, 648, "stop_reason을 이름 매칭으로 정하지 않는다 — ToolRegistry가 각 툴의 kind(builtin|mcp|custom|delegation)를 실체로 들고 있다.", "sm")}
{t(28, 668, "승인 재개는 ToolGrant(tool_call_id)로 그 호출에만 executor를 되살린다 — 레퍼런스가 '결과 없이 재개'되는 결함을 피한다.", "sm")}
""")

# ────────────────────────────────────────────────────────────── 14 비용 지렛대
svg("14-model-cost-levers.svg", 1000, 620,
    "DeepSeek V4.1-Flash 비용 지렛대",
    "캐시 히트가 미스의 1/50, off-peak가 peak의 1/2. 프롬프트 prefix 안정화가 비용의 지배 변수다",
    f"""
{t(28, 34, "비용 지렛대 — 캐시 50배, off-peak 2배", "h")}
{t(28, 54, "deepseek-flash 요금 (USD / 1M 토큰). 이 두 배수가 다른 어떤 최적화보다 크다", "sm")}

{box(24, 80, 466, 206, "c")}
{t(44, 104, "요금표", "lb")}
{t(44, 128, "                        peak      off-peak", "mono sm")}
{t(44, 150, "입력 (캐시 히트)        $0.006     $0.003", "mono sm")}
{t(44, 172, "입력 (캐시 미스)        $0.30      $0.15", "mono sm")}
{t(44, 194, "출력                    $1.20      $0.60", "mono sm")}
{box(44, 210, 426, 62, "wa")}
{t(60, 230, "peak = UTC 01:00–04:00, 06:00–10:00 (월–금)", "mono xs")}
{t(60, 248, "한국시간 10:00–13:00, 15:00–19:00  ← 정확히 업무 시간", "mono xs")}
{t(60, 264, "그 외 전부 off-peak. off-peak는 peak의 절반", "mono xs")}

{box(510, 80, 466, 206, "pu")}
{t(530, 104, "배수", "lb")}
<rect x="530" y="124" width="420" height="26" rx="4" fill="var(--da)" opacity="0.85"/>
{t(540, 142, "캐시 미스 입력  $0.30", "mono sm" , "start")}
<rect x="530" y="158" width="8.4" height="26" rx="2" fill="var(--ok)"/>
{t(548, 176, "캐시 히트 입력  $0.006    ÷ 50", "mono sm")}
<rect x="530" y="196" width="420" height="22" rx="4" fill="var(--wa)" opacity="0.8"/>
{t(540, 212, "peak", "mono sm")}
<rect x="530" y="224" width="210" height="22" rx="4" fill="var(--ac)" opacity="0.8"/>
{t(540, 240, "off-peak    ÷ 2", "mono sm")}
{box(530, 254, 420, 20, "c2")}
{t(740, 269, "최악(peak·미스) 대비 최선(off-peak·히트) = 100배", "lb mono", "middle")}

{box(24, 306, 952, 150, "ac")}
{t(44, 330, "구체 계산 — 시스템+툴 8K, 대화 누적 평균 60K, 10 step, 출력 step당 2K", "lb")}
{t(44, 356, "시나리오                                입력 토큰                      출력     peak 비용    off-peak", "mono sm")}
<line x1="44" y1="364" x2="956" y2="364" class="ln"/>
{t(44, 384, "캐시 전무 (prefix가 매 step 바뀜)        10×68K = 680K 전부 미스        20K      $0.228      $0.114", "mono sm")}
{t(44, 406, "prefix 캐시 적중                        히트 600K · 미스 80K           20K      $0.052      $0.026", "mono sm")}
<line x1="44" y1="414" x2="956" y2="414" class="ln"/>
{t(44, 434, "개선                                                                            4.4배       8.8배 (최악 대비)", "mono sm bold")}
{t(44, 450, "세션 1만 건/월 → 월 $2,280 → $260", "sm tb")}

{box(24, 476, 466, 124, "da")}
{t(44, 500, "캐시를 깨는 것 — 금지 목록", "lb tr")}
{lines(44, 522, [
  "시스템 프롬프트에 현재 시각·요청 ID·세션 ID",
  "툴 목록을 매 요청 다른 순서로 직렬화",
  "재시도마다 프롬프트 재조립  (→ ④ 요청 동결로 차단)",
  "메모리·스킬 안내문을 요청마다 재생성",
  "압축을 메모리에만 들고 있기",
  "모델 카드를 턴 중간에 바꾸기 (캐시는 모델 스코프)",
], dy=16, cls="xs")}

{box(510, 476, 466, 124, "ok")}
{t(530, 500, "지렛대 순서 — 무료부터", "lb tk")}
{lines(530, 522, [
  "① 캐시 prefix 안정화        무료 · 최대 4.4배",
  "② off-peak 이동             무료(지연 감수) · 2배",
  "③ 출력 토큰 위생            출력이 입력보다 4배 비싸다",
  "④ 툴 결과 상한·spill        컨텍스트 폭증 차단",
  "⑤ 압축 시점 조정            측정 필요",
  "⑥ reasoning_effort 하향     품질을 거래. 측정 후에만",
  "⑦ 더 작은 모델로 분기       ★ 마지막 — 캐시가 쪼개진다",
], dy=14, cls="xs")}
""")

# ────────────────────────────────────────────────────────────── 15 샌드박스 티어
svg("15-sandbox-tiers.svg", 1000, 660,
    "샌드박스 2티어와 툴 매트릭스",
    "내장 툴 8개 중 7개는 샌드박스 셸이 필요 없다. 그래서 Wasm을 기본 티어로 둘 수 있다",
    f"""
{t(28, 34, "샌드박스 2티어 — 커널을 건드리지 않는다", "h")}
{t(28, 54, "핵심 발견: 내장 툴 8개 중 7개는 샌드박스 셸이 필요 없다. 프로세스 세계가 필요한 것은 bash 하나", "sm")}

{box(24, 80, 952, 170, "c")}
{t(44, 104, "툴 매트릭스 — 각 툴이 실제로 무엇을 필요로 하는가", "lb")}
{t(44, 130, "툴            실행 위치            샌드박스 셸 필요?", "mono sm")}
<line x1="44" y1="138" x2="520" y2="138" class="ln"/>
{lines(44, 158, [
  "read          호스트 함수          ✗",
  "write         호스트 함수          ✗",
  "edit          호스트 함수          ✗",
  "glob          호스트 함수          ✗",
  "grep          호스트 (ripgrep)     ✗",
], dy=17, cls="mono sm")}
{lines(300, 158, [
  "web_fetch     신뢰 영역            ✗",
  "web_search    신뢰 영역            ✗",
], dy=17, cls="mono sm")}
{box(300, 206, 220, 32, "da")}
{t(410, 227, "bash          샌드박스       ✓", "mono sm bold", "middle")}
{box(556, 120, 400, 112, "ac")}
{t(756, 144, "그래서 질문이 바뀐다", "lb", "middle")}
{t(756, 168, "“Wasm으로 bash를 어떻게 돌리지?”  (✗)", "sm", "middle")}
{t(756, 192, "“이 에이전트가 정말 bash가 필요한가?”  (✓)", "sm bold", "middle")}
{t(756, 218, "사내 에이전트 다수 — 문서 검토·리포트·데이터 추출 — 는 필요 없다", "xs", "middle")}

{box(24, 268, 306, 250, "ok")}
{t(177, 292, "티어 W  (기본)", "lb", "middle")}
{t(177, 310, "Wasmtime + WASI preview 1", "mono sm", "middle")}
{box(38, 322, 278, 28, "c2")}
{t(177, 341, "ambient authority = 0", "lb mono", "middle")}
{lines(38, 368, [
  "bash          ✗",
  "기동          수 ~ 수십 ms",
  "메모리        수 ~ 수십 MB",
  "강제 수준     enforced (구성상)",
  "소켓          제공하지 않음",
  "network       wasi:http → 프록시만",
  "CPU 상한      fuel / epoch 인터럽션",
  "코드 실행     run_code (CPython WASI)",
], dy=17, cls="mono xs")}
{box(38, 486, 278, 24, "ac")}
{t(177, 503, "Restricted PSS를 그대로 통과", "xs", "middle")}

{box(346, 268, 306, 250, "wa")}
{t(499, 292, "티어 P", "lb", "middle")}
{t(499, 310, "bubblewrap + Landlock", "mono sm", "middle")}
{box(360, 322, 278, 28, "c2")}
{t(499, 341, "argv 래핑 · 비특권 user namespace", "lb mono", "middle")}
{lines(360, 368, [
  "bash          ✓",
  "기동          수십 ~ 수백 ms",
  "메모리        수십 ~ 수백 MB",
  "강제 수준     full 또는 partial (ABI)",
  "network       --unshare-net (기본: 없음)",
  "              pasta 시 프록시만",
  "Landlock      ABI1 5.13+ / ABI4 6.7+ 네트워크",
  "요구사항      k8s 1.33 userns 또는 seccomp",
], dy=17, cls="mono xs")}
{box(360, 486, 278, 24, "da")}
{t(499, 503, "불가하면 unsupported로 보고 → 티어 W만", "xs", "middle")}

{box(668, 268, 308, 250, "c2")}
{t(822, 292, "티어 V  (1단계 비범위)", "lb", "middle")}
{t(822, 310, "gVisor / Kata", "mono sm", "middle")}
{lines(682, 340, [
  "커널 취약점이 위협 모델에",
  "들어가면 이것이 정답이다.",
  "",
  "유저스페이스 커널(Sentry)이",
  "모든 syscall을 가로채므로",
  "호스트 커널 공격 표면이 작다.",
  "",
  "Anthropic도 같은 구분:",
  "  Claude Code  → bubblewrap",
  "  Claude 웹    → gVisor",
], dy=17, cls="xs")}
{box(682, 486, 280, 24, "ac")}
{t(822, 503, "SandboxPort가 막지 않는다 — 추가는 어댑터 1개", "xs", "middle")}

{box(24, 538, 466, 108, "da")}
{t(44, 562, "검토했지만 쓰지 않는 Wasm 선택지", "lb tr")}
{lines(44, 584, [
  "WASIX (Wasmer)      벤더 확장. ambient authority 0을 깎는다",
  "container2wasm      Linux 전체 에뮬레이션 → 느리다",
  "Pyodide             Emscripten 타깃. 네이티브 휠이 필요해지면 재검토",
  "Spin / wasmCloud    앱 호스팅 플랫폼. 우리는 툴 샌드박스가 필요",
], dy=16, cls="xs")}

{box(510, 538, 466, 108, "wa")}
{t(530, 562, "티어 W의 최대 리스크 — 경계 검사가 우리 코드다", "lb tw")}
{t(530, 584, "호스트 툴 5개가 워커 프로세스에서 돌므로 bwrap/Landlock의 2차 방어선이 없다", "xs")}
{t(530, 602, "resolve_in_workspace() 단일 진입점 + CI 검사 + 퍼징이 유일한 방어", "mono xs")}
{t(530, 620, "그래서 티어 W와 티어 P의 테스트 밀도를 다르게 가져간다", "xs")}
{t(530, 638, "tests/security/test_path_escape.py — ../ · 절대경로 · 유니코드 · 널바이트", "mono xs")}
""")

# ────────────────────────────────────────────────────────────── 16 샌드박스 생애주기
svg("16-sandbox-lifecycle.svg", 1000, 540,
    "샌드박스 생애주기",
    "지연 프로비저닝 → ready → active → idle → 스냅샷 → gone. 상태는 DB와 오브젝트 스토어에 있다",
    f"""
{t(28, 34, "샌드박스 생애주기 — cattle", "h")}
{t(28, 54, "상태는 샌드박스가 아니라 (DB + 오브젝트 스토어)에 있다. 죽으면 같은 스펙으로 다시 만든다", "sm")}

{box(40, 92, 120, 48, "c2")}
{t(100, 122, "none", "lb mono", "middle")}
<path class="ar-ac" d="M162 116 L218 116"/>
{t(190, 104, "첫 툴 호출", "xs tb", "middle")}
{t(190, 136, "(지연)", "xs", "middle")}

{box(220, 92, 170, 48, "bl")}
{t(305, 116, "provisioning", "lb mono", "middle")}
{t(305, 134, "W: 수 ms  ·  P: 수 s", "xs", "middle")}
<path class="ar-ac" d="M392 116 L448 116"/>

{box(450, 92, 120, 48, "ok")}
{t(510, 122, "ready", "lb mono", "middle")}
<path class="ar-ac" d="M572 116 L628 116"/>

{box(630, 92, 120, 48, "ok")}
{t(690, 122, "active", "lb mono", "middle")}
<path class="ar" d="M690 142 L690 170 L510 170 L510 142"/>
{t(600, 186, "재사용", "xs", "middle")}

<path class="ar" d="M752 116 L808 116"/>
{box(810, 92, 120, 48, "wa")}
{t(870, 116, "idle", "lb mono", "middle")}
{t(870, 134, "5분 타이머", "xs", "middle")}

<path class="ar" d="M870 142 L870 196"/>
{box(790, 196, 160, 48, "pu")}
{t(870, 220, "snapshot", "lb mono", "middle")}
{t(870, 238, "tar.zst → 오브젝트", "xs", "middle")}
<path class="ar" d="M788 220 L700 220"/>
{box(560, 196, 138, 48, "c2")}
{t(629, 226, "gone", "lb mono", "middle")}

<path class="ar-ac" d="M560 220 L400 220 L400 142"/>
{t(470, 212, "다음 턴 → 스냅샷에서 복원", "xs tb", "middle")}

{box(24, 272, 466, 172, "c")}
{t(44, 296, "프로비저닝 단계", "lb")}
{t(44, 320, "단계          티어 W                 티어 P", "mono sm")}
<line x1="44" y1="328" x2="470" y2="328" class="ln"/>
{lines(44, 348, [
  "프로비저닝    Store + preopen        워크스페이스 + 패키지",
  "              프로세스 생성 없음",
  "웜업          없음 (즉시)            헬스 프로브 · 복원 · 설치",
  "스냅샷        /workspace tar         동일",
  "아이들 회수   Store drop (메모리)    디렉터리 정리",
  "복원          preopen 재구성         tar 복원",
], dy=16, cls="mono xs")}

{box(510, 272, 466, 172, "ac")}
{t(530, 296, "프로비저닝 전략", "lb")}
{lines(530, 322, [
  "지연 프로비저닝   기본. 툴을 안 쓰는 세션은 비용 0",
  "병렬 시작         모델 호출은 이벤트 로그만으로 즉시 시작,",
  "                  샌드박스 준비는 백그라운드",
  "웜 풀             티어 P만. workspace.warm_pool_size",
  "사전 프로비저닝   packages가 무거울 때만 옵트인",
], dy=17, cls="sm")}
{box(530, 410, 426, 24, "wa")}
{t(743, 427, "첫 툴 호출 시점엔 보통 준비되어 있다", "xs", "middle")}

{box(24, 464, 952, 62, "c2")}
{t(44, 488, "sandbox_instances 테이블이 추적하는 것", "lb")}
{t(44, 510, "tier · host_worker_id · state · sandbox_enforcement(+reason) · egress_enforcement · snapshot_key · last_activity_at", "mono xs")}
{t(640, 488, "종료 실패 자원은 runtime_orphans에 기록 → 스케줄러가 정리", "sm", "start")}
""")

# ────────────────────────────────────────────────────────────── 17 k8s 토폴로지
svg("17-k8s-topology.svg", 1020, 680,
    "Kubernetes 인스턴스 토폴로지",
    "awp-system 공통, 부서별 awp-runtime 네임스페이스, awp-data 상태. 샌드박스는 워커 안에 있다",
    f"""
{t(28, 34, "Kubernetes 인스턴스 토폴로지", "h")}
{t(28, 54, "샌드박스가 Pod가 아니므로 '샌드박스 네임스페이스'가 없다. 부서 격리가 runtime-worker 네임스페이스로 이동한다", "sm")}

{box(24, 80, 972, 150, "ok")}
{t(44, 104, "ns  awp-system", "lb mono")}
{t(976, 104, "플랫폼 공통 · 신뢰", "sm tk", "end")}
{box(44, 118, 228, 96, "c2")}
{t(158, 140, "control-plane", "lb mono", "middle")}
{t(158, 158, "Deployment  3 ~ 20", "xs", "middle")}
{t(158, 174, "HPA: RPS + CPU 70%", "mono xs", "middle")}
{t(158, 192, "API · 승인 · 감사 · Console 서빙", "xs", "middle")}
{t(158, 208, "무상태", "xs", "middle")}
{box(284, 118, 228, 96, "wa")}
{t(398, 140, "egress-proxy", "lb mono", "middle")}
{t(398, 158, "Deployment  2 ~ 10", "xs", "middle")}
{t(398, 174, "HPA: 활성 연결 수", "mono xs", "middle")}
{t(398, 192, "MITM TLS · allowlist · 주입", "xs", "middle")}
{t(398, 208, "모델 키를 아는 유일한 Pod", "xs tw", "middle")}
{box(524, 118, 228, 96, "c2")}
{t(638, 140, "scheduler", "lb mono", "middle")}
{t(638, 158, "Deployment  2 (리더 1)", "xs", "middle")}
{t(638, 174, "pg_advisory_lock", "mono xs", "middle")}
{t(638, 192, "cron · 보존 · GC · 파티션", "xs", "middle")}
{t(638, 208, "작업은 멱등", "xs", "middle")}
{box(764, 118, 212, 96, "pu")}
{t(870, 140, "migrate", "lb mono", "middle")}
{t(870, 158, "Job", "xs", "middle")}
{t(870, 174, "helm pre-upgrade 훅", "mono xs", "middle")}
{t(870, 192, "Alembic. 단일 실행 보장", "xs", "middle")}
{t(870, 208, "스키마 먼저, 코드 나중", "xs", "middle")}

{box(24, 252, 972, 220, "bl")}
{t(44, 276, "ns  awp-runtime-<부서 slug>   ← 부서당 하나", "lb mono")}
{t(976, 276, "실행 평면 · 준신뢰", "sm tl", "end")}
{t(44, 296, "D7: 부서 = 네임스페이스 = ResourceQuota = 예산 집행 지점", "sm tb")}

{box(44, 310, 300, 148, "c")}
{t(194, 332, "awp-runtime-법무", "lb mono", "middle")}
{box(58, 342, 272, 70, "ok")}
{t(194, 362, "runtime-worker  Deployment", "lb mono", "middle")}
{t(194, 378, "KEDA  0 ~ 50", "mono xs", "middle")}
{t(194, 394, "하네스 + 샌드박스가 같은 Pod 안", "xs", "middle")}
{t(194, 408, "k8s API RBAC 거의 비어 있음", "xs", "middle")}
{box(58, 418, 132, 32, "wa")}{t(124, 438, "ResourceQuota", "mono xs", "middle")}
{box(198, 418, 132, 32, "wa")}{t(264, 438, "NetworkPolicy", "mono xs", "middle")}

{box(356, 310, 300, 148, "c")}
{t(506, 332, "awp-runtime-재경", "lb mono", "middle")}
{box(370, 342, 272, 70, "c2")}
{t(506, 368, "replicas = 0", "lb mono", "middle")}
{t(506, 388, "일이 없으면 Pod 0개", "xs", "middle")}
{t(506, 404, "첫 세션 콜드 스타트 ~10s", "xs", "middle")}
{box(370, 418, 132, 32, "wa")}{t(436, 438, "ResourceQuota", "mono xs", "middle")}
{box(510, 418, 132, 32, "wa")}{t(576, 438, "NetworkPolicy", "mono xs", "middle")}

{box(668, 310, 308, 148, "ac")}
{t(822, 332, "KEDA ScaledObject", "lb mono", "middle")}
{lines(682, 354, [
  "minReplicaCount: 0",
  "maxReplicaCount: 50",
  "cooldownPeriod: 300",
  "trigger: postgresql",
  "  SELECT count(*) FROM",
  "   session_executions",
  "   WHERE workspace_id = …",
  "     AND state = 'queued'",
], dy=13, cls="mono xs")}

{box(24, 494, 486, 112, "c")}
{t(44, 518, "ns  awp-data", "lb mono")}
{box(44, 530, 216, 62, "c2")}
{t(152, 552, "postgres  (CloudNativePG)", "lb mono", "middle")}
{t(152, 570, "primary 1 + replica 2", "xs", "middle")}
{t(152, 584, "자동 failover ~30s < lease TTL 90s", "xs tb", "middle")}
{box(272, 530, 224, 62, "c2")}
{t(384, 552, "object store", "lb mono", "middle")}
{t(384, 570, "외부 S3 권장 / MinIO", "xs", "middle")}
{t(384, 584, "스냅샷 · 업로드 · 산출물", "xs", "middle")}

{box(526, 494, 470, 112, "da")}
{t(546, 518, "per-session Pod 방식 대비 얻는 것", "lb tr")}
{t(546, 540, "세션 시작마다 k8s API 호출          → 없음", "mono xs")}
{t(546, 556, "기동 지연 수 초 ~ 수십 초           → 티어 W 수 ms", "mono xs")}
{t(546, 572, "워커의 Pod create/delete/exec RBAC  → 불필요", "mono xs")}
{t(546, 588, "노드당 Pod 수 한도                 → 워커당 수십 세션", "mono xs")}

{box(24, 622, 972, 44, "wa")}
{t(44, 642, "우아한 종료 — terminationGracePeriodSeconds: 600 + preStop drain", "lb mono")}
{t(44, 658, "drain: worker_instances.draining=true → 새 claim 중지 → 진행 중 execution 하트비트 유지 → settle 후 종료. 600s 초과 시 lease 만료 경로로 복구", "xs")}
""")

# ────────────────────────────────────────────────────────────── 18 네트워크/egress
svg("18-network-egress.svg", 1020, 680,
    "네트워크와 자격증명 egress",
    "샌드박스는 (워크스페이스, 세션, 호스트)만 알고 토큰은 모른다. egress-proxy가 요청 시점에 주입한다",
    f"""
{t(28, 34, "네트워크와 자격증명 egress — 유출할 토큰이 존재하지 않는다", "h")}
{t(28, 54, "샌드박스는 (workspace_id, session_id, hostname)만 안다. 주입은 신뢰 영역에서 요청 시점에 일어난다", "sm")}

{box(24, 80, 466, 236, "ac")}
{t(44, 104, "주입 흐름", "lb")}
{box(44, 118, 426, 30, "c2")}
{t(56, 138, "① 샌드박스에서  curl https://api.github.com/…", "mono xs")}
<path class="ar-ac" d="M257 150 L257 164"/>
{box(44, 164, 426, 30, "wa")}
{t(56, 184, "② egress-proxy — 세션 식별 (클라이언트 인증서 / 세션 토큰)", "mono xs")}
<path class="ar-ac" d="M257 196 L257 210"/>
{box(44, 210, 426, 30, "wa")}
{t(56, 230, "③ allowed_hosts 검사 → 불일치면 403 + denied 적립", "mono xs")}
<path class="ar-ac" d="M257 242 L257 256"/>
{box(44, 256, 426, 46, "ok")}
{t(56, 274, "④ 제어 평면 조회 (ws, session, host) → credential", "mono xs")}
{t(56, 290, "     세션의 vault_ids 범위 안 + fence generation 검증", "mono xs")}
<path class="ar-ac" d="M257 304 L257 318"/>

{box(24, 318, 466, 110, "pu")}
{t(44, 342, "⑤ 복호화 후 Authorization 헤더 주입", "lb mono")}
{t(44, 360, "    프록시 메모리에만. 로그 금지", "mono xs")}
{t(44, 384, "⑥ 업스트림으로 포워드", "lb mono")}
{t(44, 408, "⑦ credential_events(injected, host, generation) 적립  ← 감사", "lb mono")}

{box(510, 80, 486, 348, "c")}
{t(530, 104, "허용된 흐름 — 이것만", "lb")}
{lines(530, 130, [
  "인터넷        → Ingress (TLS) → control-plane:8000",
  "",
  "control-plane → postgres:5432          (primary)",
  "control-plane → objectstore:443",
  "control-plane → egress-proxy:8443",
  "",
  "runtime-worker → postgres:5432         역할 awp_worker",
  "runtime-worker → control-plane:8000    credential 대행",
  "runtime-worker → egress-proxy:3128     모델·web·MCP",
  "runtime-worker → kube-dns:53",
  "",
  "egress-proxy  → 인터넷 (allowlist 통과분)",
  "egress-proxy  → 사내 시스템 (allowlist)",
], dy=17, cls="mono sm")}
{box(530, 352, 446, 64, "da")}
{t(753, 374, "샌드박스의 네트워크", "lb tr", "middle")}
{t(753, 392, "티어 W — 소켓 없음 (wasi:sockets 미제공)", "mono xs", "middle")}
{t(753, 408, "티어 P — --unshare-net. 네트워크 없음. pasta 시 프록시만", "mono xs", "middle")}

{box(24, 450, 486, 210, "wa")}
{t(44, 474, "티어 P egress 강제의 5조건 — AND", "lb")}
{lines(44, 500, [
  "① 샌드박스 ns에 default-deny egress NetworkPolicy,",
  "    egress-proxy만 허용",
  "② CNI가 NetworkPolicy를 실제로 강제 (Calico / Cilium)",
  "③ hostNetwork: false, hostPort 없음",
  "④ automountServiceAccountToken: false",
  "⑤ egress-proxy가 세션별 CA로 MITM + 호스트 allowlist",
], dy=18, cls="sm")}
{box(44, 614, 446, 34, "da")}
{t(267, 635, "하나라도 빠지면 advisory → egress:required 세션 생성 거부", "sm", "middle")}

{box(526, 450, 470, 210, "ok")}
{t(546, 474, "왜 워커 안의 샌드박스가 위험한가 — 그리고 해결", "lb tk")}
{t(546, 498, "샌드박스가 워커 Pod의 netns를 공유하면 PostgreSQL IP:5432에", "sm")}
{t(546, 514, "직접 접속할 수 있다. 반드시 막아야 한다.", "sm tr")}
{box(546, 526, 430, 118, "c2")}
{lines(558, 546, [
  "bwrap --unshare-user --unshare-pid --unshare-ipc",
  "      --unshare-uts --unshare-net   ★ 자기 netns",
  "      --die-with-parent --new-session",
  "      --clearenv --setenv PATH /usr/bin:/bin",
  "      --bind <workspace> /workspace",
  "      --tmpfs /tmp --proc /proc --dev /dev",
], dy=16, cls="mono xs")}
{t(546, 656, "--unshare-pid: 워커의 /proc/<pid>/environ을 못 읽는다  ·  --clearenv: DB DSN 상속 안 됨", "xs")}
""")

# ────────────────────────────────────────────────────────────── 19 코드베이스
svg("19-codebase-tree.svg", 1020, 700,
    "코드베이스 구조 — 레이어별 색",
    "uv 워크스페이스 모노레포. 25패키지 + 5앱. 색이 레이어를 나타낸다",
    f"""
{t(28, 34, "코드베이스 구조 — 25 패키지 + 5 앱", "h")}
{t(28, 54, "색 = 레이어. 패키지는 라이브러리이고 프로세스를 만들지 않는다. 앱만 프로세스를 만든다", "sm")}

{box(24, 78, 972, 28, "c2")}
{t(40, 97, "L1 도메인", "xs")}
<rect x="104" y="84" width="16" height="16" rx="3" class="c2" style="fill:var(--card2)"/>
{t(128, 97, "L2 Store 구현", "xs")}
<rect x="214" y="84" width="16" height="16" rx="3" style="fill:var(--ok2);stroke:var(--ok)"/>
{t(238, 97, "L3 Store 인터페이스", "xs")}
<rect x="350" y="84" width="16" height="16" rx="3" style="fill:var(--wa2);stroke:var(--wa)"/>
{t(374, 97, "L4 유스케이스", "xs")}
<rect x="468" y="84" width="16" height="16" rx="3" style="fill:var(--bl2);stroke:var(--bl)"/>
{t(492, 97, "L5 HTTP · 어댑터 · 하네스 · 샌드박스", "xs")}
<rect x="724" y="84" width="16" height="16" rx="3" style="fill:var(--ac2);stroke:var(--ac)"/>
{t(748, 97, "L6 조립", "xs")}
<rect x="812" y="84" width="16" height="16" rx="3" style="fill:var(--pu2);stroke:var(--pu)"/>
{t(836, 97, "L7 앱 · 횡단", "xs")}

{box(24, 118, 486, 552, "c")}
{t(44, 142, "packages/   — 라이브러리", "lb mono")}

{box(40, 154, 454, 28, "c2")}{t(52, 174, "ma_domain                 순수 타입. 의존성 0", "mono xs")}
{box(40, 188, 454, 28, "ok")}{t(52, 208, "ma_store                  Protocol + union 결과", "mono xs")}
{box(40, 222, 454, 28, "c2")}{t(52, 242, "ma_store_memory           dict + deepcopy", "mono xs")}
{box(40, 256, 454, 28, "c2")}{t(52, 276, "ma_store_sql              SQLAlchemy Core", "mono xs")}
{box(40, 290, 454, 28, "c2")}{t(52, 310, "ma_sql                    Engine Port + 방언", "mono xs")}
{box(40, 324, 454, 28, "wa")}{t(52, 344, "ma_application            유스케이스 · Port 선언", "mono xs")}
{box(40, 358, 454, 42, "bl")}
{t(52, 376, "ma_api                    FastAPI + pydantic wire", "mono xs")}
{t(64, 392, "  internal/  (1단계)      compat/  (2단계, 독립)", "mono xs")}
{box(40, 406, 454, 28, "bl")}{t(52, 426, "ma_adapters_sql / _blob / _runtime", "mono xs")}
{box(40, 440, 454, 56, "bl")}
{t(52, 458, "ma_harness                턴 루프 · 훅 · ModelPort", "mono xs")}
{t(52, 474, "ma_model_deepseek         DeepSeek 공식 어댑터", "mono xs")}
{t(52, 490, "ma_model_openai_compat · ma_model_dsh (2단계)", "mono xs")}
{box(40, 502, 454, 72, "bl")}
{t(52, 520, "ma_sandbox                SandboxPort · ConfinedArgv", "mono xs")}
{t(52, 536, "                          resolve_in_workspace()  ★", "mono xs")}
{t(52, 552, "ma_sandbox_wasm (기본) · ma_sandbox_bwrap", "mono xs")}
{t(52, 568, "ma_sandbox_local (테스트 전용) · ma_egress", "mono xs")}
{box(40, 580, 454, 28, "ac")}{t(52, 600, "ma_platform               WorkspaceAppRegistry · create_app", "mono xs")}
{box(40, 614, 454, 46, "pu")}
{t(52, 632, "ma_auth · ma_governance · ma_observability", "mono xs")}
{t(52, 648, "ma_connectors · ma_schema  ← 스키마의 유일한 진실", "mono xs")}

{box(526, 118, 470, 216, "pu")}
{t(546, 142, "apps/   — 프로세스. 환경변수를 읽는 유일한 레이어", "lb mono")}
{box(542, 154, 438, 28, "c2")}{t(554, 174, "control_plane   API · 승인 · 감사 · Console 서빙", "mono xs")}
{box(542, 188, 438, 28, "c2")}{t(554, 208, "runtime_worker  claim → fence → 하네스 → settle", "mono xs")}
{box(542, 222, 438, 28, "c2")}{t(554, 242, "scheduler       cron · 보존 · GC · 파티션 (리더 선출)", "mono xs")}
{box(542, 256, 438, 28, "c2")}{t(554, 276, "egress_proxy    MITM · allowlist · 자격증명 주입", "mono xs")}
{box(542, 290, 438, 28, "c2")}{t(554, 310, "cli             aw — apply · 세션 추적 · 진단", "mono xs")}

{box(526, 346, 470, 142, "ac")}
{t(546, 370, "앱 내부 모양 — 전부 같다", "lb")}
{lines(546, 394, [
  "config.py       os.environ → 타입된 Config 1회  ★ 유일",
  "components.py   어떤 구현을 쓸지 선택 (기본값 = 생성자)",
  "assembly.py     생명주기 · 역순 정리 · 라우터 마운트",
  "http.py         미들웨어 순서",
  "serve.py        기동 · 시그널 · graceful shutdown",
  "__main__.py     config → components → assembly → serve",
], dy=17, cls="mono sm")}

{box(526, 500, 470, 170, "c")}
{t(546, 524, "그 밖에", "lb")}
{lines(546, 548, [
  "web/console/    React 19 + Vite + TanStack Query",
  "deploy/         helm · overlays · argocd · compose",
  "tests/          unit · contract · integration · e2e · security",
  "tools/          check_architecture · probe_capabilities · seed_dev",
  ".importlinter   레이어 계약",
], dy=17, cls="mono sm")}
{box(546, 636, 430, 24, "wa")}
{t(761, 653, "레퍼런스 173패키지 → 22개. 경계는 모듈 + CI로 그린다", "xs", "middle")}
""")

# ────────────────────────────────────────────────────────────── 20 트레이서빌리티
svg("20-traceability.svg", 1040, 700,
    "개념 → API → 레이어 → 패키지 → 테이블 → 인스턴스",
    "핵심 개념 하나를 고칠 때 실제로 건드려야 하는 것들의 전체 경로",
    f"""
{t(28, 34, "트레이서빌리티 — 개념 하나를 고칠 때 건드리는 것들", "h")}
{t(28, 54, "새 리소스를 추가하면 14~16개 파일. 전부 예측 가능한 위치다 — 그것이 레이어를 가른 대가로 얻는 것", "sm")}

{t(76, 92, "개념", "sh", "middle")}
{t(252, 92, "내부 API", "sh", "middle")}
{t(438, 92, "유스케이스 (L4)", "sh", "middle")}
{t(620, 92, "Store (L3)", "sh", "middle")}
{t(800, 92, "테이블", "sh", "middle")}
{t(968, 92, "인스턴스", "sh", "middle")}
<line x1="24" y1="100" x2="1016" y2="100" class="ln"/>

{lines(24, 124, [], dy=0)}
{t(28, 124, "Workspace", "lb")}{t(160, 124, "/workspaces", "mono xs")}{t(354, 124, "WorkspacesUseCases", "mono xs")}{t(546, 124, "WorkspaceStore", "mono xs")}{t(724, 124, "workspaces", "mono xs")}{t(886, 124, "cp + ns awp-runtime-<slug>", "mono xs")}
{t(28, 150, "Agent", "lb")}{t(160, 150, "/agents", "mono xs")}{t(354, 150, "AgentsUseCases", "mono xs")}{t(546, 150, "AgentStore", "mono xs")}{t(724, 150, "agents · agent_versions", "mono xs")}{t(886, 150, "control-plane", "mono xs")}
{t(28, 176, "Model card", "lb")}{t(160, 176, "/models", "mono xs")}{t(354, 176, "ModelCardsUseCases", "mono xs")}{t(546, 176, "ModelCardStore", "mono xs")}{t(724, 176, "model_cards", "mono xs")}{t(886, 176, "cp → 워커가 어댑터 선택", "mono xs")}
{t(28, 202, "Environment", "lb")}{t(160, 202, "/environments", "mono xs")}{t(354, 202, "EnvironmentsUseCases", "mono xs")}{t(546, 202, "EnvironmentStore", "mono xs")}{t(724, 202, "environments(+versions)", "mono xs")}{t(886, 202, "cp + 워커 능력 프로브", "mono xs")}
{t(28, 228, "Session", "lb")}{t(160, 228, "/sessions", "mono xs")}{t(354, 228, "SessionsUseCases", "mono xs")}{t(546, 228, "SessionStore", "mono xs")}{t(724, 228, "sessions · session_resources", "mono xs")}{t(886, 228, "cp(생성) + 워커(실행)", "mono xs")}
{t(28, 254, "Event", "lb")}{t(160, 254, "/events · /stream", "mono xs")}{t(354, 254, "SessionEventsUseCases", "mono xs")}{t(546, 254, "SessionEventStore", "mono xs")}{t(724, 254, "session_events(+pending)", "mono xs")}{t(886, 254, "cp(수용·SSE) + 워커", "mono xs")}
{t(28, 280, "Execution", "lb")}{t(160, 280, "(내부)", "mono xs")}{t(354, 280, "SessionExecutionUseCases", "mono xs")}{t(546, 280, "ExecutionStore", "mono xs")}{t(724, 280, "session_executions", "mono xs")}{t(886, 280, "runtime-worker", "mono xs")}
{t(28, 306, "Tool call", "lb")}{t(160, 306, "(이벤트로)", "mono xs")}{t(354, 306, "ToolRegistry + 훅", "mono xs")}{t(546, 306, "—", "mono xs")}{t(724, 306, "session_events", "mono xs")}{t(886, 306, "워커 / 샌드박스(bash)", "mono xs")}
{t(28, 332, "Vault", "lb")}{t(160, 332, "/vaults/…", "mono xs")}{t(354, 332, "CredentialsUseCases", "mono xs")}{t(546, 332, "CredentialStore", "mono xs")}{t(724, 332, "credentials(+events)", "mono xs")}{t(886, 332, "cp(보관) + 프록시(주입)", "mono xs")}
{t(28, 358, "Memory store", "lb")}{t(160, 358, "/memory_stores/…", "mono xs")}{t(354, 358, "MemoryUseCases", "mono xs")}{t(546, 358, "MemoryDocumentStore", "mono xs")}{t(724, 358, "memories(+versions)", "mono xs")}{t(886, 358, "cp + 워커(마운트·동기화)", "mono xs")}
{t(28, 384, "Approval", "lb")}{t(160, 384, "/approvals", "mono xs")}{t(354, 384, "ApprovalsUseCases", "mono xs")}{t(546, 384, "ApprovalStore", "mono xs")}{t(724, 384, "approvals(+policies)", "mono xs")}{t(886, 384, "cp(결정) + 워커(재개)", "mono xs")}
{t(28, 410, "Budget", "lb")}{t(160, 410, "/budgets · /usage", "mono xs")}{t(354, 410, "BudgetUseCases", "mono xs")}{t(546, 410, "BudgetStore", "mono xs")}{t(724, 410, "budgets · usage_events", "mono xs")}{t(886, 410, "워커 + cp + ResourceQuota", "mono xs")}
{t(28, 436, "Audit entry", "lb")}{t(160, 436, "/audit", "mono xs")}{t(354, 436, "AuditUseCases", "mono xs")}{t(546, 436, "AuditStore", "mono xs")}{t(724, 436, "audit_log (append-only)", "mono xs")}{t(886, 436, "전 인스턴스", "mono xs")}
{t(28, 462, "Sandbox", "lb")}{t(160, 462, "/env/{{id}}/capabilities", "mono xs")}{t(354, 462, "SandboxPort", "mono xs")}{t(546, 462, "—", "mono xs")}{t(724, 462, "sandbox_instances", "mono xs")}{t(886, 462, "runtime-worker 내부", "mono xs")}
<line x1="24" y1="478" x2="1016" y2="478" class="ln"/>

{box(24, 494, 332, 180, "ac")}
{t(44, 518, "새 리소스 추가 체크리스트", "lb")}
{lines(44, 542, [
  "ma_domain/<name>.py",
  "ma_store/<name>.py",
  "ma_store_memory/<name>.py",
  "ma_store_sql/<name>.py",
  "ma_schema/versions/00NN_*.py",
  "ma_application/<name>.py",
  "ma_platform/modules/<name>.py",
  "ma_platform/sql.py  (StoreBundle)",
  "ma_api/internal/{{schemas,mappers,routes}}",
  "tests/contract · tests/unit",
  "web/console",
], dy=14, cls="mono xs")}

{box(372, 494, 316, 180, "ok")}
{t(392, 518, "모델을 바꾼다", "lb tk")}
{t(392, 542, "코드 변경 0", "lb mono")}
{t(392, 562, "model_cards 행을 고치거나 새 카드를 만들고", "xs")}
{t(392, 578, "에이전트의 핸들을 바꾼다. 그게 D12의 목적.", "xs")}
{t(392, 606, "새 provider를 추가할 때만:", "lb")}
{lines(392, 626, [
  "packages/ma_model_<provider>/",
  "ma_domain/models.py  ProviderKind",
  "tests/contract/test_model_port.py",
], dy=15, cls="mono xs")}

{box(704, 494, 312, 180, "wa")}
{t(724, 518, "뒤집기 비싼 결정 vs 싼 결정", "lb")}
{lines(724, 542, [
  "D3 실행 권한        매우 높음  ★ 먼저 검증",
  "D4 이중 테이블      높음      ★ 먼저 검증",
  "D2 스키마 단일 출처  높음",
  "D5 자격증명 격리     높음",
  "D13 샌드박스 티어    낮음  (Port 뒤)",
  "D9 공식 lane        낮음  (이미 분리)",
  "D11 하네스 선택      낮음  (Protocol 뒤)",
  "D12 모델 선택        매우 낮음  ← 목적",
], dy=15, cls="mono xs")}
{t(724, 666, "D3·D4는 테스트로 검증 가능하다", "xs tw")}
""")

# ────────────────────────────────────────────────────────────── 21 승인 흐름
svg("21-approval-flow.svg", 1020, 660,
    "승인 워크플로",
    "always_ask 툴은 실행 함수가 없어 턴이 requires_action으로 끊긴다. 승인은 fail-closed다",
    f"""
{t(28, 34, "승인 워크플로 — 툴 권한 정책의 자연스러운 귀결 (D8)", "h")}
{t(28, 54, "에이전트는 '승인이 필요하다'를 배우지 않는다. 실행할 수 없는 툴을 호출했고 플랫폼이 턴을 끊었을 뿐이다", "sm")}

{box(24, 80, 306, 128, "bl")}
{t(177, 104, "① 에이전트 설정", "lb", "middle")}
{lines(40, 128, [
  "tools: [{{",
  "  type: agent_toolset,",
  "  configs: [{{",
  "    name: bash,",
  "    permission_policy: always_ask }}]}}]",
], dy=15, cls="mono xs")}

<path class="ar-bl" d="M332 144 L356 144"/>

{box(358, 80, 306, 128, "wa")}
{t(511, 104, "② 툴 레지스트리 구성", "lb", "middle")}
{t(374, 128, "해당 툴을 '실행 함수 없는", "sm")}
{t(374, 146, "선언만 있는 툴'로 등록", "sm")}
{box(374, 158, 274, 40, "c2")}
{t(511, 176, "ToolEntry(executor=None)", "mono xs", "middle")}
{t(511, 192, "kind = builtin  ← 이름 매칭 안 함", "mono xs", "middle")}

<path class="ar-bl" d="M666 144 L690 144"/>

{box(692, 80, 304, 128, "da")}
{t(844, 104, "③ 턴 실행", "lb", "middle")}
{lines(706, 128, [
  "모델이 그 툴을 호출",
  "→ 하네스가 실행할 수 없음",
  "→ pending_confirmations 적재",
  "→ 턴 종료 terminate",
  "→ status_idle{{requires_action}}",
], dy=15, cls="mono xs")}

{box(24, 236, 466, 196, "ac")}
{t(44, 260, "④ 사내 정책 레이어 — 공식 계약 위에 얹는다", "lb")}
{t(44, 284, "approval_policies", "lb mono")}
{lines(44, 304, [
  "tool_pattern        'bash' | 'mcp__github__*' | '*'",
  "required_role       viewer|operator|admin|owner",
  "required_approvals  기본 1. 민감 툴은 2 (4-eyes)",
  "self_approval       본인 세션 자기 승인 (기본 false)",
  "notify              slack_channel | email | none",
  "expires_after       미응답 시 자동 거부까지",
  "priority            높은 것이 이긴다",
], dy=16, cls="mono xs")}
{box(44, 404, 426, 20, "c2")}
{t(257, 419, "제어 평면이 approvals 행을 만들고 정책에 따라 알림", "xs", "middle")}

{box(510, 236, 486, 196, "ok")}
{t(530, 260, "⑤ 결정과 재개", "lb")}
{lines(530, 284, [
  "POST /api/v1/approvals/{{id}}  {{decision, reason}}",
  "   역할 검사 — 정책이 정한 역할만",
  "",
  "제어 평면이 user.tool_confirmation 이벤트를 세션에 수용",
  "   (§3의 같은 한 트랜잭션 경로)",
  "",
  "워커가 claim해서 재개",
  "   승인 → build_tools(grants=[ToolGrant(tool_call_id)])",
  "          그 호출에만 executor를 되살린다  ★",
  "   거부 → Denied: {{reason}} 을 tool_result로 주입",
], dy=16, cls="mono xs")}
{box(530, 404, 446, 20, "wa")}
{t(753, 419, "모든 단계가 audit_log에 기록된다", "xs", "middle")}

{box(24, 460, 486, 180, "pu")}
{t(44, 484, "DeepSeek Harness에서 가져온 승인 어휘", "lb")}
{t(44, 508, "ApprovalOutcome — 닫힌 집합이고 fail-closed", "lb mono")}
{box(44, 520, 220, 28, "ok")}{t(154, 539, "allowed-once", "mono sm", "middle")}
{box(272, 520, 220, 28, "da")}{t(382, 539, "rejected", "mono sm", "middle")}
{box(44, 554, 220, 28, "da")}{t(154, 573, "cancelled", "mono sm", "middle")}
{box(272, 520, 0, 0, "c")}
{box(272, 554, 220, 28, "da")}{t(382, 573, "unavailable", "mono sm", "middle")}
{t(44, 604, "답변자가 없거나 예외를 던지거나 비정합이면 unavailable이고,", "xs")}
{t(44, 620, "게이트를 열지 않는다. allowed-once는 '물어본 그 행위'만 허가한다.", "xs")}
{t(44, 636, "approval/asked + approval/decided는 log-only — 모델 전사에 들어가지 않는다", "xs tp")}

{box(526, 460, 470, 180, "da")}
{t(546, 484, "레퍼런스에 있던 두 결함 — 우리는 피한다", "lb tr")}
{t(546, 510, "① 승인 후 재개했는데 결과가 없다", "lb")}
{lines(546, 530, [
  "툴 재구성 시에도 always_ask 스트리핑이 적용되어",
  "executor가 없고, 결과 없이 재개된다.",
  "→ ToolGrant(tool_call_id)로 그 호출만 되살린다",
], dy=15, cls="xs")}
{t(546, 592, "② 커스텀 툴 판별이 하드코딩 이름 목록", "lb")}
{lines(546, 612, [
  "schedule_*·browser_* 에 always_ask를 걸면 오분류된다.",
  "→ ToolRegistry가 kind를 실체로 들고 있어 이름 매칭을 안 한다",
], dy=15, cls="xs")}
""")
