#!/usr/bin/env python3
"""plan/*.md + plan/svg/*.svg → plan/index.html (단일 독립 문서)."""
from __future__ import annotations
import html
import pathlib
import re
import xml.etree.ElementTree as ET

PLAN = pathlib.Path("/Users/leedonghyeon/Work/managed-agent/plan")
SVG = PLAN / "svg"

CHAPTERS = [
    ("00", "README.md", "개요", "설계 요지와 핵심 결정"),
    ("01", "01-product-concept.md", "제품 컨셉", "누구의 어떤 문제"),
    ("02", "02-architecture.md", "아키텍처", "평면 · 권한 · 생애주기"),
    ("03", "03-layers.md", "레이어 구조", "7계층과 의존 규칙"),
    ("04", "04-api.md", "API 구조", "두 lane · 이벤트 · SSE"),
    ("05", "05-database.md", "데이터베이스", "48테이블 · 동시성"),
    ("06", "06-harness-and-model.md", "하네스와 모델", "DeepSeek · 비용 지렛대"),
    ("07", "07-sandbox.md", "샌드박스", "Wasm 2티어"),
    ("08", "08-infrastructure.md", "인프라 · 인스턴스", "Kubernetes 토폴로지"),
    ("09", "09-codebase.md", "코드베이스", "Python 모노레포"),
    ("10", "10-relationships.md", "관계 · 로드맵", "트레이서빌리티"),
]
MD2CH = {f: cid for cid, f, _, _ in CHAPTERS}

# ─────────────────────────────────────────────── SVG 메타
FIGS: dict[str, dict] = {}
for p in sorted(SVG.glob("*.svg")):
    root = ET.parse(p).getroot()
    ns = "{http://www.w3.org/2000/svg}"
    ti = root.find(f"{ns}title")
    de = root.find(f"{ns}desc")
    num = p.name.split("-", 1)[0]
    vb = (root.get("viewBox") or "0 0 1000 600").split()
    FIGS[p.name] = {
        "w": int(float(vb[2])),
        "h": int(float(vb[3])),
        "num": num,
        "title": (ti.text or p.stem) if ti is not None else p.stem,
        "desc": (de.text or "") if de is not None else "",
        "id": f"fig-{num}",
        "file": p.name,
    }

# ─────────────────────────────────────────────── 인라인 마크업
RE_CODE = re.compile(r"`([^`]+)`")
RE_LINK = re.compile(r"\[([^\]]+)\]\(([^)\s]+)\)")
RE_BOLD = re.compile(r"\*\*([^*]+)\*\*")
RE_AUTO = re.compile(r"<(https?://[^>\s]+)>")


def href(target: str) -> str:
    """md 내부 링크를 페이지 앵커로, svg 링크를 figure 앵커로 바꾼다."""
    if "#" in target:
        base, frag = target.split("#", 1)
    else:
        base, frag = target, ""
    name = base.split("/")[-1]
    if name in MD2CH:
        return f"#ch{MD2CH[name]}"
    if base.startswith("svg/") and name in FIGS:
        return f"#{FIGS[name]['id']}"
    if base.startswith("../") or base.startswith("http"):
        return target
    return target


def inline(s: str) -> str:
    """코드 스팬을 플레이스홀더로 보호한 뒤 한 번에 처리한다.

    bold가 코드 스팬을 걸쳐 있는 경우(**`code`는 …**)를 올바르게 처리하려면
    코드를 먼저 떼어내고 나머지 변환을 전체 문자열에 적용해야 한다.
    """
    spans: list[str] = []

    def stash(m: re.Match[str]) -> str:
        spans.append(m.group(1))
        return f"\x00{len(spans) - 1}\x00"

    t = RE_CODE.sub(stash, s)
    t = html.escape(t)
    t = RE_AUTO.sub(lambda m: f'<a href="{m.group(1)}" rel="noreferrer">{m.group(1)}</a>', t)

    def _link(m: re.Match[str]) -> str:
        label, tgt = m.group(1), m.group(2)
        h = href(html.unescape(tgt))
        ext = ' rel="noreferrer"' if h.startswith("http") else ""
        return f'<a href="{html.escape(h)}"{ext}>{label}</a>'

    t = RE_LINK.sub(_link, t)
    t = RE_BOLD.sub(r"<strong>\1</strong>", t)
    for idx, code in enumerate(spans):
        t = t.replace(f"\x00{idx}\x00", f"<code>{html.escape(code)}</code>")
    return t


def split_row(line: str) -> list[str]:
    """백틱 안의 | 를 구분자로 보지 않는다."""
    cells: list[str] = []
    cur: list[str] = []
    tick = False
    for ch in line:
        if ch == "`":
            tick = not tick
            cur.append(ch)
        elif ch == "|" and not tick:
            cells.append("".join(cur))
            cur = []
        else:
            cur.append(ch)
    cells.append("".join(cur))
    if cells and not cells[0].strip():
        cells = cells[1:]
    if cells and not cells[-1].strip():
        cells = cells[:-1]
    return [c.strip() for c in cells]


def is_sep(line: str) -> bool:
    cs = split_row(line)
    return bool(cs) and all(re.fullmatch(r":?-{2,}:?", c) for c in cs)


# ─────────────────────────────────────────────── 블록 렌더
def render(md: str, cid: str, figs: list[dict]) -> str:
    lines = md.split("\n")
    out: list[str] = []
    i = 0
    n = len(lines)
    figs_emitted = False
    h2_seen = 0

    def flush_figs() -> None:
        nonlocal figs_emitted
        if figs_emitted or not figs:
            return
        figs_emitted = True
        out.append('<div class="figstrip">')
        for f in figs:
            out.append(
                f'<figure class="fig" id="{f["id"]}">'
                f'<img src="svg/{f["file"]}" alt="{html.escape(f["desc"] or f["title"])}" '
                f'width="{f["w"]}" height="{f["h"]}" style="aspect-ratio:{f["w"]}/{f["h"]}" '
                f'loading="lazy" decoding="async">'
                f'<figcaption><span class="fignum">도 {f["num"]}</span>'
                f'<span class="figtitle">{html.escape(f["title"])}</span>'
                f'<span class="figdesc">{html.escape(f["desc"])}</span></figcaption></figure>'
            )
        out.append("</div>")

    while i < n:
        ln = lines[i]

        # 코드 펜스 (목록 안에 들여쓴 것도 인식해 dedent한다)
        if ln.lstrip().startswith("```"):
            indent = len(ln) - len(ln.lstrip())
            lang = ln.lstrip()[3:].strip()
            i += 1
            buf: list[str] = []
            while i < n and not lines[i].lstrip().startswith("```"):
                buf.append(lines[i][indent:] if lines[i][:indent].strip() == "" else lines[i].lstrip())
                i += 1
            i += 1
            lab = f'<span class="codelang">{html.escape(lang)}</span>' if lang else ""
            out.append(
                f'<div class="codewrap">{lab}<pre><code>{html.escape(chr(10).join(buf))}</code></pre></div>'
            )
            continue

        # 제목
        if ln.startswith("# "):
            i += 1
            continue  # 챕터 제목은 셸이 그린다
        if ln.startswith("## "):
            h2_seen += 1
            txt = ln[3:].strip()
            sid = f"ch{cid}-s{h2_seen}"
            out.append(f'<h2 id="{sid}">{inline(txt)}</h2>')
            i += 1
            continue
        if ln.startswith("### "):
            out.append(f"<h3>{inline(ln[4:].strip())}</h3>")
            i += 1
            continue
        if ln.startswith("#### "):
            out.append(f"<h4>{inline(ln[5:].strip())}</h4>")
            i += 1
            continue

        # 구분선 — 첫 번째 구분선 뒤에 도판을 끼운다
        if ln.strip() == "---":
            if not figs_emitted:
                flush_figs()
            else:
                out.append('<hr class="rule">')
            i += 1
            continue

        # 인용
        if ln.startswith(">"):
            buf = []
            while i < n and (lines[i].startswith(">") or (buf and lines[i].strip()
                   and not lines[i].startswith(("#", "|", "-"))
                   and not lines[i].lstrip().startswith("```"))):
                buf.append(re.sub(r"^>\s?", "", lines[i]))
                i += 1
            body = " ".join(x.strip() for x in buf if x.strip())
            # 챕터 머리의 '다이어그램:' 안내는 도판이 대체한다
            if body.startswith("다이어그램:"):
                continue
            out.append(f'<blockquote><p>{inline(body)}</p></blockquote>')
            continue

        # 표
        if ln.lstrip().startswith("|") and i + 1 < n and is_sep(lines[i + 1]):
            head = split_row(ln)
            i += 2
            rows = []
            while i < n and lines[i].lstrip().startswith("|"):
                rows.append(split_row(lines[i]))
                i += 1
            th = "".join(f"<th>{inline(c)}</th>" for c in head)
            body = ""
            for r in rows:
                r = (r + [""] * len(head))[: len(head)]
                body += "<tr>" + "".join(f"<td>{inline(c)}</td>" for c in r) + "</tr>"
            out.append(
                f'<div class="tablewrap"><table><thead><tr>{th}</tr></thead><tbody>{body}</tbody></table></div>'
            )
            continue

        # 목록
        m_ul = re.match(r"^(\s*)[-*]\s+(.*)$", ln)
        m_ol = re.match(r"^(\s*)(\d+)\.\s+(.*)$", ln)
        if m_ul or m_ol:
            tag = "ul" if m_ul else "ol"
            items: list[str] = []
            while i < n:
                mu = re.match(r"^(\s*)[-*]\s+(.*)$", lines[i])
                mo = re.match(r"^(\s*)(\d+)\.\s+(.*)$", lines[i])
                if mu and tag == "ul":
                    items.append(mu.group(2))
                elif mo and tag == "ol":
                    items.append(mo.group(3))
                elif lines[i].lstrip().startswith("```"):
                    break
                elif lines[i].startswith(("   ", "\t")) and items and lines[i].strip():
                    items[-1] += " " + lines[i].strip()
                else:
                    break
                i += 1
            li = "".join(f"<li>{inline(x)}</li>" for x in items)
            out.append(f"<{tag}>{li}</{tag}>")
            continue

        # 빈 줄
        if not ln.strip():
            i += 1
            continue

        # 단락 (연속 줄을 합친다)
        buf = [ln]
        i += 1
        while i < n and lines[i].strip() and not lines[i].startswith(("#", ">", "|", "```", "---")) \
                and not re.match(r"^\s*[-*]\s+", lines[i]) and not re.match(r"^\s*\d+\.\s+", lines[i]):
            buf.append(lines[i])
            i += 1
        out.append(f"<p>{inline(' '.join(x.strip() for x in buf))}</p>")

    flush_figs()
    return "\n".join(out)


# ─────────────────────────────────────────────── 챕터별 도판 매핑
_EMITTED: set[str] = set()


def figs_for(md: str) -> list[dict]:
    """도판은 처음 참조한 챕터에 한 번만 그린다. 이후 참조는 그 앵커를 가리킨다."""
    seen: list[dict] = []
    for m in re.finditer(r"svg/([0-9]{2}-[a-z0-9-]+\.svg)", md):
        name = m.group(1)
        f = FIGS.get(name)
        if f and name not in _EMITTED:
            _EMITTED.add(name)
            seen.append(f)
    return seen


# ─────────────────────────────────────────────── 본문 조립
sections: list[str] = []
navitems: list[str] = []
for cid, fname, title, sub in CHAPTERS:
    md = (PLAN / fname).read_text(encoding="utf-8")
    figs = figs_for(md)
    body = render(md, cid, figs)
    subs = re.findall(r'<h2 id="(ch\d+-s\d+)">(.*?)</h2>', body, re.S)
    sublinks = "".join(
        f'<a class="nsub" href="#{sid}">{re.sub(r"<[^>]+>", "", stxt)}</a>' for sid, stxt in subs
    )
    navitems.append(
        f'<div class="navgrp"><a class="nav" href="#ch{cid}" data-ch="{cid}">'
        f'<span class="navnum">{cid}</span><span class="navtxt"><b>{title}</b><i>{sub}</i></span></a>'
        f'<div class="navsubs">{sublinks}</div></div>'
    )
    sections.append(
        f'<section class="chapter" id="ch{cid}">'
        f'<header class="chead"><span class="chnum">{cid}</span>'
        f'<h1>{title}</h1><p class="chsub">{sub}</p>'
        f'<a class="chsrc" href="{fname}">{fname}</a></header>'
        f'{body}</section>'
    )

figindex = "".join(
    f'<a class="figlink" href="#{f["id"]}"><span>도 {f["num"]}</span>{html.escape(f["title"])}</a>'
    for f in FIGS.values()
)

CSS = """
:root{
  --paper:#fbfbfc; --surface:#ffffff; --surface2:#f1f4f7; --surface3:#e8ecf2;
  --ink:#141922; --ink2:#475164; --ink3:#6c7789;
  --line:#d7dee7; --line2:#e9edf3;
  --ac:#0f7f6c; --ac-s:#e0f2ee; --ac-b:#0b5f51;
  --wa:#95590b; --wa-s:#fbf0dc;
  --da:#a4281f; --da-s:#fbe6e3;
  --ok:#1a6b3c; --ok-s:#e2f3e8;
  --in:#1f5fb0; --in-s:#e3edfb;
  --shadow:0 1px 2px rgba(20,25,34,.05),0 8px 24px -12px rgba(20,25,34,.12);
  color-scheme:light;
}
@media (prefers-color-scheme:dark){ :root:not([data-theme="light"]){
  --paper:#0c0f14; --surface:#131821; --surface2:#1a202a; --surface3:#222935;
  --ink:#e8ebf0; --ink2:#a8b2c1; --ink3:#7b8698;
  --line:#2a323e; --line2:#1f2630;
  --ac:#38c7aa; --ac-s:#0d2c27; --ac-b:#6fdcc6;
  --wa:#eda045; --wa-s:#30220e;
  --da:#ef8b82; --da-s:#351818;
  --ok:#5bcb84; --ok-s:#0f2a1b;
  --in:#6ea8f5; --in-s:#111f33;
  --shadow:0 1px 2px rgba(0,0,0,.4),0 10px 28px -14px rgba(0,0,0,.6);
  color-scheme:dark;
}}
:root[data-theme="dark"]{
  --paper:#0c0f14; --surface:#131821; --surface2:#1a202a; --surface3:#222935;
  --ink:#e8ebf0; --ink2:#a8b2c1; --ink3:#7b8698;
  --line:#2a323e; --line2:#1f2630;
  --ac:#38c7aa; --ac-s:#0d2c27; --ac-b:#6fdcc6;
  --wa:#eda045; --wa-s:#30220e;
  --da:#ef8b82; --da-s:#351818;
  --ok:#5bcb84; --ok-s:#0f2a1b;
  --in:#6ea8f5; --in-s:#111f33;
  --shadow:0 1px 2px rgba(0,0,0,.4),0 10px 28px -14px rgba(0,0,0,.6);
  color-scheme:dark;
}
*{box-sizing:border-box}
html{scroll-behavior:smooth}
@media (prefers-reduced-motion:reduce){html{scroll-behavior:auto}*{animation:none!important;transition:none!important}}
body{
  margin:0; background:var(--paper); color:var(--ink);
  font-family:"IBM Plex Sans KR","IBM Plex Sans",-apple-system,"Segoe UI","Malgun Gothic",sans-serif;
  font-size:15px; line-height:1.72; -webkit-font-smoothing:antialiased;
}
code,pre,.mono{font-family:"IBM Plex Mono",ui-monospace,SFMono-Regular,Menlo,monospace}

/* ── 셸 ───────────────────────────────── */
.shell{display:grid; grid-template-columns:276px minmax(0,1fr); min-height:100vh}
.side{
  position:sticky; top:0; align-self:start; height:100vh; overflow-y:auto;
  background:var(--surface); border-right:1px solid var(--line);
  padding-block:22px; padding-left:20px; padding-right:14px;
}
.brand{display:block; text-decoration:none; color:inherit; margin-bottom:6px}
.brand b{display:block; font-size:19px; font-weight:600; letter-spacing:-.01em}
.brand i{display:block; font-style:normal; font-size:11.5px; color:var(--ink3); letter-spacing:.04em; text-transform:uppercase; margin-top:2px}
.meta{font-size:11.5px; color:var(--ink3); line-height:1.6; margin:12px 0 18px; padding-bottom:16px; border-bottom:1px solid var(--line2)}
.meta b{color:var(--ink2); font-weight:600}
.navgrp{margin-bottom:2px}
.nav{display:flex; gap:9px; align-items:baseline; text-decoration:none; color:var(--ink2);
  padding:7px 9px; border-radius:7px; transition:background .12s,color .12s}
.nav:hover{background:var(--surface2); color:var(--ink)}
.nav.on{background:var(--ac-s); color:var(--ink)}
.nav.on .navnum{color:var(--ac)}
.navnum{font-family:"IBM Plex Mono",monospace; font-size:11px; color:var(--ink3); font-variant-numeric:tabular-nums}
.navtxt b{display:block; font-size:13.5px; font-weight:550; line-height:1.4}
.navtxt i{display:block; font-style:normal; font-size:11px; color:var(--ink3); line-height:1.4}
.navsubs{display:none; padding:2px 0 8px 29px; border-left:1px solid var(--line2); margin-left:14px}
.navgrp.on .navsubs{display:block}
.nsub{display:block; font-size:11.5px; color:var(--ink3); text-decoration:none; padding:3px 0; line-height:1.45}
.nsub:hover{color:var(--ac)}
.sidefoot{margin-top:18px; padding-top:14px; border-top:1px solid var(--line2)}
.sidefoot h5{margin:0 0 8px; font-size:10.5px; letter-spacing:.07em; text-transform:uppercase; color:var(--ink3); font-weight:600}
.figlink{display:flex; gap:8px; font-size:11.5px; color:var(--ink3); text-decoration:none; padding:2.5px 0; line-height:1.4}
.figlink span{font-family:"IBM Plex Mono",monospace; color:var(--ink3); flex:0 0 36px; font-variant-numeric:tabular-nums}
.figlink:hover{color:var(--ac)}

.main{min-width:0; padding-block:0 96px; padding-left:clamp(16px,4vw,56px); padding-right:clamp(16px,4vw,56px)}
.topbar{position:sticky; top:0; z-index:20; display:flex; align-items:center; justify-content:space-between;
  gap:12px; padding:12px 0; margin-bottom:8px; background:color-mix(in srgb,var(--paper) 88%,transparent);
  backdrop-filter:blur(8px); border-bottom:1px solid var(--line2)}
.crumb{font-size:12px; color:var(--ink3); font-variant-numeric:tabular-nums}
.themebtn{appearance:none; border:1px solid var(--line); background:var(--surface); color:var(--ink2);
  font:inherit; font-size:12px; padding:5px 11px; border-radius:999px; cursor:pointer; display:flex; gap:6px; align-items:center}
.themebtn:hover{border-color:var(--ac); color:var(--ac)}
.themebtn:focus-visible{outline:2px solid var(--ac); outline-offset:2px}

/* ── 히어로 ───────────────────────────── */
.hero{max-width:860px; padding-block:26px 8px}
.eyebrow{font-size:11.5px; letter-spacing:.09em; text-transform:uppercase; color:var(--ac); font-weight:600; margin:0 0 10px}
.hero h1{font-family:"IBM Plex Serif","IBM Plex Sans KR",Georgia,serif; font-weight:600;
  font-size:clamp(28px,4.4vw,42px); line-height:1.18; letter-spacing:-.02em; margin:0 0 14px; text-wrap:balance}
.hero p{font-size:16.5px; color:var(--ink2); margin:0 0 20px; max-width:62ch}
.facts{display:flex; flex-wrap:wrap; gap:8px; margin-bottom:8px}
.fact{display:flex; gap:7px; align-items:baseline; font-size:12px; background:var(--surface);
  border:1px solid var(--line); border-radius:999px; padding:5px 12px}
.fact b{font-weight:600; color:var(--ink)}
.fact span{color:var(--ink3)}

/* ── 본문 ─────────────────────────────── */
.chapter{padding-block:52px 8px; border-top:1px solid var(--line2); margin-top:40px; scroll-margin-top:62px}
.chapter:first-of-type{border-top:0; margin-top:0}
.chead{position:relative; margin-bottom:22px}
.chnum{font-family:"IBM Plex Mono",monospace; font-size:12px; color:var(--ac); letter-spacing:.08em; font-variant-numeric:tabular-nums}
.chead h1{font-family:"IBM Plex Serif","IBM Plex Sans KR",Georgia,serif; font-weight:600;
  font-size:clamp(23px,3vw,31px); line-height:1.22; letter-spacing:-.015em; margin:4px 0 6px; text-wrap:balance}
.chsub{margin:0; color:var(--ink3); font-size:13.5px}
.chsrc{position:absolute; top:0; right:0; font-family:"IBM Plex Mono",monospace; font-size:11px;
  color:var(--ink3); text-decoration:none; border:1px solid var(--line); border-radius:6px; padding:3px 8px}
.chsrc:hover{color:var(--ac); border-color:var(--ac)}

.chapter p,.chapter ul,.chapter ol,.chapter blockquote{max-width:74ch}
.chapter h2{font-size:19px; font-weight:600; letter-spacing:-.01em; margin:38px 0 12px;
  padding-top:6px; scroll-margin-top:66px; text-wrap:balance}
.chapter h2::before{content:""; display:block; width:26px; height:2px; background:var(--ac); margin-bottom:10px}
.chapter h3{font-size:15.5px; font-weight:600; margin:26px 0 8px; color:var(--ink); text-wrap:balance}
.chapter h4{font-size:14px; font-weight:600; margin:18px 0 6px; color:var(--ink2)}
.chapter p{margin:0 0 12px}
.chapter a{color:var(--ac); text-decoration:none; border-bottom:1px solid color-mix(in srgb,var(--ac) 32%,transparent)}
.chapter a:hover{border-bottom-color:var(--ac)}
.chapter ul,.chapter ol{margin:0 0 14px; padding-left:22px}
.chapter li{margin-bottom:5px}
.chapter li::marker{color:var(--ink3)}
.chapter strong{font-weight:600}
code{background:var(--surface2); border:1px solid var(--line2); border-radius:4px;
  padding:.08em .34em; font-size:.875em; white-space:pre-wrap; overflow-wrap:break-word}
.chapter a code{color:inherit}
hr.rule{border:0; border-top:1px solid var(--line2); margin:30px 0; max-width:74ch}

blockquote{margin:0 0 16px; padding:12px 16px; background:var(--surface);
  border:1px solid var(--line); border-left:3px solid var(--ac); border-radius:0 8px 8px 0}
blockquote p{margin:0; color:var(--ink2); font-size:14px}

.codewrap{position:relative; margin:0 0 18px; background:var(--surface); border:1px solid var(--line);
  border-radius:9px; overflow:hidden}
.codelang{position:absolute; top:0; right:0; font-family:"IBM Plex Mono",monospace; font-size:10px;
  letter-spacing:.06em; text-transform:uppercase; color:var(--ink3); background:var(--surface2);
  border-left:1px solid var(--line); border-bottom:1px solid var(--line); border-radius:0 9px 0 6px; padding:3px 9px}
.codewrap pre{margin:0; padding:14px 16px; overflow-x:auto; font-size:12.3px; line-height:1.62}
.codewrap code{background:none; border:0; padding:0; white-space:pre; font-size:inherit}

.tablewrap{margin:0 0 20px; overflow-x:auto; border:1px solid var(--line); border-radius:9px; background:var(--surface)}
table{border-collapse:collapse; width:100%; font-size:13px}
th,td{text-align:left; padding:9px 13px; border-bottom:1px solid var(--line2); vertical-align:top}
thead th{background:var(--surface2); font-weight:600; font-size:12px; color:var(--ink2);
  letter-spacing:.01em; white-space:nowrap; position:sticky; top:0; border-bottom:1px solid var(--line)}
tbody tr:last-child td{border-bottom:0}
tbody tr:hover{background:var(--surface2)}
td:first-child{white-space:nowrap}
td code,th code{white-space:nowrap}

/* ── 도판 ─────────────────────────────── */
.figstrip{display:flex; flex-direction:column; gap:20px; margin:4px 0 30px}
.fig{margin:0; background:var(--surface); border:1px solid var(--line); border-radius:11px;
  overflow:hidden; box-shadow:var(--shadow); scroll-margin-top:72px}
.fig img{display:block; width:100%; max-width:100%; height:auto; background:var(--surface)}
.fig img[width]{height:auto}
figcaption{display:flex; flex-wrap:wrap; align-items:baseline; gap:4px 10px;
  padding:10px 15px; border-top:1px solid var(--line2); background:var(--surface2)}
.fignum{font-family:"IBM Plex Mono",monospace; font-size:11px; color:var(--ac); font-variant-numeric:tabular-nums; flex:0 0 auto}
.figtitle{font-size:13px; font-weight:600}
.figdesc{font-size:11.5px; color:var(--ink3); flex:1 1 100%; line-height:1.5}

/* ── 모바일 ───────────────────────────── */
.menubtn{display:none}
@media (max-width:900px){
  .shell{grid-template-columns:1fr}
  .side{position:static; height:auto; border-right:0; border-bottom:1px solid var(--line);
    padding-left:16px; padding-right:16px}
  .side .navsubs{display:none!important}
  .main{padding-left:16px; padding-right:16px}
  .sidenav{display:none}
  .side.open .sidenav{display:block}
  .menubtn{display:flex}
  .chsrc{position:static; display:inline-block; margin-top:8px}
  .chead{display:flex; flex-direction:column; align-items:flex-start}
}
@media (max-width:560px){
  body{font-size:14.5px}
  .facts{gap:6px}
  .chapter p,.chapter ul,.chapter ol,.chapter blockquote{max-width:none}
}
"""

JS = """
(function(){
  var root=document.documentElement, btn=document.getElementById('theme');
  var order=['system','light','dark'], icon={system:'◐',light:'○',dark:'●'},
      label={system:'시스템',light:'라이트',dark:'다크'};
  function read(){ try{return localStorage.getItem('awp-theme')||'system'}catch(e){return 'system'} }
  function apply(v){
    if(v==='system'){root.removeAttribute('data-theme')}else{root.setAttribute('data-theme',v)}
    btn.innerHTML='<span aria-hidden="true">'+icon[v]+'</span>'+label[v];
    btn.setAttribute('aria-label','테마: '+label[v]+' (클릭하여 변경)');
  }
  var cur=read(); apply(cur);
  btn.addEventListener('click',function(){
    cur=order[(order.indexOf(cur)+1)%order.length];
    try{localStorage.setItem('awp-theme',cur)}catch(e){}
    apply(cur);
  });

  var mb=document.getElementById('menu'), side=document.getElementById('side');
  mb.addEventListener('click',function(){
    var open=side.classList.toggle('open');
    mb.setAttribute('aria-expanded',open?'true':'false');
  });

  var chs=[].slice.call(document.querySelectorAll('.chapter'));
  var navs={}, grps={};
  [].forEach.call(document.querySelectorAll('.nav'),function(a){
    navs[a.getAttribute('data-ch')]=a; grps[a.getAttribute('data-ch')]=a.parentNode;
  });
  var crumb=document.getElementById('crumb');
  function spy(){
    var y=window.scrollY+120, act=chs[0];
    for(var i=0;i<chs.length;i++){ if(chs[i].offsetTop<=y) act=chs[i]; }
    var id=act.id.replace('ch','');
    for(var k in navs){
      navs[k].classList.toggle('on',k===id);
      grps[k].classList.toggle('on',k===id);
      if(k===id) navs[k].setAttribute('aria-current','true'); else navs[k].removeAttribute('aria-current');
    }
    var h=act.querySelector('.chead h1');
    crumb.textContent=id+' · '+(h?h.textContent:'');
  }
  var tick=false;
  window.addEventListener('scroll',function(){
    if(tick) return; tick=true;
    requestAnimationFrame(function(){ spy(); tick=false; });
  },{passive:true});
  spy();
})();
"""

page = f"""<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>AWP 설계 문서</title>
<meta name="description" content="사내 에이전트 운영 플랫폼 AWP의 제품 컨셉 · 아키텍처 · 레이어 · API · DB · 하네스/모델 · 샌드박스 · 인프라 · 코드베이스 설계">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+KR:wght@300;400;500;600&family=IBM+Plex+Mono:wght@400;500&family=IBM+Plex+Serif:wght@500;600&display=swap">
<style>{CSS}</style>
</head>
<body>
<div class="shell">
<aside class="side" id="side">
  <a class="brand" href="#top"><b>AWP</b><i>Agent Workspace Platform</i></a>
  <button class="themebtn menubtn" id="menu" aria-expanded="false" aria-controls="side" style="margin:10px 0">목차</button>
  <div class="sidenav">
    <p class="meta">
      사내 에이전트 운영 플랫폼 설계 문서<br>
      <b>2026-10-14</b> · Python · PostgreSQL · Kubernetes<br>
      모델 <b>deepseek-flash</b> · 샌드박스 <b>Wasm + bwrap</b>
    </p>
    <nav aria-label="챕터">{''.join(navitems)}</nav>
    <div class="sidefoot">
      <h5>다이어그램 21</h5>
      {figindex}
    </div>
  </div>
</aside>

<main class="main" id="top">
  <div class="topbar">
    <span class="crumb" id="crumb">00 · 개요</span>
    <button class="themebtn" id="theme" aria-label="테마 변경">◐시스템</button>
  </div>

  <div class="hero">
    <p class="eyebrow">설계 문서 · Phase 0 이전</p>
    <h1>사내 부서가 자기 업무용 에이전트를 자산으로 운영하는 플랫폼</h1>
    <p>에이전트 설정을 버전 관리되는 자산으로, 실행을 감사 가능한 append-only 이벤트 로그로 남기고,
       자격증명이 에이전트 주소공간에 아예 존재하지 않게 만드는 것이 이 설계의 세 축입니다.</p>
    <div class="facts">
      <div class="fact"><b>13</b><span>설계 결정</span></div>
      <div class="fact"><b>48</b><span>테이블</span></div>
      <div class="fact"><b>22+5</b><span>패키지 · 앱</span></div>
      <div class="fact"><b>21</b><span>다이어그램</span></div>
      <div class="fact"><b>7</b><span>of 8 툴은 셸 불필요</span></div>
      <div class="fact"><b>50×</b><span>캐시 히트 비용차</span></div>
    </div>
  </div>

{''.join(sections)}
</main>
</div>
<script>{JS}</script>
</body>
</html>
"""

(PLAN / "index.html").write_text(page, encoding="utf-8")
print(f"index.html  {len(page):,} bytes · chapters {len(CHAPTERS)} · figures {len(FIGS)}")
