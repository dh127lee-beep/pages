# plan/_build — 문서 생성기

`index.html`은 **`plan/*.md`에서 생성됩니다.** MD가 원천이고 HTML은 산출물입니다.
MD를 고쳤으면 아래를 다시 돌려 HTML을 갱신하십시오.

```sh
python3 plan/_build/gen_svg.py      # svg/*.svg 21개 재생성 (다이어그램 수정 시에만)
python3 plan/_build/build_html.py   # plan/*.md + svg/ → plan/index.html
```

- `gen_svg.py` — 공통 스타일(라이트/다크 토큰) + 21개 다이어그램 본문. SVG는 각각
  자기 `<title>`/`<desc>`와 `prefers-color-scheme`을 들고 있어 `<img>`로 참조해도
  테마를 따릅니다.
- `build_html.py` — 마크다운 부분집합(제목·표·코드펜스·인용·목록·인라인) 렌더러 +
  디자인 셸(사이드바·스크롤스파이·테마 토글). 챕터 간 `.md` 링크는 페이지 앵커로,
  `svg/*.svg` 링크는 도판 앵커로 바뀝니다.

의존성은 Python 표준 라이브러리뿐입니다.
