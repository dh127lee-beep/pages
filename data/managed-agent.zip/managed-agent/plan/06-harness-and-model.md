# 06. 하네스와 모델

> 다이어그램: [`svg/13-harness-turn-loop.svg`](svg/13-harness-turn-loop.svg) ·
> [`svg/14-model-cost-levers.svg`](svg/14-model-cost-levers.svg)
> 조사 대상: **DeepSeek Harness** <https://github.com/deepseek-ai/deepseek-harness> (MIT, TypeScript, developer preview) ·
> **DeepSeek API** <https://api-docs.deepseek.com/>

---

## 1. 먼저: 모델은 코드가 아니라 설정이다 (D12)

이 장 전체의 전제입니다. **모델은 바뀝니다.** 조사 중에 확인된 것만 봐도:

- `deepseek-v4-flash`와 `deepseek-v4-flash-vision-exp`는 **은퇴**했고 V4.1-Flash로 임시 라우팅된다.
- `deepseek-v4-pro`는 **2026-09-14부터** 모든 요청이 V4.1-Flash로, Flash 요금으로 라우팅된다.
- 요금은 2026-09-10 04:00 UTC에 개정됐다.

즉 "지금 맞는 모델 ID"를 코드에 적으면 **교체가 릴리스**가 됩니다. 그래서 AWP는 모델에 대해
아는 것을 전부 `model_cards` **선언**으로 밀어내고, 하네스는 그 선언을 읽어 적응합니다.

### 결정 순서 — 뒤로 갈수록 우선

```
① 환경변수 기본값          AWP_DEFAULT_MODEL_CARD=dept-default
                           AWP_MODEL_PROVIDER=deepseek_official
                           AWP_MODEL_BASE_URL=https://api.deepseek.com
② 모델 카드 (DB)           model_cards 행 — 실제 모델 ID·한도·파라미터·요금
③ 워크스페이스 기본값       workspaces.settings.default_model_card
④ 에이전트 설정            agents.document.model = "<카드 핸들>"
⑤ 세션 오버라이드          sessions.config_override.model
```

`①`은 **부트스트랩용**입니다(빈 DB에서 첫 카드를 만들 때). 운영에서는 `②~⑤`만 씁니다.
코드 어디에도 모델 문자열이 없습니다.

### 모델 카드가 선언하는 것

하네스가 하드코딩하지 않기 위해 필요한 모든 것입니다.

```python
# packages/ma_domain/src/ma_domain/models.py
@dataclass(frozen=True, slots=True)
class ModelCard:
    id: ModelCardId  # "dept-default"  ← 에이전트가 참조하는 핸들
    provider: ProviderKind  # deepseek_official | openai_compatible | anthropic_compatible
    wire_model: str  # "deepseek-flash"  ← 실제로 전송되는 문자열
    base_url: str | None
    credential_id: CredentialId | None

    # --- 능력 선언: 하네스가 이것을 읽고 적응한다 ---
    max_input_tokens: int  # 1_000_000
    max_output_tokens: int  # 384_000
    supports_tools: bool
    supports_vision: bool
    reasoning: ReasoningSpec | None  # 아래 참조
    supports_prompt_cache: bool

    # --- 요금 선언: 예산·비용 계산이 코드가 아니라 데이터 ---
    pricing: PricingSpec

    # --- 기본 파라미터 ---
    defaults: Mapping[str, object]  # {"reasoning_effort": "high", "max_tokens": 49152}
    off_peak_preferred: bool


@dataclass(frozen=True, slots=True)
class ReasoningSpec:
    """추론 깊이를 어떤 파라미터 이름으로, 어떤 값으로 조절하는가."""

    param: str  # "reasoning_effort"  |  "thinking"
    style: Literal["enum", "object"]  # enum → 문자열 그대로, object → {"type": "enabled"}
    levels: tuple[str, ...]  # ("low","medium","high","max")


@dataclass(frozen=True, slots=True)
class PricingSpec:
    currency: str  # "USD"
    unit_tokens: int  # 1_000_000
    input_cache_miss: Decimal
    input_cache_hit: Decimal
    output: Decimal
    off_peak_multiplier: Decimal  # 0.5
    peak_windows: tuple[PeakWindow, ...]
```

> **`reasoning` 스펙을 카드가 들고 있는 이유**: provider마다 추론 파라미터 이름과 모양이
> 다릅니다. DeepSeek은 `reasoning_effort: "high"`와 `thinking: {"type": "enabled"}`를 둘 다
> 받고, 다른 provider는 또 다릅니다. 하네스는 "깊이를 `high`로" 같은 **의도**만 갖고,
> 그것을 wire 파라미터로 바꾸는 것은 provider 어댑터의 일입니다.

### Provider 어댑터 seam

```python
# packages/ma_harness/src/ma_harness/model_port.py
class ModelPort(Protocol):
    def describe(self, card: ModelCard) -> ModelCapabilities: ...
    async def stream(
        self,
        card: ModelCard,
        *,
        messages: Sequence[WireMessage],
        tools: Sequence[ToolSchema],
        effort: EffortIntent | None,  # 의도. 카드가 wire 파라미터로 번역
        max_tokens: int | None,
        signal: anyio.Event,
    ) -> AsyncIterator[ModelStreamEvent]: ...
```

| 어댑터 | 대상 | 1단계 |
|---|---|---|
| `DeepSeekOfficialAdapter` | `https://api.deepseek.com` (OpenAI 포맷) + DeepSeek 확장 | ✅ 기본 |
| `OpenAICompatibleAdapter` | 사내 게이트웨이, vLLM, 기타 OpenAI 호환 엔드포인트 | ✅ |
| `AnthropicCompatibleAdapter` | `https://api.deepseek.com/anthropic` 또는 Anthropic API | 2단계 |

**`ModelStreamEvent`는 provider 중립 어휘**입니다(`text_delta`, `thinking_delta`,
`tool_call_start`, `tool_call_delta`, `tool_call_end`, `usage`, `finish`). 어댑터가
provider별 SSE를 이 어휘로 정규화하므로, 하네스 루프는 provider를 전혀 모릅니다.

새 provider를 붙이는 비용 = 어댑터 파일 하나 + 계약 테스트 통과. 하네스·API·DB는 무변경.

---

## 2. DeepSeek V4.1-Flash — 1단계 기본값

| 항목 | 값 |
|---|---|
| 모델 ID | `deepseek-flash` |
| 정식명 | DeepSeek-V4.1-Flash (2026-09-10 공개) |
| 아키텍처 | 552B MoE, Causal Encoder–Decoder. 입력 활성 8B / 출력 활성 16B |
| 컨텍스트 | **1M 토큰** |
| 최대 출력 | **384K 토큰** |
| 멀티모달 | 텍스트 + 이미지 (같은 모델·같은 프롬프트 포맷) |
| 툴 호출 | 지원 |
| 추론 | 지원 (`reasoning_effort`, `thinking`) |
| Base URL | `https://api.deepseek.com` (OpenAI 포맷) / `https://api.deepseek.com/anthropic` (Anthropic 포맷) |
| SDK | OpenAI SDK 또는 Anthropic SDK에서 **base_url만 교체** |

### 요금 (USD / 1M 토큰)

| | peak | off-peak |
|---|---|---|
| 입력 (캐시 히트) | $0.006 | $0.003 |
| 입력 (캐시 미스) | $0.30 | $0.15 |
| 출력 | $1.20 | $0.60 |

peak은 **UTC 01:00–04:00, 06:00–10:00, 월–금** (중국 공휴일 제외). 그 외 전부 off-peak.
off-peak는 peak의 **절반**입니다.

> 참고: `deepseek-v4-pro`는 요금표에 남아 있지만(캐시미스 $1.32 / 출력 $3.96 peak)
> 2026-09-14부터 **요청이 V4.1-Flash로 라우팅되고 Flash 요금이 청구**됩니다.
> 새 코드에서 선택할 이유가 없습니다.

### 이 숫자가 설계에 주는 제약

```
캐시 히트 : 캐시 미스 = 1 : 50
off-peak  : peak      = 1 : 2
────────────────────────────────
최악 대비 최선        = 1 : 100   (peak·캐시미스 vs off-peak·캐시히트)
```

**프롬프트 캐시 적중률은 성능 최적화가 아니라 비용의 지배 변수입니다.** §5에서 다룹니다.

---

## 3. DeepSeek Harness (`dsh`) 검토

### 3.1 무엇인가

- DeepSeek AI의 **오픈소스 에이전트 하네스**. MIT. TypeScript.
- "Everything is a Plugin" — [Cordis](https://github.com/cordiverse/cordis) 플러그인 프레임워크
  위에 서 있고, **모델 어댑터·툴 레지스트리·세션 로그·에이전트 루프 자체가 전부 플러그인**이라
  설정으로 교체 가능합니다. 특권 코어가 없습니다.
- **Agent = Model + Harness.** dsh는 모델이 아닙니다. 모델 ID도 없습니다 — V4.1-Flash 등을
  설정해서 씁니다.
- 실행 단위는 **프로필**(`web`, `headless`, `sdk`, `sdk-minimal`, `acp`) + **번들** 조합.
- **developer preview**이고 "호환성 파괴 변경이 있을 것"이라고 명시합니다.

### 3.2 Python에서 쓰는 방법

```sh
python -m pip install deepseek-harness-sdk
```

```python
from deepseek_harness import DeepSeekHarness

with DeepSeekHarness(
    dsh_home="/absolute/path/to/isolated-dsh-home",  # 필수. ~/.dsh를 절대 자동 탐색하지 않는다
    cwd="/absolute/path/to/workspace",
    provider="deepseek-official",
    model="deepseek-flash",
    reasoning_effort="max",
    max_tokens=49_152,
) as harness:
    result = harness.run("Say hi.", session_id="example-001")
print(result.final_response)
```

구조상 중요한 사실: **Python SDK는 번들된 `dsh` CLI를 서브프로세스로 띄워
stdio 위 newline-delimited JSON-RPC로 대화합니다.** `deepseek-harness-runtime-bin` 휠이
플랫폼별 `dsh` 바이너리를 담고, 클라이언트가 `dsh --profile sdk`를 실행합니다.
즉 **Python에서 쓰더라도 Node 런타임이 프로세스 트리에 들어옵니다**(시스템 Node 설치는 불필요).

`harness.resume_session(id)`로 영속 히스토리를 복원할 수 있고, 세션은 `$DSH_HOME` 안에
JSONL로 저장됩니다.

### 3.3 가져올 만한 설계 — 실제로 가져옵니다

dsh의 아키텍처 문서는 우리가 독립적으로 도달한 결론과 여러 군데에서 일치하고, 몇 군데는
**우리보다 낫습니다.** 아래는 AWP가 채택하는 것들입니다.

| dsh 개념 | 내용 | AWP 채택 |
|---|---|---|
| **"Model-visible means logged"** | 모든 모델 요청은 로그에서 재구성 가능해야 한다. 새 모델 가시 입력은 세션 이벤트를 요구한다 | **D4와 동일.** 명문화해서 가져온다 |
| **`deriveMessages()`** | 로그 → 모델 히스토리 투영. 하네스 무상태 | `derive_messages(events) -> list[WireMessage]`로 구현 |
| **`assistant/attempt`** | 실패·재시도·취소·스트림 오류 시도를 **로그에만** 남기고 모델 히스토리에는 넣지 않는다 | **채택.** `agent.message_attempt` 이벤트 신설. 레퍼런스의 "placeholder 봉합"보다 훨씬 깔끔하다 |
| **turn / step 구분** | step = 모델 요청 1회 + 그 요청이 부른 툴들. turn = 0개 이상의 step | **채택.** 우리 이벤트로는 turn≈`session.status_running`/`_idle`, step≈`span.model_request_start`/`_end` |
| **waterfall 확장점** | `agent/pre-step`, `agent/request`, `tools/pre-execute`, `tools/execute`, `tools/post-execute`가 `next()` 위임형 | **채택.** 승인·감사·예산·레다크션을 루프 수정 없이 끼운다 |
| **freeze된 요청** | assembly 후 요청을 동결하고, 재시도는 assembly와 pre-step을 반복하지 않는다 | **채택.** 재시도마다 프롬프트가 달라지면 캐시가 매번 미스된다 (§5) |
| **capability seam = 3역할** | Service Definition + Service Provider + Consumer. 하나만으로는 seam이 아니다 | **채택.** 우리 Port 규칙 R6의 정확한 표현 |
| **approval: `allowed-once`** | 결과는 `allowed-once \| rejected \| cancelled \| unavailable`. 답변자 부재·예외·비정합은 **`unavailable`이고 게이트를 열지 않는다**(fail-closed) | **채택.** D8을 이 어휘로 정의 |
| **approval 요청은 툴 인자를 담지 않는다** | 이미 스트리밍된 툴 호출에 `callId`로 연결한다. 두 번째 복사본이 drift하지 않게 | **채택.** `approvals.input_summary`만 두고 전체 인자는 `callId`로 이벤트를 참조 |
| **approval 감사 이벤트는 log-only** | `approval/asked` + `approval/decided`는 모델 전사에 들어가지 않는다 | **채택.** 승인 사실이 모델 컨텍스트를 오염시키면 안 된다 |
| **sandbox = argv 래핑** | 같은 실행 세계의 subprocess argv를 파일 효과 정책으로 감싼다. 플랫폼 러너에 소비자를 결합시키지 않는다 | **채택.** [07](07-sandbox.md) 티어 P의 모델 |
| **`enforcement: full \| partial`** | "보고되는 사실". 절대적 경계가 필요한 호출자는 `partial`을 `full`로 취급해서는 안 된다 | **채택.** D6의 정확한 표현 |
| **`denialSignatures` / `runnerFailureRules`** | 백엔드별 stderr 방언(bwrap은 EROFS, Landlock은 EACCES, Seatbelt는 EPERM)을 구분하고, "샌드박스가 거부함"과 "샌드박스 러너가 고장남"을 분리 | **채택.** 이것이 없으면 인프라 장애가 "작업 실패"로 모델에 보고된다 |
| **per-call 정책** | 샌드박스 정책을 provider에 고정하지 않고 호출마다 실어 보낸다. 동시에 두 소비자가 다른 경계로 돌 수 있다 | **채택.** 승인된 1회 상향(escalated retry)이 자연히 표현된다 |

### 3.4 그런데 왜 dsh를 그대로 쓰지 않는가 (D11)

| 이유 | 설명 |
|---|---|
| **정본 로그가 둘이 된다** ★ | dsh는 "Model-visible means logged"를 **자기 세션 로그**(`$DSH_HOME`의 `session.vN.jsonl`)로 구현한다. 우리 `session_events`도 같은 주장을 한다. 둘 중 무엇이 모델 컨텍스트의 원천인지 모호해지는 순간 D2·D4가 깨지고 **감사 추적이 둘로 갈라진다.** 사내 플랫폼에서 감사 추적 분열은 치명적이다 |
| **실행 권한 모델이 맞물리지 않는다** | 우리는 turn 경계를 DB lease/fence로 감싼다(D3). dsh의 turn은 자기 프로세스가 소유한다. fence 검증을 dsh의 turn 안쪽에 끼울 공식 지점이 없다 |
| **developer preview** | "호환성 파괴 변경이 있을 것"을 스스로 명시한다. 사내 플랫폼의 기반으로 핀하기엔 이르다 |
| **런타임 중첩** | 모든 runtime-worker Pod에 Node 런타임 + `dsh` 바이너리가 들어간다. 이미지 크기·기동 시간·공급망 표면이 늘고, 장애 시 추적 경계가 Python↔Node로 쪼개진다 |
| **샌드박스 세계가 다르다** | dsh의 `ctx.fs`와 `ctx.subprocess`는 "하나의 실행 세계"를 공유하도록 설계되어 있다(그래서 remote로 바꾸면 Bash·PTY·LSP가 함께 이동한다 — 좋은 설계다). 우리 샌드박스는 **티어 W에 셸이 없다**([07](07-sandbox.md)). 그 세계를 dsh에 공급하려면 provider를 새로 쓰는 셈이고, 그러면 "dsh를 쓴다"는 이점이 대부분 사라진다 |
| **툴 로스터가 과하다** | dsh 툴 카탈로그는 `plugin_manager`, `cordis_inspect_*`, `create_worktree`, `ralph`, `workflow`, `terminal_*` 등 사내 에이전트에게 주면 안 되는 것까지 포함한다. 끄는 것보다 켜는 것이 안전하다 |

### 3.5 그럼 dsh를 어디에 쓰는가

세 군데에서 실제로 씁니다.

1. **1주차 스파이크.** 자체 루프를 쓰기 전에 `deepseek-harness-sdk`로 V4.1-Flash의 실제
   거동(툴 호출 포맷, `reasoning_effort` 영향, 긴 컨텍스트 비용)을 측정합니다. 우리 루프의
   목표치를 여기서 뽑습니다.
2. **벤치마크 기준선.** 같은 과제를 dsh와 AWP 하네스로 돌려 품질·토큰·시간을 비교합니다.
   우리 루프가 눈에 띄게 못하면 그것은 우리 문제입니다.
3. **교체 가능한 대안 하네스.** `agents.document.harness = "dsh"`를 2단계에 지원합니다.
   그때 **세션 로그는 단방향 투영**입니다 — dsh의 JSONL을 읽어 우리 `session_events`로
   project하고, 역방향은 없습니다. 정본은 언제나 우리 쪽입니다.

---

## 4. AWP 하네스 설계

### 4.1 턴 루프

dsh의 turn/step 구조를 우리 이벤트 어휘로 옮긴 것입니다.

```
claim(fence) 획득 후 ─────────────────────────────────────────────────────┐
                                                                          │
turn 시작  → session.status_running                                       │
  ① 입력 확정 (pre_step 훅)                                               │
     pending → promote → events (seq 부여)                                │
     훅이 입력을 재작성/거부할 수 있다. 거부되면 step 없이 turn 종료        │
  ② 프롬프트 조립                                                          │
     system prompt 섹션 + 툴 스키마 + 스킬/메모리 안내문                    │
     ← prefix 안정성이 여기서 결정된다 (§5)                                 │
  ③ 모델 히스토리 파생                                                      │
     derive_messages(events)  — 압축 경계부터. 실패 시도는 제외             │
  ④ 요청 동결(freeze)                                                      │
     이후 재시도는 ②③을 반복하지 않는다                                     │
  ⑤ step 시작 → span.model_request_start                                   │
     ModelPort.stream(card, messages, tools, effort, max_tokens)           │
       text_delta        → agent.message_chunk  (스트림 전용, 영속 안 함)   │
       thinking_delta    → agent.thinking       (진행 신호)                 │
       tool_call_*       → agent.tool_use                                  │
       usage / finish    → span.model_request_end(+model_usage)            │
     실패/취소 시 → agent.message_attempt  (로그에만. 모델 히스토리 제외)    │
  ⑥ 툴 실행 파이프라인                                                       │
     pre_execute 훅  : 권한 정책 판정 → 승인 필요 시 pending 적재 후 중단    │
                       예산 확인 · 감사 기록                                │
     execute        : fence 검증 → SandboxPort / 호스트 함수                │
     post_execute 훅 : 출력 상한(100K자) 초과 시 파일로 spill               │
                       비밀 패턴 레다크션 · 감사 기록                       │
     → agent.tool_result                                                   │
  ⑦ 툴이 다음 요청을 요구하거나 새 입력이 도착했으면 → ⑤로 (다음 step)       │
  ⑧ turn 종료 전                                                           │
     메모리 동기화(fence 검증) · 사용량 적립 · stop_reason 결정             │
turn 종료  → session.status_idle{stop_reason}   ← 정확히 한 번 보장         │
                                                                          │
settle(completed | failed | cancelled) ───────────────────────────────────┘
```

### 4.2 waterfall 훅

루프를 고치지 않고 정책을 끼우는 지점입니다. 각 훅은 `next()`로 위임합니다.

| 훅 | 끼우는 것 | 1단계 리스너 |
|---|---|---|
| `pre_step` | 입력 재작성/거부 | 예산 초과 시 거부, 인터럽트 확인 |
| `pre_request` | 요청 직전 | 프롬프트 캐시 진단, 요청 크기 상한 |
| `pre_execute` | 툴 실행 전 | **권한 정책 판정**, 예산, 감사, 샌드박스 정책 해석 |
| `execute` | 실행 자체 | 샌드박스 / 호스트 함수 / MCP |
| `post_execute` | 결과 후처리 | spill, 레다크션, 감사 |
| `turn_stopping` | 턴 종료 직전 (serial, `next()` 없음) | 메모리 동기화, 사용량 확정 |

### 4.3 툴 레지스트리

```python
# packages/ma_application/src/ma_application/tools/registry.py
@dataclass(frozen=True, slots=True)
class ToolEntry:
    name: str
    kind: ToolKind  # builtin | mcp | custom | delegation
    schema: ToolSchema
    executor: ToolExecutor | None  # None = 승인 대기 상태로 노출된다
    policy: PermissionPolicy  # always_allow | always_ask
    sandbox_mode: SandboxMode | None  # 실행에 필요한 파일 효과 수준


def build_tools(
    agent: AgentDefinition,
    *,
    sandbox: SandboxPort | None,
    grants: Sequence[ToolGrant] = (),  # 승인된 1회 호출
) -> ToolRegistry: ...
```

**`kind`를 실체로 들고 있는 것이 중요합니다.** 레퍼런스는 "커스텀 툴인지"를 이름 하드코딩
목록으로 판별해서 `schedule_*`·`browser_*`에 `always_ask`를 걸면 오분류됩니다. `kind`가
있으면 `stop_reason` 결정이 이름에 의존하지 않습니다([02](02-architecture.md) §5).

**`grants`가 승인 재개의 정확성을 만듭니다.** 레퍼런스는 승인 후 툴을 재구성할 때도
스트리핑이 그대로 적용되어 **실행 함수가 없고, 결과 없이 재개**될 수 있습니다. `grants`에
`tool_call_id`가 있으면 그 호출에 대해서만 executor를 유지합니다.

### 4.4 내장 툴 — 8개, 공식 이름 그대로

| 툴 | 실행 위치 | 비고 |
|---|---|---|
| `bash` | **샌드박스** (티어 P만) | 기본 120s, 최대 600s. 티어 W에서는 미등록 |
| `read` | 호스트 함수 | 텍스트/이미지/PDF. 이미지는 카드가 `supports_vision`일 때만 |
| `write` | 호스트 함수 | 워크스페이스 경계 검사 |
| `edit` | 호스트 함수 | `old_string` 유일성 검사, `replace_all` |
| `glob` | 호스트 함수 | mtime 정렬, 상위 N개 |
| `grep` | 호스트 함수 | 번들된 ripgrep을 **호스트에서** 실행 |
| `web_fetch` | **신뢰 영역** | 환경 `networking.allowed_hosts`를 리다이렉트 홉마다 검사 |
| `web_search` | **신뢰 영역** | provider는 설정 |

**호스트 함수 5개가 티어 W를 가능하게 합니다** — 자세한 근거는 [07](07-sandbox.md) §3.

출력 상한은 **100,000자**이고 초과분은 샌드박스 파일로 spill한 뒤 모델에는 잘린 프리뷰 +
경로를 줍니다(공식 CMA와 같은 동작).

### 4.5 하네스 교체

```python
class Harness(Protocol):
    name: str

    async def run(self, ctx: HarnessContext) -> HarnessOutcome: ...
```

| 하네스 | 1단계 | 설명 |
|---|---|---|
| `default` | ✅ | 위 §4.1 루프 |
| `dsh` | 2단계 | dsh 서브프로세스 + 단방향 로그 투영 (§3.5) |
| `acp` | 3단계 | 외부 에이전트 프록시 |

`agents.document.harness`로 고르고, 세션은 `agent:version:harness`로 하네스 인스턴스를
스코프합니다(프로세스를 유지하는 하네스를 위해).

---

## 5. 비용 설계 — 이 모델에서 제일 중요한 장

### 5.1 두 배수

```
            캐시 미스 입력  $0.30/1M  (peak)
                  ↓  ÷50
            캐시 히트 입력  $0.006/1M (peak)

            peak           ×1.0
                  ↓  ÷2
            off-peak       ×0.5
```

### 5.2 구체적인 예산 계산

사내 전형 세션: 시스템 프롬프트 + 툴 스키마 8K, 대화 누적 평균 60K, 10 step, 출력 step당 2K.

| 시나리오 | 입력 토큰 | 출력 | peak 비용 | off-peak |
|---|---|---|---|---|
| **캐시 전무** (prefix가 매 step 바뀜) | 10 step × 68K = 680K 전부 미스 | 20K | $0.204 + $0.024 = **$0.228** | $0.114 |
| **prefix 캐시 적중** (8K 고정 + 대화 증분만 미스) | 히트 ≈ 600K, 미스 ≈ 80K | 20K | $0.0036 + $0.024 + $0.024 = **$0.052** | $0.026 |
| 개선 | — | — | **4.4×** | **8.8× (최악 대비)** |

세션 1만 건/월이면 월 $2,280 → $260. **프롬프트 캐시 설계가 그대로 예산입니다.**

### 5.3 캐시 적중을 깨는 것들 — 금지 목록

| 하지 말 것 | 왜 |
|---|---|
| 시스템 프롬프트에 현재 시각·요청 ID·세션 ID를 넣기 | prefix 1바이트가 바뀌면 그 뒤 전부 미스 |
| 툴 목록을 매 요청 다른 순서로 직렬화 | 같은 이유. 툴 스키마는 정렬 고정 |
| 재시도마다 프롬프트를 다시 조립 | §4.1 ④ 요청 동결로 막는다 |
| 메모리/스킬 안내문을 요청마다 재생성 | 내용이 같으면 문자열도 같아야 한다 |
| 압축을 메모리에만 들고 있기 | 크래시 후 재구성이 달라져 전체 미스 |
| 모델 카드를 턴 중간에 바꾸기 | 캐시는 모델 스코프다. 세션 단위로 고정 |

검증: `usage`의 캐시 히트 토큰이 반복 요청에서 0이면 **조용한 무효화가 있는 것**입니다.
`pre_request` 훅에 캐시 적중률 메트릭을 붙여 **상시 감시**합니다.

### 5.4 off-peak 스케줄링

peak은 UTC 01:00–04:00, 06:00–10:00 (월–금). 한국시간(UTC+9)으로는 **10:00–13:00,
15:00–19:00**이 peak입니다 — 정확히 업무 시간입니다.

| 워크로드 | 처리 |
|---|---|
| 사용자 대화형 세션 | 그대로. 사람이 기다린다 |
| cron 배포(일일 리포트, 야간 정리) | **off-peak 창으로 민다.** `deployments.off_peak_preferred` |
| 대량 재처리 | off-peak 큐에 쌓고 창이 열리면 drain |
| 승인 대기 중인 세션 | 재개 시점이 자연히 늦어진다. 추가 조치 불필요 |

스케줄러가 `deployments.schedule`을 해석할 때 `off_peak_preferred=true`면 다음 off-peak
창의 시작으로 옮깁니다. **단, peak 창 정의도 모델 카드의 `pricing.peak_windows`에서
읽습니다** — provider가 바뀌면 창도 바뀝니다.

### 5.5 그 밖의 지렛대 (순서대로)

1. **캐시 prefix 안정화** — 무료. 최대 4.4×
2. **off-peak 이동** — 무료(지연을 감수). 2×
3. **출력 토큰 위생** — 장황한 응답을 프롬프트로 억제. 출력이 입력보다 4× 비싸다
4. **툴 결과 상한·spill** — 100K자 상한이 컨텍스트 폭증을 막는다
5. **압축 시점 조정** — 늦게 압축하면 미스 입력이 커지고, 일찍 압축하면 정보가 준다
6. **`reasoning_effort` 하향** — 품질을 거래한다. 측정 후에만
7. **더 작은 모델로 분기** — 요약·분류 경로만 별도 모델 카드로. **마지막 수단**
   (카드가 다르면 캐시 네임스페이스도 달라진다)

> 7번을 마지막에 두는 이유: 모델을 섞으면 캐시가 모델별로 쪼개져 1번의 이득을 깎습니다.
> 먼저 1~5를 측정하고, 그래도 부족할 때만 모델을 나눕니다.

---

## 6. 관측

| 메트릭 | 이유 |
|---|---|
| `model_cache_hit_ratio` (카드별) | §5.3의 상시 감시 지표. 떨어지면 즉시 알람 |
| `model_request_duration` p50/p95/p99 | 턴 지연의 지배 항 |
| `model_tokens{kind=input_hit\|input_miss\|output}` | 비용 계산의 원천 |
| `model_cost_cents` (워크스페이스·에이전트별) | 예산 대시보드 |
| `model_finish_reason` 분포 | `max-tokens`가 많으면 `max_tokens` 또는 압축 설정 문제 |
| `harness_step_count` per turn | 비정상 루프 탐지 |
| `tool_call_count{kind,name}` | 툴 설계 피드백 |
| `off_peak_ratio` | off-peak 스케줄링이 실제로 작동하는지 |

`span.model_request_start/end` 이벤트가 이 메트릭의 원천이고, 동시에 세션 상세 UI의
"이 턴이 얼마나 걸렸고 얼마 썼는가"를 그립니다.

---

## 7. 다음 문서

툴이 실제로 실행되는 곳 → [07. 샌드박스](07-sandbox.md)
