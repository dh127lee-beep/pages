# 04. API 구조

> 다이어그램: [`svg/10-api-surface.svg`](svg/10-api-surface.svg)
> 공식 계약 원문: [`../ref/api/README.md`](../ref/api/README.md) (110 엔드포인트)

---

## 1. 두 개의 lane

AWP는 HTTP 표면을 두 갈래로 갖습니다. 1단계에는 왼쪽만 구현하지만, **처음부터 코드가
분리되어 있어야** 나중에 오른쪽을 켤 때 서로를 오염시키지 않습니다 ([D9](README.md#핵심-설계-결정)).

| | 내부 lane | 공식 호환 lane |
|---|---|---|
| 경로 | `/api/v1/*` | `/v1/*` |
| 소비자 | Console SPA, `aw` CLI, 사내 서비스 | `@anthropic-ai/sdk`, `anthropic` (Python) — baseURL만 교체 |
| 스키마 | 우리가 정한다. 사내 개념(workspace/approval/budget/audit) 포함 | **공식 wire 계약을 그대로.** 필드 추가 금지 |
| 인증 | 쿠키 세션 + API 키 | API 키 (`x-api-key`) |
| 버저닝 | 경로 `v1`, 필드 추가는 하위 호환 | 공식 beta 헤더 체계를 그대로 |
| 단계 | 1단계 | 2단계 |
| 패키지 | `ma_api.internal` | `ma_api.compat` |

두 lane은 **같은 `ma_application` 유스케이스를 호출합니다.** 분리는 wire 레이어에서만
일어납니다. 그래서 비즈니스 규칙이 두 벌로 갈라지지 않습니다.

```
ma_api.internal.routes.agents ──┐
                                 ├──▶ ma_application.agents.AgentsUseCases ──▶ AgentStore
ma_api.compat.routes.agents  ──┘
     (wire 매퍼만 다르다)
```

### 공식 lane에 필드를 추가하지 않는 이유

공식 shape에 사내 필드(`approval_policy_id` 같은)를 넣으면, 그 순간 공식 SDK로는 표현할 수
없는 요청이 생깁니다. 그러면 "공식 SDK 호환"이라는 주장이 거짓이 됩니다. 확장은 내부 lane에만
둡니다. 레퍼런스의 ADR 0005/0007이 지키는 선과 같습니다.

---

## 2. 공통 규약

### 2.1 인증 — 우선순위

```
1. x-api-key                      → API 키 (워크스페이스에 고정)
2. Authorization: Bearer <token>  → 서비스 토큰 / 샌드박스 워커 세션 토큰
3. 쿠키 세션 + x-active-workspace  → Console 사용자 (멤버십으로 워크스페이스 검증)
4. 없음                            → 401
```

**워크스페이스 결정은 인증 직후 한 번만** 일어납니다. 그 뒤로는 `workspace_id`가 요청
컨텍스트에 고정되고, 애플리케이션 레이어는 파티션 키로만 씁니다 ([03](03-layers.md) §3).

`x-active-workspace`는 쿠키 사용자에게만 의미가 있고, 멤버십에 없는 워크스페이스를 지정하면
403입니다. API 키는 발급 시점에 워크스페이스가 정해지므로 이 헤더를 **무시합니다**(덮어쓰기
허용하면 키 탈취 시 횡적 이동이 가능해집니다).

### 2.2 역할과 권한

| 역할 | 할 수 있는 것 |
|---|---|
| `viewer` | 세션·에이전트 조회, 이벤트 스트림 구독 |
| `operator` | 세션 생성/인터럽트, 메시지 전송, (정책이 허용하면) 승인 |
| `admin` | 에이전트·환경·볼트·메모리·예산 관리, 멤버 초대 |
| `owner` | 워크스페이스 설정, 역할 변경, 삭제 |

권한 판단은 **L4 유스케이스에서** 합니다. 라우터에서 하면 CLI·웹훅·스케줄러가 같은 규칙을
우회합니다.

### 2.3 에러 envelope

공식 계약과 같은 모양을 **두 lane 모두** 씁니다. Console이 특별 취급을 안 하게 됩니다.

```json
{ "type": "error",
  "error": { "type": "not_found_error", "message": "Agent agent_x was not found" } }
```

| `error.type` | HTTP | 쓰는 때 |
|---|---|---|
| `invalid_request_error` | 400 | 스키마 위반, 잘못된 파라미터 |
| `authentication_error` | 401 | 자격증명 없음/무효 |
| `permission_error` | 403 | 역할 부족, 다른 워크스페이스 접근 |
| `not_found_error` | 404 | 없음 또는 **다른 워크스페이스에 있음**(존재를 누설하지 않는다) |
| `conflict_error` | 409 | `version_conflict`, `idempotency_conflict`, 상태 전이 위반 |
| `rate_limit_error` | 429 | 레이트 리밋/쿼터 |
| `budget_exceeded_error` | 409 | 예산 상한 도달 (사내 확장) |
| `approval_required_error` | 409 | 승인 없이 실행 시도 (사내 확장) |
| `api_error` | 500 | 내부 오류. **egress 스키마 검증 실패도 여기** |

### 2.4 멱등성

`POST`는 모두 `Idempotency-Key` 헤더를 받습니다. 이벤트 전송은 특히 중요합니다.

```
event id = sha256(idempotency_key + index)   ← 결정적 생성
→ 이미 존재하면 payload 비교
   같으면   : 202 + 기존 결과 (재반환)
   다르면   : 409 idempotency_conflict
```

재시도 길이가 다른 경우(3개 보냈다가 2개로 재시도)를 잡기 위해 `prefix+N`(다음 위치)도 함께
조회합니다.

### 2.5 페이지네이션

커서 기반입니다. offset은 쓰지 않습니다(이벤트가 계속 들어오는 테이블에서 offset은 틀립니다).

```
GET /api/v1/agents?limit=50&page=<cursor>
→ { "data": [...], "has_more": true, "next_page": "<cursor>" }
```

커서는 `(created_at, id)` 복합키를 base64url로 인코딩한 것입니다. 인덱스가 정확히 이 순서로
있어야 합니다 ([05](05-database.md) §4).

### 2.6 낙관적 동시성

```
GET  → 응답에 "version" (또는 세션은 "revision")
POST → 본문에 "expected_version"
     → 불일치면 409 { error: { type: "conflict_error", actual_version: 7 } }
```

### 2.7 수정은 `POST`

공식 계약을 따릅니다. `PATCH`가 아니라 `POST /v1/<resource>/{id}`입니다. 이유는 공식 API가
그렇게 되어 있고, 두 lane의 모양을 다르게 할 이유가 없기 때문입니다.

### 2.8 삭제와 아카이브

| 동작 | 의미 |
|---|---|
| `POST .../archive` | 소프트 삭제. 조회는 되지만 **새 사용이 불가**. 기본 동작 |
| `DELETE ...` | 하드 삭제. 데이터가 사라진다. 세션·리소스·메모리에만 있음 |

에이전트·환경·볼트는 **하드 삭제가 없습니다.** 과거 세션이 그 버전을 참조하므로, 지우면
감사 추적이 깨집니다.

---

## 3. 내부 API 전체 (`/api/v1/*`) — 1단계

### 3.1 워크스페이스 · 사용자

| Method | Path | 설명 | 역할 |
|---|---|---|---|
| `GET` | `/api/v1/me` | 내 정보 + 멤버십 목록 | 인증만 |
| `GET` | `/api/v1/workspaces` | 내가 속한 워크스페이스 | 인증만 |
| `POST` | `/api/v1/workspaces` | 워크스페이스 생성 | 플랫폼 관리자 |
| `GET` | `/api/v1/workspaces/{id}` | 단건 | viewer |
| `POST` | `/api/v1/workspaces/{id}` | 설정 수정 | owner |
| `GET` | `/api/v1/workspaces/{id}/members` | 멤버 목록 | viewer |
| `POST` | `/api/v1/workspaces/{id}/members` | 멤버 초대 | admin |
| `POST` | `/api/v1/workspaces/{id}/members/{uid}` | 역할 변경 | owner |
| `DELETE` | `/api/v1/workspaces/{id}/members/{uid}` | 멤버 제거 | owner |
| `GET` | `/api/v1/api_keys` | API 키 목록(해시만) | admin |
| `POST` | `/api/v1/api_keys` | 키 발급 (**평문은 이때 한 번만**) | admin |
| `POST` | `/api/v1/api_keys/{id}/revoke` | 폐기 | admin |

### 3.2 에이전트 · 스킬 · 모델

| Method | Path | 설명 |
|---|---|---|
| `POST` | `/api/v1/agents` | 생성 |
| `GET` | `/api/v1/agents` | 목록 (`include_archived`, `created_at[gte|lte]`) |
| `GET` | `/api/v1/agents/{id}` | 단건 (현재 버전) |
| `POST` | `/api/v1/agents/{id}` | 수정 → **새 버전** |
| `GET` | `/api/v1/agents/{id}/versions` | 버전 목록 |
| `GET` | `/api/v1/agents/{id}/versions/{v}` | 특정 버전 |
| `POST` | `/api/v1/agents/{id}/archive` | 아카이브 |
| `POST` | `/api/v1/agents/{id}/validate` | **설정 검증만** (사내 확장: 저장 전 린트) |
| `POST` | `/api/v1/skills` · `GET` · `GET /{id}` · `POST /{id}/archive` | 스킬 (2단계) |
| `GET` | `/api/v1/models` | 사용 가능한 모델 카드 |
| `POST` | `/api/v1/models` | 모델 카드 등록 (admin) |

### 3.3 환경

| Method | Path | 설명 |
|---|---|---|
| `POST` | `/api/v1/environments` | 생성 (`config.type`: `cloud` \| `self_hosted`) |
| `GET` | `/api/v1/environments` · `GET /{id}` · `POST /{id}` · `POST /{id}/archive` | CRUD |
| `GET` | `/api/v1/environments/{id}/capabilities` | **사내 확장**: egress 강제 수준 등 실제 능력 보고 ([08](08-infrastructure.md) §4) |

`environment_work/*`(self-hosted 워커 오케스트레이션)는 2단계입니다.

### 3.4 세션

| Method | Path | 설명 |
|---|---|---|
| `POST` | `/api/v1/sessions` | 생성 (`agent_id`+`agent_version`, `environment_id`, `initial_events`, `resources`, `vault_ids`, `budget`) |
| `GET` | `/api/v1/sessions` | 목록 (`status`, `agent_id`, `created_by`, 기간) |
| `GET` | `/api/v1/sessions/{id}` | 단건 (상태, revision, usage, budget) |
| `POST` | `/api/v1/sessions/{id}` | 수정 (예산 변경, 설정 오버라이드) |
| `POST` | `/api/v1/sessions/{id}/archive` | 아카이브 → `terminated` |
| `DELETE` | `/api/v1/sessions/{id}` | 하드 삭제 (이벤트·산출물까지) |
| `POST` | `/api/v1/sessions/{id}/events` | **이벤트 전송** (§4) |
| `GET` | `/api/v1/sessions/{id}/events` | 이벤트 목록 (커서, `after_seq`) |
| `GET` | `/api/v1/sessions/{id}/events/stream` | **SSE 스트림** (§5) |
| `GET` | `/api/v1/sessions/{id}/pending` | 아직 승격 안 된 입력 (사내 확장: UI가 "대기 중" 표시) |
| `GET` | `/api/v1/sessions/{id}/resources` · `POST` · `GET /{rid}` · `POST /{rid}` · `DELETE /{rid}` | 세션 리소스(파일/레포/메모리/env) |
| `GET` | `/api/v1/sessions/{id}/threads` · `GET /{tid}` · `POST /{tid}/archive` | 스레드 (3단계. 1단계는 primary 하나) |
| `GET` | `/api/v1/sessions/{id}/outputs` | 산출물 목록 |
| `GET` | `/api/v1/sessions/{id}/outputs/{oid}/content` | 산출물 다운로드 (서명 URL 리다이렉트) |

### 3.5 자격증명

| Method | Path | 설명 |
|---|---|---|
| `POST` | `/api/v1/vaults` · `GET` · `GET /{id}` · `POST /{id}` · `POST /{id}/archive` | 볼트 |
| `POST` | `/api/v1/vaults/{id}/credentials` | 자격증명 추가 (**평문 입력, 응답에 없음**) |
| `GET` | `/api/v1/vaults/{id}/credentials` | 목록 (메타데이터만) |
| `POST` | `/api/v1/vaults/{id}/credentials/{cid}` | 로테이션 |
| `POST` | `/api/v1/vaults/{id}/credentials/{cid}/archive` | 아카이브 |
| `POST` | `/api/v1/vaults/{id}/credentials/{cid}/validate` | 유효성 확인 (OAuth 갱신 진단) |

> **자격증명 평문은 어떤 GET으로도 돌아오지 않습니다.** 응답 스키마에 필드 자체가 없습니다
> (`extra="forbid"` + egress 재검증이 이를 기계적으로 보장).

### 3.6 메모리

| Method | Path | 설명 |
|---|---|---|
| `POST` | `/api/v1/memory_stores` · `GET` · `GET /{id}` · `POST /{id}` · `POST /{id}/archive` · `DELETE /{id}` | 스토어 |
| `POST` | `/api/v1/memory_stores/{id}/memories` | 메모리 생성 (`precondition.content_sha256`) |
| `GET` | `/api/v1/memory_stores/{id}/memories` · `GET /{mid}` · `POST /{mid}` · `DELETE /{mid}` | 메모리 CRUD |
| `GET` | `/api/v1/memory_stores/{id}/memory_versions` · `GET /{vid}` | 버전 감사 |
| `POST` | `/api/v1/memory_stores/{id}/memory_versions/{vid}/redact` | 레댁션 (live head는 거부) |

### 3.7 거버넌스 — 사내 확장

| Method | Path | 설명 | 역할 |
|---|---|---|---|
| `GET` | `/api/v1/approvals` | 승인 인박스 (`state=pending`) | operator |
| `GET` | `/api/v1/approvals/{id}` | 단건 (툴 입력 요약 포함) | operator |
| `POST` | `/api/v1/approvals/{id}` | **승인 또는 거부** `{decision, reason}` | 정책이 정한 역할 |
| `GET` | `/api/v1/approval_policies` · `POST` · `POST /{id}` · `DELETE /{id}` | 정책 | admin |
| `GET` | `/api/v1/budgets` | 워크스페이스/에이전트별 예산 | viewer |
| `POST` | `/api/v1/budgets` | 설정 | admin |
| `GET` | `/api/v1/usage` | 사용량 집계 (기간·에이전트·사용자별) | viewer |
| `GET` | `/api/v1/audit` | 감사 로그 (커서, `actor`, `action`, `resource`, 기간) | admin 또는 auditor |
| `GET` | `/api/v1/audit/sessions/{id}` | **세션 하나의 전체 감사 재구성** | admin |

`/api/v1/audit/sessions/{id}`가 성공 기준의 "3클릭 내 재구성"을 뒷받침하는 엔드포인트입니다.
이벤트 로그 + 승인 이력 + 자격증명 사용 기록 + 샌드박스 명령 이력을 하나의 타임라인으로
합쳐서 돌려줍니다.

### 3.8 운영

| Method | Path | 설명 | 단계 |
|---|---|---|---|
| `POST` | `/api/v1/deployments` · `GET` · `GET /{id}` · `POST /{id}` | 배포(cron 템플릿) | 2 |
| `POST` | `/api/v1/deployments/{id}/pause` · `/unpause` · `/archive` · `/run` | 생애주기 | 2 |
| `GET` | `/api/v1/deployment_runs` · `GET /{id}` | 실행 기록 | 2 |
| `POST` | `/api/v1/files` | 파일 업로드 (multipart) | 1 |
| `GET` | `/api/v1/files/{id}` · `GET /{id}/content` · `DELETE /{id}` | 파일 | 1 |
| `POST` | `/api/v1/webhooks` · `GET` · `DELETE /{id}` | 웹훅 등록 | 2 |
| `GET` | `/health` · `/healthz` · `/readyz` | 헬스 (인증 없음) | 1 |
| `GET` | `/metrics` | Prometheus (내부 네트워크만) | 1 |

---

## 4. 이벤트 전송

```
POST /api/v1/sessions/{id}/events
Idempotency-Key: <uuid>
{
  "events": [ { "type": "user.message",
                 "content": [ {"type":"text","text":"..."} ] } ],
  "expected_revision": 12            // 선택
}
→ 202 { "accepted": [ {"id":"evt_...","type":"user.message"} ], "revision": 13 }
```

처리는 [02](02-architecture.md) §3의 단일 트랜잭션입니다. **200이 아니라 202**인 이유:
수용은 끝났지만 실행은 아직 시작되지 않았습니다.

### 4.1 보낼 수 있는 이벤트

| 타입 | 언제 | 본문 |
|---|---|---|
| `user.message` | 일반 메시지 | `content[]` (text / image / document) |
| `user.interrupt` | 실행 중단 | — |
| `user.tool_confirmation` | 툴 승인/거부 | `tool_call_id`, `decision`, `reason?` |
| `user.custom_tool_result` | 커스텀 툴 결과 | `tool_call_id`, `content`, `is_error?` |
| `user.tool_result` | `self_hosted` 환경에서 agent toolset 결과 | (2단계) |
| `user.define_outcome` | 루브릭 정의 | (3단계) |
| `system.message` | 특권 컨텍스트 주입 | `content`. **역할 `admin` 이상만** |

> `system.message`를 `operator`에게 열면 시스템 프롬프트 우회가 됩니다. 사내에서는
> 특히 `admin` 이상으로 제한하고 모든 호출을 감사합니다.
> `{"type":"redacted"}` 블록은 플랫폼이 내보내는 콘텐츠에만 나타나며, 사용자 이벤트에
> 포함되면 400입니다.

### 4.2 받는 이벤트 — 공식 분류를 그대로

[`reference.md`](../ref/claude-managed-agents/09-reference/reference.md)의 분류를 따릅니다.
1단계에서 실제로 쓰는 것에 ✅를 붙였습니다.

| 그룹 | 타입 | 1단계 |
|---|---|---|
| agent | `agent.message` | ✅ |
| | `agent.thinking` (진행 신호. 내용 없음) | ✅ |
| | `agent.tool_use` / `agent.tool_result` | ✅ |
| | `agent.mcp_tool_use` / `agent.mcp_tool_result` | 2단계 |
| | `agent.custom_tool_use` | ✅ |
| | `agent.thread_context_compacted` | ✅ |
| | `agent.thread_message_sent` | 3단계 |
| | `agent.thread_message_received` | 3단계 |
| | `agent.message_attempt` — 실패·취소·스트림 오류. **로그에만**, 모델 히스토리 제외 | ✅ |
| session | `session.status_running` | ✅ |
| | `session.status_idle` (+`stop_reason`) | ✅ |
| | `session.status_rescheduled` | ✅ |
| | `session.status_terminated` | ✅ |
| | `session.error`(+`retry_status`) / `session.deleted` / `session.updated` | ✅ |
| | `session.usage` (누적 사용량 + 예산) | ✅ |
| | `session.thread_created` | 3단계 |
| | `session.thread_status_running` · `session.thread_status_idle` | 3단계 |
| | `session.thread_status_rescheduled` · `session.thread_status_terminated` | 3단계 |
| workflow_run | `workflow_run.created` · `workflow_run.error` | 3단계 |
| | `workflow_run.status_running` · `workflow_run.status_idle` · `workflow_run.status_ended` | 3단계 |
| | `workflow_run.phase_started` · `workflow_run.phase_ended` | 3단계 |
| span | `span.model_request_start` | ✅ |
| | `span.model_request_end` (+`model_usage`) | ✅ |
| | `span.outcome_evaluation_start` · `span.outcome_evaluation_ongoing` · `span.outcome_evaluation_end` | 3단계 |
| system | `system.message` | ✅ |
| **스트림 전용** | `system.user_message_pending` / `_promoted` / `_cancelled` | ✅ ([02](02-architecture.md) §4) |
| | `agent.message_chunk`, `event_start`, `event_delta` | ✅ (영속 안 함) |

---

## 5. SSE 스트림 계약

```
GET /api/v1/sessions/{id}/events/stream?after_seq=42&event_deltas=true
Accept: text/event-stream
```

| 규칙 | 내용 |
|---|---|
| **재연결** | `after_seq`로 이어받는다. `Last-Event-ID` 헤더도 같은 의미로 받는다 |
| **replay** | 연결 시 `after_seq` 이후의 영속 이벤트를 먼저 모두 보낸 뒤 실시간으로 전환한다 |
| **중복** | at-least-once다. 클라이언트는 `event.id`로 dedupe해야 한다 |
| **순서** | 영속 이벤트는 `seq` 단조 증가. 스트림 전용 프레임은 `seq`가 없다 |
| **하트비트** | 15초마다 `: keepalive` 코멘트. 프록시 타임아웃 방지 |
| **종료** | `session.deleted` 또는 `session.status_terminated` 후 서버가 닫는다 |
| **백프레셔** | 클라이언트가 느리면 버퍼 한도 초과 시 연결을 끊는다. 클라이언트는 재연결해 replay |

### 프레임 모양

```
id: 43
event: agent.message
data: {"id":"evt_01H...","seq":43,"type":"agent.message","content":[...],"created_at":"..."}

event: system.user_message_pending
data: {"type":"system.user_message_pending","event_id":"evt_01H...","enqueued_at":"..."}

: keepalive
```

### 왜 WebSocket이 아닌가

이벤트 흐름은 **단방향**입니다(서버→클라이언트). 입력은 별도 `POST`로 들어옵니다. SSE는
프록시·로드밸런서·재연결 의미가 HTTP 그대로라 운영이 단순합니다. 양방향이 필요한 경우
(로컬 에이전트 bridge 같은)만 2단계에 WebSocket을 추가합니다.

---

## 6. 공식 호환 lane (`/v1/*`) — 2단계

### 6.1 켤 때의 원칙

1. **wire 계약의 유일한 출처는 공식 SDK가 만드는 타입**입니다. 우리 pydantic 스키마는 그
   타입을 보고 작성하고, 계약 테스트로 공식 SDK를 **블랙박스로** 돌려 검증합니다.
2. **beta 헤더를 리소스별로 게이트**합니다. 전역 게이트가 아닙니다.
3. 응답도 strict 스키마로 재검증합니다. 공식 shape에 없는 필드가 새면 500입니다.

```python
MANAGED_AGENTS_BETA = "managed-agents-2026-04-01"
DREAMING_BETA = "dreaming-2026-04-21"
MCP_TUNNELS_BETA = "mcp-tunnels-2026-06-22"
```

### 6.2 매핑 — 공식 리소스 ↔ 우리 유스케이스

| 공식 리소스 | 엔드포인트 수 | 우리 유스케이스 | 비고 |
|---|---|---|---|
| Agents | 6 | `AgentsUseCases` | 그대로 매핑 |
| Sessions | 20 | `SessionsUseCases`, `SessionEventsUseCases` | threads/*는 3단계까지 빈 목록 반환 |
| Environments | 15 | `EnvironmentsUseCases` | `work/*`는 `self_hosted` 구현 후 |
| Vaults | 13 | `VaultsUseCases` | 그대로 |
| Memory Stores | 14 | `MemoryUseCases` | 그대로 |
| Deployments | 8 | `DeploymentsUseCases` | 2단계 |
| Deployment Runs | 2 | 같음 | 2단계 |
| Dreams | 5 | — | 3단계. 그전엔 404 |
| Tunnels | 10 | — | 미지원. `not_found_error` |

**합계 93개 중 1단계 유스케이스로 덮이는 것이 78개**입니다. 나머지는 단계적으로 켭니다.

### 6.3 모양이 다른 지점 — 명시해 둘 것

| 항목 | 공식 | AWP | 처리 |
|---|---|---|---|
| 권한 정책 `auto` | 서버가 호출마다 위험 평가 | 미지원 | `invalid_request_error`: "auto policy is not supported" |
| 워크스페이스 헤더 | `anthropic-workspace-id` | `x-active-workspace` | 공식 lane에서는 공식 헤더 이름을 받는다 |
| 모델 ID | 실제 모델 문자열 | 모델 카드 핸들 | 공식 lane에서는 카드 핸들과 실제 모델 ID 둘 다 허용하고 해석한다 |
| 레이트 리밋 | 조직당 생성 300/분, 조회 1200/분 | 같은 수치로 시작 | `reference.md` 기준 |

---

## 7. 레이트 리밋과 쿼터

| 버킷 | 한도 | 키 |
|---|---|---|
| 생성 엔드포인트 | 300 req/min | 워크스페이스 |
| 조회 엔드포인트 | 1,200 req/min | 워크스페이스 |
| 이벤트 전송 | 60 req/min | 세션 |
| 파일 업로드 | 20 req/min, 100MB/req | 워크스페이스 |
| SSE 동시 연결 | 20 | 사용자 |
| 동시 실행 세션 | `workspace.max_concurrent_sessions` | 워크스페이스 |
| 일일 세션 생성 | `workspace.daily_session_quota` | 워크스페이스 |

리밋 초과는 429 + `Retry-After`. 쿼터 초과는 409 `budget_exceeded_error`
(재시도해도 안 되는 것이므로 429가 아닙니다).

---

## 8. 다음 문서

이 엔드포인트들이 읽고 쓰는 테이블 → [05. 데이터베이스 구조](05-database.md)
