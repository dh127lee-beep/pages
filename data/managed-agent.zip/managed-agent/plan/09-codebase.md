# 09. 코드베이스 구조

> 다이어그램: [`svg/19-codebase-tree.svg`](svg/19-codebase-tree.svg)
> Python 3.13 · uv 워크스페이스 · 25 패키지 + 5 앱 + 1 웹

---

## 1. 전체 트리

```
managed-agent/
├── pyproject.toml                  uv 워크스페이스 루트 (members = packages/*, apps/*)
├── uv.lock
├── .importlinter                   레이어 계약 ([03](03-layers.md) §5.1)
├── Makefile                        dev / test / lint / migrate / run
│
├── packages/                       ── 라이브러리. 프로세스를 만들지 않는다
│   │
│   │  L1 도메인
│   ├── ma_domain/                  순수 타입. 의존성 0
│   │
│   │  L3 Store 인터페이스
│   ├── ma_store/                   Protocol + 입출력 dataclass + union 결과
│   │
│   │  L2 Store 구현
│   ├── ma_store_memory/            dict 기반. 테스트·로컬
│   ├── ma_store_sql/               SQLAlchemy Core. "Agent를 아는" SQL은 여기만
│   ├── ma_sql/                     Engine/Connection Port + 방언 어댑터
│   │
│   │  L4 유스케이스
│   ├── ma_application/             검증·권한·페이지네이션·CAS. Port 선언
│   │
│   │  L5a HTTP
│   ├── ma_api/                     FastAPI 라우터 + pydantic wire
│   │   └── src/ma_api/
│   │       ├── internal/           /api/v1/*   ← 1단계
│   │       └── compat/             /v1/*       ← 2단계. 독립 (D9)
│   │
│   │  L5b 어댑터
│   ├── ma_adapters_sql/            application persistence Port ↔ ma_store_sql
│   ├── ma_adapters_blob/           FileContentPort ← 오브젝트 스토어
│   ├── ma_adapters_runtime/        스케줄러(cron) · 웹훅 서명 · 실시간 fanout
│   │
│   │  하네스와 모델  ([06](06-harness-and-model.md))
│   ├── ma_harness/                 턴 루프 · waterfall 훅 · derive_messages · ModelPort
│   ├── ma_model_deepseek/          DeepSeek 공식 어댑터 (OpenAI 포맷 + 확장)
│   ├── ma_model_openai_compat/     사내 게이트웨이 · vLLM 등
│   ├── ma_model_dsh/               (2단계) dsh 서브프로세스 하네스 + 단방향 로그 투영
│   │
│   │  샌드박스  ([07](07-sandbox.md))
│   ├── ma_sandbox/                 SandboxPort · SandboxPolicy · ConfinedArgv
│   │                               resolve_in_workspace (경계 검사 단일 진입점)
│   ├── ma_sandbox_wasm/            Wasmtime + WASI p1. 티어 W (기본)
│   ├── ma_sandbox_bwrap/           bubblewrap + Landlock argv 래핑. 티어 P
│   ├── ma_sandbox_local/           격리 없음. **테스트 전용** (프로덕션 기동 시 거부)
│   ├── ma_egress/                  MITM 프록시 라이브러리 + allowlist + 주입
│   │
│   │  L6 조립
│   ├── ma_platform/                WorkspaceAppRegistry · PortToken · AppModule · create_app
│   │
│   │  횡단
│   ├── ma_auth/                    인증 미들웨어 · principal 해석 · 역할 판정
│   ├── ma_governance/              승인 · 감사 · 예산 · 쿼터
│   ├── ma_observability/           구조화 로그 · OTel · 메트릭
│   ├── ma_connectors/              MCP 클라이언트 · Slack/메일 알림 (2단계)
│   └── ma_schema/                  Alembic 마이그레이션 — **스키마의 유일한 진실** (D2)
│
├── apps/                           ── 프로세스. 환경변수를 읽는 유일한 레이어
│   ├── control_plane/              FastAPI ASGI. API + 승인 + 감사 + Console 서빙
│   ├── runtime_worker/             claim → fence → 하네스 → settle
│   ├── scheduler/                  cron · 보존 · GC · 파티션 생성 (리더 선출)
│   ├── egress_proxy/               MITM 프록시 프로세스
│   └── cli/                        `aw` — 에이전트 apply, 세션 추적, 진단
│
├── web/console/                    React 19 + Vite + TanStack Query + Tailwind
│
├── deploy/                         ([08](08-infrastructure.md) §8)
│   ├── helm/awp/
│   ├── overlays/{dev,staging,prod}/
│   ├── argocd/
│   └── compose/                    로컬 개발 (postgres + minio + 전 앱)
│
├── tests/
│   ├── unit/           패키지별 단위
│   ├── contract/       Store 계약 (memory·sql 양쪽) · ModelPort 계약 · SandboxPort 계약
│   ├── integration/    testcontainers (postgres + minio)
│   ├── e2e/            세션 생성 → 이벤트 → 툴 → 승인 → 완료
│   ├── security/       경로 탈출 퍼징 · 자격증명 유출 스캔 · egress 우회 시도
│   └── fixtures/
│
├── tools/
│   ├── check_architecture.py       [03](03-layers.md) §5.2의 7개 검사
│   ├── probe_capabilities.py       노드의 실제 샌드박스/egress 능력 프로브
│   └── seed_dev.py                 개발용 워크스페이스·에이전트·모델 카드 시딩
│
└── plan/                           ← 이 문서 세트
```

---

## 2. 패키지 ↔ 레이어 ↔ 의존 방향

| 패키지 | L | import 가능 | import 금지 |
|---|---|---|---|
| `ma_domain` | L1 | (없음) | 전부. 표준 라이브러리만 |
| `ma_store` | L3 | `ma_domain` | 그 외 전부. **다른 `ma_store.*` 서브모듈끼리도 금지** |
| `ma_store_memory` | L2a | `ma_store`, `ma_domain` | SQLAlchemy, FastAPI |
| `ma_store_sql` | L2b | `ma_store`, `ma_domain`, `ma_sql` | FastAPI, pydantic |
| `ma_sql` | L2c | (드라이버만) | `ma_store`, `ma_domain` — Agent를 모른다 |
| `ma_application` | L4 | `ma_store`, `ma_domain` | SQLAlchemy, FastAPI, pydantic, httpx |
| `ma_api` | L5a | `ma_application`, `ma_domain`, `ma_auth` | SQLAlchemy, `ma_store_*`, `anthropic`, `openai` |
| `ma_adapters_*` | L5b | `ma_application`, `ma_store*`, 외부 SDK | `ma_api` |
| `ma_harness` | L5b | `ma_application`, `ma_domain`, `ma_sandbox` | provider SDK(어댑터가 들고 있다), `ma_api` |
| `ma_model_*` | L5b | `ma_harness`(Port만), provider SDK | `ma_application`, `ma_store*` |
| `ma_sandbox` | L5b | `ma_domain` | `kubernetes`, `wasmtime`, provider별 코드 |
| `ma_sandbox_*` | L5b | `ma_sandbox`, 해당 런타임 | 서로 다른 `ma_sandbox_*` |
| `ma_platform` | L6 | 위 전부 | `apps.*` |
| `apps/*` | L7 | 전부 | 서로 다른 app |

### 가장 중요한 세 가지 금지

```python
# ❌ ma_api가 Store를 직접 만진다 → 유스케이스 우회, 권한 검사 우회
from ma_store_sql import SqlAgentStore

# ❌ ma_application이 SQL을 안다 → 런타임 이식성 상실
from sqlalchemy import select

# ❌ ma_sandbox가 특정 런타임을 안다 → provider 중립성 상실
import wasmtime
```

CI가 `import-linter`로 막습니다 ([03](03-layers.md) §5.1).

---

## 3. 패키지 내부 모양 — 전부 같다

```
packages/ma_<name>/
├── pyproject.toml           이름·의존성·버전. 내부 패키지는 `workspace = true`
├── src/ma_<name>/
│   ├── __init__.py          공개 표면만 re-export
│   ├── <domain>.py          도메인별 모듈 (agents / sessions / vaults / …)
│   └── py.typed
└── tests/                   그 패키지만의 단위 테스트
```

도메인별 분할을 **모든 레이어에서 같은 이름으로** 유지합니다. 그래서 "에이전트 기능을
고치려면" 어디를 보는지 즉시 알 수 있습니다.

```
ma_domain/agents.py  →  ma_store/agents.py  →  ma_store_sql/agents.py
                     →  ma_application/agents.py  →  ma_api/internal/agents.py
                     →  ma_platform/modules/agents.py
```

---

## 4. 앱 내부 모양 — config → components → assembly → serve

레퍼런스의 `main-node` 패턴을 그대로 가져왔습니다. 이것이 "배포 프리셋이 라이브러리
사용자가 된다"를 가능하게 합니다.

```
apps/control_plane/src/control_plane/
├── config.py          os.environ → 타입된 Config 1회. **환경변수를 읽는 유일한 파일**
│                      모든 문제를 하나의 ConfigError로 모아 보고
├── components.py      어떤 구현을 쓸지 선택. 기본값은 각각 export된 생성자
│                      default_components(cfg) / 호출자가 일부 교체 가능
├── assembly.py        생명주기(시작·종료 역순 정리), 라우터 마운트
├── http.py            FastAPI 앱 구성, 미들웨어 순서
├── serve.py           uvicorn 기동, 시그널 처리, graceful shutdown
└── __main__.py        config → components → assembly → serve
```

```python
# apps/control_plane/src/control_plane/__main__.py
async def main() -> None:
    cfg = load_config(os.environ)  # 여기만 환경변수를 안다
    components = await default_components(cfg)
    app = await build_control_plane(components)
    await serve(app, host=cfg.host, port=cfg.port)
```

```python
# 테스트·다른 배포 프리셋은 os.environ을 건드리지 않는다
components = await default_components(
    cfg,
    overrides=ComponentOverrides(
        stores=StoreOverrides(agents=MemoryAgentStore()),
        sandbox=WasmSandboxFactory(fuel=10_000_000),
        realtime=InProcessRealtime(),
    ),
)
```

### 미들웨어 순서 (control_plane/http.py)

순서가 의미를 가집니다.

```
1. request_metrics          관측이 가장 밖 — 실패한 요청도 세야 한다
2. error_envelope           모든 4xx/5xx를 공통 envelope으로 ([04](04-api.md) §2.3)
3. request_id               트레이스 상관관계
4. /healthz /readyz         인증 없음. 여기서 분기
5. auth                     principal + workspace_id 확정 ([04](04-api.md) §2.1)
6. rate_limit               인증 후 — 워크스페이스 키로 버킷
7. workspace_app            WorkspaceAppRegistry에서 앱 그래프 획득
8. 라우터                    internal lane / compat lane
```

---

## 5. 두 lane의 물리적 분리 (D9)

```
packages/ma_api/src/ma_api/
├── internal/
│   ├── __init__.py          mount_internal(app, source)
│   ├── schemas/             pydantic. 사내 개념 포함
│   ├── mappers/             wire ↔ application
│   └── routes/              agents.py sessions.py approvals.py budgets.py audit.py …
├── compat/                  ← 2단계. internal을 import하지 않는다
│   ├── __init__.py          mount_compat(app, source)
│   ├── beta.py              리소스별 beta 헤더 게이트
│   ├── schemas/             공식 wire shape만. 필드 추가 금지
│   ├── mappers/
│   └── routes/
└── shared/                  에러 envelope · 커서 인코딩 · 페이지네이션 (양쪽이 쓴다)
```

`.importlinter`의 `independence` 계약이 `internal`↔`compat` 상호 import를 금지합니다.
공유가 필요한 것은 `shared/`에 두고, 거기에는 **비즈니스 규칙을 넣지 않습니다.**

---

## 6. 테스트 전략 — 레이어마다 다르다

| 종류 | 대상 | 속도 | 실행 시점 |
|---|---|---|---|
| **단위** | `ma_domain` 불변식, 매퍼, 커서 인코딩, 정책 해석 | ms | 매 커밋 |
| **Store 계약** | 모든 `ma_store` Protocol × (memory, sql) | 초 | 매 커밋 (sql은 testcontainers) |
| **ModelPort 계약** | 어댑터 × 녹음된 SSE 픽스처 | ms | 매 커밋 |
| **SandboxPort 계약** | `ma_sandbox_wasm`, `ma_sandbox_bwrap`, `local` | 초 | 매 커밋 (가능한 백엔드만) |
| **아키텍처** | import-linter + `check_architecture.py` | 초 | 매 커밋 |
| **통합** | 제어 평면 + 워커 + postgres + minio | 분 | PR |
| **E2E** | 세션 생성 → 툴 → 승인 → 완료 (가짜 모델) | 분 | PR |
| **보안** | 경로 탈출 퍼징 · 자격증명 유출 스캔 · egress 우회 | 분 | PR + 야간 |
| **모델 실측** | 실제 DeepSeek 호출 | 분 + **비용** | 수동 / 야간. 별 마커 |

### Store 계약 테스트가 핵심

같은 스위트를 두 구현에 돌립니다. 이것이 런타임 이식성을 **주장이 아니라 사실**로 만듭니다.

```python
# tests/contract/test_execution_store.py
@pytest.fixture(params=["memory", "sql"])
async def store(request, pg) -> ExecutionStore: ...


async def test_two_workers_cannot_claim_same_lane(store: ExecutionStore):
    await store.admit(...)
    a = await store.claim(owner="worker-a", ttl_s=90)
    b = await store.claim(owner="worker-b", ttl_s=90)
    assert a is not None
    assert b is None  # SKIP LOCKED + 부분 유니크 인덱스


async def test_expired_lease_is_reclaimable(store, clock):
    a = await store.claim(owner="worker-a", ttl_s=1)
    clock.advance(2)
    b = await store.claim(owner="worker-b", ttl_s=90)
    assert b is not None
    assert b.generation == a.generation + 1  # fence가 올라간다
```

### 보안 테스트는 성공 기준과 1:1

[01](01-product-concept.md) §7의 성공 기준이 그대로 테스트가 됩니다.

```python
# tests/security/test_credential_isolation.py
async def test_no_plaintext_credential_anywhere_in_sandbox(session_with_vault):
    """성공 기준: 샌드박스 전수 조사에서 평문 자격증명 0건."""
    secret = session_with_vault.known_secret_value
    for probe in (dump_env, dump_filesystem, dump_process_memory):
        assert secret not in await probe(session_with_vault.sandbox)


# tests/security/test_path_escape.py
@pytest.mark.parametrize("candidate", PATH_ESCAPE_CORPUS)  # ../  절대경로  유니코드  널바이트
def test_resolve_in_workspace_rejects(candidate, tmp_path):
    with pytest.raises(PathEscape):
        resolve_in_workspace(tmp_path, candidate)
```

### 가짜 모델

E2E가 매번 실제 모델을 부르면 비용과 비결정성이 생깁니다. `FakeModelAdapter`가
**스크립트된 스트림**을 재생합니다.

```python
FakeModelAdapter(
    script=[
        TextDelta("파일을 확인합니다"),
        ToolCall("read", {"path": "report.md"}),
        Finish("tool_use"),
    ]
)
```

실제 모델은 `tests/model_live/`에 분리하고 `-m live` 마커로만 실행합니다.

---

## 7. 개발 루프

```sh
make dev        # compose up (postgres+minio) → migrate → seed → 4개 앱 + vite 동시 실행
make test       # arch → unit → contract → integration (순서가 의미 있다)
make test-fast  # arch → unit → contract(memory만). 수 초
make lint       # ruff + mypy --strict + import-linter
make migrate m="add approvals"   # alembic revision --autogenerate
make probe      # 현재 노드의 샌드박스/egress 능력 보고
```

`make test`의 순서가 중요합니다. **아키텍처 검사가 가장 먼저** 돌아서, 레이어를 깬 PR이
느린 통합 테스트를 기다리지 않고 바로 실패합니다.

### 로컬에서의 샌드박스

| 환경 | 티어 W | 티어 P |
|---|---|---|
| macOS 개발 | ✅ Wasmtime은 그대로 동작 | ✗ bwrap 없음 → `ma_sandbox_local`(격리 없음, 테스트 전용) |
| Linux 개발 | ✅ | ✅ (비특권 userns 가능하면) |
| CI | ✅ | 조건부. `probe_capabilities.py` 결과에 따라 스킵 |
| 프로덕션 | ✅ | [08](08-infrastructure.md) §4의 조건 충족 시 |

`ma_sandbox_local`은 **프로덕션 기동 시 거부**합니다 (`AWP_ENV=production`이면 예외).
레퍼런스도 같은 가드를 둡니다 — "subprocess is test-only".

---

## 8. 버전과 릴리스

| 대상 | 방식 |
|---|---|
| 내부 패키지 | 버전을 올리지 않는다. 워크스페이스 참조 (`workspace = true`) |
| 앱 이미지 | 단일 버전 (`v1.4.0`). 전부 함께 올린다 |
| `aw` CLI | 별도 배포 가능 (사내 PyPI 또는 단일 바이너리) |
| 마이그레이션 | 앱 버전과 독립. 앞으로만 간다 ([05](05-database.md) §8) |
| web/console | 앱 이미지에 번들 (control-plane이 정적 서빙) |

**단일 버전 전략**을 쓰는 이유: 제어 평면과 워커는 같은 DB 스키마와 같은 이벤트 어휘를
공유합니다. 버전을 따로 가면 호환 매트릭스가 생기고, 그것은 사내 플랫폼 규모에서 낭비입니다.
배포는 `migrate Job → control-plane → runtime-worker` 순서입니다.

---

## 9. 레퍼런스(OpenMA, TypeScript) 대응표

레이어 경계는 가져왔지만 패키지 수는 크게 줄였습니다. 레퍼런스는 173패키지, 우리는 25개입니다.

| OpenMA (TS) | AWP (Python) | 비고 |
|---|---|---|
| `managed-agents-domain` | `ma_domain` | 1:1 |
| `agent-store` + `environment-store` + `session-store` + … (18개 인터페이스 패키지) | `ma_store` **하나** (도메인별 모듈) | 패키지 대신 모듈로 분할. `independence` 계약으로 교차 import를 막으니 물리 분리가 불필요 |
| `*-store-memory` × 18 | `ma_store_memory` 하나 | 같은 이유 |
| `*-store-sql` × 18 | `ma_store_sql` 하나 | 같은 이유 |
| `sql-client` + 어댑터 5종 | `ma_sql` | PostgreSQL 하나만 지원하므로 더 작다 |
| `managed-agents-application` | `ma_application` | 1:1 |
| `managed-agents-api` | `ma_api.compat` | 공식 lane |
| `http-routes` (v0 레거시) | `ma_api.internal` | 우리는 세대 분기가 없다 (D1) |
| `managed-agents-app` (createApp) | `ma_platform` | PortToken·AppModule을 Python으로 |
| `platform` + `platform-sql` + `platform-cloudflare` + `platform-node` | `ma_platform` | 호스팅 타깃이 k8s 하나라 분기가 없다 |
| `session-runtime` + `session-runtime-contract` + `session-runtime-sql` + `execution-control` | `ma_harness` + `ma_store.executions` | v0/v1 분기가 없어 셋이 하나로 합쳐진다 |
| `sandbox` + `sandbox-adapter-*` × 4 + `managed-runtime-*` × 12 | `ma_sandbox` + `ma_sandbox_wasm` + `ma_sandbox_bwrap` + `ma_sandbox_local` | **provider 12개 대신 2개.** 커널을 건드리지 않는 선택지만 (D13) |
| `memory-store` + `memory-store-store` + `memory-document-store` + 각 `-memory`/`-sql` | `ma_store.memory` + `ma_application.memory` | 레퍼런스의 이중 세대가 없다 |
| `vault-store` + `credential-store` + `vault-forward` | `ma_store.vaults` + `ma_egress` | |
| `services` (v0 서비스 로케이터) | **없음** | 금지 (R3) |
| `compat-v0` + `migrate-v0` | **없음** | 세대 분기가 없으므로 불필요 (D1) |
| `apps/main` + `main-node` + `main-fly` + `main-vercel` | `apps/control_plane` | 타깃 하나 |
| `apps/agent` (SessionDO 6,700줄) | `apps/runtime_worker` + `ma_harness` | 권한이 DB에 있으므로 거대 객체가 생기지 않는다 (D3) |
| `apps/oma-vault` | `apps/egress_proxy` | 같은 역할 |
| `apps/console` | `web/console` | |
| `eval-core` + `evals-runner` + `rl/` | **없음** | 비범위 ([01](01-product-concept.md) §5) |

### 패키지를 173개에서 25개로 줄일 수 있는 이유

| 레퍼런스의 패키지 증식 원인 | AWP에서 사라지는 이유 |
|---|---|
| v0/v1 이중 세대 | D1 — 세대 분기를 만들지 않는다 |
| Store마다 인터페이스/memory/sql 3패키지 | Python `Protocol` + `independence` 계약으로 **모듈** 분할이면 충분 |
| 호스팅 타깃 4종 (CF/Node/Fly/Vercel) | k8s 하나 |
| 샌드박스 provider 12종 | 2종 (D13) |
| npm 독립 배포 요구 | 사내 모노레포. 외부 배포 대상은 `aw` CLI 하나 |

> **다만 레퍼런스의 선택이 틀린 것은 아닙니다.** 그들은 공개 npm 배포, 4개 호스팅 타깃,
> 12개 샌드박스 provider를 **실제로 지원해야** 했습니다. 우리 범위에서는 같은 경계를
> 모듈로 그려도 CI가 똑같이 강제할 수 있고, 그 쪽이 읽기 쉽습니다. 범위가 넓어지면
> 모듈을 패키지로 승격하면 됩니다 — 경계가 이미 CI로 지켜지고 있으므로 비용이 작습니다.

---

## 10. 다음 문서

지금까지의 모든 조각이 어떻게 맞물리는가 → [10. 관계 · 트레이서빌리티](10-relationships.md)
