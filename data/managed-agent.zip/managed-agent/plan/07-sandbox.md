# 07. 샌드박스 — Wasm 중심 2티어

> 다이어그램: [`svg/15-sandbox-tiers.svg`](svg/15-sandbox-tiers.svg) ·
> [`svg/16-sandbox-lifecycle.svg`](svg/16-sandbox-lifecycle.svg) ·
> [`svg/18-network-egress.svg`](svg/18-network-egress.svg)

요구사항: **커널을 건드리지 않는 라이트한 격리.** Wasm 검토 포함.

---

## 1. 결론 먼저

| 티어 | 격리 | `bash` | 기동 | 메모리 | 강제 수준 | 쓰는 곳 |
|---|---|---|---|---|---|---|
| **W (wasm)** | Wasmtime + WASI p1. **ambient authority 0** | ✗ | **수~수십 ms** | 수~수십 MB | **`enforced`** (구성상) | **기본.** 데이터·분석·문서·조회 에이전트 |
| **P (process)** | bubblewrap argv 래핑. 비특권 user namespace | ✓ | 수십~수백 ms | 수십~수백 MB | `enforced` / `partial` / `unsupported` (**프로브 결과**) | 셸이 필요한 개발·운영 에이전트 |
| (V) vm | gVisor / Kata | ✓ | 초 | 수백 MB+ | `enforced` | **1단계 비범위.** Port로 막지 않음 |

**둘 다 커널 모듈을 설치하지 않습니다.** Wasm은 전부 유저스페이스이고, bubblewrap은 비특권
user namespace를, Landlock은 이미 커널에 있는 LSM을 씁니다.

---

## 2. 왜 Wasm을 기본으로 둘 수 있는가 — 핵심 발견

공식 CMA 내장 툴셋은 8개입니다. 각각이 **실제로 무엇을 필요로 하는지** 따져 보면:

| 툴 | 필요한 것 | 샌드박스 셸이 필요? |
|---|---|---|
| `read` | 워크스페이스 디렉터리 읽기 | ✗ — 호스트 함수로 충분 |
| `write` | 워크스페이스 디렉터리 쓰기 | ✗ — 호스트 함수 |
| `edit` | read + 문자열 치환 + write | ✗ — 호스트 함수 |
| `glob` | 디렉터리 순회 + 패턴 매칭 + mtime 정렬 | ✗ — 호스트 함수 |
| `grep` | 정규식 파일 검색 | ✗ — **호스트에서** ripgrep 실행 |
| `web_fetch` | HTTP + 마크다운 변환 | ✗ — 원래 신뢰 영역에서 실행 |
| `web_search` | 검색 provider 호출 | ✗ — 원래 신뢰 영역에서 실행 |
| `bash` | POSIX 프로세스 세계 (fork/exec, PATH, 파이프) | **✓** |

> 레퍼런스 구현도, 공식 CMA도 `web_fetch`/`web_search`는 샌드박스 밖에서 실행합니다.
> 공식 문서가 명시합니다 — "Managed Agents web tools ignore the environment's `networking`.
> `web_search`/`web_fetch` run on Anthropic's servers." 레퍼런스의 `glob`/`grep`은 번들된
> ripgrep을 `ctx.subprocess`로 돌리는데, 그 subprocess가 **샌드박스 안일 필요가 없습니다.**

**8개 중 7개가 샌드박스 셸 없이 동작합니다.** 프로세스 세계가 필요한 것은 `bash` 하나입니다.

그러면 질문이 바뀝니다. "Wasm으로 bash를 어떻게 돌리지?"가 아니라
**"이 에이전트가 정말 bash가 필요한가?"** 입니다. 사내 에이전트 다수 — 계약서 검토, 리포트
작성, 데이터 추출, 사내 위키 조회 — 는 필요 없습니다.

그래서 기본 티어를 Wasm으로 두고, **셸은 옵트인**으로 만듭니다.

---

## 3. 티어 W — Wasm (WASI preview 1)

> **정정 (2026-10-15, T-0303 구현)** — 이 절은 원래 WASI preview 2를 전제했습니다.
> `wasmtime-py` 49에는 Component Model / p2 API가 **없습니다**(`WasiConfig` 하나뿐이고
> 그것이 p1입니다). **preview 1로 갑니다.** 잃는 것은 `wasi:http` 하나인데, 그것은
> 애초에 §3.3에서 쓰지 않기로 한 것입니다 — HTTP는 호스트 쪽에서 일어나고 T-0402의
> egress 프록시가 맡습니다. 소켓에 대한 주장은 아래 §3.1에서 정확하게 고쳐 적었습니다.
> 측정과 근거는 [`docs/impl/0016-wasm-tier.md`](../docs/impl/0016-wasm-tier.md).

### 3.1 왜 Wasm이 격리 수단으로 강한가

Wasm 런타임의 기본 상태는 **아무 권한도 없음**입니다. 모듈은 파일시스템을 건드릴 수 없고,
소켓을 열 수 없고, 환경변수를 읽을 수 없습니다. **명시적으로 제공된 import를 통해서만**
외부와 통신합니다. 이것이 능력 기반(capability-based) 보안이고, "일단 다 주고 나서 막는"
방식과 근본적으로 다릅니다.

WASI preview 1에서 우리가 주는 것과 주지 않는 것:

| 줄 수 있는 것 | 모양 | 우리 |
|---|---|---|
| 특정 디렉터리만 | `preopen_dir` | `/workspace`(rw) · `/mnt/memory/<name>` · `/scratch` · `/usr/local/lib` |
| 환경변수 | `WasiConfig.env` | **화이트리스트만**. `inherit_env`를 쓰지 않는다 |
| 표준 입출력 | `stdin/stdout/stderr_file` | 임시 파일로 고정 (상한까지만 읽는다) |
| 시계·난수 | `clock_time_get` · `random_get` | 준다 |
| 소켓 **생성·연결** | `sock_open`·`sock_connect`·`sock_bind`·`sock_listen` | **Linker에 정의되지 않는다** |
| 소켓 fd **조작** | `sock_accept`·`sock_send`·`sock_recv`·`sock_shutdown` | 정의되지만 **쓸 fd가 없다** |

**소켓에 대한 정확한 주장**은 "함수가 존재하지 않는다"가 아니라
**"게스트가 소켓 descriptor를 얻을 길이 없다"** 입니다. 근거 둘: 만드는 함수 넷이
Linker에 없고, 우리는 디렉터리만 preopen합니다. 후자는 코드를 읽어 믿는 대신
실행으로 확인합니다 — `sock_accept`를 fd 0~31에 전부 걸어 전부 `ENOTSOCK`/`EBADF`가
나오는 것을 테스트가 봅니다.

### 3.2 런타임 선택: Wasmtime

| 런타임 | 파이썬 임베딩 | WASI p1 | 선택 |
|---|---|---|---|
| **Wasmtime** (Bytecode Alliance) | `wasmtime-py` — 1급 | 완전 | **✅** |
| WasmEdge (CNCF Sandbox) | 바인딩 있음 | 완전 | ✗ |
| Wasmer | `wasmer-python` 유지보수 느슨 | WASIX가 별도 축 | §3.5 참조 |

p2를 기준으로 고를 이유가 없어졌으므로(위 정정), 선택 근거는 **파이썬 임베딩의
성숙도**입니다. `wasmtime-py`가 유일하게 1급으로 유지됩니다.

Python 호스트에서는 `wasmtime-py`로 임베드합니다. 별도 프로세스도, 별도 컨테이너도,
k8s API 호출도 필요 없습니다 — **runtime-worker 프로세스 안에서 인스턴스를 만듭니다.**

### 3.3 티어 W의 실제 구성

```
runtime-worker Pod (Python)
├── 하네스 루프
├── 호스트 툴 구현 ──────────── read / write / edit / glob / grep
│     └── 워크스페이스 경계 검사 (경로 정규화 후 prefix 확인)
├── Wasmtime Engine (프로세스당 1개) ─ 컴파일된 코드. 상태 없음
│     └── Wasmtime Store (호출당 1개) ─ run_code 전용
│           ├── preopen: /workspace          (rw)
│           ├── preopen: /mnt/memory/<name>  (rw 또는 ro)
│           ├── preopen: /scratch            (이번 호출의 스크립트)
│           ├── preopen: /usr/local/lib      (CPython stdlib)
│           ├── env: 화이트리스트된 것만 (자격증명 없음)
│           ├── 소켓 생성·연결    : 미제공  ← 네트워크 불가
│           ├── HTTP             : 미제공. 호스트 쪽 web_fetch 가 맡는다
│           ├── fuel / epoch 인터럽션: CPU 상한
│           └── memory limit        : 선형 메모리 상한
└── egress 프록시로 나가는 web_fetch / web_search / 모델 호출
```

### 3.4 티어 W에서 코드 실행 (`run_code`)

`bash`를 못 주더라도 "코드를 돌려 데이터를 처리"는 필요합니다. 그래서 `run_code` 툴을
Wasm 안의 **CPython WASI 빌드**로 제공합니다.

```python
# packages/ma_sandbox_wasm/src/ma_sandbox_wasm/runner.py
class WasmRunner:
    """세션당 Wasmtime Store. 호출마다 새 인스턴스(상태 누적 없음)."""
    async def run_python(self, code: str, *, timeout_s: float) -> ExecResult:
        # cpython.wasm + stdlib zip을 preopen으로 마운트
        # fuel 소진 또는 epoch deadline → Timeout
        # stdout/stderr 캡처, 100K자 초과 시 spill
```

| 할 수 있는 것 | 할 수 없는 것 |
|---|---|
| 순수 Python 표준 라이브러리 | 네이티브 확장 휠(numpy/pandas) — **wasm 빌드가 필요** |
| 파일 읽기/쓰기 (preopen 범위) | `subprocess`, `os.fork` |
| 텍스트·JSON·CSV 처리 | 임의 소켓 |
| 정규식, 수학, 날짜 | `pip install` |

> 네이티브 휠이 필요한 분석 작업이 많다면 그 환경은 **티어 P**로 선언하는 것이 정직합니다.
> "Wasm에서 pandas를 쓰게 만들기"는 가능하지만(Pyodide 계열) 유지보수 비용이 큽니다.
> 1단계에서는 선택지를 열어 두고 측정 후 결정합니다.

### 3.5 검토했지만 1단계에 쓰지 않는 Wasm 선택지

| 선택지 | 무엇인가 | 왜 안 쓰는가 |
|---|---|---|
| **WASIX** (Wasmer) | WASI를 확장해 스레드·`fork`·소켓 등 POSIX에 가깝게 | 표준이 아니라 벤더 확장이다. 능력 기반 모델이 느슨해지는 방향이고, "ambient authority 0"이라는 티어 W의 유일한 강점을 깎는다 |
| **container2wasm** | OCI 컨테이너를 Wasm 안의 CPU 에뮬레이터로 구동 | Linux 전체를 에뮬레이션하므로 **느리다**. 그 비용을 낼 거면 티어 P가 더 빠르고 더 정직하다 |
| **Pyodide** (Emscripten) | 브라우저용 CPython + 과학 스택 wasm 빌드 | 서버 사이드 WASI가 아니라 Emscripten 타깃이다. 능력 모델이 우리 preopen 설계와 맞지 않는다. 다만 §3.4의 네이티브 휠 문제를 풀어야 할 때 재검토 대상 |
| **Spin / wasmCloud** | Wasm 서버리스 플랫폼 | 우리는 애플리케이션 호스팅이 아니라 **툴 실행 샌드박스**가 필요하다. 플랫폼 하나를 더 운영할 이유가 없다 |

### 3.6 티어 W의 한계 — 정직하게

| 한계 | 영향 |
|---|---|
| `bash` 없음 | 셸이 필요한 에이전트는 티어 P |
| 네이티브 패키지 설치 없음 | `environment.packages`가 무의미. 환경 정의 시 거부 |
| `git` 없음 | 저장소 작업은 호스트 측 리소스 마운트로(§5) 또는 티어 P |
| 긴 실행 프로세스 없음 | 백그라운드 잡·PTY 불가 |
| Wasm 런타임 자체의 CVE | 공격 표면이 작지만 0은 아니다. Wasmtime을 즉시 패치 가능하게 버전 핀 + 갱신 자동화 |

---

## 4. 티어 P — bubblewrap + Landlock

셸이 필요할 때. **DeepSeek Harness의 sandbox seam을 그대로 모델로 삼습니다** — 플랫폼
러너에 소비자를 결합시키지 않고, **argv를 감쌉니다.**

### 4.1 argv 래핑

```python
# packages/ma_sandbox/src/ma_sandbox/ports.py
type SandboxMode = Literal["read-only", "workspace-write", "danger-full-access"]
type Enforcement = Literal["enforced", "partial", "unsupported"]


@dataclass(frozen=True, slots=True)
class SandboxPolicy:
    """한 번의 실행에 대한 완전한 파일 효과 정책. provider에 고정하지 않고 호출마다 싣는다."""

    mode: Literal["read-only", "workspace-write"]  # danger-full-access는 confine을 부르지 않는다
    workspace_root: Path
    session_id: SessionId | None


@dataclass(frozen=True, slots=True)
class ConfinedArgv:
    argv: list[str]  # 러너 + 프로필 + 구분자 + 원래 argv
    enforcement: Enforcement
    denial_signatures: tuple[str, ...]  # 이 백엔드가 거부할 때 내는 stderr 방언
    runner_failure_rules: tuple[RunnerFailureRule, ...]


class SandboxProvider(Protocol):
    def confine(self, argv: Sequence[str], policy: SandboxPolicy) -> ConfinedArgv: ...
```

`danger-full-access`는 **provider에 보내지 않습니다.** 소비자가 원래 argv를 그대로 실행하고
`ctx.sandbox`를 호출하지 않습니다. 그래야 "감금 안 함"이 코드에서 명시적으로 보입니다.

### 4.2 거부 vs 러너 고장을 구분한다

이것이 없으면 **인프라 장애가 "작업 실패"로 모델에 보고되고**, 모델은 엉뚱한 재시도를 합니다.

| 종류 | 판정 | 처리 |
|---|---|---|
| **거부(denial)** | stderr가 백엔드 방언과 일치 (bwrap 읽기전용 바인드 → `EROFS` 텍스트, Landlock → `EACCES`) | 정상. 툴 결과로 "권한 없음"을 모델에 전달 |
| **러너 고장** | 비정상 종료 + `fatal_signatures` 일치, `informational_lines` 제외 후 | **인프라 오류.** `session.error`, 모델에 작업 실패로 보고하지 않음 |

종료 코드만으로는 러너 고장을 증명하지 않습니다. 양성 안내 라인을 먼저 제거한 뒤 치명
시그니처를 봅니다. 방언은 **백엔드별**로 매칭합니다 — 전 백엔드 합집합을 쓰면 해당 백엔드가
내지 않는 거부를 주장하게 됩니다.

### 4.3 Landlock으로 얻는 것

> **정정 (2026-10-15, T-0304 구현)** — 이 절은 enforcement가 "Landlock ABI에 따라"
> 달라진다고 읽히게 쓰여 있었습니다. 구현해 보니 그렇지 않습니다.
>
> - **bwrap은 Landlock을 걸지 않습니다.** mount namespace + capability drop으로
>   막습니다. Landlock은 별개의 LSM이고, 걸려면 **게스트 프로세스 자신이**
>   `landlock_restrict_self`를 호출해야 합니다. 우리는 argv를 감쌀 뿐 게스트 안에서
>   코드를 실행하지 않으므로 그것을 걸 자리가 없습니다.
> - **네트워크도 ABI 4가 아니라 `--unshare-net`이 막습니다.** 그쪽이 더 강합니다 —
>   포트 단위 제한이 아니라 netns 자체가 없습니다.
>
> 그래서 `enforcement`는 **프로브 결과**로 정해집니다 (`provider.py::run_probe` —
> 실제로 bwrap을 띄워 밖에 쓰기·밖에 읽기·환경 상속·네트워크 넷을 시험합니다).
> Landlock ABI는 측정해서 `notes`에 싣습니다 — 2차 방어선을 붙일 때 어디까지
> 되는지가 거기 있습니다. 자세한 것은
> [`docs/impl/0017-tier-p-flags-and-dialect.md`](../docs/impl/0017-tier-p-flags-and-dialect.md).


| Landlock ABI | 커널 | 얻는 것 |
|---|---|---|
| 1 | 5.13+ | 파일시스템 접근 제한 |
| 2–3 | 5.19 / 6.2 | 파일 재명명, truncate |
| 4 | **6.7+** | **TCP bind/connect 제한 (포트 단위)** |

Landlock의 결정적 장점은 **비특권**이라는 것입니다. 어떤 프로세스든 **자기 자신을** 안전하게
제한할 수 있습니다. BPF LSM과 달리 로드에 권한이 필요 없습니다.

> **정확히 말하면**: Landlock의 네트워크 규칙은 **포트 기반**이고 주소 기반이 아닙니다.
> "egress 프록시로만" 을 Landlock만으로 보장할 수 없습니다. §6의 다층 방어가 필요합니다.

### 4.4 티어 P의 위협 모델 — 무엇을 막고 무엇을 못 막는가

| 공격 | 막는가 |
|---|---|
| 프롬프트 인젝션된 에이전트가 `/etc/shadow`를 읽어 유출 | **막는다** (파일 효과 제한) |
| 워크스페이스 밖에 파일 쓰기 | **막는다** |
| 다른 세션의 워크스페이스 접근 | **막는다** (mount 네임스페이스 분리) |
| 환경변수에서 토큰 탈취 | **애초에 토큰이 없다** (§6) |
| 임의 호스트로 데이터 유출 | **막는다** — 단 §6의 네트워크 계층이 함께 있어야 한다 |
| **커널 취약점으로 호스트 탈출** | **못 막는다.** 호스트 커널을 공유한다 |
| 리소스 고갈로 다른 세션 방해 | 부분적 — cgroup 한도로 완화 |

> 커널 취약점이 위협 모델에 들어가면(진짜 악의적 멀티테넌트) gVisor 같은 유저스페이스
> 커널이 정답입니다. **사내 플랫폼의 주된 위협은 "프롬프트 인젝션된 에이전트의 데이터
> 유출"이고, 그 위협에는 티어 P로 충분합니다.** Anthropic도 같은 구분을 합니다 —
> Claude Code(단일 사용자 CLI)는 bubblewrap, Claude 웹(멀티테넌트)은 gVisor를 씁니다.
>
> 이 판단은 **환경별로 다시 할 수 있어야** 합니다. 그래서 티어 V를 Port에서 막지 않습니다.

---

## 5. 환경 → 티어 결정

```python
# environments.config
{
    "type": "cloud",
    "tier": "wasm",  # wasm | process   (기본 wasm)
    "packages": {...},  # tier=process에서만 유효
    "networking": {
        "type": "limited",
        "allowed_hosts": ["wiki.corp.example", "api.github.com"],
        "allow_mcp_servers": true,
    },
    "egress": "required",  # required | best_effort
}
```

검증 규칙 (환경 생성 시점):

| 조합 | 결과 |
|---|---|
| `tier: wasm` + `packages` 비어있지 않음 | **400.** "wasm tier does not install packages" |
| `tier: wasm` + 에이전트가 `bash`를 켬 | **400.** 세션 생성 시점에 거부 |
| `egress: required` + 백엔드가 `enforced` 미보고 | **400.** 세션 생성 거부 ([D6](README.md#핵심-설계-결정)) |
| `tier: process` + 노드에 비특권 userns 불가 | **400.** 능력 조회 결과를 그대로 보고 |

`GET /api/v1/environments/{id}/capabilities`가 **실제 보고된 능력**을 반환합니다. 추측이
아니라 런타임이 프로브한 사실입니다.

```json
{
  "tier": "process",
  "sandbox_enforcement": "partial",
  "sandbox_enforcement_reason": "Landlock ABI 2 (kernel 5.19): network rules unavailable",
  "egress_enforcement": "enforced",
  "egress_enforcement_conditions": {
    "default_deny_egress_networkpolicy": true,
    "cni_enforces_networkpolicy": "cilium",
    "no_host_network": true,
    "service_account_token_disabled": true,
    "proxy_mitm_ca_per_session": true
  },
  "tools_available": ["bash","read","write","edit","glob","grep","web_fetch","web_search"]
}
```

---

## 6. 자격증명과 egress (D5)

### 6.1 원칙

> **샌드박스는 `(workspace_id, session_id, hostname)`만 압니다. 토큰은 모릅니다.**

흐름:

```
샌드박스에서 curl https://api.github.com/... 실행
   │  (HTTPS_PROXY = egress-proxy, CA = 세션별 발급)
   ▼
egress-proxy  [신뢰 영역]
   ① 세션 식별 (프록시 연결의 클라이언트 인증서 또는 세션 토큰)
   ② 환경의 allowed_hosts 검사 → 불일치면 403, credential_events(denied) 적립
   ③ 제어 평면에 조회: (workspace, session, host) → credential
       · 세션의 vault_ids 범위 안에 있는 것만
       · fence generation 검증 — 소유권이 넘어간 세션은 거부
   ④ 복호화 후 Authorization 헤더 주입 (프록시 메모리에만, 로그 금지)
   ⑤ 업스트림으로 포워드
   ⑥ credential_events(injected, host, generation) 적립 ← 감사
```

**프롬프트 인젝션된 에이전트가 유출할 토큰이 존재하지 않습니다.** 샌드박스의 `env`,
파일시스템, 메모리를 전수 조사해도 나오지 않습니다 — 이것이 성공 기준 중 하나입니다
([01](01-product-concept.md) §7).

### 6.2 티어별 egress 강제

| 티어 | 수단 | 강제 |
|---|---|---|
| **W** | 소켓을 **만들거나 연결하는 import가 없고**, 소켓 fd를 건네주지 않는다. HTTP는 게스트 밖(호스트 툴)에서 일어난다 | **`enforced` (구성상)** — 우회 경로가 코드에 없다 |
| **P** | 아래 5조건의 AND | 5개 전부 참일 때만 `enforced` |

티어 P의 5조건:

1. 샌드박스 네임스페이스에 **default-deny egress NetworkPolicy**, egress-proxy만 허용
2. CNI가 NetworkPolicy를 **실제로 강제** (Calico / Cilium — 강제하지 않는 CNI가 있다)
3. `hostNetwork: false`, `hostPort` 없음
4. `automountServiceAccountToken: false`
5. egress-proxy가 **세션별 CA**로 MITM하고 호스트 allowlist를 적용

하나라도 빠지면 `advisory`로 보고하고, `egress: required` 환경의 세션 생성을 **거부**합니다.

> 티어 W가 구성상 `enforced`인 것이 Wasm의 가장 큰 실용적 이점입니다. 티어 P는 5개 조건을
> 운영 내내 참으로 유지해야 하고, 그중 하나(CNI 설정)는 우리 코드 밖에 있습니다.

### 6.3 모델 호출도 프록시를 지난다

runtime-worker → DeepSeek API 호출도 egress-proxy를 지나갑니다. 이유:

- 모델 API 키가 **워커 프로세스에도 없어도 됩니다** (프록시가 주입)
- 모든 모델 호출이 `credential_events`에 남아 감사됩니다
- provider 엔드포인트 변경이 프록시 설정 하나로 끝납니다

---

## 7. 샌드박스 생애주기

```
   none
     │ 첫 툴 호출 (지연 프로비저닝)
     ▼
  provisioning ──── 티어 W: Store 생성 + preopen 구성      (~ms)
     │              티어 P: 워크스페이스 준비 + 패키지 설치 (~s)
     │              공통  : 스냅샷 복원, 메모리/스킬/리소스 마운트
     ▼
   ready ──▶ active ──▶ idle ──(5분)──▶ snapshot ──▶ gone
     ▲          │                                      │
     └──────────┘                                      │
       재사용                     다음 턴이 오면 ────────┘
                                 스냅샷에서 복원
```

| 단계 | 티어 W | 티어 P |
|---|---|---|
| 프로비저닝 | Wasmtime Store + preopen. 프로세스 생성 없음 | 워크스페이스 디렉터리 + 패키지 레이어 준비 |
| 웜업 | 없음(즉시) | 헬스 프로브, 스냅샷 복원, 패키지 설치 |
| 스냅샷 | `/workspace` tar → 오브젝트 스토어 | 동일 |
| 아이들 회수 | Store drop (메모리만) | 워크스페이스 보존 후 디렉터리 정리 |
| 복원 | preopen 재구성 | tar 복원 |

**상태는 샌드박스가 아니라 (DB + 오브젝트 스토어)에 있습니다.** 샌드박스는 cattle입니다.

`sandbox_instances` 테이블이 이 상태를 추적하고, 스케줄러가 `last_activity_at` 기준으로
회수합니다. 종료에 실패한 자원은 `runtime_orphans`에 기록되어 나중에 정리됩니다
([05](05-database.md) §3 G11).

---

## 8. 워크스페이스 경계 — 호스트 툴의 책임

티어 W에서 `read/write/edit/glob/grep`이 **호스트 프로세스에서** 실행되므로, 경계 검사가
샌드박스가 아니라 **우리 코드의 책임**이 됩니다. 이것은 티어 W의 가장 큰 리스크입니다.

```python
# packages/ma_sandbox/src/ma_sandbox/paths.py
def resolve_in_workspace(root: Path, candidate: str) -> Path:
    """워크스페이스 밖을 가리키면 예외. 모든 호스트 툴이 유일하게 이 함수를 쓴다."""
    target = (root / candidate).resolve(strict=False)  # 심볼릭 링크 해소 포함
    if not target.is_relative_to(root.resolve(strict=True)):
        raise PathEscape(candidate)
    return target
```

강제 장치:

| 장치 | 내용 |
|---|---|
| **단일 진입점** | 파일 경로를 받는 모든 호스트 툴은 `resolve_in_workspace`만 쓴다 |
| **CI 검사** | `ma_harness.tools` 안에서 `open(`·`Path(` 직접 사용 발견 시 실패 |
| **심볼릭 링크** | `resolve()`로 해소 후 검사. 워크스페이스 안의 심링크가 밖을 가리켜도 막힌다 |
| **퍼징 테스트** | `../`, 절대경로, 유니코드 정규화, 널바이트, 긴 경로를 상시 테스트 |
| **쓰기 전 읽기 정책** | `write`/`edit`는 해당 경로를 먼저 `read`한 적이 있어야 한다(선택) |

> 티어 P에서는 bwrap/Landlock이 **두 번째 방어선**이 되어 줍니다. 티어 W에서는 이 함수가
> 유일한 방어선입니다. 그래서 테스트 밀도를 다르게 가져갑니다.

---

## 9. 티어 선택 가이드

| 에이전트 성격 | 티어 | 이유 |
|---|---|---|
| 사내 문서·위키 조회, 요약 | W | 파일 툴 + web만 쓴다 |
| 계약서·보고서 검토, 작성 | W | 파일 처리와 텍스트 분석 |
| 데이터 추출·변환 (CSV/JSON) | W | `run_code`로 충분 |
| 리포트 생성 (차트·문서 파일) | P | 네이티브 라이브러리가 필요 |
| 코드 리뷰·수정, 테스트 실행 | P | `bash`, `git`, 빌드 툴 |
| 인프라 운영 (kubectl, terraform) | P + 엄격한 승인 정책 | 셸 필수. 모든 변경 툴에 `always_ask` |
| 외부/비신뢰 입력을 많이 다룸 | W 우선, 불가하면 P + 티어 V 검토 | 공격 표면 최소화 |

**기본값은 W입니다.** 환경을 만들 때 `tier`를 생략하면 `wasm`이고, 셸이 필요하다는 것이
드러날 때 명시적으로 `process`로 올립니다. 반대 방향(기본 P, 필요시 W)은 아무도 내리지
않습니다.

---

## 10. 1단계에서 측정할 것

설계의 가정 중 측정으로 확인해야 하는 것들입니다.

| 가정 | 측정 방법 | 틀렸을 때 |
|---|---|---|
| 사내 에이전트 대부분은 `bash`가 필요 없다 | 파일럿 10개 에이전트의 툴 사용 분포 | 기본 티어를 P로 바꾸거나 `run_code` 능력을 확대 |
| 티어 W 기동이 ms 단위다 | `sandbox_provision_duration` 히스토그램 | 웜 풀 도입 |
| `run_code`(CPython WASI)로 데이터 작업이 가능하다 | 실제 과제 20건 통과율 | Pyodide 재검토 또는 해당 환경만 P |
| 호스트 툴 경계 검사에 구멍이 없다 | 퍼징 + 레드팀 | 티어 W를 보류하고 P로 통일 |
| 티어 P의 5조건이 운영 내내 유지된다 | `capabilities` 상시 프로브 + 알람 | `required` 환경을 자동 차단(이미 설계됨) |

---

## 11. 다음 문서

이 티어들이 k8s에서 실제로 어떻게 배치되는가 → [08. 인프라 · 인스턴스](08-infrastructure.md)
