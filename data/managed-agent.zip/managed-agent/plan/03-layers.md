# 03. 레이어 구조

> 다이어그램: [`svg/08-layers.svg`](svg/08-layers.svg) · [`svg/09-port-module.svg`](svg/09-port-module.svg)

---

## 1. 왜 레이어를 가르는가

목적은 세 가지입니다. 추상화를 좋아해서가 아닙니다.

1. **런타임 이식성** — 같은 `AgentStore`를 PostgreSQL·SQLite·메모리에서 쓴다. 테스트는
   메모리로 밀리초 단위로, 프로덕션은 PostgreSQL로.
2. **비밀 경계** — 암복호화와 자격증명은 특정 레이어 아래로 내려가지 않는다. 경계가 없으면
   "어디서 토큰을 읽는가"를 전수 조사해야 한다.
3. **변경 반경 제한** — 새 리소스를 추가할 때 건드려야 하는 파일이 예측 가능해야 한다
   ([10](10-relationships.md) §3의 체크리스트).

---

## 2. 7계층

의존은 **아래로만** 흐릅니다. 위 레이어를 import하면 CI가 실패합니다.

```
 ┌─────────────────────────────────────────────────────────────────────────────┐
 │ L7  apps          조립과 호스팅 (composition root)                           │
 │     control_plane · runtime_worker · scheduler · egress_proxy · cli          │
 │     여기서만: 환경변수 읽기, 프로세스 기동, 시그널 처리, 구현체 선택           │
 └────────────────────────────────┬────────────────────────────────────────────┘
                                  ▼
 ┌─────────────────────────────────────────────────────────────────────────────┐
 │ L6  ma_platform   워크스페이스별 앱 그래프 조립 SDK                           │
 │     WorkspaceAppRegistry: workspace_id → App 1개 (테넌트 누수 방지)          │
 │     build_sql_platform(engine) / build_memory_platform()                     │
 └──────────────┬──────────────────────────────────────────┬───────────────────┘
                ▼                                          ▼
 ┌──────────────────────────────┐   ┌──────────────────────────────────────────┐
 │ L5a ma_api                   │   │ L5b ma_adapters_*                        │
 │  FastAPI 라우터              │   │  sql · http · blob · runtime · k8s        │
 │  pydantic wire 스키마        │   │  외부 자원을 application Port 모양으로    │
 │  내부 lane / 공식 lane 분리  │   │  맞추는 코드                              │
 └──────────────┬───────────────┘   └──────────────┬───────────────────────────┘
                └───────────────┬──────────────────┘
                                ▼
 ┌─────────────────────────────────────────────────────────────────────────────┐
 │ L4  ma_application   유스케이스                                              │
 │     검증 · 권한 · 페이지네이션 · 낙관적 동시성 · 교차 도메인 narrow Port       │
 │     결과는 discriminated union. 예외로 비즈니스 결과를 표현하지 않는다        │
 └────────────────────────────────┬────────────────────────────────────────────┘
                                  ▼
 ┌─────────────────────────────────────────────────────────────────────────────┐
 │ L3  ma_store      도메인별 Store 인터페이스 (Protocol)                        │
 │     AgentStore · SessionStore · SessionEventStore · ExecutionStore · …       │
 │     모든 메서드 입력에 workspace_id. 결과는 union                             │
 └──────────────┬──────────────────────────────────────────┬───────────────────┘
                ▼                                          ▼
 ┌──────────────────────────────┐   ┌──────────────────────────────────────────┐
 │ L2a ma_store_memory          │   │ L2b ma_store_sql                         │
 │  dict 기반. 테스트·로컬       │   │  SQLAlchemy Core. ma_sql 위에            │
 │  deepcopy로 격리             │   │  "Agent를 아는" SQL은 여기에만            │
 └──────────────────────────────┘   └──────────────┬───────────────────────────┘
                                                   ▼
                                    ┌──────────────────────────────────────────┐
                                    │ L2c ma_sql   Engine/Connection Port       │
                                    │  방언 차이 흡수. Agent를 전혀 모른다      │
                                    └──────────────────────────────────────────┘
                                  ▼
 ┌─────────────────────────────────────────────────────────────────────────────┐
 │ L1  ma_domain     순수 타입. 외부 의존성 0                                   │
 │     Agent · Session · SessionEvent · Vault · MemoryStore · Approval · …      │
 │     frozen dataclass. 직렬화 라이브러리도 import하지 않는다                   │
 └─────────────────────────────────────────────────────────────────────────────┘
```

### 횡단(cross-cutting) 패키지

레이어 밖에 있지만 어디서나 import할 수 있는 것들입니다. 대신 **이들은 아무도 import하지
않습니다**(의존성 0에 가깝게 유지).

| 패키지 | 역할 | 어느 레이어에서 쓰이나 |
|---|---|---|
| `ma_observability` | 구조화 로그, OTel 트레이스, 메트릭 | L4~L7 |
| `ma_auth` | 인증 미들웨어, 주체(principal) 해석 | L5a, L7 |
| `ma_governance` | 승인 · 감사 · 예산 · 쿼터 | L4 (Port로), L5a |
| `ma_schema` | Alembic 마이그레이션 — **스키마의 유일한 진실** | L7에서만 실행 |

---

## 3. 레이어별 책임과 금지 사항

금지 목록이 책임 목록보다 중요합니다. 이것이 CI 규칙이 됩니다.

### L1 `ma_domain`

| 있어야 하는 것 | 절대 없어야 하는 것 |
|---|---|
| `frozen=True` dataclass, Enum, 타입 별칭 | FastAPI, pydantic, SQLAlchemy, httpx, anthropic SDK |
| 도메인 불변식 검사 (`__post_init__`) | DB 세션, 네트워크 호출, 파일 I/O |
| 값 객체(`WorkspaceId`, `SessionId`) | `datetime.now()` — 시간은 주입받는다 |

```python
# packages/ma_domain/src/ma_domain/agents.py
@dataclass(frozen=True, slots=True)
class AgentDefinition:
    name: str
    model: ModelHandle
    system: str | None
    tools: tuple[ToolSpec, ...]
    mcp_servers: tuple[McpServerSpec, ...]
    skills: tuple[SkillRef, ...]


@dataclass(frozen=True, slots=True)
class AgentRecord:
    id: AgentId
    workspace_id: WorkspaceId
    definition: AgentDefinition
    version: int
    created_at: datetime
    updated_at: datetime
    archived_at: datetime | None
```

> **`workspace_id`는 도메인에서 "호스트가 준 파티션 키"일 뿐입니다.** 도메인은 "테넌트",
> "부서", "조직"을 모릅니다. 그 해석은 L5a 인증 이후에 끝납니다.

### L2 `ma_store_sql` / `ma_store_memory` / `ma_sql`

| 있어야 하는 것 | 절대 없어야 하는 것 |
|---|---|
| `ma_store` Protocol의 구현 | 비즈니스 규칙, 검증, 권한 판단 |
| SQL 문장, 인덱스 힌트, 방언 분기 | HTTP 상태코드, pydantic 모델 |
| 암복호화 **호출**(cipher는 생성자 인자) | 키 생성·키 관리 정책 |

**cipher는 생성자 인자**라는 것이 중요합니다. 비밀 처리기가 application Port 그래프에
들어가면, 어떤 유스케이스가 평문을 만질 수 있는지 추적할 수 없게 됩니다.

```python
# packages/ma_store_sql/src/ma_store_sql/credentials.py
class SqlCredentialStore:
    def __init__(self, sql: SqlClient, cipher: CredentialCipher) -> None:
        self._sql, self._cipher = sql, cipher

    # cipher는 ma_platform 조립 시점에만 주입된다. Port 토큰이 아니다.
```

### L3 `ma_store`

| 있어야 하는 것 | 절대 없어야 하는 것 |
|---|---|
| `Protocol` 선언, 입출력 dataclass | 구현, SQL, dict |
| discriminated union 결과 타입 | 다른 Store import (교차 도메인 결합 금지) |
| `ma_domain` 의존 | 그 외 모든 의존 |

```python
# packages/ma_store/src/ma_store/agents.py
type ReplaceAgentResult = ReplacedAgent | AgentNotFound | AgentVersionConflict


class AgentStore(Protocol):
    async def insert(self, cmd: InsertAgent) -> AgentRecord: ...
    async def find_current(self, q: FindCurrentAgent) -> AgentRecord | None: ...
    async def find_version(self, q: FindAgentVersion) -> AgentRecord | None: ...
    async def replace_current(self, cmd: ReplaceAgent) -> ReplaceAgentResult: ...
    async def archive_current(self, cmd: ArchiveAgent) -> ArchiveAgentResult: ...
    async def list_current(self, q: ListAgents) -> Sequence[AgentRecord]: ...
    async def list_versions(self, q: ListAgentVersions) -> Sequence[AgentRecord]: ...
```

**결과를 예외로 표현하지 않는 이유**: `version_conflict`는 버그가 아니라 정상적인 동시성
결과입니다. 예외로 던지면 호출자가 `try/except`로 흐름 제어를 하게 되고, 어떤 예외가
비즈니스 결과이고 어떤 것이 장애인지 구분이 사라집니다.

### L4 `ma_application`

| 있어야 하는 것 | 절대 없어야 하는 것 |
|---|---|
| 유스케이스 메서드 (`create_agent`, `send_session_events`) | SQL, HTTP, pydantic, FastAPI |
| 검증, 권한 확인, 페이지네이션 커서 계산 | 특정 DB 방언 지식 |
| 좁은 Port 선언 (`agent_store_port`) | 범용 `Store` 서비스 로케이터 |
| 교차 도메인 narrow Port (조립 시점에 만들어 주입) | 다른 Store를 직접 resolve |

**범용 서비스 로케이터 금지**가 레퍼런스에서 배운 가장 실용적인 규칙입니다. 레퍼런스의 v0는
`Services` 컨테이너(agents, sessions, vaults, credentials, memory, files, evals, ... 16개
필드)를 미들웨어가 요청마다 만들어 주입합니다. 결과적으로 **어떤 라우트가 무엇에
의존하는지 코드에서 읽을 수 없습니다.** v1은 기능마다 자기가 쓰는 Store만 선언합니다.

교차 도메인이 필요하면 **조립 시점에 좁은 Port를 만듭니다**:

```python
# 자격증명 생성 시 vault 존재를 검증해야 한다.
# ❌ CredentialStore가 VaultStore를 import
# ✅ 조립 시점에 좁은 Port를 만들어 주입
def credential_vault_source(vaults: VaultStore) -> CredentialVaultSource:
    async def exists(ws: WorkspaceId, vault_id: VaultId) -> bool:
        return await vaults.find_current(FindCurrentVault(ws, vault_id)) is not None

    return CredentialVaultSource(exists=exists)
```

### L5a `ma_api`

| 있어야 하는 것 | 절대 없어야 하는 것 |
|---|---|
| FastAPI 라우터, 의존성 주입 | 비즈니스 규칙 |
| pydantic wire 스키마 (**`extra="forbid"`**) | SQL, Store 직접 호출 |
| wire ↔ application 명시적 매퍼 | Store를 건너뛴 DB 접근 |
| 에러 envelope 변환 | `Any` / `dict[str, Any]` 반환 |

**응답도 재검증합니다.** 들어오는 것만 검증하고 나가는 것을 검증하지 않으면, 내부 필드가
조용히 wire에 새어 나갑니다(그리고 그게 사실상 공개 API가 됩니다).

```
요청 → 라우터 → strict ingress 스키마 → wire→app 매퍼
     → application Port → app→wire 매퍼 → strict egress 스키마 → 응답
                                              ↑ 실패하면 500. 200으로 내보내지 않는다
```

### L5b `ma_adapters_*`

application Port를 "밖의 세계" 모양에 맞추는 코드입니다. Store보다 거친 자원을 다룹니다.

| 어댑터 | 하는 일 |
|---|---|
| `ma_adapters_sql` | application persistence Port ↔ `ma_store_sql`. 세션 이벤트 폴링/복제 스트림 |
| `ma_adapters_blob` | `FileContentPort` ← 오브젝트 스토어 |
| `ma_adapters_runtime` | 스케줄러(cron), 웹훅 서명, 실시간 fanout |
| `ma_adapters_k8s` | `SandboxPort` ← k8s API |
| `ma_adapters_http` | 외부 HTTP(모델 provider, MCP) |

### L6 `ma_platform`

```python
# packages/ma_platform/src/ma_platform/sql.py
def build_sql_app(
    *, workspace_id: WorkspaceId, sql: SqlClient,
    clock: Clock, ids: IdGenerator,
    ciphers: CipherBundle,
    features: FeatureSet,
    overrides: StoreOverrides | None = None,
) -> App:
    stores = StoreBundle(
        agents      = overrides.agents      or SqlAgentStore(sql),
        sessions    = overrides.sessions    or SqlSessionStore(sql),
        events      = overrides.events      or SqlSessionEventStore(sql),
        executions  = overrides.executions  or SqlExecutionStore(sql),
        credentials = overrides.credentials or SqlCredentialStore(sql, ciphers.credential),
        ...
    )
    return create_app(
        modules=[agents_module(), sessions_module(), vaults_module(), ...],
        provided=[
            provide(workspace_context_port, WorkspaceContext(workspace_id)),
            provide(clock_port, clock), provide(id_generator_port, ids),
            provide(agent_store_port, stores.agents),
            ...
        ],
        features=features,
    )
```

`WorkspaceAppRegistry`가 `workspace_id → App` 하나를 캐시합니다. **이것이 테넌트 누수
방어선입니다** — 앱 그래프가 워크스페이스에 핀되어 있으므로, 요청 스코프 액터나 백그라운드
작업이 다른 워크스페이스의 캐시를 보는 일이 구조적으로 불가능합니다.

### L7 `apps`

**환경변수를 읽는 유일한 레이어**입니다. 레퍼런스의 `main-node`가 이 패턴을 잘 보여줍니다.

```
config.py      : os.environ → 타입된 Config 1회. 모든 문제를 하나의 ConfigError로 보고
components.py  : 어떤 구현을 쓸지 선택. 기본값은 각각 export된 생성자
assembly.py    : 생명주기(시작/종료 역순 정리), 스케줄러, 워커
http.py        : 라우터 마운트
__main__.py    : config → components → assemble → serve
```

```python
# apps/control_plane/src/control_plane/__main__.py
cfg = load_config(os.environ)  # 여기만 환경변수를 안다
components = await default_components(cfg)  # 또는 호출자가 일부를 교체
app = await build_control_plane(components)
await serve(app, host=cfg.host, port=cfg.port)
```

이 구조의 가치: **배포 프리셋이 라이브러리 사용자가 된다.** 쿠버네티스용·Compose용·
테스트용이 `os.environ`을 건드리지 않고 `components`를 조립합니다.

---

## 4. Port / Module 규칙 7개

레퍼런스의 규칙을 Python으로 옮긴 것입니다. 이것이 CI 규칙의 근거입니다.

| # | 규칙 |
|---|---|
| R1 | 모듈은 자기가 **필요한 Port와 제공하는 Port를 모두 선언**한다 |
| R2 | 모듈은 선언한 의존성만 받는다. 앱 그래프·컨테이너·환경변수·전체 Store 묶음을 resolve할 수 없다 |
| R3 | 각 기능은 **좁은 도메인 Store Port만** 받는다. 범용 `Store` 서비스 로케이터는 없다 |
| R4 | 인터페이스 패키지(L1, L3)는 FastAPI·pydantic·SQLAlchemy·드라이버·벤더 SDK를 import하지 않는다 |
| R5 | 구현체는 저수준 의존성(`SqlClient`, cipher)을 **생성자로** 받는다. `SqlClient`는 application Port가 아니다 |
| R6 | HTTP · 저장소 · 샌드박스 · MCP · 하네스 · 스케줄링 · 실시간 · 실행 조정은 **별개 capability**다. 하나를 켜려고 다른 것을 켜야 하면 경계가 잘못됐다 |
| R7 | 내부 API lane과 공식 호환 API lane은 **최외곽 HTTP 조립 직전까지 분리**된다 ([D9](README.md#핵심-설계-결정)) |

### Module 선언 예시

```python
# packages/ma_platform/src/ma_platform/modules/agents.py
agent_store_port = PortToken[AgentStore]("ma.store.agents")
agents_port = PortToken[AgentsUseCases]("ma.app.agents")


def agents_module() -> AppModule:
    return AppModule(
        name="ma:agents",
        provides=[agents_port],
        requires=[
            workspace_context_port,
            clock_port,
            id_generator_port,
            agent_store_port,
            audit_port,
        ],
        setup=lambda port: [
            bind(
                agents_port,
                AgentsUseCases(
                    workspace_id=port(workspace_context_port).workspace_id,
                    clock=port(clock_port),
                    store=port(agent_store_port),
                    audit=port(audit_port),
                    next_id=lambda: port(id_generator_port).next("agent"),
                ),
            )
        ],
    )
```

`requires`에 적지 않은 Port를 `port()`로 꺼내면 조립 시점에 **실패합니다**(런타임이 아니라).
의존성이 선언과 일치함을 기계가 보장합니다.

---

## 5. CI로 강제하기

문서에 적힌 원칙은 지켜지지 않습니다. 기계가 검사해야 지켜집니다.

### 5.1 import 경계 — `import-linter`

```ini
# .importlinter
[importlinter]
root_packages = ma_domain ma_store ma_store_sql ma_store_memory ma_sql
                ma_application ma_api ma_adapters_sql ma_adapters_k8s
                ma_platform ma_harness ma_sandbox ma_governance

[importlinter:contract:layers]
name = AWP 레이어 순서
type = layers
layers =
    ma_platform
    ma_api | ma_adapters_sql | ma_adapters_k8s
    ma_application
    ma_store_sql | ma_store_memory
    ma_store
    ma_domain

[importlinter:contract:core-purity]
name = 코어는 플랫폼을 모른다
type = forbidden
source_modules = ma_domain ma_store ma_application ma_api
forbidden_modules =
    sqlalchemy  asyncpg  psycopg  kubernetes  boto3  anthropic  httpx  redis

[importlinter:contract:domain-purity]
name = 도메인은 아무것도 모른다
type = forbidden
source_modules = ma_domain
forbidden_modules = pydantic fastapi sqlalchemy

[importlinter:contract:no-cross-store]
name = Store끼리 서로 모른다
type = independence
modules = ma_store.agents ma_store.sessions ma_store.vaults
          ma_store.credentials ma_store.memory ma_store.executions

[importlinter:contract:api-lanes]
name = 내부 lane과 공식 lane은 섞이지 않는다
type = independence
modules = ma_api.internal ma_api.compat
```

> `ma_api`가 `anthropic`을 import 못 하게 막는 것이 핵심입니다. 공식 호환 lane은 wire
> **shape**만 따르고, SDK를 런타임 의존으로 들이지 않습니다. (타입 참조가 필요하면
> `TYPE_CHECKING` 블록 안에서만.)

### 5.2 추가 검사 — `tools/check_architecture.py`

| 검사 | 실패 조건 |
|---|---|
| 스키마 단일 출처 | `packages/`에서 `CREATE TABLE` 문자열 발견 (`ma_schema` 제외) → 실패 ([D2](README.md#핵심-설계-결정)) |
| 환경변수 단일 출처 | `apps/*/config.py` 밖에서 `os.environ` / `os.getenv` 발견 → 실패 |
| 시간 주입 | `ma_domain` · `ma_application`에서 `datetime.now` / `time.time` 발견 → 실패 |
| provider 중립 | `ma_sandbox`에서 `kubernetes` import 발견 → 실패 (어댑터에만 허용) |
| Store 계약 커버리지 | 모든 `ma_store` Protocol이 memory·sql 두 구현에서 동일한 계약 테스트를 통과하는지 |
| 응답 재검증 | `ma_api` 라우터에 `response_model`이 없는 핸들러 발견 → 실패 |
| 감사 권한 | 마이그레이션에 `audit_log`에 대한 UPDATE/DELETE GRANT가 있으면 실패 |

### 5.3 Store 계약 테스트

같은 테스트 스위트를 두 구현에 돌립니다. 이것이 "런타임 이식성"을 실제로 보장합니다.

```python
# tests/contract/test_agent_store.py
@pytest.fixture(params=["memory", "sql"])
async def store(request, pg_engine) -> AgentStore:
    if request.param == "memory":
        return MemoryAgentStore()
    return SqlAgentStore(SqlClient(pg_engine))


async def test_replace_detects_version_conflict(store: AgentStore):
    created = await store.insert(InsertAgent(...))
    first = await store.replace_current(ReplaceAgent(..., expected_version=created.version))
    second = await store.replace_current(ReplaceAgent(..., expected_version=created.version))
    assert isinstance(first, ReplacedAgent)
    assert isinstance(second, AgentVersionConflict)
    assert second.actual_version == created.version + 1
```

---

## 6. 낙관적 동시성 — 한 가지 패턴만

버전 관리되는 모든 리소스가 같은 모양을 씁니다. 패턴이 하나면 리뷰가 쉽습니다.

```
읽기:  record.version
쓰기:  replace_current(expected_version=record.version)
결과:  ReplacedAgent | AgentNotFound | AgentVersionConflict(actual_version=N)
HTTP:  409 conflict_error + actual_version
```

SQL 구현은 **한 번의 원자적 배치**로 처리합니다(스냅샷 + 교체가 쪼개지면 버전 역사가 깨집니다).

```sql
-- stmt 1: 현재 행을 버전 테이블로 스냅샷
INSERT INTO agent_versions (agent_id, workspace_id, version, document, created_at)
SELECT id, workspace_id, version, document, updated_at FROM agents
 WHERE workspace_id = :ws AND id = :id AND version = :expected AND archived_at IS NULL;

-- stmt 2: 같은 조건으로 현재 행 교체
UPDATE agents SET document = :doc, version = :next, updated_at = :now
 WHERE workspace_id = :ws AND id = :id AND version = :expected AND archived_at IS NULL;
```

영향 행 수가 `(1,1)`이면 성공, `(0,0)`이면 `not_found` 또는 `version_conflict`를 구분하기 위해
추가 조회, 그 밖의 조합이면 **불변식 위반이므로 예외**를 올립니다(조용히 넘기지 않습니다).

---

## 7. 세대 분기를 만들지 않기 (D1)

레퍼런스를 읽기 어렵게 만드는 가장 큰 원인은 **같은 개념에 두 세대의 구현이 공존**하는
것입니다. `agent`가 `/v1/agents`(신, `managed_agents` 테이블)와 `/v1/oma/agents`(구,
`agents` 테이블)에 별개 문서·별개 테이블로 존재하고, 한 파일 안에서 두 경로가 나란히 쓰입니다.

AWP의 규칙:

1. **리소스마다 구현은 하나.** 마이그레이션 중이라도 두 구현을 동시에 서빙하지 않는다.
2. **인터페이스 변경은 adapter로 흡수한다.** `ma_store` Protocol이 바뀌면 구현을 고치고,
   두 번째 Protocol을 만들지 않는다.
3. **API 버전은 HTTP 경로로만 표현한다.** 내부 패키지 이름에 `v1`/`v2`를 넣지 않는다.
   패키지 이름에 세대가 들어가면 영구히 남는다(레퍼런스의 `memory-store-store`,
   `session-runtime-contract` 같은 이름은 세대 충돌 회피의 흔적이다).
4. 그래도 큰 전환이 필요하면 **워크스페이스 단위 lane**으로 라우팅하고, 전환이 끝나면
   구 경로를 **삭제**한다. 유지하지 않는다.

---

## 8. 다음 문서

레이어 L5a가 노출하는 표면 → [04. API 구조](04-api.md)
