# 08. 인프라 · 인스턴스

> 다이어그램: [`svg/17-k8s-topology.svg`](svg/17-k8s-topology.svg) ·
> [`svg/18-network-egress.svg`](svg/18-network-egress.svg)
> Kubernetes 1.33+ · Calico 또는 Cilium CNI · CloudNativePG · Argo CD

---

## 1. 샌드박스를 워커 안에 넣은 결과

[07](07-sandbox.md)의 결정 — Wasm 기본, bubblewrap 보조 — 이 토폴로지를 크게 단순화합니다.

| | per-session Pod 방식 | **AWP (샌드박스 = 워커 내부)** |
|---|---|---|
| 세션 시작마다 | k8s API 호출 + 스케줄링 + 이미지 pull | 없음 |
| 기동 지연 | 수 초 ~ 수십 초 | 티어 W **수 ms**, 티어 P 수십 ms |
| 워커의 k8s RBAC | Pod create/delete/exec 필요 | **불필요** |
| 밀도 | 노드당 Pod 수 한도에 묶임 | 워커 프로세스당 수십 세션 |
| 격리 경계 | Pod | Wasm 인스턴스 / confine된 subprocess |
| 커널 모듈 | gVisor·Kata는 runtimeClass 필요 | **없음** |

대신 **노이지 네이버와 부서 격리를 어디서 처리할지**가 바뀝니다. 샌드박스가 Pod가 아니니
"샌드박스 네임스페이스"가 사라지고, 대신 **runtime-worker를 부서별 네임스페이스에 둡니다.**
D7(부서 = 네임스페이스 = ResourceQuota = 예산 집행 지점)은 그대로 유지됩니다.

---

## 2. 네임스페이스

```
awp-system                       플랫폼 공통 (신뢰)
  control-plane      Deployment  FastAPI. API + 인증 + 승인 + 감사 + Console 서빙
  egress-proxy       Deployment  MITM TLS + allowlist + credential 주입
  scheduler          Deployment  cron · 보존 · GC · 파티션 생성 (리더 선출)
  migrate            Job         Alembic (helm pre-upgrade 훅)

awp-runtime-법무                  부서별 실행 평면 (준신뢰)
  runtime-worker     Deployment  하네스 + 샌드박스. KEDA scale-to-zero
  ResourceQuota                  ← 예산의 물리적 집행 지점
  LimitRange · NetworkPolicy · ServiceAccount(최소 권한)
awp-runtime-재경
awp-runtime-인사
  …부서당 하나

awp-data                         상태 (신뢰)
  postgres           CloudNativePG Cluster  primary 1 + replica 2
  objectstore        S3 (외부) 또는 MinIO StatefulSet
```

### 왜 부서별 네임스페이스인가

| 얻는 것 | 설명 |
|---|---|
| **예산의 물리적 집행** | `ResourceQuota`로 CPU·메모리 상한. 애플리케이션 예산(토큰 $)과 자원 예산이 같은 경계 |
| **노이지 네이버 차단** | 한 부서가 자원을 다 써도 다른 부서 네임스페이스의 Quota는 그대로 |
| **부서별 NetworkPolicy** | 법무는 사내 위키만, 재경은 ERP만 — allowlist를 네트워크 계층에도 반영 |
| **blast radius** | 워커 버그·OOM이 해당 부서에 머문다 |
| **감사 단위 일치** | 네임스페이스 로그·메트릭이 곧 부서 단위 보고 |

### 대안: 공유 워커 풀 (작은 설치에서)

부서가 3개 이하면 `awp-runtime` 하나에 공유 워커를 두고 애플리케이션 레벨 공정 큐
(워크스페이스별 동시 실행 상한)만 씁니다. 그러면 `ResourceQuota`로 예산을 집행할 수 없고
노이지 네이버를 애플리케이션이 떠안습니다. **부서가 늘면 분리하는 것이 전제**입니다.

---

## 3. 인스턴스 역할표

| 워크로드 | 종류 | 복제 | 요청/한도 | 스케일 신호 | 상태 | 죽으면 |
|---|---|---|---|---|---|---|
| **control-plane** | Deployment | 3 ~ 20 | 500m/1Gi ~ 2/4Gi | HPA: RPS + CPU 70% | 무상태 | 진행 중 턴은 무영향. 새 입력·SSE만 중단 |
| **runtime-worker** | Deployment (부서별) | **0** ~ 50 | 1/2Gi ~ 4/8Gi | **KEDA: 해당 워크스페이스 `queued` execution 수** | 무상태 (fence가 권한) | lease 90s 만료 후 다른 워커가 재claim |
| **egress-proxy** | Deployment | 2 ~ 10 | 250m/512Mi ~ 1/2Gi | HPA: 활성 연결 수 | 무상태 (세션 CA는 단기) | **세션이 막힌다. 올바른 동작** |
| **scheduler** | Deployment | 2 (리더 1) | 100m/256Mi | 없음 | 리더 락 (`pg_advisory_lock`) | 리더 교체. 작업은 멱등 |
| **migrate** | Job | 1 | 250m/512Mi | 없음 | — | 배포 실패. 롤백 |
| **postgres** | CNPG Cluster | 1 primary + 2 replica | 2/8Gi ~ 4/16Gi | 수동 | **상태** | 자동 failover (~30s). lease TTL 90s가 이를 흡수 |
| **objectstore** | 외부 S3 권장 | — | — | — | **상태** | 스냅샷·산출물 접근 불가 |

### KEDA — 워커를 0으로 내린다

```yaml
apiVersion: keda.sh/v1alpha1
kind: ScaledObject
metadata:
  name: runtime-worker
  namespace: awp-runtime-법무
spec:
  scaleTargetRef: { name: runtime-worker }
  minReplicaCount: 0          # 일이 없으면 Pod 0개
  maxReplicaCount: 50
  cooldownPeriod: 300         # 실행 중 턴을 끊지 않기 위해 넉넉히
  triggers:
    - type: postgresql
      metadata:
        query: >
          SELECT count(*) FROM session_executions
           WHERE workspace_id = 'wrkspc_법무'
             AND state = 'queued'
        targetQueryValue: "2"   # queued 2건당 1 Pod
```

**scale-to-zero가 중요한 이유**: 부서별 네임스페이스로 쪼개면 유휴 Pod가 부서 수만큼
생깁니다. 0으로 내려가면 그 비용이 사라집니다. 첫 세션의 콜드 스타트(~10s)는 사내
플랫폼에서 받아들일 만합니다.

### 우아한 종료 — 턴을 끊지 않기

```yaml
terminationGracePeriodSeconds: 600     # 턴이 끝날 시간
lifecycle:
  preStop:
    exec: { command: ["/app/bin/awp-worker", "drain"] }
```

`drain`은 (1) `worker_instances.draining = true` 표시, (2) 새 claim 중지,
(3) 진행 중 execution의 하트비트 유지, (4) 끝나면 `settle` 후 종료합니다.
600초를 넘기면 SIGKILL이고, 그때는 lease 만료 → 재claim 경로로 복구됩니다.

---

## 4. Pod 보안 — 티어가 요구하는 것

### 티어 W (Wasm) — 가장 제약적인 설정에서도 동작한다

```yaml
securityContext:                    # Pod
  runAsNonRoot: true
  runAsUser: 10001
  seccompProfile: { type: RuntimeDefault }
  fsGroup: 10001
containers:
- name: runtime-worker
  securityContext:                  # Container
    allowPrivilegeEscalation: false
    readOnlyRootFilesystem: true
    capabilities: { drop: ["ALL"] }
  volumeMounts:
  - { name: workspaces, mountPath: /var/awp/workspaces }
  - { name: tmp,        mountPath: /tmp }
volumes:
- { name: workspaces, emptyDir: { sizeLimit: 20Gi } }
- { name: tmp,        emptyDir: { sizeLimit: 2Gi } }
automountServiceAccountToken: false
hostNetwork: false
hostPID: false
```

`RuntimeDefault` seccomp, 전 capability drop, read-only rootfs, non-root — **Restricted Pod
Security Standard를 그대로 통과합니다.** Wasm은 전부 유저스페이스이므로 특별 권한이
하나도 필요 없습니다.

### 티어 P (bubblewrap) — 비특권 user namespace가 필요하다

bubblewrap은 **비특권 user namespace**를 만듭니다. 컨테이너 안에서 이것이 되려면 둘 중
하나가 필요합니다.

| 방법 | 요구사항 | 비고 |
|---|---|---|
| **(A) k8s user namespace** | k8s **1.33+** `UserNamespacesSupport` + `hostUsers: false` + CRI 지원(containerd 2.0+) | **권장.** 추가 seccomp 완화 불필요 |
| **(B) 커스텀 seccomp 프로필** | `clone`/`unshare`의 `CLONE_NEWUSER`·`CLONE_NEWNS`를 허용하는 프로필 | `RuntimeDefault`는 이것을 막는다. 완화 범위를 문서화해야 한다 |

**둘 다 불가하면 티어 P는 `unsupported`로 보고**되고, 그 노드/클러스터에서는 티어 W만
쓸 수 있습니다. 이것이 [D6](README.md#핵심-설계-결정)의 실제 작동 예입니다 —
능력을 추측하지 않고 프로브해서 보고합니다.

### 티어 P의 bwrap 플래그 — 네트워크를 반드시 끊는다

샌드박스가 워커 Pod 안에 있으므로, 아무 조치 없이 subprocess를 띄우면 **Pod의 네트워크
네임스페이스를 공유해 PostgreSQL IP:5432에 직접 접속할 수 있습니다.** 이것이 샌드박스를
워커 안에 넣을 때의 핵심 위험이고, 반드시 막아야 합니다.

```
bwrap
  --unshare-user --unshare-pid --unshare-ipc --unshare-uts
  --unshare-net                      ★ 자기 netns. 네트워크 없음
  --die-with-parent --new-session
  --ro-bind /usr /usr  --ro-bind /lib /lib  --ro-bind /bin /bin
  --bind   <workspace> /workspace
  --bind   <memory>    /mnt/memory/<name>      (읽기전용이면 --ro-bind)
  --tmpfs  /tmp  --proc /proc  --dev /dev
  --chdir  /workspace
  --clearenv --setenv PATH /usr/bin:/bin --setenv HOME /workspace
  -- <원래 argv>
```

| 효과 | 왜 |
|---|---|
| `--unshare-net` | **기본값.** 샌드박스에 네트워크가 없다. DB·k8s API·인터넷 전부 불가 |
| `--unshare-pid` | 워커 프로세스의 `/proc/<pid>/environ`을 읽을 수 없다 |
| `--clearenv` | 워커 환경변수(DB DSN 등)가 상속되지 않는다 |
| `--die-with-parent` | 고아 프로세스가 남지 않는다 |

**네트워크가 필요한 티어 P 환경**(`pip install`, `git clone`)은 `pasta`(또는 `slirp4netns`)로
유저모드 네트워크 스택을 붙이고 **egress-proxy 주소 하나로만** 라우팅합니다. 커널 모듈
없이 되고, 이 경우에만 `egress_enforcement: enforced`를 보고합니다. pasta가 없으면
`--unshare-net`을 유지하고 그 환경에서는 네트워크 툴을 **등록하지 않습니다.**

> `web_fetch`/`web_search`는 신뢰 영역에서 실행되므로 `--unshare-net`에 영향받지 않습니다.
> 샌드박스에 네트워크가 없어도 에이전트는 웹을 볼 수 있습니다 — 다만 **우리가 중개하는
> 경로로만** 봅니다. 이것이 올바른 기본값입니다.

---

## 5. 네트워크

### 5.1 허용된 흐름만

```
인터넷 ──▶ Ingress (TLS) ──▶ control-plane:8000

control-plane ──▶ postgres:5432          (primary)
control-plane ──▶ objectstore:443
control-plane ──▶ egress-proxy:8443      (credential 조회 응답은 "주입 완료"뿐)

runtime-worker ──▶ postgres:5432         (역할 awp_worker: execution/event만)
runtime-worker ──▶ control-plane:8000    (credential 대행 요청)
runtime-worker ──▶ egress-proxy:3128     (모델 호출 · web_fetch · MCP)
runtime-worker ──▶ kube-dns:53

egress-proxy ──▶ 인터넷 (allowlist 통과분)
egress-proxy ──▶ 사내 시스템 (allowlist)

샌드박스 ──▶ (티어 W) 소켓 없음 / (티어 P) 자기 netns, 네트워크 없음
             네트워크 필요 환경만 pasta → egress-proxy
```

### 5.2 NetworkPolicy — 부서 네임스페이스

```yaml
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata: { name: runtime-worker-egress, namespace: awp-runtime-법무 }
spec:
  podSelector: { matchLabels: { app: runtime-worker } }
  policyTypes: [Egress, Ingress]
  ingress: []                                  # 아무도 워커에 들어오지 않는다
  egress:
    - to: [{ namespaceSelector: { matchLabels: { name: awp-data } },
            podSelector: { matchLabels: { app: postgres } } }]
      ports: [{ port: 5432, protocol: TCP }]
    - to: [{ namespaceSelector: { matchLabels: { name: awp-system } },
            podSelector: { matchLabels: { app: control-plane } } }]
      ports: [{ port: 8000, protocol: TCP }]
    - to: [{ namespaceSelector: { matchLabels: { name: awp-system } },
            podSelector: { matchLabels: { app: egress-proxy } } }]
      ports: [{ port: 3128, protocol: TCP }]
    - to: [{ namespaceSelector: { matchLabels: { kubernetes.io/metadata.name: kube-system } },
            podSelector: { matchLabels: { k8s-app: kube-dns } } }]
      ports: [{ port: 53, protocol: UDP }, { port: 53, protocol: TCP }]
  # 그 외 전부 거부 — 인터넷 직접 접근 불가
```

**CNI가 NetworkPolicy를 실제로 강제해야 합니다.** 강제하지 않는 CNI(일부 기본 설정)에서는
이 정책이 조용히 무시됩니다. 그래서 부팅 시 **프로브로 확인**하고
`egress_enforcement_conditions.cni_enforces_networkpolicy`에 CNI 이름을 보고합니다
([07](07-sandbox.md) §5).

### 5.3 DB 역할 분리

| 역할 | 권한 |
|---|---|
| `awp_app` (control-plane) | 전 테이블 SELECT/INSERT/UPDATE. **`audit_log`는 INSERT/SELECT만** |
| `awp_worker` (runtime-worker) | `session_executions`·`session_events`·`session_pending_events`·`sandbox_instances`·`usage_events`에 한정. RLS 우회 허용(워크스페이스 횡단 claim 때문) |
| `awp_migrate` (Job) | DDL |
| `awp_ro` (대시보드·분석) | SELECT only |

워커에게 `credentials` 테이블 권한을 **주지 않습니다.** 자격증명은 제어 평면 대행으로만
접근합니다([07](07-sandbox.md) §6).

---

## 6. 스토리지

| 용도 | 매체 | 보존 |
|---|---|---|
| 세션 워크스페이스 (활성) | `emptyDir` (워커 Pod) | 세션 아이들까지 |
| 워크스페이스 스냅샷 | 오브젝트 스토어 `snapshots/<ws>/<session>/<gen>.tar.zst` | 7일 (설정) |
| 업로드 파일 | 오브젝트 스토어 `files/<ws>/<file_id>` | 워크스페이스 정책 |
| 세션 산출물 | 오브젝트 스토어 `outputs/<ws>/<session>/…` | 워크스페이스 정책 |
| 메모리 스냅샷 | 오브젝트 스토어 `memory/<ws>/<store>/<session>/` | 턴 종료 후 삭제 |
| 이벤트·감사·사용량 | PostgreSQL (월 파티션) | [05](05-database.md) §6 |

**`emptyDir`를 쓰는 이유**: 워크스페이스는 영속 상태가 아닙니다. 진실은 DB + 오브젝트
스토어에 있고, Pod가 죽으면 스냅샷에서 복원합니다. PVC를 쓰면 Pod가 노드에 묶여
scale-to-zero와 재스케줄이 어려워집니다.

`sizeLimit`을 반드시 지정합니다 — 없으면 에이전트가 노드 디스크를 채울 수 있습니다.

---

## 7. 비밀 관리

```
외부 KMS / Vault
      │  External Secrets Operator
      ▼
k8s Secret (awp-system)
      │
      ├── AWP_ROOT_SECRET          → control-plane만. credential 암복호화 키 파생
      ├── postgres 접속 정보        → control-plane, runtime-worker(awp_worker), scheduler
      ├── 모델 provider API 키      → egress-proxy만  ★ 워커에 주지 않는다
      └── 세션 CA 서명키            → egress-proxy만
```

| 원칙 | 구현 |
|---|---|
| 루트 시크릿은 제어 평면만 | 워커·프록시는 파생 키나 대행 호출만 |
| **모델 키도 워커에 없다** | egress-proxy가 주입. 워커가 탈취돼도 모델 키는 안 나간다 |
| 키 로테이션 | `credentials.key_version` 증가 + 백그라운드 재암호화 ([05](05-database.md) §7) |
| 백업에 루트 시크릿 미포함 | 별도 보관 |

---

## 8. 배포 — GitOps

```
deploy/
├── helm/awp/                     차트 1개
│   ├── templates/
│   │   ├── control-plane.yaml  egress-proxy.yaml  scheduler.yaml
│   │   ├── migrate-job.yaml      # helm.sh/hook: pre-upgrade
│   │   ├── runtime-worker.yaml   # range .Values.workspaces → 부서별 생성
│   │   ├── networkpolicy.yaml  resourcequota.yaml  keda.yaml
│   │   └── rbac.yaml  pdb.yaml  servicemonitor.yaml
│   └── values.yaml
├── overlays/{dev,staging,prod}/
└── argocd/applications.yaml
```

| 규칙 | 이유 |
|---|---|
| 마이그레이션은 **별도 Job** (`pre-upgrade` 훅) | 여러 Pod가 동시에 마이그레이션하면 깨진다. `pg_advisory_lock`으로 이중 안전 |
| **스키마 먼저, 코드 나중** | 하위 호환 스키마 → 코드 → (다음 릴리스에) 컬럼 삭제 |
| 부서 추가는 `values.yaml` 편집 | 네임스페이스·Quota·NetworkPolicy·KEDA가 함께 생성된다 |
| 이미지는 다이제스트 핀 | 태그 재사용으로 인한 드리프트 방지 |
| `PodDisruptionBudget` | control-plane `minAvailable: 2`, runtime-worker는 **설정하지 않음**(drain이 처리) |

---

## 9. 관측

```
control-plane / runtime-worker / egress-proxy
      │ OTel SDK (trace + metric + log)
      ▼
OTel Collector (DaemonSet)
      ├── trace  → Tempo
      ├── metric → Prometheus
      └── log    → Loki
                    ▼
                 Grafana
```

### 꼭 있어야 하는 대시보드 4개

| 대시보드 | 패널 |
|---|---|
| **세션 건강** | 상태 분포, `stop_reason` 분포, 턴 지연 p50/95/99, 에러율, `requires_action` 체류 시간 |
| **실행 큐** | `queued` 깊이(부서별), claim 지연, lease 만료(재claim) 수, `settle` 결과 분포 |
| **비용** | 부서별 토큰·비용, **캐시 적중률**(모델 카드별), off-peak 비율, 예산 소진율 ([06](06-harness-and-model.md) §6) |
| **샌드박스** | 티어별 프로비저닝 지연, 활성 인스턴스 수, `enforcement` 보고 분포, orphan 수 |

### 알람

| 알람 | 조건 | 왜 |
|---|---|---|
| **캐시 적중률 급락** | 15분 평균이 전주 대비 30%+ 하락 | 비용이 최대 50× 뛴다. 최우선 알람 |
| egress 강제 하향 | `enforcement`가 `enforced`→`advisory`로 바뀜 | 보안 상태 변화. 즉시 조사 |
| lease 만료 급증 | 5분간 10건+ | 워커 크래시 또는 DB 지연 |
| 큐 적체 | `queued`가 10분간 감소하지 않음 | KEDA·워커 장애 |
| 승인 체류 | `pending` 승인이 정책 만료의 80% 경과 | 사람이 놓치고 있다 |
| 예산 소진 | 부서 월 예산 80% | 사전 경고 |
| orphan 누적 | `runtime_orphans` 미정리 10건+ | 정리 경로 고장 |

---

## 10. 장애 모드 종합

| 장애 | 영향 | 복구 | 설계상 보장 |
|---|---|---|---|
| control-plane 전체 다운 | 새 입력·SSE 중단. 진행 중 턴은 계속 | ReplicaSet 교체 | 턴은 워커+DB로 완결된다 |
| runtime-worker 크래시 | 해당 턴 중단 | lease 90s 만료 → 재claim | 이벤트 유실 0, 중복 커밋 0 (fence) |
| 워커 좀비 (느린 죽음) | — | fence `generation` 불일치로 커밋 거부 | split-brain 불가 |
| egress-proxy 다운 | 모든 외부 호출 실패 → 세션 정체 | ReplicaSet 교체 | **자격증명 유출 0.** 가용성보다 기밀성 우선 |
| postgres failover | claim/append 일시 실패 | CNPG 자동 (~30s) | lease TTL 90s > failover 시간 |
| postgres 완전 손실 | 서비스 정지 | PITR 복구 | RPO 5분 (WAL 아카이빙) |
| 오브젝트 스토어 다운 | 스냅샷·산출물 불가. 새 세션은 가능 | — | 워크스페이스 복원만 지연 |
| 노드 손실 | 해당 워커의 턴들 중단 | 재스케줄 + 재claim | `emptyDir`라 노드에 묶이지 않는다 |
| 부서 Quota 소진 | 그 부서 새 Pod 불가 → 세션 `rescheduling` | Quota 증액 또는 대기 | **다른 부서 무영향** (D7) |
| CNI 정책 미강제 발견 | — | `enforcement` 하향 보고 → `required` 환경 차단 | 거짓 보안 주장을 하지 않는다 (D6) |

---

## 11. 용량 계획 출발점

| 가정 | 값 |
|---|---|
| 부서 수 | 8 |
| 동시 활성 세션 (피크) | 40 |
| 워커 Pod당 동시 세션 | 티어 W 20 / 티어 P 5 |
| 필요 워커 Pod (피크) | 티어 W 2 + 티어 P 8 ≈ **10** |
| 워커 노드 | 4 vCPU / 16Gi × 4대 (여유 포함) |
| control-plane | 3 Pod (SSE 연결 500개 기준) |
| PostgreSQL | 4 vCPU / 16Gi, 스토리지 500Gi (이벤트 1년) |
| 오브젝트 스토어 | 2TB (스냅샷 7일 + 산출물 1년) |

**SSE 연결이 control-plane 용량의 지배 항**입니다. 연결 하나가 소켓과 DB 구독을 점유하므로,
1단계에서는 PostgreSQL `LISTEN/NOTIFY`로 시작하고 연결이 1,000을 넘으면 Redis
pub/sub으로 `RealtimePort`를 교체합니다 — Port이므로 코드 변경이 한 파일입니다.

---

## 12. 다음 문서

이 인스턴스들을 만드는 코드의 배치 → [09. 코드베이스 구조](09-codebase.md)
