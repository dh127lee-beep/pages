# 05. 데이터베이스 구조

> 다이어그램: [`svg/11-erd-core.svg`](svg/11-erd-core.svg) · [`svg/12-erd-session.svg`](svg/12-erd-session.svg)
> PostgreSQL 17. 스키마의 유일한 진실은 `packages/ma_schema`의 Alembic 마이그레이션 ([D2](README.md#핵심-설계-결정)).

---

## 1. 설계 원칙 8개

| # | 원칙 | 이유 |
|---|---|---|
| S1 | **모든 테이블에 `workspace_id`.** 복합 인덱스의 첫 컬럼으로 둔다. | 파티션 키이자 격리 경계. `WHERE workspace_id = ?` 없는 쿼리는 리뷰에서 거부 |
| S2 | **버전 관리 리소스는 `document JSONB` + `version INT`.** 정규화하지 않는다. | 에이전트 설정 shape는 자주 변한다. 컬럼으로 펼치면 마이그레이션이 매번 필요하다. 조회는 ID·시간 기준이고 설정 내용으로 검색하지 않는다 |
| S3 | **`version` 테이블을 분리한다.** (`agents` ↔ `agent_versions`) | 현재 행은 작게 유지해 핫 경로 조회를 빠르게. 역사는 별 테이블 |
| S4 | **낙관적 동시성은 CAS 한 패턴.** `WHERE version = :expected` | [03](03-layers.md) §6. 패턴이 하나라 리뷰가 쉽다 |
| S5 | **이벤트 `seq`는 promote 시점에 부여한다.** 도착 시점이 아니다 | [D4](README.md#핵심-설계-결정). 순서 불변식 |
| S6 | **비밀은 `BYTEA` 암호문으로만.** 평문 컬럼을 두지 않는다 | 덤프·백업·로그에 평문이 남지 않는다 |
| S7 | **`audit_log`는 append-only.** 애플리케이션 역할에 UPDATE/DELETE 권한이 없다 | DB가 보장하면 코드 리뷰가 필요 없다 |
| S8 | **큰 테이블은 월 단위 파티션.** `session_events`, `audit_log`, `usage_events` | 보존 정책을 `DETACH PARTITION`으로 실행. DELETE로 지우면 vacuum 지옥 |

---

## 2. 테이블 그룹 — 11그룹 48테이블

| 그룹 | 테이블 | 수 |
|---|---|---|
| G1 테넌시·인증 | `workspaces` `users` `workspace_members` `workspace_invitations` `api_keys` `auth_sessions` | 6 |
| G2 에이전트 자산 | `agents` `agent_versions` `skills` `skill_versions` `model_cards` | 5 |
| G3 환경 | `environments` `environment_versions` `environment_work` | 3 |
| G4 세션 | `sessions` `session_threads` `session_resources` `session_memory_stores` `session_initial_events` | 5 |
| G5 이벤트·실행 | `session_events` `session_pending_events` `session_executions` `session_streams` | 4 |
| G6 자격증명 | `vaults` `credentials` `credential_events` | 3 |
| G7 메모리 | `memory_stores` `memories` `memory_versions` | 3 |
| G8 파일·산출물 | `files` `session_outputs` `workspace_snapshots` | 3 |
| G9 운영 | `deployments` `deployment_runs` `schedules` `webhook_endpoints` `webhook_deliveries` | 5 |
| G10 거버넌스 | `approval_policies` `approvals` `audit_log` `budgets` `usage_events` `quota_counters` | 6 |
| G11 인프라 좌표 | `sandbox_instances` `runtime_fences` `runtime_orphans` `worker_instances` `schema_locks` | 5 |

---

## 3. 주요 DDL

전체는 마이그레이션에 있고, 여기서는 **설계 판단이 들어간 테이블만** 싣습니다.

### G1. 테넌시

```sql
CREATE TABLE workspaces (
  id                        TEXT PRIMARY KEY,              -- wrkspc_01H...
  name                      TEXT NOT NULL,
  slug                      TEXT NOT NULL UNIQUE,          -- k8s 네임스페이스 이름이 된다
  settings                  JSONB NOT NULL DEFAULT '{}',
  max_concurrent_sessions   INT  NOT NULL DEFAULT 10,
  daily_session_quota       INT  NOT NULL DEFAULT 200,
  warm_pool_size            INT  NOT NULL DEFAULT 0,
  created_at                TIMESTAMPTZ NOT NULL,
  archived_at               TIMESTAMPTZ
);
-- slug는 소문자 영숫자와 하이픈만. k8s 네임스페이스 규칙(RFC1123)을 DB가 강제한다.
ALTER TABLE workspaces ADD CONSTRAINT workspaces_slug_dns
  CHECK (slug ~ '^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?$');

CREATE TABLE workspace_members (
  workspace_id  TEXT NOT NULL REFERENCES workspaces(id),
  user_id       TEXT NOT NULL REFERENCES users(id),
  role          TEXT NOT NULL CHECK (role IN ('viewer','operator','admin','owner')),
  created_at    TIMESTAMPTZ NOT NULL,
  PRIMARY KEY (workspace_id, user_id)
);
CREATE INDEX idx_members_user ON workspace_members (user_id);

CREATE TABLE api_keys (
  id              TEXT PRIMARY KEY,
  workspace_id    TEXT NOT NULL REFERENCES workspaces(id),   -- 키는 워크스페이스에 고정
  name            TEXT NOT NULL,
  key_hash        BYTEA NOT NULL,                            -- argon2id. 평문은 발급 시 1회만
  key_prefix      TEXT NOT NULL,                             -- 'awp_live_a1b2' 식별용
  role            TEXT NOT NULL,
  created_by      TEXT NOT NULL REFERENCES users(id),
  last_used_at    TIMESTAMPTZ,
  expires_at      TIMESTAMPTZ,
  revoked_at      TIMESTAMPTZ,
  created_at      TIMESTAMPTZ NOT NULL
);
CREATE UNIQUE INDEX idx_api_keys_hash ON api_keys (key_hash);
```

> `workspaces.slug`에 DNS 제약을 거는 것이 [D7](README.md#핵심-설계-결정)의 구현
> 디테일입니다. 워크스페이스가 k8s 네임스페이스가 되므로, 이름 규칙 위반을 Pod 생성
> 시점이 아니라 **생성 시점에** 막습니다.

### G2. 에이전트 — S2/S3/S4 패턴의 표준형

```sql
CREATE TABLE agents (
  id            TEXT NOT NULL,
  workspace_id  TEXT NOT NULL,
  document      JSONB NOT NULL,        -- AgentDefinition 직렬화
  version       INT  NOT NULL,
  created_by    TEXT NOT NULL,
  created_at    TIMESTAMPTZ NOT NULL,
  updated_at    TIMESTAMPTZ NOT NULL,
  archived_at   TIMESTAMPTZ,
  PRIMARY KEY (workspace_id, id)
);
-- 목록 조회는 (workspace, 시간, id) 커서. 인덱스가 커서 순서와 정확히 같아야 한다.
CREATE INDEX idx_agents_ws_created_id ON agents (workspace_id, created_at, id)
  WHERE archived_at IS NULL;

CREATE TABLE agent_versions (
  workspace_id  TEXT NOT NULL,
  agent_id      TEXT NOT NULL,
  version       INT  NOT NULL,
  document      JSONB NOT NULL,
  created_at    TIMESTAMPTZ NOT NULL,
  PRIMARY KEY (workspace_id, agent_id, version)
);
```

`skills`/`skill_versions`, `environments`/`environment_versions`가 **같은 모양**입니다.
새 버전 관리 리소스를 추가할 때 이 두 테이블을 복사하면 됩니다.

### G2b. 모델 카드 — 모델을 설정으로 만드는 테이블 (D12)

에이전트는 `document.model`에 **핸들**만 적고, 실제 모델에 대해 아는 것은 전부 여기 있습니다.
하네스는 이 행을 읽고 적응합니다 — 코드에 모델 문자열이 없습니다 ([06](06-harness-and-model.md) §1).

```sql
CREATE TABLE model_cards (
  id              TEXT NOT NULL,              -- "dept-default"  ← 에이전트가 참조하는 핸들
  workspace_id    TEXT NOT NULL,              -- NULL 불가. 전역 카드는 플랫폼 워크스페이스에 둔다
  provider        TEXT NOT NULL
      CHECK (provider IN ('deepseek_official','openai_compatible','anthropic_compatible')),
  wire_model      TEXT NOT NULL,              -- "deepseek-flash"  ← 실제로 전송되는 문자열
  base_url        TEXT,
  credential_id   TEXT,                       -- credentials(id). 평문은 제어 평면만

  -- 능력 선언: 하네스가 하드코딩하지 않기 위해 필요한 전부
  max_input_tokens   BIGINT NOT NULL,         -- 1000000
  max_output_tokens  BIGINT NOT NULL,         -- 384000
  supports_tools     BOOLEAN NOT NULL DEFAULT TRUE,
  supports_vision    BOOLEAN NOT NULL DEFAULT FALSE,
  supports_prompt_cache BOOLEAN NOT NULL DEFAULT TRUE,
  reasoning          JSONB,                   -- {param,style,levels} — §06 ReasoningSpec

  -- 요금 선언: 비용 계산이 코드가 아니라 데이터
  pricing         JSONB NOT NULL,             -- {currency,unit_tokens,input_cache_hit,
                                              --  input_cache_miss,output,
                                              --  off_peak_multiplier,peak_windows[]}
  off_peak_preferred BOOLEAN NOT NULL DEFAULT FALSE,

  defaults        JSONB NOT NULL DEFAULT '{}',-- {"reasoning_effort":"high","max_tokens":49152}
  enabled         BOOLEAN NOT NULL DEFAULT TRUE,
  created_at      TIMESTAMPTZ NOT NULL,
  updated_at      TIMESTAMPTZ NOT NULL,
  archived_at     TIMESTAMPTZ,
  PRIMARY KEY (workspace_id, id)
);
CREATE INDEX idx_model_cards_enabled ON model_cards (workspace_id)
  WHERE enabled AND archived_at IS NULL;
```

> **카드를 아카이브해도 지우지 않습니다.** 과거 세션의 `usage_events.model_card_id`가
> 이 행을 참조하고, 비용 재계산이 당시 요금표를 필요로 합니다. 요금이 바뀌면
> **새 카드를 만들거나** `pricing`을 갱신하되, 갱신하면 과거 비용 재계산이 달라진다는
> 점을 알고 해야 합니다. 그래서 `usage_events`는 계산된 `list_cost_cents`를 **그 시점 값으로
> 함께 저장**합니다(§3 G10).

```sql
-- 모델 결정 순서의 ②~③을 받치는 설정
-- workspaces.settings.default_model_card = "dept-default"
-- agents.document.model                  = "dept-default"   (④)
-- sessions.config_override.model         = "dept-heavy"     (⑤)
```

### G4. 세션

```sql
CREATE TABLE sessions (
  id                TEXT NOT NULL,
  workspace_id      TEXT NOT NULL,
  agent_id          TEXT NOT NULL,
  agent_version     INT  NOT NULL,                  -- 버전 핀. 에이전트가 바뀌어도 세션은 안 바뀐다
  environment_id    TEXT NOT NULL,
  environment_version INT NOT NULL,
  config_override   JSONB,                          -- 세션 단위 오버라이드
  status            TEXT NOT NULL
      CHECK (status IN ('idle','running','rescheduling','terminated')),
  stop_reason       TEXT,
  revision          BIGINT NOT NULL DEFAULT 0,      -- 이벤트 수용 CAS
  budget_cents      INT,                            -- NULL = 무제한
  spent_cents       INT  NOT NULL DEFAULT 0,
  usage             JSONB NOT NULL DEFAULT '{}',    -- 토큰 누적
  created_by        TEXT NOT NULL,
  created_at        TIMESTAMPTZ NOT NULL,
  updated_at        TIMESTAMPTZ NOT NULL,
  last_active_at    TIMESTAMPTZ,
  archived_at       TIMESTAMPTZ,
  deleted_at        TIMESTAMPTZ,
  PRIMARY KEY (workspace_id, id)
);
CREATE INDEX idx_sessions_ws_created ON sessions (workspace_id, created_at DESC, id);
CREATE INDEX idx_sessions_ws_status  ON sessions (workspace_id, status)
  WHERE status IN ('running','rescheduling');
CREATE INDEX idx_sessions_ws_agent   ON sessions (workspace_id, agent_id, created_at DESC);

CREATE TABLE session_resources (
  id            TEXT NOT NULL,
  workspace_id  TEXT NOT NULL,
  session_id    TEXT NOT NULL,
  kind          TEXT NOT NULL
      CHECK (kind IN ('file','github_repository','memory_store','env')),
  spec          JSONB NOT NULL,       -- 마운트 경로, 읽기전용 여부 등
  secret_ref    TEXT,                 -- credentials(id). 평문은 여기에 없다
  mount_path    TEXT,
  created_at    TIMESTAMPTZ NOT NULL,
  removed_at    TIMESTAMPTZ,
  PRIMARY KEY (workspace_id, id)
);
CREATE INDEX idx_session_resources ON session_resources (workspace_id, session_id)
  WHERE removed_at IS NULL;
```

> `agent_version`을 세션에 **핀**하는 것이 중요합니다. 운영자가 에이전트를 고치는 동안
> 진행 중인 세션의 행동이 바뀌면, 그 세션의 이벤트 로그를 재현할 수 없습니다.

### G5. 이벤트·실행 — 이 설계의 핵심

```sql
-- 승격된 정본 이벤트. seq = 모델이 본 순서.
CREATE TABLE session_events (
  workspace_id  TEXT   NOT NULL,
  session_id    TEXT   NOT NULL,
  seq           BIGINT NOT NULL,
  id            TEXT   NOT NULL,            -- evt_01H...
  thread_id     TEXT   NOT NULL,            -- lane. 1단계는 'primary'
  type          TEXT   NOT NULL,
  payload       JSONB  NOT NULL,
  generation    INT,                        -- 어느 fence에서 커밋됐나 (감사용)
  created_at    TIMESTAMPTZ NOT NULL,
  PRIMARY KEY (workspace_id, session_id, seq)
) PARTITION BY RANGE (created_at);

-- 중복 promote 방지. 크래시 복구가 이것에 의존한다.
CREATE UNIQUE INDEX idx_events_event_id ON session_events (workspace_id, session_id, id);
CREATE INDEX idx_events_thread ON session_events (workspace_id, session_id, thread_id, seq);
CREATE INDEX idx_events_type   ON session_events (workspace_id, session_id, type, seq);

-- seq 생성: 세션 단위 단조 증가. 시퀀스 객체가 아니라 MAX+1을 트랜잭션 안에서.
-- (시퀀스 객체는 롤백 시 구멍이 생기고, 우리는 구멍 없는 seq가 필요하다)
```

```sql
-- 아직 모델이 보지 않은 입력. 큐.
CREATE TABLE session_pending_events (
  workspace_id  TEXT   NOT NULL,
  session_id    TEXT   NOT NULL,
  pending_seq   BIGSERIAL,                  -- 큐 순서. 여기서는 구멍이 생겨도 무해하다
  id            TEXT   NOT NULL,
  thread_id     TEXT   NOT NULL,
  type          TEXT   NOT NULL,
  payload       JSONB  NOT NULL,
  enqueued_at   TIMESTAMPTZ NOT NULL,
  cancelled_at  TIMESTAMPTZ,                -- user.interrupt가 표시
  PRIMARY KEY (workspace_id, session_id, pending_seq)
);
CREATE UNIQUE INDEX idx_pending_event_id ON session_pending_events (workspace_id, session_id, id);
CREATE INDEX idx_pending_drain ON session_pending_events (workspace_id, session_id, thread_id, pending_seq)
  WHERE cancelled_at IS NULL;
```

```sql
-- 실행 권한. outbox + lease + fence. 이 테이블이 "누가 실행할 권리가 있는가"의 정답.
CREATE TABLE session_executions (
  id                      BIGSERIAL PRIMARY KEY,
  workspace_id            TEXT NOT NULL,
  session_id              TEXT NOT NULL,
  lane_id                 TEXT NOT NULL,     -- = thread_id. lane 안에서 FIFO
  execution_id            TEXT NOT NULL,     -- 이 lane의 첫 이벤트 id = 멱등키
  state                   TEXT NOT NULL
      CHECK (state IN ('queued','running','completed','failed','cancelled')),
  event_ids               TEXT[] NOT NULL,   -- 이 execution이 소비할 이벤트들
  generation              INT  NOT NULL DEFAULT 0,   -- claim마다 +1. fence의 핵심
  attempt_id              UUID,
  attempt_count           INT  NOT NULL DEFAULT 0,
  lease_owner             TEXT,              -- 워커 인스턴스 ID
  lease_expires_at        TIMESTAMPTZ,
  interrupt_requested_at  TIMESTAMPTZ,
  deadline_at             TIMESTAMPTZ,
  error                   JSONB,
  created_at              TIMESTAMPTZ NOT NULL,
  settled_at              TIMESTAMPTZ
);
CREATE UNIQUE INDEX idx_exec_idem ON session_executions (workspace_id, session_id, execution_id);
-- claim 쿼리를 받치는 부분 인덱스. 큐가 커져도 claim은 상수 시간에 가깝다.
CREATE INDEX idx_exec_claimable ON session_executions (created_at)
  WHERE state = 'queued';
CREATE INDEX idx_exec_reclaim   ON session_executions (lease_expires_at)
  WHERE state = 'running';
-- 한 lane에 running은 하나만. DB가 강제한다.
CREATE UNIQUE INDEX idx_exec_one_running ON session_executions (workspace_id, session_id, lane_id)
  WHERE state = 'running';
```

> 마지막 부분 유니크 인덱스가 **split-brain의 마지막 방어선**입니다. 애플리케이션 버그로
> 두 워커가 같은 lane을 running으로 만들려 하면 DB가 거부합니다.

```sql
-- 스트리밍 중간 상태. 영속 이벤트가 아니라 재연결 시 "진행 중" 복원용.
CREATE TABLE session_streams (
  workspace_id  TEXT NOT NULL,
  session_id    TEXT NOT NULL,
  thread_id     TEXT NOT NULL,
  stream_id     TEXT NOT NULL,
  kind          TEXT NOT NULL,       -- message | thinking | tool_input
  partial       TEXT NOT NULL DEFAULT '',
  updated_at    TIMESTAMPTZ NOT NULL,
  PRIMARY KEY (workspace_id, session_id, stream_id)
);
```

### G6. 자격증명 — S6

```sql
CREATE TABLE vaults (
  id            TEXT NOT NULL,
  workspace_id  TEXT NOT NULL,
  name          TEXT NOT NULL,
  document      JSONB NOT NULL DEFAULT '{}',
  version       INT  NOT NULL DEFAULT 1,
  created_at    TIMESTAMPTZ NOT NULL,
  archived_at   TIMESTAMPTZ,
  PRIMARY KEY (workspace_id, id)
);

CREATE TABLE credentials (
  id                TEXT NOT NULL,
  workspace_id      TEXT NOT NULL,
  vault_id          TEXT NOT NULL,
  kind              TEXT NOT NULL
      CHECK (kind IN ('bearer','basic','api_key_header','mcp_oauth','environment_variable')),
  -- 주입 대상 식별
  match_hosts       TEXT[] NOT NULL DEFAULT '{}',   -- egress 프록시가 호스트로 매칭
  mcp_server_name   TEXT,
  header_name       TEXT,
  -- 비밀
  ciphertext        BYTEA NOT NULL,                 -- AES-256-GCM
  nonce             BYTEA NOT NULL,
  key_version       INT  NOT NULL,                  -- 키 로테이션용
  -- OAuth
  expires_at        TIMESTAMPTZ,
  refresh_failed_at TIMESTAMPTZ,
  refresh_error     TEXT,
  -- 메타
  created_by        TEXT NOT NULL,
  created_at        TIMESTAMPTZ NOT NULL,
  rotated_at        TIMESTAMPTZ,
  archived_at       TIMESTAMPTZ,
  PRIMARY KEY (workspace_id, id)
);
CREATE INDEX idx_credentials_vault ON credentials (workspace_id, vault_id) WHERE archived_at IS NULL;
-- egress 프록시의 핫 경로 조회: (워크스페이스, 호스트) → 자격증명
CREATE INDEX idx_credentials_hosts ON credentials USING GIN (match_hosts)
  WHERE archived_at IS NULL;

-- 자격증명이 "언제 누구에게 쓰였는가". 평문은 없다.
CREATE TABLE credential_events (
  id            BIGSERIAL PRIMARY KEY,
  workspace_id  TEXT NOT NULL,
  credential_id TEXT NOT NULL,
  session_id    TEXT,
  action        TEXT NOT NULL,     -- injected | refreshed | refresh_failed | rotated | denied
  host          TEXT,
  generation    INT,               -- 어느 fence에서
  created_at    TIMESTAMPTZ NOT NULL
);
CREATE INDEX idx_cred_events_session ON credential_events (workspace_id, session_id, created_at);
```

> `credential_events`가 감사 요구("어떤 자격증명이 쓰였는지")를 직접 만족시킵니다.
> egress 프록시가 주입할 때마다 한 줄 씁니다. 세션별로 집계하면 "이 세션이 어떤 시스템에
> 몇 번 접근했는가"가 나옵니다.

### G7. 메모리

```sql
CREATE TABLE memory_stores (
  id            TEXT NOT NULL,
  workspace_id  TEXT NOT NULL,
  name          TEXT NOT NULL,
  slug          TEXT NOT NULL,          -- /mnt/memory/<slug>
  document      JSONB NOT NULL DEFAULT '{}',
  revision      BIGINT NOT NULL DEFAULT 0,
  created_at    TIMESTAMPTZ NOT NULL,
  archived_at   TIMESTAMPTZ,
  PRIMARY KEY (workspace_id, id)
);
CREATE UNIQUE INDEX idx_memory_stores_slug ON memory_stores (workspace_id, slug)
  WHERE archived_at IS NULL;

CREATE TABLE memories (
  id              TEXT NOT NULL,
  workspace_id    TEXT NOT NULL,
  store_id        TEXT NOT NULL,
  path            TEXT NOT NULL,                -- 'projects/alpha/notes.md'
  content         TEXT NOT NULL,                -- 상한 100KB. 그보다 크면 거부
  content_sha256  TEXT NOT NULL,                -- CAS precondition
  revision        BIGINT NOT NULL DEFAULT 0,
  created_at      TIMESTAMPTZ NOT NULL,
  updated_at      TIMESTAMPTZ NOT NULL,
  deleted_at      TIMESTAMPTZ,
  PRIMARY KEY (workspace_id, id)
);
-- 경로 충돌 방지. 공식 계약의 memory_path_conflict_error를 DB가 보장한다.
CREATE UNIQUE INDEX idx_memories_path ON memories (workspace_id, store_id, path)
  WHERE deleted_at IS NULL;

CREATE TABLE memory_versions (
  id              TEXT NOT NULL,
  workspace_id    TEXT NOT NULL,
  store_id        TEXT NOT NULL,
  memory_id       TEXT NOT NULL,
  path            TEXT NOT NULL,
  content         TEXT,                        -- redact되면 NULL
  content_sha256  TEXT NOT NULL,
  author          TEXT NOT NULL,               -- user:... | session:... | dream:...
  redacted_at     TIMESTAMPTZ,
  redacted_by     TEXT,
  created_at      TIMESTAMPTZ NOT NULL,
  PRIMARY KEY (workspace_id, id)
);
CREATE INDEX idx_memory_versions ON memory_versions (workspace_id, memory_id, created_at DESC);
```

> **content를 DB에 두는 이유**: 메모리 하나는 100KB 이하이고, 진실의 원천이 하나여야
> 합니다. 레퍼런스는 오브젝트 스토어를 bytes-of-truth로 두고 DB를 인덱스로 썼는데, 그
> 결과 "에이전트가 FUSE로 직접 쓴 것"을 이벤트 큐로 reconcile해야 하고 그 사이에 gap이
> 생깁니다. AWP는 SQL이 진실이고 샌드박스에는 **사본**을 마운트해 턴 종료에 CAS로
> 되돌립니다 ([02](02-architecture.md) §9).

### G10. 거버넌스

```sql
CREATE TABLE approval_policies (
  id                 TEXT PRIMARY KEY,
  workspace_id       TEXT NOT NULL,
  agent_id           TEXT,                     -- NULL = 워크스페이스 전체
  tool_pattern       TEXT NOT NULL,            -- 'bash' | 'mcp__github__*' | '*'
  required_role      TEXT NOT NULL,
  required_approvals INT  NOT NULL DEFAULT 1,  -- 2 = 4-eyes
  self_approval      BOOLEAN NOT NULL DEFAULT FALSE,
  notify             JSONB NOT NULL DEFAULT '{}',
  expires_after_s    INT,
  priority           INT  NOT NULL DEFAULT 0,  -- 높은 것이 이긴다
  created_at         TIMESTAMPTZ NOT NULL
);
CREATE INDEX idx_approval_policies ON approval_policies (workspace_id, priority DESC);

CREATE TABLE approvals (
  id             TEXT PRIMARY KEY,
  workspace_id   TEXT NOT NULL,
  session_id     TEXT NOT NULL,
  event_id       TEXT NOT NULL,            -- 해당 agent.tool_use 이벤트
  tool_call_id   TEXT NOT NULL,
  tool_name      TEXT NOT NULL,
  tool_kind      TEXT NOT NULL,            -- builtin | mcp | custom | delegation
  input_summary  JSONB NOT NULL,           -- 전체 입력이 아니라 요약(비밀 유출 방지)
  policy_id      TEXT,
  state          TEXT NOT NULL CHECK (state IN ('pending','approved','denied','expired')),
  decided_by     TEXT[] NOT NULL DEFAULT '{}',
  decided_at     TIMESTAMPTZ,
  reason         TEXT,
  requested_at   TIMESTAMPTZ NOT NULL,
  expires_at     TIMESTAMPTZ
);
CREATE UNIQUE INDEX idx_approvals_call ON approvals (workspace_id, session_id, tool_call_id);
CREATE INDEX idx_approvals_inbox ON approvals (workspace_id, requested_at DESC)
  WHERE state = 'pending';

-- append-only. S7
CREATE TABLE audit_log (
  id            BIGSERIAL,
  workspace_id  TEXT NOT NULL,
  actor_type    TEXT NOT NULL,     -- user | api_key | system | agent
  actor_id      TEXT NOT NULL,
  action        TEXT NOT NULL,     -- agent.create | session.interrupt | approval.decide | credential.inject ...
  resource_type TEXT NOT NULL,
  resource_id   TEXT NOT NULL,
  session_id    TEXT,
  detail        JSONB NOT NULL DEFAULT '{}',
  request_id    TEXT,
  ip            INET,
  created_at    TIMESTAMPTZ NOT NULL,
  PRIMARY KEY (id, created_at)
) PARTITION BY RANGE (created_at);
CREATE INDEX idx_audit_ws_time    ON audit_log (workspace_id, created_at DESC);
CREATE INDEX idx_audit_session    ON audit_log (workspace_id, session_id, created_at);
CREATE INDEX idx_audit_actor      ON audit_log (workspace_id, actor_id, created_at DESC);

-- DB 레벨 강제: 애플리케이션 역할은 INSERT와 SELECT만 할 수 있다.
REVOKE UPDATE, DELETE, TRUNCATE ON audit_log FROM awp_app;
GRANT  INSERT, SELECT            ON audit_log TO   awp_app;
```

```sql
CREATE TABLE budgets (
  id             TEXT PRIMARY KEY,
  workspace_id   TEXT NOT NULL,
  scope          TEXT NOT NULL CHECK (scope IN ('workspace','agent','user')),
  scope_id       TEXT,
  period         TEXT NOT NULL CHECK (period IN ('daily','monthly','total')),
  limit_cents    INT  NOT NULL,
  session_default_cents INT,              -- 이 스코프의 세션 기본 상한
  hard           BOOLEAN NOT NULL DEFAULT TRUE,
  created_at     TIMESTAMPTZ NOT NULL
);
CREATE UNIQUE INDEX idx_budgets_scope ON budgets (workspace_id, scope, scope_id, period);

CREATE TABLE usage_events (
  id            BIGSERIAL,
  workspace_id  TEXT NOT NULL,
  session_id    TEXT NOT NULL,
  thread_id     TEXT,
  model_card_id TEXT NOT NULL,
  wire_model    TEXT NOT NULL,
  input_tokens          BIGINT NOT NULL DEFAULT 0,
  output_tokens         BIGINT NOT NULL DEFAULT 0,
  cache_read_tokens     BIGINT NOT NULL DEFAULT 0,
  cache_write_tokens    BIGINT NOT NULL DEFAULT 0,
  list_cost_cents       NUMERIC(12,4) NOT NULL DEFAULT 0,
  sandbox_seconds       INT NOT NULL DEFAULT 0,
  created_at    TIMESTAMPTZ NOT NULL,
  PRIMARY KEY (id, created_at)
) PARTITION BY RANGE (created_at);
CREATE INDEX idx_usage_ws_time  ON usage_events (workspace_id, created_at DESC);
CREATE INDEX idx_usage_session  ON usage_events (workspace_id, session_id);
```

### G11. 인프라 좌표

```sql
-- 샌드박스 인스턴스 하나의 수명. 티어 W는 워커 프로세스 안의 Wasmtime Store,
-- 티어 P는 confine된 워크스페이스. 어느 쪽이든 k8s Pod가 아니다 ([07](07-sandbox.md)).
CREATE TABLE sandbox_instances (
  id              TEXT PRIMARY KEY,
  workspace_id    TEXT NOT NULL,
  session_id      TEXT NOT NULL,
  tier            TEXT NOT NULL CHECK (tier IN ('wasm','process','vm')),
  host_worker_id  TEXT,                        -- worker_instances(id). 어느 워커가 들고 있나
  workspace_path  TEXT,                        -- 티어 P의 confine 루트
  state           TEXT NOT NULL
      CHECK (state IN ('pending','provisioning','ready','active','idle','terminating','gone')),
  -- 보고된 사실. 추측이 아니다 (D6)
  sandbox_enforcement TEXT NOT NULL
      CHECK (sandbox_enforcement IN ('enforced','partial','unsupported')),
  sandbox_enforcement_reason TEXT,             -- "Landlock ABI 2: network rules unavailable"
  egress_enforcement  TEXT NOT NULL
      CHECK (egress_enforcement IN ('enforced','advisory','unsupported')),
  snapshot_key    TEXT,                        -- 오브젝트 스토어 키
  last_activity_at TIMESTAMPTZ,
  created_at      TIMESTAMPTZ NOT NULL,
  terminated_at   TIMESTAMPTZ
);
CREATE INDEX idx_sandbox_session ON sandbox_instances (workspace_id, session_id);
CREATE INDEX idx_sandbox_reap    ON sandbox_instances (last_activity_at)
  WHERE state IN ('ready','active','idle');

-- 샌드박스/워크스페이스 자원의 세대. 원자적 publish를 보장한다.
CREATE TABLE runtime_fences (
  scope_key     TEXT PRIMARY KEY,      -- ws:sess:lane
  generation    INT  NOT NULL,
  owner_id      TEXT NOT NULL,
  token         UUID NOT NULL,
  expires_at    TIMESTAMPTZ NOT NULL,
  updated_at    TIMESTAMPTZ NOT NULL
);

-- 종료에 실패한 자원. 스케줄러가 정리한다.
CREATE TABLE runtime_orphans (
  id            BIGSERIAL PRIMARY KEY,
  workspace_id  TEXT NOT NULL,
  kind          TEXT NOT NULL,         -- pod | pvc | snapshot
  reference     TEXT NOT NULL,
  reason        TEXT NOT NULL,
  detected_at   TIMESTAMPTZ NOT NULL,
  cleaned_at    TIMESTAMPTZ
);

CREATE TABLE worker_instances (
  id              TEXT PRIMARY KEY,    -- pod 이름
  kind            TEXT NOT NULL,       -- runtime_worker | scheduler
  version         TEXT NOT NULL,
  started_at      TIMESTAMPTZ NOT NULL,
  heartbeat_at    TIMESTAMPTZ NOT NULL,
  draining        BOOLEAN NOT NULL DEFAULT FALSE
);
```

---

## 4. 인덱스 설계 — 커서와 정렬을 맞춘다

커서 페이지네이션은 **인덱스 순서와 ORDER BY가 정확히 같아야** 합니다. 다르면 PostgreSQL이
전체 정렬을 하고, 테이블이 커지면 그 순간 느려집니다.

| 쿼리 | ORDER BY | 받치는 인덱스 |
|---|---|---|
| 에이전트 목록 | `(created_at, id)` | `idx_agents_ws_created_id` |
| 세션 목록 | `(created_at DESC, id)` | `idx_sessions_ws_created` |
| 세션 이벤트 | `(seq)` | PK `(workspace_id, session_id, seq)` |
| 승인 인박스 | `(requested_at DESC)` | `idx_approvals_inbox` (부분) |
| execution claim | `(created_at)` | `idx_exec_claimable` (부분) |
| lease 회수 | `(lease_expires_at)` | `idx_exec_reclaim` (부분) |
| egress 자격증명 조회 | 호스트 배열 포함 | `idx_credentials_hosts` (GIN) |

**부분 인덱스(`WHERE`)를 적극 씁니다.** `session_executions`는 완료된 행이 계속 쌓이지만
claim 쿼리는 `state='queued'`만 봅니다. 부분 인덱스면 인덱스 크기가 큐 길이에 비례합니다.

---

## 5. 동시성 제어 정리

| 상황 | 기법 | 위치 |
|---|---|---|
| 리소스 수정 충돌 | `version` CAS + 원자적 2문장 배치 | [03](03-layers.md) §6 |
| 이벤트 수용 충돌 | `sessions.revision` CAS, 실패 시 최대 3회 재시도 | [02](02-architecture.md) §3 |
| execution claim 경합 | `FOR UPDATE SKIP LOCKED` | §3 G5 |
| lane 중복 실행 | 부분 유니크 인덱스 `idx_exec_one_running` | §3 G5 |
| 중복 이벤트 | `idx_events_event_id` 유니크 | §3 G5 |
| 중복 promote | 같은 인덱스 + `ON CONFLICT DO NOTHING` | §3 G5 |
| 메모리 경로 충돌 | 부분 유니크 `idx_memories_path` | §3 G7 |
| 메모리 내용 충돌 | `content_sha256` precondition + `revision` CAS | §3 G7 |
| 멱등 요청 | `Idempotency-Key` → 결정적 event id | [04](04-api.md) §2.4 |
| 스케줄러 중복 실행 | `pg_advisory_lock` (리더 선출) | `schema_locks` |

**트랜잭션 격리 수준은 기본값(`READ COMMITTED`)을 씁니다.** 모든 경합을 명시적 CAS와
유니크 인덱스로 처리하므로 `SERIALIZABLE`이 필요 없고, `SERIALIZABLE`로 올리면
직렬화 실패 재시도를 전역에 깔아야 합니다.

---

## 6. 파티셔닝과 보존

```sql
-- 월 단위. 스케줄러가 다음 달 파티션을 미리 만든다.
CREATE TABLE session_events_2026_10 PARTITION OF session_events
  FOR VALUES FROM ('2026-10-01') TO ('2026-11-01');
```

| 테이블 | 파티션 | 기본 보존 | 삭제 방법 |
|---|---|---|---|
| `session_events` | 월 | 워크스페이스 설정 (기본 365일) | `DETACH PARTITION` → 콜드 스토리지 → `DROP` |
| `audit_log` | 월 | **최소 3년** (변경 불가) | 콜드 스토리지로 아카이브. 삭제는 수동 승인 |
| `usage_events` | 월 | 25개월 (전년 동월 비교용) | `DETACH` → 집계만 남기고 `DROP` |
| `memory_versions` | — | 메모리당 최신 1개는 항상 유지 | 스케줄러가 `pruneOlderThan` |
| `credential_events` | 월 | 3년 (감사) | audit_log와 동일 |
| `session_streams` | — | 세션 종료 시 삭제 | 스케줄러 GC |

**보존 정책은 워크스페이스가 정합니다**(사내 부서별로 규정이 다릅니다). 단 `audit_log`는
플랫폼이 정하고 부서가 줄일 수 없습니다.

---

## 7. 암호화

| 대상 | 방식 |
|---|---|
| `credentials.ciphertext` | AES-256-GCM. 키는 루트 시크릿에서 `HKDF(root, "credential", key_version)` 파생 |
| `session_resources.secret_ref` | 평문 없음. `credentials(id)` 참조만 |
| `environment_work` 워커 시크릿 | 같은 방식, 별 파생 레이블 |
| 전송 구간 | 모든 DB 연결 `sslmode=verify-full` |
| 저장 매체 | 노드 디스크 암호화 (k8s StorageClass) |
| 백업 | 백업 자체도 암호화. 루트 시크릿은 백업에 **포함하지 않는다** |

키 로테이션: `key_version`을 올려 새 자격증명은 새 키로 쓰고, 기존 것은 읽을 때 옛 키로
복호화합니다. 백그라운드 작업이 점진적으로 재암호화합니다.

---

## 8. 마이그레이션 운영

```
packages/ma_schema/
├── alembic.ini
├── env.py
└── versions/
    ├── 0001_initial.py              # G1~G5 (MVP에 필요한 최소)
    ├── 0002_credentials_memory.py   # G6, G7
    ├── 0003_governance.py           # G10
    ├── 0004_infra_coords.py         # G11
    └── 0005_partitions.py           # 파티션 + GRANT/REVOKE
```

규칙:

1. **패키지 안에 `CREATE TABLE`을 쓰지 않습니다.** CI가 검사합니다 ([03](03-layers.md) §5.2).
2. 모든 마이그레이션은 **앞으로만** 갑니다. `downgrade`는 작성하되 프로덕션에서 실행하지
   않습니다(데이터 손실을 되돌릴 수 없으므로).
3. **배포는 2단계**입니다. (a) 스키마를 하위 호환으로 먼저 올린다, (b) 코드를 올린다.
   컬럼 삭제는 코드가 그것을 안 쓰게 된 다음 릴리스에서.
4. 마이그레이션은 **제어 평면 시작 시 자동 실행하지 않습니다.** 별도 Job
   (`helm hook: pre-upgrade`)으로 돌립니다. 여러 Pod가 동시에 마이그레이션하면 깨집니다.
5. `pg_advisory_lock`으로 마이그레이션 Job 자체도 단일 실행을 보장합니다.

---

## 9. 멀티테넌시 — 지금은 한 DB, 나중에 샤딩

### 1단계: 행 수준 격리

단일 PostgreSQL + 모든 테이블의 `workspace_id` 필터. `WorkspaceAppRegistry`가 앱 그래프를
워크스페이스에 핀하므로 애플리케이션 레이어에서 섞이지 않습니다.

추가 안전장치로 **Row Level Security를 켭니다**:

```sql
ALTER TABLE sessions ENABLE ROW LEVEL SECURITY;
CREATE POLICY sessions_ws ON sessions
  USING (workspace_id = current_setting('awp.workspace_id', true));
```

애플리케이션은 연결마다 `SET LOCAL awp.workspace_id = '...'`을 설정합니다. 코드 버그로
필터를 빼먹어도 DB가 막습니다. (워커의 claim 쿼리처럼 워크스페이스 횡단이 필요한 경로는
별도 DB 역할 `awp_worker`로 RLS를 우회합니다.)

### 2단계: 샤딩이 필요해지면

샤딩은 **`SqlClient` 구성 시점에 끝내는 것**이 핵심입니다. 도메인은 샤드를 모릅니다.

```
요청 → 인증 → workspace_id 확정
            → ShardDirectory.resolve(workspace_id) → DSN
            → SqlClient(engine) 생성
            → build_sql_app(workspace_id, sql) → 앱 그래프
            → 유스케이스는 workspace_id 컬럼 필터만 안다
```

디렉터리 테이블(`workspace_shard`)은 컨트롤 DB에 두고, 샤딩은 sticky(INSERT only)이므로
프로세스 수명 동안 캐시해도 안전합니다.

---

## 10. 다음 문서

이 DB와 프로세스들이 어디서 돌아가는가 → [08. 인프라 · 인스턴스](08-infrastructure.md)
