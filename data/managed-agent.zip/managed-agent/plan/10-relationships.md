# 10. 관계 · 트레이서빌리티

> 다이어그램: [`svg/20-traceability.svg`](svg/20-traceability.svg)

이 문서는 새로운 설계를 추가하지 않습니다. 01~09의 조각이 **어디서 맞물리는지**만 보여줍니다.

---

## 1. 개념 → API → 레이어 → 패키지 → 테이블 → 인스턴스

핵심 개념 하나를 고를 때, 실제로 건드려야 하는 것들의 전체 목록입니다.

| 개념 | 내부 API | 유스케이스 (L4) | Store (L3) | 테이블 | 실행 인스턴스 |
|---|---|---|---|---|---|
| **Workspace** | `/api/v1/workspaces` | `WorkspacesUseCases` | `WorkspaceStore` `MemberStore` | `workspaces` `workspace_members` `workspace_invitations` | control-plane + **네임스페이스 `awp-runtime-<slug>`** |
| **Agent** | `/api/v1/agents` | `AgentsUseCases` | `AgentStore` | `agents` `agent_versions` | control-plane |
| **Model card** | `/api/v1/models` | `ModelCardsUseCases` | `ModelCardStore` | `model_cards` | control-plane → 워커가 읽어 provider 어댑터 선택 |
| **Environment** | `/api/v1/environments` | `EnvironmentsUseCases` | `EnvironmentStore` | `environments` `environment_versions` | control-plane + 워커가 **능력 프로브** |
| **Session** | `/api/v1/sessions` | `SessionsUseCases` | `SessionStore` `SessionResourceStore` | `sessions` `session_resources` `session_memory_stores` | control-plane (생성) + runtime-worker (실행) |
| **Event** | `POST .../events`, `GET .../events/stream` | `SessionEventsUseCases` | `SessionEventStore` `PendingEventStore` | `session_events` `session_pending_events` `session_streams` | control-plane (수용·SSE) + 워커 (promote·append) |
| **Execution** | (없음 — 내부) | `SessionExecutionUseCases` | `ExecutionStore` | `session_executions` `runtime_fences` | runtime-worker (claim·fence) |
| **Tool call** | (이벤트로 노출) | `ToolRegistry` + 하네스 훅 | — | `session_events` | 워커 (호스트 툴) / 샌드박스 (`bash`) |
| **Vault / Credential** | `/api/v1/vaults/...` | `VaultsUseCases` `CredentialsUseCases` | `VaultStore` `CredentialStore` | `vaults` `credentials` `credential_events` | control-plane (보관) + **egress-proxy (주입)** |
| **Memory store** | `/api/v1/memory_stores/...` | `MemoryUseCases` | `MemoryStoreStore` `MemoryDocumentStore` | `memory_stores` `memories` `memory_versions` | control-plane + 워커 (마운트·동기화) |
| **Approval** | `/api/v1/approvals` | `ApprovalsUseCases` | `ApprovalStore` `ApprovalPolicyStore` | `approvals` `approval_policies` | control-plane (결정) + 워커 (pending 적재·재개) |
| **Budget** | `/api/v1/budgets` `/api/v1/usage` | `BudgetUseCases` | `BudgetStore` `UsageStore` | `budgets` `usage_events` `quota_counters` | 워커 (적립) + control-plane (조회) + **ResourceQuota** |
| **Audit entry** | `/api/v1/audit` | `AuditUseCases` | `AuditStore` | `audit_log` | 전 인스턴스 (append) |
| **Sandbox** | `/api/v1/environments/{id}/capabilities` | `SandboxPort` | — | `sandbox_instances` `runtime_orphans` | **runtime-worker 내부** (Wasm 인스턴스 / confine된 subprocess) |
| **Deployment** (2단계) | `/api/v1/deployments` | `DeploymentsUseCases` | `DeploymentStore` `DeploymentRunStore` | `deployments` `deployment_runs` `schedules` | scheduler (발화) + 워커 (실행) |

---

## 2. 한 요청의 전체 경로

`POST /api/v1/sessions/{id}/events` 하나가 모든 레이어를 지나는 모습입니다.

```
Console
  │ POST /api/v1/sessions/sess_7/events  { events: [user.message], expected_revision: 12 }
  │ Idempotency-Key: 9f3c...
  ▼
apps/control_plane ── http.py 미들웨어 체인
  │ ① request_metrics
  │ ② error_envelope
  │ ③ request_id
  │ ⑤ auth           → principal(user_42, role=operator), workspace_id=wrkspc_법무
  │ ⑥ rate_limit     → 세션 버킷 60/min
  │ ⑦ workspace_app  → WorkspaceAppRegistry[wrkspc_법무] → App
  ▼
ma_api.internal.routes.sessions          ← L5a
  │ pydantic ingress 스키마 (extra="forbid")
  │ wire → application 매퍼
  ▼
ma_application.session_events.SendSessionEvents   ← L4
  │ 역할 검사 (operator 이상)
  │ 멱등키 → 결정적 event id = sha256(key + index)
  │ 예산 확인 (BudgetPort)
  │ 감사 기록 (AuditPort)
  ▼
ma_store.SessionEventStore.append_with_outbox     ← L3 Protocol
  ▼
ma_store_sql.SessionEventStore                    ← L2b  한 트랜잭션
  │ UPDATE sessions SET revision=revision+1 WHERE revision=12   ← CAS
  │ INSERT session_pending_events … ON CONFLICT DO NOTHING
  │ UPDATE session_executions SET interrupt_requested_at … (해당 시)
  │ INSERT session_executions (state='queued') ON CONFLICT DO NOTHING
  ▼
PostgreSQL  (awp-data)
  │
  ├──▶ 202 accepted { revision: 13 }  ──────────────▶ Console
  └──▶ LISTEN/NOTIFY ──▶ control-plane SSE ──▶ system.user_message_pending ──▶ Console

                        ╌╌╌ 여기서 요청은 끝났다. 실행은 비동기 ╌╌╌

KEDA  (queued 수 증가 감지)
  ▼
apps/runtime_worker  (awp-runtime-법무)
  │ ExecutionStore.claim(owner=worker-3, ttl=90s)  FOR UPDATE SKIP LOCKED
  │ → fence{generation: 5, attempt_id, expires_at}
  │ 하트비트 30s
  ▼
ma_harness 턴 루프                                  ← [06](06-harness-and-model.md) §4.1
  │ ① pre_step 훅     → pending promote → session_events (seq 부여)
  │                     SSE: system.user_message_promoted
  │ ② 프롬프트 조립    → 시스템 섹션 + 툴 스키마 (정렬 고정 — 캐시 prefix)
  │ ③ derive_messages(events)
  │ ④ 요청 동결
  │ ⑤ ModelPort.stream → ma_model_deepseek → egress-proxy → api.deepseek.com
  │      (모델 키는 프록시가 주입. 워커에 없다)
  │      SSE: agent.message_chunk… → agent.tool_use
  │ ⑥ pre_execute 훅  → 권한 정책: bash = always_ask
  │                   → ApprovalPort.request() → approvals INSERT
  │                   → 턴 중단, pending_confirmations 적재
  │ ⑧ turn_stopping   → 메모리 동기화 · usage_events 적립
  ▼
session.status_idle { stop_reason: "requires_action" }
  │ ExecutionStore.settle(completed)
  └──▶ SSE ──▶ Console: "승인 대기"
       └──▶ 알림(Slack/메일) ──▶ 승인 권한자

       ╌╌╌ 사람이 승인하면 POST /api/v1/approvals/{id} → 같은 경로를 다시 ╌╌╌
```

**관찰 1**: 제어 평면은 **수용만** 하고 실행을 기다리지 않습니다. 202입니다.
**관찰 2**: 자격증명(모델 키 포함)은 워커를 지나지 않습니다.
**관찰 3**: 승인 대기는 에러가 아니라 정상 종료(`idle`)입니다.

---

## 3. 변경 영향도 — 체크리스트

### 새 리소스를 추가한다 (예: `Playbook`)

```
□ ma_domain/playbooks.py            frozen dataclass + 값 객체
□ ma_store/playbooks.py             Protocol + 입출력 + union 결과
□ ma_store_memory/playbooks.py      dict 구현
□ ma_store_sql/playbooks.py         SQL 구현 (CAS 2문장 배치)
□ ma_schema/versions/00NN_*.py      playbooks + playbook_versions 테이블
□ ma_application/playbooks.py       유스케이스 + Port 선언
□ ma_platform/modules/playbooks.py  PortToken + AppModule (requires/provides)
□ ma_platform/sql.py                StoreBundle에 추가 + provide()
□ ma_api/internal/schemas/…         pydantic ingress/egress
□ ma_api/internal/mappers/…         wire ↔ application
□ ma_api/internal/routes/…          라우터
□ ma_api/internal/__init__.py        mount
□ tests/contract/test_playbook_store.py   계약 테스트 (memory + sql)
□ tests/unit/…                      유스케이스 단위
□ web/console/…                     UI
□ (2단계) ma_api/compat/…           공식 shape가 있을 때만
```

**14~16개 파일. 전부 예측 가능한 위치입니다.** 이것이 레이어를 가른 대가로 얻는 것입니다.

### 새 모델/provider를 추가한다

```
□ packages/ma_model_<provider>/     ModelPort 구현. ModelStreamEvent로 정규화
□ ma_domain/models.py               ProviderKind에 값 추가
□ tests/contract/test_model_port.py 녹음된 SSE 픽스처로 계약 테스트
□ model_cards 행 INSERT             ← 운영. 코드 변경 아님
```

**모델 자체를 바꾸는 것은 코드 변경이 0입니다** — `model_cards` 행을 고치거나 새 카드를
만들고 에이전트의 핸들을 바꿉니다 (D12).

### 새 샌드박스 티어를 추가한다

```
□ packages/ma_sandbox_<tier>/       SandboxProvider 구현 + enforcement 보고
□ ma_sandbox/ports.py               SandboxTier에 값 추가
□ tools/probe_capabilities.py       프로브 추가
□ environments.config.tier          CHECK 제약에 값 추가 (마이그레이션)
□ tests/contract/test_sandbox_port.py
□ 08-infrastructure.md §4           Pod 보안 요구사항 문서화
```

### 새 이벤트 타입을 추가한다

```
□ ma_domain/events.py               타입 + payload dataclass
□ ma_api/internal/schemas/events.py SSE 직렬화
□ derive_messages()                 모델 히스토리에 들어가는가? (대부분 아니다)
□ web/console 리듀서                 렌더링
□ 04-api.md §4.2                    표에 추가 + 단계 표시
```

> **`derive_messages()`를 반드시 검토하십시오.** 새 이벤트가 모델 히스토리에 들어가면
> 프롬프트가 바뀌고 캐시가 전부 미스됩니다. 기본값은 "들어가지 않는다"입니다.

### DB 컬럼을 삭제한다

```
릴리스 N   : 코드가 그 컬럼을 읽지 않게 한다. 스키마는 그대로
릴리스 N+1 : 마이그레이션으로 컬럼 삭제
```

한 릴리스에 둘을 같이 하면 롤백이 불가능해집니다 ([05](05-database.md) §8).

---

## 4. 설계 결정 사이의 의존 관계

결정들은 독립적이지 않습니다. 하나를 뒤집으면 따라 무너지는 것들이 있습니다.

```
D3 (실행 권한 = DB)
 ├─▶ D4 (이중 테이블)        : promote 시점이 claim 안이어야 seq가 모델 순서가 된다
 ├─▶ 크래시 복구 = 재claim    : 별도 복구 코드가 필요 없는 이유
 ├─▶ 워커 scale-to-zero      : 권한이 프로세스에 없으니 0으로 내려도 안전
 └─▶ D13 (워커 내부 샌드박스) : 워커가 cattle이라 샌드박스도 cattle일 수 있다

D13 (커널 안 건드리는 2티어)
 ├─▶ k8s API 호출 제거        : 워커 RBAC가 거의 비어 있다
 ├─▶ D7 재배치               : 부서 격리가 샌드박스 ns → 워커 ns로 이동
 ├─▶ bwrap --unshare-net 필수 : 샌드박스가 워커 netns를 공유하므로
 └─▶ D6이 더 중요해진다       : 티어 P 가용성이 커널·CRI 설정에 달려 있다

D12 (모델은 설정)
 ├─▶ model_cards가 요금을 선언 : 예산 계산이 코드가 아니라 데이터
 ├─▶ D12b (캐시·off-peak)     : 배수 자체도 카드가 선언한다
 └─▶ ModelPort 중립 어휘       : 하네스가 provider를 모른다

D5 (자격증명 샌드박스 밖)
 ├─▶ egress-proxy가 단일 통로  : 그래서 프록시 다운 = 세션 정체가 올바른 동작
 ├─▶ 모델 키도 워커 밖         : 같은 논리를 모델 호출에 적용
 └─▶ credential_events         : 감사 요구를 직접 만족시킨다

D8 (승인 = 권한 정책의 귀결)
 ├─▶ ToolRegistry.kind        : 이름 매칭으로 stop_reason을 정하지 않는다
 ├─▶ ToolGrant                : 승인 재개 시 executor를 되살리는 정확한 수단
 └─▶ fail-closed              : unavailable은 게이트를 열지 않는다

D1 (세대 분기 없음) ─▶ D2 (스키마 단일 출처) ─▶ 패키지 173 → 22 ([09](09-codebase.md) §9)
```

### 뒤집으면 비싼 결정 vs 싼 결정

| 결정 | 뒤집는 비용 | 이유 |
|---|---|---|
| D3 실행 권한 | **매우 높음** | 세션·이벤트·워커·복구가 전부 여기 걸려 있다 |
| D4 이중 테이블 | **높음** | 마이그레이션 + 순서 불변식 재검증 |
| D2 스키마 단일 출처 | 높음 | 분산되면 다시 모으기 어렵다 |
| D5 자격증명 격리 | 높음 | 보안 모델 전체 |
| D13 샌드박스 티어 | **낮음** | `SandboxPort` 뒤에 있다. 티어 V 추가가 설계에 없는 일이 아니다 |
| D12 모델 선택 | **매우 낮음** | 그게 이 결정의 목적이다 |
| D9 공식 lane | 낮음 | 지금 분리해 뒀으니 켜는 것은 추가다 |
| D11 하네스 선택 | 낮음 | `Harness` Protocol 뒤에 있다 |

**가장 먼저 검증해야 하는 것은 D3·D4입니다.** 뒤집기 비싸고, 둘 다 테스트로 검증
가능합니다 ([09](09-codebase.md) §6의 `test_two_workers_cannot_claim_same_lane`,
`test_expired_lease_is_reclaimable`).

---

## 5. 로드맵

### Phase 0 — 뼈대와 가정 검증 (3~4주)

가장 비싼 결정을 **먼저** 검증합니다. UI는 나중입니다.

| | 산출물 | 검증하는 가정 |
|---|---|---|
| W1 | 모노레포 + CI(아키텍처 검사부터) + compose 개발 환경 | — |
| W1 | **dsh 스파이크**: `deepseek-harness-sdk`로 V4.1-Flash 거동·비용 실측 | [06](06-harness-and-model.md) §3.5 |
| W2 | `ma_domain` + `ma_store` + 양쪽 구현 + **계약 테스트** | 런타임 이식성 |
| W2 | `ma_schema` 0001 (G1~G5) | D2 |
| W3 | `ExecutionStore` + claim/fence + **크래시 주입 테스트** | **D3 · D4** ★ |
| W3 | `ma_sandbox_wasm` 최소 (호스트 툴 5개 + `run_code`) | **D13** ★ |
| W4 | `ma_harness` 최소 루프 + `ma_model_deepseek` | D11 · D12 |
| W4 | 에이전트/세션/이벤트 CRUD + SSE | — |

**Phase 0 종료 조건**: 턴 중간에 워커를 `kill -9`해도 이벤트 유실 0 · 중복 커밋 0으로
다음 워커가 이어받는 것을 테스트로 보여준다.

### Phase 1 — MVP (6~8주)

| | 산출물 |
|---|---|
| 툴 | 내장 8개 (티어 P 포함) + 출력 spill |
| 보안 | Vault + `ma_egress` + credential_events + **보안 테스트 스위트** |
| 거버넌스 | 승인 정책·인박스·감사·예산 |
| 메모리 | 메모리 스토어 + 마운트 + 턴 종료 동기화 |
| 파일 | 업로드·마운트·산출물 다운로드 |
| Console | 세션 목록/상세, 에이전트 편집기, 승인 인박스, 감사 뷰, 비용 대시보드 |
| 인프라 | helm 차트 + KEDA + NetworkPolicy + Argo CD + 관측 4개 대시보드 |
| 운영 | `probe_capabilities` + `enforcement` 알람 |

**Phase 1 종료 조건**: [01](01-product-concept.md) §7 성공 기준 7개를 전부 측정값으로 보고.

### Phase 2 — 확장 (8~10주)

MCP 커넥터 · 스킬 · Deployment(cron, off-peak) · 웹훅 · `self_hosted` 환경 ·
**공식 호환 lane 켜기** · `dsh` 대안 하네스 · Redis 실시간

### Phase 3 — 고급 (범위 재평가 후)

멀티에이전트 · 동적 워크플로 · Outcome 평가 루프 · Dreams · 티어 V(gVisor)

---

## 6. 열린 질문

설계로 못 정하고 **측정이나 조직 합의가 필요한 것들**입니다. 숨기지 않고 적어 둡니다.

| # | 질문 | 어떻게 답할 것인가 | 기한 |
|---|---|---|---|
| Q1 | 사내 에이전트 중 `bash`가 실제로 필요한 비율은? | Phase 0에서 파일럿 10개의 툴 사용 분포 측정 | Phase 0 종료 |
| Q2 | `run_code`(CPython WASI)로 실제 데이터 작업이 되는가? | 실제 과제 20건 통과율 | Phase 0 종료 |
| Q3 | 프로덕션 클러스터에서 티어 P가 가능한가? (k8s 1.33 userns 또는 커스텀 seccomp) | 플랫폼팀과 `probe_capabilities` 결과 공유 | Phase 0 |
| Q4 | 부서별 네임스페이스 vs 공유 워커 풀 | 부서 수 확정 후. 3개 이하면 공유 | Phase 1 시작 |
| Q5 | 감사 로그 보존 기간 (최소 3년?) | 법무·보안 합의 | Phase 1 |
| Q6 | 승인 정책 기본값 — 어떤 툴이 `always_ask`인가 | 보안팀과 툴별 리스크 평가 | Phase 1 |
| Q7 | 모델 비용을 부서에 어떻게 배분하는가 (실비 vs 정액) | 재경 합의. `usage_events`는 어느 쪽이든 지원 | Phase 1 |
| Q8 | 공식 호환 lane을 실제로 쓸 소비자가 있는가 | 없으면 Phase 2에서 연기. 코드 분리는 이미 됐으므로 비용 없음 | Phase 2 시작 |
| Q9 | Wasm에서 네이티브 휠(numpy/pandas)이 필요해지면? | Pyodide 재검토 vs 해당 환경만 티어 P | Q2 결과에 따라 |
| Q10 | DeepSeek 외 provider를 병행할 것인가 | D12로 이미 가능. 필요가 생기면 어댑터 1개 | 상시 |

---

## 7. 문서 자체의 유지

| 문서 | 언제 갱신하는가 |
|---|---|
| 01 제품 컨셉 | 범위가 바뀔 때. Phase 경계마다 재검토 |
| 02 아키텍처 | 평면 경계·실행 권한·턴 생애주기가 바뀔 때 |
| 03 레이어 | 새 레이어·새 Port 규칙. `.importlinter`와 **반드시 함께** |
| 04 API | 엔드포인트 추가 시. 이벤트 타입 표는 `ma_domain/events.py`와 함께 |
| 05 DB | 마이그레이션마다. ERD는 자동 생성 고려 |
| 06 하네스·모델 | provider 추가, 요금 개정, 모델 은퇴 시 ★ 가장 자주 바뀐다 |
| 07 샌드박스 | 티어 추가, 커널/CRI 요구사항 변경 시 |
| 08 인프라 | 토폴로지·네트워크·스케일 신호 변경 시 |
| 09 코드베이스 | 패키지 추가/승격 시 |
| 10 관계 | §3 체크리스트는 새 리소스를 추가할 때마다 실제로 쓰고 틀리면 고친다 |

> **06이 가장 자주 바뀝니다.** 모델 ID·요금·파라미터는 분기 단위로 바뀝니다. 그래서
> D12가 그것들을 **코드가 아니라 `model_cards` 데이터**로 밀어낸 것이고, 이 문서는
> "그때 어디를 보면 되는가"만 유지하면 됩니다.
