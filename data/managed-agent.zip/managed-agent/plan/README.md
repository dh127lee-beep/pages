# AWP — 사내 에이전트 운영 플랫폼 설계

> 코드명 **AWP** (Agent Workspace Platform). 이름은 임시입니다.
> 작성일 2026-10-14
> 설계 기준 스택: **Python 3.13 / FastAPI / SQLAlchemy 2.0 / PostgreSQL 17 / Kubernetes**
> 모델: **DeepSeek V4.1-Flash (`deepseek-flash`)** · 샌드박스: **Wasm(WASI p1) + bubblewrap/Landlock**

이 폴더는 AWP의 **설계 문서 세트**입니다. 구현 코드는 아직 없고, 이 문서가 코드보다 먼저
합의되어야 하는 것들(제품 범위, 레이어 경계, DB 스키마, 하네스·모델 선택, 샌드박스 격리
수준, 인스턴스 토폴로지)을 담습니다.

HTML 버전: [`index.html`](index.html) — 같은 내용에 21개 SVG 다이어그램이 들어 있습니다.
브라우저로 바로 열면 됩니다 (`open plan/index.html`).

> **MD가 원천이고 HTML은 산출물입니다.** 이 폴더의 `.md`를 고쳤으면
> `python3 plan/_build/build_html.py`로 `index.html`을 다시 생성하십시오
> ([`_build/README.md`](_build/README.md)).

---

## 문서 목차

| # | 문서 | 다루는 것 |
|---|---|---|
| 01 | [제품 컨셉](01-product-concept.md) | 누구의 어떤 문제를 푸는가, 핵심 개념 10개, 범위와 비범위, 성공 기준 |
| 02 | [아키텍처](02-architecture.md) | 3평면 분리와 신뢰 경계, 메타-하네스, 실행 권한, 턴 생애주기, 장애 복구 |
| 03 | [레이어 구조](03-layers.md) | 7계층과 의존 규칙, 레이어별 금지 사항, Port/Module 규칙, CI 강제 |
| 04 | [API 구조](04-api.md) | 내부 API와 공식 호환 API의 분리, 엔드포인트 전체, 이벤트 타입, SSE 계약 |
| 05 | [데이터베이스 구조](05-database.md) | 11개 테이블 그룹 · 48개 테이블, DDL, 동시성 제어, 파티셔닝 |
| 06 | [하네스와 모델](06-harness-and-model.md) | **DeepSeek Harness 검토**, DeepSeek V4.1-Flash API·요금, 자체 하네스 설계, 비용 지렛대 |
| 07 | [샌드박스](07-sandbox.md) | **Wasm(WASI p1) 검토**, 2티어 설계, 툴 매트릭스, 위협 모델, egress 강제 |
| 08 | [인프라 · 인스턴스](08-infrastructure.md) | k8s 네임스페이스/인스턴스 역할표, 네트워크, 샌드박스 생애주기, 스케일링과 장애 모드 |
| 09 | [코드베이스 구조](09-codebase.md) | uv 워크스페이스 모노레포, 25패키지 + 5앱, 패키지↔레이어 매핑, 테스트 전략 |
| 10 | [관계 · 트레이서빌리티](10-relationships.md) | 개념→API→레이어→패키지→테이블→인스턴스 매트릭스, 변경 영향도, 로드맵 |

---

## 핵심 설계 결정

레퍼런스(`ref/open-code` = Open Managed Agents)가 **나중에 고쳐야 했던 것들**을 처음부터
반영하고, DeepSeek Harness가 **이미 잘 풀어 둔 것들**은 가져온 것이 이 설계의 요지입니다.

| # | 결정 | 왜 |
|---|---|---|
| D1 | **세대(v0/v1) 이중 구조를 만들지 않는다.** 리소스마다 구현은 하나. | 레퍼런스는 같은 `agent`가 `/v1/agents`(신)와 `/v1/oma/agents`(구)에 **별개 테이블·별개 문서**로 존재해 읽는 사람이 매번 세대를 확인해야 한다. 최대 가독성 비용. → [03](03-layers.md) §7 |
| D2 | **스키마 진실의 원천은 Alembic 마이그레이션 하나.** 패키지 안 `CREATE TABLE IF NOT EXISTS` 금지. | 레퍼런스는 drizzle 마이그레이션 5종 + `applySchema()` + 패키지 inline DDL + DO 내부 `ensureSchema`로 분산되어 있다. → [05](05-database.md) §8 |
| D3 | **실행 권한은 DB에 있다.** `session_executions`의 outbox + lease + fence가 유일한 권한. 워커는 "claim한 lane의 host"일 뿐. | 레퍼런스가 ADR 0006으로 뒤늦게 도달한 결론. 처음에 특정 런타임 객체가 권한을 가지면 split-brain과 멀티 런타임 이식이 모두 막힌다. → [02](02-architecture.md) §3 |
| D4 | **이벤트 로그는 처음부터 이중 테이블.** 입력은 `session_pending_events`에 쌓고, 드레인 시점에 `session_events`로 promote하며 `seq`를 부여. | 레퍼런스는 도착 시점에 `seq`를 매겨서, 에이전트 스트리밍 중 사용자 입력이 **이전 턴 중간에 끼어들어** LLM replay가 오염됐다(`ORDERING_DESIGN.md`). → [02](02-architecture.md) §4 |
| D5 | **자격증명은 샌드박스 주소공간에 절대 없다.** egress 프록시가 요청 시점에 주입한다. | 프롬프트 인젝션된 에이전트가 유출할 토큰이 **존재하지 않게** 만드는 것이 유일하게 견고한 방어. → [07](07-sandbox.md) §6 |
| D6 | **능력(enforcement)은 보고되는 사실이다.** `enforced` / `partial` / `unsupported`를 백엔드가 보고하고, `required` 프로필과 맞지 않으면 세션 생성을 거부한다. | 레퍼런스는 12개 provider 중 1개만 `enforced`인데 레거시 경로의 `capabilities()`는 "메서드가 있으면 있다"고 판단한다. DeepSeek Harness도 같은 결론(`SandboxEnforcement: 'full' \| 'partial'`, "절대적 경계가 필요한 호출자는 `partial`을 `full`로 취급해서는 안 된다")에 도달해 있다. → [07](07-sandbox.md) §4 |
| D7 | **부서(워크스페이스) = k8s 네임스페이스 = ResourceQuota = 예산 집행 지점.** | 사내 플랫폼에서 "부서별 비용 통제"가 1급 요구인데, 애플리케이션 레벨 예산만으로는 노드 자원을 못 막는다. 격리와 예산을 같은 경계에 둔다. → [08](08-infrastructure.md) §3 |
| D8 | **승인(approval)은 툴 권한 정책의 자연스러운 귀결로 구현한다.** `always_ask` 툴은 실행 함수를 떼고 pending으로 두어 `requires_action`으로 턴을 끊는다. 결과는 **fail-closed**. | 공식 CMA 계약과 같은 메커니즘이라 호환이 깨지지 않는다. DeepSeek Harness의 approval seam에서 `allowed-once`/`rejected`/`cancelled`/`unavailable` 4값과 "답변자 부재는 `unavailable`이고 게이트를 열지 않는다"를 그대로 가져온다. → [02](02-architecture.md) §7 |
| D9 | **공식 Managed Agents wire 계약은 처음부터 "별도 inbound lane"으로 격리한다.** 지금은 내부 API만 쓰더라도 최외곽 조립 직전까지 분리. | 내부 API와 공식 API가 같은 라우터를 공유하면, 나중에 공식 SDK 호환을 켤 때 내부 편의 필드가 공식 shape를 오염시킨다. 레퍼런스의 ADR 0005가 지키는 선. → [04](04-api.md) §1 |
| D10 | **메모리는 전용 툴 없이 파일시스템 마운트로 제공한다.** `/mnt/memory/<name>/`. | 공식 계약과 동일. 에이전트는 이미 가진 파일 툴로 읽고 쓰므로 툴 표면이 늘지 않고, 프롬프트에는 "어디에 마운트됐다"는 안내만 들어간다. → [02](02-architecture.md) §9 |
| **D11** | **하네스는 자체 Python 루프로 만든다. DeepSeek Harness(`dsh`)는 (a) 설계 레퍼런스 + (b) 교체 가능한 대안 하네스로 둔다.** | dsh는 "Model-visible means logged"를 **자기 세션 로그**(`$DSH_HOME`의 JSONL)로 구현한다. 우리의 정본 이벤트 로그와 둘 중 어느 것이 모델 컨텍스트의 원천인지 모호해지는 순간 D2·D4가 깨지고 감사 추적이 둘로 갈라진다. 또 dsh는 developer preview로 호환성 파괴를 예고하고 있고, Node 런타임을 모든 워커에 넣어야 한다. → [06](06-harness-and-model.md) §3 |
| **D12** | **모델은 코드가 아니라 설정이다.** `ModelPort` + provider 어댑터를 seam으로 두고, 어떤 모델을 쓸지는 **환경변수 기본값 → 모델 카드 → 워크스페이스 → 에이전트 → 세션 오버라이드** 순으로 결정한다. `deepseek-flash`는 그 기본값일 뿐이다. | 모델은 바뀐다. 실제로 `deepseek-v4-pro`는 2026-09-14부터 V4.1-Flash로 라우팅되고 `deepseek-v4-flash`는 은퇴했다. 모델 ID·컨텍스트 한도·추론 파라미터 이름·요금이 전부 **모델 카드의 선언**이어야 하고, 하네스는 그 선언을 읽어 적응해야 한다. 모델 문자열이 코드나 프롬프트에 박히면 교체가 릴리스가 된다. → [06](06-harness-and-model.md) §1, §4 |
| **D12b** | **프롬프트 prefix 안정화와 off-peak 스케줄링을 1급 설계 제약으로 둔다.** | 캐시 히트 입력이 캐시 미스의 **1/50** 가격이고(peak $0.006 vs $0.3 / 1M), off-peak가 peak의 **1/2**이다. 사내 플랫폼은 cron 배포가 많아 off-peak 이동이 그대로 비용 절감이 된다. 이 두 배수는 다른 어떤 최적화보다 크다. 단 배수 자체도 모델 카드가 선언하는 값이다. → [06](06-harness-and-model.md) §5 |
| **D13** | **샌드박스는 커널을 건드리지 않는 2티어.** 기본은 **Wasm(Wasmtime + WASI p1, 능력 기반)**, 셸이 필요하면 **bubblewrap + Landlock**(비특권 user namespace). gVisor/Kata는 1단계 비범위이되 Port로 막지 않는다. | 내장 툴 8개 중 **7개는 샌드박스 셸이 필요 없다** — `read/write/edit/glob/grep`은 호스트 함수로 구현 가능하고 `web_fetch/web_search`는 원래 신뢰 영역에서 돈다. 프로세스 세계가 필요한 것은 `bash` 하나뿐이다. 그래서 기본 티어를 Wasm으로 두면 ambient authority가 0인 격리를 ms 단위 기동으로 얻는다. → [07](07-sandbox.md) |

---

## 한 장 요약

```
                    사내 사용자 (부서 담당 · 운영자 · 관리자 · 감사)
                                      │
                              Console (React SPA)
                                      │  /api/v1/*
 ┌────────────────────────────────────▼─────────────────────────────────────┐
 │ 제어 평면  control-plane (FastAPI, HPA)                       [신뢰]      │
 │  인증·인가 · 리소스 CRUD · 이벤트 수용(admission) · 승인 · 감사 · 예산     │
 │  자격증명 평문을 아는 유일한 곳                                            │
 └──────┬──────────────────────────────────────────────────┬────────────────┘
        │ PostgreSQL (유일한 실행 권한: outbox+lease+fence) │ 대행 RPC
        ▼                                                  │ (credential 주입)
 ┌──────────────────────────────────────────────┐           │
 │ 실행 평면  runtime-worker (HPA on queue 깊이) │           │
 │  claim → fence → 하네스 루프 → 이벤트 append  │  [준신뢰]  │
 │  DeepSeek V4.1-Flash 호출 · 자격증명 없음      │           │
 └──────┬───────────────────────────────────────┘           │
        │ 같은 Pod 안에서 confine (k8s API 호출 없음)        │
        ▼                                                   ▼
 ┌──────────────────────────────┐          ┌────────────────────────────────┐
 │ 샌드박스 평면                 │  egress  │ egress-proxy                   │
 │ 티어 W: Wasmtime + WASI p1    │─────────▶│ MITM TLS · 호스트 allowlist     │
 │ 티어 P: bwrap + Landlock      │  only    │ 호스트별 credential 주입        │
 │ /workspace /mnt/memory [비신뢰]│          │ credential_events 적립          │
 └──────────────────────────────┘          └────────────────────────────────┘
                                                      │
                                                      ▼
                                   DeepSeek API · MCP 서버 · 사내 시스템
```

---

## 참고한 자료

| 자료 | 위치 | 역할 |
|---|---|---|
| Claude Managed Agents 공식 문서 37페이지 | [`../ref/claude-managed-agents/`](../ref/claude-managed-agents/) | 개념 모델·이벤트 분류·세션 상태의 원천. 우리가 따르는 계약 |
| 공식 API 레퍼런스 110엔드포인트 | [`../ref/api/`](../ref/api/) | 엔드포인트별 파라미터·스키마. [04](04-api.md)의 호환 표 근거 |
| Open Managed Agents 소스 | [`../ref/open-code/`](../ref/open-code/) | 같은 문제를 TypeScript로 푼 구현. 패키지 173개 + 앱 10개 |
| OpenMA 분석 5부 | [`../ref/open-code-analysis/`](../ref/open-code-analysis/) | 위 소스의 아키텍처·세션·툴·API·메모리 분석. D1~D10의 반면교사 근거 |
| CMA 문서 서베이 6부 | [`../docs/survey/`](../docs/survey/) | 공식 문서를 주제별로 재편한 노트 |
| DeepSeek Harness (`dsh`) | <https://github.com/deepseek-ai/deepseek-harness> | 하네스 아키텍처·툴 카탈로그·approval/sandbox seam의 설계 레퍼런스. [06](06-harness-and-model.md) |
| DeepSeek API 문서 | <https://api-docs.deepseek.com/> | 모델 ID·요금·파라미터. [06](06-harness-and-model.md) §2 |

> 레퍼런스 구현은 **TypeScript**, 이 설계는 **Python**입니다. 패키지 구조는 1:1 대응되지
> 않지만 레이어 경계와 Port 규칙은 그대로 가져왔습니다. 대응표는 [09](09-codebase.md)
> 마지막 절에 있습니다.
