# 02. 아키텍처

> 다이어그램: [`svg/03-planes.svg`](svg/03-planes.svg) · [`svg/04-meta-harness.svg`](svg/04-meta-harness.svg) ·
> [`svg/05-turn-sequence.svg`](svg/05-turn-sequence.svg) · [`svg/06-execution-authority.svg`](svg/06-execution-authority.svg) ·
> [`svg/07-event-dual-table.svg`](svg/07-event-dual-table.svg) · [`svg/21-approval-flow.svg`](svg/21-approval-flow.svg)

---

## 1. 세 평면과 신뢰 경계

AWP는 신뢰 수준이 다른 세 평면으로 나뉩니다. **경계를 넘는 것이 무엇인지**가 아키텍처의 전부입니다.

| 평면 | 프로세스 | 신뢰 | 아는 것 | 모르는 것 |
|---|---|---|---|---|
| **제어 평면** Control Plane | `control-plane` (FastAPI) | 신뢰 | 자격증명 평문, 전체 DB, 모든 워크스페이스 | — |
| **실행 평면** Runtime Plane | `runtime-worker` | 준신뢰 | 자기가 claim한 세션의 이벤트 로그, 샌드박스 인스턴스 | 사용자 자격증명 평문, 모델 API 키, 다른 워크스페이스 |
| **샌드박스 평면** Sandbox Plane | 워커 안의 Wasm 인스턴스 또는 confine된 subprocess | **비신뢰** | `/workspace` 파일, 자기 세션 ID, egress 프록시 주소 | 자격증명, DB, k8s API, 다른 세션, 인터넷 직접 접근 |

### 경계를 넘는 것만 나열

```
Console ──HTTPS──▶ 제어 평면          : 쿠키 세션 또는 API 키
제어 평면 ──SQL──▶ PostgreSQL          : 전 테이블
실행 평면 ──SQL──▶ PostgreSQL          : 자기 lane의 execution/event만 (DB 역할로 제한)
실행 평면 ──gRPC/HTTP──▶ 제어 평면     : credential 대행 요청 (tenant,session,host) → 응답은 "주입 완료"뿐
실행 평면 ──in-process──▶ 샌드박스        : Wasmtime 인스턴스 또는 confine된 argv spawn (k8s API 불필요)
샌드박스 ──TCP──▶ egress-proxy         : 유일한 허용 egress (NetworkPolicy)
egress-proxy ──HTTPS──▶ 외부           : 호스트 allowlist 통과분만, credential 주입 후
```

**샌드박스에서 제어 평면·DB·k8s API로 가는 화살표는 없습니다.** 이것이 D5의 구현입니다.

### 왜 실행 평면을 따로 두는가

제어 평면에 하네스 루프를 합치면 세 가지가 깨집니다.

1. **HPA 신호가 섞인다.** API 요청 수와 턴 실행 시간은 전혀 다른 축이다. 턴은 분~시간 단위다.
2. **배포가 턴을 끊는다.** API 롤링 업데이트마다 실행 중인 턴이 죽는다.
3. **자격증명 반경이 커진다.** 하네스는 모델 응답을 신뢰할 수 없는 입력으로 다루는 코드다.
   그 프로세스가 전체 자격증명을 들고 있으면 안 된다.

---

## 2. 메타-하네스: 플랫폼이 준비하고, 하네스가 결정한다

하네스(에이전트 루프)는 **교체 가능**해야 합니다. 코딩용 하네스, 조사용 하네스, 외부 에이전트
프록시(ACP 류)가 같은 플랫폼 위에서 돌아야 합니다. 경계선은 하나입니다.

> **플랫폼은 "무엇이 사용 가능한지"를 준비하고, 하네스는 "그것을 모델에게 어떻게 전달할지"를 결정한다.**

| 플랫폼(실행 평면 호스트)이 준비하는 것 | 하네스가 결정하는 것 |
|---|---|
| 에이전트 설정 로드, 버전 핀 | 시스템 프롬프트 구성 |
| 툴 레지스트리 구성(권한 정책 적용 포함) | 툴 전달 방식(한 번에 전부 vs 점진 공개) |
| 스킬 파일 샌드박스 마운트 | 캐시 breakpoint 배치 전략 |
| 메모리 스토어 마운트 + 턴 종료 동기화 | 압축(compaction) 시점과 방식 |
| 샌드박스 생애주기(프로비저닝·웜업·스냅샷) | 컨텍스트 엔지니어링(이벤트→메시지 변환·필터·순서) |
| 이벤트 내구적 append + 실시간 fanout | 재시도 전략, 전환 조건 |
| 세션 상태 전이와 `running/idle` 쌍 불변식 | 턴 종료 판단(`stop_reason` 후보 제시) |
| lease/fence 검증, 크래시 복구 | 스텝마다 무엇을 broadcast할지 |
| 모델 카드 해석 → 클라이언트 생성 | 모델 호출 파라미터(effort, thinking display) |

### 하네스에 주는 컨텍스트

```python
# packages/ma_harness/ports.py
@dataclass(frozen=True)
class HarnessContext:
    agent: AgentDefinition  # 모델/프롬프트/툴 설정 (버전 핀됨)
    trigger: SessionEvent  # 이 턴을 일으킨 이벤트
    tools: ToolRegistry  # 플랫폼이 이미 권한 정책을 적용해 만든 것
    runtime: HarnessRuntime


@runtime_checkable
class HarnessRuntime(Protocol):
    history: EventLogPort  # 읽기 + fence가 붙은 append
    sandbox: SandboxPort
    model: ModelPort
    broadcast: Callable[[SessionEvent], Awaitable[None]]
    pending_confirmations: list[str]  # 승인 대기 tool_call_id
    abort: anyio.Event  # 인터럽트
    report_usage: Callable[[Usage], Awaitable[None]]
```

**하네스는 무상태입니다.** 필요한 모든 것은 (1) 이벤트 로그, (2) 에이전트 설정, (3) 샌드박스
파일시스템에서 옵니다. 크래시하면 다음 claim이 새 인스턴스를 만들고, 이벤트 로그를 다시 읽어
컨텍스트를 재구성합니다. 잃을 메모리가 없습니다.

### 플랫폼이 제공하는 Port 목록

| Port | 책임 | 1단계 구현 |
|---|---|---|
| `EventLogPort` | append / read / promote(pending→events) | `ma_store_sql` (PostgreSQL) |
| `ExecutionStorePort` | admit / claim / renew / settle / interrupt | `ma_store_sql` (outbox + lease) |
| `SandboxPort` | confine / exec / mount / snapshot / destroy | `ma_sandbox_wasm`(기본), `ma_sandbox_bwrap`, `ma_sandbox_local`(테스트) |
| `CredentialEgressPort` | prepare / attach / revoke + `enforcement` 보고 | `ma_egress` + NetworkPolicy |
| `ModelPort` | 모델 카드 → provider 어댑터, 스트리밍 호출 | `ma_harness` + `ma_model_deepseek` / `ma_model_openai_compat` |
| `RealtimePort` | publish / subscribe (SSE fanout) | PostgreSQL `LISTEN/NOTIFY` → 2단계에 Redis |
| `ObjectStorePort` | 파일·산출물·스냅샷 | S3 / MinIO |
| `ApprovalPort` | 승인 요청 생성 / 결과 조회 | `ma_governance` |
| `AuditPort` | append-only 감사 기록 | `ma_governance` |
| `BudgetPort` | 예산 확인 / 사용량 적립 | `ma_governance` |

---

## 3. 실행 권한은 DB에 있다 (D3)

이것이 이 아키텍처의 **가장 중요한 결정**입니다.

### 문제

세션의 턴을 실행할 권리를 누가 갖는가? 레퍼런스는 처음에 Durable Object가 권한을 갖도록
했고, 그래서 (a) 다른 런타임으로 이식할 수 없었고 (b) DO가 느리게 죽는 동안 새 DO가 같은
세션을 실행하는 split-brain이 가능했습니다.

### 해결: outbox + lease + fence

```
session_executions
┌──────────────────────────────────────────────────────────────────────┐
│ workspace_id, session_id, lane_id   ← FIFO 단위 (lane = session_thread)│
│ execution_id        = 이 lane의 첫 이벤트 id (멱등키)                   │
│ state               queued → running → completed | failed | cancelled │
│ generation          단조 증가. claim마다 +1                            │
│ attempt_id          이번 시도의 UUID                                   │
│ lease_owner         워커 인스턴스 ID                                   │
│ lease_expires_at    claim 시점 + TTL(90s). 하트비트로 갱신(30s)         │
│ interrupt_requested_at                                               │
│ deadline_at                                                           │
└──────────────────────────────────────────────────────────────────────┘
```

규칙 4개:

1. **입력 수용과 실행 예약은 같은 트랜잭션에서 일어난다.**
   `POST /sessions/{id}/events`는 아래를 한 트랜잭션으로 처리합니다.

   ```sql
   -- 1) 세션 revision CAS (경합에서 진 트랜잭션은 아무것도 남기지 않는다)
   UPDATE sessions SET revision = revision + 1
    WHERE workspace_id = :ws AND id = :sid AND revision = :expected
   RETURNING revision;
   -- 2) user.interrupt면 해당 lane execution에 플래그 + 그때까지 쌓인 pending 취소
   UPDATE session_executions SET interrupt_requested_at = now() WHERE ... AND state = 'running';
   UPDATE session_pending_events SET cancelled_at = now() WHERE ... AND cancelled_at IS NULL;
   -- 3) 이벤트 INSERT (pending)
   INSERT INTO session_pending_events (...) VALUES (...) ON CONFLICT (id) DO NOTHING;
   -- 4) outbox: lane별 execution 예약
   INSERT INTO session_executions (..., state = 'queued') ON CONFLICT (execution_id) DO NOTHING;
   ```

   revision CAS가 실패하면 롤백되므로 **이벤트·인터럽트·outbox 중 어느 것도 새지 않습니다.**

   **인터럽트가 pending INSERT보다 먼저입니다.** 뒤에 두면 인터럽트가 자기 자신과,
   같은 요청에 실려 온 새 메시지까지 접습니다 — "멈추고 이거 해줘"는 흔한 조합이고,
   `user.interrupt`는 모델이 보는 이벤트라 로그에 올라가야 합니다
   ([IMPL-0008](../docs/impl/0008-admission-ordering.md)).

2. **워커는 claim해서 fence를 얻는다.** 권한의 증거는 `(generation, attempt_id, lease_expires_at)`
   세 쌍, 즉 **fence**입니다.

   ```sql
   UPDATE session_executions SET
     state = 'running', generation = generation + 1,
     attempt_id = :attempt, lease_owner = :worker,
     lease_expires_at = now() + interval '90 seconds'
   WHERE id = (
     SELECT id FROM session_executions
      WHERE state = 'queued'
        AND (lease_expires_at IS NULL OR lease_expires_at < now())
      ORDER BY created_at
      FOR UPDATE SKIP LOCKED
      LIMIT 1
   )
   RETURNING *;
   ```

   `FOR UPDATE SKIP LOCKED`가 여러 워커의 동시 claim을 자연히 직렬화합니다.

3. **fence 없는 쓰기는 거부된다.** 이벤트 append, 메모리 동기화, 샌드박스 호출 전에 fence의
   `generation`이 DB의 현재 값과 같은지 확인합니다. 다르면 `ExecutionFenceLost`를 올리고 턴을
   중단합니다. 느리게 죽는 워커는 **자기 결과를 커밋할 수 없습니다.**

4. **at-least-once 실행, at-most-once 커밋.** 턴은 여러 번 시도될 수 있지만 커밋은 한 번만
   성공합니다. 그래서 LLM 스트림은 **재생하지 않습니다** — 부분 텍스트와 짝 없는 `tool_use`는
   placeholder 이벤트로 봉합하고 다음 시도가 새 턴으로 이어갑니다.

### 워커는 호스트일 뿐이다

이 설계의 결과로 **세션은 어느 워커에서도 이어서 실행될 수 있습니다.** 워커를 늘리고 줄이고
죽여도, 권한은 DB에 있으므로 복구는 "다음 claim"입니다. 별도 복구 코드가 거의 필요 없습니다.

상태 전이는 [`svg/06-execution-authority.svg`](svg/06-execution-authority.svg)에 있습니다.

---

## 4. 이벤트 로그와 순서 보장 (D4)

### 지켜야 하는 불변식

> "LLM이 본 것"을 재구성하는 읽기는, 수용된 각 입력 이벤트를
> **그 입력을 수집하기 전 에이전트가 낸 이벤트들 뒤**,
> **그 입력 때문에 에이전트가 낸 이벤트들 앞**에 위치시켜야 한다.

이것이 깨지면 프롬프트 캐시가 매 턴 drift하고, 모델은 자기가 보지 않은 순서의 역사를
보게 됩니다.

### 왜 단일 테이블로는 안 되는가

`seq`를 **도착 시점**에 부여하면, 에이전트가 스트리밍하는 동안 사용자가 메시지를 보내면
그 `user.message`가 **이전 턴 중간**에 꽂힙니다. 콘솔은 클라이언트 정렬로 가릴 수 있지만,
`ORDER BY seq`로 모델 메시지를 만드는 replay 경로는 그대로 오염됩니다.

### 이중 테이블

```
입력 수용 시                      드레인(턴 시작) 시
──────────────                   ──────────────────
session_pending_events           ① peek  (pending_seq 순)
  pending_seq  (큐 순서)          ② INSERT INTO session_events (seq 부여)  ← 여기서 seq가 생긴다
  enqueued_at                     ③ DELETE FROM session_pending_events
  event_id                        크래시 시 ②만 되고 ③이 안 될 수 있음
  cancelled_at                      → event_id 유니크 인덱스로 중복 promote 방지
  payload

session_events                   seq = 모델이 본 순서. 영구 불변.
  seq  (promote 시점 부여)
```

`peek → INSERT → DELETE` 순서가 중요합니다. 반대로 하면 크래시 시 이벤트가 **사라집니다.**
이 순서면 크래시는 중복을 만들고, 중복은 `event_id` 유니크 인덱스가 막습니다.

### 사용자에게 보이는 상태

사용자가 보낸 메시지가 pending에 머무는 동안 UI가 조용하면 안 되므로, 세 가지 SSE 프레임을
추가로 내보냅니다. 이들은 **이벤트 로그에 영속되지 않습니다**(스트림 전용).

| 프레임 | 의미 |
|---|---|
| `system.user_message_pending` | 큐에 들어갔고 아직 모델이 보지 않았다 |
| `system.user_message_promoted` | `session_events`로 승격됐다. 이제 모델이 본다 |
| `system.user_message_cancelled` | 인터럽트로 취소됐다 |

---

## 5. 턴 하나의 생애주기

[`svg/05-turn-sequence.svg`](svg/05-turn-sequence.svg)의 텍스트 버전입니다.

```
Console      control-plane            PostgreSQL              runtime-worker            Sandbox Pod     Model
  │ POST /sessions/:id/events │             │                        │                      │            │
  │──────────────────────────▶│ 멱등키 확인 │                        │                      │            │
  │                           │ revision CAS│                        │                      │            │
  │                           │  ┌── 한 트랜잭션 ──────────────┐     │                      │            │
  │                           │  │ pending INSERT              │     │                      │            │
  │                           │  │ interrupt UPDATE(있으면)     │     │                      │            │
  │                           │  │ executions INSERT(queued)   │     │                      │            │
  │                           │  │ sessions revision+1         │     │                      │            │
  │                           │  └─────────────────────────────┘     │                      │            │
  │◀── 202 accepted ──────────│             │                        │                      │            │
  │◀══ SSE user_message_pending ════════════│                        │                      │            │
  │                           │             │◀── claim (SKIP LOCKED) │                      │            │
  │                           │             │    fence{gen,attempt}  │                      │            │
  │                           │             │◀── heartbeat 30s ──────│ (TTL 90s)            │            │
  │                           │             │◀── promote pending→events (seq 부여)          │            │
  │◀══ SSE user_message_promoted ═══════════│                        │                      │            │
  │                           │             │                        │ 샌드박스 확보         │            │
  │                           │             │                        │──── Pod ensure ─────▶│            │
  │                           │             │                        │  웜업: 헬스체크       │            │
  │                           │             │                        │        스냅샷 복원    │            │
  │                           │             │                        │        패키지 설치    │            │
  │                           │             │                        │        리소스 마운트  │            │
  │                           │             │                        │        스킬/메모리    │            │
  │◀══ SSE session.status_running ══════════│◀── append ─────────────│                      │            │
  │                           │             │                        │ 이벤트→메시지 재구성  │            │
  │                           │             │                        │─────── 스트리밍 호출 ─────────────▶│
  │◀══ SSE agent.message_chunk ═════════════│◀── (영속 안 함) ───────│◀══ 토큰 ══════════════════════════│
  │                           │             │◀── agent.message ──────│◀── message_end ───────────────────│
  │                           │             │◀── agent.tool_use ─────│◀── tool_use ──────────────────────│
  │                           │             │                        │  fence 검증 후        │            │
  │                           │             │                        │──── exec ───────────▶│            │
  │                           │             │                        │◀─── stdout ──────────│            │
  │                           │             │◀── agent.tool_result ──│                      │            │
  │                           │             │                        │─────── 다음 스텝 ─────────────────▶│
  │                           │             │                        │        … 루프 …       │            │
  │                           │             │◀── 메모리 동기화(fence 검증) ──────────────────│            │
  │                           │             │◀── usage 적립 / 예산 확인 ─────────────────────│            │
  │◀══ SSE session.status_idle{stop_reason} ═│◀── append ─────────────│                      │            │
  │                           │             │◀── settle(completed) ──│                      │            │
  │                           │             │                        │  idle 5분 → 스냅샷 + Pod 삭제      │
```

### 턴 종료 처리 — 순서가 중요한 세 가지

1. **메모리 동기화는 `idle` 이전에 끝난다.** 사용자가 "끝났다"를 본 뒤에도 메모리가
   반영 중이면, 다음 세션이 오래된 메모리를 읽는다. 동기화는 턴의 일부다.
2. **`running`과 `idle`은 반드시 짝을 이룬다.** 예외 경로에서도 `idle`을 정확히 한 번
   내보낸다(`idle_emitted` 플래그). 짝이 깨지면 UI가 영구 로딩 상태에 빠진다.
3. **settle은 마지막이다.** 하트비트 갱신 → 모든 append 완료 확인 → `settle`.
   lease 안에서 커밋이 끝나야 fence가 의미를 갖는다.

### `stop_reason` 결정

| 조건 | `stop_reason` |
|---|---|
| 승인 대기 중인 **커스텀** 툴 호출이 있다 | `requires_action` (`custom_tool_result` 필요) |
| 승인 대기 중인 **내장/MCP** 툴 호출이 있다 | `requires_action` (`tool_confirmation` 필요) |
| 예산 상한에 도달했다 | `budget_reached` |
| 인터럽트됐다 | `interrupted` |
| 그 밖에 모델이 턴을 마쳤다 | `end_turn` |

> 레퍼런스에서는 "커스텀 툴 판별"이 하드코딩 이름 목록이라 `schedule*`·`browser_*`에
> `always_ask`를 걸면 오분류됩니다. AWP는 툴 레지스트리가 각 툴의 `kind`
> (`builtin | mcp | custom | delegation`)를 들고 있어서 이름 매칭을 하지 않습니다.

---

## 6. 인터럽트

세 가지를 **동시에** 합니다. 하나만으로는 부족합니다.

| 수단 | 역할 | 없으면 |
|---|---|---|
| `session_executions.interrupt_requested_at` 기록 | **내구적 권한.** 워커가 죽어도 남는다 | 재claim한 워커가 인터럽트를 모른 채 계속한다 |
| 로컬 `anyio.Event.set()` | **지연 최적화.** 같은 프로세스면 즉시 멈춘다 | 다음 폴링까지 수초 더 돌아간다 |
| `session_pending_events`의 미승격 행에 `cancelled_at` | 아직 모델이 안 본 입력을 취소 | 취소했는데 나중에 promote되어 실행된다 |

`user.interrupt`는 **lane을 소비하는 실행 단위가 아닙니다.** 그래서 outbox에 execution을
만들지 않고, 진행 중인 execution에 플래그만 붙입니다.

---

## 7. 승인 워크플로 (D8)

[`svg/21-approval-flow.svg`](svg/21-approval-flow.svg)

### 메커니즘 — 공식 계약과 동일

```
에이전트 설정           툴 레지스트리 구성            턴 실행
─────────────          ──────────────────           ────────
tools:[{               해당 툴을 "실행 함수 없는     모델이 그 툴을 호출
  type: agent_toolset,  선언만 있는 툴"로 등록        → 하네스가 실행할 수 없음
  configs:[{                                        → pending_confirmations에 적재
    name: bash,                                     → 턴 종료 terminate
    permission_policy:                              → session.status_idle{requires_action}
      always_ask }]}]
```

에이전트는 "승인이 필요하다"는 것을 배우지 않습니다. 단지 **실행할 수 없는 툴을 호출했고,
플랫폼이 턴을 끊었을 뿐**입니다. 그래서 프롬프트 인젝션으로 승인을 우회할 수 없습니다.

### 사내 확장 — 정책 레이어

공식 계약은 "클라이언트가 `user.tool_confirmation`을 보낸다"까지만 정의합니다. 사내에서는
**누가 보낼 수 있는지**가 핵심이라 그 위에 정책을 얹습니다.

```
approval_policies
  workspace_id, agent_id(nullable), tool_name 또는 tool_pattern
  required_role        viewer | operator | admin | owner
  required_approvals   기본 1. 민감 툴은 2 (4-eyes)
  self_approval        본인이 올린 세션을 본인이 승인할 수 있는가 (기본 false)
  notify               slack_channel | email | none
  expires_after        미응답 시 자동 거부까지 시간
```

```
approvals
  id, workspace_id, session_id, event_id(tool_use 이벤트)
  tool_name, tool_input(요약), requested_at
  state  pending | approved | denied | expired
  decided_by[], decided_at, reason
```

흐름:

1. 턴이 `requires_action`으로 멈추면 제어 평면이 `approvals` 행을 만들고 정책에 따라 알림.
2. 권한 있는 사람이 Console 승인 인박스에서 결정 → `POST /api/v1/approvals/{id}`.
3. 제어 평면이 `user.tool_confirmation` 이벤트를 **세션에 수용**(§3의 같은 트랜잭션 경로).
4. 워커가 claim해서 재개. 승인된 툴은 **실행 함수가 붙은 상태로 다시 구성**해 실행.
5. 거부면 `"Denied: {reason}"`을 `tool_result`로 주입하고 재개.
6. 모든 단계가 `audit_log`에 기록.

> 레퍼런스에는 여기에 결함이 있습니다. 승인 후 툴을 재구성할 때도 **`always_ask` 스트리핑이
> 그대로 적용되어** 실행 함수가 없고, 그러면 결과 없이 재개됩니다. AWP는 툴 레지스트리 구성
> 함수가 `grant: ToolGrant`를 받아 "이번 호출은 승인됨"을 명시적으로 표현합니다.

```python
# packages/ma_application/tools/registry.py
def build_tools(
    agent: AgentDefinition, sandbox: SandboxPort, grants: Sequence[ToolGrant] = ()
) -> ToolRegistry: ...


# grants = [ToolGrant(tool_call_id="toolu_...", tool_name="bash")]
# → 그 tool_call_id에 대해서만 실행 함수를 유지한다
```

---

## 8. 장애와 복구

| 장애 | 어떻게 되는가 | 복구 |
|---|---|---|
| **제어 평면 Pod 죽음** | 진행 중 턴은 영향 없음(워커가 돌고 있다). 새 입력 수용과 SSE만 중단 | HPA/ReplicaSet이 교체. SSE는 클라이언트가 지수 backoff 재연결 |
| **워커가 턴 중간에 죽음** | lease가 90초 후 만료 | 다른 워커가 claim(`generation+1`). 부분 텍스트는 placeholder로 봉합, 새 턴으로 이어짐. 이벤트 유실 0 |
| **워커가 느리게 죽음**(좀비) | fence 검증이 막는다 | `generation` 불일치 → `ExecutionFenceLost` → 좀비는 아무것도 커밋 못 함 |
| **샌드박스 Pod OOMKilled** | 툴 호출이 에러 문자열로 모델에 돌아감 | 다음 툴 호출 시 재프로비저닝(스냅샷 복원). 하네스는 죽지 않음 |
| **PostgreSQL failover** | claim/append가 일시 실패 | 워커는 재시도. lease TTL이 failover 시간보다 길어야 한다(90s) |
| **egress-proxy 죽음** | 샌드박스의 모든 외부 호출 실패 | **세션이 막히는 것이 올바른 동작.** 자격증명 유출보다 가용성 손실이 낫다 |
| **워커 노드 포화** | 샌드박스 프로비저닝 지연 | 티어 W는 ms 단위라 거의 없다. 티어 P는 웜 풀로 흡수. 풀이 비면 세션은 `rescheduling` |
| **모델 provider 5xx/429** | 하네스가 재시도(지수 backoff) | 한도 초과 시 `session.error` + `retry_status`. 세션은 `idle`로 돌아간다 |

### 모든 장애의 공통 규칙

> **이벤트는 broadcast 전에 내구적으로 쓴다.**
> SSE로 나간 것이 DB에 없는 상황을 만들지 않는다. 역순(먼저 쓰고 나중에 보냄)이면
> 최악의 경우 사용자가 조금 늦게 보지만, 반대면 사용자가 본 것이 사라진다.

---

## 9. 메모리 동기화

메모리 스토어는 SQL 문서가 진실이고, 샌드박스에는 **세션별 사본**을 마운트합니다.

```
세션 웜업                                    턴 종료 (public idle 직전)
─────────                                   ─────────────────────────
memories (SQL)                              샌드박스 /mnt/memory/<name> 디프 계산
  → 오브젝트 스토어 세션 prefix로 materialize    │
  → Pod에 마운트 (읽기/쓰기 또는 읽기전용)        ▼
                                            fence 재검증 (generation 일치?)
                                              │
                                              ▼
                                            CAS write (expected_revision)
                                              │
                                     ┌────────┴────────┐
                                  성공              revision_conflict
                                     │                 │
                                   완료          rebase 로그 남기고 재시도(최대 3회)
```

- 쓰기 가능한 마운트가 있을 때만 동작합니다. 읽기전용 스토어는 건너뜁니다.
- `fence_lost`면 동기화를 **포기합니다**. 소유권이 넘어갔다면 이 워커의 파일시스템 뷰는
  더 이상 정본이 아닙니다. 이것이 split-brain 방어의 마지막 지점입니다.
- 충돌 시 "에이전트의 쓰기를 버리고 SQL을 유지"가 기본입니다. 반대로 하면 다른 세션의
  메모리를 조용히 덮어씁니다.

---

## 10. 샌드박스 — 커널을 건드리지 않는 2티어

AWP는 **per-session VM이나 커널 모듈을 쓰지 않습니다.** 두 티어를 두고 환경이 티어를 고릅니다.

| 티어 | 격리 수단 | `bash` | 기동 | 강제 수준 |
|---|---|---|---|---|
| **W (wasm)** 기본 | Wasmtime + WASI p1 **능력 기반** (ambient authority 0) | ✗ | 수~수십 ms | 구성상 `enforced` |
| **P (process)** | bubblewrap argv 래핑 (비특권 user namespace) | ✓ | 수십~수백 ms | `enforced` / `partial` / `unsupported` (**프로브 결과에 따라**) |
| (V) vm | gVisor/Kata — 1단계 비범위, Port는 막지 않음 | ✓ | 초 | `enforced` |

**핵심 발견: 내장 툴 8개 중 7개는 샌드박스 셸이 필요 없습니다.**
`read/write/edit/glob/grep`은 호스트 측 함수로 워크스페이스 디렉터리에 직접 구현할 수 있고,
`web_fetch/web_search`는 원래 신뢰 영역에서 실행됩니다(공식 CMA도 그렇습니다).
프로세스 세계가 필요한 것은 **`bash` 하나**입니다.

그래서 기본 티어를 Wasm으로 두고, 셸이 필요한 에이전트만 티어 P를 씁니다.
전체 근거·툴 매트릭스·위협 모델은 [07. 샌드박스](07-sandbox.md)에 있습니다.

### 프로비저닝 전략

| 전략 | 설명 | 선택 |
|---|---|---|
| **지연 프로비저닝** | 첫 툴 호출 때 샌드박스를 만든다 | **기본.** 툴을 안 쓰는 세션은 비용 0 |
| **병렬 시작** | 모델 호출은 이벤트 로그만으로 즉시 시작, 샌드박스 준비는 백그라운드 | **기본** |
| **웜 풀** | 티어 P만. 미리 N개 confine 세션을 준비 | 워크스페이스별 `warm_pool_size` |
| **사전 프로비저닝** | 세션 생성 즉시 | `environment.packages`가 무거울 때만 옵트인 |

샌드박스는 **cattle입니다.** 죽으면 같은 스펙으로 다시 만들고 `/workspace`는 오브젝트 스토어
스냅샷에서 복원합니다. 상태는 샌드박스가 아니라 (DB + 오브젝트 스토어)에 있습니다.

### 능력은 **보고되는 사실**이다 (D6)

DeepSeek Harness의 sandbox seam이 같은 결론에 도달해 있습니다 — `enforcement: 'full' | 'partial'`이
*보고되는 사실*이고, "절대적 경계가 필요한 호출자는 `partial`을 `full`로 취급해서는 안 된다"로
명시합니다. AWP도 같습니다. 환경이 `required` 프로필을 요구하는데 백엔드가 `partial`을
보고하면 **세션 생성을 거부합니다.**

생애주기 상세: [`svg/16-sandbox-lifecycle.svg`](svg/16-sandbox-lifecycle.svg) ·
티어 설계: [07](07-sandbox.md) · 인프라 실현: [08](08-infrastructure.md) §5

---

## 11. 하네스와 모델

하네스는 **DeepSeek V4.1-Flash(`deepseek-flash`)** 를 호출하는 자체 Python 루프이고,
**DeepSeek Harness(`dsh`)** 는 (a) 설계 레퍼런스이자 (b) 교체 가능한 대안 하네스입니다.
선택 근거와 API 규약은 [06. 하네스와 모델](06-harness-and-model.md)에 있습니다. 요약만 둡니다.

### 모델 카드로 간접화

에이전트 설정에는 `model_id` **핸들**만 들어갑니다. 실제 모델·provider·base_url·키는
`model_cards` 테이블이 들고 있습니다.

```
agents.document.model = "dept-default"          ← 핸들
                           │
                           ▼
model_cards
  id             "dept-default"
  wire_model     "deepseek-flash"               ← 실제 모델 ID (= DeepSeek-V4.1-Flash)
  provider       deepseek_official | openai_compatible | anthropic_compatible
  base_url       https://api.deepseek.com       (Anthropic 포맷은 .../anthropic)
  credential_id  → credentials  (평문은 제어 평면만)
  defaults       { reasoning_effort: "high", max_tokens: 49152 }
  off_peak_preferred  true                      ← 비용 2배 차이를 스케줄러가 쓴다
```

이렇게 해야 (a) 모델 교체가 에이전트 버전을 올리지 않고 되고, (b) 부서별로 다른 provider를
쓸 수 있고, (c) 키가 에이전트 문서에 들어가지 않습니다.

### 호출 규약 (DeepSeek)

- **항상 스트리밍한다** — 최대 출력이 384K다. 긴 턴에서 HTTP 타임아웃을 피하고 SSE로 바로 중계한다.
- **`reasoning_effort`로 깊이를 조절한다** — 에이전트 작업은 `high`, 요약·분류는 낮게.
- **프롬프트 prefix 안정화가 압도적인 비용 지렛대다** — 캐시 히트 입력이 캐시 미스의
  **1/50** 가격이다. 시스템 프롬프트에 타임스탬프·요청 ID를 절대 넣지 않는다.
- **급하지 않은 실행은 off-peak로 민다** — off-peak 요금이 peak의 **절반**이다.
- **모델 히스토리는 매 턴 이벤트 로그에서 다시 만든다**(`derive_messages`). 하네스는 무상태다.
- **실패한 시도는 모델 히스토리에 넣지 않는다** — `agent.message_attempt` 이벤트로 **로그에만**
  남긴다(dsh의 `assistant/attempt`와 같은 발상). 부분 텍스트를 다음 요청에 섞으면 안 된다.

### 압축(compaction)

긴 세션이 컨텍스트 윈도(1M)를 넘으면 하네스가 압축합니다. 압축은 **이벤트**로 남습니다
(`agent.thread_context_compacted`, summary 포함). 그래야 다음 턴의 컨텍스트 재구성이
"압축 경계부터"로 결정적이 됩니다. 압축을 메모리에만 들고 있으면 크래시 후 재구성이 달라집니다.

---

## 12. 다음 문서

이 평면들을 코드 레이어로 나누는 규칙 → [03. 레이어 구조](03-layers.md)
