# API 규약

전체 설계는 [`plan/04-api.md`](../../plan/04-api.md). 여기는 **코드를 쓸 때 지키는 규칙**입니다.

## 두 lane은 섞이지 않는다

```
ma_api/internal/   /api/v1/*   사내 API
ma_api/compat/     /v1/*       공식 Managed Agents wire 계약
ma_api/shared/     양쪽이 쓰는 것 — 비즈니스 규칙을 넣지 않는다
```

`internal`과 `compat`은 **서로 import하지 않는다.** `import-linter`의 `independence`
계약이 강제한다. 공식 lane의 스키마에 사내 필드를 추가하지 않는다 — 그 순간 "공식 SDK
호환"이 거짓이 된다.

## 스키마

- 요청 스키마는 `extra="forbid"`. 모르는 필드는 400이다.
- **응답도 strict 스키마로 재검증한다.** 실패하면 500이고 200으로 내보내지 않는다.
  검증하지 않으면 내부 필드가 조용히 새고, 그게 사실상 공개 API가 된다.
- wire ↔ application 매퍼를 **명시적으로** 쓴다. `model_validate(obj.__dict__)` 금지.
- 라우트 핸들러에 `response_model`이 없으면 CI가 실패한다.

## 에러

두 lane 모두 같은 envelope을 쓴다.

```json
{ "type": "error", "error": { "type": "not_found_error", "message": "..." } }
```

| `error.type` | HTTP |
|---|---|
| `invalid_request_error` | 400 |
| `authentication_error` | 401 |
| `permission_error` | 403 |
| `not_found_error` | 404 |
| `conflict_error` | 409 |
| `rate_limit_error` | 429 |
| `budget_exceeded_error` | 409 |
| `approval_required_error` | 409 |
| `api_error` | 500 |

- **404는 "없음"과 "다른 워크스페이스에 있음"을 구분하지 않는다.** 존재를 누설하지 않는다.
- 재시도해도 안 되는 것은 429가 아니라 409다 (쿼터 초과 등).
- 에러 메시지에 내부 경로·스택·SQL을 넣지 않는다.

## 메서드와 경로

- 수정은 `POST /<resource>/{id}`. `PATCH`를 쓰지 않는다 (공식 계약을 따른다).
- 아카이브는 `POST /<resource>/{id}/archive` — 소프트 삭제가 기본.
- `DELETE`는 하드 삭제이고 세션·리소스·메모리에만 있다.
- 에이전트·환경·볼트는 **하드 삭제가 없다.** 과거 세션이 참조한다.

## 페이지네이션

커서 기반. offset을 쓰지 않는다 (이벤트가 계속 들어오는 테이블에서 offset은 틀린다).

```
GET /api/v1/agents?limit=50&page=<cursor>
→ { "data": [...], "has_more": true, "next_page": "<cursor>" }
```

커서는 `base64url(created_at|id)`. **인덱스가 정확히 그 순서여야 한다.**

## 멱등성과 동시성

- 모든 `POST`가 `Idempotency-Key`를 받는다.
- 이벤트 전송은 `event id = sha256(key + index)`로 결정적 생성.
- 버전 리소스는 `expected_version` → 불일치 시 409 + `actual_version`.
- 세션 이벤트는 `expected_revision`.

## 권한

**권한 판단은 L4 유스케이스에서 한다.** 라우터에서 하면 CLI·웹훅·스케줄러가 우회한다.
라우터는 principal과 `workspace_id`를 확정하는 데까지만 관여한다.

## SSE

- `after_seq`로 재연결. `Last-Event-ID`도 같은 의미로 받는다.
- 연결 시 `after_seq` 이후 영속 이벤트를 전부 보낸 뒤 실시간 전환.
- at-least-once. 클라이언트가 `event.id`로 dedupe한다.
- 15초마다 `: keepalive` 코멘트.
- 백프레셔 한도 초과 시 끊는다. 클라이언트가 재연결해 replay한다.
