# Python 규약

Python 3.13 · `uv` · `ruff` · `mypy --strict`

## 타입

- **모든 공개 함수에 타입을 붙인다.** `mypy --strict`가 강제한다.
- `Any`를 쓰지 않는다. 외부 JSON은 경계에서 `TypedDict`나 dataclass로 파싱한다.
- `dict[str, Any]`를 레이어 사이로 넘기지 않는다. 그것은 "타입을 정하지 않았다"는 뜻이다.
- 제네릭은 `list[X]`·`dict[K, V]` 내장 문법. `typing.List`를 쓰지 않는다.
- 합 타입은 `type X = A | B` (3.12+ 문법).
- `Protocol`로 인터페이스를 정의한다. ABC 상속을 쓰지 않는다 — 구현이 인터페이스 패키지를
  import해야 해서 의존 방향이 뒤집힌다.

## 불변성

- 도메인 타입은 `@dataclass(frozen=True, slots=True)`.
- 함수 기본값에 가변 객체를 쓰지 않는다. 컬렉션 기본값은 `()` 또는 `None`.
- 반환하는 컬렉션은 `Sequence`·`Mapping`으로 선언한다 (호출자가 바꾸지 못하게).

## async

- I/O 경계는 전부 `async`. 동기 I/O를 async 함수 안에서 호출하지 않는다.
- 블로킹 CPU 작업(Wasm 실행, ripgrep, 압축)은 `anyio.to_thread.run_sync`.
- 취소는 `anyio` 구조적 동시성으로. 떠도는 `asyncio.create_task`를 만들지 않는다 —
  태스크 그룹 안에서만 만든다.
- `asyncio.sleep`으로 폴링하지 않는다. DB는 `LISTEN/NOTIFY`, 큐는 `SKIP LOCKED`.

## 시간

- **`datetime.now()`를 도메인·애플리케이션 레이어에서 쓰지 않는다.** `Clock` Port를 주입받는다.
  `tools/check_architecture.py`가 검사한다.
- 전부 `datetime` with `tzinfo=UTC`. naive datetime을 만들지 않는다.
- 저장은 `TIMESTAMPTZ`, 직렬화는 RFC 3339.

## 에러

- **비즈니스 결과를 예외로 표현하지 않는다.** `version_conflict`·`not_found`는 union 결과다.
- 예외는 **불변식 위반**과 **인프라 장애**에만.
- 예외 클래스는 도메인별 기반에서 상속하고, 밖으로 나갈 때 `ma_api`가 envelope으로 변환한다.
- `except Exception:`을 쓰지 않는다. 잡을 것을 지정한다. 최상위 핸들러만 예외.
- 예외를 삼키지 않는다. 삼켜야 하면 **왜** 삼키는지 주석을 단다.

## 로깅

- 구조화 로그. `logger.info("session.claimed", session_id=..., generation=...)`.
- f-string으로 로그 메시지를 만들지 않는다 (키가 생기지 않는다).
- **비밀을 로그에 넣지 않는다.** 자격증명·토큰·모델 키. 레다크션을 기본값으로 둔다.
- 레벨: `debug`=개발용, `info`=상태 전이, `warning`=복구된 이상, `error`=사람이 봐야 함.

## 금지 패턴

| 금지 | 대신 |
|---|---|
| `os.environ` (`apps/*/config.py` 밖) | `Config` 주입 |
| `datetime.now()` (도메인·앱) | `Clock` Port |
| `CREATE TABLE` 문자열 (`ma_schema` 밖) | Alembic 마이그레이션 |
| `open()`·`Path()` (`ma_harness.tools` 안) | `resolve_in_workspace()` |
| 전역 가변 상태 | 조립 시점 주입 |
| 모듈 import 시 부수효과 | 명시적 `setup()` |
| `print()` | 로거 |
| 상대 import (`from ..x import`) | 절대 import |

처음 5개는 CI가 검사한다.

## 의존성

- 런타임 의존은 최소로. 표준 라이브러리로 되면 쓰지 않는다.
- 인터페이스 패키지(`ma_domain`·`ma_store`)는 **의존성 0**.
- provider SDK는 해당 어댑터 패키지의 의존이지 코어의 의존이 아니다.
- 버전은 `uv.lock`으로 고정. 직접 의존은 상한을 둔다 (`>=1.2,<2`).
