# SQL 규약

PostgreSQL 17. 전체 설계는 [`plan/05-database.md`](../../plan/05-database.md).

## 스키마의 유일한 진실

**`packages/ma_schema`의 Alembic 마이그레이션 하나다.** 패키지 코드에 `CREATE TABLE`을
쓰지 않는다 — `tools/check_architecture.py`가 검사한다.

## 마이그레이션

1. **앞으로만 간다.** `downgrade`는 작성하되 프로덕션에서 실행하지 않는다.
2. **스키마 먼저, 코드 나중.** 하위 호환 스키마 → 코드 배포 → (다음 릴리스에) 컬럼 삭제.
   한 릴리스에 둘을 같이 하면 롤백이 불가능해진다.
3. 앱 기동 시 자동 실행하지 않는다. **별도 Job**(`helm pre-upgrade`)으로 돌린다.
4. `pg_advisory_lock`으로 단일 실행을 보장한다.
5. 큰 테이블에 인덱스를 추가할 때는 `CREATE INDEX CONCURRENTLY`.
6. 마이그레이션 파일 이름은 `NNNN_주제.py` (`0004_governance.py`).

## 쿼리

- **`WHERE workspace_id = ?` 없는 쿼리는 리뷰에서 거부한다.** RLS가 2차 방어선이지만
  애플리케이션 필터를 빼도 된다는 뜻이 아니다.
- 파라미터 바인딩만. 문자열 포매팅으로 SQL을 만들지 않는다.
- `SELECT *`를 쓰지 않는다. 컬럼을 나열한다.
- 정렬 컬럼과 인덱스 순서를 맞춘다. `EXPLAIN`으로 확인하는 테스트를 둔다.
- N+1을 만들지 않는다. 목록 조회는 한 쿼리로.

## 동시성 — 패턴은 하나씩만

| 상황 | 기법 |
|---|---|
| 리소스 수정 충돌 | `version` CAS + 원자적 2문장 배치 |
| 이벤트 수용 충돌 | `sessions.revision` CAS, 3회 재시도 |
| 실행 claim 경합 | `FOR UPDATE SKIP LOCKED` |
| lane 중복 실행 | 부분 유니크 인덱스 |
| 중복 이벤트 | 유니크 인덱스 + `ON CONFLICT DO NOTHING` |
| 스케줄러 중복 | `pg_advisory_lock` |

**격리 수준은 기본값(`READ COMMITTED`)이다.** 모든 경합을 명시적 CAS와 유니크 인덱스로
처리하므로 `SERIALIZABLE`이 필요 없다. 올리면 직렬화 실패 재시도를 전역에 깔아야 한다.

## 인덱스

- 부분 인덱스를 적극 쓴다. `WHERE state='queued'` 같은 조건이 있으면 인덱스 크기가
  큐 길이에 비례한다.
- 복합 인덱스의 첫 컬럼은 `workspace_id`.
- 인덱스를 추가하면 **그것을 타는 쿼리의 `EXPLAIN` 테스트**도 추가한다.

## 비밀

- 평문 컬럼을 만들지 않는다. `BYTEA` 암호문 + `nonce` + `key_version`.
- cipher는 Store의 **생성자 인자**다. application Port 그래프에 넣지 않는다.

## 역할

| 역할 | 권한 |
|---|---|
| `awp_app` | 전 테이블 SELECT/INSERT/UPDATE. **`audit_log`는 INSERT/SELECT만** |
| `awp_worker` | execution·event·sandbox·usage 계열만. `credentials` 권한 **없음** |
| `awp_migrate` | DDL |
| `awp_ro` | SELECT only |

`REVOKE UPDATE, DELETE, TRUNCATE ON audit_log FROM awp_app;` 는 마이그레이션에 들어간다.
**DB가 보장하면 코드 리뷰가 필요 없다.**

## 파티션

`session_events` · `audit_log` · `usage_events`는 월 단위 `PARTITION BY RANGE (created_at)`.
스케줄러가 다음 달 파티션을 미리 만든다 — 없으면 월초에 INSERT가 실패한다.
보존 정책은 `DETACH PARTITION` → 콜드 스토리지 → `DROP`. DELETE로 지우지 않는다.
