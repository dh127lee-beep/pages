# 테스트 규약

전체 전략은 [`plan/09-codebase.md`](../../plan/09-codebase.md) §6.

## 레이어마다 다른 테스트

| 종류 | 대상 | 속도 예산 | 언제 돈다 |
|---|---|---|---|
| **아키텍처** | import 경계 · 7개 검사 | < 5s | **가장 먼저** |
| **단위** | 도메인 불변식 · 매퍼 · 정책 해석 | < 10s 전체 | 매 커밋 |
| **Store 계약** | 모든 Protocol × (memory, sql) | < 60s | 매 커밋 |
| **Port 계약** | ModelPort · SandboxPort (녹음 픽스처) | < 30s | 매 커밋 |
| **통합** | cp + worker + postgres + minio | < 5m | PR |
| **E2E** | 세션 생성→툴→승인→완료 (가짜 모델) | < 5m | PR |
| **보안** | 유출 스캔 · 경로 퍼징 · egress 우회 | < 10m | PR + 야간 |
| **모델 실측** | 실제 DeepSeek 호출 | — | 수동 / 야간 |

`make test` 순서가 이 순서다. **아키텍처가 먼저** 돌아서 레이어를 깬 PR이 느린 테스트를
기다리지 않고 바로 실패한다.

## 계약 테스트가 핵심이다

같은 스위트를 두 구현에 돌린다. 이것이 "런타임 이식성"을 주장이 아니라 사실로 만든다.

```python
@pytest.fixture(params=["memory", "sql"])
async def store(request, pg) -> AgentStore: ...
```

새 Store Protocol을 추가하면 **계약 테스트도 함께** 추가한다. CI가 커버리지를 검사한다.

## 역테스트를 쓴다

규칙이 실제로 강제되는지 확인하려면 **일부러 깨뜨려 본다.**

```sh
printf 'import sqlalchemy\n' >> packages/ma_domain/src/ma_domain/__init__.py
make arch && echo "FAIL: 위반을 못 잡았다" || echo "OK"
git checkout packages/ma_domain/src/ma_domain/__init__.py
```

작업 명세의 `검증` 절에 역테스트가 있으면 **반드시 돌린다.** 통과만 확인하는 테스트는
검사가 꺼져 있어도 통과한다.

## 가짜를 쓴다

- **모델**: `FakeModelAdapter(script=[TextDelta(...), ToolCall(...), Finish(...)])`.
  E2E가 네트워크 없이 결정적으로 돈다.
- **시간**: `Clock` Port를 주입한다. `freezegun` 같은 몽키패치를 쓰지 않는다.
- **샌드박스**: `ma_sandbox_local`. 단 `AWP_ENV=production`에서는 기동을 거부한다.
- **오브젝트 스토어**: MinIO (testcontainers).

실제 모델 호출은 `tests/model_live/`에 분리하고 `-m live` 마커로만 돈다. **비용이 든다.**

## 보안 테스트는 성공 기준과 1:1

[`plan/01-product-concept.md`](../../plan/01-product-concept.md) §7의 기준이 그대로
테스트가 된다. 기준을 추가하면 테스트도 추가한다.

| 성공 기준 | 테스트 |
|---|---|
| 자격증명 유출 0건 | `test_no_plaintext_in_sandbox.py` |
| 크래시 복구 유실 0 | `test_crash_recovery.py` |
| 이벤트 순서 | `test_event_ordering.py` |
| 부서 격리 | `test_workspace_isolation.py` |

## 쓰지 않는 것

- 구현 세부를 검사하는 테스트 (내부 함수 호출 횟수 같은 것). 리팩터링을 막는다.
- 커버리지 숫자 목표. 의미 없는 테스트를 양산한다. **계약 커버리지**를 본다.
- `sleep`으로 타이밍을 맞추는 테스트. 이벤트나 조건으로 기다린다.
- 테스트 간 순서 의존. 각 테스트는 독립적으로 돈다.
