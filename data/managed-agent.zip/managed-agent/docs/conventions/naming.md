# 이름 규약

이름이 흔들리면 레이어 매핑이 흔들립니다. 같은 개념은 **모든 레이어에서 같은 이름**을 씁니다.

## 레이어 전체를 관통하는 이름

도메인 하나는 전 레이어에서 **같은 모듈 이름**을 갖습니다.

```
ma_domain/agents.py → ma_store/agents.py → ma_store_sql/agents.py
                    → ma_application/agents.py → ma_api/internal/routes/agents.py
                    → ma_platform/modules/agents.py
```

"에이전트 기능을 고치려면 어디를 보는가"의 답이 즉시 나와야 합니다.

## 패키지

| 종류 | 형태 | 예 |
|---|---|---|
| 인터페이스 | `ma_<domain>` | `ma_store` · `ma_domain` |
| 구현 | `ma_<domain>_<backend>` | `ma_store_sql` · `ma_store_memory` |
| 어댑터 | `ma_adapters_<target>` | `ma_adapters_sql` · `ma_adapters_blob` |
| provider | `ma_<capability>_<provider>` | `ma_model_deepseek` · `ma_sandbox_wasm` |
| 앱 | 역할 이름 (`ma_` 없음) | `control_plane` · `runtime_worker` |

**패키지 이름에 세대를 넣지 않습니다** (`_v1` · `_v2` · `_new`). 세대가 이름에 들어가면
영구히 남습니다 — 레퍼런스의 `memory-store-store` · `session-runtime-contract`가 그 흔적입니다.

## ID prefix

```
wrkspc_   워크스페이스        user_     사용자
apikey_   API 키              agent_    에이전트
mdc_      모델 카드           env_      환경
sess_     세션                thrd_     세션 스레드(lane)
evt_      이벤트              exec_     실행
res_      세션 리소스          vault_    볼트
cred_     자격증명            memst_    메모리 스토어
mem_      메모리              memv_     메모리 버전
appr_     승인                apol_     승인 정책
skill_    스킬                dep_      배포
run_      배포 실행           file_     파일
sbx_      샌드박스 인스턴스     wkr_      워커 인스턴스
whe_      웹훅 엔드포인트       whd_      웹훅 전송
sched_    배포 스케줄          work_     외부 워커 작업
```

이 표는 `ma_domain.ids.PREFIXES`와 **1:1이어야 한다.**
`tests/unit/domain/test_invariants.py::test_id_prefixes_match_convention_doc`이 검사한다.

형식은 `<prefix>_<ULID>` 입니다. ULID는 시간 정렬이 되고 커서 페이지네이션과 잘 맞습니다.

## 테이블과 컬럼

| 규칙 | 예 |
|---|---|
| 테이블은 **복수형 snake_case** | `sessions` · `session_events` |
| 버전 테이블은 `<단수>_versions` | `agent_versions` · `memory_versions` |
| 조인 테이블은 `<a>_<b>` | `session_memory_stores` |
| 모든 테이블 첫 컬럼은 `id`, 둘째는 `workspace_id` | |
| 시각은 `_at` 접미사, `TIMESTAMPTZ` | `created_at` · `archived_at` |
| 불리언은 긍정형 | `enabled` (`disabled` 아님) |
| JSON 문서는 `document` 또는 역할 이름 | `document` · `pricing` · `spec` |
| 인덱스는 `idx_<테이블>_<컬럼들>` | `idx_agents_ws_created_id` |
| 부분 인덱스는 의도를 이름에 | `idx_exec_claimable` |

## 이벤트 타입

공식 CMA 분류를 그대로 씁니다 — `{domain}.{action}`.

```
user.message · user.interrupt · user.tool_confirmation · user.custom_tool_result
agent.message · agent.thinking · agent.tool_use · agent.tool_result
agent.message_attempt            ← 우리 추가. 실패 시도를 로그에만
session.status_running · session.status_idle · session.error · session.usage
span.model_request_start · span.model_request_end
system.message
```

**스트림 전용 프레임**(영속되지 않는 것)은 `system.` 아래에 둡니다 —
`system.user_message_pending` · `_promoted` · `_cancelled`.

새 이벤트 타입을 추가할 때는 `plan/04-api.md` §4.2 표를 **함께** 고칩니다.

## Port 토큰

```python
agent_store_port = PortToken[AgentStore]("ma.store.agents")
agents_port = PortToken[AgentsUseCases]("ma.app.agents")
```

문자열은 `ma.<레이어>.<도메인>` 형식입니다. `store` · `app` · `adapter` · `cap`.

## 파이썬 식별자

| 종류 | 형태 |
|---|---|
| 모듈·함수·변수 | `snake_case` |
| 클래스·타입 별칭 | `PascalCase` |
| 상수 | `UPPER_SNAKE` |
| Protocol | 역할 이름 + 명사 (`AgentStore` · `SandboxProvider`) |
| 결과 union 멤버 | 동사 과거분사 또는 상태 (`ReplacedAgent` · `AgentVersionConflict`) |
| 비공개 | `_` 접두 |

**축약하지 않습니다.** `ws` 대신 `workspace_id`, `cfg` 대신 `config`.
단 널리 쓰이는 것은 예외: `id` · `url` · `sql` · `db` · `ttl` · `ca`.
