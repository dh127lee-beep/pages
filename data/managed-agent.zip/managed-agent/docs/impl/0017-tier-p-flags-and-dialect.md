# IMPL-0017 · 티어 P — bwrap 플래그 세트, stderr 방언, Landlock 정정

| | |
|---|---|
| 날짜 | 2026-10-15 |
| 관련 | `T-0304` · [`plan/07-sandbox.md §4`](../../plan/07-sandbox.md) · [`plan/08-infrastructure.md §4`](../../plan/08-infrastructure.md) · `D6` |
| 종류 | `정정` · `배경` · `함정` |

## 요약

**이 노드에서는 티어 P 의 격리를 검증하지 못했다.** macOS 개발 머신이고
bwrap 도 컨테이너 런타임도 없다. 그래서 이 노트가 기록하는 것은 둘로 나뉜다.

| | 상태 |
|---|---|
| 플래그 조립 · 방언 분류 · 능력 보고 | **테스트로 확인** (26건, bwrap 없이 돈다) |
| 실제 격리 (쓰기·읽기·환경·네트워크) | **미검증** — Linux CI 에서 `@pytest.mark.linux` 2건이 돈다 |

그리고 계획의 Landlock 전제가 틀렸다 — **bwrap 은 Landlock 을 걸지 않는다.**

## 내용

### 1. Landlock 정정 — enforcement 는 ABI 가 아니라 프로브가 정한다

`plan/07` §4 의 티어 표는 티어 P 의 enforcement 를 *"`full` 또는 `partial`
(ABI에 따라)"* 라고 적었고, `T-0304` 의 DoD 에도 *"Landlock ABI에 따라
`full`/`partial`과 사유가 달라진다"* 가 있다. 구현해 보니 성립하지 않는다.

**(a) bwrap 은 Landlock 을 걸지 않는다.** bwrap 이 쓰는 것은 mount /
user / pid / net / ipc / uts namespace 와 capability drop, 그리고 선택적
seccomp 다. Landlock 은 별개의 LSM 이고, 걸려면 **게스트 프로세스 자신이**
`landlock_create_ruleset` → `landlock_add_rule` → `landlock_restrict_self`
를 불러야 한다.

우리는 **argv 를 감쌀 뿐 게스트 안에서 코드를 실행하지 않는다.** 그래서
그 세 호출을 할 자리가 없다. 하려면 게스트 안으로 shim 바이너리를 넣고
`bwrap … -- /shim -- <원래 argv>` 로 감싸야 하는데, 그 shim 이 게스트에
보여야 하고(`--ro-bind`), 어떤 언어로 쓰든 런타임이 게스트에 있어야 한다.
**지금 하지 않는다** — 1차 방어선(namespace)이 이미 서 있고, 2차 방어선을
위해 게스트 표면을 넓히는 것은 순이익이 아니다.

**(b) 네트워크도 ABI 4 가 아니라 `--unshare-net` 이 막는다.** 그쪽이 더
강하다 — Landlock ABI 4 는 **포트 단위** 제한인데, `--unshare-net` 은
netns 자체를 없앤다. 주소 기반 통제가 애초에 불가능하다는 `plan/07` §4.3
의 단서가 여기서 의미를 잃는다.

그래서 바꾼 것:

```
enforcement = 프로브 결과
  bwrap 없음 / 기동 실패        → unsupported  (+ 사유)
  떴는데 네 검사 중 일부 뚫림   → partial      (+ 무엇이 뚫렸는지)
  네 검사 전부 막힘             → enforced
```

Landlock ABI 는 **측정해서 `notes` 에 싣는다.** 2차 방어선을 붙일 때
(`TODO`) 이 노드에서 어디까지 되는지가 거기 있어야 한다.

ABI 탐지는 `/proc/version` 의 커널 버전을 읽지 않는다 — 배포판이 백포트하면
틀리고, 부팅 파라미터(`lsm=`)로 꺼져 있을 수도 있다. `ctypes` 로
`landlock_create_ruleset(NULL, 0, LANDLOCK_CREATE_RULESET_VERSION)` 를
직접 부르고, `ENOSYS`/`EOPNOTSUPP` 를 구분해 사유에 적는다.

**탐지 실패는 `abi=0` 이지 예외가 아니다.** 예외로 올리면 호출자가
`try/except` 를 빠뜨렸을 때 provider 조립이 통째로 죽는다 — 티어 W 로
떨어질 수 있는 상황인데도.

### 2. 능력은 **실제로 띄워 보고** 정한다

`shutil.which("bwrap")` 이 성공하는 것과 bwrap 이 도는 것은 다르다.
`RuntimeDefault` seccomp 프로필은 `clone(CLONE_NEWUSER)` 를 막고, 그것이
k8s 의 기본값이다. 바이너리만 보고 `enforced` 라고 말하면 **그 클러스터
전체가 없는 보호를 믿는다.**

`run_probe()` 가 임시 워크스페이스를 만들고 그 **바깥**에 표식을 둔 뒤,
게스트 셸 한 줄로 넷을 시험한다.

| 검사 | 뚫리면 |
|---|---|
| 바깥에 쓰기 | 격리가 없다 |
| 바깥 읽기 | 경계가 없다 |
| `$AWP_PROBE_SECRET` 상속 | `--clearenv` 가 안 먹었다 → DB DSN 이 샌다 |
| TCP 연결 | `--unshare-net` 이 안 먹었다 → PostgreSQL 에 직접 붙는다 |

게스트 스크립트를 **셸 한 줄**로 쓴 이유: 게스트에 파이썬이 있다고 가정할
수 없다. `--ro-bind /usr /usr` 는 uv 가 관리하는 인터프리터
(`~/.local/share/uv/...`)를 데려오지 않는다. `/bin/sh` 는 `--ro-bind /bin`
으로 확실히 있다.

프로브는 **프로세스당 한 번**만 돈다 (`measurement()` 가 잠금과 함께
메모이즈). 노드 능력은 프로세스 수명 안에서 바뀌지 않고, bwrap 기동은 싸지
않다. 계약 테스트의 `test_probe_is_stable_across_calls` 가 이것을 강제한다.

### 3. 플래그 세트 — 셋은 정책으로 끌 수 없다

`plan/08` §4 의 세트를 그대로 쓰되, 셋을 `REQUIRED_FLAGS` 로 고정했다.

```
--unshare-net    네트워크 전부. DB · k8s API · 인터넷
--unshare-pid    워커 프로세스의 /proc/<pid>/environ 읽기
--clearenv       워커 환경변수(DB DSN, 모델 키) 상속
```

`flags.verify()` 가 조립 결과에 셋이 다 있는지 보고, 없으면
`FlagAssemblyError` 로 **실행 전에** 죽는다.

`profile()` 이 넣는데 왜 또 보는가: `profile()` 에서 한 줄을 지우는 것은
쉽고, 지워도 기능 테스트는 "실행이 된다"로 **통과한다**. `verify()` 가
있으면 지우는 순간 깨진다. 역테스트(`test_verify_catches_a_missing_flag`)
로 `verify()` 자신이 장식이 아님을 확인한다.

#### `allow_network=True` 를 받아도 네트워크를 열지 않는다

`SandboxPolicy.allow_network` 가 참이어도 `--unshare-net` 을 유지한다.
pasta/slirp4netns 가 생기기 전(T-0402)에 여는 것은 "프록시로만"이 아니라
**"전부 열림"**이다. 인자는 받아 두되 지금은 무시하고, 그 사실을 테스트가
고정한다 — 시그니처가 나중에 바뀌지 않게.

#### 시스템 경로는 **있는 것만** 바인드한다

`--ro-bind /lib64 /lib64` 를 없는 시스템에 주면 bwrap 이 기동 자체를
실패한다. 그것은 거부가 아니라 **러너 고장**으로 보고되고, 운영자가 없는
장애를 쫓는다. `SYSTEM_PATHS` 를 순회하며 `Path.exists()` 로 거른다.

### 4. stderr 방언 — 백엔드별이다

| 종류 | 예 |
|---|---|
| **거부** | `Read-only file system` · `Permission denied` · `Network is unreachable` |
| **러너 고장** | `bwrap: Creating new namespace failed` · `bwrap: setting up uid map` |
| **양성 안내** | `bwrap: Note that sandboxing` — 먼저 지운 뒤 치명을 본다 |
| **양성 종료 코드** | `127` (command not found) — 모델이 오타를 친 것이다 |

거부 문구는 대부분 POSIX `strerror` 의 영어 문자열이다. 로케일이 바뀌면
달라지는데, `--clearenv` 가 `LC_ALL`·`LANG` 을 지우므로 게스트는 C 로케일로
뜬다. **`--clearenv` 가 방언 매칭의 전제이기도 하다**는 것이 숨은 결합이다.

`127` 을 `benign_exit_codes` 에 넣은 것이 중요하다. 넣지 않으면 모델이
없는 명령을 칠 때마다 `session.error` 가 난다 — 그것은 모델이 스스로
고칠 수 있는 실수다.

**전 백엔드 합집합을 쓰지 않는다.** 계약 테스트가 양방향으로 확인한다:
bwrap 이 `unknown import`(Wasmtime 방언)를 들고 있으면 깨지고, wasm 이
`Read-only file system`(POSIX 방언)을 들고 있으면 깨진다.

### 5. `bash` 툴 — 거부는 결과, 고장은 예외

```
종료 코드 0            → 성공. **stderr 를 보지 않는다**
거부 시그니처 일치     → ToolResult(is_error=True) → 모델에게
치명 시그니처 일치     → RunnerFailure 예외 → session.error
분류 불가(UNKNOWN)     → RunnerFailure (보수적으로)
```

종료 코드 0 에서 stderr 를 보지 않는 이유: 경고를 내는 멀쩡한 명령이 많고,
그 안에 `failed` 가 섞이면 세션마다 죽는다.

`bash` 는 `env={}` 로 서브프로세스를 띄운다. bwrap 의 `--clearenv` 가
이미 지우지만, **감금되지 않은 provider(`local`)에서도** 새지 않아야
두 겹이 된다.

출력 spill 은 `FsContext.emit()` 을 쓴다 — 직접 파일을 열면 `ADR-0008` 의
워크스페이스 경계 단일 진입점이 둘이 된다.

### 6. 이 머신에서 검증하지 못한 것

macOS 에 bwrap 이 없고, Docker/podman/colima 도 없다. 그래서:

- `test_probe_measures_real_isolation`
- `test_enforced_is_reported_only_when_measured`

이 둘은 `@pytest.mark.linux` + `skipif(bwrap 없음)` 으로 **skip 된다.**
작업 명세가 *"macOS 개발 환경에는 bwrap이 없다 → `unsupported` 보고 →
테스트는 skip. 이것이 정상이다"* 라고 적은 그대로다.

**그래서 조립 쪽을 두껍게 썼다.** `--unshare-net` 한 줄이 사라지는 사고는
격리 테스트가 아니라 조립 테스트가 잡아야 한다 — 격리 테스트는 그 사고가
난 뒤에도 Linux CI 에서만 돈다.

조립 테스트를 bwrap 없이 돌리기 위해 `as_if_bwrap_worked()` 가 프로브
결과를 주입한다. **이것이 증명하는 것은 "bwrap 이 제대로 돌 때 우리 코드가
올바른 argv 와 방언을 낸다"이지 "bwrap 이 막는다"가 아니다.** 그 구분을
테스트 docstring 에 적어 두었다.

## 남은 것 (Q3)

프로덕션 클러스터가 비특권 user namespace 를 허용하는가 — **플랫폼팀 확인
필요**. 둘 중 하나가 있어야 한다.

| 방법 | 요구 |
|---|---|
| (A) k8s user namespace | 1.33+ `UserNamespacesSupport` + `hostUsers: false` + containerd 2.0+ |
| (B) 커스텀 seccomp | `CLONE_NEWUSER`·`CLONE_NEWNS` 허용 프로필 |

둘 다 불가하면 티어 P 는 `unsupported` 로 보고되고 티어 W 만 쓴다 —
**그것으로도 돌아간다** (`IMPL-0003`: 내장 툴 8개 중 7개가 셸 없이 되고,
`run_code` Q2 통과율이 95%). 결론이 나오면 ADR 로 적는다.

## 재현

```sh
uv run python tools/probe_capabilities.py
uv run python tools/probe_capabilities.py --json
uv run pytest tests/security/test_bwrap_isolation.py -q      # Linux 에서 2건 더
uv run pytest tests/unit/tools/test_bash_tool.py -q
uv run pytest tests/contract/test_sandbox_port.py -q -k bwrap
```
