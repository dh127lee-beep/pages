# IMPL-0027 · 콘솔 — 리듀서의 상태 모양, backoff 곡선, Playwright 가 잡은 버그

| | |
|---|---|
| 날짜 | 2026-10-16 |
| 관련 | `T-0503` · `plan/04-api.md §5` · `plan/01-product-concept.md §6` |
| 종류 | `배경` · `함정` |

## 요약

이벤트 투영은 **순수 함수 하나**(`reduce`)이고, 커서·dedupe·상태가 전부
거기서 나온다. 재연결은 지수 backoff + **지터**로 하고 `random` 을
주입받아 곡선을 테스트한다. Playwright 가 단위 테스트로는 못 잡을 버그를
하나 잡았다: **스트림이 종료 이벤트 없이 닫히면 영원히 재연결하지
않았다.**

## 내용

### 리듀서의 상태 모양

```ts
interface SessionView {
  phase: "idle" | "running" | "requires_action" | "terminated" | "error";
  cursor: number;          // 본 것 중 가장 큰 seq. **-1 이 "못 봤다"**
  timeline: TimelineItem[];
  costCents: number;
  streamingText: string;   // 영속 이벤트가 오면 비운다
  error: string | null;
  seenIds: ReadonlySet<string>;  // dedupe
}
```

**`cursor` 의 초깃값이 `-1` 인 이유**: `0` 은 실제 `seq` 일 수 있다.
`0` 으로 두면 첫 이벤트를 본 뒤에도 "아무것도 못 봤다"와 구분되지 않고,
재연결이 처음부터 다시 받는다.

**`seenIds` 가 집합인 이유**: at-least-once 다. 개수나 마지막 id 로는
부족하다 — replay 가 겹치는 구간을 통째로 다시 보낸다.

### 커서는 `timeline` 에서 뽑지 않는다

`resumeFrom()` 이 `cursor` 를 그대로 쓴다. 타임라인의 마지막 `seq` 를
쓰면 **타임라인에 들어가지 않는 이벤트**(`session.usage` 등)를 재연결마다
다시 받고, 그러면 **비용이 두 번 더해진다.**

`tests/events.test.ts` 의 `타임라인에 안 들어가는 이벤트도 커서를 민다`
와 `재연결 후 replay 를 다시 접어도 비용이 두 번 더해지지 않는다` 가
이 둘을 각각 고정한다.

### 모르는 이벤트는 무시하되 **커서는 민다**

서버가 먼저 배포돼도 콘솔이 깨지지 않아야 한다 — 콘솔 배포가 서버 배포를
막으면 안 된다. 하지만 커서까지 안 밀면 그 이벤트를 **재연결마다 다시
받고**, 커서가 거기서 멈춘다.

### `requires_action` 은 경고가 아니다

`stop_reason === "requires_action"` 이면 `phase` 가 `requires_action` 이고,
배지 색은 **파랑(행동 요청)**이다. 빨간 배지를 달면 사용자가 "뭔가
잘못됐다"고 읽는데, 실제로는 **사용자가 할 일이 있다**는 뜻이다.

`error` 는 `session.error` 만 만든다. Playwright 가 `data-tone` 속성으로
그 구분을 본다 — 색을 바꾸는 리팩터가 의미까지 바꾸지 못하게.

### backoff 곡선

| | |
|---|---|
| 기본 | 500ms |
| 배수 | 2 |
| 상한 | 30초 |
| 지터 | ±50% |

```
1회: 500ms   2회: 1s   3회: 2s   4회: 4s   5회: 8s   …   상한 30s
```

**지터가 핵심이다.** 없으면 프록시가 한 번 끊겼을 때 모든 탭이 **같은
순간에** 다시 붙어 그 프록시를 다시 쓰러뜨린다.

상한이 30초인 이유: 넘으면 사용자가 "멈췄다"고 느끼고 새로고침한다 —
그러면 backoff 가 의미를 잃는다.

`backoffMs(attempt, random)` 가 `random` 을 **주입받는다.**
`Math.random` 을 직접 부르면 "지수로 늘어나는가"를 검증할 수 없고,
그러면 backoff 가 사실상 테스트되지 않는다.

### `EventSource` 를 쓰지 않는 이유

| 모자란 것 | 왜 필요한가 |
|---|---|
| 커스텀 헤더 | `x-api-key` |
| backoff 제어 | 재연결이 브라우저 몫이라 곡선을 못 정한다 |

`fetch` + `ReadableStream` 으로 직접 읽는다. 대신 **증분 파서**를 써야
한다 — 청크 경계가 프레임 가운데를 가를 수 있고, 반쪽을 버리면 이벤트가
조용히 사라진다.

### 함정 — Playwright 가 잡은 것

처음 구현은 이랬다:

```ts
await readOnce(...);
return;   // "서버가 정상 종료했다"
```

**본문이 끝난 것과 서버가 정상 종료한 것은 다르다.** 서버가 스트림을
닫는 정상적인 이유는 `session.deleted`·`session.status_terminated` 둘
뿐이다 (`plan/04` §5). 그 밖의 끝남은 프록시 타임아웃·백프레셔 절단·
네트워크다.

증상: 프록시가 연결을 끊으면 **화면이 영원히 멈춘 채로 남는다.** 사용자는
에이전트가 죽은 줄 안다. 재연결 로직은 멀쩡히 있는데 **한 번도 불리지
않는다.**

단위 테스트만 있었으면 못 잡았다 — 모든 단위 테스트가 "프레임을 주면
접는다"를 보고 있었고, "본문이 끝났을 때 무엇을 하는가"는 아무도 묻지
않았다. 브라우저에서 `연결이 끊겼습니다` 가 안 뜬 것이 신호였다.

고친 뒤 `tests/stream.test.ts` 에 단위로도 내렸다. 브라우저 테스트는
느리고, 이 판단은 순수 로직이기 때문이다.

### 테스트가 두 겹인 이유

| | 무엇을 보는가 | 서버 |
|---|---|---|
| vitest (45건) | 리듀서·파서·backoff 의 **순수 로직** | 없음 |
| Playwright (6건) | 브라우저에서의 **실제 행동** | 가로챔 |

Playwright 가 API 를 가로채는 이유: 보려는 것이 "서버가 **정확히 이것을**
보냈을 때 콘솔이 어떻게 하는가"다. 진짜 스택으로는 "중복을 보냈다"나
"연결이 끊겼다"를 재현하기 어렵고, 재현하려고 서버를 비틀면 그 비튼
서버가 테스트 대상이 된다.

진짜 스택을 지나는 경로는 `tests/e2e/` (pytest) 와 **T-0507 수용 측정**이
본다. 둘은 다른 것을 보며, 둘 다 필요하다.

### 환경 함정 — Vite preview 가 IPv6 에만 바인딩한다

Playwright `webServer.url` 을 `http://127.0.0.1:4173` 으로 두었더니
120초를 기다리다 죽었다. 이 머신에서 `vite preview` 는 `localhost` 를
`::1` 로 해석해 **IPv4 로는 연결이 거부된다.**

```sh
curl http://127.0.0.1:4173/   # Connection refused
curl http://localhost:4173/   # 200
```

`localhost` 로 바꿨다. `--host 127.0.0.1` 로도 되지만, `localhost` 쪽이
개발자가 브라우저에 치는 주소와 같다.

### 쓰이지 않던 길 하나를 열었다

`ListSessions` 포트와 두 Store 구현은 처음부터 `agent_id`·`created_by`
필터를 받았는데 **라우트가 노출하지 않았다.** 콘솔이 그것을 필요로 하면서
드러났다.

함께 고친 것:

- 쿼리 파라미터를 `session_status` → `status` 로 (옛 이름도 받는다)
- 기간 필터 `created_after`·`created_before` 추가 (양끝 포함)
- **모르는 상태는 400 이다.** 빈 목록을 돌려주면 사용자는 "세션이
  없다"고 읽는데 실제로는 오타다 — 목록 API 에서 특히 위험하다

`datetime` 을 `TYPE_CHECKING` 아래가 아니라 **런타임에** import 해야
한다. FastAPI 가 타입을 실제로 풀어야 `?created_after=…` 를 `datetime`
으로 바꿔 주고, 안 그러면 문자열이 그대로 들어온다.

## 설계에 미치는 영향

`plan/` 변경 없음.

다만 `plan/04` §5 의 "종료" 줄("`session.deleted` 또는
`session.status_terminated` 후 서버가 닫는다")이 **클라이언트 쪽 함의**를
적지 않는다: 그 둘 없이 닫힌 것은 **끊긴 것으로 다뤄야 한다.** 위 함정이
정확히 그것을 놓친 것이고, 그 함의를 여기 적어 둔다.
