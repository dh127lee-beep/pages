# IMPL-0022 · 승인 — 정책 매칭 우선순위와 표 세는 곳

| | |
|---|---|
| 날짜 | 2026-10-15 |
| 관련 | `T-0403` · [`plan/02-architecture.md §7`](../../plan/02-architecture.md) · [`plan/05-database.md §3 G10`](../../plan/05-database.md) · [`IMPL-0019`](0019-tool-registry-layering.md) |
| 종류 | `배경` · `함정` |

## 요약

- **동률이면 조이는 쪽.** 정책이 겹칠 때 임의로 고르면 같은 입력에 다른
  답이 나오고, 그 차이가 보안 경계다.
- **Store 는 표를 세지 않는다.** `required_approvals` 를 두 곳이 알면
  어긋난다.
- **거부는 한 표로 끝난다.** 승인만 수를 센다.
- **재개를 세션 이벤트로 일으킨다.** DB 상태로만 두면 워커는 모른다.

## 내용

### 1. 정책 매칭 우선순위

작업 명세가 결정 대상으로 꼽은 것이다 — *"정책 매칭 우선순위 규칙
(priority 동률 시)"*.

```
1. agent_id 가 맞는 정책 > 워크스페이스 전체 정책
2. priority 가 높은 것
3. 더 구체적인 패턴 — 'mcp__github__*' > '*'
4. 그래도 같으면 **더 엄격한 것** (높은 역할 · 많은 승인 수 · self_approval=false)
```

1번이 2번보다 앞인 이유: 에이전트별 정책을 만든 사람은 **그 에이전트에
대해 생각하고 만든 것**이다. 워크스페이스 전체 정책이 `priority=100` 이라고
그것을 덮으면, 에이전트별 정책을 만들 방법이 없어진다.

3번의 구체성은 패턴 길이로 잰다. `mcp__github__*`(14자)가 `mcp__*`(6자)를
이기고, 정확 일치는 늘 이긴다(10,000).

#### 4번이 이 노트의 요점이다

동률일 때 "리스트의 첫 번째"나 "id 순"으로 고르면 **같은 정책 집합에
다른 답**이 나올 수 있다 — 정책 하나를 지웠다 다시 만들면 id 가 바뀌고,
그러면 승인 요건이 조용히 달라진다.

`_rank` 가 역할·승인 수·self_approval 까지 정렬 키에 넣어 **동률을
없앤다.** 완전히 같은 두 정책이면 어느 쪽을 골라도 결과가 같다.

### 2. 정책이 없을 때가 가장 중요하다

맞는 정책이 하나도 없으면:

```python
DEFAULT_ROLE = Role.ADMIN
DEFAULT_REQUIRED_APPROVALS = 1
DEFAULT_SELF_APPROVAL = False
DEFAULT_EXPIRES_AFTER = 24시간
```

**"정책이 없으니 아무나"가 아니다.** 정책을 안 만든 워크스페이스에서
`always_ask` 툴이 나오면 admin 이 승인해야 한다. 느슨하게 하려면
**명시적으로 정책을 만들어야** 하고, 그 행위가 곧 기록이다.

만료 기본값이 무한이 아닌 이유: 무한 대기면 세션이 영영
`requires_action` 에 남고, 그 세션이 잡은 자원(샌드박스·워크스페이스
디스크)도 함께 남는다.

### 3. 표를 세는 곳은 한 곳이다

`ApprovalStore.decide()` 는 **표를 하나 더한다.** 상태를 올리지 않는다.
`required_approvals` 를 아는 것은 정책 레이어이고, Store 가 그 수를 알면
두 곳이 어긋난다.

```
decide()    표를 더한다 (state 는 pending 유지)
            같은 사람의 두 번째 표는 None — 혼자 4-eyes 를 못 채운다
finalize()  정책 레이어가 "찼다"고 판단했을 때 pending → approved
```

SQL 쪽 CAS:

```sql
WHERE state = 'pending' AND NOT ($3 = ANY(decided_by))
```

`NOT ... ANY` 가 핵심이다. 없으면 같은 사람이 두 번 눌러 2를 만들고,
`required_approvals=2` 가 의미를 잃는다. 두 사람이 **동시에** 눌러도
`array_append` 가 원자적이라 표가 정확히 둘이 된다.

### 4. 거부는 한 표로 끝난다

승인만 수를 센다. 반대가 하나라도 있으면 진행하지 않는 것이 fail-closed
이고, "2명 거부가 필요하다"는 규칙은 존재하지 않는다.

```sql
state = CASE WHEN $6 THEN state ELSE 'denied' END
```

### 5. 재개를 세션 이벤트로 일으킨다

승인이 `approvals` 테이블의 상태로만 남으면 **워커는 그것을 모른다.**
세션이 `requires_action` 에 영원히 남는다.

`ApprovalsUseCases._resume()` 이 `user.tool_confirmation` 을 세션에
수용한다 — T-0203 의 같은 경로다. 그래야 `session_executions` 에 outbox
행이 생기고, 워커가 claim 하고, 재개된다.

**멱등키가 `approval:{id}` 다.** 같은 승인이 두 번 재개를 일으키면 툴이
두 번 실행된다.

거부도 **같은 경로**로 간다. 턴을 죽이지 않고 `Denied: {reason}` 을
`tool_result` 로 주입해 모델이 이어 가게 한다 (`plan/02` §7 ⑤) — 모델이
다른 방법을 찾거나 사용자에게 설명할 수 있어야 한다.

만료도 재개한다. 상태만 바꾸고 말면 세션이 멈춘 채 남는다.

### 6. 레퍼런스 결함 ① 을 피했는지 어떻게 아는가

> 레퍼런스는 승인 후 툴을 재구성할 때도 `always_ask` 스트리핑이 그대로
> 적용되어 **실행 함수가 없고, 결과 없이 재개**된다.

"승인 상태가 `approved` 다"로는 그것을 잡지 못한다. 상태는 맞고 실행만
안 된 것이 그 결함이기 때문이다.

`test_resume_actually_executes` 가 **하네스 루프를 끝까지 돌려** 본다:

```
승인 전 → REQUIRES_ACTION, ran == []
승인 후 → END_TURN, ran == ["toolu_1"], tool_result 가 전사에 있다
```

`ran` 리스트가 증거다. 그리고 `IMPL-0019` §3 에서 고친 **호출 id 단위
grant** 가 없으면 이 테스트는 통과하지만 다른 테스트
(`test_a_grant_is_scoped_to_one_call_id`)가 깨진다.

### 7. 승인 사실이 모델 전사에 들어가지 않는다

`approval/asked`·`approval/decided` 는 **log-only** 다 (명세). 그것들을
세션 이벤트로 만들지 않았다 — `approvals` 테이블과 (T-0404 의) 감사 로그에
산다.

세션에 들어가는 것은 `user.tool_confirmation` 하나이고, `derive_messages`
가 그 타입을 전사에 넣지 않는다. 전사에 들어가는 것은 그 뒤에 실행된
툴의 **결과**다.

왜 중요한가: 승인 사실이 모델 컨텍스트에 있으면 모델이 "다음에는 승인을
피하는 방법"을 학습할 재료가 된다.

### 8. 요약을 자른다

`input_summary` 에 전체 입력을 담지 않는다. 담으면 둘이 나쁘다:

1. **비밀이 섞인다** — `bash` 의 명령 전체가 인박스에 그대로 뜬다.
2. **두 번째 복사본이 drift 한다** — 이미 스트리밍된 `agent.tool_use`
   이벤트가 원본이고, `tool_call_id` 로 연결하면 된다.

`truncate_summary` 가 200자에서 자른다. 호출자가 실수로 전체를 넘겨도
여기서 걸린다 — 완벽한 비밀 차단은 아니지만, 명령 전체가 뜨는 것과는
다르다.

## 남은 것 (Q6)

**기본 `always_ask` 툴 목록을 보안팀과 합의해야 한다.** 지금은 에이전트
설정이 정하고(`AgentToolset.configs`), 플랫폼이 강제하는 목록이 없다.

후보: `bash` · `write`(워크스페이스 밖) · MCP 쓰기 툴. `bash` 는 티어 P
에서만 존재하므로 그 자체가 이미 좁다.

합의되면 `ApprovalPolicy` 가 아니라 **툴 레지스트리 기본값**에 들어가야
한다 — 정책은 "누가 승인하는가"이고, "무엇이 승인을 요구하는가"는 툴의
성질이다.
