# IMPL-0008 · 수용 트랜잭션의 문장 순서와 CAS 재시도

| | |
|---|---|
| 날짜 | 2026-10-15 |
| 관련 | `T-0203` · [`plan/02-architecture.md §3 규칙 1`](../../plan/02-architecture.md) · [`plan/04-api.md §2.4`](../../plan/04-api.md) · `IMPL-0007` |
| 종류 | `함정` · `배경` |

## 요약

인터럽트 UPDATE 는 pending INSERT **보다 먼저** 와야 한다 — 뒤에 두면 인터럽트가
자기 자신과 같은 요청에 실려 온 새 메시지까지 접는다. CAS 재시도는 3회이되
클라이언트가 `expected_revision`을 **명시한 경우에는 재시도하지 않는다**.

## 내용

### 결정 — 트랜잭션 문장 순서

plan §3 규칙 1 은 네 문장을 이 순서로 적어 두었다:

```
1. revision CAS
2. pending INSERT
3. interrupt UPDATE
4. outbox INSERT
```

구현해 보니 **2와 3이 바뀌어야 한다.**

`user.interrupt`를 수용하면 3번이 그 lane 의 `cancelled_at IS NULL` 인 pending 을
전부 접는다. 그런데 2번이 먼저 돌면 **방금 들어온 인터럽트 이벤트 자신도**
그 조건에 걸린다. 결과는 두 가지로 나빴다.

- **인터럽트가 로그에 올라가지 않는다.** `user.interrupt`는 `NOT_MODEL_VISIBLE`이
  아니다 — 모델이 봐야 자기가 중단당했다는 것을 안다. 접히면 모델에게는 턴이
  그냥 증발한 것이 된다.
- **같은 요청의 새 메시지가 사라진다.** "멈추고 이거 해줘"는 흔한 조합이고,
  클라이언트는 `[user.interrupt, user.message]` 한 요청으로 보낸다. 2번이 먼저면
  그 메시지가 들어가자마자 접힌다.

고친 순서:

```
1. revision CAS
2. interrupt UPDATE (+ 그때까지 쌓인 pending 취소)
3. pending INSERT
4. outbox INSERT
```

읽는 방법: **인터럽트는 "지금까지 들어온 것을 접어라"이지 "이 요청을 버려라"가
아니다.** 이 요청의 이벤트는 인터럽트 *이후*에 도착한 것이므로 살아남는다.

테스트가 이것을 지킨다 — `test_interrupt_cancels_what_arrived_before_it`,
`test_interrupt_does_not_fold_a_message_in_the_same_request`.

> `plan/02-architecture.md` §3 의 SQL 예시는 순서가 다르다. 예시는 "네 문장이
> 한 트랜잭션"이라는 점을 보이는 것이 목적이었으므로 설계 결정이 바뀐 것은
> 아니다. 다만 그대로 베껴 쓰면 이 버그가 나온다.

### 결정 — CAS 재시도 3회, 단 명시적 revision 은 재시도하지 않는다

재시도 횟수는 3이다 (`MAX_CAS_RETRIES`). 백오프는 두지 않는다.

근거:

- 경합의 원인이 **짧다.** CAS 가 지는 경우는 다른 요청이 같은 세션에 거의 동시에
  쓴 것이고, 그 트랜잭션은 밀리초 단위로 끝난다. 백오프를 넣으면 기다리는 시간이
  경합 해소 시간보다 길어져 지연만 늘어난다.
- 경합자가 **적다.** 한 세션에 동시에 쓰는 주체는 콘솔·워커·스케줄러 정도다.
  수십 개가 몰리는 구조가 아니므로 3회면 사실상 항상 통과한다.
- 3회가 다 실패하면 그것은 경합이 아니라 **이상 상황**이다. 더 재시도하는 대신
  409 로 돌려 클라이언트가 다시 읽게 하는 편이 정직하다.

**명시적 `expected_revision`은 재시도하지 않는다.** 이것이 미묘한 지점이다.
낙관적 동시성의 뜻은 "내가 본 상태 위에서만 써라"이므로, 몰래 최신 상태를 다시
읽어 그 위에 쓰면 클라이언트가 요구한 보장을 깨는 것이다. 반대로
`expected_revision`을 주지 **않은** 클라이언트는 그 보장을 요구하지 않았으므로
재시도가 맞는 동작이다.

| 클라이언트 | CAS 실패 시 |
|---|---|
| `expected_revision` 줌 | 즉시 409 + `actual_version` |
| 안 줌 | 다시 읽고 최대 3회 재시도 |

### 함정 — 멱등 검사가 정본 로그만 보면 안 된다

첫 구현은 `events.find_by_id`만 봤다. 그러면 **아직 승격되지 않은 입력**을 못 본다.

같은 `Idempotency-Key`로 두 번 보내면:

- pending `id` 유니크와 outbox `execution_id` 유니크가 행 중복은 막는다.
- 하지만 `revision`은 **두 번 올라간다.** 클라이언트가 보기에 "같은 요청을 두 번
  보냈더니 상태가 두 번 바뀐" 것이 된다. 그 상태를 `expected_revision`으로 쓰고
  있던 다른 클라이언트는 영문 모르고 409 를 받는다.

고침: `_find_anywhere`가 정본과 pending 을 **둘 다** 본다. 수용됐는지를 묻는
질문에 "어느 테이블에 있는가"는 답이 아니다.

### 측정 — 원자성

`tests/integration/test_admission_atomicity.py`가 같은 `expected_revision`으로
두 요청을 동시에 보낸다.

| 항목 | 기대 | 결과 |
|---|---|---|
| 성공 | 1 | 1 |
| 409 | 1 | 1 |
| `sessions.revision` | 1 | 1 |
| `session_pending_events` | 1 | 1 |
| `session_executions` | 1 | 1 |

**진 쪽이 아무 행도 남기지 않는다.** 남겼다면 사용자가 보지 않은 메시지가
다음 턴에 섞여 들어갔을 것이다.

### 함정 — 두 구현이 `usage` 누적에서 갈렸다

`MemorySessionStore.accrue_usage`는 `rec.usage + cmd.usage`로 누적했고,
`SqlSessionStore`는 `usage = $4::jsonb`로 **덮어썼다**. 계약 테스트가 accrue 를
한 번만 부르고 있어서 못 잡았다.

누적이 맞다 — 덮어쓰면 턴 하나의 숫자만 남고 세션 전체 비용을 잃는다. 예산
한도(`SessionBudget`)가 그 숫자를 보므로 조용히 한도를 넘게 된다.

SQL 을 `jsonb_build_object` + `coalesce(… , 0) + $n` 으로 고치고,
`test_accrue_usage_accumulates_tokens`(3회 누적)를 계약에 추가했다.

> 교훈: **계약 테스트에서 "여러 번" 을 빠뜨리지 말 것.** 한 번만 부르는 테스트는
> 덮어쓰기와 누적을 구별하지 못한다.

## 설계에 미치는 영향

`plan/02-architecture.md` §3 의 SQL 예시 순서를 2↔3 바꿔야 한다. D1~D13 을
바꾸는 결정은 아니므로 ADR 은 쓰지 않는다 — 같은 결정의 **정확한 표현**이다.
