# IMPL-0007 · 취소된 pending은 지우지 않고 표시한다

| | |
|---|---|
| 날짜 | 2026-10-15 |
| 관련 | `T-0202` · [`plan/02-architecture.md §4`](../../plan/02-architecture.md) · `ADR-0004` |
| 종류 | `함정` · `배경` |

## 요약

인터럽트로 접힌 pending을 **삭제하지 않고 `cancelled_at`을 세운다.** 삭제하면
"사용자가 보냈는데 조용히 사라졌다"가 되어 감사로 추적할 수 없다. 구현하다가
promote 실패 경로가 그 흔적을 지우는 버그를 만들었고, 계약 테스트로 고정했다.

## 내용

### 결정 — promote 시 건너뛰기 vs 사전 삭제

T-0202의 열린 질문이었다. **건너뛰기를 택한다.**

`cancel_lane`은 `UPDATE … SET cancelled_at = now()`이고, `peek`과 promote의
`src` CTE가 둘 다 `cancelled_at IS NULL`로 거른다.

사전 삭제(`DELETE FROM session_pending_events`)를 택하지 않은 이유:

- 사용자가 메시지를 보냈다는 사실 자체가 **감사 대상**이다. 승인 워크플로(M3)와
  감사 로그(T-0404)가 "무엇이 들어왔고 무엇이 반영되지 않았는가"를 답해야 한다.
  행이 없으면 그 질문에 답할 수 없다.
- 콘솔이 `system.user_message_cancelled` 프레임을 쏜 뒤 사용자가 새로고침하면,
  "내가 보낸 그 메시지 어디 갔지"를 설명할 근거가 있어야 한다.
- 비용이 거의 없다. `idx_pending_drain`이 `WHERE cancelled_at IS NULL` 부분
  인덱스라 취소된 행은 인덱스에 들어가지도 않는다. 드레인 경로가 느려지지 않는다.

> 정리(보존 기간 지난 취소 행 삭제)는 **별도 작업**이다. 지금 두는 이유는
> 데이터가 적기 때문이고, M4의 보존 정책에서 같이 다룬다.

### 함정 — promote 실패 경로가 감사 흔적을 지웠다

`SqlSessionEventStore.promote`의 첫 구현은 "pending 에서 못 집었다"는 결과를
하나로 묶어 처리했다:

```python
# 처음 구현 — 틀렸다
if row is None:
    missed = True
...
await self._sql.execute(_DELETE_PENDING_SQL, ...)   # ← 취소된 행도 여기서 지워졌다
return await self.find_by_id(...)
```

"못 집었다"에는 **세 가지 다른 이유**가 섞여 있다.

| 이유 | pending 행 | 정본 로그 | 해야 할 일 |
|---|---|---|---|
| 이미 올라갔다 (INSERT 커밋 후 DELETE 전 크래시) | 있음 | **있음** | pending 정리 후 기존 이벤트 반환 |
| 취소됐다 | 있음(`cancelled_at`) | 없음 | **아무것도 건드리지 않는다** |
| 모르는 id | 없음 | 없음 | `None` |

셋을 가르는 것은 **정본 로그**다. `find_by_id`가 이벤트를 찾으면 1번, 못 찾으면
2번이나 3번이고 둘 다 손대지 않는다.

```python
already = await self.find_by_id(...)
if already is None:
    return None          # 취소됐거나 모르는 id — pending 은 그대로 둔다
await self._sql.execute(_DELETE_PENDING_SQL, ...)
return already
```

**메모리 구현은 처음부터 맞았다** — `find_by_id`를 먼저 보는 구조였기 때문이다.
계약 테스트가 두 구현에 같은 시나리오를 돌려 차이를 드러냈고, 그 뒤
`test_promote_skips_cancelled`에 "취소 흔적이 남아 있어야 한다"를 추가해
두 구현 모두에 못 박았다.

> 계약 테스트의 값이 여기서 드러났다. SQL만 있었으면 이 버그는 M3의 감사 작업
> 때까지 안 보였을 것이다.

### 역테스트 — 순서 불변식 테스트가 실제로 버그를 잡는가

`SqlPendingEventStore.enqueue`를 "도착 시점에 정본 로그로 직행"으로 바꿔
레퍼런스가 겪은 단일 테이블 버그를 재현했다.

```
AssertionError: assert ['evt_a0','evt_a1','evt_u0','evt_a2']
                    == ['evt_a0','evt_a1','evt_a2','evt_u0']
At index 2 diff: 'evt_u0' != 'evt_a2'
```

사용자 입력이 정확히 에이전트 턴 **중간**에 꽂혔고, 4개 테스트가 잡았다:

- `test_input_during_streaming_lands_after_not_inside` — 순서가 틀렸다
- `test_cancelled_input_never_reaches_the_model` — 취소된 입력이 로그에 들어갔다
- `test_crash_between_insert_and_delete` — `seq` PK 충돌
- `test_failed_promote_leaves_no_gap` — 실패한 promote 가 `seq`를 먹었다

### 함정 — hypothesis 기대값을 구현에서 가져오면 안 된다

property 테스트의 기대 순서는 **독립적으로** 계산한다. 구현이 만든 순서를
기대값으로 쓰면 아무것도 검사하지 않는 테스트가 된다. 시뮬레이션이 `expected`
리스트를 따로 쌓는 이유다 — "agent 는 즉시, arrive 는 큐로, drain 에서 큐를
순서대로" 라는 규칙만으로 답을 만든다.

1,000 examples 통과 (invalid 88건 포함, hypothesis 통계로 확인).

## 설계에 미치는 영향

`plan/`을 바꿀 것은 없다. D4의 `peek → INSERT → DELETE`가 그대로 성립한다.

다만 plan §4는 셋이 **별개 단계**인 것처럼 적혀 있는데, 실제로는 같은 DB라
한 트랜잭션에 묶을 수 있었다. 묶으면 흔한 경우는 원자적이고, 그래도 유니크
인덱스와 멱등 복구 경로는 남겼다 — 배치 드레인이나 커밋 결과 불확실 같은
"갈라지는 경우"가 남기 때문이다. plan 의 논증(유실보다 중복)이 그 경우에
그대로 적용된다.

`seq` 부여 방식은 `ADR-0004`에 따로 썼다.
