# IMPL-0004 · M0 툴체인 함정 세 가지

| | |
|---|---|
| 날짜 | 2026-10-15 |
| 관련 | `T-0101` · `T-0102` · `docs/conventions/testing.md` |
| 종류 | `함정` |

## 요약

M0 구현 중 **조용히 틀리는** 세 가지를 만났다. 전부 "검사가 통과했는데 실제로는 검사하고
있지 않던" 부류라, 기록해 둔다.

---

## ① `ruff format`이 마크다운 안의 Python 코드블록을 고친다

### 증상

`uv run ruff format .` 한 번에 `plan/*.md`·`docs/*.md`의 ` ```python ` 블록이
재포맷됐다. 설계 문서의 주석 정렬이 무너지고, `plan/index.html`이 원본과 어긋났다.

### 원인

ruff 0.17은 Markdown 안의 Python 코드블록을 포맷 대상으로 본다. 우리는 `.py`만
대상이라고 가정하고 있었다.

### 우회

```toml
[tool.ruff]
extend-exclude = ["ref", "screenshot", "web/console/dist", "*.md"]
```

**`plan/`은 코드가 아니다.** 포매터가 설계 문서를 말없이 고치면, 다음 사람은 그것이
의도된 모양인지 알 수 없다.

검증은 디렉터리 스캔으로 해야 한다 — 파일을 **명시적으로 넘기면** `extend-exclude`가
무시되므로(`--force-exclude`가 필요) `ruff format --check plan/x.md`는 여전히 동작한다.
실제로 쓰는 경로(`ruff format .`)로 확인할 것.

---

## ② 정규식 기반 소스 검사는 독스트링을 오탐한다

### 증상

`tools/check_architecture.py`의 "시간 주입" 검사가 `clock.py`를 걸었다. 그 파일은
`datetime.now()`를 **호출하지 않고** 독스트링에서 *언급*만 한다.

```python
"""`docs/conventions/python.md` §시간 — 도메인에서 `datetime.now()`를 쓰지 않는다."""
```

### 원인

줄 단위 정규식은 코드와 문서를 구분하지 못한다. 그리고 규약 문서를 인용하는 모듈일수록
금지 패턴을 더 많이 **적는다** — 오탐이 가장 성실한 코드에서 난다.

### 우회

AST로 호출 노드만 본다.

```python
for node in ast.walk(tree):
    if not isinstance(node, ast.Call):
        continue
    fn = node.func
    if isinstance(fn, ast.Attribute) and isinstance(fn.value, ast.Name):
        if (fn.value.id, fn.attr) in banned:
            ...
```

`check_architecture.py`의 나머지 검사 중 `CREATE TABLE`과 `os.environ`은 아직 정규식이다.
둘 다 문자열 리터럴 안에 있는 것이 **진짜 위반**이라 AST로 바꿀 실익이 적지만,
주석에서 언급하면 오탐한다 — 그때 `# noqa: env` 같은 탈출구가 이미 있다.

---

## ③ 문서와 코드가 조용히 어긋난다 — 그래서 문서를 읽는 테스트를 쓴다

### 증상

`ma_domain.events.EventType`을 쓰고 나서 `plan/04-api.md` §4.2 표와 비교해 보니:

- 표가 `session.status_running` / `_idle` 처럼 **축약**되어 있어 사람은 읽지만 기계는 못 읽었다
- `agent.message_attempt`가 표에 **빠져 있었다** (설계 결정은 `plan/02` §11과 `plan/06` §3.3에
  적혀 있는데 §4.2 표에만 없었다)
- `docs/conventions/naming.md`의 ID prefix 표에 7개가 빠져 있었다
  (`apikey` `apol` `memv` `res` `sbx` `thrd` `wkr`)

### 원인

문서를 먼저 쓰고 코드를 나중에 쓰면, 코드가 더 정확해진다. 그 차이를 사람이 발견하길
기대하면 발견되지 않는다.

### 우회

**문서를 읽어서 비교하는 테스트**를 쓴다.

- `tests/unit/domain/test_event_taxonomy.py` — `plan/04-api.md` §4.2 ↔ `EventType`
- `tests/unit/domain/test_invariants.py::test_id_prefixes_match_convention_doc`
  — `docs/conventions/naming.md` ↔ `ids.PREFIXES`

그러려면 **문서가 기계가 읽을 수 있는 모양**이어야 한다. 그래서 §4.2의 축약형을 전부
풀어 썼다. 표가 조금 길어졌지만, 읽는 사람에게도 더 낫다.

## 설계에 미치는 영향

없음. 셋 다 도구와 문서의 문제이고 `plan/`의 결정은 그대로다.

다만 **규칙 하나를 `docs/conventions/testing.md`에 추가할 만하다**: 설계 문서가 코드와
1:1이어야 하는 지점(이벤트 타입, ID prefix, 에러 코드, 상태 전이)에는 **문서를 읽는
테스트**를 둔다. 지금은 2개뿐이고, M1에서 에러 코드와 세션 상태가 생기면 늘어난다.
