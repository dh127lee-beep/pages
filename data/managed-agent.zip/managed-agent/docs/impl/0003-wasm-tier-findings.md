# IMPL-0003 · Q2 — CPython WASI 로 실제 데이터 작업이 되는가

| | |
|---|---|
| 날짜 | 2026-10-15 |
| 관련 | `T-0303` · [`plan/07-sandbox.md §3.4`](../../plan/07-sandbox.md) · `IMPL-0016` |
| 종류 | `측정` |

## 요약

**20건 중 19건 통과 (95%).** 유일한 실패는 `numpy` 이고, 네이티브 휠은
T-0303 범위에서 명시적으로 제외돼 있다.

그래서 `plan/07` §3 의 결정 — **Pyodide 재검토도, 해당 환경 티어 P 강제도
하지 않는다.** 티어 W 를 기본으로 유지한다.

예상 밖의 수확 둘: `sqlite3` 과 `xml.etree`(expat)가 **된다.** 둘 다 C 확장이라
안 될 것으로 보았는데, wasi-sdk 빌드가 정적으로 넣어 두었다.

## 측정

머신 M4 Pro · `wasmtime-py` 49 · CPython 3.12.0 (wasi-sdk-20.0) ·
`tests/fixtures/run_code_tasks.json` · 상한 `fuel=1e11, timeout=60s`.

| # | 과제 | 쓰는 것 | 결과 | 시간 |
|---|---|---|---|---|
| t01 | CSV 집계 | `csv` | ✅ | 49ms |
| t02 | JSON 변환 | `json` | ✅ | 48ms |
| t03 | 정규식 추출 | `re` | ✅ | 45ms |
| t04 | 날짜 계산 | `datetime` | ✅ | 26ms |
| t05 | 기초 통계 | `statistics` | ✅ | 59ms |
| t06 | 유니코드 정규화 | `unicodedata` | ✅ | 26ms |
| t07 | 워크스페이스 읽고 쓰기 | 파일 I/O | ✅ | 26ms |
| t08 | 디렉터리 순회 | `pathlib` | ✅ | 60ms |
| t09 | 그룹 집계 | `collections` | ✅ | 32ms |
| t10 | 상위 N 추출 | `heapq` | ✅ | 26ms |
| t11 | 해시와 인코딩 | `hashlib`·`base64` | ✅ | 47ms |
| t12 | ZIP 읽고 쓰기 | `zipfile` | ✅ | 77ms |
| t13 | gzip 압축 | `gzip` (zlib) | ✅ | 28ms |
| t14 | SQLite 질의 | `sqlite3` **(C 확장)** | ✅ | 39ms |
| t15 | 금액 계산 | `decimal` | ✅ | 35ms |
| t16 | 조합 생성 | `itertools` | ✅ | 26ms |
| t17 | 텍스트 차이 | `difflib` | ✅ | 47ms |
| t18 | XML 파싱 | `xml.etree` **(expat)** | ✅ | 57ms |
| t19 | 타임존 변환 | `zoneinfo` | ✅ | 131ms |
| t20 | 수치 배열 연산 | `numpy` **(네이티브 휠)** | ❌ | — |

**19 / 20 = 95%**

## 해석

### t19 는 처음에 실패했고, 고쳤다

`wasi-sdk` 빌드에는 타임존 데이터베이스가 없어 `ZoneInfo("UTC")` 조차
`ZoneInfoNotFoundError` 였다. tzdata 는 **순수 파이썬 휠**(340KB)이라
에셋에 끼워 넣는 것으로 해결했다 — 네이티브 확장이 아니므로 "휠 지원"
범위에 들어가지 않는다.

고친 이유: 사내 데이터 작업에서 **KST↔UTC 변환은 거의 반드시 나온다.**
340KB 로 메울 수 있는 구멍을 열어 둘 이유가 없다. 공급망 비용은 핀 하나가
늘어난 것뿐이고, `fetch_wasm_assets.py` 가 sha256 으로 검증한다.

### t20 은 고치지 않는다

`numpy` 는 네이티브 휠이고, T-0303 범위 문서에 *"하지 않는다 — 네이티브
휠(numpy/pandas) 지원"* 으로 적혀 있다.

`test_q2_task[t20]` 은 **xfail** 로 둔다. 실패를 숨기는 것이 아니라,
어느 날 통과하기 시작하면(휠 지원이 들어오면) 그것도 알아야 하기 때문이다 —
xfail 은 예상 외의 성공도 보고한다.

### 통과율이 문서 안에서만 참인 값이 되지 않게

`tests/integration/test_run_code.py::test_q2_pass_rate_has_not_regressed`
가 이 표의 숫자를 **테스트로 고정한다.** 95% 아래로 내려가면 깨진다.

개별 과제 테스트가 따로 있는데도 합계를 또 재는 이유가 그것이다 — 개별
테스트를 하나 `skip` 하면 합계가 조용히 내려가지만, 합계 테스트는 그것을
잡는다.

## 결정

| 질문 | 답 | 근거 |
|---|---|---|
| Pyodide 재검토? | **아니오** | 95% 는 재설계를 정당화하지 않는다 |
| 해당 환경 티어 P 강제? | **아니오** | 실패가 환경 의존이 아니라 패키지 하나다 |
| 네이티브 휠 지원? | **보류** | 수요가 관측되면 그때. 지금은 추측이다 |

numpy 가 실제로 필요해지면 선택지는 둘이다.

1. **티어 P** — 그 워크스페이스만 bubblewrap 으로 (T-0304).
2. **Pyodide** — 네이티브 확장을 Wasm 으로 미리 빌드해 둔 배포본.

어느 쪽이든 **수요를 보고 결정한다.** 지금 고르면 쓰지 않을 복잡도를 산다.

## 재현

```sh
uv run python tools/fetch_wasm_assets.py
uv run pytest tests/integration/test_run_code.py -q -k q2
uv run python tools/bench_sandbox.py --tier wasm --iterations 200
```

과제는 `tests/fixtures/run_code_tasks.json` 에 있다. `expect` 는 stdout
전체(양끝 공백 제거)이고, **호스트 CPython 3.13 에서 실제로 돌려 얻은
값**이다 — 손으로 적은 기대값 두 개가 틀려서 WASI 실패로 오인했던 적이
있다.
