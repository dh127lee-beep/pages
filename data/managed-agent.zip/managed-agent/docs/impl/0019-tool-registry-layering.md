# IMPL-0019 · 툴 레지스트리 — 레이어 분할과 승인의 범위

| | |
|---|---|
| 날짜 | 2026-10-15 |
| 관련 | `T-0305` · [`plan/06-harness-and-model.md §4.3`](../../plan/06-harness-and-model.md) · [`plan/02-architecture.md §7`](../../plan/02-architecture.md) · `IMPL-0013` |
| 종류 | `정정` · `함정` · `배경` |

## 요약

두 가지가 나왔다.

1. **작업 명세의 파일 배치가 레이어를 깬다.** `ma_application` (L4) 이
   `ma_harness` (L5) 를 import 할 수 없다. 책임을 쪼갰고, 쪼개고 나니 더 맞다.
2. **승인이 호출 id 가 아니라 툴 이름으로 복원되고 있었다.** 한 번 허락하면
   같은 툴의 다음 호출까지 열렸다 — 통합 테스트가 잡았다.

## 내용

### 1. 레이어 — 명세가 기대한 배치가 안 된다

`T-0305` 의 산출물 목록은 이렇게 적혀 있다.

```
packages/ma_application/src/ma_application/tools/registry.py
    build_tools(agent, *, sandbox, grants) -> ToolRegistry
```

그런데 `ToolRegistry` 와 `ToolExecutor` 는 `ma_harness` 에 있고,
`.importlinter` 의 `layers` 계약은 이렇다.

```
ma_api | ma_adapters_* | ma_harness      ← L5
ma_application                            ← L4
```

L4 가 L5 를 import 할 수 없다. 실제로 그대로 쓰니 계약이 깨졌다:

```
ma_application is not allowed to import ma_harness:
  ma_application.tools.registry -> ma_harness.registry
  ma_application.tools.registry -> ma_harness.model_port
```

`ma_harness.model_port` 가 `anyio` 를 쓰므로 **"코어는 드라이버를 모른다"**
계약도 함께 깨졌다. 두 계약이 같은 한 줄을 가리킨 것이다.

#### 쪼갠 결과

| 레이어 | 파일 | 무엇 |
|---|---|---|
| L4 | `ma_application/tools/registry.py` | **어떤 툴이 허용되는가** — 환경과 에이전트를 맞춰 보고 `ToolsetMismatch` |
| L5 | `ma_harness/registry.py` | **그 이름들로 조립** — 실행기 · 스키마 · 승인 |

L4 는 **이름만** 다룬다: `enabled_tool_names` · `check_toolset` ·
`registrable_tools` · `shell_requested`. L5 의 `build_tools` 는
`available: Collection[str] | None` 을 받아 그 밖의 내장 툴을 **등록하지
않는다.**

**쪼개고 나니 더 맞다.** 세션 생성 시점에는 실행기가 존재하지 않는다 —
그것은 워커가 턴을 조립할 때 생긴다. 생성 시점에 할 수 있는 일은 이름
판정뿐이고, 명세의 배치는 그 두 시점을 한 함수에 묶으려 했던 것이다.

### 2. 빼는 것과 `executor=None` 은 다르다

둘 다 "모델이 그 툴을 못 쓴다"지만 뜻이 반대다.

| | 뜻 | 모델이 보는 것 |
|---|---|---|
| `executor=None` 으로 등록 | **승인하면 된다** | 스키마에 보인다. 부르면 `requires_action` |
| 아예 등록하지 않음 | **이 환경에는 없다** | 보이지 않는다 |

티어 W 의 `bash` 를 전자로 두면 모델이 승인을 기다리는데, **승인해도
실행할 것이 없다.** 영원히 안 열리는 문을 계속 두드린다.

반대로 `always_ask` 툴을 숨기면 모델이 능력을 모르고, 사용자는 "왜 안
하지"를 묻게 된다. 그래서 그쪽은 **노출하되 실행기를 뗀다.**

커스텀·MCP 툴은 `available` 로 거르지 않는다 — 샌드박스가 실행하지 않으므로
티어와 무관하다.

### 3. 승인은 **호출 하나**에 붙는다 (버그 수정)

처음 구현은 이랬다.

```python
granted_names = {g.tool_name for g in grants}
if policy is ALWAYS_ASK and name not in granted_names:
    executor = None
```

`tool_call_id` 를 **받아만 두고 쓰지 않았다.** 결과: `toolu_1` 에 대한
승인 하나가 그 턴의 모든 `write` 호출을 열었다.

```
모델: write(toolu_1, "a.txt")  → 승인됨. 실행
모델: write(toolu_2, "b.txt")  → **그냥 실행됐다**
```

작업 명세가 경고한 바로 그 지점인데도 그렇게 썼다. 단위 테스트는 통과했다 —
`decide(ToolCall(id="toolu_1"))` 만 봤기 때문이다. **통합 테스트가
두 번째 호출을 넣고서야** 드러났다.

#### 고친 모양

```python
@dataclass
class ToolRegistry:
    entries: Mapping[str, ToolEntry]
    granted: Mapping[str, ToolExecutor]   # tool_call_id → 실행기

    def executor_for(self, call) -> ToolExecutor | None:
        entry = self.get(call.name)
        if entry is None: return None
        return entry.executor or self.granted.get(call.id)
```

승인을 **엔트리에 되돌려 놓지 않는다.** 엔트리는 툴 하나를 나타내고 승인은
호출 하나에 대한 것이라, 엔트리에 넣으면 범위가 넓어진다.

`loop.py` 의 실행 경로도 `entry.executor` 대신 `executor_for(call)` 을
쓰도록 바꿨다 — 안 바꾸면 `decide()` 는 ALLOW 인데 실행에서 "실행기가
없다"가 나온다.

#### 정책을 두 번 보지 않는다는 규칙은 지켰다

`IMPL-0013` 이 기록한 버그 — `decide()` 가 `entry.policy` 를 다시 읽으면
승인이 와도 `ASK` 가 유지되어 **재개가 영영 안 된다**. 이번 수정도 그
규칙을 지킨다: `decide()` 는 `executor_for()` 의 `None` 여부만 본다.
`entry.policy` 는 기록으로만 남는다.

테스트가 그것을 고정한다 —
`test_policy_is_not_re_evaluated_at_decide_time` 은 `entry.policy` 가
`ALWAYS_ASK` 로 **남아 있는 것**을 확인한 뒤 판정이 `ALLOW` 인지를 본다.

### 4. 스키마 직렬화를 바이트로 고정했다

툴 블록은 **프롬프트 접두사의 일부**다. 순서가 호출마다 흔들리면 캐시가
전부 미스되고, DeepSeek 기준 입력 비용이 **50배**가 된다 (`plan/06` §5 —
캐시 히트 $0.006 vs 미스 $0.3 / 1M).

두 축을 고정했다 (`ma_model_openai_compat.adapter.build_request`):

- **툴 배열** — 이름순 정렬
- **JSON Schema 객체 키** — 재귀적으로 정렬 (`_canonical`)

**리스트는 건드리지 않는다.** JSON 배열의 순서는 의미가 있다 — `enum` 값을
정렬하면 스키마가 달라진다. 테스트가 양쪽을 본다: 키 순서가 달라도 같은
바이트, `enum` 순서가 다르면 다른 바이트.

`len()` 이나 집합 비교로는 못 잡는다는 것이 요점이다. 같은 내용이 다른
순서로 나와도 통과하는데, 캐시에는 그것이 **완전히 다른 접두사**다.

### 5. `hooks.py` → `hooks/` 패키지

`ma_harness/hooks/permission.py` 를 만들기 위해 모듈을 패키지로 바꿨다.
기존 내용이 그대로 `hooks/__init__.py` 가 되므로 **`from ma_harness.hooks
import ...` 가 전부 그대로 동작한다** — import 를 하나도 고치지 않았다.

## 환경 티어 × 툴 등록 매트릭스

| 티어 | `bash` | `run_code` | `read`·`write`·`edit`·`glob`·`grep` | `web_fetch`·`web_search` |
|---|---|---|---|---|
| **W** (wasm) | ✗ ambient authority 0 | ✓ 에셋 있을 때 | ✓ 호스트 함수 | ✓ 신뢰 영역 |
| **P** (bwrap) | ✓ **격리가 측정됐을 때만** | ✗ | ✓ | ✓ |
| local (개발) | ✓ 막는 것이 없다 | ✗ | ✓ | ✓ |

웹 툴이 모든 티어에 있는 것이 D13 의 요점이다 — 신뢰 영역에서 돌기 때문에
**샌드박스에 네트워크가 없어도 에이전트는 웹을 본다.**

## `sandbox_mode` 는 툴마다인가 호출마다인가

**호출마다다.** `SandboxPolicy` 가 `confine()` 호출에 실리고, provider 에
고정되지 않는다 (`plan/07` §4.1). 그래서 `ToolEntry` 에 `sandbox_mode` 를
두지 않았다 — 두면 "이 툴은 지금 어떤 모드인가"를 추적해야 하고, 그 추적이
틀리면 **의도보다 넓은 권한으로 실행된다**.

승인된 1회 상향(`policy.escalated()`)이 자연히 표현되는 것도 같은 이유다.
