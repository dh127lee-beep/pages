# IMPL-0024 · RLS — 유도한 목록, 비는 쪽 실패, 아직 안 꽂힌 훅

| | |
|---|---|
| 날짜 | 2026-10-15 |
| 관련 | `T-0406` · [`plan/05-database.md §9`](../../plan/05-database.md) · [`ADR-0009`](../adr/0009-root-secret-storage.md) |
| 종류 | `함정` · `배경` |

## 요약

- **목록을 손으로 적었다가 9개를 빠뜨렸다.** 테스트가 잡았고, 스키마에서
  유도하도록 바꿨다.
- **스코프를 빼먹으면 비는 쪽으로 실패한다.** 반대였다면 설정 누락이
  전면 유출이다.
- **역할에 운영 테이블 권한이 아예 없었다.** 소유자로만 돌던 개발
  환경에서는 안 보였다.
- **`SET LOCAL` 훅이 아직 제어 평면에 꽂히지 않았다.** 실패는 시끄럽다.

## 내용

### 1. 목록을 손으로 적으면 빠진다

처음에 `SCOPED_TABLES` 를 상수 튜플로 적었다. 9개를 빠뜨렸다:

```
environments · environment_versions · session_resources · session_streams
session_threads · skills · skill_versions · worker_instances · workspace_members
```

빠진 테이블은 **그 테이블만 구멍**이다. 그리고 앞으로 생길 테이블은
전부 빠진다 — 마이그레이션을 쓰는 사람이 이 목록을 기억해야 하기 때문이다.

`test_every_scoped_table_has_rls` 가 잡았다. `workspace_id` 컬럼이 있는
테이블을 `pg_attribute` 에서 찾아 RLS 가 켜졌는지 본다.

고친 모양: **마이그레이션도 같은 질의로 유도한다.** 빼는 것만
`EXCLUDED` 에 **이유와 함께** 적고, 테스트가 그 목록을 **마이그레이션
파일에서 직접 읽는다** — 두 곳에 적으면 어긋나고, 어긋나면 테스트가
구멍을 놓친다.

#### 뺀 둘

| 테이블 | 왜 |
|---|---|
| `worker_instances` | 테넌트 데이터가 아니라 **인프라 관측**이다 (D3). `workspace_id` 가 nullable 이고, NULL 행(워크스페이스에 핀되지 않은 워커)이 가려지면 운영이 전체 워커를 못 본다 |
| `workspaces` | 이 테이블의 행이 **곧 워크스페이스 자신**이다. 자기를 자기로 거르면 목록 조회가 통째로 막힌다 |

### 2. 비는 쪽으로 실패한다

```sql
USING (workspace_id = current_setting('awp.workspace_id', true))
```

두 번째 인자 `true` 가 "없으면 에러 대신 NULL" 이다. NULL 비교는 거짓이라
**아무것도 안 보인다.**

반대였다면 — 설정이 없을 때 전부 보이게 했다면 — **설정 누락이 전면
유출**이 된다. 그리고 설정 누락은 조용하다: 코드가 잘 돌고, 테스트가
통과하고, 어느 날 다른 부서 데이터가 보인다.

쓰기도 막힌다. 그래야 "기록했다고 믿었는데 안 됐다"가 생기지 않는다.

### 3. 역할에 권한이 아예 없었다

`awp_app`·`awp_worker` 를 `0004_credentials` 에서 만들었지만, **핵심
테이블(`sessions`·`agents`·`session_events`…)에 아무 권한도 주지
않았다.** 자격증명·감사·예산에만 명시적 GRANT 가 있었다.

개발에서는 안 보였다 — DSN 이 소유자(`leedonghyeon`)를 가리키기 때문이다.
`SET ROLE awp_worker` 로 실제 접속해 보는 테스트를 쓰고서야 드러났다.

`0008_rls._grant_operational()` 이 **스키마에서 유도해** 건다.
`ALREADY_GRANTED` 는 건너뛴다 — 앞선 마이그레이션이 **일부러 좁혀 놓은**
것들이고(워커의 credentials 차단, audit_log append-only, budgets 읽기
전용), 여기서 넓히면 그 결정이 사라진다.

### 4. 워커가 우회하는 것과 그것을 보완하는 것

워커의 claim 은 **워크스페이스를 횡단한다** — 아무 claimable 한 건을
집는 것이 D3 의 설계다. 그래서 `awp_worker` 에 `BYPASSRLS` 를 준다.

구멍처럼 보이지만 **그 역할에 `credentials` 권한이 없다는 것이
보완한다** (`0004_credentials` 의 `REVOKE ALL`). 워커가 횡단해서 볼 수
있는 것은 실행 권한과 이벤트이고, 비밀은 아니다.

테스트가 **둘을 함께** 본다:

```
test_the_worker_role_crosses_workspaces      → sessions 를 횡단한다
test_the_worker_still_cannot_read_credentials → credentials 는 못 본다
```

첫 테스트를 `vaults` 로 쓰면 안 된다 — 거기서는 RLS 가 아니라 **권한**이
막아서, 다른 사실을 시험하게 된다.

### 5. `SET LOCAL` 이지 `SET` 이 아니다

`SET` 은 연결 수명 내내 남고, **연결은 풀에서 재사용된다** — 한
워크스페이스의 값이 다음 요청으로 새어 다른 부서의 데이터를 보게 된다.

`SET LOCAL` 은 트랜잭션이 끝나면 사라진다. 그래서
`ma_sql.workspace_scope.scoped()` 는 **트랜잭션 안에서만** 의미가 있고,
테스트가 그것을 고정한다 (`test_the_scope_is_transaction_local`).

#### 파라미터 바인딩이 안 된다

`SET LOCAL` 은 `$1` 을 받지 않는다. `set_config()` 함수를 쓰면 되지만
세 번째 인자(지역 여부)를 실수하기 쉽다. 그래서 **값을 검증해서** 문자열로
넣는다 — 워크스페이스 id 는 `wrkspc_` + ULID 라 영숫자와 밑줄뿐이고,
그 밖의 문자는 `ScopeError` 다.

### 6. 아직 꽂히지 않은 것

**제어 평면이 요청마다 `scoped()` 를 부르지 않는다.** 지금 구조는
`AsyncpgClient(pool)` 이고 요청별 트랜잭션 경계가 없다.

그래서 지금 상태는:

| 접속 역할 | 결과 |
|---|---|
| 소유자 (개발 DSN) | RLS 가 적용되지 않는다 (소유자는 기본 우회) |
| `awp_app` (운영) | **모든 조회가 빈다** — 스코프가 없으므로 |

**실패가 시끄럽다**는 것이 중요하다. 조용히 안전하지 않은 것이 아니라,
요란하게 아무것도 안 된다. 그래서 RLS 를 켜 두는 쪽이 끄는 쪽보다 낫다 —
배포에서 바로 드러난다.

꽂는 일은 **요청별 트랜잭션 경계**를 만드는 일이고, 그것은 스토어가
커넥션을 얻는 방식과 맞물린다. T-0406 범위를 넘으므로 여기서 하지 않고
적어 둔다.

운영 전 체크리스트:

```
1. control_plane 이 요청마다 트랜잭션을 열고 scoped() 를 부른다
2. DSN 이 awp_app 을 가리킨다 (소유자가 아니라)
3. tests/security/test_workspace_isolation.py 가 CI 에서 돈다
```

### 7. RLS 가 감사 테스트를 깨뜨렸다

RLS 를 켜자 `test_the_app_role_can_still_write_and_read` 가
`InsufficientPrivilegeError` 로 실패했다. `audit_log` 에도 정책이 걸렸고,
스코프 없이 INSERT 하려 했기 때문이다.

**올바른 동작이다.** 테스트가 스코프를 세우도록 고쳤고, 반대 경우
(스코프 없이 쓰면 막힌다)를 테스트로 추가했다.

이 상호작용이 RLS 의 성격을 잘 보여 준다 — 추가 안전장치라고 해서
투명하지는 않다. 켜면 **모든 쓰기 경로가 스코프를 요구**한다.
