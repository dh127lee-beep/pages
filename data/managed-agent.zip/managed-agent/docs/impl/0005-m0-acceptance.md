# IMPL-0005 · M0 기반 수용 보고

| | |
|---|---|
| 날짜 | 2026-10-15 |
| 관련 | `T-0101`~`T-0106` · [`task/M0-foundation/README.md`](../../task/M0-foundation/README.md) |
| 종류 | `수용 보고` |

## 요약

M0의 종료 조건 4개 중 **3개 통과, 1개 보류**(T-0106 실행은 API 키 필요).
모든 게이트가 녹색이고, 메모리·SQL 두 구현이 **같은 계약 테스트**를 통과한다.

```
make test   →  arch 7/7 · lint 통과 · mypy 64파일 0오류 · pytest 92/92
```

---

## 종료 조건 대조

| 조건 | 결과 | 근거 |
|---|---|---|
| `make test` 전 단계 통과, 레이어 위반 역테스트가 실제로 실패 | **통과** | 역테스트 6종 전부 위반을 잡았다 (아래 §역테스트) |
| 메모리·SQL 두 구현이 같은 계약 테스트를 통과 | **통과** | `tests/contract/test_agent_store.py` 12개 × 2 백엔드 |
| 선언하지 않은 Port를 꺼내면 조립 시점에 실패 | **통과** | `test_undeclared_port_fails_at_assembly` 외 9개 |
| DeepSeek 실측 숫자가 `docs/impl/0001`에 있다 | **보류** | 스크립트 3종 완성, 실행에 `DEEPSEEK_API_KEY` 필요 |

---

## 만든 것

| 작업 | 산출물 |
|---|---|
| T-0101 | uv 워크스페이스 · **패키지 25 + 앱 5** · `.importlinter` 계약 8 · `check_architecture.py` 검사 7 · Makefile · CI · compose |
| T-0102 | `ma_domain` 14모듈 — 외부 의존성 **0**, mypy strict 통과 |
| T-0103 | `ma_store` Protocol **11모듈 / 30+ Protocol** · `ma_store_memory` · 계약 테스트 틀 |
| T-0104 | Alembic `0001` — **19테이블** · `ma_sql`(포트+asyncpg+에러 정규화) · `SqlAgentStore` |
| T-0105 | `ma_platform` — PortToken · AppModule · create_app · WorkspaceAppRegistry |
| T-0106 | 스파이크 3종 (`direct_stream` · `cache_ab` · `via_dsh`) + README |

테스트 92개: 단위 56 · 계약 23 · 통합 13.

---

## 역테스트 — 게이트가 실제로 잡는가

통과만 확인하는 검사는 **꺼져 있어도 통과**한다. 일부러 깨뜨려 확인했다.

| 위반 | 잡혔나 |
|---|---|
| `ma_domain`이 `sqlalchemy`를 import | ✓ import-linter |
| 패키지에 `CREATE TABLE` | ✓ 스키마 단일 출처 |
| `config.py` 밖의 `os.environ` | ✓ 환경변수 단일 출처 |
| 도메인에서 `datetime.now()` | ✓ 시간 주입 |
| `ma_sandbox`가 `wasmtime`을 import | ✓ provider 중립 |
| `compat`이 `internal`을 import | ✓ 두 lane 독립 |

---

## 설계가 실제로 작동하는 것을 확인한 지점

**D2 스키마 단일 출처** — `CREATE TABLE`을 패키지에 넣으면 CI가 막는다. 실제로 막혔다.

**D3 실행 권한** — `idx_exec_one_running` 부분 유니크 인덱스가 DB에서 강제된다.
`test_one_running_per_lane_is_enforced_by_db`가 두 번째 `running` INSERT를 거부하는 것을
확인했다. *애플리케이션 버그로도* split-brain을 못 만든다.

**D4 이벤트 순서** — `idx_events_event_id`가 중복 `event_id`를 거부한다.
크래시 복구(T-0202)가 이 인덱스에 의존한다.

**D7 워크스페이스 = 네임스페이스** — `workspaces_slug_dns` CHECK가 `Legal_Team`을
생성 시점에 거부한다. Pod 생성 시점이 아니라 **여기서** 막힌다.

**D12 모델은 설정** — 코드 전체에 `"deepseek-flash"` 문자열이 없다 (테스트 픽스처 제외).
`model_cards` 테이블이 요금·한도·추론 파라미터를 전부 선언한다.

**CAS 2문장 원자 배치** — `test_batch_is_atomic`이 두 번째 문장 실패 시 첫 문장도
롤백되는 것을 실제 PostgreSQL로 확인했다. 이것이 깨지면 버전 역사가 깨진다.

**인덱스가 커서 순서와 같다** — `EXPLAIN`으로 확인한다. 500행에서 `idx_agents_ws_created_id`를
타고 `Seq Scan`이 없다. 2,000행 execution 큐에서 `idx_exec_claimable`을 탄다.

---

## 환경 — 계획과 다르게 한 것

| 계획 | 실제 | 이유 |
|---|---|---|
| `docker compose up -d postgres` | **Homebrew PostgreSQL 17.11** | 이 머신에 Docker가 없다. `docker-compose.yml`은 작성해 두었고 CI는 GitHub Actions service를 쓴다 |
| 패키지 22개 | **25개** | `plan/09-codebase.md` §1의 트리가 실제로 25개를 나열한다 — 요약 문장의 숫자가 틀렸다 |
| `pytest-asyncio` + `anyio` | **anyio 단독** | 둘이 각각 이벤트 루프를 만들어 `attached to a different loop`. `ma_harness`가 anyio 기반이므로 anyio로 통일 |
| (없음) | `psycopg[binary]` dev 의존 추가 | Alembic은 동기 드라이버가 필요하다. 런타임은 asyncpg 그대로 |

### 로컬에서 DB 띄우기 (Docker 없는 경우)

```sh
brew install postgresql@17
pg_ctl -D /opt/homebrew/var/postgresql@17 -l /tmp/awp-pg.log start
createuser -s awp; createdb -O awp awp
psql -U awp -d awp -c "alter user awp password 'awp';"
export AWP_DATABASE_URL="postgresql://awp:awp@localhost:5432/awp"
make migrate
```

---

## 범위를 줄인 것 — 정직하게

`ma_store`에 Protocol 30여 개를 정의했지만 **구현은 `AgentStore` 하나만** 했다
(메모리 + SQL). 나머지는 그것을 쓰는 작업이 가져온다:

| Store | 구현하는 작업 |
|---|---|
| `ExecutionStore` | `T-0201` — lease/fence 계약이 그 작업의 핵심이다 |
| `SessionEventStore` · `PendingEventStore` | `T-0202` — promote 순서 의미가 거기서 정의된다 |
| `SessionStore` | `T-0203` |
| `WorkspaceStore` · `ApiKeyStore` 등 | `T-0206` |
| `CredentialStore` | `T-0401` |

`tools/check_architecture.py`의 **계약 커버리지 검사를 이에 맞게 정밀화**했다 —
"모든 Protocol"이 아니라 "**구현이 있는** Protocol"에 계약 테스트를 요구한다.
`MemoryXStore`가 생기는 순간 테스트가 없으면 CI가 실패한다. 미리 비워 둔 칸이 아니라
**구현과 함께 따라오는 요구**다.

`AgentStore`는 버전 관리 리소스의 **표준형**이다. `environments`·`skills`는 같은 모양이므로
그 파일 셋(Protocol / memory / sql / 계약 테스트)을 복사하면 된다.

---

## 다음

`T-0106` 실행 — API 키와 예산 상한을 정하고 돌린다. off-peak(한국시간 19시 이후 또는
13–15시, 주말)에 돌리면 요금이 절반이다.

```sh
export DEEPSEEK_API_KEY=...
uv run python spikes/deepseek/direct_stream.py --budget-usd 5
uv run python spikes/deepseek/cache_ab.py --budget-usd 5
```

그 결과가 `T-0204`(ModelPort 중립 어휘)와 `T-0205`(하네스 기본값)의 입력이다.
`T-0201`(실행 권한)은 **T-0106과 무관하게 지금 시작할 수 있다** — M1의 임계 경로다.
