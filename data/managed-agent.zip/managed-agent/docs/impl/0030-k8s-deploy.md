# IMPL-0030 · k8s 배포 — KEDA 질의, 매니페스트가 책임지는 보안, 못 본 것

| | |
|---|---|
| 날짜 | 2026-10-16 |
| 관련 | `T-0506` · `plan/08-infrastructure.md` 전체 · `plan/07-sandbox.md §6.2` |
| 종류 | `배경` · `측정` |

## 요약

KEDA 트리거 질의는 **만료된 lease 도 센다** — 안 세면 워커가 다 죽었을
때 0 을 유지하고 복구가 영원히 안 일어난다. egress 5조건 중 셋을
**차트가 책임지고 렌더 테스트가 지킨다** (런타임 프로브와 다른 종류의
증거다). 그리고 **클러스터가 없어 못 본 것 셋**을 DoD 에 `[~]` 로
남겼다.

## 내용

### KEDA 질의 — 만료된 lease 를 세는 이유

```sql
SELECT count(*) FROM session_executions
WHERE workspace_id = '<부서>'
  AND (state = 'queued'
       OR (state = 'running' AND lease_expires_at < now()))
```

`queued` 만 세면 이런 일이 생긴다:

1. 워커 Pod 가 전부 죽는다 (노드 장애).
2. 그 lane 들은 `running` 으로 남아 있다 — lease 가 아직 안 끊겼다.
3. KEDA 가 `queued = 0` 을 보고 **0 을 유지한다.**
4. lease 가 만료돼도 **집어 갈 워커가 없다.**

**lease 가 만료된 `running` 행은 아무도 처리하지 않는 일**이므로 큐에
있는 것과 같다. 그래서 센다.

`targetQueryValue: 2` — 워커 하나가 lane 두 개를 감당한다는 뜻이다
(`concurrency: 4` 지만 여유를 둔다). `cooldownPeriod: 300` 은 긴 턴을
끊지 않기 위한 값이고, lease TTL 90초보다 넉넉하다.

**질의를 진짜 DB 에 돌렸다.** 매니페스트가 유효한 것과 질의가 도는
것은 다르다 — 틀린 질의의 증상은 "워커가 안 뜬다"이지 "질의가
틀렸다"가 아니다.

| 확인 | 결과 |
|---|---|
| 세 overlay 의 질의가 전부 실행된다 | ✓ |
| `queued` 행을 넣으면 숫자가 1 오른다 | ✓ |

### Deployment 에 `replicas` 를 두지 않는다

KEDA 가 켜져 있으면 **`spec.replicas` 를 쓰지 않는다.** 두면 배포마다
helm 이 그 값을 되돌리고, scale-to-zero 가 "배포할 때마다 1 로
올라갔다 다시 0" 이 된다.

개발 overlay 는 KEDA 를 끄므로 `replicas: 1` 을 쓴다 — 개발 클러스터에
KEDA 가 없을 수 있고, 없으면 아무도 replicas 를 쥐지 않아 0 으로 남는다.

### 워커에 PDB 를 두지 않는다

`plan/08` §3 이 그렇게 적었고, 이유를 여기 적는다: **PDB 와
`terminationGracePeriodSeconds` 가 싸운다.** 노드 드레인이 PDB 때문에
막히면 kubelet 이 Pod 를 못 내리고, 그동안 drain 은 이미 끝나 있다.
결국 둘 다 제 일을 못 한다.

워커는 drain 이 처리한다: SIGTERM → 새 claim 중단 → 진행 중인 턴 완주
→ 종료. 넘기면 SIGKILL 이고 **lease 만료 경로로 복구된다** — 두 경로
모두 T-0207 이 테스트했다.

제어 평면에는 PDB 를 **둔다.** 전부 빠지면 새 입력과 SSE 가 끊긴다.

### drain 시간이 두 곳에 있다

`terminationGracePeriodSeconds` (kubelet) 와 `AWP_DRAIN_TIMEOUT_SECONDS`
(앱) 가 **같은 값이어야 한다.** 다르면:

- 앱이 더 길면: kubelet 이 SIGKILL 하고 턴이 중간에 끊긴다
- 앱이 더 짧으면: 앱이 먼저 포기하고 남은 시간을 그냥 기다린다

둘 다 `worker.drainSeconds` 에서 나오고, 렌더 테스트가 **같은 숫자인지
확인한다.**

### 매니페스트가 책임지는 egress 조건

`plan/07` §6.2 의 다섯 중 셋은 Pod 명세와 NetworkPolicy 가 정한다.
`tools/probe_capabilities.py --egress` 는 그것들을 `unknown` 으로
보고한다 — 프로세스 안에서 확인할 수 없기 때문이다.

이제 **두 종류의 증거가 있다**:

| | 무엇을 말하는가 |
|---|---|
| 런타임 프로브 | "이 노드에서 **지금** 참인가" |
| `test_helm_render.py` | "배포가 **그렇게 만드는가**" |

①(default-deny) ③(hostNetwork) ④(SA 토큰) 은 차트가 책임지고 렌더
테스트가 지킨다. **②(CNI 강제)만은 둘 다 닿지 못한다** — 클러스터에서
우회를 시도해 봐야 알 수 있다. 그것이 그 줄이 영원히 `unknown` 인
이유다.

### `hostNetwork` 가 특히 중요한 이유

`hostNetwork: true` 면 Pod 가 노드의 netns 를 쓰고, **NetworkPolicy 가
적용되지 않는다.** 정책이 멀쩡히 있어도 아무 일도 하지 않는다 —
"정책을 썼는데 강제되지 않는" 가장 조용한 경로다.

### NetworkPolicy selector 가 어긋나는 사고

정책의 `podSelector` 와 Deployment 의 `labels` 가 다르면 **정책이
아무도 선택하지 않는다.** 매니페스트는 유효하고, `kubectl get
networkpolicy` 에도 보이고, 강제만 사라진다.

렌더 테스트가 그 둘을 맞대어 본다. `_helpers.tpl` 에 라벨을 모은 이유도
같다.

### 기본 거부를 먼저 건다

부서 네임스페이스마다 `default-deny`(podSelector 비움)를 먼저 걸고 그
위에 허용을 얹는다. 허용 정책만 쓰면 **그것이 지워졌을 때
네임스페이스가 통째로 열린다** — 정책 삭제는 정책 추가보다 쉽게
일어난다 (리팩터, 잘못된 prune).

### ResourceQuota 는 limits 까지 건다

`requests` 만 걸면 limit 이 큰 Pod 가 노드를 먹는다. 그리고 LimitRange
가 **기본값을 줘야 한다** — ResourceQuota 는 limit 을 선언한 Pod 만
세므로, 기본값이 없으면 limit 없는 Pod 가 Quota 를 **우회한다.**

### 마이그레이션 — `pre-upgrade` + advisory lock

둘 다 쓴다. helm 훅이 Job 하나만 돌리지만, 재시도·동시 배포·수동
실행이 있을 수 있다. alembic 의 `pg_advisory_lock` 이 이중 안전이다.

`hook-delete-policy: before-hook-creation` — **실패한 Job 을 남긴다.**
지우면 왜 배포가 실패했는지 로그가 없다.

### Argo CD — 프로덕션은 자동 동기화하지 않는다

dev·staging 은 `automated`, 프로덕션은 아니다. **동기화가 곧 스키마
변경**이기 때문이다 (`pre-upgrade` Job). 되돌릴 수 없는 변경이 아무도
안 볼 때 일어나면 안 된다.

프로덕션의 `targetRevision` 은 태그다 — `main` 을 보면 머지가 곧
배포다.

### 티어 P 는 PSS 를 내린다 — 그 사실을 드러낸다

`worker.tier=process` 면 부서 네임스페이스의
`pod-security.kubernetes.io/enforce` 가 `restricted` → `baseline` 이
되고 `hostUsers: false` 가 붙는다.

**완화를 한 줄로 드러내는 것이 요점이다.** 조용히 하면 "왜 이
네임스페이스만 baseline 이지"를 나중에 아무도 설명하지 못한다.
기본은 티어 W 이고, 그것은 Restricted 를 **그대로** 통과한다.

### 함정 — helm `--set` 이 배열에 구멍을 만든다

`--set departments[9].slug=x` 를 쓰면 인덱스 1~8 이 `nil` 이 되고
템플릿이 `nil pointer` 로 터진다. 테스트가 "부서를 추가하면"을
그렇게 썼다가 걸렸다.

`--set-json 'departments[N]={...}'` 로 **기존 길이 다음 인덱스**에
붙인다.

### 함정 — CRD 는 기본으로 검사되지 않는다

`kubeconform -ignore-missing-schemas` 만 쓰면 `ScaledObject` 와
`ServiceMonitor` 가 **조용히 skip 된다.**

```
Summary: 46 resources found - Valid: 38, Invalid: 0, Errors: 0, Skipped: 8
```

오타 난 필드가 통과하고 클러스터에 올려야 알게 된다. datreeio CRD
카탈로그를 `-schema-location` 으로 더하면 `Skipped: 0` 이 되고, 테스트가
**그 0 을 확인한다.**

오프라인에서는 카탈로그를 못 받으므로 내장 스키마만 보고 **skip 사유에
"CRD 는 검사하지 않았다"를 적는다** — 조용히 통과시키지 않는다.

## 못 본 것

클러스터가 없다. 세 가지를 확인하지 못했고 DoD 에 `[~]` 로 남겼다.

| | 왜 못 봤나 | 대신 한 것 |
|---|---|---|
| KEDA 가 실제로 0 으로 내린다 | KEDA 가 필요하다 | 질의를 **진짜 DB 에** 돌리고, 큐가 늘면 숫자가 오르는 것을 확인 |
| NetworkPolicy 가 실제로 강제된다 | CNI 가 필요하다 | 매니페스트가 selector·포트·기본 거부를 올바로 내는지 확인 |
| 롤링 중 턴이 안 끊긴다 | 클러스터가 필요하다 | drain 자체는 T-0207 이 봤다. 여기서는 grace period 와 앱 설정이 **같은 숫자**인지 확인 |

세 번째가 가장 근접하다 — 프로세스 수준 drain 은 이미 테스트됐고,
남은 것은 "kubelet 이 그만큼 기다려 주는가"뿐이다.

## 설계에 미치는 영향

`plan/` 변경 없음.

**Q4(부서별 네임스페이스 vs 공유 워커 풀)는 열어 둔다.** 차트가 부서별
네임스페이스로 구현했지만, `plan/08` §2 가 "부서 3개 이하면 공유 풀"을
대안으로 둔다. 부서 수가 확정되면 ADR 로 닫는다 — 지금 닫으면 숫자
없이 결정하는 셈이다.
