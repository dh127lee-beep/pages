# IMPL-0006 · claim 경합과 `reclaim_expired`의 역할

| | |
|---|---|
| 날짜 | 2026-10-15 |
| 관련 | `T-0201` · [`plan/02-architecture.md §3`](../../plan/02-architecture.md) · [`plan/05-database.md §3 G5`](../../plan/05-database.md) · `ADR-0003` |
| 종류 | `측정` · `함정` |

## 요약

`FOR UPDATE SKIP LOCKED`만으로는 "한 lane에 running 하나"가 보장되지 않는다 —
부분 유니크 인덱스가 실제로 걸린다. `claim`은 그 충돌을 예외가 아니라 "claim 실패"로
번역한다. 그리고 큐가 10만 건이어도 claim p95는 변하지 않는다(0.98배, 버퍼 5개).

## 내용

### 함정 1 — `SKIP LOCKED`는 lane 단위 배타를 주지 않는다

`SKIP LOCKED`가 보장하는 것은 **두 워커가 같은 행을 집지 않는다**이지,
**두 워커가 같은 lane을 집지 않는다**가 아니다.

같은 lane에 queued가 두 건 있으면:

1. 워커 A가 행 #1을 잠근다. 워커 B는 #1을 건너뛰고 #2를 잠근다.
2. 둘 다 `NOT EXISTS (... state='running' ...)`를 통과한다 — 아직 아무도 커밋을
   안 했으므로 둘 다 "이 lane에 running 없음"으로 본다.
3. 둘 다 `state='running'`으로 UPDATE한다.
4. `idx_exec_one_running`(부분 유니크)이 **둘 중 하나를 떨어뜨린다.**

처음 작성한 코드는 이 `UniqueViolation`을 그대로 올렸고, 8워커 동시 claim 테스트가
불규칙하게 깨졌다. 재현은 쉽지 않다 — 혼자 돌리면 통과하고 전체 스위트에서만
가끔 깨진다. **동시성 버그의 전형적인 모습**이다.

#### 우회

예외가 아니라 **결과**로 번역한다. 진 워커에게 맞는 답은 "claim 실패(None)"다.

```python
try:
    row = await self._claim_once(lane_filter, tuple(args))
except UniqueViolation:
    return None
```

`NOT EXISTS` 조건은 그대로 둔다. 그것이 있으면 **대부분의** 경합이 DB까지 가기
전에 걸러지고, 유니크 인덱스는 남은 틈을 막는 마지막 방어선이 된다. 둘 중 하나만
두면 안 된다 — `NOT EXISTS`만 두면 위 경합이 통과하고, 인덱스만 두면 모든 경합이
예외 경로로 흐른다.

> 이것이 **부분 유니크 인덱스를 둔 이유가 실제로 작동한 사례**다. 애플리케이션
> 로직이 틀렸을 때 DB가 split-brain을 막았다.

### 함정 2 — `$1 + $2::interval`에서 `$1`이 interval로 추론된다

```
DatatypeMismatchError: column "lease_expires_at" is of type timestamp with time zone
but expression is of type interval
```

`renew`의 `SET lease_expires_at = $1 + $2::interval`에서 `$1`을 묶어 줄 단서가
없으면 PostgreSQL이 `interval + interval`로 추론한다. `claim`은 같은 식을 쓰는데
멀쩡했다 — 거기서는 `$1`이 `e.lease_expires_at < $1` 비교에도 쓰여 타입이 고정됐다.

우회: 파라미터에 **항상 명시적으로 캐스팅한다.** `$1::timestamptz + $2::interval`.

### 측정 — 큐 깊이와 claim 지연

```sh
uv run python tools/bench_claim.py --queued 100000
```

| 조건 | p50 | p95 | max | 비고 |
|---|---|---|---|---|
| queued 400건 | 0.22ms | 0.35ms | 0.66ms | 기준선 |
| queued 100,000건 | 0.22ms | 0.34ms | 0.63ms | **0.98×** |

`EXPLAIN (ANALYZE, BUFFERS)`:

```
Limit  (actual time=0.003..0.004 rows=1 loops=1)
  Buffers: shared hit=5
  ->  Incremental Sort (Presorted Key: created_at)
        ->  Index Scan using idx_exec_claimable on session_executions e
              Buffers: shared hit=5
```

**버퍼 5개.** 큐가 10만 건이든 400건이든 같다. `idx_exec_claimable`이
`state='queued'` 부분 인덱스이고 `created_at` 순서가 `ORDER BY`와 같기 때문에
PostgreSQL이 첫 행만 보고 멈춘다.

이 숫자가 중요한 이유는 성능이 아니라 **장애 거동**이다. claim이 큐 깊이에
비례하면 밀릴수록 느려지고, 느려져서 더 밀린다. 0.98배는 그 되먹임이 없다는 뜻이다.

### 결정 — `reclaim_expired`는 폴링으로 돌리지 않는다

T-0201의 열린 질문이었다: 만료 lease 회수를 주기적 폴링으로 할 것인가,
`claim`이 겸하게 할 것인가.

**`claim`이 겸한다. 폴링 잡은 두지 않는다.**

`claim`의 조건이 이미 `state='queued' OR (state='running' AND lease_expires_at < now)`
이므로 만료된 lease는 자동으로 다시 집힌다. 폴링 잡을 따로 두면:

- 컴포넌트가 하나 늘고, 그것이 죽었는지 지켜봐야 한다.
- 폴링과 claim이 같은 행을 두고 경쟁해 위 함정 1을 한 번 더 만든다.
- `queued`로 되돌리는 순간과 claim 사이에 틈이 생긴다 — 그 틈에 아무도 안 집으면
  아무것도 나아지지 않는다.

`ExecutionStore.reclaim_expired()`는 **남겨 두되 운영 도구로만 쓴다**: 만료 건수를
세는 관측 경로와, `attempt_count`를 정확히 맞춰야 하는 수동 개입용이다. 워커
루프는 호출하지 않는다.

> 되돌리기 싸다. 폴링이 필요해지면(예: 만료 건이 claim 되지 않고 오래 남는 현상이
> 관측되면) T-0207의 워커 루프에 `reclaim_expired` 호출을 한 줄 넣으면 된다.

### 함정 3 — 테스트에서 "lease 탈취"를 시간으로 만들면 흔들린다

`clock.advance(TTL+1)` 후 `claim`을 부르는 테스트가 불규칙하게 깨졌다. 그 사이에
호스트의 하트비트가 끼어들어 lease를 다시 늘릴 수 있다.

우회: 소유권 이전을 **한 문장으로** 한다 (generation을 원자적으로 +1). 재현하려는
것은 "lease가 어떻게 만료됐는가"가 아니라 "generation이 움직인 뒤 호스트가 어떻게
행동하는가"다.

## 설계에 미치는 영향

`plan/`을 바꿀 것은 없다. D3이 말한 것이 그대로 성립한다 — 오히려 "부분 유니크
인덱스를 마지막 방어선으로 둔다"는 부분이 실제로 필요했음이 확인됐다.

TTL·하트비트 수치의 근거는 `ADR-0003`에 따로 썼다.
