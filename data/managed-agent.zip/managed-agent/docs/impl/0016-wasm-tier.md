# IMPL-0016 · 티어 W — WASI 버전, fuel 눈금, 에셋 출처

| | |
|---|---|
| 날짜 | 2026-10-15 |
| 관련 | `T-0303` · [`plan/07-sandbox.md §3`](../../plan/07-sandbox.md) · `IMPL-0003` |
| 종류 | `정정` · `측정` · `함정` |

## 요약

세 가지가 계획과 달랐다.

1. **WASI preview 2 를 못 쓴다.** `wasmtime-py` 49 에 Component Model API 가
   없다. preview 1 로 갔고, 우리가 기대던 보안 성질은 **그대로 성립한다** —
   단, "소켓 import 가 전부 없다"는 처음 적은 문장은 **틀렸다**. 실제로는
   *만드는* 함수만 없다.
2. **세션마다 `Engine` 을 만들면 프로비저닝이 165ms 다.** 예산 50ms 의 세
   배였다. Wasmtime 의 격리 단위는 `Store` 지 `Engine` 이 아니다 — 공유하니
   0.003ms 가 됐다.
3. **fuel 기본값 2e9 는 0.18초치였다.** CPython 기동만으로 244M 을 쓴다.

## 내용

### 1. preview 2 가 아니라 preview 1 이다

`plan/07` §3 은 WASI preview 2(Component Model)를 전제했다. `wasmtime-py`
49 에는 그 API 가 **없다** — `WasiConfig` 하나뿐이고 그것이 preview 1 이다.

우리가 p2 에서 쓰려던 것은 `wasi:http` 하나뿐이었고, 그것은 **애초에 쓰지
않기로 한 것**이다 (`plan/07` §3.3 — HTTP 는 호스트 쪽에서 일어나고,
T-0402 의 egress 프록시가 맡는다). 그래서 잃은 것이 없다.

#### 소켓에 대한 정정 — **"import 가 없다"가 아니다**

처음에 나는 이렇게 적었다: *"`wasi:sockets` 를 제공하지 않는다 — import 가
존재하지 않는다."* 실측해 보니 **절반만 맞다**. `define_wasi()` 가 정의하는
것을 전수 조사했다.

| 함수 | 정의되는가 | 무엇을 하는가 |
|---|---|---|
| `sock_open` | **아니오** | 소켓을 만든다 |
| `sock_connect` | **아니오** | 바깥으로 연결한다 |
| `sock_bind` | **아니오** | 주소에 묶는다 |
| `sock_listen` | **아니오** | 듣는다 |
| `sock_accept` | 예 | **이미 있는** 리스닝 fd 에서 받는다 |
| `sock_send` | 예 | **이미 있는** 소켓 fd 로 보낸다 |
| `sock_recv` | 예 | **이미 있는** 소켓 fd 에서 받는다 |
| `sock_shutdown` | 예 | **이미 있는** 소켓 fd 를 닫는다 |

preview 1 은 설계상 "게스트가 소켓을 만들 수 없고, 호스트가 preopen 으로
건네준 소켓 fd 만 쓸 수 있다"이다. 그래서 주장은 다음과 같이 **바뀌어야**
한다.

> ~~소켓 함수가 존재하지 않는다~~
> → **게스트가 소켓 descriptor 를 얻을 길이 없다.**

근거 둘:

- 만드는 함수 넷이 Linker 에 없다 (위 표).
- 우리는 **디렉터리만 preopen 한다.** 소켓 fd 를 건네주는 코드가 없다.

두 번째는 코드를 읽어 믿는 대신 실행으로 확인한다 —
`tests/integration/test_run_code.py::test_no_descriptor_in_the_guest_is_a_socket`
가 `sock_accept` 를 fd 0~31 에 전부 걸어 본다. 결과:

```
fd 0‥3   errno 57  ENOTSOCK   (stdin/stdout/stderr/preopen — 소켓이 아니다)
fd 4‥31  errno  8  EBADF      (그런 fd 가 없다)
```

0 이 하나라도 나오면 소켓이 새어 들어간 것이고, 테스트가 깨진다.

**왜 이 정정이 중요한가**: 틀린 근거로 맞는 결론을 지키고 있으면, 근거가
바뀌는 날(예: preopen 에 소켓을 하나 추가하는 변경) 결론이 조용히 무너진다.
`enforced` 는 보고되는 사실이므로 그 근거도 사실이어야 한다.

### 2. `Engine` 은 프로세스에 하나다

처음 설계는 `SessionStore` 가 자기 `Engine` 을 들었다. "세션당 Wasmtime
인스턴스"라는 과제 문구를 그대로 읽은 결과다. 벤치가 그것을 깼다.

| 구성 | 프로비저닝 p50 |
|---|---|
| 세션마다 `Engine` + `Linker` | **165ms** |
| 세션마다 `Engine`, 모듈 캐시만 | 165ms (바뀌지 않는다) |
| `Engine`·`Linker`·모듈 공유 | **0.003ms** |

비싼 것은 모듈 컴파일이 아니라 **새 엔진에 대고 `Linker.define_wasi()` 를
다시 하는 것**이었다. 모듈만 캐시해도 값이 안 떨어진 이유가 그것이다.

공유해도 격리가 흐려지지 않는다. Wasmtime 에서

- `Engine` — 컴파일된 코드와 그 메모리. **상태가 없다.**
- `Store` — 선형 메모리, 테이블, fuel, epoch deadline, WASI 컨텍스트.
  **여기에 전부 들어 있다.**

세션이 서로 볼 수 있는 것은 `Store` 안에 있고, `Store` 는 호출마다 새로
만든다. 공유 엔진은 같은 프로세스의 두 세션이 **같은 기계어를 읽는다**는
뜻일 뿐이고, 그것은 두 세션이 같은 `python` 바이너리를 쓰는 것과 같은
의미의 공유다.

`epoch_ticker` 도 따라서 공유한다. 세션마다 틱 스레드를 띄우면 동시 세션
수만큼 틱이 빨라지고 **모든 세션의 타임아웃이 함께 짧아진다** — 참조 수를
세어 하나만 돈다.

#### 모듈 캐시 — 두 겹

| 경로 | 비용 |
|---|---|
| 엔진별 메모리 캐시 적중 | ~0ms |
| `Module.deserialize_file` (`python.cwasm`) | 1.4ms |
| `Module.from_file` (`python.wasm`, 20MB) | **314ms** |

`.cwasm` 은 `python.wasm` 을 처음 컴파일할 때 원자적으로 떨어뜨린다
(`os.replace` — 워커 여러 개가 동시에 써도 반쪽 파일이 남지 않는다).
Wasmtime 버전이 바뀌면 `deserialize_file` 이 실패하고, 그때는 조용히 다시
컴파일한다. **캐시는 신뢰 경계 안이다** — 우리가 방금 직렬화한 것이고
같은 호스트만 읽는다.

측정(M4 Pro, 200회):

```
첫 세션      1.668ms   (모듈 적재 + Linker 구성)
이후 세션    p50 0.003ms  p95 0.004ms  p99 0.005ms
첫 run_code  p50 25.3ms   (CPython 인터프리터 기동)
```

프로비저닝 예산 50ms 는 **세 자릿수 여유**로 지켜진다. 실제 체감 비용은
프로비저닝이 아니라 **호출마다 드는 CPython 기동 25ms** 다 — 그것은
"호출마다 새 인스턴스"의 값이고, 치르기로 한 값이다.

### 3. fuel ↔ CPU 시간

`DEFAULT_FUEL = 2_000_000_000` 은 측정 없이 고른 값이었고, **0.18초치**였다.

| 과제 | fuel | 시간 |
|---|---|---|
| CPython 기동 (빈 스크립트) | 244M | 27ms |
| `import json, re, csv, …` | 639M | 65ms |
| 10만 회 정수 루프 | 938M | 87ms |
| 100만 회 정수 루프 | 6.91G | 617ms |
| CSV 1만 행 집계 | 1.43G | 115ms |

→ **≈ 11.2 G fuel / 초** (`FUEL_PER_SECOND`). 워크로드마다 다르다 —
`while True: pass` 같은 조밀한 루프는 같은 fuel 을 더 빨리 태운다. 그러므로
이 값은 **상한을 고를 때의 눈금**이지 변환 공식이 아니다.

바꾼 값:

```python
FUEL_PER_SECOND     = 11_200_000_000   # 측정 눈금
CPYTHON_STARTUP_FUEL=    250_000_000   # 이보다 낮으면 print 도 TIMEOUT
DEFAULT_FUEL        = 400_000_000_000  # ≈35초, 기본 타임아웃 30초보다 넉넉히
```

**fuel 이 epoch 보다 먼저 터지면 안 된다.** 둘 다 "너무 오래 걸렸다"를
뜻하는데, 운영자가 이해하는 축은 벽시계다. fuel 은 epoch 틱 스레드가 굶었을
때를 받치는 백스톱이므로 여유를 얹는다.

### 4. 메모리 상한은 trap 으로 오지 않는다

`Store.set_limits(memory_size=…)` 가 `memory.grow` 를 거부하면, 게스트에서
일어나는 일은 **trap 이 아니라 malloc 실패**다. CPython 은 그것을 평범한
`MemoryError` 로 올리고 종료 코드 1 로 끝난다. 호스트에서 보면 그냥
`FAILED` 다.

그래서 `runner` 가 stderr 에 `MemoryError` 가 있으면 `OUT_OF_MEMORY` 로
되살려 분류한다. 구분해 주는 쪽이 낫다 — 모델에게 **"나눠서 처리하라"**
고 말해 줄 수 있는 것은 이 경우뿐이고, 일반 `FAILED` 에는 그런 처방이 없다.

### 5. 에셋 출처와 갱신 절차

```
cpython  3.12.0 (wasi-sdk-20.0)
  vmware-labs/webassembly-language-runtimes
  tag python/3.12.0+20231211-040d5a6 · python-3.12.0-wasi-sdk-20.0.tar.gz
  sha256 6c1cddbb69ae09e87eee2906bdc70539bff5f2969818a6f8457d4e6a6eb67d4d
tzdata   2026.5 (PyPI, 순수 파이썬 휠)
  sha256 b683bd1b6659ddcd810ff02ad09ba821d4bf1065072805063eb35c49617905ac
```

`tools/fetch_wasm_assets.py` 가 받고 **해시를 검증한 뒤에** 푼다. 틀리면
설치하지 않는다 — 샌드박스 안에서 돌 바이너리를 검증 없이 받으면 공급망이
곧 샌드박스 탈출 경로다. 받은 뒤 `assets/PROVENANCE.txt` 에 출처를 적는다
(에셋 파일만 보고는 어느 빌드인지 알 수 없다).

배치:

```
assets/python.wasm          21MB   인터프리터
assets/python.cwasm         23MB   미리 컴파일한 캐시 (재생성 가능)
assets/pylib/               ←      게스트의 /usr/local/lib 로 preopen
  python312.zip             3.6MB  stdlib
  python3.12/os.py                 (빌드가 밖에 둔 것)
  python3.12/tzdata/        340KB  타임존 DB
```

**`pylib/` 를 따로 두는 것이 중요하다.** `assets/` 를 통째로 preopen 하면
`python.wasm` 자신이 게스트에 보인다.

갱신 절차: 새 릴리스의 URL·sha256 으로 상수 넷을 바꾸고, `assets/` 를 지운
뒤 다시 받고, `tests/integration/test_run_code.py` 를 돌린다. Q2 통과율이
내려가면 `test_q2_pass_rate_has_not_regressed` 가 막는다.

### 6. 함정 — mypy 가 내려받은 stdlib 를 검사한다

`assets/pylib/python3.12/os.py` 가 모듈 `os` 로 잡혀 **저장소 전체의
`os.environ` 타입이 그쪽으로 해소된다.** 증상이 엉뚱한 곳에서 나온다:

```
apps/runtime_worker/.../__main__.py:21: error:
  Argument 1 to "load_config" has incompatible type "dict[bytes, bytes]"
```

`ma_sandbox_local` 과 `ma_harness.tools._io` 에서도 관계없어 보이는 오류가
다섯 건 떴고, 전부 같은 원인이었다. `pyproject.toml` 의 mypy `exclude` 에
`(^|/)assets/` 를 넣어 막는다.

ruff 는 `.gitignore` 를 따르므로 영향이 없었다 — **두 도구가 "우리 코드"를
다르게 정의한다**는 것이 이 함정의 본체다.

## 영향

| 무엇 | 어디 |
|---|---|
| `plan/07-sandbox.md` §3 — p2 전제 정정 | 계획 수정 완료 |
| `SessionStore` 가 공유 엔진을 쓴다 | `store.py::shared_engine` |
| fuel 기본값 200배 상향 | `limits.py` |
| mypy `exclude` | `pyproject.toml` |
