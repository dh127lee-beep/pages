# IMPL-0011 · SSE 백프레셔·LISTEN/NOTIFY 한계·ASGITransport 측정

| | |
|---|---|
| 날짜 | 2026-10-15 |
| 관련 | `T-0206` · [`plan/04-api.md §5`](../../plan/04-api.md) · `ADR-0007` |
| 종류 | `측정` · `함정` |

## 요약

`httpx.ASGITransport` 는 **응답 본문을 전부 모은 뒤 돌려준다** — SSE 를 테스트할
수 없다(측정해서 확인). `NOTIFY` payload 는 8000바이트 한계가 있어 **id 와 seq
만** 싣는다. 백프레셔는 "버리기"(알림)와 "끊기"(연결)를 다르게 다룬다.

## 내용

### 측정 — `httpx.ASGITransport` 는 스트리밍하지 않는다

E2E 테스트가 멈췄다. 최소 재현:

```python
@app.get("/s")
async def s():
    async def gen():
        for i in range(3):
            yield f"data: {i}\n\n"
        while True:
            await anyio.sleep(15)
            yield ": keepalive\n\n"
    return StreamingResponse(gen(), media_type="text/event-stream")

# ASGITransport 로 client.stream(...) → aiter_text() 가 **한 조각도 주지 않는다**
# 8초 fail_after → TimeoutError
```

| 전송 | 첫 조각까지 | 결과 |
|---|---|---|
| `httpx.ASGITransport` | **영원히** | 끝나지 않는 스트림에서 멈춘다 |
| 실제 uvicorn (`127.0.0.1:0`) | 즉시 | 정상 |

그래서 SSE 테스트는 **임시 포트에 진짜 uvicorn 을 띄운다**. 다른 E2E 는
ASGITransport 로 둔다 — 빠르고, 스트리밍이 아니면 문제가 없다.

> 교훈: "E2E 가 진짜 HTTP 를 쓴다"는 주장은 전송 계층을 확인해야 사실이 된다.
> ASGITransport 는 **앱을 호출할 뿐 HTTP 를 하지 않는다.**

### 함정 — `BaseHTTPMiddleware` 경계를 넘는 예외는 감싸진다

인증 미들웨어가 `raise ApiError(...)` 를 했는데 바깥 미들웨어의
`except ApiError` 가 **잡지 못하고** 500 이 났다. Starlette 이 내부
태스크그룹의 예외를 `raise app_exc from app_exc.__cause__ or context` 로 다시
올리면서 원본이 체인 뒤로 들어간다.

두 가지로 고쳤다.

1. **미들웨어는 올리지 않고 응답을 돌려준다.** 경계 안에서 `_envelope(...)` 를
   만들어 반환한다. 라우트 안에서는 `raise` 해도 된다 — 예외 핸들러가 잡는다.
2. `error_envelope` 이 `_unwrap()` 으로 `__cause__`/`__context__`/
   `ExceptionGroup` 을 최대 6단계 따라가며 `ApiError` 를 찾는다. 1번으로 대부분
   막히지만, 미들웨어가 늘어날 때를 대비한 안전망이다.

### 결정 — SSE 백프레셔 한도와 끊는 기준

T-0206 의 열린 질문이었다. **두 가지를 다르게 다룬다.**

| 대상 | 넘치면 | 이유 |
|---|---|---|
| 알림 큐 (`Wake`) | **버린다** (`QUEUE_LIMIT=64`) | 신호는 데이터가 아니다 — 하나를 잃어도 다음 신호에서 `after_seq` 로 따라잡는다 |
| 클라이언트 연결 | **끊는다** | 느린 구독자 하나가 서버 메모리를 먹는다. 끊긴 쪽은 재연결해 replay 받으므로 **잃는 것이 없다** |

이 비대칭이 핵심이다. 알림을 끊으면 영원히 못 받지만, 연결을 끊으면
클라이언트가 다시 붙는다. **복구 경로가 있는 쪽을 끊는다.**

지금 구현은 알림 버리기만 있고 연결 끊기는 uvicorn 의 기본 동작에 기대고 있다
(쓰기가 블록되면 백프레셔가 전파된다). 명시적 한도는 M4 의 관측에서 실제
느린 클라이언트를 보고 정한다 — 숫자를 먼저 정하면 근거가 없다.

### 결정 — `NOTIFY` payload 는 id 와 seq 만

PostgreSQL `NOTIFY` payload 는 **8000바이트 한계**가 있다. 툴 결과 하나가
그것을 넘는다 (출력 상한이 100,000자다).

이벤트를 싣지 않는 이유가 그것만은 아니다.

1. 실려 온 것과 DB 의 것이 다를 수 있다 — **두 벌의 진실**이 생긴다.
2. 구독자가 `after_seq` 로 다시 읽으면 **놓친 것도 같이** 받는다.

즉 알림은 "깨우는 신호"이지 데이터가 아니다. 실제 payload:

```json
{"s": "sess_01J…", "q": 42}
```

채널은 **워크스페이스 단위**다. 세션마다 채널을 만들면 `LISTEN` 수가 세션
수만큼 늘고, PostgreSQL 의 채널 수는 공짜가 아니다. 워크스페이스 채널 하나를
듣고 `session_id` 로 거른다.

### 함정 — SSE 는 구독을 **replay 보다 먼저** 열어야 한다

처음엔 replay → 구독 순서로 썼다. 그러면 그 사이에 난 이벤트를 **놓친다**.

고침: 구독을 먼저 열고 replay 한다. 겹치는 것은 at-least-once 라 클라이언트가
`event.id` 로 지운다 — **중복이 유실보다 낫다**는 원칙이 여기서도 같다.

### 함정 — 응답 재검증 실패 본문에 필드 이름을 싣지 않는다

`revalidate` 가 `ValidationError` 를 500 으로 바꿀 때, pydantic 의 에러 상세를
본문에 실으면 **샌 필드 이름이 그대로 나간다** — 막으려던 것이 에러 경로로
새는 셈이다. 상세는 로그로만 보내고 본문은 "응답을 만들지 못했다"뿐이다.
E2E 역테스트가 `"internal_secret" not in r.text` 로 지킨다.

## 설계에 미치는 영향

`plan/04-api.md` §5 그대로다. SSE vs WebSocket 의 근거는 `ADR-0007` 에 썼다.
