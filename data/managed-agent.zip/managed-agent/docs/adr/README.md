# ADR — 아키텍처 결정 기록

작성 규칙은 [`../README.md`](../README.md) §3에 있습니다. 템플릿은 [`_template.md`](_template.md).

## 목록

| # | 제목 | 상태 | 날짜 |
|---|---|---|---|
| [0001](0001-record-architecture-decisions.md) | 아키텍처 결정을 ADR로 남긴다 | `채택` | 2026-10-15 |
| [0002](0002-adopt-plan-decisions.md) | `plan/`의 D1~D13을 구속력 있는 결정으로 수입한다 | `채택` | 2026-10-15 |
| [0003](0003-lease-ttl-and-heartbeat.md) | lease TTL 90초 · 하트비트 30초 | `채택` | 2026-10-15 |
| [0004](0004-seq-as-max-plus-one.md) | `seq`를 시퀀스 객체가 아니라 `MAX+1`로 부여한다 | `채택` | 2026-10-15 |
| [0005](0005-neutral-stream-vocabulary.md) | 중립 스트림 어휘를 8개 이벤트로 고정한다 | `채택` | 2026-10-15 |
| [0006](0006-waterfall-hook-points.md) | waterfall 훅 지점을 6개로 고정하고 `turn_stopping`만 serial로 둔다 | `채택` | 2026-10-15 |
| [0007](0007-sse-not-websocket.md) | 이벤트 스트림은 SSE다 (WebSocket이 아니다) | `채택` | 2026-10-15 |
| [0008](0008-tier-w-boundary-in-application-code.md) | 티어 W의 경계 검사를 애플리케이션 코드에 맡기는 위험을 수용한다 | `채택` | 2026-10-15 |
| [0009](0009-root-secret-storage.md) | 루트 시크릿은 External Secrets + KMS 로 공급하고, 제어 평면만 안다 | `채택` | 2026-10-15 |
| [0010](0010-mitm-with-per-session-ca.md) | egress 를 세션별 CA 로 MITM 한다 | `채택` | 2026-10-15 |
| [0011](0011-audit-failure-fails-the-operation.md) | 감사 기록이 실패하면 그 작업도 실패한다 | `채택` | 2026-10-15 |
| [0012](0012-our-worker-contract-first.md) | self_hosted 워커는 우리 계약을 먼저 세운다 (공식 무수정 호환 아님) | `채택` | 2026-10-16 |
| [0013](0013-compat-lane-without-a-consumer.md) | 공식 호환 lane 을 소비자가 정해지기 전에 켠다 (Q8) | `채택` | 2026-10-16 |

> 새 ADR을 쓰면 **이 표에 한 줄 추가**합니다. 추가하지 않으면 아무도 찾지 못합니다.

## 번호

전역 증가. 재사용하지 않습니다. 동시에 두 사람이 같은 번호를 쓰면 머지할 때 **나중 것이
다음 번호로** 옮깁니다 — 이미 머지된 번호는 바꾸지 않습니다.

## 상태

```
제안 ──▶ 채택 ──┬──▶ 폐기            (더 이상 하지 않기로 함)
                └──▶ 대체됨 by NNNN  (다른 결정이 이것을 밀어냄)
```

`제안` 상태의 ADR은 **합의 전**입니다. 그 내용대로 구현하면 안 됩니다.
PR 리뷰에서 합의되면 `채택`으로 바꾸고 날짜를 적습니다.
