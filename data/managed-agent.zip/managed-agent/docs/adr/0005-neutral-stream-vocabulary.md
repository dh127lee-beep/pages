# ADR-0005 · 중립 스트림 어휘를 8개 이벤트로 고정한다

| | |
|---|---|
| 상태 | `채택` |
| 날짜 | 2026-10-15 |
| 관련 | `T-0204` · [`plan/06-harness-and-model.md §1`](../../plan/06-harness-and-model.md) · `ADR-0002` (D12) · [`IMPL-0009`](../impl/0009-model-error-classification.md) |

## 맥락

D12 에 따라 하네스는 provider 를 모른다. 어댑터가 provider 별 스트림을 중립
어휘로 정규화하고, 하네스 루프는 그 어휘만 읽는다.

문제는 **이 목록이 사실상 영구적**이라는 것이다. 어휘에 이벤트를 하나 추가하면:

- 모든 어댑터가 그것을 낼지 말지 정해야 하고,
- 하네스 루프의 `match`가 바뀌고,
- 이벤트 로그 타입(`EventType`)과 SSE 프레임까지 따라 바뀐다.

즉 **나중에 추가하는 비용이 처음 정하는 비용보다 훨씬 크다.** 반대로 너무 많이
넣으면 어댑터마다 "이건 우리 provider 에 없는데" 하는 빈 구현이 늘고, 하네스가
실제로는 안 오는 이벤트를 다루는 죽은 코드를 갖게 된다.

조사한 provider 들의 스트림 모양:

| | OpenAI / DeepSeek | Anthropic | 비고 |
|---|---|---|---|
| 텍스트 | `delta.content` | `content_block_delta(text)` | 공통 |
| 추론 | `delta.reasoning_content` | `thinking_delta` | 이름만 다름 |
| 툴 호출 시작 | `tool_calls[i]` 첫 조각 | `content_block_start(tool_use)` | **OpenAI 는 명시적 시작이 없다** |
| 툴 인자 | `function.arguments` 조각 | `input_json_delta` | 공통 |
| 툴 호출 끝 | **없음** | `content_block_stop` | OpenAI 는 `finish_reason`으로 유추 |
| 사용량 | 마지막 chunk `usage` | `message_delta.usage` | 공통 |
| 종료 | `finish_reason` | `message_stop` + `stop_reason` | 공통 |

## 선택지

### A. OpenAI chunk 를 그대로 통과시킨다 (어휘 없음)

- 장점: 어댑터가 거의 비어 있다. 지금 당장 가장 빠르다.
- 단점: **하네스가 OpenAI 포맷을 알게 된다.** D12 가 막으려던 바로 그 결합이고,
  Anthropic 포맷 어댑터(M5)를 붙일 때 하네스를 고쳐야 한다.

### B. 6개 — `text_delta` `thinking_delta` `tool_call` `usage` `finish` `error`

툴 호출을 **완성된 것 하나로** 낸다(조각을 어댑터가 모아서).

- 장점: 가장 작다. 하네스가 툴 인자 조립을 안 해도 된다.
- 단점: **툴 인자를 스트리밍으로 보여줄 수 없다.** 콘솔이 "에이전트가 지금 이
  파일을 읽으려 한다"를 인자가 다 모이기 전에 띄우지 못한다. 긴 인자(패치 본문
  같은 것)에서는 수 초 동안 화면이 멈춘 것처럼 보인다.

### C. 8개 — B + `tool_call_start` / `tool_call_delta` / `tool_call_end` 분리

- 장점: 툴 인자를 흘릴 수 있다. `start`에 이름이 있으므로 인자가 다 오기 전에
  "무엇을 하려는지"를 띄울 수 있다. `end`가 "인자가 다 모였다"의 신호라
  하네스가 파싱 시점을 안다.
- 단점: OpenAI 는 `tool_call_end`를 **보내지 않으므로 어댑터가 만들어야** 한다.
  경계를 만드는 책임이 어댑터로 간다.

### D. 12개 — C + `message_start` `content_block_start/stop` `ping`

Anthropic 어휘를 거의 그대로.

- 장점: Anthropic 어댑터가 가장 얇아진다.
- 단점: OpenAI 계열 어댑터가 **없는 이벤트를 지어내야** 한다. 어휘가 한
  provider 쪽으로 기울면 다른 쪽 어댑터가 거짓말을 하게 된다.

## 결정

**C를 택한다. 8개:**

```
text_delta · thinking_delta
tool_call_start · tool_call_delta · tool_call_end
usage · finish · error
```

`tool_call_end`를 **OpenAI 가 보내지 않는데도 넣은 것**이 이 결정의 핵심이다.
어댑터가 `finish_reason`을 보고 열린 호출을 닫아 경계를 만든다. 비용은 어댑터
20줄이고, 얻는 것은 하네스가 "인자가 다 모였다"를 묻지 않아도 되는 것이다 —
그 판단을 하네스가 하면 **모든 provider 의 종료 규칙을 하네스가 알아야** 한다.

포기하는 것: **Anthropic 의 블록 구조.** `message_start`·`content_block_*`를
받지 않으므로, 한 응답 안에 텍스트·추론·툴 블록이 어떤 순서로 몇 개 있었는지는
중립 어휘로 복원되지 않는다. 지금 하네스가 그 정보를 쓰지 않으므로 버린다.

`error`를 어휘에 넣은 이유는 따로 있다. 예외로 올리면 **스트림 중간까지 받은
텍스트가 버려진다.** 모델이 2,000 토큰을 쓰고 429 를 맞았다면 그 2,000 토큰은
이미 과금됐고 사용자에게 보여줄 가치가 있다. 이벤트로 흘리면 하네스가
`agent.message_attempt`로 기록하고 재시도할 수 있다.

## 결과

**좋아지는 것**

- 새 provider 비용 = 어댑터 파일 하나 + 계약 테스트. 하네스·API·DB 무변경.
- 툴 인자가 스트리밍된다 — 콘솔이 멈춘 것처럼 보이지 않는다.
- 부분 출력이 에러에도 살아남는다.
- 계약 테스트가 **네트워크 없이** 돈다. 정규화기가 순수 함수이기 때문이다.

**나빠지는 것**

- **어댑터가 상태를 갖는다.** `tool_call_end` 경계를 만들려면 열린 호출을
  기억해야 하고, 그래서 `StreamNormalizer`는 스트림당 인스턴스 하나다.
  재사용하면 이전 스트림의 툴 호출이 샌다.
- Anthropic 블록 구조가 소실된다. 나중에 "모델이 추론 블록을 몇 개 냈는가" 같은
  질문이 생기면 어휘를 늘려야 하고, 그 비용이 이 ADR 의 맥락에 적은 그대로다.
- `usage`가 `finish` **뒤에** 올 수 있다(OpenAI 는 마지막 chunk 에 싣는다).
  하네스는 `finish`를 받고도 스트림을 끝까지 읽어야 비용을 센다 — 직관에
  반하므로 루프에 주석이 필요하다.

## 되돌리려면

어휘를 늘리는 것은 **모든 어댑터를 고치는 일**이다. 지금 어댑터가 둘이라 싸지만
(각 20~40줄), M5 에서 Anthropic·MCP 가 붙으면 넷이 된다.

늘려야 할 조건:

1. 콘솔이나 하네스가 **실제로 못 하는 일**이 생긴다 (가정이 아니라 사례).
2. 그 일을 기존 8개의 조합으로 표현할 수 없다.

둘 다 참일 때만 늘린다. 특히 2를 먼저 확인한다 — 대부분은 `finish_reason`을
늘리거나 `ModelStreamEvent`에 선택 필드를 더하는 것으로 충분하고, 그쪽은
기존 어댑터를 고치지 않는다.
