# 04. 도구와 외부 연동 (Tools & Integrations)

> 대상: Claude Managed Agents (public beta, 2026-04-08~), beta header `managed-agents-2026-04-01`
> 작성 기준일: 2026-10-14. 이 장은 공식 문서 8개(tools, tools-web-restrictions, mcp-connector, skills, files, github, vaults, permission-policies)의 내용만을 정리한다. 문서에 없는 추론은 하지 않았다.

이 장은 에이전트가 "무엇을 할 수 있는가"(도구), "어디에 접근할 수 있는가"(웹 도메인, MCP, GitHub, 파일), "어떤 자격 증명으로"(vault), "누구의 승인 아래"(permission policy) 동작하는지를 다룬다.

설정 위치를 먼저 정리하면 다음과 같다.

| 구성 요소 | 설정 위치 | 비고 |
| --- | --- | --- |
| 내장 도구 (`agent_toolset_20260401`) | Agent `tools` | 활성/비활성, `permission_policy`, 웹 도구 도메인 제한 |
| Custom tool (`type: "custom"`) | Agent `tools` | 실행은 클라이언트(애플리케이션)가 담당 |
| MCP 서버 | Agent `mcp_servers` + `tools`의 `mcp_toolset` | 인증 정보는 Agent에 넣지 않음 |
| Skills | Agent `skills` / 마운트된 GitHub repo의 `.claude/skills` | |
| 파일 | Session `resources` (`type: "file"`) | 세션 실행 중 추가/삭제 가능 |
| GitHub 저장소 | Session `resources` (`type: "github_repository"`) | 토큰 rotate만 가능, 저장소 교체는 새 세션 |
| 자격 증명 | Vault → Session `vault_ids` | workspace 범위 |
| 권한 정책 | Agent `tools`의 `default_config` / `configs` | Custom tool에는 적용되지 않음 |

---

## 1. 내장 도구 세트 (`agent_toolset_20260401`)

### 1.1 제공 도구

toolset을 Agent 설정에 포함하면 아래 8개 도구가 **모두 기본 활성화**된다.

| 도구 | `name` | 설명 |
| --- | --- | --- |
| Bash | `bash` | shell 세션에서 bash 명령 실행 |
| Read | `read` | sandbox 파일시스템에서 파일 읽기 |
| Write | `write` | sandbox 파일시스템에 파일 쓰기 |
| Edit | `edit` | 파일 내 문자열 치환 |
| Glob | `glob` | glob 패턴 기반 파일 매칭 |
| Grep | `grep` | 정규식 텍스트 검색 |
| Web fetch | `web_fetch` | URL 내용 가져오기 |
| Web search | `web_search` | 웹 검색 |

- 도구 출력이 **100,000자(약 25,000 토큰)를 넘으면** 자동으로 sandbox 내 파일로 기록되고, 모델은 파일 경로가 포함된 잘린 preview를 받는다. 모델은 필요하면 그 파일을 읽어 전체 내용을 확인한다. (MCP 도구 출력에도 동일 규칙 적용)
- `web_search`, `web_fetch`는 sandbox가 아니라 **Anthropic 서버에서 실행**된다(2장 참조).

### 1.2 설정 구조: `default_config` + `configs`

- `default_config`: toolset 전체의 기본값.
- `configs[]`: 도구별 override. 각 항목은 `name`(위 표의 이름)으로 식별하며, 선택적으로 같은 값의 `type`을 둘 수 있다(생략 시 서버가 `name`으로 추론, 응답에는 항상 포함).
- 각 항목에 `enabled`, `permission_policy`를 지정할 수 있고, `web_search`/`web_fetch`는 도메인 제한 등 추가 설정을 받는다.

특정 도구 비활성화:

```json
{
  "type": "agent_toolset_20260401",
  "configs": [
    { "name": "web_fetch", "enabled": false },
    { "name": "web_search", "enabled": false }
  ]
}
```

필요한 도구만 활성화(allowlist 방식):

```json
{
  "type": "agent_toolset_20260401",
  "default_config": { "enabled": false },
  "configs": [
    { "name": "bash", "enabled": true },
    { "name": "read", "enabled": true },
    { "name": "write", "enabled": true }
  ]
}
```

Agent 생성 예시(Python):

```python
agent = client.beta.agents.create(
    name="Coding Assistant",
    model="claude-opus-5-5",
    tools=[
        {
            "type": "agent_toolset_20260401",
            "configs": [{"name": "web_fetch", "enabled": False}],
        }
    ],
)
```

SDK 관련 참고: Python/TypeScript/Go/Java/C#/Ruby/PHP SDK는 `configs` 항목을 도구별 union 타입(판별자 `type`)으로 정의한다. Go/Java/C#/PHP에서는 dict가 아니라 도구별 타입 값(예: `BetaManagedAgentsWebFetchToolConfigParams`)으로 항목을 만든다. 직렬화된 JSON은 동일하다.

> 권한 정책은 "활성화된 도구가 언제 실행되는가"를 통제한다. 도구를 아예 제거하려면 정책이 아니라 `enabled: false`를 쓴다.

---

## 2. 웹 검색/가져오기 도메인 제한

### 2.1 개요

`web_search`, `web_fetch`의 `configs` 항목에는 다음 중 **하나의 목록만** 지정한다.

- `allowed_domains`: 이 호스트들에만 접근 가능
- `blocked_domains`: 이 호스트들에는 절대 접근 불가

두 도구는 각각 별도 목록을 가진다.

| 설정 | 적용 대상 | 설명 |
| --- | --- | --- |
| `allowed_domains` | `web_search`, `web_fetch` | 허용 호스트 목록 |
| `blocked_domains` | `web_search`, `web_fetch` | 차단 호스트 목록 |
| `max_content_tokens` | `web_fetch` | 컨텍스트에 포함되는 fetch 내용 상한(양의 정수) |
| `user_location` | `web_search` | 검색 결과 지역화. Messages API `user_location`과 동일 필드 |

```json
{
  "type": "agent_toolset_20260401",
  "configs": [
    {
      "type": "web_search", "name": "web_search",
      "allowed_domains": ["docs.example.com", "arxiv.org"],
      "user_location": {"type": "approximate", "country": "US", "timezone": "America/Los_Angeles"}
    },
    {
      "type": "web_fetch", "name": "web_fetch",
      "blocked_domains": ["ads.example.com"],
      "max_content_tokens": 50000
    }
  ]
}
```

Console에서는 Agent 폼의 **Built-in tools** 카드에서 도메인 목록을, **Raw** 뷰에서 `max_content_tokens`/`user_location`을 설정한다.

### 2.2 환경 네트워킹과의 관계

- 웹 도구는 Anthropic 서버에서 실행되지만, cloud 환경이 `limited` 네트워킹이면 환경의 `allowed_hosts`가 웹 도구에도 적용된다. `unrestricted` 네트워킹과 self-hosted 환경은 웹 도구를 제한하지 않는다.
- Claude Console의 조직 단위 웹 검색/가져오기 설정은 **Messages API에만** 적용되고 Managed Agents 세션에는 적용되지 않는다.
- `limited` 환경에서, 활성화된 웹 도구의 `allowed_domains` 항목이 `allowed_hosts` 범위 밖이면 **세션 생성(또는 해당 항목을 추가하는 세션 업데이트)이 400으로 실패**한다.
- 런타임에 `allowed_hosts`에 맞지 않는 호스트의 URL을 `web_fetch`하면 `url_not_allowed` 에러 결과, `web_search`는 해당 결과를 생략한다.
- 매칭 방식 차이: 도구 목록 항목은 **하위 도메인을 포함**하지만, `allowed_hosts` 항목은 `*.`로 시작하지 않는 한 **정확히 한 호스트**만 매칭한다. 예: 도구 항목 `docs.example.com`은 `allowed_hosts: ["example.com"]` 안에 포함되지 않지만 `["docs.example.com"]` 또는 `["*.example.com"]`에는 포함된다.

### 2.3 허용되지 않은 도메인일 때

- `web_search`: 허용되지 않은 결과를 생략.
- `web_fetch`: 에러 결과 반환. `agent.tool_result` 이벤트가 `is_error: true`이며 내용에 `url_not_allowed` 코드가 포함된다.

### 2.4 도메인 목록 규칙

| 규칙 | 내용 |
| --- | --- |
| 목록 하나만 | 한 항목에 `allowed_domains`와 `blocked_domains`를 동시에 둘 수 없음 |
| 크기 | 목록당 1~64개, 각 도메인 1~255자 |
| 빈 목록 금지 | 제한하지 않으려면 필드 생략 또는 `null` |
| 중복 금지 | `www.example.com`과 `example.com`은 서로 다른 도메인 |
| 매칭 | 해당 호스트 + 모든 하위 도메인. `example.com`은 `docs.example.com`을 포함하지만 역은 성립 안 함. `www.`도 일반 하위 도메인 취급 |
| 대소문자 | 무시 |
| 형식 | ASCII 문자, 숫자, `-`, `_`, `.`만. 끝의 `/` 하나는 무시 |

허용되지 않는 형식:

| 불가 | 예 | 대신 |
| --- | --- | --- |
| scheme | `https://example.com` | `example.com` |
| port | `example.com:443` | `example.com` |
| wildcard | `*.example.com` | `example.com` |
| `web_fetch` 도메인의 path | `example.com/*` | `example.com` |
| IP 주소(모든 형태) | `127.1` | 도메인 이름 |
| TLD/registry suffix 단독 | `com`, `co.uk` | `example.co.uk` |
| 단일 라벨 이름 | `intranet` | 완전한 도메인 |
| 비 ASCII(IDN) | | `xn--` Punycode |

그 밖에 자격 증명·공백 포함, 하이픈으로 시작/끝나는 라벨, `localhost` 및 `.localhost`/`.local`/`.internal`/`.localdomain`/`.invalid`로 끝나는 호스트는 거부된다. `web_search` 도메인에는 `example.com/blog` 같은 path suffix가 허용되지만(공백, `?`, `#`, `$ , | ^ !` 불가), 검색 공급자가 URL 패턴으로 매칭하므로 plain hostname 사용이 권장된다.

### 2.5 검증 오류와 재검증

Agent 생성/수정, 그리고 `tools`를 포함한 세션 생성/수정 시 검증되며 위반 시 400 `invalid_request_error`.

| 위반 | 메시지 |
| --- | --- |
| 두 목록 동시 지정 | `Only one of allowed_domains or blocked_domains may be set.` |
| 빈 목록 | `allowed_domains: Empty list of domains is ambiguous. Provide at least one domain or null.` |
| 형식 위반 | 목록명과 0-based 위치 포함, 예: `allowed_domains.0: IP addresses are not supported; ...` |

추가로 Anthropic 크롤러가 접근할 수 없는 `allowed_domains` 항목, 검색 공급자가 지원하지 않는 `user_location.country`, 유효한 IANA 이름이 아닌 `user_location.timezone`도 거부된다.

세션이 도구를 처음 초기화할 때 설정을 다시 검사한다. 이전에 받아들여진 설정이 그 시점에 무효면 `session.error`를 내고 재시도 없이 `idle`로 돌아간다. 복구 절차: (1) 세션 tools 업데이트로 수정 → (2) 새 세션을 위해 Agent도 수정 → (3) 새 `user.message` 전송.

### 2.6 멀티에이전트·outcome 세션

`subagents`의 `predefined_agents`에 있는 에이전트는 (자신의 목록) + (자신을 호출한 에이전트의 목록) + (세션 에이전트의 현재 목록)을 모두 동시에 적용받는다.

| 설정 | 결합 방식 |
| --- | --- |
| `allowed_domains` | 모든 목록이 포함하는 호스트만 접근 가능(교집합) |
| `blocked_domains` | 합집합 |
| `max_content_tokens`, `user_location` | 결합하지 않음. 자신 → 호출자 → 세션 에이전트 순으로 먼저 설정된 값 사용 |

즉 하위 에이전트는 범위를 **좁힐 수만 있고 넓힐 수는 없다**. 교집합이 비면 도구는 노출되지만 모든 호출이 `url_not_allowed`로 실패한다. `{"type": "self"}` 항목은 자체 웹 설정이 없고 세션 에이전트 설정을 따른다. outcome-driven 세션의 grader는 설정과 무관하게 `web_search`/`web_fetch` 없이 실행된다.

idle 세션의 tools를 업데이트해 목록을 중간에 바꿀 수 있고, 멀티에이전트 세션에서는 각 thread의 다음 turn부터 적용된다(단, predefined agent 자신의 목록은 세션 생성 시 정의 그대로 유지).

### 2.7 Messages API 서버 도구와의 차이

1. 목록당 최대 64개.
2. `web_fetch` 도메인에 path 불가.
3. ASCII만 허용(Messages API는 Unicode 허용하나 비권장).
4. `max_uses`, `citations`, `cache_control`은 toolset에서 사용 불가.

---

## 3. Custom tools (클라이언트 실행 도구)

Messages API의 user-defined client tool과 같은 개념이다. **Claude는 custom tool을 직접 실행하지 않는다.** 구조화된 요청을 내보내면 애플리케이션이 작업을 실행하고 결과를 세션에 돌려준다.

```json
{
  "type": "custom",
  "name": "get_weather",
  "description": "Get current weather for a location",
  "input_schema": {
    "type": "object",
    "properties": { "location": {"type": "string", "description": "City name"} },
    "required": ["location"]
  }
}
```

실행 흐름(permission-policies 문서 기준):

1. 에이전트가 custom tool을 호출하면 애플리케이션이 `agent.custom_tool_use` 이벤트를 받는다.
2. 실행 여부 판단과 실행은 전적으로 애플리케이션 책임이다(permission policy 비적용, 이벤트에 `evaluated_permission`/`evaluation` 필드 없음).
3. 결과를 `user.custom_tool_result` 이벤트로 돌려보낸다. 상세 흐름은 Session event stream 문서 참조.

이름 규칙:

- `mcp__` 또는 `ant__`로 시작하거나 내장 도구 이름과 같으면 400.
- 이미 `ant__`로 시작하는 custom tool을 가진 Agent는 그 이름을 뺀 `tools`를 보내는 update만 허용된다. 그런 도구가 Agent(세션 override 적용 후), `subagents`/`workflows`의 `predefined_agents`에 있으면 새 세션 생성이 400으로 거부된다. 기존 세션은 영향 없음.

Self-hosted sandbox 세션에서는 environment worker가 sandbox에서 custom tool을 제공할 수 있으며, 사내 네트워크의 MCP 서버를 감싸는 도구도 가능하다.

작성 모범 사례(문서 요약):

| 원칙 | 내용 |
| --- | --- |
| 매우 상세한 description | 성능에 가장 중요. 도구당 3~4문장 이상: 기능, 사용/비사용 시점, 각 파라미터 의미, 주의사항 |
| 관련 작업 통합 | `create_pr`/`review_pr`/`merge_pr` → `action` 파라미터를 가진 하나의 도구 |
| 의미 있는 namespacing | `db_query`, `storage_read`처럼 리소스 prefix |
| 고신호 응답 | 안정적 식별자(slug, UUID), 다음 단계에 필요한 필드만 |

---

## 4. MCP connector

### 4.1 2단계 구성

1. **Agent 생성**: 연결할 MCP 서버를 이름과 URL로 선언(토큰 없음).
2. **Session 생성**: 사전 등록한 vault를 `vault_ids`로 참조해 인증 제공.

재사용되는 Agent 정의에서 secret을 분리하고, 세션마다 자기 자격 증명을 쓰게 하려는 설계다.

```json
{
  "name": "GitHub Assistant",
  "model": "claude-opus-5-5",
  "mcp_servers": [
    {"type": "url", "name": "github", "url": "https://api.githubcopilot.com/mcp/"}
  ],
  "tools": [
    {"type": "agent_toolset_20260401"},
    {"type": "mcp_toolset", "mcp_server_name": "github"}
  ]
}
```

| `mcp_servers` 필드 | 설명 |
| --- | --- |
| `type` | 필수. `"url"`만 허용 |
| `name` | 필수. Agent 내 고유(1~255자). `mcp_toolset.mcp_server_name`과 MCP 도구 이벤트에 사용 |
| `url` | 필수. 원격 MCP 서버 endpoint(최대 2,048자). 전송 요구사항은 reference의 "Supported MCP server types" |

제약:

- Agent당 MCP 서버 최대 **20개**, 이름 고유.
- 모든 `mcp_servers` 항목은 `mcp_toolset`으로 참조되어야 하고, 모든 `mcp_toolset`은 선언된 서버를 참조해야 한다(미참조 서버/dangling toolset은 거부).

### 4.2 노출 도구 선택

`mcp_toolset`도 `default_config`/`configs`를 지원한다. 단 `configs` 항목은 `name`, `enabled`, `permission_policy`만 받고, `type` 필드와 웹 설정은 없다. `name`은 서버가 보고하는 bare tool name이다. 기본은 서버의 모든 도구 활성화.

```json
{
  "type": "mcp_toolset",
  "mcp_server_name": "github",
  "default_config": { "enabled": false },
  "configs": [
    { "name": "get_issue", "enabled": true },
    { "name": "list_issues", "enabled": true }
  ]
}
```

이 allowlist 패턴은 서버 운영자가 나중에 추가한 도구가 검토 전까지 꺼져 있게 하는 데 유용하다. 반대로 특정 도구만 끄려면 `{"name": "delete_repository", "enabled": false}`처럼 쓴다.

MCP toolset의 기본 permission policy는 **`always_ask`**(호출마다 승인 필요)다.

### 4.3 세션에서 인증 제공

```python
session = client.beta.sessions.create(
    agent=agent.id,
    environment_id=environment.id,
    vault_ids=[vault.id],
)
```

- 자격 증명은 **URL로 매칭**된다. vault 자격 증명의 `mcp_server_url`과 `mcp_servers.url`이 같은 서버여야 한다. 비교 전 정규화(scheme/host 소문자화, 기본 포트·끝 슬래시 제거)하므로 대소문자, 기본 포트, 끝 슬래시 차이는 무시되지만 **path, subdomain, 비기본 포트 차이는 불일치**다.
- 일치 항목이 없으면 **인증 없이** 연결을 시도한다.
- `limited` 환경에서 MCP 서버 host가 `allowed_hosts`에 없으면 세션 생성이 400. 환경 networking의 `allow_mcp_servers: true`로 이 검사를 끌 수 있다.

### 4.4 연결/인증 실패 처리

세션 생성은 MCP 연결성이나 자격 증명을 검증하지 않는다(위의 host 검사만 수행). 서버 접속 불가나 자격 증명 거부가 있어도 세션은 시작되고 상호작용이 가능하며, 영향받은 서버의 `mcp_server_name`과 `retry_status`를 담은 `session.error`가 발생한다.

| 에러 타입 | 의미 |
| --- | --- |
| `mcp_connection_failed_error` | 서버 접속 불가(네트워크 오류, 타임아웃, 인증 외 HTTP 실패) |
| `mcp_authentication_failed_error` | 자격 증명 거부, 매칭 자격 증명 없이 인증 요구, OAuth 토큰 refresh 실패 |

연결은 다음 `session.status_idle` → `session.status_running` 전환 시 재시도된다. 클라이언트는 상호작용 차단, 자격 증명 rotate, 또는 해당 서버 도구 없이 계속 진행 중 선택할 수 있다.

---

## 5. Agent Skills

Skills는 재사용 가능한 파일시스템 기반 리소스로, 일반 에이전트를 도메인 전문가로 만드는 워크플로·컨텍스트·모범 사례를 담는다. 스킬마다 세션 컨텍스트 윈도우에 약간의 비용(지침과 메타데이터)이 추가된다. 에이전트는 관련 작업일 때 스킬을 **자동으로 호출**한다.

에이전트에 스킬이 전달되는 경로는 두 가지다.

| 경로 | 종류 | 비고 |
| --- | --- | --- |
| Agent `skills` 배열 | Anthropic 사전 제작(`pptx`, `xlsx`, `docx`, `pdf`) | 모든 workspace에서 바로 사용 가능 |
| Agent `skills` 배열 | Custom(workspace에 업로드) | `skill_*` ID 필요 |
| GitHub repo 마운트 | repo 루트의 `.claude/skills` | 업로드·`skills` 항목 불필요 |

### 5.1 Custom skill 생성

`SKILL.md`와 보조 파일을 담은 디렉터리를 zip 또는 개별 파일로 Skills API에 업로드한다(Files API가 아님). 응답의 `skill_*` ID를 Agent에 붙인다. `display_name`은 선택(최대 255자, 고유 불필요)이며 생략 시 `SKILL.md`의 `name`에서 유래한다.

```bash
curl -X POST "https://api.anthropic.com/v1/skills" \
  -H "x-api-key: $ANTHROPIC_API_KEY" \
  -H "anthropic-version: 2023-06-01" \
  -F "files[]=@example_skill.zip"
```

CLI의 `ant apply skills/<dir>`는 업로드 후 ID를 `claude-lock.json`에 기록한다. 이 파일을 커밋하면 다음 `ant apply`가 새 스킬이 아니라 새 버전으로 업로드한다.

### 5.2 Agent에 부착

| 필드 | 설명 |
| --- | --- |
| `type` | `anthropic` 또는 `custom` |
| `skill_id` | Anthropic은 short name(`xlsx`), custom은 `skill_*` ID |
| `version` | 특정 버전 또는 `latest`. 선택, 기본 `latest` |

```json
"skills": [
  {"type": "anthropic", "skill_id": "xlsx"},
  {"type": "custom", "skill_id": "skill_01AbCdEfGhIjKlMnOpQrStUv", "version": "latest"}
]
```

- 세션당 최대 **500개**(세션 내 모든 에이전트의 중복 제거 합계).
- 스킬이 많을수록 sandbox 시작 시간이 늘어난다. 필요한 것만 붙인다.

### 5.3 GitHub 저장소에서 로드

`github_repository` 리소스를 마운트하면 세션 시작 시 repo 루트의 `.claude/skills`를 스캔한다. 에이전트는 발견된 스킬의 이름·설명·sandbox 경로를 알고, 작업과 맞으면 `SKILL.md`(및 스크립트·리소스)를 읽는다. 발견은 `read` 도구에 의존하므로 `read`를 끄면 repo 스킬이 로드되지 않는다.

- 정확히 `.claude/skills/<skill-name>/SKILL.md`(한 단계 깊이)만 발견된다. `.claude/skills/SKILL.md`, `.claude/skills/tools/code-review/SKILL.md`, `skills/code-review/SKILL.md`는 발견되지 않는다. 하위 패키지 내부의 `.claude/skills`는 세션 시작 시 공지되지 않지만, 에이전트가 해당 subtree를 읽을 때 드러날 수 있다.
- `checkout`이 지정되면 그 브랜치/커밋, 아니면 기본 브랜치 기준. 스캔은 세션 시작 시 1회이며 세션 중 push는 반영되지 않는다(새 세션 필요).
- `skills` 배열 스킬이나 다른 repo 스킬과 이름이 겹쳐도 둘 다 사용 가능하며 각자 경로로 공지된다.
- cloud sandbox에서만 동작. self-hosted sandbox는 GitHub repository 리소스를 지원하지 않는다.

> 경고(문서): repo 스킬은 에이전트 지침이므로 마운트한 repo는 신뢰 경계의 일부다. 커밋 권한이 있는 누구든(병합된 외부 PR, 오염된 의존성 등) 스킬을 추가·변경할 수 있고, 플랫폼은 검토 없이 로드하며, `bash`·`web_fetch`가 그 지침에 실질적 영향력을 준다. 신뢰하는 repo만 마운트하고 외부 기여를 받는 repo는 `.claude/skills`를 사전 검토할 것.

---

## 6. 파일 (Files)

### 6.1 업로드와 마운트

Files API로 업로드한 뒤 세션 `resources`에 `type: "file"`로 마운트한다.

```python
file = client.files.upload(file=Path("data.csv"))
session = client.beta.sessions.create(
    agent=agent.id,
    environment_id=environment.id,
    resources=[{"type": "file", "file_id": file.id, "mount_path": "/data.csv"}],
)
```

경로 규칙:

| 항목 | 내용 |
| --- | --- |
| `mount_path` 지정 시 | 세션 uploads 디렉터리 아래에 위치: `/data.csv` → `/mnt/session/uploads/data.csv` |
| `mount_path` 생략 시 | `/mnt/session/uploads/<file_id>` (그래서 파일명을 서술적으로 할 것이 권장됨) |
| 부모 디렉터리 | 자동 생성 |
| 경로 형식 | 절대 경로(`/`로 시작) |
| 쓰기 | 마운트된 파일은 **읽기 전용 복사본**. 수정본은 sandbox 내 새 경로에 작성 |
| 출력 | `/mnt/session/outputs/`에 쓴 파일은 세션 범위로 Files API에서 조회 가능 |

- 마운트 시 세션 내 인스턴스를 가리키는 새 `file_id`가 생성되며, 이 복사본은 storage limit에 포함되지 않는다.
- 세션당 최대 **500개** 파일.
- 지원 형식: 소스 코드, 데이터(`.csv`, `.json`, `.xml`, `.yaml`), 문서(`.txt`, `.md`), 아카이브(`.zip`, `.tar.gz`, bash로 압축 해제), 바이너리 등 모든 형식.

### 6.2 실행 중 세션에서 파일 관리

| 작업 | API |
| --- | --- |
| 추가 | `POST /v1/sessions/{session_id}/resources` (`{"type":"file","file_id":...}`) → `sesrsc_...` ID 반환 |
| 목록 | `GET /v1/sessions/{session_id}/resources` |
| 삭제 | `DELETE /v1/sessions/{session_id}/resources/{resource_id}` |

### 6.3 출력 파일 목록/다운로드

```bash
# 세션 범위 파일 목록 (scope_id 필터는 beta header 필요)
curl "https://api.anthropic.com/v1/files?scope_id=sesn_abc123" \
  -H "x-api-key: $ANTHROPIC_API_KEY" -H "anthropic-version: 2023-06-01" \
  -H "anthropic-beta: managed-agents-2026-04-01"
# 다운로드
curl "https://api.anthropic.com/v1/files/$FILE_ID/content" \
  -H "x-api-key: $ANTHROPIC_API_KEY" -H "anthropic-version: 2023-06-01" -o output.txt
```

`/mnt/session/outputs/`의 파일은 에이전트가 쓰기를 마친 직후, 때로는 세션이 idle이 된 뒤 몇 초 후에 목록에 나타난다. 없으면 잠시 후 다시 조회하며, 목록에 나타나면 업로드가 완료된 것이다.

---

## 7. GitHub 접근

GitHub 연동은 두 축이다: (1) 세션 sandbox에 저장소를 **마운트**(clone)하고, (2) **GitHub MCP**로 PR 생성 등을 수행한다. 저장소는 캐시되어 같은 repo를 쓰는 이후 세션이 더 빨리 시작된다.

Agent에는 GitHub MCP 서버(`https://api.githubcopilot.com/mcp/`)를 토큰 없이 선언하고, 세션에서 저장소를 마운트한다.

```json
"resources": [{
  "type": "github_repository",
  "url": "https://github.com/org/repo",
  "mount_path": "/workspace/repo",
  "authorization_token": "ghp_your_github_token"
}]
```

| 필드 | 설명 |
| --- | --- |
| `type` | 필수. `"github_repository"` |
| `url` | 필수. `https://github.com/<owner>/<repo>` 형식, `.git` 접미사 없음. SSH URL 등 다른 형식은 `invalid_request_error` |
| `authorization_token` | 필수. clone용 GitHub 토큰. API 응답에 echo되지 않음 |
| `mount_path` | 선택. `/workspace` 아래 clone 위치. 기본 `/workspace/<repo-name>` |
| `checkout` | 선택. `{"type":"branch","name":"main"}` 또는 `{"type":"commit","sha":"..."}`. 기본은 기본 브랜치 |

- 여러 저장소는 `resources`에 항목을 추가해 마운트한다.
- 마운트하면 repo 루트 `.claude/skills`의 스킬도 로드된다(5.3).
- `limited` 환경에서 MCP 서버 host 검사 규칙(4.3)이 동일하게 적용된다.

토큰 권한(최소 권한 원칙, fine-grained PAT 권장):

| 작업 | 필요 scope |
| --- | --- |
| private repo clone | `repo` |
| PR 생성 | `repo` |
| issue 읽기/생성 | `repo`(private) 또는 `public_repo` |

실행 중 세션 관리: `GET /v1/sessions/{id}/resources`로 리소스 ID를 얻고, 해당 리소스를 `authorization_token`만 담아 업데이트해 **토큰을 rotate**할 수 있다(Python: `client.beta.sessions.resources.update(resource_id, session_id=..., authorization_token=...)`). 저장소는 세션 수명 동안 고정이며, 마운트 대상을 바꾸려면 새 세션을 만든다.

PR 생성은 `user.message`로 지시한다(예: "Fix the type error in src/utils.ts, commit it to a new branch, and push it."). 에이전트는 GitHub MCP로 브랜치 생성, 커밋, push를 수행한다.

---

## 8. Vaults (자격 증명 저장소)

### 8.1 개념

Vault와 credential은 서드파티 서비스 자격 증명을 한 번 등록하고 세션 생성 시 ID로 참조하게 하는 인증 primitive다. 자체 secret store 운영, 매 호출 토큰 전송, 에이전트가 어떤 최종 사용자를 대신했는지 추적하는 부담을 줄인다. vault 참조는 세션 단위 파라미터이므로 **제품은 `agent` 단위로, 사용자는 `session` 단위로** 관리할 수 있다.

- vault = 한 최종 사용자에 연결된 `credentials` 모음. `display_name`과 선택적 `metadata`(예: `{"external_user_id": "usr_abc123"}`)를 가진다. ID 형식 `vlt_...`.
- **workspace 범위**: workspace 접근 권한이 있는 어떤 API key든 세션 생성 시 참조할 수 있다. 접근 철회는 vault/credential 삭제로 한다.

### 8.2 Credential 유형

| `auth.type` | 키 | 주입 방식 | 용도 |
| --- | --- | --- | --- |
| `mcp_oauth` | `mcp_server_url` | 해당 URL의 MCP 서버 연결 시 토큰 자동 주입. `refresh` 블록이 있으면 Anthropic이 만료 시 갱신 | OAuth 2.0 MCP 서버 |
| `static_bearer` | `mcp_server_url` | 고정 bearer token 자동 주입 | API key, PAT 등 |
| `environment_variable` | `secret_name`(환경변수 이름) | sandbox에는 **opaque placeholder**로 저장, 아웃바운드 요청의 **egress에서 실제 값으로 치환** | CLI, SDK, 직접 API 호출 |

민감 필드(`token`, `access_token`, `refresh_token`, `client_secret`, `secret_value`)는 **write-only**이며 API 응답에 반환되지 않는다.

`mcp_oauth` 예:

```json
{
  "display_name": "Alice's Slack",
  "auth": {
    "type": "mcp_oauth",
    "mcp_server_url": "https://mcp.slack.com/mcp",
    "access_token": "xoxp-...",
    "expires_at": "2099-12-31T23:59:59Z",
    "refresh": {
      "token_endpoint": "https://slack.com/api/oauth.v2.user.access",
      "client_id": "1234567890.0987654321",
      "scope": "channels:read chat:write",
      "refresh_token": "xoxe-1-...",
      "token_endpoint_auth": {"type": "client_secret_post", "client_secret": "abc123..."}
    }
  }
}
```

`refresh.token_endpoint_auth.type`: `none`(public client), `client_secret_basic`(HTTP Basic), `client_secret_post`(POST body). `refresh.token_endpoint`는 refresh token을 발급한 OAuth flow의 endpoint여야 하며 생성 후 변경 불가.

`environment_variable` 예:

```json
{
  "display_name": "Notion API key for sandbox",
  "auth": {
    "type": "environment_variable",
    "secret_name": "NOTION_API_KEY",
    "secret_value": "ntn_your-secret-here",
    "networking": {"type": "limited", "allowed_hosts": ["api.notion.com"]},
    "injection_location": {"header": true}
  }
}
```

### 8.3 모델에게 secret을 노출하지 않는 방식 (`environment_variable`)

- 에이전트는 secret 값을 보지 못한다. sandbox 안에는 placeholder만 있고, 치환은 **sandbox 밖 egress**에서 일어난다.
- `networking.allowed_hosts`는 "어느 호스트로 가는 요청에 secret을 치환할지"를 정한다(`limited` 목록 또는 `unrestricted`). 도메인 제한이 강력히 권장된다. 이는 "요청 허용 여부"가 아니므로, 실제 도달하려면 **환경 수준에서도** 해당 도메인이 허용되어야 한다(둘 다 필요).
- `injection_location`(`header`, `body` boolean)은 요청의 어느 부분에 치환할지 정한다. 요청 body는 에이전트가 다루는 내용으로 조립되는 경우가 많아 노출면이 넓으므로 `header`만 켜는 것이 더 좁은 설정이다.

| 작업 | `injection_location` 동작 |
| --- | --- |
| 생성 | 객체를 주면 생략한 필드는 `false`(`{"header": true}` = header 전용). 객체 자체를 생략하면 둘 다 활성 |
| 수정 | 필드별 merge(`{"body": false}`는 body만 끔) |

둘 다 끄는 요청, 또는 객체/필드에 명시적 `null`은 400. 응답은 항상 두 필드의 확정값을 반환한다.

주의점:

- 비활성 위치의 placeholder는 치환도 제거도 되지 않고 **문자 그대로** 전송된다. 서드파티에 placeholder가 그대로 도착했다면 그 위치가 꺼져 있거나 host가 `allowed_hosts`에 없는 것이다.
- Console에서 만든 credential은 header 주입만 켜진다. form-encoded token 요청처럼 body로 보내는 클라이언트는 body 주입을 켜야 한다.
- 로컬에서 credential을 처리하는 클라이언트는 placeholder만 본다: 시작 시 형식을 검증하는 클라이언트는 거부할 수 있고, secret으로 서명을 계산하는 클라이언트(예: AWS SigV4)는 잘못된 서명을 만든다. **값을 그대로 아웃바운드 요청에 싣는 클라이언트**에서만 동작한다.
- 치환은 아웃바운드 전용이다. secret으로 session token을 받아오는 교환형 flow(예: OAuth client-credentials)는 반환 토큰이 sandbox에 **마스킹 없이** 들어온다. 이런 경우 교환을 직접 수행하고 결과 토큰을 vault에 저장하라.
- self-hosted sandbox에서는 `environment_variable` credential이 아직 지원되지 않는다.
- 키에는 에이전트에 필요한 권한만 부여할 것(에이전트는 키가 허용하는 모든 것을 할 수 있다).

### 8.4 제약과 런타임 동작

- credential은 저장 시 검증되지 않으며 세션 런타임에 처음 검증된다. 무효 credential은 인증/하위 오류로 나타나지만 세션을 막지는 않는다.
- vault 내 활성 credential 사이에서 `mcp_server_url`/`secret_name`은 고유(중복 시 409). 키는 불변이며 바꾸려면 archive 후 재생성.
- vault당 최대 **20개** credential.
- 세션 생성 시 `vault_ids`로 참조. MCP credential이 URL로 매칭되지 않으면 인증 없이 연결(서버가 인증 요구 시 오류). 여러 vault가 매칭되면 **첫 번째 vault**가 우선. 멀티에이전트 세션에서는 vault credential이 모든 thread에 적용된다.

### 8.5 Rotation과 수명 주기

- 수정 가능: secret 값, `display_name`, (environment variable의) `injection_location`. 잠긴 구조 필드: `mcp_server_url`, `secret_name`, `token_endpoint`, `client_id`.
- credential은 세션 중에도 주기적으로 재해석(re-resolve)되므로 rotation·archive·삭제가 **재시작 없이** 실행 중 세션에 전파된다. `mcp_oauth`는 재해석 시 만료 토큰도 refresh한다.

| Webhook 이벤트 | 트리거 |
| --- | --- |
| `vault.archived` | vault archive(각 credential에 대해 `vault_credential.archived`도 발생) |
| `vault.deleted` | vault 삭제(각 credential에 `vault_credential.deleted`) |
| `vault_credential.archived` | credential archive |
| `vault_credential.deleted` | credential 삭제 |
| `vault_credential.refresh_failed` | `mcp_oauth` refresh 불가 |

OAuth refresh 실패 진단: `POST /v1/vaults/{vault_id}/credentials/{credential_id}/mcp_oauth_validate` → `vault_credential_validation` 객체(`mcp_probe`, `refresh` 포함). `status`가 `valid`(조치 불필요), `invalid`(grant 소멸 또는 4xx → 사용자 재인가), `unknown`(5xx/429/네트워크 → 대기 후 재시도).

기타 작업: 목록(최신순, 기본 archive 제외, `include_archived=true`), vault archive(`POST /v1/vaults/{id}/archive`, credential까지 cascade, secret purge·기록 보존, 이후 이를 참조하는 세션은 실패하나 실행 중 세션은 계속), credential archive(secret purge, 키는 보이며 대체 credential용으로 해제), 삭제(hard delete, 기록 미보존).

---

## 9. Permission policies

### 9.1 정책 종류

권한 정책은 **서버 실행 도구**(내장 agent toolset, MCP toolset)에만 적용된다. Custom tool은 애플리케이션이 실행하므로 대상이 아니다.

| 정책 | 동작 |
| --- | --- |
| `always_allow` | 확인 없이 자동 실행 |
| `always_ask` | 세션이 일시정지하고 승인을 기다림 |
| `auto` | 서버가 호출마다 평가해 실행/거부/승인 대기 중 하나로 처리 |

| Toolset | 기본 정책 |
| --- | --- |
| `agent_toolset_20260401` | `always_allow` |
| `mcp_toolset` | `always_ask` (서버에 새 도구가 추가돼도 승인 없이 실행되지 않도록) |
| (어느 toolset도) | `auto`는 기본값이 아님 |

### 9.2 설정 방법

정책은 Agent `tools`의 `default_config.permission_policy`(toolset 전체) 또는 `configs[].permission_policy`(개별 도구)에 둔다. Agent 수정으로 바꿀 수 있지만 **실행 중 세션은 생성 시의 toolset 설정을 유지**하고, 변경은 이후 생성 세션에 적용된다.

```json
"tools": [
  {
    "type": "agent_toolset_20260401",
    "default_config": { "permission_policy": {"type": "auto"} },
    "configs": [ {"name": "bash", "permission_policy": {"type": "always_ask"}} ]
  },
  {
    "type": "mcp_toolset",
    "mcp_server_name": "github",
    "default_config": { "permission_policy": {"type": "always_allow"} }
  }
]
```

MCP toolset도 서버가 보고한 도구 이름으로 같은 per-tool override를 지원한다.

### 9.3 `auto` 정책

서버는 도구, 호출 입력, 그 시점까지의 세션 내용을 고려해 평가하므로 같은 도구의 두 호출을 다르게 처리할 수 있다.

| 결과 | 동작 |
| --- | --- |
| 실행 | 안전하다고 판단 → `always_allow`처럼 실행 |
| 거부 | 고위험 판단 → 미실행. 에이전트는 `Permission to use {tool_name} has been denied.`, `is_error: true` 결과를 받음. 세션은 계속되며 **클라이언트가 거부를 뒤집을 수 없음** |
| 승인 대기 | 판단 불가 → `always_ask`처럼 일시정지 |

- `user.message`에 쓴 내용은 운영자의 의도로 간주되어, 원래 거부될 호출이 허용될 수도 있다. 서버는 tool result, fetch한 웹페이지, MCP 서버 응답, session thread 간 메시지에서는 의도를 읽지 않는다(평가는 하되 지시로 받지 않음). 일부 호출은 누가 요청하든 고위험으로 평가된다.
- 신뢰할 수 없는 최종 사용자 입력을 `user.message`로 중계하면 그것도 의도로 읽힌다. 그 사용자가 검토 없이 실행하면 안 되는 도구에는 `always_ask`를 설정하라.
- 경고: **`auto`는 사람의 검문소가 아니다.** 안전 판정 시 누구도 보기 전에 실행되며 되돌릴 수 없을 수 있다. 사람이 반드시 검토해야 하면 `always_ask`.

### 9.4 평가 결과 확인

모든 정책에서 `agent.tool_use`, `agent.mcp_tool_use` 이벤트는 `evaluated_permission`(`"allow"`/`"ask"`/`"deny"`)을 가지며, 대부분 어떤 정책이 결과를 냈는지 나타내는 `evaluation` 객체도 가진다.

| `evaluation` | `evaluated_permission` | 의미 |
| --- | --- | --- |
| `{"type":"always_allow"}` | `allow` | 정책상 실행 |
| `{"type":"always_ask"}` | `ask` | 정책상 승인 대기 |
| `{"type":"auto","evaluated_permission":{"type":"allow"}}` | `allow` | auto: 안전 판정, 실행 |
| `{"type":"auto","evaluated_permission":{"type":"ask","reason_code":"indeterminate"}}` | `ask` | auto: 판단 불가, 승인 대기 |
| `{"type":"auto","evaluated_permission":{"type":"deny","reason_code":"high_risk"}}` | `deny` | auto: 고위험, 거부 |

- `evaluation`이 없는 경우: (1) 세션에서 활성화되지 않은 도구를 호출한 경우(`deny`, 정책 평가 없음), (2) `evaluation` 도입 이전 기록 이벤트(`allow`→`always_allow`, `ask`→`always_ask`로 해석).
- `reason_code`는 클라이언트 분기·감사 기록용이며 최종 사용자 표시용이 아니다. 알 수 없는 `evaluation.type`/`reason_code`를 허용하도록 클라이언트를 작성하라.
- `agent.custom_tool_use`에는 두 필드 모두 없다.

### 9.5 확인(confirmation) 흐름

`always_ask`, 또는 `auto`의 판단 불가로 `ask`가 되면:

1. 세션이 `agent.tool_use` 또는 `agent.mcp_tool_use` 이벤트를 낸다.
2. `session.status_idle`(`stop_reason.type: "requires_action"`, 차단 이벤트 ID는 `stop_reason.event_ids`)로 일시정지하고 **무기한** 대기한다. workflow run의 thread에서 온 호출은 primary stream으로 전달되며, 세션의 다른 부분이 작업 중이면 `running` 상태로 `session.status_idle` 없이 머물 수 있으므로 tool-use 이벤트 자체에 응답해야 한다(호출은 run이 그 thread를 마치거나 끝날 때까지만 대기; interrupt 시 대기로 남을 수 있어 직접 allow/deny 필요).
3. 차단 이벤트마다 `user.tool_confirmation`을 보낸다: `tool_use_id`=이벤트 ID, `result`=`"allow"`/`"deny"`, 거부 사유는 `deny_message`. 한 `events` 요청에 여러 개를 담을 수 있다.
4. 모두 해결되면 `running`으로 복귀. 허용된 도구는 실행, 거부된 도구는 실행되지 않고 에이전트는 `deny_message`를 포함한 거부 결과를 받는다.

```json
{
  "events": [{
    "type": "user.tool_confirmation",
    "tool_use_id": "sevt_01def...",
    "result": "deny",
    "deny_message": "Don't create issues in the production project. Use the staging project."
  }]
}
```

`evaluated_permission`이 `ask`가 아닌 이벤트(auto가 거부한 호출 포함)에 confirmation을 보내면 400. 터미널에서는 `ant beta:sessions connect`로 대기 중 호출을 보고 대화형으로 허용/거부할 수 있고, webhook으로 일시정지 알림을 받을 수도 있다.

---

## 10. 정리: 보안 관점의 핵심 설계

| 관심사 | 문서상 메커니즘 |
| --- | --- |
| Agent 정의에서 secret 분리 | MCP 서버는 URL만 선언, 인증은 세션 `vault_ids` |
| 모델에게 secret 비노출 | `environment_variable` credential: placeholder + egress 치환, `allowed_hosts`·`injection_location`으로 범위 제한 |
| 응답에서 secret 비노출 | credential 민감 필드 write-only, `authorization_token` echo 안 됨 |
| 실행 통제 | `always_allow`/`always_ask`/`auto`, MCP 기본 `always_ask` |
| 웹 접근 통제 | 도구별 `allowed_domains`/`blocked_domains` + 환경 `allowed_hosts` (멀티에이전트에서는 좁히기만 가능) |
| 공급망 위험 | repo `.claude/skills`는 검토 없이 로드 → 신뢰 repo만 마운트 |
| 최소 권한 | fine-grained PAT, API key scope 최소화 |

---

## 출처

- Tools — https://platform.claude.com/docs/en/managed-agents/tools
- Restrict web search and web fetch domains — https://platform.claude.com/docs/en/managed-agents/tools-web-restrictions
- MCP connector — https://platform.claude.com/docs/en/managed-agents/mcp-connector
- Skills — https://platform.claude.com/docs/en/managed-agents/skills
- Adding files — https://platform.claude.com/docs/en/managed-agents/files
- Accessing GitHub — https://platform.claude.com/docs/en/managed-agents/github
- Authenticate with vaults — https://platform.claude.com/docs/en/managed-agents/vaults
- Permission policies — https://platform.claude.com/docs/en/managed-agents/permission-policies
