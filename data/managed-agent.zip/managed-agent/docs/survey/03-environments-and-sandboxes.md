# 03. Environment와 Sandbox (Cloud / Self-hosted)

> 기준일: 2026-10-14 · 대상: Claude Managed Agents (public beta, beta header `managed-agents-2026-04-01`)
> 본 장은 공식 문서에 명시된 내용만 정리한다. 문서에 없는 수치(예: CPU 코어 수, 세션 타임아웃)는 "문서에 명시 없음"으로 표기한다.

---

## 1. 개요: Environment란

**Environment**는 에이전트가 실행되는 sandbox의 구성(configuration)을 정의하는 리소스다.

- Environment는 한 번 만들고, 세션을 시작할 때마다 그 ID(`environment_id`)를 참조한다.
- 여러 세션이 같은 environment를 공유할 수 있지만, **각 세션은 자신만의 격리된 sandbox(새 Linux 컨테이너)** 를 받는다. 세션 간 파일시스템 상태는 공유되지 않는다.
- `config.type`에 따라 두 종류가 있다.

| `config.type` | 실행 위치 | 설명 |
| --- | --- | --- |
| `cloud` | Anthropic 관리 인프라 | 기본값. Anthropic이 sandbox 수명주기, 네트워크, 파일/리포 마운트를 관리 |
| `self_hosted` | 고객 인프라 | 오케스트레이션(모델 루프)은 Anthropic, **tool 실행**은 고객의 worker가 수행 |

---

## 2. Cloud Environment 설정

### 2.1 생성과 세션 연결

```bash
curl -fsS https://api.anthropic.com/v1/environments \
  -H "x-api-key: $ANTHROPIC_API_KEY" \
  -H "anthropic-version: 2023-06-01" \
  -H "anthropic-beta: managed-agents-2026-04-01" \
  -H "content-type: application/json" \
  -d '{
    "name": "python-dev",
    "config": {
      "type": "cloud",
      "networking": {"type": "limited", "allow_package_managers": true}
    }
  }'
```

`ant` CLI로는 YAML 파일을 `ant apply environment.yaml`로 적용한다. `ant apply`는 생성된 ID를 `claude-lock.json`에 기록하며, 이 파일을 커밋해 두면 다음 `apply`가 새로 만들지 않고 기존 environment를 갱신한다.

```yaml
# yaml-language-server: $schema=https://platform.claude.com/schemas/ant/beta/environment.json
name: python-dev
config:
  type: cloud
  networking:
    type: limited
    allow_package_managers: true
```

세션 생성 시 `environment_id`를 문자열로 전달한다.

```python
session = client.beta.sessions.create(agent=agent.id, environment_id=environment.id)
```

### 2.2 `packages`: 사전 설치 패키지

`config.packages`는 에이전트 시작 전에 sandbox에 패키지를 설치한다.

- 각 패키지 매니저로 설치되며, **같은 environment를 공유하는 세션 간에 캐시**된다.
- 여러 매니저를 지정하면 **알파벳 순서**(apt → cargo → gem → go → npm → pip)로 실행된다.
- 버전 고정(pin)은 선택 사항이며, 고정하지 않으면 최신 버전이 설치된다.
- `limited` 네트워킹에서 `packages`를 쓰려면 반드시 `networking.allow_package_managers: true`를 설정해야 한다. 그렇지 않으면 **400 에러**로 거부된다(registry 호스트를 `allowed_hosts`에 넣어도 마찬가지).

| 필드 | 패키지 매니저 | 예시 |
| --- | --- | --- |
| `apt` | 시스템 패키지(apt-get) | `"graphviz"` |
| `cargo` | Rust | `"hyperfine@1.18.0"` |
| `gem` | Ruby | `"rails:7.1.0"` |
| `go` | Go modules | `"golang.org/x/tools/cmd/goimports@latest"` |
| `npm` | Node.js | `"express@4.18.0"` |
| `pip` | Python | `"sqlalchemy==2.0.30"` |

```json
"config": {
  "type": "cloud",
  "packages": { "pip": ["pandas", "numpy", "scikit-learn"], "npm": ["express"] },
  "networking": { "type": "limited", "allow_package_managers": true }
}
```

### 2.3 `networking`: 아웃바운드 네트워크 제어

| 모드 | 설명 |
| --- | --- |
| `limited` | `allowed_hosts`에 있는 호스트로만 접근 허용. `allow_package_managers`, `allow_mcp_servers`로 추가 허용. 사전에 나열할 수 없는 사이트에 접근해야 하는 경우가 아니라면 이 모드를 권장 |
| `unrestricted` | 일반 safety blocklist를 제외한 전체 아웃바운드 허용 |

> **주의: 기본값 차이.** API 요청에서 `networking`을 생략하면 **`unrestricted`** 가 된다. 반면 Claude Console의 생성 폼은 **Limited**(아무것도 허용 안 함)로 시작한다. Cloud sandbox reference에 따르면 Claude Studio로 프로비저닝한 sandbox도 기본 `limited`다. 따라서 API에서는 `networking`을 항상 명시하라는 것이 문서의 권고다.

`limited` 모드 세부 규칙:

- `allowed_hosts`: bare hostname 또는 wildcard(`*.example.com`). scheme, port, path는 넣지 않는다.
  - `example.com`은 정확히 그 호스트만 매칭(`www.example.com` 불포함).
  - `*.example.com`은 모든 서브도메인에 매칭되지만 `example.com` 자체는 불포함.
- `allow_mcp_servers` (기본 `false`): 에이전트에 설정된 MCP 서버 엔드포인트로의 접근을 추가 허용. `false`인 상태에서 에이전트(또는 위임 대상 에이전트)가 `allowed_hosts`에 없는 호스트의 MCP 서버를 선언하면 **세션 생성이 400으로 실패**한다.
- `allow_package_managers` (기본 `false`): 아래 공개 registry/코드 호스트를 추가 허용. 목록은 Anthropic이 관리하며 변경될 수 있다.
- 다른 필드 없이 `limited`만 주면 **허용 호스트 0개**. 단, 세션에 첨부한 file, memory store, GitHub repository는 계속 사용 가능하다.
- 허용되지 않은 호스트로 80/443 포트 요청 시 차단된 호스트명을 담은 **403** 응답이 돌아온다.

`allow_package_managers: true` 시 허용되는 호스트:

| 생태계 | 호스트 |
| --- | --- |
| Code hosting | `github.com`, `api.github.com`, `codeload.github.com`, `raw.githubusercontent.com`, `objects.githubusercontent.com`, `release-assets.githubusercontent.com`, `gitlab.com`, `bitbucket.org` |
| Node.js | `registry.npmjs.org`, `registry.yarnpkg.com`, `nodejs.org` |
| Python | `pypi.org`, `files.pythonhosted.org` |
| Rust | `crates.io`, `index.crates.io`, `static.crates.io`, `static.rust-lang.org` |
| Go | `proxy.golang.org`, `sum.golang.org` |
| Java | `repo1.maven.org`, `repo.maven.apache.org`, `services.gradle.org`, `plugins.gradle.org`, `plugins-artifacts.gradle.org` |
| Ruby | `rubygems.org`, `index.rubygems.org` |
| PHP | `packagist.org`, `repo.packagist.org` |
| Ubuntu (apt) | `archive.ubuntu.com`, `security.ubuntu.com`, `ppa.launchpad.net` |
| Containers | `registry-1.docker.io`, `auth.docker.io`, `production.cloudflare.docker.com`, `download.docker.com`, `ghcr.io` |

#### `web_search` / `web_fetch`와의 관계

이 두 도구는 Anthropic 서버에서 실행되지만, `limited` 네트워킹에서는 `allowed_hosts`가 이들에게도 적용된다.

- `allowed_hosts`에 매칭되지 않는 URL에 대한 `web_fetch`는 에러 결과를 반환한다.
- `web_search`는 매칭되지 않는 호스트의 결과를 제외한다.
- `allow_package_managers`/`allow_mcp_servers`는 이 도구들에 호스트를 추가하지 **않는다**.
- `allowed_hosts`가 비어 있으면 `web_fetch`/`web_search`는 어떤 페이지나 결과도 반환하지 않는다.
- 이 도구들을 위해 `allowed_hosts`에 추가한 호스트는 **sandbox에도 열린다**.
- `unrestricted` 네트워킹과 self-hosted environment에서는 이 도구들을 제한하지 않는다. 추가 제한은 agent toolset의 도구 항목에 `allowed_domains`/`blocked_domains`를 설정한다.

#### 보안 경고 (문서 요지)

- 네트워크 허용은 **호스트 단위이지 동작 단위가 아니다**. 허용된 호스트에는 `git push`, 패키지 publish 등 업로드도 가능하다. Prompt injection이 성공하면 허용 호스트를 통해 sandbox 파일이 유출될 수 있다. 완화책으로 `bash` 도구의 permission policy를 `always_ask` 또는 `auto`로 설정하라고 권고한다.
- `unrestricted`의 위험: 에이전트가 외부 사이트를 *변경*할 수 있음, agent toolset 기본 permission policy가 `always_allow`라 `bash`가 승인 없이 실행됨, sandbox 안의 모든 것(파일·출력·자격증명)이 밖으로 나갈 수 있음, 가져온 콘텐츠가 에이전트를 조종할 수 있음, "모델 행동은 보안 통제가 아니다", safety blocklist는 allowlist가 아니다.

### 2.4 환경 변수 / 기타 설정

Cloud environment 문서에서 `config`의 설정 항목은 `type`, `packages`, `networking` 세 가지만 설명된다. **Environment 수준에서 임의 환경 변수(env vars)나 시크릿을 주입하는 필드는 문서에 기술되어 있지 않다.** (sandbox가 기본으로 설정하는 변수로는 `PLAYWRIGHT_BROWSERS_PATH=/opt/pw-browsers`가 언급된다.)

### 2.5 수명주기와 관리 API

- Environment는 명시적으로 archive 또는 delete할 때까지 유지된다.
- **버전 관리가 없다.** 자주 변경한다면 어떤 세션이 어떤 구성을 썼는지 직접 기록해야 한다.

| 작업 | Endpoint | CLI |
| --- | --- | --- |
| 목록 | `GET /v1/environments` | `ant beta:environments list` |
| 조회 | `GET /v1/environments/{id}` | `ant beta:environments retrieve --environment-id ...` |
| Archive (읽기 전용화, 기존 세션은 계속) | `POST /v1/environments/{id}/archive` | `ant beta:environments archive ...` |
| 삭제 (참조하는 세션이 없을 때만) | `DELETE /v1/environments/{id}` | `ant beta:environments delete ...` |

---

## 3. Cloud Sandbox 사양

Cloud sandbox는 Anthropic 관리 인프라 위의 격리된 Linux 컨테이너다. 아래 사양은 `cloud` environment에만 해당한다(self-hosted는 worker가 제공하는 것이 전부).

### 3.1 하드웨어/OS

| 항목 | 값 |
| --- | --- |
| OS | Ubuntu 24.04 LTS |
| 아키텍처 | x86_64 (amd64) |
| 메모리 | 최대 8 GB |
| 디스크 | 최대 10 GB |
| 네트워크 | API로 만든 environment는 기본 `unrestricted`, Claude Studio로 프로비저닝한 sandbox는 기본 `limited` |
| CPU | 문서에 명시 없음 |
| 실행 타임아웃 / 유휴 타임아웃 | 문서(본 장 대상 페이지)에 명시 없음 |

### 3.2 언어 런타임

| 언어 | 버전 | 패키지 매니저 |
| --- | --- | --- |
| Python | 3.10, 3.11, 3.12, 3.13 | pip, uv, poetry |
| Node.js | 20, 21, 22 (기본) | npm, yarn, pnpm, bun |
| Go | 1.24 (기본), 1.25 | go modules |
| Rust | stable (rustup) | cargo |
| Java | OpenJDK 21 | maven, gradle |
| Ruby | 3.1, 3.2, 3.3 (기본) | bundler, gem |
| PHP | 8.3 | composer |
| C/C++ | GCC 13, Clang | make, cmake, ninja |

`python3`에는 NumPy, pandas, Matplotlib, openpyxl, python-docx, python-pptx, pypdf 등이 설치되어 있다.

### 3.3 데이터베이스

| DB | 설명 |
| --- | --- |
| PostgreSQL 16 | 서버와 `psql` 설치, **기본적으로 서버는 실행되지 않음** |
| Redis 7 | 서버와 `redis-cli` 설치, **기본적으로 실행되지 않음** |
| SQLite | 언어 바인딩(예: Python `sqlite3`)으로 사용 |

### 3.4 유틸리티

| 분류 | 도구 |
| --- | --- |
| 시스템 | `git`, `curl`, `wget`, `jq`, `yq`, `tar`, `zip`, `unzip`, `tmux` |
| 개발 | `make`, `cmake`, `docker`(제한적 가용성), `ripgrep`(`rg`) |
| 텍스트 | `sed`, `awk`, `grep`, `vim`, `nano`, `diff`, `patch` |
| 문서/미디어 | `ffmpeg`, ImageMagick(`convert`, `identify`), `pandoc`, LibreOffice(headless), Poppler(`pdftotext`, `pdftoppm`), `qpdf`, `tesseract`(영어 데이터), TeX Live(`pdflatex`, `xelatex`, `latexmk`) |
| 브라우저 자동화 | Playwright(Python/Node.js), Chromium(`/opt/pw-browsers/chromium`, `PATH`에 없음) |

Playwright 관련: sandbox가 `PLAYWRIGHT_BROWSERS_PATH=/opt/pw-browsers`를 설정하므로 사전 설치된 패키지는 별도 설정 없이 Chromium을 찾는다. 다른 Playwright 버전을 설치하면 없는 브라우저 빌드를 찾게 되므로 사전 설치본 사용을 권장한다. Firefox와 WebKit은 설치되어 있지 않다.

### 3.5 영속성(persistence)

- 각 세션은 독립 sandbox 인스턴스를 받으며 세션 간 파일시스템은 공유되지 않는다.
- `packages`로 설치한 패키지는 같은 environment를 쓰는 세션들 사이에 **캐시**된다.
- 세션 간 지속되어야 하는 데이터는 memory store(`/mnt/memory/` 마운트)를 통해 다룬다(자세한 내용은 memory 장 참조).

---

## 4. Self-hosted Sandbox 아키텍처

### 4.1 목적

Self-hosted sandbox는 **오케스트레이션은 Anthropic 측에 두고, tool 실행을 고객이 통제하는 인프라로 옮긴다.** 에이전트의 파일, 프로세스, 네트워크 트래픽은 고객 환경에 머문다. 적합한 경우:

- 데이터가 네트워크 경계를 벗어날 수 없을 때
- 공개 라우팅되지 않는 내부 서비스에 접근해야 할 때
- 조직 자체의 컴플라이언스/감사 통제 하에 실행해야 할 때

모든 Managed Agents 지원 Claude 모델을 사용할 수 있으며, 모델은 environment가 아니라 agent에서 설정한다.

### 4.2 동작 방식: Work Queue 모델

`self_hosted` environment는 **work queue** 로 동작하고, 고객이 실행하는 **environment worker** 프로세스가 이 큐를 처리한다.

1. `self_hosted` environment를 대상으로 세션을 만들면 Anthropic이 세션을 **work item**으로 큐에 넣는다.
2. Worker가 work item을 **claim**하고, 에이전트의 skills와 세션의 memory store를 다운로드한다.
3. Claude는 Anthropic 측에서 실행되며 tool call을 요청한다. Worker는 각 호출을 로컬에서 실행하고 결과를 다시 post한다.

```
 ┌──────────────── Anthropic (control plane) ────────────────┐
 │                                                            │
 │   Sessions API ──▶ Work queue (per environment)           │
 │        ▲               │  depth / pending / workers_polling│
 │        │               │                                   │
 │   Claude 모델 루프  ◀──┼── tool 결과 (input/output은       │
 │   (tool_use 요청)      │    control plane으로 흐름)        │
 │   Skills, Memory store │ (원본 저장소 = source of truth)   │
 └────────────────────────┼───────────────────────────────────┘
                          │  outbound HTTPS only
                          │  (poll / claim / ack / heartbeat / result)
                          │  인증: ANTHROPIC_ENVIRONMENT_KEY
                          │        + work item별 secret
 ┌────────────────────────▼─────── 고객 인프라 ───────────────┐
 │  Environment worker (ant CLI 또는 SDK EnvironmentWorker)   │
 │   ├─ (in-process) bash/read/write/edit/glob/grep 실행      │
 │   │      workdir: /workspace, skills: <workdir>/skills/    │
 │   │      memory: /mnt/memory/<store>/  (주기적 sync)       │
 │   ├─ custom tools (SDK worker만) → 내부 서비스/MCP 서버    │
 │   └─ 또는 --on-work → 세션별 sandbox(컨테이너) 기동        │
 │                       └─ ant beta:worker run / SDK handle_item │
 └────────────────────────────────────────────────────────────┘
```

핵심 포인트:

- **Worker는 아웃바운드 HTTPS만 필요하다**(always-on 모드). 인바운드 연결이 필요 없다(webhook 모드 제외).
- **Tool 입력과 출력은 여전히 Anthropic control plane으로 전달된다.** 모델이 결과를 보고 다음 행동을 결정해야 하기 때문이다.
- Skills와 memory store는 Anthropic이 저장하며, sandbox는 세션 동안 사본을 보유한다.
- 연결된 worker가 없으면 세션은 실패하지 않고 **큐에서 대기**한다.

### 4.3 Cloud와의 차이

| | Cloud environment | Self-hosted sandbox |
| --- | --- | --- |
| Tool 실행 위치 | Anthropic 관리 sandbox | 고객 인프라 |
| 네트워크 도달 범위 | Anthropic egress 통제(`networking`) | 고객 네트워크 정책 |
| File / GitHub repo 마운트 | Anthropic이 관리 | 고객이 관리 |
| Memory store | Anthropic이 `/mnt/memory/`에 마운트 | Worker가 `/mnt/memory/`로 다운로드 및 sync |
| 수명주기 | Anthropic 관리 | 고객 관리 |

**세션 resources 제약:** self-hosted environment는 `memory_store` 리소스만 지원한다. `file`이나 `github_repository` 리소스를 포함하면 400으로 거부된다.

```text
Environment env_... is a self-hosted environment. `resources` are not supported with self-hosted environments.
```

Self-hosted environment를 대상으로 하는 scheduled deployment도 같은 규칙을 따른다. ZDR 및 HIPAA BAA 적격성은 별도 문서(API and data retention)를 참조하라고 되어 있다.

### 4.4 Self-hosted와 MCP tunnel

두 기능은 서로 독립적이다.

- Self-hosting은 *에이전트 코드가 어디서 실행되는가*를 통제한다.
- MCP tunnel은 *Anthropic이 고객 네트워크의 MCP 서버에 어떻게 도달하는가*를 통제한다.
- Cloud sandbox 세션도 tunnel로 사설 MCP 서버에 접근할 수 있고, self-hosted 세션은 tunnel 또는 공개 MCP 서버를 쓸 수 있다.
- Tunnel 없이 가려면 MCP 서버를 **custom tool로 감싸 worker가 서빙**하면 된다(§7.2).

### 4.5 Quickstart 흐름

전제 조건:

- Agent (ID)
- **`/bin/bash`가 정확히 그 경로에 있는 Linux 호스트.** Worker는 아웃바운드 HTTPS만 필요
- Claude API key: 자신의 머신에서 세션 생성·큐 통계 조회용. **Worker 호스트에는 두지 말 것**(agent의 tool call이 읽을 수 있음)

> Claude Platform on AWS에서는 worker가 environment key 대신 AWS IAM(SigV4) 또는 AWS Console에서 생성한 API key로 인증한다. Worker의 IAM principal에 `AnthropicSelfHostedEnvironmentAccess` managed policy를 붙인다. Claude Console에서 생성한 environment key는 AWS 엔드포인트에서 동작하지 않는다.

단계:

```bash
# 1) self-hosted environment 생성 (Console: Workspace > Environments > New > Self-hosted, 또는 API)
curl -sS --fail-with-body https://api.anthropic.com/v1/environments \
  -H "x-api-key: $ANTHROPIC_API_KEY" -H "anthropic-version: 2023-06-01" \
  -H "anthropic-beta: managed-agents-2026-04-01" -H "content-type: application/json" \
  -d '{"name": "self-hosted", "config": {"type": "self_hosted"}}'

# 2) Console에서 environment를 열고 "Generate environment key" (Console에서만 발급 가능)
export ANTHROPIC_ENVIRONMENT_KEY="sk-ant-oat01-..."
export ANTHROPIC_ENVIRONMENT_ID="env_..."

# 3) worker 호스트에 ant CLI 설치 (예: v1.40.0 릴리스 바이너리, 또는 brew install anthropics/tap/ant)

# 4) worker 시작 (--workdir 기본값은 현재 디렉터리 → 시스템 기본값 /workspace에 맞춤)
sudo mkdir -p /workspace && sudo chown "$USER" /workspace
ant beta:worker poll --workdir /workspace

# 5) (자기 머신에서, API key로) workers_polling >= 1 확인
ant beta:environments:work stats --environment-id "$ANTHROPIC_ENVIRONMENT_ID"

# 6) 세션 생성 후 user.message 전송 → worker 호스트의 /workspace/hello.txt로 실행 위치 확인
```

---

## 5. Worker 배포 패턴

두 가지 선택 축이 있다.

**Work를 claim하는 방식**

- **Always-on:** 장기 실행 프로세스가 큐를 계속 poll. 아웃바운드 HTTPS만 필요. 가장 단순함.
- **Webhook-triggered:** 핸들러가 `session.status_run_started` 이벤트에 깨어나 polling 시작. 유휴 poller가 없지만, Anthropic이 도달 가능한 webhook 엔드포인트가 필요.

**세션이 실행되는 위치**

- **In process:** claim한 worker가 tool call도 직접 실행. 하나의 공유 작업 디렉터리 사용.
- **Sandbox per session:** poller가 claim한 세션마다 새 sandbox를 띄움. 새 파일시스템, 리소스 제한, 세션별 네트워크 통제 등 더 강한 격리.

| 기능 | `ant` CLI | SDK (Python, TypeScript, Go) |
| --- | --- | --- |
| Always-on polling | Yes | Yes |
| Webhook-triggered | No | Yes |
| Sandbox per session | Yes | Yes |
| Memory stores | Yes (기본 sync 설정만) | Yes (sync 설정 가능) |
| Custom tools | No | Yes |

C#, Java, PHP, Ruby SDK에는 `EnvironmentWorker`/work poller 헬퍼가 현재 없으며, `ant` CLI worker를 쓰거나 Environments Work endpoint를 직접 호출해야 한다. 직접 worker를 구현하려면 Environments Work endpoint를 호출하면 된다.

### 5.1 Always-on worker

```bash
ant beta:worker poll --workdir /workspace
```

```python
from anthropic import AsyncAnthropic
from anthropic.lib.environments import EnvironmentWorker

async with AsyncAnthropic(auth_token=environment_key) as client:
    worker = EnvironmentWorker(
        client, environment_id=environment_id, environment_key=environment_key, workdir="/workspace"
    )
    task = asyncio.create_task(worker.run())
    # SIGINT/SIGTERM에서 task.cancel() → 진행 중 work item 정리 및 memory 업로드 후 종료
```

SDK client는 API key가 아니라 **environment key를 `auth_token`으로** 사용한다.

### 5.2 Webhook-triggered worker

1. Console에서 `session.status_run_started`를 수신하는 webhook 엔드포인트를 정의한다.
2. 핸들러 호스트에 `ANTHROPIC_WEBHOOK_SIGNING_KEY="whsec_..."`를 export한다(payload 서명 검증용; Python은 `pip install "anthropic[webhooks]"`).
3. 핸들러는 서명을 검증하고(`client.beta.webhooks.unwrap`), 큐를 drain하면서 각 item을 `handle_item()`에 넘긴다.

```python
async for work in client.beta.environments.work.poller(
    environment_id=environment_id,
    environment_key=environment_key,
    block_ms=None,
    reclaim_older_than_ms=2000,
    drain=True,
    auto_stop=False,
):
    await client.beta.environments.work.worker(workdir="/workspace").handle_item(
        work_id=work.id,
        environment_id=environment_id,
        session_id=work.data.id,
        environment_key=environment_key,
        work_secret=work.secret,  # memory store 마운트에 필요한 세션별 secret
    )
```

문서 예제의 구현 포인트:

- 세션은 webhook 전달 타임아웃보다 오래 갈 수 있으므로 작업을 요청 컨텍스트에서 분리한다(Python은 `asyncio.shield`, Go는 `r.Context()` 대신 프로세스 shutdown context 사용).
- 종료 중에는 503을 반환해 sender가 재시도하도록 한다("실행되지 않을 delivery를 ack하지 말 것").
- 이 핸들러는 claim한 모든 item을 한 호스트·한 프로세스에서 실행한다. 같은 memory store를 공유하는 세션이 있으면 §8.4 참조.

### 5.3 Sandbox per session

Host의 poller가 work를 claim하고 item마다 스크립트를 한 번 호출, 스크립트가 해당 세션용 sandbox를 띄운다.

**이미지**: `ant`를 설치하고 entrypoint를 `ant beta:worker run`으로 설정. 시작 시 환경 변수에서 세션 정보를 읽어 그 세션을 처리하고 종료한다. 베이스 이미지는 `/bin/bash`를 제공해야 한다.

```dockerfile
FROM your-base-image
ARG ANT_VERSION=1.40.0
ARG TARGETARCH
RUN ARCH=$([ "$TARGETARCH" = "arm64" ] && echo arm64 || echo amd64) && \
    curl -fsSL "https://github.com/anthropics/anthropic-cli/releases/download/v${ANT_VERSION}/ant_${ANT_VERSION}_linux_${ARCH}.tar.gz" \
      | tar -xz -C /usr/local/bin ant
WORKDIR /workspace
VOLUME /workspace
ENTRYPOINT ["ant", "beta:worker", "run"]
```

**spawn 스크립트** (poller 호스트에 `jq` 필요):

```bash
#!/bin/bash
# claim된 work item JSON이 stdin으로 들어온다
ANTHROPIC_WORK_SECRET="$(jq -r '.secret // empty')"
export ANTHROPIC_WORK_SECRET
mkdir -p "/host/outputs/$ANTHROPIC_SESSION_ID"
exec docker run --rm \
  -e ANTHROPIC_SESSION_ID -e ANTHROPIC_ENVIRONMENT_KEY \
  -e ANTHROPIC_WORK_ID -e ANTHROPIC_ENVIRONMENT_ID -e ANTHROPIC_BASE_URL \
  -e ANTHROPIC_WORK_SECRET \
  -v "/host/outputs/$ANTHROPIC_SESSION_ID":/workspace \
  your-image
```

```bash
ant beta:worker poll --on-work ./spawn.sh
```

- Poller는 `ANTHROPIC_*` 변수를 설정해 주지만 **secret은 설정하지 않는다** → 스크립트가 stdin JSON의 `secret`을 꺼내 전달해야 한다.
- `/host/outputs`를 `/workspace`에 마운트하면 sandbox 종료 후 산출물(그리고 다운로드된 `skills/` 트리, 중간 파일)을 회수할 수 있다.

SDK로 직접 claim할 때는 `work.poller()`(Go: `environments.NewWorkPoller()`)를 사용하고 `auto_stop=False`로 둔다(띄운 sandbox가 stop 호출을 소유하므로). Custom tool이나 비기본 memory sync 설정이 필요하면 sandbox entrypoint를 `ant beta:worker run` 대신 SDK `EnvironmentWorker(...).handle_item()`으로 바꾼다(인자 없이 호출하면 `ANTHROPIC_*` 변수를 읽음).

### 5.4 Work item secret 전달

각 claim된 work item은 Anthropic이 발급한 **세션별 `secret`** 을 가질 수 있다. Memory store 마운트에 필요하다.

| Claim 방식 | Secret 도착 위치 | Worker에 전달하는 방법 |
| --- | --- | --- |
| `ant beta:worker poll --on-work` | 스크립트 stdin의 work item JSON `secret` 필드 | sandbox 환경 변수 `ANTHROPIC_WORK_SECRET` |
| SDK `work.poller()` / `NewWorkPoller()` | 각 work item의 `secret` 필드 | `ANTHROPIC_WORK_SECRET` 또는 `handle_item(work_secret=...)` |

In-process worker(`--on-work` 없는 `ant beta:worker poll`, `EnvironmentWorker.run()`)는 이를 자동 처리한다. Secret은 해당 세션을 서빙하는 sandbox에만 전달하고 절대 로그에 남기지 않는다.

### 5.5 세션 입력 파일 스테이징

Anthropic은 self-hosted sandbox에 파일이나 GitHub 리포를 마운트하지 않는다. 대신:

1. 세션 `metadata`에 파일 참조(예: S3 경로, 커밋 SHA)를 넣는다.
2. spawn 스크립트나 `--on-work` 핸들러에서 `GET /v1/sessions/{session_id}`로 `metadata`를 읽는다(work item에는 session ID만 있고 metadata는 없음).
3. Tool 실행 시작 전에 작업 디렉터리에 파일을 스테이징한다.

```bash
ant beta:sessions create --agent "$AGENT_ID" \
  --environment-id "$ANTHROPIC_ENVIRONMENT_ID" \
  --metadata '{"input_file": "s3://my-bucket/data.csv"}'
```

---

## 6. Worker 레퍼런스

### 6.1 CLI 명령과 플래그

| 명령 | 설명 |
| --- | --- |
| `ant beta:worker poll` | 큐에서 work item을 claim하고 각 세션을 in-process로 실행. `--on-work`가 있으면 item마다 스크립트를 호출 |
| `ant beta:worker run` | claim된 세션 하나를 처리하고 종료. 세션별 sandbox의 entrypoint용 |

| 플래그 | 설명 | 기본값 |
| --- | --- | --- |
| `--environment-id` | Poll할 environment (`ANTHROPIC_ENVIRONMENT_ID`에서도 읽음) | – |
| `--environment-key` | Worker 인증 (`ANTHROPIC_ENVIRONMENT_KEY`에서도 읽음) | – |
| `--workdir` | Skills 다운로드 및 tool 파일 I/O 디렉터리 | `.` (현재 디렉터리) |
| `--on-work` | item마다 호출할 스크립트. 세션 정보는 환경 변수, work item은 stdin JSON | – |
| `--max-idle` | 세션이 `end_turn` stop reason으로 idle이 된 뒤 종료까지 대기 시간 | `60s` |
| `--log-format` | 로그 포맷(`json`이면 구조화 로그) | `text` |

### 6.2 환경 변수

| 변수 | 설명 | 설정 주체 |
| --- | --- | --- |
| `ANTHROPIC_ENVIRONMENT_ID` | Worker가 서빙하는 environment | 사용자(worker 호스트). Poller가 `--on-work` 스크립트에 전달 |
| `ANTHROPIC_ENVIRONMENT_KEY` | 큐 인증 | 사용자. Poller가 `--on-work` 스크립트에 전달 |
| `ANTHROPIC_SESSION_ID` | Work item이 나타내는 세션 | Poller (`--on-work` 스크립트용) |
| `ANTHROPIC_WORK_ID` | Claim된 work item | Poller (`--on-work` 스크립트용) |
| `ANTHROPIC_WORK_SECRET` | Work item의 세션별 secret | **사용자** (poller는 설정하지 않음) |
| `ANTHROPIC_BASE_URL` | 기본 API 엔드포인트 override (선택) | 사용자 |
| `ANTHROPIC_WEBHOOK_SIGNING_KEY` | Webhook payload 검증 | 사용자(webhook 핸들러 호스트) |

### 6.3 호스트 요구사항

| Worker | 요구사항 |
| --- | --- |
| 모든 worker | `/bin/bash`가 정확히 그 경로에 있는 Linux 호스트. bash tool이 `PATH`를 거치지 않고 직접 호출 |
| TypeScript SDK | `PATH`에 `unzip`, `tar`; Node.js 22 이상 |
| Python / Go SDK | 추가 바이너리 불필요(표준 라이브러리로 압축 해제) |

Memory store 사용 시 추가 요구사항은 §8.1.

### 6.4 Sandbox 파일시스템

| 경로 | 내용 |
| --- | --- |
| `/workspace` | 시스템 기본 작업 디렉터리(tool 실행, skill 다운로드). 다른 경로를 쓰면 Claude가 skill 파일을 찾을 수 있도록 agent system prompt를 수정해야 함 |
| `<workdir>/skills/<name>/` | 다운로드된 agent skills |
| `/mnt/memory/<store>/` | 첨부된 memory store당 하나, store의 `mount_path`에 위치. 세션 claim 시 생성, 종료 시 제거 |

- Self-hosted에서는 세션 system prompt에 Anthropic 관리 sandbox용 `/mnt/session/outputs` 지시가 **빠진다.** 최종 산출물은 에이전트가 쓰는 위치(보통 작업 디렉터리 아래)에 남는다.
- Skill 번들의 실행 권한은 CLI/SDK worker가 압축 해제 시 보존한다. Skills 다운로드를 직접 구현하면 권한 설정은 구현자 책임.

### 6.5 SDK 헬퍼 (Python / TypeScript / Go)

| 헬퍼 | 역할 | 사용 시점 |
| --- | --- | --- |
| `EnvironmentWorker` | polling, setup, 실행을 end-to-end 처리 | 대부분의 경우 |
| `work.poller()` (Go: `environments.NewWorkPoller()`) | 큐를 poll하고 claim된 세션을 넘겨줌 | 세션마다 sandbox를 띄우는 등 처리 방식을 직접 결정할 때 |
| `client.beta.sessions.events.tool_runner()` | 세션 ID와 tool 목록으로 단일 세션의 tool call 실행 | 이미 claim했고 실행 계층만 필요할 때 |

**`EnvironmentWorker`**

| 메서드/옵션 | 설명 |
| --- | --- |
| `run()` | 무한 실행하며 도착하는 세션 처리 |
| `handle_item()` | claim된 work item 하나를 처리하고 반환. 식별자와 `work_secret`을 명시하거나 `ANTHROPIC_*` 변수에서 읽음 |
| `tools` (Go: `ToolsFunc`) | 세션의 `AgentToolContext`를 받아 tool 목록을 반환하는 factory. 기본은 표준 agent toolset |
| `memory_sync_interval` | memory store reconcile 주기 (§8.3) |
| `memory_sync_deletions` | 로컬 삭제를 store에도 반영할지 (§8.3) |

`EnvironmentWorker`는 **signal handler를 설치하지 않는다.** 독립 프로세스로 쓸 때는 직접 SIGINT/SIGTERM에서 cancel해야 한다.

**Work poller 옵션**

| 옵션 | 설명 |
| --- | --- |
| `drain` | 큐가 비면 대기하지 않고 polling 종료 |
| `block_ms` | 각 poll의 long-poll 대기(ms). 1–999 범위, 헬퍼가 자동 재poll. `null`이면 non-blocking. 기본 999 ms |
| `reclaim_older_than_ms` | claim됐지만 이 시간 내 ack되지 않은 item을 재claim |
| `auto_stop` | loop 본문이 끝난 item에 stop 신호를 post할지. `handle_item()`이나 띄운 sandbox가 stop을 직접 post하면 `false` |

**`AgentToolContext`** — tool call 실행 컨텍스트(작업 디렉터리, 경로 정책, skill 다운로드).

| 옵션 | 설명 |
| --- | --- |
| `allowed_roots` | 작업 디렉터리 외에 파일 도구(`read`, `write`, `edit`, `glob`, `grep`)가 접근 가능한 디렉터리 |
| `read_only_roots` | `write`/`edit`가 거부하는 디렉터리 |

`EnvironmentWorker`는 memory store 디렉터리를 `allowed_roots`에, `access: "read_only"` store를 `read_only_roots`에 자동 추가한다. **이 confinement는 파일 도구용 가드레일일 뿐 sandbox가 아니며 `bash`는 제약하지 않는다.** `beta_agent_toolset_20260401(env)`는 표준 tool 구현(`bash`, `read`, `write`, `edit`, `glob`, `grep`)을 반환한다.

---

## 7. Self-hosted에서의 Custom Tools와 MCP

### 7.1 Custom tool 서빙

Custom tool은 에이전트가 `agent.custom_tool_use` 이벤트를 내고 `user.custom_tool_result`를 기다리는 도구다. Worker가 그 실행 주체가 될 수 있으며, sandbox 안에서 돌기 때문에 sandbox에 구성된 내부 서비스·자격증명·egress에 접근한다(그 이상은 아님). Custom tool 결과 post는 **environment key로 인가**되므로 Claude API key를 worker 호스트에 둘 필요가 없다.

- **SDK worker 필수.** `ant` CLI worker는 custom tool 구현을 등록할 방법이 없다. Sandbox-per-session 패턴에서는 sandbox 안에서 SDK worker를 실행한다.
- 절차: (1) agent의 `tools`에 `type: "custom"` 항목 선언 → (2) worker의 `tools` factory에 같은 `name`의 구현 등록.

```python
@beta_async_tool
async def get_order_status(order_id: str) -> str:
    """Look up an order in the internal fulfillment system by order ID."""
    return f"Order {order_id}: shipped"  # worker 호스트에서 실행


await EnvironmentWorker(
    client,
    environment_id=environment_id,
    environment_key=environment_key,
    workdir="/workspace",
    tools=lambda env: [*beta_agent_toolset_20260401(env), get_order_status],
).run()
```

Worker는 자신에게 등록된 도구만 응답한다. Agent에 선언됐지만 아무 worker/client도 서빙하지 않으면 세션은 `requires_action` stop reason으로 **일시정지**되어 결과가 post될 때까지 대기한다.

### 7.2 MCP 서버를 custom tool로 감싸기 (tunnel 없이)

MCP connector는 Anthropic 측에서 MCP 서버에 연결하므로 서버가 Anthropic에서 도달 가능한 HTTP 엔드포인트(직접 또는 MCP tunnel 경유)를 노출해야 한다. 내부망에서만 접근 가능한 서버라면 **worker를 MCP client로 만들고** 서버의 도구를 custom tool로 선언한다. MCP 서버는 외부로부터의 인바운드 연결이 필요 없다. Anthropic은 agent에 선언된 tool 정의, 각 호출의 input, worker가 post한 결과를 받는다.

런타임 흐름: `agent.custom_tool_use` 발생 → worker가 열린 MCP 세션으로 내부 서버에 호출 전달 → 서버 응답을 `user.custom_tool_result`로 post.

설치: `pip install "anthropic[mcp]" "mcp>=1.24"` (TS: `npm install @modelcontextprotocol/sdk`, Go: `go get github.com/modelcontextprotocol/go-sdk`). 인증이 필요하면 MCP transport에 넘기는 `http_client`(TS: `requestInit`, Go: `HTTPClient`)를 설정한다.

1. **Agent에 선언** (API key가 있는 곳에서 실행, worker 호스트 아님): MCP `list_tools` 결과의 `name`, `description`, `inputSchema`를 custom tool 필드로 1:1 매핑. 페이지네이션되면 모든 페이지를 선언해야 하며 worker도 같은 페이지를 나열해야 한다.
2. **Worker에서 서빙**: 시작 시 같은 서버에 연결하고 `async_mcp_tool`(TS: `mcpTools`, Go: `mcp.NewBetaTools`)로 변환해 toolset과 함께 등록. **MCP 세션 하나를 worker 수명 동안 유지**.

```python
async with (
    streamable_http_client(MCP_SERVER_URL) as (read, write, _),
    ClientSession(read, write, read_timeout_seconds=timedelta(seconds=60)) as mcp_session,
    AsyncAnthropic(auth_token=environment_key) as client,
):
    await mcp_session.initialize()
    listed = await mcp_session.list_tools()
    mcp_tools = [async_mcp_tool(tool, mcp_session) for tool in listed.tools]
    await EnvironmentWorker(
        client,
        ...,
        workdir="/workspace",
        tools=lambda env: [*beta_agent_toolset_20260401(env), *mcp_tools],
    ).run()
```

### 7.3 제약과 동작

- **런타임 디스커버리 없음:** worker는 시작 시 한 번만 도구를 나열하며 실행 중 세션에 도구를 추가할 수 없다. 서버 도구가 바뀌면 (1) agent 또는 idle 세션에 다시 선언하고 (2) worker를 재시작한다.
- **선언 규칙:**

| 필드 | 규칙 |
| --- | --- |
| `name` | agent 내 유일. 영문자·숫자·`_`·`-`, 1–128자. `bash`, `read` 등 내장 도구명 불가, `mcp__`/`ant__` 접두사 예약 |
| `description` | 필수, 비어 있으면 안 됨 |
| `input_schema` | `additionalProperties`, `title` 등 허용. `$ref`(어디서든)와 최상위 `oneOf`/`anyOf`/`allOf` 거부. 속성명은 영문자·숫자·`_`·`.`·`-`, 1–64자 |
| agent `tools` 배열 | 최대 256개. 감싼 도구 각각 1개, 내장 toolset 1개 |

  - 두 서버가 같은 도구명을 노출하면 접두사를 붙인 래퍼를 직접 정의한다.
  - pydantic 등이 `$defs`로 스키마를 분리하면 선언 전에 inline한다.
- **실패 처리:** MCP 서버의 tool 에러는 에러 tool result로 post된다. 오디오 블록, resource link 등 tool result에 대응하지 않는 콘텐츠도 에러로 처리된다. MCP client에 타임아웃을 설정하라(미설정 시 §9.3의 backstop까지 대기).
- **신뢰:** 감싼 도구의 이름·설명·결과는 모델 컨텍스트에 들어가는 비신뢰 입력이며 worker 호스트의 `bash` 등 다른 도구 사용에 영향을 줄 수 있다. 운영하거나 신뢰하는 서버만 감쌀 것.
- **Permission policy 미적용:** permission policy는 내장/MCP toolset에 적용되며, worker는 감싼 도구 호출을 모두 실행한다. 승인 단계가 필요하면 도구 코드에 직접 넣는다.

---

## 8. Self-hosted에서의 Memory Store

세션은 cloud와 동일하게 `resources`에 memory store를 나열해 첨부한다(세션당 **최대 8개**). 차이는 **누가 materialize하느냐**: self-hosted에서는 worker가 store를 sandbox로 다운로드하고 에이전트의 변경을 다시 sync한다.

### 8.1 요구사항

- Memory store를 마운트하는 worker: `ant` CLI **1.33.0 이상**, 또는 Python/TypeScript/Go SDK의 `EnvironmentWorker`
- POSIX 파일시스템: memory 파일을 열 때 `O_NOFOLLOW`가 필요하므로 **Windows 호스트 미지원**. 대소문자 구분 파일시스템 권장
- 쓰기 가능한 `/mnt/memory` 디렉터리
- Work item의 secret (자체 코드가 worker를 띄운다면 전달 필요)
- **Claude Platform on AWS의 self-hosted environment에서는 memory store를 첨부할 수 없다.**

### 8.2 호스트 준비와 동작

```bash
sudo mkdir -p /mnt/memory && sudo chown "$USER" /mnt/memory
```

- 각 store의 `mount_path` 디렉터리(예: `/mnt/memory/user-preferences`)는 **직접 만들지 말 것.** Worker가 세션 시작 시 만들고 종료 시 제거하며, 이미 무언가 존재하면 해당 세션 작업 시작을 거부한다.
- Sandbox-per-session 패턴에서는 이미지에 쓰기 가능한 `/mnt/memory`만 있으면 되고 호스트 bind-mount는 불필요(종료 전 worker가 업로드).

Worker의 처리 순서:

1. 각 store를 `mount_path`로 다운로드(cloud와 같은 `/mnt/memory/` 아래; system prompt가 에이전트에게 설명). 예: "User Preferences" → `/mnt/memory/user-preferences/`
2. 해당 디렉터리를 파일 도구에 개방
3. Tool call 후 변경 사항 reconcile — 최대 sync interval당 1회(기본 15초). store에서 바뀐 memory는 디스크에 쓰고, 에이전트가 바꾼 파일은 업로드
4. 세션 종료 시 최종 sync — 남은 업로드를 최대 30초간 flush 후 디렉터리 제거

- Anthropic 측 store가 **source of truth**. Memory 버전, redaction, Console 조회/편집은 cloud와 동일. Memory 읽기/쓰기는 이벤트 스트림에 일반 tool 이벤트로 나타난다.
- 세션 간 가시성: 각 worker가 주기적으로 sync하므로 다른 세션의 변경은 양쪽이 sync한 뒤에 보인다(기본값에서 보통 1분 미만). Cloud sandbox 세션끼리는 거의 즉시 보인다.
- 각 store 디렉터리에는 `.anthropic-memory-store` 마커 파일이 있다. 없거나 변경되면 worker가 그 디렉터리를 sync하지 않는다.
- Worker가 정상 종료가 아니라 kill되면 teardown이 없어 미동기화 편집이 유실되고 디렉터리가 남는다.

### 8.3 Sync 설정 (SDK만; `ant` CLI는 항상 기본값)

`memory_sync_interval` (TS: `memorySyncIntervalMs`, Go: `MemorySyncInterval`):

| 설정 | 값 |
| --- | --- |
| 기본 | 15초 |
| 최소 | 5초 |
| 예시(10초) | `10` (TS: `10_000`, Go: `10 * time.Second`) |
| memory 지원 비활성화 | `None` (TS: `null`, Go: `-1`) |

- 비활성화는 memory store를 첨부하지 않는 세션만 받는 worker에서만 사용. 비활성 worker는 store를 받지도 sync하지도 않으며, system prompt는 여전히 store를 설명한다.
- Memory 지원이 켜진 상태에서 store가 첨부된 세션의 work item이 `secret` 없이 도착하면 memory 없이 실행하지 않고 **실패**한다.

`memory_sync_deletions` (로컬 삭제의 store 반영 여부; 업로드/다운로드에는 영향 없음):

| 값 | 동작 |
| --- | --- |
| `"enabled"` (기본) | 이후 sync에서 파일이 여전히 없음을 확인하면 store에서 삭제 |
| `"log_only"` | 같은 검사를 하되 삭제 예정 항목만 로그. enabled를 신뢰하기 전 관찰용 |
| `"disabled"` | store에서 절대 삭제하지 않음 |

### 8.4 같은 store를 공유하는 세션의 격리

두 세션은 같은 경로를 필요로 하므로 한 호스트에서 동시에 같은 store를 마운트할 수 없다. 같은 store를 붙이는 세션들은 **세션당 파일시스템 하나**로 실행해야 하며, sandbox-per-session 패턴이 이를 충족한다.

### 8.5 읽기 전용 store와 충돌

- `access: "read_only"` store: `write`/`edit` 도구가 해당 디렉터리 변경을 거부하고, worker는 그곳에서 아무것도 업로드하지 않는다.
- 하지만 `bash`, custom tool, sandbox에서 서빙하는 MCP 서버를 통한 변경은 **로컬에서 막히지 않는다.** 이런 변경은 sync되지 않고, 해당 memory의 다음 원격 변경 시 덮어써진다. 로컬 사본 자체를 불변으로 유지하려면 그 agent의 `bash`를 비활성화하고 파일시스템에 쓰는 custom tool을 주지 않는다. Store 경로를 read-only로 마운트하지는 말 것(worker가 디렉터리를 만들고 써야 함).
- **충돌은 store 쪽이 이긴다.** 마지막 sync 이후 store에서도 바뀐 파일을 에이전트가 수정하면, 다음 sync에서 worker가 store 버전으로 로컬 파일을 덮어쓰고 경고를 로그한다. `write`/`edit` 자체는 성공하며 에이전트에게 에러는 전달되지 않는다.

---

## 9. 운영: 모니터링, 정지, 트러블슈팅

모니터링 호출은 운영 도구에서 **조직 API key** 로 수행한다. 이 endpoint들은 API key와 environment key를 모두 받지만, worker 호스트에 `ANTHROPIC_API_KEY`를 두면 조직 범위 자격증명이 agent tool call에 노출되므로 피해야 한다. Claim/keep-alive 루프는 worker 헬퍼가 처리하므로 직접 호출할 필요가 없다.

### 9.1 큐 깊이 조회

`GET /v1/environments/{environment_id}/work/stats` (CLI: `ant beta:environments:work stats`)

| 필드 | 의미 | 용도 |
| --- | --- | --- |
| `depth` | claim 대기 중인 item 수 | worker fleet 스케일링, 백로그 알림 |
| `pending` | claim됐지만 ack되지 않은 item. 헬퍼는 처리 전 ack하므로 평소 0 근처 | claim과 ack 사이에서 멈춘 worker 탐지(지속적 non-zero 알림) |
| `oldest_queued_at` | 큐에 남은 가장 오래된 item(대기 또는 미ack)의 타임스탬프, 없으면 `null` | 최장 대기 시간 확인 |
| `workers_polling` | 최근 30초 내 poll한 worker 수 | liveness 알림 |

```json
{ "type": "work_queue_stats", "depth": 0, "pending": 0, "oldest_queued_at": null, "workers_polling": 0 }
```

### 9.2 세션 / Worker 정지

**세션 정지:** `POST /v1/environments/{environment_id}/work/{work_id}/stop` (CLI: `ant beta:environments:work stop --environment-id ... --work-id ...`)

- 기본: work item이 `stopping`으로 전환 → worker가 다음 **lease heartbeat**에서 감지 → 진행 중 tool call 취소 후 종료 확인 → `stopped`.
- `force: true` (CLI: `--force`): worker 확인 없이 즉시 `stopped`.
- 운영 도구에서는 `ANTHROPIC_WORK_ID`가 자동 설정되지 않으므로 Environments Work endpoint로 work item 목록을 조회해 ID를 찾는다.

**Worker 정상 종료:** 실행 중 cancel된 worker는 진행 중 작업을 멈추고 종료한다. Memory store가 있으면 최종 sync는 건너뛰지만 변경 파일 업로드와 디렉터리 제거는 수행한다. Kill된 프로세스는 teardown을 실행하지 않는다.

| Worker | 해야 할 일 |
| --- | --- |
| `ant` CLI | 없음. SIGTERM/SIGINT를 직접 처리(진행 중 tool call 취소, 에러 결과 post, work item 해제) |
| 독립 프로세스 SDK worker | `EnvironmentWorker`는 signal handler를 설치하지 않음 → signal handler에서 cancel |
| Webhook 서버 내 SDK worker | 서버의 shutdown hook에서 cancel. Worker가 서버의 signal을 가로채면 안 됨 |

- SIGTERM으로 멈추고 **hard kill 전 최소 30초**를 허용할 것(최종 업로드가 그만큼 걸릴 수 있음). Docker는 기본적으로 stop 신호 10초 후 SIGKILL을 보내므로 `docker run --stop-timeout` 또는 오케스트레이터의 termination grace period를 늘린다.
- 장기 호스트에서 kill이 발생했다면 다음 세션 전에 `/mnt/memory/` 아래 잔여 store 디렉터리를 제거한다(일회용 sandbox는 정리 불필요).

### 9.3 트러블슈팅

| 증상 | 원인 / 조치 |
| --- | --- |
| `workers_polling`이 0에 머묾 | worker가 큐에 도달하지 못함. worker 호스트에 `ANTHROPIC_ENVIRONMENT_KEY`, `ANTHROPIC_ENVIRONMENT_ID` 설정 확인 |
| 세션이 계속 queued | claim하는 worker 없음(실패하지 않고 대기). `workers_polling`, `depth` 확인 |
| 로그에 `the work item carried no sessions token` (Go: `ErrSessionMemoryNoToken`), work item 실패 | secret이 worker에 전달되지 않음, 또는 조직에 self-hosted memory store가 활성화되지 않음 → secret 전달. in-process worker인데도 발생하면 support 문의 |
| 로그에 `something already exists at the memory store's path` | 이전 세션(대개 kill된 worker)의 잔여 디렉터리 → 로그가 지목한 디렉터리 삭제(미동기화 편집 유실) |
| 로그에 `cannot create the memory store's folder` / `the worker host must make this mount path writable` | worker 사용자에게 `/mnt/memory` 쓰기 권한 없음 → 생성 후 `chown` |
| claim 직후 세션이 `idle` + `requires_action`, 에러 이벤트 없음 | memory 마운트 실패로 work item 실패 → 호스트 원인 수정 후 `user.interrupt` 이벤트 전송 → 재큐잉되어 다음 worker가 재시도 |
| Custom tool 호출이 돌아오지 않음 (`requires_action`으로 일시정지) | 해당 도구를 서빙하는 worker/client 없음 |
| 감싼 MCP 도구 호출이 멈춤 | MCP client 타임아웃 미설정 시 backstop까지 대기: Python은 worker 자체 tool call 한도(약 2분 30초), TypeScript는 MCP SDK 기본 요청 타임아웃(약 1분), Go는 worker 기본 한도(120초) |

참고: worker는 마운트 및 백그라운드 sync 실패를 세션에 보고하지 않고 **로그로만** 남긴다. 에이전트에게 도달하는 것은 read-only 거부(tool 에러)뿐이다.

---

## 10. 보안 모델 (Shared Responsibility)

Anthropic은 모든 environment에 대해 control plane을 보호한다: 세션·work queue 무결성, multitenant 격리, agent-context 최소화. Self-host 시 다음은 **고객 책임**이다.

| 영역 | 고객 책임 내용 |
| --- | --- |
| Sandbox 이미지 품질·런타임 하드닝 | Anthropic은 이미지를 검사·검증하지 않음. 불필요한 Linux capability 제거, non-root 실행, read-only root FS 권장 |
| 네트워크 egress | VPC/방화벽 규칙이 결정. 제한 없으면 침해된 tool 실행이 임의 외부 호스트에 도달 가능 |
| Service key 보관·교체 | `ANTHROPIC_ENVIRONMENT_KEY`는 큐 polling과 세션 결과 제출을 인가. secrets manager에 보관(환경 파일·이미지 금지), 노출 의심 시 즉시 교체 |
| 비신뢰 워크로드 격리 | key는 한 environment 큐로 scope됨. 비신뢰 코드 실행 시 신뢰 경계마다 별도 workspace·environment 프로비저닝 고려 |
| 세션별 자격증명 | work item의 `secret`은 해당 세션에서 environment key 대신 사용. **memory store endpoint는 environment key를 거부하고 `secret`을 요구.** 해당 sandbox에만 전달, 이미지·공유 볼륨 금지, 로그 금지 |
| Tool 실행 blast radius | 도구는 프로세스 권한으로 실행. 최소 권한 사용자, 필요한 디렉터리만 마운트 |
| 로그 보존·세션 콘텐츠 | 대화 내용과 tool 출력이 worker를 거쳐 고객 환경에 머묾. 보존·redaction·삭제는 고객 정책 |
| Memory store 내용 | store(버전 이력 포함)는 Anthropic이 호스팅. `/mnt/memory/` 작업 사본은 세션 종료 시 삭제되나, teardown 없이 종료된 worker는 사본을 남김. 잔여 사본 정리, 경로 권한, 같은 FS를 공유하는 세션 간 격리는 고객 책임 |
| 읽기 전용 store | 업로드로부터 보호될 뿐 로컬 수정으로부터는 아님. `bash`, custom tool, MCP 서버가 로컬 사본을 바꿀 수 있음(§8.5) |

**Anthropic이 해줄 수 없는 것**

- **Key 유출 인지:** 이상 사용 패턴은 탐지할 수 있지만 유출 자체는 알 수 없다. 의심되면 즉시 revoke 후 재발급. Revocation은 매 요청마다 검증되므로 worker의 다음 호출부터 적용된다.
- **Worker 빌드 검증:** 이미지의 공급망 침해는 control plane에서 탐지 불가.
- **Sandbox 내부 tool 간 격리:** Anthropic의 보안 경계는 sandbox에서 끝난다.
- **고객 환경 내 데이터 보존 강제:** 세션 콘텐츠가 worker에 도달하면 Anthropic의 데이터 수명주기 통제 밖이다.

**자격증명 정리**

| 자격증명 | 위치 | 용도 |
| --- | --- | --- |
| Claude API key (`ANTHROPIC_API_KEY`) | 운영자 머신 (worker 호스트 금지) | 세션 생성, agent 선언, 큐 통계·stop |
| Environment key (`ANTHROPIC_ENVIRONMENT_KEY`, `sk-ant-oat01-...`) | worker 호스트 (secrets manager) | 큐 poll/claim, tool·custom tool 결과 post. Console에서만 발급 |
| Work item `secret` (`ANTHROPIC_WORK_SECRET`) | 해당 세션 sandbox만 | memory store 접근 (environment key는 거부됨) |
| Webhook signing key (`ANTHROPIC_WEBHOOK_SIGNING_KEY`, `whsec_...`) | webhook 핸들러 호스트 | payload 서명 검증 |

---

## 11. 요약

- Environment는 sandbox 구성의 재사용 단위이며 세션마다 독립된 sandbox가 생성된다. 버전 관리는 없다.
- Cloud: Ubuntu 24.04 / x86_64 / 메모리 최대 8 GB / 디스크 최대 10 GB, 다수 언어·DB·문서·브라우저 도구 사전 설치. **API에서 `networking` 생략 시 `unrestricted`** 이므로 `limited` + `allowed_hosts` 명시가 권장된다.
- Self-hosted: Anthropic은 work queue와 모델 루프를 운영하고, 고객 worker가 outbound HTTPS로 work를 claim해 tool을 로컬 실행한다. Tool I/O는 여전히 control plane을 거친다. `memory_store` 외 resources는 불가.
- 배포: always-on vs webhook, in-process vs sandbox-per-session. Custom tool과 memory sync 튜닝은 SDK worker(Python/TS/Go)에서만 가능하다.
- 운영: `work/stats`의 `depth`/`pending`/`workers_polling`, graceful stop(최소 30초 유예), work item `secret` 전달이 핵심 함정이다.

---

## 출처

- Cloud environment setup — https://platform.claude.com/docs/en/managed-agents/environments
- Cloud sandbox reference — https://platform.claude.com/docs/en/managed-agents/cloud-sandboxes-reference
- Self-hosted sandboxes — https://platform.claude.com/docs/en/managed-agents/self-hosted-sandboxes
- Deploy self-hosted workers — https://platform.claude.com/docs/en/managed-agents/self-hosted-sandboxes-workers
- Self-hosted worker reference — https://platform.claude.com/docs/en/managed-agents/self-hosted-sandboxes-reference
- Custom tools in self-hosted sandboxes — https://platform.claude.com/docs/en/managed-agents/self-hosted-sandboxes-custom-tools
- Memory stores in self-hosted sandboxes — https://platform.claude.com/docs/en/managed-agents/self-hosted-sandboxes-memory
- Monitor and troubleshoot self-hosted workers — https://platform.claude.com/docs/en/managed-agents/self-hosted-sandboxes-operations
- Security model — https://platform.claude.com/docs/en/managed-agents/self-hosted-sandboxes-security
