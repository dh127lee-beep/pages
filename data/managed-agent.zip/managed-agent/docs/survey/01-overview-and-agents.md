# 01. 개요와 Agent 정의 — Claude Managed Agents

> 작성 기준일: 2026-10-14
> 상태: **beta** (공개 베타 2026-04-08 시작), 모든 엔드포인트에 `anthropic-beta: managed-agents-2026-04-01` 헤더 필요
> 근거 문서: overview, quickstart, agent-setup, onboarding, migration, reference (하단 "출처" 참고)
> 표기 규칙: API 이름·필드·엔드포인트·코드는 원문(영어) 그대로 둔다. 문서에 근거가 없거나 모호한 내용은 **[불명확]**으로 표시한다.

---

## 1. Claude Managed Agents란?

Claude Managed Agents는 Anthropic이 운영하는 인프라에서 돌아가는 **"사전 구축되고 설정 가능한 agent harness"**다. 직접 agent loop, 도구 실행, 런타임을 만들 필요 없이, Claude가 파일을 읽고, 명령을 실행하고, 웹을 탐색하고, 코드를 안전하게 실행할 수 있는 완전 관리형 환경을 제공한다. Harness에는 prompt caching, compaction 등 성능 최적화가 내장되어 있다.

- Claude Platform on AWS에서도 제공되지만, 기능 가용성과 session 동작에 일부 차이가 있다(세부 내용은 AWS 가이드 참조, 이 장의 범위 밖).

### 1.1 Messages API vs Managed Agents vs Agent SDK

공식 overview는 Messages API와 Managed Agents 두 가지만 대비하며, Agent SDK와의 비교는 migration 문서에 나온다. 세 가지를 한 표로 정리하면 다음과 같다.

| 구분 | Messages API | Claude Agent SDK | Claude Managed Agents |
| --- | --- | --- | --- |
| 정체 | 모델에 직접 프롬프트하는 접근 | agent·tools·sessions 개념을 제공하는 SDK | 관리형 인프라에서 돌아가는 사전 구축 agent harness |
| 실행 위치 | 호출자 코드 (loop는 직접 작성) | **사용자가 운영하는 프로세스** | **Anthropic 인프라** |
| 적합한 용도 | 커스텀 agent loop, 세밀한 제어 | (문서에 별도 명시 없음) | 장시간 실행 작업, 비동기 작업 |
| 대화 이력 | 호출자가 배열로 유지, 매 턴 재전송 | SDK가 관리 | session이 서버 측에 저장 |
| 도구 실행 | `tool_use` 블록을 받아 직접 실행 후 `tool_result` 전송 | 내장 도구가 로컬 파일시스템에서 실행 | 내장 도구가 session sandbox(`/workspace`) 안에서 자동 실행 |
| 종료 판단 | 호출자가 결정 (`stop_reason == "end_turn"` 등) | SDK | session이 `session.status_idle` 이벤트 발행 |

### 1.2 언제 쓰는가 (문서가 제시하는 워크로드)

| 요구사항 | 설명 |
| --- | --- |
| Long-running execution | 여러 tool call을 포함해 수 분~수 시간 실행되는 작업 |
| Cloud infrastructure | 패키지가 미리 설치되고 네트워크 접근이 가능한 보안 sandbox |
| Self-hosted execution | compliance·data residency 요구로 자체 인프라에서 sandbox 실행 |
| Minimal infrastructure | agent loop, sandbox, 도구 실행 계층을 직접 만들 필요 없음 |
| Stateful sessions | 여러 상호작용에 걸쳐 파일시스템·대화 이력 유지 |
| Scheduled execution | scheduled deployments를 통한 cron 기반 반복 실행 |

### 1.3 기본 제공 도구 (overview 기준 요약)

- **Bash**: sandbox에서 shell 명령 실행
- **File operations**: read, write, edit, glob, grep
- **Web search / fetch**: 웹 검색 및 URL 내용 조회. 도메인 allowlist/blocklist로 제한 가능
- **MCP servers**: 외부 도구 제공자 연결

`{"type": "agent_toolset_20260401"}` 하나로 사전 구축 도구 전체(bash, 파일 작업, 웹 검색 등)가 활성화된다. 전체 목록과 도구별 설정은 Tools 문서(다른 장)에서 다룬다.

---

## 2. 네 가지 핵심 개념

| 개념 | 정의 (문서 원문 요지) | ID 접두사 예시 |
| --- | --- | --- |
| **Agent** | model, system prompt, tools, MCP servers, skills의 묶음. 한 번 만들고 ID로 재사용, 버전 관리됨 | `agent_...` |
| **Environment** | session이 실행될 위치의 설정: Anthropic 관리 cloud sandbox 또는 자체 인프라의 self-hosted sandbox | `env_...` |
| **Session** | environment 안에서 특정 작업을 수행하고 산출물을 만드는 실행 중인 agent 인스턴스 | (예시 ID 형식은 이 문서들에 없음) |
| **Events** | 애플리케이션과 agent 사이에 오가는 메시지 (user turn, tool result, status update) | — |

관계 요약: **Agent(무엇을/어떻게) + Environment(어디서) → Session(실행) ↔ Events(대화)**.

---

## 3. End-to-end 흐름

### 3.1 동작 단계 (overview "How it works")

1. **Agent 생성** — model, system prompt, tools, MCP servers, skills 정의. 한 번 만들고 여러 session에서 ID로 참조.
2. **Environment 생성** — cloud sandbox 또는 self-hosted sandbox 설정.
3. **Session 시작** — agent와 environment를 참조하는 session 생성.
4. **Events 전송 및 스트리밍** — user message를 event로 보내면 Claude가 자율적으로 도구를 실행하고 결과를 SSE(server-sent events)로 스트리밍. 이벤트 이력은 서버에 저장되며 전체 조회 가능.
5. **Steer / interrupt** — 실행 중 추가 user event로 방향을 조정하거나 interrupt로 중단.

user event를 보냈을 때 내부에서 일어나는 일 (quickstart "What's happening"):

1. **Sandbox 프로비저닝** — environment 설정에 따라 구성
2. **Agent loop 실행** — Claude가 메시지에 따라 사용할 도구 결정
3. **도구 실행** — 파일 쓰기, bash 등은 sandbox 안에서 실행
4. **이벤트 스트리밍** — 실시간 업데이트 전송
5. **Idle 전환** — 더 할 일이 없으면 `session.status_idle` 발행

### 3.2 사전 준비

- Claude Console 계정, API key (`ANTHROPIC_API_KEY` 환경 변수)
- Managed Agents 접근 권한: **모든 API 계정에 기본 활성화**
- SDK 사용 시 beta 헤더는 **SDK가 자동으로 설정**

설치:

| 대상 | 명령 |
| --- | --- |
| `ant` CLI (macOS) | `brew install anthropics/tap/ant` |
| `ant` CLI (Linux/WSL) | GitHub release 바이너리 다운로드 (문서 예시 `VERSION=1.40.0`) |
| `ant` CLI (Go, 1.25+) | `go install github.com/anthropics/anthropic-cli/cmd/ant@latest` |
| Python SDK | `pip install anthropic` |
| TypeScript SDK | `npm install @anthropic-ai/sdk` |
| Java | `com.anthropic:anthropic-java:2.71.0` (문서 예시 버전) |
| Go / C# / Ruby / PHP | `go get github.com/anthropics/anthropic-sdk-go` / `dotnet add package Anthropic` / `bundle add anthropic` / `composer require "anthropic-ai/sdk" "guzzlehttp/guzzle:^7"` |

> 참고: quickstart는 Claude Code 최신 버전에서 `/claude-api managed-agents-onboard`를 실행하면 대화형 가이드를 받을 수 있다고 안내한다.

### 3.3 Quickstart — Python (압축본)

```python
from anthropic import Anthropic

client = Anthropic()  # ANTHROPIC_API_KEY 사용, beta 헤더 자동 설정

# 1) Agent
agent = client.beta.agents.create(
    name="Coding Assistant",
    model="claude-opus-5-5",
    system="You are a helpful coding assistant. Write clean, well-documented code.",
    tools=[{"type": "agent_toolset_20260401"}],
)

# 2) Environment: cloud sandbox, limited networking + package managers 허용
environment = client.beta.environments.create(
    name="quickstart-env",
    config={
        "type": "cloud",
        "networking": {"type": "limited", "allow_package_managers": True},
    },
)

# 3) Session
session = client.beta.sessions.create(
    agent=agent.id,
    environment_id=environment.id,
    title="Quickstart session",
)

# 4) 스트림을 먼저 연 뒤 user.message 전송, 이벤트 처리
with client.beta.sessions.events.stream(session.id) as stream:
    client.beta.sessions.events.send(
        session.id,
        events=[
            {
                "type": "user.message",
                "content": [
                    {
                        "type": "text",
                        "text": "Create a Python script that generates the first 20 "
                        "Fibonacci numbers and saves them to fibonacci.txt",
                    }
                ],
            }
        ],
    )
    for event in stream:
        match event.type:
            case "agent.message":
                for block in event.content:
                    if block.type == "text":
                        print(block.text, end="")
            case "agent.tool_use":
                print(f"\n[Using tool: {event.name}]")
            case "session.status_idle":
                print("\n\nAgent finished.")
                break
```

포인트:
- **스트림을 먼저 열고(send 이전) 메시지를 보낸다** — 모든 SDK 예제가 이 순서를 따른다.
- quickstart environment는 `limited` networking에 `allowed_hosts`가 비어 있다. 문서에 따르면 web search/fetch는 sandbox 밖에서 실행되지만 `limited` networking에서는 `allowed_hosts`가 이들에도 적용되므로, **이 environment에서는 web search/fetch가 결과를 반환하지 않는다.** 실제 agent에는 필요한 host를 `allowed_hosts`에 넣어야 한다.
- 예상 출력: `write` → `bash` → `bash` 도구 사용 후 "fibonacci.txt contains the first 20 Fibonacci numbers (0 through 4181)."
- session 생성 시 `agent`는 ID 문자열 외에 `{"type": "agent", "id": ..., "version": ...}` 객체로 **특정 버전에 pin**할 수도 있다(migration 예제).

### 3.4 Quickstart — curl

```bash
set -euo pipefail
H=(-H "x-api-key: $ANTHROPIC_API_KEY"
   -H "anthropic-version: 2023-06-01"
   -H "anthropic-beta: managed-agents-2026-04-01"
   -H "content-type: application/json")

# Agent
AGENT_ID=$(curl -sS --fail-with-body https://api.anthropic.com/v1/agents "${H[@]}" -d '{
  "name": "Coding Assistant",
  "model": "claude-opus-5-5",
  "system": "You are a helpful coding assistant. Write clean, well-documented code.",
  "tools": [{"type": "agent_toolset_20260401"}]
}' | jq -er '.id')

# Environment
ENVIRONMENT_ID=$(curl -sS --fail-with-body https://api.anthropic.com/v1/environments "${H[@]}" -d '{
  "name": "quickstart-env",
  "config": {"type": "cloud", "networking": {"type": "limited", "allow_package_managers": true}}
}' | jq -er '.id')

# Session
SESSION_ID=$(curl -sS --fail-with-body https://api.anthropic.com/v1/sessions "${H[@]}" \
  -d "{\"agent\": \"$AGENT_ID\", \"environment_id\": \"$ENVIRONMENT_ID\", \"title\": \"Quickstart session\"}" \
  | jq -er '.id')
```

(위 `H` 배열 정리는 가독성을 위한 편집이며, 원문은 헤더를 각 요청에 직접 나열한다.)

메시지 전송·스트리밍 단계는 quickstart에서 **"한 번의 shell 명령으로는 잘 옮겨지지 않으므로 SDK 예제를 사용하라"**고 되어 있다. 다만 migration 문서에는 curl 버전이 있다:

- 스트림: `GET /v1/sessions/{session_id}/events/stream` (SSE, `curl -N`으로 백그라운드 실행)
- 전송: `POST /v1/sessions/{session_id}/events` — body `{"events": [{"type": "user.message", "content": [{"type": "text", "text": "..."}]}]}`
- 종료 감지: 스트림 로그에서 `"session.status_idle"`을 grep
- migration의 curl 예제는 URL에 `?beta=true` 쿼리를 붙이고 있다(quickstart 예제에는 없음). 그 의미는 이 문서들에 설명되어 있지 않다 **[불명확]**.

### 3.5 `ant` CLI 방식 (선언적)

`ant apply`는 Markdown(frontmatter + 본문=system prompt)이나 YAML 파일로 리소스를 만들고, ID를 `claude-lock.json`에 기록한다.

```markdown
---
name: Coding Assistant
model: claude-opus-5-5
tools:
  - type: agent_toolset_20260401
---

You are a helpful coding assistant. Write clean, well-documented code.
```

```yaml
# yaml-language-server: $schema=https://platform.claude.com/schemas/ant/beta/environment.json
name: quickstart-env
config:
  type: cloud
  networking:
    type: limited
    allow_package_managers: true
```

```bash
ant apply coding-assistant.md environment.yaml   # 두 리소스를 한 번에
SESSION_ID=$(ant beta:sessions create --agent "$AGENT_ID" \
  --environment-id "$ENVIRONMENT_ID" --title "Quickstart session" \
  --transform id --raw-output)
```

- `claude-lock.json`을 커밋해야 다음 `ant apply`가 **새 agent를 만들지 않고 기존 agent를 업데이트**한다.
- 업데이트 시 `ant apply`가 `version`을 자동으로 채운다.

### 3.6 완성형 앱 예제 (claude-quickstarts 저장소)

| 예제 | 내용 |
| --- | --- |
| Chat SDK (Vercel) | 브라우저 채팅의 research analyst. 대화 1개 = 영속 session 1개. adapter 교체로 Slack/Teams/Discord/WhatsApp 이전 가능 |
| assistant-ui | spreadsheet analyst. session = thread 목록, bash 명령마다 Allow/Deny 게이트 |
| CopilotKit (AG-UI) | 개인 재무 assistant. 채팅 thread ↔ managed session 매핑, 토큰 단위 스트리밍, custom tool로 차트 렌더링 |
| Knowledge wiki | 문서 코퍼스를 한 번 wiki로 정제한 뒤 반복 질문을 "훨씬 적은 비용"으로 응답 |

---

## 4. Agent 정의 (agent-setup)

Agent는 **재사용 가능하고 버전이 매겨지는 설정**으로, persona와 capability를 정의한다. 한 번 만들고 session을 시작할 때마다 ID로 참조한다.

### 4.1 필드

| 필드 | 필수 | 설명 |
| --- | --- | --- |
| `name` | 필수 | 사람이 읽는 이름. clear 불가 |
| `model` | 필수 | 모델 ID 문자열 또는 객체(`{"id": "claude-opus-5-5"}`). **Claude 4.5 이상 모델 지원**. 객체 형식은 `speed`, `effort`, `inference_geo`도 받음. clear 불가 |
| `system` | 선택 | system prompt (persona·행동). 해야 할 작업은 user message에 쓰라고 구분함. Ruby SDK에서는 `system_` |
| `tools` | 선택 | pre-built agent tools + MCP tools + custom tools 조합 |
| `mcp_servers` | 선택 | 표준화된 3rd-party 기능을 제공하는 MCP 서버 |
| `skills` | 선택 | progressive disclosure로 도메인 컨텍스트를 제공하는 skills |
| `multiagent` | 선택 | 다른 agent에 작업 위임(subagents, dynamic workflows), advisor 모델 자문. `multiagent_20261001` 타입이면 dynamic workflows가 기본 on |
| `description` | 선택 | agent가 하는 일 설명 |
| `metadata` | 선택 | 추적용 임의 key-value |

**`model` 객체의 하위 필드**

| 하위 필드 | 값 | 비고 |
| --- | --- | --- |
| `id` | 모델 ID | 예: `claude-opus-5-5` |
| `speed` | `"standard"`(응답 기본값), `"fast"` | fast mode는 Claude Opus 5.5, Opus 5, Opus 4.8 지원 (문서 Tip 기준) |
| `effort` | `low`, `medium`, `high`, `xhigh`, `max` 문자열 또는 `{"type": "high"}` 객체 | 생략 시 기본값으로 채워짐(예시 응답에서 `{"type": "medium"}`) |
| `inference_geo` | `"us"` 또는 `"global"` | 미설정 시 각 요청이 서빙 시점의 workspace 기본 geo를 따름 |

**Session 단위 override**: `model`, `system`, `tools`, `mcp_servers`, `skills`는 agent를 바꾸지 않고 session 하나에서만 override 가능하다. 단, `model` override는 agent의 `model` 객체를 **통째로 교체**하므로 agent의 `effort`가 이어지지 않는다. 특정 effort로 돌리려면 override의 `model` 객체 안에 `effort`를 직접 지정해야 한다.

### 4.2 생성 응답

요청한 설정을 그대로 돌려주고 `id`, `type`, `version`, `created_at`, `updated_at`, `archived_at`을 추가하며, 생략한 `model` 필드(예: `effort`)를 기본값으로 채운다. `version`은 1부터 시작.

```json
{
  "id": "agent_01HqR2k7vXbZ9mNpL3wYcT8f",
  "type": "agent",
  "name": "Coding Assistant",
  "model": {"id": "claude-opus-5-5", "effort": {"type": "medium"}, "speed": "standard"},
  "system": "You are a helpful coding agent.",
  "description": null,
  "tools": [{
    "type": "agent_toolset_20260401",
    "default_config": {"permission_policy": {"type": "always_allow"}}
  }],
  "skills": [], "mcp_servers": [], "multiagent": null, "metadata": {},
  "version": 1,
  "created_at": "2026-04-03T18:24:10.412Z",
  "updated_at": "2026-04-03T18:24:10.412Z",
  "archived_at": null
}
```

> 주의: toolset의 기본 permission policy는 **`always_allow`**다. 별도 설정하지 않으면 모든 내장 도구 호출이 승인 없이 실행된다.

### 4.3 Inference geo 고정

- `model` 객체에 `inference_geo`를 설정(`"us"`/`"global"`).
- 검증 시점: **agent 저장 시, session 생성 시, session이 서빙하는 매 턴마다** workspace의 `allowed_inference_geos`와 대조.
- workspace allowlist가 좁아져 pin이 더 이상 허용되지 않으면: 새 session 생성 불가, 실행 중 session도 이후 턴 거부. pin에 대한 예외는 없음(compliance 목적).
- geo pinning을 지원하지 않는 모델에 설정하면 **400 에러**.
- `multiagent` 구성에서는 agent 자신과 `subagents`/`workflows`의 `predefined_agents`에 있는 모든 agent의 pin이 **모두 같은 값이거나 모두 미설정**이어야 함.
- `model`을 보내면서 `inference_geo`를 빼면 pin이 **해제**됨.

### 4.4 업데이트와 버전 관리

엔드포인트: `POST /v1/agents/{agent_id}` (curl 예제가 `-d`로 POST). 설정이 바뀌면 새 버전 생성.

| 규칙 | 내용 |
| --- | --- |
| `version` (선택, ≥1) | 지정 시 optimistic concurrency: 현재 버전과 다르면 **409** (보낸 필드가 이미 저장값과 같아도). 생략 시 무조건 적용(last write wins, 양쪽 모두 에러 없음). 대화형 호출자는 지정 권장, CI 동기화 같은 선언적 apply loop는 생략이 적합 |
| 생략된 필드 | 보존 |
| Scalar (`model`, `system`, `name`, `description`) | 새 값으로 교체. `system`, `description`은 `null`로 clear 가능 |
| `model` 내 `effort` 예외 | model `id`가 같으면 `effort` 생략 시 저장값 유지. `id`가 바뀌면 새 모델의 기본값으로 리셋 |
| Array (`tools`, `mcp_servers`, `skills`) | 새 배열로 **전체 교체**. `null` 또는 빈 배열로 clear |
| `multiagent` | `multiagent_20261001` 타입 유지 시 레벨별 merge(생략=유지, `predefined_agents`는 교체). 그 외는 블록 전체 교체. `"multiagent": null`로 전체 제거. 블록 내부 `null`은 기본값으로 리셋 → `workflows: null`이면 dynamic workflows **on** |
| `metadata` | key 단위 merge. 특정 key 삭제는 값을 `null`로 |
| No-op | 변경이 없으면 새 버전을 만들지 않고 기존 버전 반환 |
| 다른 agent의 `predefined_agents` | 자동 갱신 안 됨. 이 agent를 참조하는 agent는 pin된 버전을 계속 사용 → 새 버전으로 위임하려면 참조하는 쪽을 업데이트 |
| Archived agent | 업데이트 거부 |

```python
# 낙관적 동시성 업데이트
updated = client.beta.agents.update(
    agent.id, version=agent.version, system="You are a helpful coding agent. Always write tests."
)
# 무조건 업데이트
client.beta.agents.update(agent.id, description="Writes and reviews code.")
# clear 예: description 제거, metadata.team 삭제, dynamic workflows on
client.beta.agents.update(
    agent.id,
    description=None,
    metadata={"team": None},
    multiagent={"type": "multiagent_20261001", "workflows": None},
)
```

### 4.5 Lifecycle

| 작업 | 엔드포인트 / CLI | 동작 |
| --- | --- | --- |
| Create | `POST /v1/agents` / `ant apply` | version 1 생성 |
| Update | `POST /v1/agents/{id}` / `ant apply`, `ant beta:agents update` | 변경 시 새 버전 |
| List versions | `GET /v1/agents/{id}/versions` / `ant beta:agents:versions list --agent-id` | 전체 버전 이력, 페이지네이션(SDK는 자동 순회) |
| Archive | `POST /v1/agents/{id}/archive` / `ant beta:agents archive --agent-id` | **되돌릴 수 없음**. read-only가 되며 새 session은 참조 불가, 기존 session은 계속 실행. `archived_at` 설정 |

삭제(delete) 엔드포인트는 이 문서들에 나오지 않는다 **[불명확: agent 삭제 가능 여부]**.

---

## 5. Console에서 만들기 (onboarding)

Console(`platform.claude.com/workspaces/default/agent-quickstart/`)은 agent를 시각적으로 생성·설정하는 UI다.

| 단계 | 내용 |
| --- | --- |
| Model & system prompt | 모델 선택, 전체 폭 에디터에서 system prompt 작성 |
| MCP servers | URL로 원격 MCP 서버 추가, 인증 |
| Tools | pre-built agent toolset과 MCP tools로 확장 |
| Skills | Anthropic 또는 조직 라이브러리의 custom skills 첨부 |
| API 요청 미리보기 | 설정에 대응하는 API 요청을 보여 주어 코드로 복사 가능 |
| 테스트 | 인라인 session runner로 테스트 session 시작, 메시지 전송, 이벤트 스트림 관찰 |

코드로 옮기기: Console에서 **agent ID와 environment ID**를 복사해 session 생성에 사용한다.

```python
session = client.beta.sessions.create(
    agent="agent_01J8XkN5uT3vHpLqRfWdY2",
    environment_id="env_01K2mPsT7hNwR4jXuLvCqD8",
    title="My first session",
)
```

---

## 6. 마이그레이션 가이드

대상은 두 가지다: **(A) Messages API 기반 직접 작성 agent loop**, **(B) Claude Agent SDK**. 그리고 (C) 모델 버전 간 이동.

### 6.1 (A) Messages API loop → Managed Agents

| Before | After |
| --- | --- |
| 대화 이력 배열을 유지하며 매 턴 재전송 | session이 서버에 이력 저장. event 송수신만 |
| `tool_use` 블록 순회, 실행, `tool_result`로 루프 | 내장 도구는 sandbox에서 자동 실행. custom tool만 `agent.custom_tool_use` 이벤트로 처리 |
| agent 생성 코드 실행용 sandbox 직접 구축 | session sandbox가 코드 실행·파일·bash 담당 |
| 루프 종료 시점을 직접 판단 | `session.status_idle` 발행 |

여전히 직접 제어하는 것:
- **System prompt, model** — 같은 필드, 이제 agent 정의에 위치
- **Custom tools** — 여전히 JSON Schema로 선언. 실행은 `agent.custom_tool_use` 이벤트에 응답하는 방식
- **Web search/fetch 설정** — `allowed_domains`, `blocked_domains`, `max_content_tokens`, `user_location`은 agent toolset `configs` 배열의 `web_search`/`web_fetch` 항목에 **한 번** 설정. `max_uses`, `citations`, `cache_control`은 **사용 불가**
- **Context 주입** — system prompt, file resources, skills

### 6.2 (B) Claude Agent SDK → Managed Agents

핵심 차이: SDK는 **사용자 프로세스**에서, Managed Agents는 **Anthropic 인프라**에서 실행된다. 마이그레이션의 대부분은 SDK 설정 객체를 API 측 등가물로 매핑하는 일이다.

| Agent SDK | Managed Agents |
| --- | --- |
| 실행마다 `ClaudeAgentOptions(...)` 구성 | `client.beta.agents.create(...)` 한 번. 서버에 영속·버전 관리 |
| `ClaudeSDKClient(...)` / `query(...)` | `client.beta.sessions.create(...)` 후 events 송수신 |
| `@tool` 함수, SDK가 자동 dispatch | agent에 `{"type": "custom", ...}` 선언, 클라이언트가 `agent.custom_tool_use` 처리 후 `user.custom_tool_result` 응답 |
| 내장 도구가 로컬 파일시스템에서 실행 | `agent_toolset_20260401`이 session sandbox의 `/workspace`에서 실행 |
| `cwd`, `add_dirs` (로컬 경로) | files를 session resource로 업로드/마운트 |
| `system_prompt` + `CLAUDE.md` 계층 | agent의 단일 `system` 문자열. session을 특정 버전에 pin해 배포 없이 promote/rollback |
| `mcp_servers` (설정+인증 한 곳) | agent에 서버 선언, 자격 증명은 session의 **Vault**로 제공 |
| `permission_mode`, `can_use_tool` | 도구별 `permission_policy` (`always_allow`, `always_ask`, `auto`); 승인 대기 호출에는 `user.tool_confirmation` 이벤트 전송 |

Custom tool 처리 루프 (Python, 요지):

```python
agent = client.beta.agents.create(
    name="weather-agent",
    model="claude-opus-5-5",
    system="You are a concise weather assistant.",
    tools=[
        {
            "type": "custom",
            "name": "get_weather",
            "description": "Get the current weather for a city.",
            "input_schema": {
                "type": "object",
                "properties": {"city": {"type": "string"}},
                "required": ["city"],
            },
        }
    ],
)
# ... environment, session(agent={"type": "agent", "id": agent.id, "version": agent.version}) 생성 ...
with client.beta.sessions.events.stream(session.id) as stream:
    client.beta.sessions.events.send(
        session.id,
        events=[
            {
                "type": "user.message",
                "content": [{"type": "text", "text": "What's the weather in Tokyo?"}],
            }
        ],
    )
    for event in stream:
        match event.type:
            case "agent.custom_tool_use":
                client.beta.sessions.events.send(
                    session.id,
                    events=[
                        {
                            "type": "user.custom_tool_result",
                            "custom_tool_use_id": event.id,
                            "content": [{"type": "text", "text": get_weather(**event.input)}],
                        }
                    ],
                )
            case "session.status_idle":
                if event.stop_reason and event.stop_reason.type == "end_turn":
                    break
```

`session.status_idle`은 custom tool 응답 대기 중에도 올 수 있으므로, 예제는 `stop_reason.type == "end_turn"`일 때만 루프를 끝낸다(문서에서 그 이유를 명시하진 않으나 코드상 그렇게 처리).

**클라이언트로 넘어오는 기능** (SDK가 자동으로 해 주던 것):

| SDK 기능 | Managed Agents 방식 |
| --- | --- |
| Plan mode | 계획 전용 session을 먼저 돌리고, 두 번째 session에서 실행 |
| Output styles, slash commands | `user.message` 전송 전 또는 `agent.message` 수신 후 클라이언트에서 적용 |
| `PreToolUse` / `PostToolUse` hooks | custom tool은 `agent.custom_tool_use` 처리 지점에 로직 배치. 내장 도구는 `permission_policy: always_ask`로 모든 호출 검토. `auto`는 서버가 평가하며, 안전하다고 판단된 호출은 **클라이언트를 거치지 않고 실행됨** |
| `max_turns` | 클라이언트 측에서 턴 수 카운트 |

### 6.3 마이그레이션 체크리스트

1. 필요한 networking·runtime을 갖춘 **environment 생성**
2. system prompt와 도구 선택을 **agent 정의로 이전**
3. 루프 교체: `client.beta.sessions.create()`(`POST /v1/sessions`)로 session 생성, `client.beta.sessions.events.stream()`(`GET /v1/sessions/{session_id}/events/stream`)으로 이벤트 스트리밍
4. agent가 읽는 로컬 파일은 **Files API로 업로드** 후 `resources`로 마운트
5. custom tool 핸들러를 이벤트 루프의 `agent.custom_tool_use` 응답으로 이동
6. 프로덕션 트래픽 전환 전 **테스트 session으로 검증**

### 6.4 (C) 모델 버전 간 마이그레이션

- 대개 **한 필드 변경**: agent 정의의 `model`을 업데이트하면 **다음에 생성하는 session부터** 적용.
  ```python
  client.beta.agents.update(agent.id, version=agent.version, model="claude-opus-5-5")
  ```
- Messages API migration guide의 대부분 항목은 조치 불필요:
  - `max_tokens` 기본값, `thinking` 설정 등 **요청 파라미터 변경은 런타임이 처리** — 이 필드들은 agent 정의에 노출되지 않음
  - **Assistant message prefilling**은 이벤트 기반 session 모델에 존재하지 않으므로 제거되어도 영향 없음
  - **Tool argument JSON escaping**은 런타임이 파싱하므로 `agent.custom_tool_use`에서 구조화된 데이터를 받음
- 모델의 **행동 변화 설명**은 여전히 유효하지만, **요청 코드 변경 절차**는 해당되지 않음.
- 실행 중인 기존 session이 새 모델로 바뀌는지는 문서에 직접 언급이 없다("next session you create"라고만 함) **[불명확]**.

---

## 7. Reference 표

### 7.1 Event types 요약

영속 이벤트 타입은 `{domain}.{action}` 명명 규칙을 따른다(stream 전용 delta는 예외). Webhook 이벤트 이름은 일부 다르다(예: webhook은 `session.status_idled`, stream은 `session.status_idle`).

**User events** (클라이언트 → agent)

| Type | 설명 |
| --- | --- |
| `user.message` | 텍스트, 이미지, 문서 콘텐츠를 담은 사용자 메시지 |
| `user.interrupt` | 실행 중 agent 중지. workflow run은 종료하지 않음 |
| `user.custom_tool_result` | custom tool 호출에 대한 응답 |
| `user.tool_confirmation` | permission policy가 확인을 요구할 때 agent/MCP tool 호출 승인·거부 |
| `user.define_outcome` | agent가 지향할 outcome 정의 |
| `user.tool_result` | `self_hosted` environment 전용. `agent_toolset` 결과를 통합 측이 제공(SDK helper·CLI는 자동 처리) |

**Agent events**

| Type | 설명 |
| --- | --- |
| `agent.message` | agent 응답 content blocks |
| `agent.thinking` | extended thinking 진행 신호. **thinking 내용은 포함하지 않음** |
| `agent.tool_use` / `agent.tool_result` | pre-built 도구 호출/결과. tool_use는 `evaluated_permission`과 보통 `evaluation` 포함 |
| `agent.mcp_tool_use` / `agent.mcp_tool_result` | MCP 도구 호출/결과. mcp_tool_use도 `evaluated_permission`, `evaluation` 포함 |
| `agent.custom_tool_use` | custom tool 호출. `user.custom_tool_result`로 응답 |
| `agent.thread_context_compacted` | context window에 맞추려 대화 이력이 compaction됨 |
| `agent.thread_message_received` / `agent.thread_message_sent` | multiagent session에서 thread 간 메시지 수신/발신 |

메시지 content에 `{"type": "redacted"}` 블록이 나올 수 있다(Anthropic 모델 정책으로 보류된 콘텐츠의 placeholder). 플랫폼이 내보내는 콘텐츠에만 등장하며, user event에 넣으면 **400**.

**Session events**

| Type | 설명 |
| --- | --- |
| `session.status_running` | 처리 중 |
| `session.status_idle` | 현재 작업 완료, 입력 대기. `stop_reason` 포함 |
| `session.status_rescheduled` | 일시 오류, 자동 재시도 중 |
| `session.status_terminated` | 복구 불가 오류 또는 archive로 종료 |
| `session.deleted` | 삭제됨. 활성 스트림 종료, 이후 이벤트 없음 |
| `session.updated` | session 업데이트로 변경된 필드만 포함. 다음 턴부터 적용 |
| `session.error` | 처리 중 오류. `error` 객체에 `retry_status` |
| `session.usage` | 누적 usage와 tracked list cost 스냅샷, budget이 있으면 함께 |
| `session.thread_created` | multiagent thread 생성 (`workflow_run_id`, workflow run이 아니면 `null`) |
| `session.thread_status_running` / `_idle` / `_rescheduled` / `_terminated` | thread 단위 상태. 모든 session은 primary thread에 대해 running을 발행 |

Dynamic workflows가 켜진 agent의 session에서는 `workflow_run.created`, `workflow_run.status_running`, `workflow_run.status_idle`, `workflow_run.status_ended`, `workflow_run.error`, `workflow_run.phase_started`, `workflow_run.phase_ended`도 도착한다.

**Span events** (관측용 마커)

| Type | 설명 |
| --- | --- |
| `span.model_request_start` / `span.model_request_end` | 모델 추론 호출 시작/종료. end에 `model_usage`(토큰 수) |
| `span.outcome_evaluation_start` / `_ongoing` / `_end` | outcome 평가. 결과 `needs_revision`이면 다음 사이클, `satisfied`·`max_iterations_reached`·`failed`·`interrupted`는 종료 |

**System events**: `system.message` — 해당 턴과 이후 모든 턴에 적용되는 특권 system-level 컨텍스트 추가. 지원하지 않는 primary 모델이면 `model_does_not_support_mid_conversation_system`으로 거부.

**Event deltas** (stream 전용, 영속화 안 됨): `event_start`, `event_delta`. 스트림 연결 시 `event_deltas` 파라미터(curl: `event_deltas[]`, CLI: `--event-delta`)로 opt-in.

### 7.2 Rate limits (조직 단위)

| 작업 | 한도 |
| --- | --- |
| Create 엔드포인트 (agents, sessions, environments 등) | **300 requests / minute** |
| Read 엔드포인트 (retrieve, list, stream 등) | **1,200 requests / minute** |

조직 수준의 spend limit과 usage-tier rate limit도 함께 적용된다.

### 7.3 CLI 플래그

reference 페이지는 self-hosted worker용 `ant beta:worker` CLI 플래그·환경 변수·파일시스템 경로·SDK helper 옵션을 **별도 페이지(Self-hosted worker reference)로 위임**하며, 이 장의 소스에는 플래그 표가 없다(→ self-hosted 관련 장 참조). 이 장의 문서들에 등장한 `ant` 명령/플래그는 다음과 같다.

| 명령 | 등장 플래그 |
| --- | --- |
| `ant apply <file...>` | (파일 인자) — `claude-lock.json`에 ID 기록 |
| `ant beta:sessions create` | `--agent`, `--environment-id`, `--title`, `--transform id`, `--raw-output` |
| `ant beta:sessions:events stream` | `--session-id`, `--transform type`, `--raw-output`, (`--event-delta`) |
| `ant beta:sessions:events send` | `--session-id`, `--event` |
| `ant beta:agents update` | `--agent-id`, `--description` |
| `ant beta:agents:versions list` | `--agent-id` |
| `ant beta:agents archive` | `--agent-id` |

### 7.4 지원 MCP 서버 유형

- HTTP endpoint를 노출하는 **remote MCP server**, 또는 **MCP tunnels**를 통한 private MCP server.
- streamable HTTP transport 지원 권장. deprecated SSE transport만 지원하는 서버도 자동 fallback으로 동작.

### 7.5 기타 한도

이 장의 소스 문서에는 rate limit 외의 수치 한도(최대 session 수, 파일 크기, session 시간 등)가 **나오지 않는다** **[불명확: 다른 장/문서 확인 필요]**.

### 7.6 Branding 가이드라인 (파트너용)

Claude 브랜딩 사용은 **선택 사항**.

| 허용 | 금지 |
| --- | --- |
| "Claude Agent" (드롭다운 메뉴에 권장) | "Claude Code" 또는 "Claude Code Agent" |
| "Claude" ("Agents"로 라벨된 메뉴 안에서) | "Claude Cowork" 또는 "Claude Cowork Agent" |
| "{YourAgentName} Powered by Claude" (기존 agent 이름이 있을 때) | Claude Code 브랜드 ASCII art나 Claude Code를 모방한 시각 요소 |

제품은 자체 브랜딩을 유지해야 하며 Claude Code, Claude Cowork 등 Anthropic 제품처럼 보이면 안 된다. 문의는 Anthropic sales 팀.

---

## 8. Beta 접근, 데이터 보존, ZDR/HIPAA

### 8.1 Beta 조건

1. Claude API key
2. 모든 요청에 `managed-agents-2026-04-01` beta 헤더 (SDK는 자동)
3. Managed Agents 접근 — **모든 API 계정에 기본 활성화**

- 베타 기간 중 동작이 출력 개선을 위해 릴리스 사이에 다듬어질 수 있다.
- **MCP tunnels**와 **dreaming**은 더 제한된 research preview이며 별도 접근 요청 필요(`claude.com/form/claude-managed-agents`).

### 8.2 데이터 보존과 컴플라이언스 주의

- Managed Agents는 **설계상 stateful**: session은 장시간 실행되고, 일시정지 후 재개되며, 대화 이력·sandbox 상태·출력을 **서버 측에 저장**한다.
- 그 결과 **Zero Data Retention(ZDR) 대상이 아니며, HIPAA BAA 적용 대상도 아니다** (현재 기준).
- 데이터 통제: API로 언제든 **session 삭제** 가능, 업로드한 **files는 별도로 삭제**해야 함.
- 데이터 위치 관련 통제는 `inference_geo` pin(§4.3)과 self-hosted sandbox 옵션이 문서에 언급된다. 단 self-hosted가 ZDR/HIPAA 적격성을 바꾸는지는 언급이 없다 **[불명확]**.

### 8.3 가격

이 장의 소스 문서(overview, quickstart, agent-setup, onboarding, migration, reference)에는 **가격 정보가 없다.** 관련 단서는 다음뿐이다.
- `session.usage` 이벤트가 "tracked list cost"와 budget을 담는다.
- agent-setup은 inference geo 관련 pricing을 Data residency 문서로 안내한다.
- Knowledge wiki 예제가 "a fraction of the cost"를 언급한다.
- 조직 spend limit이 적용된다.

session 시간 과금, 토큰 단가 등은 **[불명확: 이 장 소스 범위 밖]**.

---

## 9. 핵심 정리

- Managed Agents = Anthropic 인프라에서 도는 관리형 agent harness. Messages API의 "직접 루프"와 Agent SDK의 "내 프로세스 실행"을 대체.
- 4개념: **Agent**(버전 관리되는 설정) / **Environment**(cloud 또는 self-hosted sandbox) / **Session**(실행 인스턴스) / **Events**(SSE 기반 송수신).
- 흐름: agent·environment는 한 번 만들어 재사용 → session 생성 → 스트림 open → `user.message` send → `session.status_idle`까지 처리.
- Agent 업데이트는 새 버전을 만들고, `version`으로 optimistic concurrency(409), archive는 비가역.
- 내장 toolset 기본 permission은 `always_allow`.
- Rate limit: create 300/min, read 1,200/min (조직 단위).
- **ZDR·HIPAA BAA 미적격.**

---

## 출처

- https://platform.claude.com/docs/en/managed-agents/overview
- https://platform.claude.com/docs/en/managed-agents/quickstart
- https://platform.claude.com/docs/en/managed-agents/agent-setup
- https://platform.claude.com/docs/en/managed-agents/onboarding
- https://platform.claude.com/docs/en/managed-agents/migration
- https://platform.claude.com/docs/en/managed-agents/reference
