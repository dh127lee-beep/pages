# 7장. 출시 경과, 가격, 시장 반응, 대안 비교

> 작성 기준일: 2026-10-14. Claude Managed Agents(이하 MA)는 2026-04-08 public beta로 출시되었으며 beta 헤더는 `managed-agents-2026-04-01`이다.
>
> 출처 표기 원칙
> - **[1차]** Anthropic(anthropic.com, claude.com, platform.claude.com) 또는 경쟁사 공식 문서/가격 페이지.
> - **[3자]** 언론, 블로그, 벤치마크 등 제3자 자료. 3자 자료에만 있는 수치는 본문에 명시적으로 표시했다.
> - **[불일치]** 출처 간 수치나 날짜가 서로 다른 경우.
> - **(정리자 주)** 필자의 해석이나 계산.

---

## 7.1 한눈에 보기

- **가격 구조 [1차, 검증됨]:** 모델 토큰 요금(Messages API와 동일 단가, 프롬프트 캐싱 배수 동일 적용) + **세션 런타임 $0.08/세션-시간**. 런타임은 세션 상태가 `running`인 동안만 밀리초 단위로 계측하며, `idle`(다음 메시지나 도구 승인 대기), `rescheduling`, `terminated` 상태는 과금하지 않는다. 세션 안의 웹 검색은 **$10 / 1,000회**이며, 웹 페치는 추가 요금이 없다(토큰만 과금).
- **적용되지 않는 할인 [1차]:** Batch API 50% 할인은 적용되지 않는다(배치 모드가 없음). Bedrock/Google Cloud 같은 파트너 운영 클라우드에서는 MA를 제공하지 않는다.
- **출시 후 6개월 동안 기능이 빠르게 추가되었다:** 메모리(4/23), 멀티에이전트·Outcomes·웹훅·Dreams(5/6), Claude Platform on AWS(5/11), 자체 호스팅 샌드박스·MCP 터널(5/19), 스케줄 배포·볼트 환경 변수(6/9), 세션 예산(8/7), `auto` 권한 정책(9/10), 웹 도구 네트워크 강화(10/7), 동적 워크플로(10/9).
- **주요 비판:** Claude 전용이라 생기는 벤더 종속(lock-in), 세션 데이터가 Anthropic DB에 저장되는 점, 토큰과 런타임이 섞인 하이브리드 과금이라 비용 예측이 어렵다는 점, ZDR과 HIPAA BAA를 적용받을 수 없다는 점(공식 문서가 확인).
- **대안:** OpenAI(Agents SDK/AgentKit + Responses API 컨테이너), Google Vertex AI Agent Engine, AWS Bedrock AgentCore, 그리고 Claude Agent SDK로 직접 호스팅하는 방법.

---

## 7.2 출시 및 기능 타임라인

주 출처는 Claude Platform 릴리스 노트 [1차]이고, 블로그 발표 [1차]와 언론 보도 [3자]로 교차 확인했다.

| 날짜 (2026) | 이벤트 | 상태 | 출처 |
| --- | --- | --- | --- |
| 04-08 | **MA public beta 출시.** 관리형 하네스, 샌드박스, 내장 도구, 스트리밍 제공. 같은 날 엔지니어링 블로그 "Scaling Managed Agents: Decoupling the brain from the hands"도 공개 | public beta | 릴리스 노트, claude.com 블로그, anthropic.com/engineering [1차] |
| 04-08 | 출시 시점에 멀티에이전트 조정과 Outcomes(자기 평가)는 별도 신청이 필요한 research preview였음 | research preview | claude.com 블로그 [1차] |
| 04-09 | 일부 매체는 출시일을 Cowork GA, Claude Code 업데이트와 묶어 4월 9일로 보도 **[불일치]** | - | pasqualepillitteri.it [3자] |
| 04-23 | **메모리(memory stores) public beta.** 파일 기반이라 export, API 관리 가능 | public beta | 릴리스 노트, claude.com 블로그 [1차] |
| 04-29 | 오픈소스 Claude API skill이 MA 구축 가이드 포함 | - | 릴리스 노트 [1차] |
| 05-06 | **멀티에이전트 오케스트레이션, Outcomes public beta 전환.** 웹훅, 세션/이벤트 필터링, `mcp_oauth` 볼트 갱신 추가. **Dreams(dreaming) research preview** | public beta / RP | 릴리스 노트 [1차], SD Times(5/6), 9to5Mac(5/7) [3자] |
| 05-11 | **Claude Platform on AWS 출시**(Anthropic 운영, AWS Marketplace 과금). MA는 beta로 포함 | GA(플랫폼) / beta(MA) | claude.com 블로그, 릴리스 노트 [1차] |
| 05-19 | **자체 호스팅 샌드박스**(public beta), **MCP 터널**(research preview). Code with Claude London에서 발표. 파트너는 Cloudflare, Daytona, Modal, Vercel | public beta / RP | 릴리스 노트, claude.com 아티클 [1차], The Decoder, InfoQ [3자] |
| 05-29 | Claude Platform on AWS에서 웹훅, 멀티에이전트, 자체 호스팅 샌드박스 지원 | - | 릴리스 노트 [1차] |
| 06-09 | **스케줄 배포**(cron), **볼트 환경 변수 자격 증명** | public beta | 릴리스 노트, claude.com 블로그 [1차] |
| 06-22 | MCP 터널 관리 API가 `/v1/tunnels`로 이동(`mcp-tunnels-2026-06-22`) | - | 릴리스 노트 [1차] |
| 06-30 | 이벤트 델타, 세션별 에이전트 오버라이드, 볼트 `injection_location`, 에이전트/배포 수명주기 웹훅 | - | 릴리스 노트 [1차] |
| 07-02 | 메모리 스토어 엔드포인트 헤더가 `agent-memory-2026-07-22`로 교체 | - | 릴리스 노트 [1차] |
| 07-22 | 에이전트 `effort` 설정, 환경/메모리 스토어 웹훅, 세션 생성 시 `initial_events` | - | 릴리스 노트 [1차] |
| 08-07 | **세션 예산**(`budget_reached`), advisors, 에이전트 `inference_geo`, 마운트한 GitHub 저장소에서 스킬 로드 | - | 릴리스 노트 [1차] |
| 08-19 | 웹 도구 `allowed_domains`/`blocked_domains`, 자체 호스팅 샌드박스에서 메모리 스토어 사용, 콘솔 세션 뷰어 재설계 | - | 릴리스 노트 [1차] |
| 09-03 | `ant apply`로 에이전트, 환경, 스킬, 메모리 스토어, 배포를 저장소 파일에서 선언적으로 관리(`claude-lock.json`) | - | 릴리스 노트 [1차] |
| 09-10 | **`auto` 권한 정책**(서버가 각 호출을 평가), `ant beta:sessions connect` | - | 릴리스 노트 [1차] |
| 10-01 | Dreams가 Opus 5.5, Fable 5.1, Sonnet 5.5 지원 | - | 릴리스 노트 [1차] |
| 10-07 | limited 네트워킹의 `allowed_hosts`가 web_search/web_fetch에도 적용됨. `web_fetch`는 세션에 이미 등장한 URL만 가져옴 | - | 릴리스 노트 [1차] |
| 10-09 | **동적 워크플로(dynamic workflows) beta.** 에이전트가 여러 에이전트를 단계별로 실행하는 워크플로를 작성 | beta | 릴리스 노트 [1차] |

**날짜 불일치 메모**

- Dreams/Outcomes/멀티에이전트 발표일: 릴리스 노트와 SD Times는 **5월 6일**이다. 그런데 claude.com 블로그 "New in Claude Managed Agents: dreaming, outcomes, and multiagent orchestration"은 조회 시점에 **5월 19일**로 표시되었다 **[불일치]**. 다른 페이지가 5/19에 같은 URL 계열로 묶였거나 게시 후 수정되었을 가능성이 있다. 이 장은 릴리스 노트 기준(5/6)을 따른다.
- 일부 3자 자료(The Decoder 등)는 dreaming을 5월 19일 발표로 보도했다. 5월 19일의 확인된 발표는 자체 호스팅 샌드박스와 MCP 터널이다.
- (정정) 동적 워크플로의 "실행당 최대 1,000개 에이전트", "동시 64 스레드"는 공식 문서 [Workflow runs](https://platform.claude.com/docs/en/managed-agents/workflow-runs)의 한도 표에 있다 [1차]. 단, 64는 API가 보장하지 않는 값이라고 명시되어 있다. 3자 자료(fourweekmba, vanja.io)도 같은 수치를 인용한다.
- (정정) 멀티에이전트의 "목록당 최대 20개 에이전트", "세션당 자식 스레드 최대 25개(idle 포함, advisor·workflow 스레드 제외)"도 공식 문서 [Multiagent orchestration](https://platform.claude.com/docs/en/managed-agents/multiagent-orchestration) / [Session threads](https://platform.claude.com/docs/en/managed-agents/session-threads)에 있다 [1차]. 자세한 내용은 [05-advanced-features.md](05-advanced-features.md) 참고.

---

## 7.3 가격

### 7.3.1 MA 고유 과금 [1차: platform.claude.com/docs/en/about-claude/pricing]

| 항목 | 단가 | 계측 / 비고 |
| --- | --- | --- |
| 세션 런타임 | **$0.08 / 세션-시간** | `running` 상태 시간만 밀리초 단위로 계측. `idle`, `rescheduling`, `terminated`는 제외 |
| 모델 토큰 | 모델별 표준 단가(아래 표) | 프롬프트 캐싱 배수 동일 적용 |
| 웹 검색 | **$10 / 1,000회** + 결과 토큰 | 세션 안에서 발생한 검색도 표준 요금 |
| 웹 페치 | 추가 요금 없음 | 가져온 콘텐츠의 토큰만 과금 |
| 코드 실행 컨테이너 | **별도 과금 없음** | "세션 런타임이 코드 실행의 컨테이너-시간 과금 모델을 대체한다" |
| US 전용 추론(`model.inference_geo: "us"`) | 토큰 1.1배 | Messages API와 동일한 배수 |
| Fast mode(`model.speed: "fast"`) | Fast mode 프리미엄 단가 | research preview, 1st-party API 전용 |
| Claude Platform on AWS | 토큰과 런타임을 CCU로 환산 | 1 CCU = $0.01, AWS Marketplace에서 시간 단위 계측, 후불 |
| Batch API 할인 | **적용 안 됨** | "Sessions are stateful and interactive. There is no batch mode." |
| 파트너 클라우드(Bedrock, Google Cloud) | **제공 안 됨** | "Not available on partner-operated cloud platforms." |
| Dreams | 선택한 모델의 표준 토큰 단가 | 입력 세션 수와 길이에 대략 선형으로 비례(dreams 문서) |

공식 예시 [1차]: Claude Opus 5.5로 1시간 코딩 세션, 입력 50,000 토큰, 출력 15,000 토큰.

| 항목 | 계산 | 비용 |
| --- | --- | --- |
| 입력 토큰 | 50,000 × $4 / 1M | $0.20 |
| 출력 토큰 | 15,000 × $20 / 1M | $0.30 |
| 세션 런타임 | 1.0h × $0.08 | $0.08 |
| **합계** | | **$0.58** |
| (캐싱 시) 입력 중 40,000이 캐시 읽기 | 10,000×$4/1M + 40,000×$4×0.05/1M + $0.30 + $0.08 | **$0.428** |

### 7.3.2 모델 토큰 단가 (2026-10-14 조회, 발췌) [1차]

| 모델 | 입력 | 5분 캐시 쓰기 | 1시간 캐시 쓰기 | 캐시 히트 | 출력 |
| --- | --- | --- | --- | --- | --- |
| Claude Fable 5.1 | $10 | $12.50 | $20 | $0.25 | $50 |
| Claude Opus 5.5 | $4 | $5 | $8 | $0.20 | $20 |
| Claude Opus 5 / 4.8 / 4.7 / 4.6 / 4.5 | $5 | $6.25 | $10 | $0.50 | $25 |
| Claude Sonnet 5.5 | $2 | $2.50 | $4 | $0.10 | $10 |
| Claude Sonnet 5 | $2 | $2.50 | $4 | $0.20 | $10 |
| Claude Sonnet 4.6 / 4.5 | $3 | $3.75 | $6 | $0.30 | $15 |
| Claude Haiku 5.5 (≤100K 프롬프트) | $0.10 | $0.125 | $0.20 | $0.01 | $0.50 |
| Claude Haiku 4.5 | $1 | $1.25 | $2 | $0.10 | $5 |

(단위: USD / 백만 토큰. Opus 5.5와 Sonnet 5.5의 캐시 히트는 0.05배, Fable 5.1은 0.025배, 그 외는 0.1배다. Claude 4.7 이후 모델은 새 토크나이저 때문에 같은 텍스트에서 토큰이 약 30% 더 나온다고 공식 페이지가 명시한다.)

### 7.3.3 비교 기준: Messages API 직접 사용 시 관련 과금 [1차]

| 항목 | Messages API | MA |
| --- | --- | --- |
| 코드 실행 컨테이너 | 조직당 월 **1,550시간 무료**, 초과 시 **$0.05/시간/컨테이너**, 최소 5분. web_search/web_fetch(20260209 이후 버전)와 함께 쓰면 무료 | 세션 런타임 $0.08/h에 포함 |
| Batch API | 50% 할인 | 해당 없음 |
| 웹 검색 | $10 / 1,000회 | 동일 |
| 웹 페치 | 무료(토큰만) | 동일 |

### 7.3.4 런타임 비용 감각 (정리자 계산)

| 시나리오 | 런타임 요금 |
| --- | --- |
| 1시간 `running` | $0.08 |
| 하루 24시간 내내 `running` | $1.92 |
| 30일 내내 `running` (720h) | $57.60 |
| 하루 10분짜리 스케줄 실행 × 30일 | 약 $0.40 |

(정리자 주) 공식 예시에서도 런타임($0.08)은 토큰 비용($0.50)보다 작다. 대부분의 워크로드에서 비용을 좌우하는 것은 **모델 선택과 토큰량**이다. 그래도 Messages API와 비교하면 (1) Batch 할인을 못 쓰고, (2) 코드 실행 1,550시간 무료 구간이 없으며, (3) 런타임 요금이 추가된다는 점이 차이로 남는다. 승인 대기(`idle`)는 과금되지 않으므로 사람 승인 루프에는 비용 페널티가 없다.

### 7.3.5 3자 자료의 가격 주장과 검증 결과

| 주장 | 출처 | 검증 |
| --- | --- | --- |
| "표준 토큰 + $0.08/세션-시간" | Medium(sathishkraju), VentureBeat, AIMultiple 등 | **공식 가격 페이지와 일치** |
| "활성 실행 시간 기준 $0.08/시간"(블로그 표현 "per session-hour of active runtime") | claude.com 출시 블로그 [1차] | 가격 문서의 `running` 계측과 일치 |
| "시간당 $0.70, 1시간 세션으로 티켓 10,000건 처리 시 최대 $37" | VentureBeat [3자] | **근거 불명.** $0.70의 의미를 기사에서 설명하지 않으며, 공식 자료에도 이런 수치는 없다. 인용하지 않는 것을 권장 |
| Batch 할인 미적용, 컨테이너-시간 대체 | verdent.ai, TrueFoundry 등 [3자] | 공식과 일치 |

### 7.3.6 레이트 리밋 [1차: MA reference]

| 작업 | 한도(조직당) |
| --- | --- |
| 생성 엔드포인트(에이전트, 세션, 환경 등) | 300 req/분 |
| 읽기 엔드포인트(조회, 목록, 스트림) | 1,200 req/분 |

조직 단위 지출 한도와 사용 등급별 레이트 리밋도 함께 적용된다.

---

## 7.4 고객 사례 (공식 발표에 나온 고객 주장)

모든 수치는 **Anthropic이 공식 발표에 인용한 고객 주장**이다. 독립적으로 검증된 수치가 아니다.

| 고객 | 용도 / 주장 | 출처(날짜) |
| --- | --- | --- |
| Rakuten | 제품, 영업, 마케팅, 재무 전반의 전문 에이전트를 "각각 1주일 내 배포". 이후 스케줄 배포로 주간/월간 보고서와 덱 생성, 운영 로그 모니터링 | 출시 블로그(4/8), 스케줄 블로그(6/9) |
| Notion | Notion Custom Agents 안에서 private alpha로 사용. 볼트로 CLI를 배포하면서 "API 토큰을 에이전트에 넘기지 않음" | 4/8, 6/9 |
| Sentry | 통합 기능을 "몇 달이 아닌 몇 주 만에" 구축 | 4/8 |
| Atlassian | 개발자 에이전트를 "몇 주 만에" 구축 | 4/8 |
| Asana | 기능 추가 속도 향상(수치 없음) | 4/8 |
| Vibecode | 인프라 구성이 "최소 10배 빨라짐" | 4/8 |
| General Legal | "개발 시간을 10배 단축"(CTO 인용) | 4/8 |
| Blockit | 회의 준비 에이전트를 "3배 빠르게" 구축 | 4/8 |
| Harvey | Outcomes 적용 후 테스트에서 "완료율 약 6배" | 5월 블로그 |
| Wisedocs | 리뷰가 "50% 빨라짐" | 5월 블로그 |
| Netflix | 플랫폼 팀이 멀티에이전트 오케스트레이션 사용(수치 없음) | 5월 블로그, 9to5Mac |
| Spiral by Every | 언급만 있음 | 5월 블로그 |
| Amplitude | Cloudflare 샌드박스로 디자인 에이전트 첫 버전을 "이틀 만에" 가동 | 5/19 |
| Clay | GTM 에이전트 Sculptor를 Daytona 샌드박스에서 운영 | 5/19 |
| Rogo | Vercel Sandbox로 애널리스트 에이전트 구축 | 5/19 |
| DoorDash | Modal 기반으로 "평가 중" | 5/19 |
| Actively AI | 자체 스케줄링 인프라를 스케줄 배포로 대체해 "스택이 크게 단순해짐" | 6/9 |
| Ando, Browserbase, KERNEL, Milana | 스케줄 배포와 볼트 활용 사례 | 6/9 |

Anthropic 자체 성능 주장 [1차]:

- 구조화된 파일 생성 내부 테스트에서 표준 프롬프트 루프 대비 "task success 최대 10포인트 향상"(4/8). Outcomes 내부 벤치마크는 "docx +8.4%, pptx +10.1%"(5월).
- 엔지니어링 블로그: 하네스와 샌드박스를 분리한 뒤 p50 TTFT가 "약 60%", p95 TTFT가 "90% 이상" 감소. 기준값은 공개하지 않았다.
- 3자 해설: "10배 빠르다"는 고객 주장은 모델 성능이 아니라 **개발 속도**를 말한다는 지적이 있다(emergingai substack).

---

## 7.5 시장 반응과 제3자 평가

### 7.5.1 긍정적 평가

- **구축 속도와 운영 부담 감소.** VentureBeat(2026-04-14)는 내장 하네스가 상태, 실행 그래프, 라우팅 같은 엔지니어링 부담을 줄인다고 평가했다. 같은 기사는 자체 설문에서 tool-use/workflows API 채택률이 1월 0%에서 2월 5.7%로 올랐다고 인용했다 [3자].
- **관리형 하네스 기능.** AIMultiple 벤치마크(2026-05-04, 8/21 갱신)에서 MA는 10개 코딩 과제 × 3회에서 30/30을 통과했고, 실행 중 조향(mid-stream steering)과 재연결을 테스트할 수 있었던 유일한 플랫폼이었다 [3자, 단일 벤더 벤치마크, 소규모 과제].
- **아키텍처.** Martin Alderson(2026-05-14)은 백그라운드 상시 실행, 이벤트 반응, 인프라와 OS 패치를 맡아 주는 점, 샌드박싱을 장점으로 꼽았다 [3자].

### 7.5.2 비판

| 쟁점 | 내용 | 출처 |
| --- | --- | --- |
| 벤더 종속(모델) | 하네스 안에서 Claude 외 모델(GPT, Gemini 등)을 실행할 방법이 없다. 가격 변경이나 기능 폐기 시 이전이 어렵다 | Medium(sathishkraju) [3자] |
| 벤더 종속(데이터) | "세션 데이터가 Anthropic이 관리하는 DB에 저장된다." 기업이 통제력, 관측성, 이식성을 잃는다 | VentureBeat [3자] |
| "새로운 Lambda" | 하네스나 모델 교체는 기술적으로 쉽지만, 벤더 클라우드에 쌓인 데이터와 워크플로가 종속을 만든다. "export 가능"의 정의는 시간이 지나며 좁아지는 경향이 있다. **당분간 자체 호스팅을 권장** | Martin Alderson [3자] |
| 두 개의 제어 평면 | 기업 오케스트레이션과 Claude 런타임이 서로 상충하는 지시를 낼 수 있다. 규제 대상 워크플로에 영향 | VentureBeat [3자] |
| 비용 예측성 | 토큰과 런타임이 섞인 하이브리드 과금이라 비용이 더 동적이고 예측하기 어렵다 | VentureBeat [3자] |
| 가격 정책 리스크 | 비대화형 Claude Code 사용이 구독 한도에서 빠진 사례를 들어, 헤비 유저 기준 5~20배 비용 증가를 추정 | Martin Alderson [3자, 추정치] |
| ZDR / HIPAA | **MA는 현재 Zero Data Retention이나 HIPAA BAA를 적용받을 수 없다.** 세션 이력, 샌드박스 상태, 출력물을 서버에 저장하는 상태 유지형 설계 때문 | MA 개요 및 보안 문서 **[1차, 확인됨]** |
| 기능 성숙도 | 출시 시 멀티에이전트와 Outcomes가 research preview였다(5/6 public beta 전환). 현재도 Dreams와 MCP 터널은 신청이 필요한 research preview | 출시 블로그, 개요 문서 [1차] |
| 커뮤니티 | HN 반응을 정리한 한국어 글에 따르면 단일 벤더 의존이 최대 비판이었고, 혼합 모델 워크플로를 선호하는 의견이 많았다(원문 직접 확인 실패, 검색 요약 기준) | wikidocs [3자, 미확인] |

### 7.5.3 AWS 경로의 추가 제약 [1차: AWS 사용자 가이드]

- Claude Platform on AWS는 Anthropic이 운영하는 서비스로, 데이터가 AWS 경계 밖에서 처리된다. **표준 AWS 컴플라이언스 프로그램(SOC, ISO, HIPAA 적격성 등) 범위에 포함되지 않는다.**
- MA 리소스(에이전트, 세션, 환경, 볼트, 메모리 스토어)는 IAM 리소스로 다뤄진다.
- **자율 세션은 6시간마다 재인증이 필요하다.** SigV4 자격 증명이나 API 키를 갱신하지 않으면 세션이 종료된다.
- AWS 가이드는 Outcomes와 멀티에이전트 세션이 "현재 미지원"이라고 적고 있다. 반면 Anthropic 릴리스 노트는 5/29에 멀티에이전트와 웹훅이 AWS에서 지원된다고 했다 **[불일치]**. 문서 갱신 시차로 추정되므로 도입 전에 직접 확인이 필요하다.
- 지출 한도(spend limits)는 제공되지 않아 AWS 결제 통제에 의존해야 한다. HIPAA-ready 프로그램도 없다.

---

## 7.6 대안 비교

### 7.6.1 비교표

| 항목 | Claude Managed Agents | OpenAI (Agents SDK / AgentKit / Responses API) | Google Vertex AI Agent Engine | AWS Bedrock AgentCore | 자체 호스팅 (Claude Agent SDK) |
| --- | --- | --- | --- | --- | --- |
| 형태 | 완전 관리형 하네스 + 샌드박스 + 세션 상태 | SDK(오픈소스) + 호스티드 도구/컨테이너, 비주얼 빌더(AgentKit) | 관리형 에이전트 런타임(ADK 등 프레임워크 배포) | 관리형 런타임(microVM) + Gateway/Memory/Identity 등 모듈 | 라이브러리. 루프, 샌드박스, 상태를 모두 직접 운영 |
| 모델 | Claude 전용 | OpenAI 모델 중심 | Gemini 중심(타 모델 배포 가능 여부는 이번 조사에서 미확인) | 공식 가격 페이지에서 모델 중립성 미확인(일반적으로 프레임워크/모델 무관으로 알려짐, 정리자 배경지식) | Claude(Messages API, Bedrock, Vertex 경유 가능) |
| 런타임 과금 | **$0.08/세션-시간**(`running`만) [1차] | 컨테이너(Hosted Shell / Code Interpreter) 1GB **$0.03/20분 세션**, 4GB $0.12, 16GB $0.48, 64GB $1.92, 분 단위 과금, 최소 5분 [1차] | 약 $0.0864/vCPU-h + $0.009/GiB-h (2026) 또는 $0.0994 / $0.0105 (2025 출시가) **[불일치, 3자]** | Runtime v1 $0.0895/vCPU-h + $0.00945/GB-h. v2 $0.1276 / $0.0169. I/O 대기 중 CPU 무과금 [1차] | 자체 인프라 비용 |
| 웹 검색 | $10/1k [1차] | $10/1k(+토큰) [1차] | (미조사) | Gateway Web Search $7/1k [1차] | Messages API 웹 검색 $10/1k |
| 메모리 | 메모리 스토어(추가 단가 공시 없음), Dreams는 토큰 과금 | (해당 기능 별도 조사 안 함) | Sessions $0.25/1k 이벤트, Memory Bank $0.25/1k 메모리·월 **[3자]** | 단기 수집 $1.00/GB(10/6부터), 장기 저장 $0.75/1k 레코드·월, 조회 $0.50/1k [1차] | 직접 구현 |
| 배치 할인 | 없음 | (컨테이너 해당 없음) | - | - | Messages API Batch 50% 가능 |
| 자체 인프라 실행 | 자체 호스팅 샌드박스(public beta). 루프와 이력은 Anthropic에 남음 | - | GCP 프로젝트 내 | AWS 계정 내 | 전부 자체 |
| 데이터 보존 | ZDR/HIPAA BAA **불가** [1차] | (미조사) | (미조사) | (미조사) | Messages API의 ZDR 적용 가능(계약 시) |
| 고유 강점 | 실행 중 조향, 재연결, Outcomes 채점기, Dreams, 볼트 placeholder 주입, `auto` 권한 정책 | 비주얼 빌더, ChatKit UI | GCP 통합, 무료 크레딧 | IAM/VPC 통합, 세분화된 모듈 과금 | 최대 통제력, 이식성, 비용 최적화 여지 |

### 7.6.2 AIMultiple 벤치마크 (2026-05-04) [3자, 단일 출처]

| 플랫폼 | 모델 | 통과율 | 소요 시간 | 비용 | 토큰 |
| --- | --- | --- | --- | --- | --- |
| Claude Managed Agents | Sonnet 4.6 | 30/30 | 1,172초 | $2.50 | 93k |
| Vertex AI Agent Engine | Gemini 2.5 Pro | 30/30 | 1,447초 | $1.45 | 159k |
| OpenAI Responses + Code Interpreter | GPT-5.4 | 27/30 | 522초 | $1.54 | 113k |
| 대조군(로컬 자체 루프) | Sonnet 4.6 | 30/30 | 794초 | $1.96 | 464k |

해석 시 주의할 점:

- 과제 10개 × 3회의 소규모 코딩 과제다. 장시간 자율 실행, 콜드 스타트, 동시성은 측정하지 않았다.
- OpenAI의 실패 3건은 모델이 아니라 Code Interpreter 샌드박스가 외부 HTTP를 막았기 때문이었다.
- Vertex는 약 42% 저렴했지만 가장 느렸다. MA는 관리형 하네스 고유 기능에서 가장 앞섰다.
- 사용 모델이 현재 최신 모델(Opus 5.5, Sonnet 5.5 등)이 아니므로 비용 비교는 현재 단가와 다르다.

### 7.6.3 언제 무엇을 고르나 (공식 문서 + 정리자 종합)

공식 개요 문서 [1차]는 MA가 다음 상황에 적합하다고 한다.

- 수 분에서 수 시간 동안 도구를 여러 번 호출하는 **장시간 실행**
- 패키지가 미리 설치되고 네트워크에 접근할 수 있는 안전한 **클라우드 샌드박스**
- 컴플라이언스나 데이터 거주 요건 때문에 필요한 **자체 호스팅 실행**
- 에이전트 루프, 샌드박스, 도구 실행 계층을 직접 만들 필요가 없는 **최소 인프라**
- 여러 상호작용에 걸쳐 파일시스템과 대화 이력이 유지되는 **상태 유지형 세션**
- cron 기반 **스케줄 실행**

반대로 직접 에이전트 루프를 세밀하게 통제하려면 Messages API를 쓰라고 안내한다.

(정리자 주) 선택 기준 요약:

| 상황 | 권장 |
| --- | --- |
| Claude만 쓰고, 빠른 출시와 운영 부담 최소화가 우선 | MA |
| ZDR이나 HIPAA BAA가 필수 | MA 불가. Messages API 기반 자체 호스팅(Claude Agent SDK) 또는 Bedrock 경유 Claude 검토 |
| 멀티 모델이나 모델 교체 가능성 확보가 중요 | AgentCore, Vertex Agent Engine 같은 범용 런타임 또는 자체 호스팅 |
| 대량의 비대화형 배치 처리 | Messages API Batch(50% 할인). MA는 배치 할인 없음 |
| AWS 청구와 IAM 통합이 필요하고 Claude를 쓰려 함 | Claude Platform on AWS 경유 MA(6시간 재인증, 일부 기능 미지원 확인) |
| 파일과 실행을 자사 경계 안에 두되 하네스는 관리형으로 | MA 자체 호스팅 샌드박스(이력과 도구 입출력은 여전히 Anthropic으로 전송됨) |

---

## 7.7 장단점 정리

### 장점

1. **인프라 구축 불필요.** 루프, 샌드박스, 상태 저장, 재연결, 컨텍스트 관리(캐싱, 컴팩션)가 기본 제공된다 [1차].
2. **단순하고 낮은 런타임 단가.** $0.08/h이며 `idle`은 무과금이다. 공식 예시 기준으로 런타임은 총비용의 약 14%다(0.08 / 0.58) [1차, 정리자 계산].
3. **보안 기본기.** 볼트 placeholder 주입, 호스트 단위 네트워크 제한, 도구별 권한 정책(`auto` 포함), 예산 상한, 웹훅 기반 모니터링을 제공한다(6장 참조).
4. **기능 추가 속도.** 6개월 동안 메모리, 멀티에이전트, Outcomes, 스케줄, 자체 호스팅 샌드박스, 예산, 워크플로가 추가되었다 [1차].
5. **설계상 내구성.** 세션 로그를 하네스 밖에 두는 구조이며, 엔지니어링 블로그는 p50 TTFT 약 60%, p95 TTFT 90% 이상 개선을 주장한다 [1차, 기준값 비공개].
6. **배포 경로.** 1st-party API와 Claude Platform on AWS(CCU 과금, 기존 AWS 약정 소진에 사용 가능)를 지원한다 [1차].

### 단점 / 리스크

1. **Claude 전용, 데이터 종속.** 세션 이력, 메모리, 오케스트레이션 로직이 Anthropic 플랫폼에 묶인다 [3자 비판 다수].
2. **ZDR/HIPAA BAA 불가** [1차]. AWS 경로도 표준 AWS 컴플라이언스 범위 밖이다.
3. **Batch 할인 없음, 파트너 클라우드(Bedrock/Vertex) 미제공** [1차].
4. **아직 beta.** 동작이 릴리스 사이에 바뀔 수 있다고 공식 문서가 명시하며, 일부 기능은 research preview다. 메모리 헤더 교체(7/2) 같은 API 변경 사례가 이미 있었다 [1차].
5. **비용 예측성.** 토큰이 비용의 대부분이고 에이전트 자율성 때문에 변동 폭이 크다. 세션 예산은 생성 시에만 설정할 수 있고, 요청 하나만큼 초과할 수 있다 [1차].
6. **레이트 리밋.** 조직당 생성 300/분, 읽기 1,200/분이라 대규모 팬아웃 설계 시 고려해야 한다 [1차].

---

## 7.8 미해결 및 확인 필요 항목

- Vertex AI Agent Engine의 현재 vCPU/GiB 단가: 3자 자료끼리 다르고(2026: $0.0864 / $0.009, 2025: $0.0994 / $0.0105) 공식 페이지 확인에 실패했다. Google은 Vertex AI를 "Gemini Enterprise Agent Platform"으로 개편 중이라는 표기가 있다.
- OpenAI AgentKit의 출시일과 별도 요금: 이번 조사에서 1차 자료로 확인하지 못했다. 가격 페이지에는 Agent Builder 별도 요금이 없고, ChatKit 파일 저장 요금($0.10/GB-일, 1GB 무료)만 있다.
- AWS 가이드와 Anthropic 릴리스 노트의 멀티에이전트 지원 여부 불일치(7.5.3).
- 자체 호스팅 샌드박스 사용 시 세션 런타임 요금이 같은지 여부: 가격 페이지에 별도 언급이 없어 `running` 계측이 동일하게 적용되는 것으로 보이지만, 명시적 확인은 하지 못했다.
- 멀티에이전트와 워크플로의 동시 실행 한도: 3자 수치만 존재한다.

---

## 출처

### 1차 (Anthropic / Claude)
- Pricing (Claude Managed Agents pricing 절 포함): https://platform.claude.com/docs/en/about-claude/pricing
- Claude Platform release notes: https://platform.claude.com/docs/en/release-notes/overview
- Claude Managed Agents overview: https://platform.claude.com/docs/en/managed-agents/overview
- Managed Agents reference (rate limits): https://platform.claude.com/docs/en/managed-agents/reference
- Session budgets: https://platform.claude.com/docs/en/managed-agents/budgets
- Dreams (Billing 절): https://platform.claude.com/docs/en/managed-agents/dreams
- API and data retention: https://platform.claude.com/docs/en/manage-claude/api-and-data-retention
- 출시 블로그 "Claude Managed Agents" (2026-04-08): https://claude.com/blog/claude-managed-agents
- 엔지니어링 블로그 "Scaling Managed Agents: Decoupling the brain from the hands" (2026-04-08): https://www.anthropic.com/engineering/managed-agents
- "Built-in memory for Claude Managed Agents" (2026-04-23): https://claude.com/blog/claude-managed-agents-memory
- "New in Claude Managed Agents: dreaming, outcomes, and multiagent orchestration": https://claude.com/blog/new-in-claude-managed-agents
- "New in Claude Managed Agents: self-hosted sandboxes and MCP tunnels" (2026-05-19): https://claude.com/resources/articles/claude-managed-agents-updates
- "New in Claude Managed Agents: run agents on a schedule and store environment variables in vaults" (2026-06-09): https://claude.com/blog/whats-new-in-claude-managed-agents
- "Introducing the Claude Platform on AWS" (2026-05-11): https://claude.com/blog/claude-platform-on-aws

### 1차 (경쟁사 / 파트너)
- AWS Claude Platform 사용자 가이드, Feature support: https://docs.aws.amazon.com/claude-platform/latest/userguide/feature-support.html
- AWS Bedrock AgentCore pricing: https://aws.amazon.com/bedrock/agentcore/pricing/
- OpenAI API pricing (built-in tools, containers): https://developers.openai.com/api/docs/pricing
- Google Agent Builder release notes: https://docs.cloud.google.com/agent-builder/release-notes

### 3자
- VentureBeat, "Anthropic's Claude Managed Agents gives enterprises a new one-stop shop but..." (2026-04-14): https://venturebeat.com/orchestration/anthropics-claude-managed-agents-gives-enterprises-a-new-one-stop-shop-but
- Martin Alderson, "Managed agents are the new Lambda" (2026-05-14): https://martinalderson.com/posts/managed-agents-are-the-new-lambda/
- AIMultiple, AI agent platforms benchmark (2026-05-04, 8/21 갱신): https://aimultiple.com/ai-agent-platforms
- SD Times (2026-05-06): https://sdtimes.com/ai/new-in-claude-managed-agents-dreaming-outcomes-and-multiagent-orchestration/
- 9to5Mac (2026-05-07): https://9to5mac.com/2026/05/07/anthropic-updates-claude-managed-agents-with-three-new-features/
- The Decoder, self-hosted sandboxes and MCP tunnels: https://the-decoder.com/anthropic-adds-self-hosted-sandboxes-and-mcp-tunnels-to-claude-managed-agents/
- InfoQ, Claude MCP tunnels: https://infoq.com/news/2026/05/claude-mcp-tunnels
- Medium (sathishkraju), "Anthropic's Managed Agents: I Read the Fine Print So You Don't Have To" (본문 직접 접근 실패, 검색 요약 기준): https://medium.com/@sathishkraju/anthropics-managed-agents-i-read-the-fine-print-so-you-don-t-have-to-ed17b77e17c5
- pasqualepillitteri.it (4/9 출시 보도): https://pasqualepillitteri.it/en/news/755/anthropic-managed-agents-cowork-ga-april-9-2026
- emergingai substack, "Claude Managed Agents explained": https://emergingai.substack.com/p/claude-managed-agents-explained
- wikidocs, "Claude Managed Agents, Anthropic의 플랫폼 전쟁 선언인가" (본문 직접 접근 실패): https://wikidocs.net/blog/@jaehong/11057/
- fourweekmba, workflows up to 1,000 agents: https://fourweekmba.com/ai-claude-managed-agents-adds-workflows-of-up-to-1000-agents/
- CloudZero, Google Vertex AI pricing: https://www.cloudzero.com/blog/google-vertex-ai-pricing/
- verdent.ai, Claude Managed Agents pricing guide: https://verdent.ai/guides/claude-managed-agents-pricing
