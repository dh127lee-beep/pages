# 2장. 세션과 이벤트 (Sessions & Events)

> 기준일: 2026-10-14 · 대상: Claude Managed Agents (public beta, 2026-04-08~) · 베타 헤더 `anthropic-beta: managed-agents-2026-04-01`
>
> 이 장은 공식 문서(platform.claude.com/docs/en/managed-agents/…)의 세션·이벤트 관련 페이지 8개와 이벤트 타입 카탈로그(reference)를 바탕으로 정리했다. 문서에 없는 내용은 추측해 넣지 않았다.

---

## 2.1 개요: 세션이란

- **세션(session)** 은 환경(environment) 안에서 실행되는 에이전트 인스턴스다. 각 세션은 별도로 만들어 둔 **agent** 와 **environment** 를 참조하고, 여러 번의 상호작용에 걸쳐 대화 기록을 유지한다.
- 수명주기는 두 단계다: **(1) 세션 생성 → (2) user 이벤트 전송으로 작업 시작**. `initial_events` 를 쓰면 두 단계를 한 번의 호출로 합칠 수 있다.
- 세션 자체는 진행 상황을 추적하는 **상태 머신**이고, 실제 실행은 **이벤트**가 이끈다.
- 모든 통신은 이벤트 기반이다. 스트림(SSE)을 열어 세션을 따라가고, 이벤트를 보내 지시하며, 세션이 입력을 기다리며 멈추면 응답한다.

모든 요청에는 공통 헤더가 붙는다.

```bash
-H "x-api-key: $ANTHROPIC_API_KEY" \
-H "anthropic-version: 2023-06-01" \
-H "anthropic-beta: managed-agents-2026-04-01"
```

---

## 2.2 세션 상태(status)

| Status | 의미 |
| --- | --- |
| `idle` | 에이전트가 입력(사용자 메시지, 도구 확인 등)을 기다리는 중. `initial_events` 없이 만든 세션은 `idle` 로 시작한다. workflow run이 열려 있어도 `idle` 일 수 있으므로 `idle` 만으로 작업 완료를 뜻하지는 않는다. |
| `running` | 에이전트가 실행 중. |
| `rescheduling` | 일시적 오류가 발생해 자동으로 재시도 중. |
| `terminated` | 복구할 수 없는 오류 또는 archive로 세션이 종료됨. **작업을 마친 세션은 `terminated` 가 아니라 `idle` 이 된다.** |

멀티에이전트 세션에서 세션 `status` 는 모든 스레드 활동의 집계다. 스레드가 하나라도 `running` 이면 세션도 `running` 이다. 실행 중인 workflow run도 세션을 `running` 으로 유지할 수 있다. 일하는 스레드가 없고 어떤 스레드가 클라이언트를 기다리면 세션은 `idle` 이다.

---

## 2.3 세션 생성

### 2.3.1 기본 생성

`POST /v1/sessions` 에는 `agent` 와 `environment_id` 가 필요하다. `agent` 에 ID 문자열을 넘기면 에이전트의 **최신 버전**으로 세션이 만들어진다.

```bash
curl -fsSL https://api.anthropic.com/v1/sessions \
  -H "x-api-key: $ANTHROPIC_API_KEY" \
  -H "anthropic-version: 2023-06-01" \
  -H "anthropic-beta: managed-agents-2026-04-01" \
  -H "content-type: application/json" \
  -d '{"agent": "'"$AGENT_ID"'", "environment_id": "'"$ENVIRONMENT_ID"'"}'
```

```python
session = client.beta.sessions.create(
    agent=agent.id,
    environment_id=environment.id,
)
```

`initial_events` 없이 생성하면 세션은 등록만 되고 작업은 시작되지 않는다. 다만 **환경의 샌드박스 프로비저닝은 생성 즉시 시작**되므로 첫 도구 호출이 이를 기다리지 않는다.

### 2.3.2 `agent` 파라미터의 세 가지 형태

| 형태 | 예 | 용도 |
| --- | --- | --- |
| ID 문자열 | `"agent": "agent_..."` | 최신 버전 사용 |
| 버전 고정 객체 | `{"type": "agent", "id": "...", "version": 1}` | 특정 버전 고정, 새 버전의 단계적 롤아웃 |
| 오버라이드 객체 | `{"type": "agent_with_overrides", "id": "...", ...}` | 이 세션에서만 설정 일부 변경 |

**오버라이드(`agent_with_overrides`)** 규칙:

- 바꿀 수 있는 필드: `model`, `system`, `tools`, `mcp_servers`, `skills`. `version` 을 생략하면 최신 버전이 기준이 된다.
- **필드 생략** → 에이전트 버전의 값을 상속한다.
- **`null` 또는 빈 배열** → 해당 필드를 비운다. 예외:
  - `model` 은 비울 수 없다(`model: null` → 400 `agent_model_required`).
  - 실효 `skills` 가 비어 있지 않으면 `tools` 를 비울 수 없다(skills에는 `read` 도구가 필요). 400.
  - 실효 `tools` 에 에이전트 서버를 참조하는 `mcp_toolset` 이 남아 있으면 `mcp_servers` 를 비울 수 없다. 400.
- **값 지정** → 병합하지 않고 **전체 교체**한다. `tools` 오버라이드에는 필요한 도구를 모두 나열해야 한다. `model` 오버라이드도 전체 교체이므로 에이전트의 `effort` 가 이어지지 않는다. effort를 원하면 오버라이드의 `model` 안에 `effort` 를 넣는다. 지원하지 않는 레벨은 400이고, `effort` 를 빼면 해당 모델의 기본 effort가 쓰인다.
- 오버라이드는 생성되는 세션에만 적용된다. agent 리소스를 수정하거나 새 버전을 만들지 않는다. 응답의 `agent` 는 오버라이드가 적용된 스냅샷이지만 `id`/`version` 은 기준 에이전트를 가리킨다.
- **inference geo 고정**: `model` 오버라이드에 `inference_geo` 를 넣으면 이 세션의 모델 요청을 해당 지역에 고정한다. 빼면 에이전트의 고정이 해제되고 워크스페이스의 `default_inference_geo` 를 따른다. 값은 생성 시 `allowed_inference_geos` 로 검증된다.

```python
override_session = client.beta.sessions.create(
    agent={
        "type": "agent_with_overrides",
        "id": agent.id,
        "model": {"id": "claude-opus-5-5", "inference_geo": "us"},
        "system": None,  # 이 세션에서만 시스템 프롬프트 제거
    },
    environment_id=environment.id,
)
```

### 2.3.3 `initial_events` 로 생성과 시작을 한 번에

- 생성 시 보낼 이벤트 배열이며 순서대로 처리된다. **최대 50개**.
- 허용 타입은 **`user.message` 와 `user.define_outcome` 뿐**이다. `user.tool_confirmation`, `user.tool_result`, `user.custom_tool_result` 는 응답할 에이전트 턴이 아직 없어서, `user.interrupt` 는 멈출 턴이 없어서 거부된다. 세션의 `initial_events` 는 (scheduled deployment의 `initial_events` 와 달리) `system.message` 도 받지 않는다.
- 비어 있지 않은 목록을 주면 같은 호출에서 에이전트 루프가 시작되고, 세션은 처음부터 **`running`** 상태로 만들어진다. 빈 목록은 필드를 생략한 것과 같다.
- 각 이벤트는 응답이 반환되기 전에 목록 순서대로 검증·저장되고 서버가 ID를 매긴다. 생성 직후 send events 엔드포인트로 보낸 것과 똑같이 처리된다. 검증은 all-or-nothing이라 하나라도 실패하면 세션이 만들어지지 않는다.
- `initial_events` 는 생성 응답에 echo되지 않는다. 확인하려면 이벤트 목록을 조회한다.

| 거부 조건 | Status |
| --- | --- |
| `user.define_outcome` 이 2개 이상 | 400 |
| `rubric` 이 없는 `user.define_outcome` | 400 |
| 목록 전체에서 파일 기반 `document` 블록이 100개 초과 | 400 |
| 요청 본문이 32 MB 초과 | 413 |

```python
seeded = client.beta.sessions.create(
    agent=agent.id,
    environment_id=environment.id,
    initial_events=[
        {
            "type": "user.message",
            "content": [{"type": "text", "text": "List the files in the working directory."}],
        }
    ],
)
```

### 2.3.4 그 밖의 생성 옵션

- **`budget`**: 세션 비용 상한. 생성할 때만 붙일 수 있다(2.11절).
- **`vault_ids`**: 인증이 필요한 MCP 도구를 위해 저장된 OAuth 자격 증명이 든 vault를 참조한다. 토큰 갱신은 Anthropic이 관리한다.

---

## 2.4 이벤트 보내기

`POST /v1/sessions/{session_id}/events` 에 `events` 배열을 보낸다.

```bash
curl --fail-with-body -sS "https://api.anthropic.com/v1/sessions/$SESSION_ID/events?beta=true" \
  -H "x-api-key: $ANTHROPIC_API_KEY" \
  -H "anthropic-version: 2023-06-01" \
  -H "anthropic-beta: managed-agents-2026-04-01" \
  -H "content-type: application/json" \
  -d '{"events": [{"type": "user.message",
       "content": [{"type": "text", "text": "Analyze the performance of the sort function in utils.py"}]}]}'
```

```python
client.beta.sessions.events.send(
    session.id,
    events=[
        {
            "type": "user.message",
            "content": [
                {"type": "text", "text": "Analyze the performance of the sort function in utils.py"}
            ],
        }
    ],
)
```

**`processed_at`**: 세션 기록의 모든 이벤트에는 처리가 끝난 시각인 `processed_at` 이 있다. 사용자가 보낸 이벤트는 앞선 이벤트 뒤에 대기하는 동안 `null` 이다. 예외로 `user.define_outcome`, `user.custom_tool_result`, `user.tool_result` 는 수신 즉시 처리되어 `processed_at` 이 채워진 채로 echo된다.

### 2.4.1 `system.message` (세션 도중 시스템 컨텍스트 추가)

- 지원 모델에서 `system.message` 를 보내면 특권 시스템 수준 컨텍스트를 추가할 수 있다. 함께 보낸 턴과 이후 모든 턴에 적용된다(페르소나 변경, 제약 수정, 런타임에 가져온 컨텍스트 등).
- `content` 에는 텍스트 항목 1–1000개가 들어간다. `role: "system"` 턴으로 덧붙을 뿐 에이전트 정의의 최상위 `system` 을 **대체하지 않는다**.
- 지원 모델: Claude Fable 5.1, Mythos 5.1, Fable 5, Mythos 5, Opus 5.5, Opus 5, Opus 4.8, Sonnet 5.5, Haiku 5.5. 주 모델이 지원하지 않으면 `model_does_not_support_mid_conversation_system` 검증 오류가 난다. `system.message` 는 primary 스레드에만 들어가므로 서브에이전트 모델은 검사하지 않는다.
- 세션이 `requires_action` 으로 idle일 때 `system.message` 는 **같은 요청 안에서 도구 결과 이벤트 뒤에** 와야 한다. 단독으로 보내거나 `user.message` 와 함께 보내면 대기 중인 도구 이벤트가 해결될 때까지 거부된다.

---

## 2.5 이벤트 타입 카탈로그

영속 이벤트 타입은 `{domain}.{action}` 명명 규칙을 따른다. 스트림 전용 event delta(`event_start`, `event_delta`)만 예외다. **웹훅 이벤트 타입은 별도 목록이며 이름이 다를 수 있다**(예: 스트림의 `session.status_idle` ↔ 웹훅의 `session.status_idled`).

### 2.5.1 User events (클라이언트 → 세션)

| Type | 설명 |
| --- | --- |
| `user.message` | 텍스트, 이미지, 문서 콘텐츠를 담은 사용자 메시지. |
| `user.interrupt` | 실행 중인 에이전트를 멈춘다. workflow run은 종료하지 않는다. |
| `user.custom_tool_result` | 에이전트의 custom tool 호출에 대한 응답. |
| `user.tool_confirmation` | permission policy가 확인을 요구할 때 agent/MCP 도구 호출을 허용(`allow`)하거나 거부(`deny`). |
| `user.define_outcome` | 에이전트가 달성할 outcome을 정의. |
| `user.tool_result` | `self_hosted` 환경 세션 전용. `agent_toolset` 결과를 통합 측이 제공한다(SDK 헬퍼와 CLI가 자동 처리). |

### 2.5.2 System events

| Type | 설명 |
| --- | --- |
| `system.message` | 함께 보낸 턴과 이후 모든 턴에 적용되는 특권 시스템 컨텍스트를 추가한다. 미지원 주 모델에서는 `model_does_not_support_mid_conversation_system` 으로 거부된다. |

### 2.5.3 Agent events (세션 → 클라이언트)

| Type | 설명 |
| --- | --- |
| `agent.message` | 에이전트 응답 content block. |
| `agent.thinking` | extended thinking으로 진행 중임을 알리는 신호. thinking 내용은 담지 않는다. |
| `agent.tool_use` | 내장 agent tool(bash, 파일 작업 등) 호출. `evaluated_permission` 과 보통 `evaluation` 을 포함한다. |
| `agent.tool_result` | 내장 도구 실행 결과. |
| `agent.mcp_tool_use` | MCP 서버 도구 호출. `evaluated_permission`, 보통 `evaluation` 포함. |
| `agent.mcp_tool_result` | MCP 도구 실행 결과. |
| `agent.custom_tool_use` | 사용자 custom tool 호출. `user.custom_tool_result` 로 응답해야 한다. |
| `agent.thread_context_compacted` | 컨텍스트 창에 맞추려고 대화 기록이 압축(compaction)됨. |
| `agent.thread_message_received` | 멀티에이전트에서 다른 스레드의 메시지가 이 스트림의 스레드에 도착함. |
| `agent.thread_message_sent` | 멀티에이전트에서 이 스트림의 스레드가 다른 스레드로 메시지를 보냄. |

메시지 콘텐츠에는 Anthropic 모델 정책으로 숨겨진 내용을 대신하는 `{"type": "redacted"}` 블록이 들어갈 수 있다. 플랫폼이 내보내는 콘텐츠에만 나타나며, user 이벤트에 넣으면 400이다.

### 2.5.4 Session events

| Type | 설명 |
| --- | --- |
| `session.status_running` | 에이전트가 처리 중. |
| `session.status_idle` | 현재 작업을 마치고 입력 대기 중. `stop_reason` 포함. |
| `session.status_rescheduled` | 일시적 오류로 자동 재시도 중. |
| `session.status_terminated` | 복구 불가 오류 또는 archive로 종료됨. |
| `session.deleted` | 세션 삭제됨. 활성 스트림이 끊기고 이후 이벤트는 없다. |
| `session.updated` | 업데이트 요청으로 하나 이상의 필드가 바뀜. 바뀐 필드만 담는다. 변경은 다음 턴부터 적용된다. |
| `session.error` | 처리 중 오류. `retry_status` 가 든 typed `error` 객체를 포함한다. |
| `session.usage` | 누적 사용량과 추적된 list cost의 스냅샷. 예산이 있으면 `budget` 도 담는다. |
| `session.thread_created` | 멀티에이전트 스레드 생성. `workflow_run_id`(run 스레드가 아니면 `null`) 포함. |
| `session.thread_status_running` | 세션 스레드가 실행을 시작함. 모든 세션은 primary 스레드에 대해 이 이벤트를 보내고, 자식 스레드의 전이도 primary 스트림에 교차 게시된다. |
| `session.thread_status_idle` | 스레드가 턴을 마치고 입력 대기. `stop_reason` 포함. |
| `session.thread_status_rescheduled` | 스레드가 일시적 오류로 자동 재시도 중. |
| `session.thread_status_terminated` | 스레드가 종료되어 더 이상 입력을 받지 않음(archive, 복구 불가 오류, advisor 상담 종료 등). |

dynamic workflows가 켜진 세션에서는 `workflow_run.*` 이벤트(`workflow_run.created`, `.status_running`, `.status_idle`, `.status_ended`, `.error`, `.phase_started`, `.phase_ended`)도 세션 스트림에 온다. 자세한 내용은 workflow runs 문서에 있다.

### 2.5.5 Span events (관측용 마커)

| Type | 설명 |
| --- | --- |
| `span.model_request_start` | 모델 추론 호출 시작. |
| `span.model_request_end` | 모델 추론 호출 완료. 토큰 수가 든 `model_usage` 포함. |
| `span.outcome_evaluation_start` | outcome 평가 시작. |
| `span.outcome_evaluation_ongoing` | outcome 평가 진행 중 heartbeat. |
| `span.outcome_evaluation_end` | outcome 평가 사이클 완료. `needs_revision` 이면 다음 사이클이 이어지고, `satisfied`, `max_iterations_reached`, `failed`, `interrupted` 는 종결 결과다. |

### 2.5.6 Event deltas (스트림 전용, 영속 안 됨)

| Type | 설명 |
| --- | --- |
| `event_start` | 미리보기 대상 이벤트의 생성이 시작됨. 다가올 이벤트의 `type` 과 `id` 를 담는다. |
| `event_delta` | 미리보기 이벤트의 증분 콘텐츠. `event_id` 로 대상을 식별한다. |

---

## 2.6 SSE 스트리밍

### 2.6.1 스트림 열기

- 세션 단위 스트림: `GET /v1/sessions/{session_id}/events/stream` (`accept: text/event-stream`)
- 스트림은 **열린 뒤에 발생한 이벤트만** 전달한다. 경쟁 상태를 피하려면 **이벤트를 보내기 전에 스트림을 먼저 연다.**
- 응답 텍스트는 버퍼링된 `agent.message` 이벤트로 오며, 각 이벤트는 그것을 만든 모델 요청이 끝난 뒤에 나온다. 생성 중인 텍스트를 보려면 event delta(2.7절)를 쓴다.
- 오류는 `session.error` 이벤트로 보고된다.

```python
# 스트림을 먼저 열고, 그다음 메시지를 보낸다
with client.beta.sessions.events.stream(session.id) as stream:
    client.beta.sessions.events.send(
        session.id,
        events=[
            {
                "type": "user.message",
                "content": [{"type": "text", "text": "Summarize the repo README"}],
            }
        ],
    )
    for event in stream:
        match event.type:
            case "agent.message":
                for block in event.content:
                    if block.type == "text":
                        print(block.text, end="")
            case "session.status_idle":
                break
            case "session.error":
                print(f"\n[Error: {event.error.message if event.error else 'unknown'}]")
                break
```

### 2.6.2 재연결(이벤트 누락 없이)

문서가 권장하는 절차:

1. 새 스트림을 연다(연 시점부터 버퍼링된다).
2. 전체 이벤트 기록을 조회해 이미 본 이벤트 ID 집합을 만든다.
3. 라이브 스트림을 tail하면서 기록에 있던 이벤트는 건너뛴다.

```python
with client.beta.sessions.events.stream(session.id) as stream:
    seen = {e.id for e in client.beta.sessions.events.list(session.id)}
    for event in stream:
        if event.type in ("event_start", "event_delta"):
            continue  # 이 연결은 delta 미리보기를 켜지 않았다
        if event.id in seen:
            continue
        seen.add(event.id)
        ...
```

일시정지된 세션에 재연결했다면 가장 최근 `session.status_idle` 의 `stop_reason.event_ids` 가 응답해야 할 호출 목록이다.

### 2.6.3 이벤트 기록 조회

- `GET /v1/sessions/{session_id}/events` 로 세션의 전체 이벤트 기록을 가져온다.
- `types[]` 필터로 특정 타입만 조회할 수 있다(SDK: `types=[...]`, CLI: `--type`).

```bash
curl --fail-with-body -sS \
  "https://api.anthropic.com/v1/sessions/$SESSION_ID/events?beta=true&types[]=agent.tool_use&types[]=agent.tool_result" \
  -H "x-api-key: $ANTHROPIC_API_KEY" \
  -H "anthropic-version: 2023-06-01" \
  -H "anthropic-beta: managed-agents-2026-04-01"
```

---

## 2.7 Event deltas (응답 텍스트 실시간 미리보기)

- 기본적으로 응답 텍스트는 버퍼링된 `agent.message` 로만 온다. event delta를 켜면 모델이 생성하는 동안 텍스트를 점진적으로 렌더링할 수 있다.
- 미리보기는 **best-effort 표시 보조 수단**이고 **권위 있는 기록은 항상 버퍼링된 `agent.message`** 다. 미리보기를 무시해도 완전하고 올바른 스트림을 받는다.

### 2.7.1 Opt-in

- **스트림 연결마다** `event_deltas[]` 쿼리 파라미터를 붙이고, 미리볼 타입마다 반복한다. 허용 값은 `agent.message`, `agent.thinking` 뿐이다. 다른 값이나 100개를 넘는 값은 400이다.
- 두 스트림 엔드포인트가 모두 지원한다: `GET /v1/sessions/{id}/events/stream`, `GET /v1/sessions/{id}/threads/{thread_id}/stream`.
- `[]` 는 셸 glob이므로 URL을 따옴표로 감싸거나 `%5B%5D` 로 인코딩한다.

### 2.7.2 와이어 포맷

```json
{"type": "event_start", "event": {"type": "agent.message", "id": "sevt_01abc..."}}
{"type": "event_delta", "event_id": "sevt_01abc...",
 "delta": {"type": "content_delta", "index": 0, "content": {"type": "text", "text": "Here is the summary"}}}
```

- `agent.thinking` 은 `event_start` 만 나오고 `event_delta` 는 오지 않는다. 이후 오는 버퍼링된 `agent.thinking` 에도 thinking 내용은 없다.
- `event_start`/`event_delta` 에는 자체 `id` 나 `processed_at` 이 없다. 미리보는 이벤트의 `id` 만 담는다.
- Messages API 스트리밍과 포맷이 **의도적으로 다르다**: 블록별 start/stop 이벤트가 없고, 미리보는 이벤트의 stop 이벤트도 없으며, delta 타입은 `content_block_delta` 가 아니라 `content_delta` 다. Messages API용 accumulator 코드는 그대로 쓸 수 없다.

### 2.7.3 누적과 조정(reconcile)

턴은 `session.status_running` 하나로 시작한다. 정상 완료되는 턴에서 모델 요청마다 다음 순서로 이벤트가 나온다: `span.model_request_start` → `event_start` → `event_delta`들 → 버퍼링된 `agent.message` → `span.model_request_end`.

1. `event_start` 에서 `id` 를 기록한다. `event_start.event.id`, 모든 `event_delta.event_id`, 버퍼링된 `agent.message.id` 는 같은 값이다.
2. `event_delta` 마다 `(event_id, delta.index)` 키에 `delta.content.text` 를 이어 붙여 렌더링한다.
3. 버퍼링된 `agent.message` 가 오면 `id` 로 맞춘 뒤 미리보기를 버리고 메시지 콘텐츠를 렌더링한다.
4. `span.model_request_end` 에서는 조정되지 않은 미리보기를 닫는다. 오류나 interrupt로 버퍼 이벤트가 오지 않을 수 있지만 `span.model_request_end` 는 온다.

보장 사항: 도착 순서대로 이어 붙인 delta는 버퍼 이벤트 `content[index].text` 의 **prefix**다(부하 시 shedding으로 전체가 아닐 수 있다). 한 연결은 `event_id` 당 `event_start` 를 최대 한 번 보내며, 그 `id` 에 대해 마지막으로 전달하는 것은 버퍼 이벤트다.

SDK에는 accumulator 헬퍼가 있다(Python 예: `accumulate_managed_agents_event`). Go/Java/Ruby/C# 헬퍼는 `id` 별 키잉까지 처리하고, Python/TypeScript/PHP는 `id` 별 맵을 직접 관리해야 한다.

```python
previews = {}
with client.beta.sessions.events.stream(session.id, event_deltas=["agent.message"]) as stream:
    for event in stream:
        match event.type:
            case "event_start":
                snap = accumulate_managed_agents_event(None, event)
                if snap is not None:
                    previews[event.event.id] = snap
            case "event_delta":
                p = accumulate_managed_agents_event(previews.get(event.event_id), event)
                if p is not None:
                    previews[event.event_id] = p
            case "agent.message":
                final = accumulate_managed_agents_event(previews.pop(event.id, None), event)
            case "span.model_request_end":
                previews.clear()
```

### 2.7.4 제약

- **Best effort**: 부하가 높으면 delta가 버려질 수 있다. 그러면 연속된 prefix까지만 받고 그 이벤트의 delta는 더 오지 않는다. 미리보기를 최종본으로 취급하면 안 된다.
- **재연결 시 재생 없음**: delta는 opt-in한 연결이 열려 있는 동안에만 전달된다. 모델 요청이 시작된 뒤에 연 연결은 진행 중인 이벤트의 delta를 받지 못하고, 다시 요청할 방법도 없다.
- **한 스레드, 텍스트만**: 읽고 있는 스레드의 assistant 텍스트만 미리보기된다. 도구 호출·결과·MCP 결과는 미리보기 대상이 아니다.
- **영속되지 않음**: 세션 기록과 스레드 기록 어디에도 나타나지 않는다.

트러블슈팅: delta가 안 보이면 해당 연결이 opt-in하지 않았거나 그 스레드가 턴을 돌지 않은 경우다. 스트림 URL에서 404가 나면 경로나 ID가 틀렸거나 베타 헤더가 없는 경우다(thread 엔드포인트는 베타 게이트). `event_deltas` 를 언급하는 400은 허용되지 않은 값을 넣은 경우다.

---

## 2.8 Steering: idle 응답, 도구 호출 응답, interrupt, 재개

### 2.8.1 `session.status_idle` 의 `stop_reason.type`

| `stop_reason.type` | 원인 | 대응 |
| --- | --- | --- |
| `end_turn` | 에이전트가 턴을 끝냈거나 interrupt됨 | 추가 작업이 있으면 `user.message` 전송 |
| `requires_action` | custom tool 호출이나 확인 요청 등에 응답이 필요함 | 블로킹된 각 호출에 응답 |
| `budget_reached` | 추적 list cost가 예산에 도달함 | 예산 변경 또는 제거(보내는 이벤트로는 재개되지 않음) |

### 2.8.2 일시정지시키는 도구 호출에 응답

1. 세션이 도구 호출을 `agent.custom_tool_use` / `agent.tool_use` / `agent.mcp_tool_use` 로 내보낸다.
2. `stop_reason.type = requires_action` 인 `session.status_idle` 로 멈춘다. 블로킹 이벤트 ID는 `stop_reason.event_ids` 에 있다.
3. 각 ID에 대해 `user.custom_tool_result`(`custom_tool_use_id`) 또는 `user.tool_confirmation`(`tool_use_id`, `result: "allow" | "deny"`)을 보낸다.
4. 블로킹 이벤트가 모두 해결되면 세션이 `running` 으로 돌아간다.

- custom tool 결과는 `agent.custom_tool_use` 가 도착하자마자 보내도 된다(idle을 기다릴 필요 없음). 같은 호출에 결과를 두 번 보내면 받아들여지지만 효과는 없다.
- workflow run이 열려 있으면 세션이 `running` 인 채로 도구 호출이 대기할 수 있다. 이때는 idle을 기다리지 말고, `agent.custom_tool_use` 가 오거나 `evaluated_permission` 이 `ask` 인 `agent.tool_use`/`agent.mcp_tool_use` 가 올 때마다 응답한다.

```python
client.beta.sessions.events.send(
    session.id,
    events=[
        {"type": "user.tool_confirmation", "tool_use_id": event_id, "result": "allow"},
    ],
)
```

### 2.8.3 Interrupt와 방향 전환

`user.interrupt` 를 보내고 이어서 `user.message` 로 방향을 바꾼다.

```python
client.beta.sessions.events.send(
    session.id,
    events=[
        {"type": "user.interrupt"},
        {
            "type": "user.message",
            "content": [{"type": "text", "text": "Instead, focus on fixing the bug in line 42."}],
        },
    ],
)
```

호출은 이벤트가 큐에 들어가면 바로 반환되고, interrupt는 다음 순서로 적용된다.

1. 에이전트가 interrupt를 적용한다. 그전까지 interrupt의 `processed_at` 은 `null`, 세션은 `running` 이다. 진행 중인 모델 응답은 즉시 멈추지만 도구 호출이 실행 중이면 더 걸릴 수 있다.
2. `user.interrupt` 가 스트림에 나타나고, 중단된 턴은 `session.status_idle`(`stop_reason.type = end_turn`)로 끝난다.
3. interrupt 뒤에 보낸 `user.message` 로 다음 턴이 시작된다.

workflow run은 interrupt로 끝나지 않는다. 실행 중인 run이 세션을 `running` 으로 유지하면 2단계의 idle 이벤트가 오지 않을 수 있다.

### 2.8.4 Idle 세션 재개와 샌드박스 보존

- 세션은 상호작용 사이에도 유지된다. 재개하려면 `user.message` 를 다시 보내면 된다.
- 대화 기록은 명시적으로 삭제하지 않는 한 보존된다. 세션이 idle이 되면 샌드박스가 **체크포인트**된다(파일시스템, 설치한 패키지, 에이전트가 만든 파일 포함).
- **샌드박스 상태는 샌드박스 생성 후 30일 동안만 보존**되며 활동해도 기간이 늘지 않는다. 30일이 지나면 복구할 수 없고, 재개한 세션은 새 샌드박스에서 시작한다. 중요한 산출물은 outputs에 쓰도록 해야 한다.

---

## 2.9 세션 운영 (Session operations)

| 작업 | 엔드포인트 | Python SDK |
| --- | --- | --- |
| 조회 | `GET /v1/sessions/{id}` | `client.beta.sessions.retrieve(id)` |
| 목록 | `GET /v1/sessions` | `client.beta.sessions.list(...)` |
| 업데이트 | `POST /v1/sessions/{id}` | `client.beta.sessions.update(id, ...)` |
| 아카이브 | `POST /v1/sessions/{id}/archive` | `client.beta.sessions.archive(id)` |
| 삭제 | `DELETE /v1/sessions/{id}` | `client.beta.sessions.delete(id)` |

### 2.9.1 목록과 페이지네이션

- `limit` 로 페이지 크기를 정한다. 응답의 `next_page` 커서를 다음 요청의 `page` 로 넘긴다(마지막이면 `null`). 뒤로 가려면 `prev_page` 를 `page` 로 넘긴다(첫 페이지면 `null`).
- `order` 는 생성 시각 기준 `asc`/`desc` 이고 기본값은 `desc`(최신순)다. 커서는 불투명하며 `order` 를 인코딩한다. 다른 `order` 로 재사용하거나 `created_at` 필터를 커서 위치가 빠지도록 바꾸면 400이다. 다른 필터(`agent_id` 등)와 `limit` 는 바꿔도 된다.

```python
first = client.beta.sessions.list(limit=1, agent_id=agent.id)
second = client.beta.sessions.list(limit=1, agent_id=agent.id, page=first.next_page)
```

### 2.9.2 세션 중 에이전트 설정 변경

- 세션 생성 후 바꿀 수 있는 것은 `agent.tools` 와 `agent.mcp_servers` 뿐이다(permission policy, `allowed_domains`/`blocked_domains` 같은 도구별 웹 설정 포함). 새 에이전트 버전을 만들지 않고 세션 안에서만 적용된다.
- `model`, `system`, `skills`, `inference_geo` 는 세션 중에 바꿀 수 없다. 생성 시 오버라이드를 써야 한다. 시스템 수준 지시를 추가하려면 `system.message` 를 쓴다.
- 의미는 **전체 교체**다. 기존 항목을 유지하려면 GET → 배열 수정 → POST 한다.
- 세션이 **`idle`** 이어야 한다. 실행 중이면 `user.interrupt` 만 단독으로 보내고 idle을 기다린다. workflow run이 열려 있으면(running이든 paused든) idle이어도 400이다.

```python
client.beta.sessions.update(
    session.id,
    agent={
        "tools": [
            {"type": "agent_toolset_20260401"},
            {"type": "mcp_toolset", "mcp_server_name": "linear"},
        ],
        "mcp_servers": [{"type": "url", "name": "linear", "url": "https://mcp.linear.app/sse"}],
    },
)
```

### 2.9.3 아카이브

- 기록은 보존하면서 새 이벤트를 받지 않게 한다. 세션은 `terminated` 가 된다.
- `running` 세션은 아카이브할 수 없다. `user.interrupt` 를 단독으로 보내고 idle을 기다린 뒤 아카이브한다.
- workflow run이 열려 있으면 400이 나거나, 성공하면서 run이 끝날 수 있다. 먼저 run을 멈추라고 요청하거나 끝나기를 기다린다.

### 2.9.4 삭제

- 세션 레코드, 이벤트, 연결된 샌드박스를 **영구 삭제**한다. `running` 이면 삭제할 수 없다(interrupt 후 idle 대기).
- workflow run이 열려 있으면 400이 나거나 성공할 수 있다. 성공해도 run 종료를 알리는 `workflow_run` 이벤트는 없다.
- memory store, vault, skill, environment, agent는 독립 리소스라 영향이 없다. Files API로 올린 파일도 영향이 없다. 반면 **세션이 만든 파일은 세션 범위라 함께 영구 삭제**되므로 먼저 내려받아야 한다. 마지막 턴에 쓴 출력 파일은 idle 이후 몇 초가 지나야 세션 파일 목록에 나타날 수 있다.

---

## 2.10 세션 스레드 (멀티에이전트)

### 2.10.1 개념

- 멀티에이전트 세션에서 각 에이전트는 자신의 **session thread** 에서 일한다. workflow run도 스레드를 만든다.
- 세션 단위 스트림(`/v1/sessions/{id}/events/stream`)이 **primary thread** 다. 모든 스레드 활동의 요약 뷰로, 서브에이전트의 전체 활동은 보이지 않지만 작업의 시작·종료와 도구 권한 요청 같은 블로킹 이벤트는 보인다.
- 세션당 동시 **자식 스레드는 최대 25개**다. idle 스레드도 archive하기 전까지 집계되고 primary는 세지 않는다. advisor 상담 스레드와 workflow run 스레드는 이 한도에서 제외된다.
- 세션 예산은 모든 스레드가 공유하는 단일 상한이다.

### 2.10.2 스레드 API

| 작업 | 엔드포인트 |
| --- | --- |
| 목록 | `GET /v1/sessions/{id}/threads` (`statuses[]` 필터 반복 가능) |
| 스트림 | `GET /v1/sessions/{id}/threads/{thread_id}/stream` (`/threads/{id}/events/stream` 은 **없다**) |
| 이벤트 기록 | `GET /v1/sessions/{id}/threads/{thread_id}/events` |
| 아카이브 | `POST /v1/sessions/{id}/threads/{thread_id}/archive` |

- 목록에는 primary가 포함되며 primary의 `parent_thread_id` 는 `null` 이다. `workflow_run_id` 는 run 스레드에만 값이 있다.
- **Interrupt**: `user.interrupt` 에 `session_thread_id` 를 지정하면 그 스레드만 멈춘다. 생략하면 primary를 포함해 archive되지 않은 모든 스레드가 interrupt된다. `requires_action` 으로 막힌 서브에이전트 스레드는 대기 중인 도구 호출이 오류 결과("Tool execution was interrupted before completion. Please retry.")로 닫히고 `end_turn` 으로 다시 idle이 된다(모델 샘플링 없음). `end_turn`/`budget_reached` 로 idle인 자식에게는 no-op이고, terminated 스레드를 지정하면 400이다.
- **Archive**: 스레드가 `idle` 일 때만 성공한다(`requires_action` 대기 상태도 idle로 본다). 25개 한도 자리가 비워진다. run 스레드는 서버가 직접 archive하며, run이 열려 있는 동안에는 직접 archive할 수 없다.
- 스레드 스트림은 이전 이벤트를 재생하지 않는다. 스트림을 먼저 열고 이벤트 목록을 조회한 뒤 중복 `id` 를 건너뛴다.

```python
client.beta.sessions.events.send(
    session.id, events=[{"type": "user.interrupt", "session_thread_id": thread.id}]
)
archived = client.beta.sessions.threads.archive(thread.id, session_id=session.id)
```

### 2.10.3 Primary 스레드에 나타나는 이벤트

| Type | 설명 |
| --- | --- |
| `session.thread_created` | 스레드 생성(`session_thread_id`, `agent_name`) |
| `session.thread_status_running` | 스레드 활동 시작 |
| `session.thread_status_idle` | 스레드가 입력 대기(`stop_reason`) |
| `session.thread_status_terminated` | 스레드 종료 |
| `agent.thread_message_received` | 서브에이전트가 primary 에이전트에게 보고나 질문을 보냄(`from_session_thread_id`, `from_agent_name`, `content`) |
| `agent.thread_message_sent` | primary 에이전트가 서브에이전트에게 작업을 보냄(`to_session_thread_id`, `to_agent_name`, `content`) |

advisor 상담은 예약된 이름 `anthropic.advisor` 로 같은 이벤트를 내보낸다.

### 2.10.4 스레드 간 도구 권한과 custom tool

- 서브에이전트에 권한 확인이나 custom tool 결과가 필요하면 해당 이벤트가 `session_thread_id` 와 함께 **primary 스레드에 교차 게시**된다. 권한이 필요한 경우는 `always_ask` 정책이거나, `auto` 정책에서 서버가 판단을 내리지 못했을 때다.
- 응답은 primary에 보내면 서버가 올바른 스레드로 라우팅한다. 두 스트림의 사본은 `id` 가 다를 수 있으므로 `type` 과 `tool_use_id`/`custom_tool_use_id` 로 맞춘다.
- primary 스트림에서 서브에이전트의 `session.thread_status_idle` 이 그 `event_ids` 가 가리키는 `agent.tool_use` 보다 먼저 올 수 있고, 아직 도착하지 않은 호출에 확인을 보내면 400이 날 수 있다. `evaluated_permission` 이 `ask` 인 이벤트가 도착할 때 응답하는 편이 안전하다.
- `auto` 에서 서버가 거부한 호출은 교차 게시되지 않고 서브에이전트 자신의 스레드 스트림에만 나타난다.

```json
{"type": "session.thread_status_idle", "id": "sevt_01ABC...",
 "session_thread_id": "sthr_01DEF...", "agent_name": "code-reviewer",
 "stop_reason": {"type": "requires_action", "event_ids": ["sevt_01XYZ..."]}}
```

---

## 2.11 세션 예산 (Budgets)

> 문서상 Managed Agents의 세션 예산은 **달러(list cost) 상한 하나뿐**이다. 별도의 토큰 수 상한이나 시간 상한 필드는 없다. 실행 시간은 시간당 요금으로 list cost에 합산될 뿐이다. 또한 이 예산은 Messages API의 advisory 토큰 기반 "task budgets"와는 다른 기능이다.

### 2.11.1 설정

```json
"budget": {"type": "limit", "max_list_cost": {"amount": "125", "currency": "USD"}}
```

- `type` 은 항상 `"limit"` 이다.
- `amount` 는 **US 센트 정수를 문자열**로 쓴다(앞자리 0 없음, 0보다 커야 함). `"125"` = $1.25이고 `"25.00"` 같은 소수 표기는 거부된다. 부동소수점 반올림을 피하려고 문자열을 쓴다.
- `currency` 는 대문자 ISO-4217 코드이며 현재 `USD` 만 지원한다.
- **세션 생성 시에만 붙일 수 있다.** 예산 없이 만든 세션에 나중에 추가하면 400이다.

### 2.11.2 list cost 산정

| 항목 | 단가 |
| --- | --- |
| 모델 토큰 | 실제로 서빙된 모델의 list price |
| 웹 검색 | 1,000회당 $10 USD |
| 세션 실행 시간 | 시간당 $0.08 USD |

계약 할인과 무관하게 public list rate로 계산하므로 실제 청구액은 상한보다 낮을 수 있다. 집행에는 반올림하지 않은 정확한 값을 쓰고, 보고되는 `list_cost` 는 센트 단위로 반올림된다(±0.5센트).

### 2.11.3 상한 도달 시 동작

- 상한은 모델 요청 **사이에** 집행된다. 상한을 넘긴 요청은 끝까지 실행되므로 최종 `list_cost` 가 상한을 약간 넘을 수 있다(예: `"50"` 상한에서 `"53"`에 멈춤). 초과분은 스레드당 모델 요청 1회 비용 이내이고, 그 응답에 든 도구 호출은 여전히 실행된다.
- 세션은 종료되지 않고 `stop_reason = budget_reached` 로 **idle** 이 된다. 기록과 샌드박스는 보존된다.
- 스트림에 나타나는 순서: 각 스레드의 `session.thread_status_idle`(`budget_reached`) → `session.usage` → `session.status_idle`(`budget_reached`). 열린 workflow run이 있으면 `workflow_run.status_idle` 도 나온다.
- 상한에 걸린 동안 받는 이벤트는 진행 중인 작업을 정리하는 것뿐이다: `user.tool_confirmation`, `user.tool_result`, `user.custom_tool_result`, `user.interrupt`. `user.message` 등 새 작업을 시작하는 이벤트는 400이다. 이때 보낸 `user.interrupt` 는 받아들여지지만 이벤트 목록에 나타나지 않으며 아무 스레드도 멈추지 않는다.

### 2.11.4 재개: 변경 또는 제거

- `POST /v1/sessions/{id}` 로 예산을 업데이트하면 예산 때문에 멈춘 작업이 **자동으로 재개**된다. 클라이언트가 따로 할 일은 없다.
- 새 상한은 **현재 소비한 list cost보다 엄격히 커야** 한다. 아니면 400(`budget.max_list_cost must be greater than the session's consumed list cost`). 이전 상한이 아니라 보고된 `usage.list_cost` 보다 1센트 이상 높게 잡는다.
- `"budget": null` 로 제거할 수 있다. **제거는 일방향**이라 다시 추가할 수 없다.
- interrupt로 멈춘 workflow run은 예산을 바꿔도 재개되지 않는다. `user.message` 로 계속하라고 요청해야 한다.

```python
client.beta.sessions.update(
    session.id, budget={"type": "limit", "max_list_cost": {"amount": "500", "currency": "USD"}}
)
client.beta.sessions.update(session.id, budget=None)  # 제거 (되돌릴 수 없음)
```

### 2.11.5 멀티에이전트, 배포, 가격 미공개 모델

- 멀티에이전트 세션은 모든 스레드가 하나의 예산을 공유한다(스레드별 상한 없음). 각 스레드는 자기 모델 단가로 계산되고 독립적으로 멈춘다. advisor 비용도 같은 예산에 포함된다. 한 스레드가 `requires_action`, 다른 스레드가 `budget_reached` 면 세션 수준은 `requires_action` 이다(대기 중인 요청이 상한보다 우선).
- **Deployment** 도 같은 `budget` 객체를 받는다. 상한은 deployment가 시작하는 각 세션에 복사되므로 실행 1회 단위로 적용된다. 변경은 이후 시작하는 세션에만 반영된다. 세션과 달리 deployment 예산은 `null` 로 지운 뒤 다시 설정할 수 있다.
- 에이전트나 subagents/workflows의 `predefined_agents`, advisor 중 하나라도 public list price가 없는 모델을 쓰면 예산이 있는 세션 생성이 400이다. 세션 도중 그런 모델 사용이 생기면 `budget_reached` 로 멈출 수 있고 예산 변경은 거부되므로 예산을 제거해야 재개된다.

---

## 2.12 관측성과 사용량 추적

### 2.12.1 Console 세션 뷰어

- Developer와 Admin만 접근할 수 있다. Console 사이드바 **Managed Agents → Sessions** 에서 워크스페이스의 모든 세션(상태, 에이전트, 토큰 사용량, 비용, 생성 시각)을 본다.
- **Timeline minimap**(멀티에이전트면 스레드별 lane), **Transcript**(모델 요청 단위로 그룹화, JSON 복사·다운로드), **Inspector**(5개 탭)로 구성된다.

| Inspector 탭 | 내용 |
| --- | --- |
| Session | 세부 정보, 메타데이터, 누적 비용 추이, 예산 대비 지출 |
| Events | 현재 스레드의 raw 이벤트(JSON). 페이지가 열린 동안 스트리밍된 메시지는 **Deltas** 뷰 제공 |
| Tools | 설정된 도구별 호출 수, 실패 수, 소요 시간 중앙값 |
| Resources | 마운트된 파일·저장소·memory store(이번 세션의 변경 포함), `/mnt/session/outputs` 산출물, skills |
| Threads | 스레드별 상태, 컨텍스트 크기, 비용 |

세션 URL에 `?event={event_id}` 를 붙이면 해당 이벤트로 바로 간다. CLI에서는 `ant beta:sessions connect` 로 같은 뷰어를 열거나 터미널에서 세션을 따라갈 수 있다.

### 2.12.2 `usage` 필드

```json
"usage": {
  "input_tokens": 5000, "output_tokens": 3200, "cache_read_input_tokens": 20000,
  "cache_creation": {"ephemeral_5m_input_tokens": 2000, "ephemeral_1h_input_tokens": 0},
  "list_cost": {"amount": "187", "currency": "USD"},
  "active_seconds": 342.5,
  "server_tool_use": {"web_search_requests": 3, "web_fetch_requests": 0}
}
```

| 필드 | 설명 |
| --- | --- |
| `input_tokens` | 세션 전체 모델 호출의 비캐시 입력 토큰 |
| `output_tokens` | 전체 출력 토큰 |
| `cache_read_input_tokens` | 프롬프트 캐시에서 읽은 토큰 |
| `cache_creation` | 캐시 생성 토큰(5분/1시간 TTL별) |
| `list_cost` | public list rate 기준 누적 비용(센트 정수 문자열과 통화) |
| `active_seconds` | 스레드가 하나 이상 실행 중이던 누적 시간. 동시 실행은 한 번만 센다. 런타임 비용의 기준 |
| `server_tool_use` | 서버 실행 도구 요청 수. 웹 검색은 요청당 과금되고, web fetch는 과금·계측하지 않아 `0` |

- 최신 합계는 세션이 idle이 된 뒤 조회한다. 캐시 TTL 기본값은 5분이다.
- 세션 `stats.active_seconds` 는 스레드별 활동 시간을 단순 합산한 값이다(중복 포함).
- 스레드별 `usage` 에도 `list_cost`, `active_seconds` 가 있다. 각각 따로 반올림되고 런타임 비용을 제외하므로 합이 세션 값과 정확히 맞지 않는다. 권위 있는 값은 세션 수치다.
- **`session.usage` 이벤트**는 같은 누적 스냅샷(`usage` 와 예산이 있으면 `budget`)을 스트림과 기록에 남긴다. 타이머가 아니라 idle 전이 때 나온다: idle 직전(stop reason 무관)과 스레드가 예산 때문에 멈출 때.
- 지출을 제한하려면 사용량을 폴링해 직접 멈추지 말고 세션 예산을 쓰라는 것이 문서의 권장이다.

디버깅 팁: `session.error` 이벤트를 확인하고, Tools 탭에서 도구 실패를 보고, 시스템 프롬프트에 로깅 지시를 넣고, 미리보기 문제는 event delta 트러블슈팅 표를 참고한다.

---

## 2.13 웹훅 (Webhooks)

SSE 스트림이 실시간 상호작용용이라면 웹훅은 **주요 상태 변화 알림**용이다. 웹훅 페이로드에는 이벤트 `type` 과 `id` 만 있고 전체 객체는 없으므로 받은 뒤 `GET` 으로 조회한다. 재시도 때 오래된 데이터를 보내지 않고 전송 크기를 작게 유지하기 위한 설계다.

### 2.13.1 지원 이벤트 타입

**Session events** (스트림 이벤트와 이름이 다를 수 있음)

| Event | 트리거 |
| --- | --- |
| `session.status_run_started` | `running` 으로 전이할 때마다 (스트림의 `session.status_running` 에 해당) |
| `session.status_idled` | 입력 대기 (스트림의 `session.status_idle` 에 해당) |
| `session.budget_reached` | 예산 도달로 일시정지. 설정한 예산 값마다 최대 1회 발생하고, 예산을 바꾸면 다시 활성화된다 |
| `session.status_rescheduled` | 일시적 오류로 자동 재시도 |
| `session.status_terminated` | 복구 불가 오류 또는 archive로 종료 |
| `session.thread_created` | 멀티에이전트 스레드 생성(advisor 상담, workflow run 스레드 포함) |
| `session.thread_idled` | 멀티에이전트 스레드 입력 대기 |
| `session.thread_terminated` | 자식 스레드 종료(archive 또는 재시도 소진). primary의 종료는 `session.status_terminated` 로만 나타난다 |
| `session.outcome_evaluation_ended` | outcome 평가 1회 반복 완료 |
| `session.updated` | 세션 속성 변경 |
| `session.deleted` | 영구 삭제. 조회할 객체가 없으니 이벤트 자체를 최종으로 처리 |

**기타 리소스 이벤트**

| 그룹 | 이벤트 |
| --- | --- |
| Vault | `vault.created`, `vault.archived`, `vault.deleted`, `vault_credential.created`, `vault_credential.archived`, `vault_credential.deleted`, `vault_credential.refresh_failed` |
| Agent | `agent.created`, `agent.updated`(새 버전 게시 시에만), `agent.archived`, `agent.deleted` |
| Deployment | `deployment.created`, `deployment.updated`, `deployment.paused`, `deployment.unpaused`, `deployment.archived`, `deployment.deleted` |
| Deployment run | `deployment_run.started`, `deployment_run.succeeded`, `deployment_run.failed` (스케줄 실행만, 수동 실행은 발생 안 함) |
| Environment | `environment.created`, `environment.updated`(변경이 있을 때만), `environment.archived`, `environment.deleted` |
| Memory store | `memory_store.created`, `memory_store.archived`, `memory_store.deleted` (개별 memory는 이벤트 없음) |

### 2.13.2 엔드포인트 등록

Console의 **Manage > Webhooks** 에서 등록한다.

- **URL**: 포트 443의 HTTPS, 공개적으로 resolve되는 호스트명.
- **Event types**: 받을 `data.type` 목록. 구독한 타입만 받는다.
- **Signing secret**: 생성 시 발급되는 32바이트 `whsec_` 접두 secret. **한 번만 표시**된다.

### 2.13.3 서명 검증

모든 전송에는 `webhook-id`, `webhook-timestamp`, `webhook-signature` 헤더가 붙는다. SDK의 `unwrap()` 이 서명 검증과 파싱을 한 번에 처리하며, 서명이 틀리거나 페이로드가 **5분보다 오래됐으면** 예외를 던진다. `ANTHROPIC_WEBHOOK_SIGNING_KEY` 환경 변수에 `whsec_` secret을 넣는다.

```python
client = anthropic.Anthropic()  # ANTHROPIC_WEBHOOK_SIGNING_KEY 를 env에서 읽음


@app.route("/webhook", methods=["POST"])
def webhook():
    try:
        event = client.beta.webhooks.unwrap(
            request.get_data(as_text=True), headers=dict(request.headers)
        )
    except Exception:
        return "invalid signature", 400
    if event.data.type == "session.status_idled":
        session = client.beta.sessions.retrieve(event.data.id)
    return "", 204
```

페이로드 구조:

```json
{"type": "event", "id": "whe_9d5c1f7e...", "created_at": "2026-03-18T14:05:22Z",
 "data": {"type": "session.status_idled", "id": "sesn_01XYZ...",
          "organization_id": "8a3d2f1e-...", "workspace_id": "c7b0e4d9-..."}}
```

### 2.13.4 전송 동작

- **응답**: 어떤 `2xx` 든 수신 확인으로 본다. `3xx` 는 즉시 비활성화된다(리다이렉트는 따라가지 않음). 그 밖의 실패는 재시도한다.
- **중복**: 같은 이벤트가 여러 번 올 수 있다. 모든 시도의 최상위 `event.id`(= `webhook-id` 헤더)가 같으므로 이를 기준으로 중복을 제거한다.
- **구독 범위**: 발생 시점에 그 타입을 구독한 엔드포인트에만 전달된다. 나중에 구독해도 backfill되지 않는다.
- **순서 보장 없음**: 예를 들어 `session.status_idled` 가 `session.outcome_evaluation_ended` 보다 먼저 오거나 `.deleted` 가 `.archived` 보다 먼저 올 수 있다. 상태는 조회한 리소스를 기준으로 판단한다.
- **재시도**: 엔드포인트·이벤트마다 **최대 3회** 시도하며 5–120초 사이 jittered exponential backoff를 쓴다. 마지막 시도까지 실패하면 이벤트는 **버려지고** 손실 신호도 없다. 웹훅은 durable log가 아니므로 모든 전이를 봐야 한다면 API로 목록·조회해 맞춰야 한다.
- **타임스탬프**: `webhook-timestamp` 는 시도마다 다시 찍히므로 재시도가 freshness 검사에 걸리지 않는다. 이벤트 발생 시각은 페이로드의 `created_at` 을 쓴다.
- **자동 비활성화**(`disabled_reason` 기록): (1) `3xx` 응답 시 즉시, (2) URL이 비공개 IP로 resolve되면 즉시, (3) 일정 기간 계속 실패하면(횟수가 아니라 연속 실패 기간 기준이며 `2xx` 한 번이면 리셋). 모두 Console에서 다시 활성화할 수 있지만, 비활성 기간에 발생한 이벤트는 재생되지 않는다.

---

## 2.14 핵심 요약

1. 세션은 agent와 environment를 참조하는 상태 머신(`idle`/`running`/`rescheduling`/`terminated`)이다. 생성 후 `user.message` 로 시작하거나 `initial_events`(최대 50개, `user.message`/`user.define_outcome` 만)로 생성과 동시에 `running` 으로 시작한다.
2. 스트림은 연 뒤의 이벤트만 주므로 **스트림을 먼저 열고** 이벤트를 보낸다. 재연결은 스트림 열기 → 기록 조회 → ID 기준 중복 제거로 한다.
3. `session.status_idle.stop_reason.type`(`end_turn`/`requires_action`/`budget_reached`)에 따라 대응이 달라진다. 도구 대기는 `event_ids` 각각에 `user.tool_confirmation`/`user.custom_tool_result` 로 응답한다.
4. Event delta는 연결별 opt-in(`event_deltas[]=agent.message|agent.thinking`)이고 best-effort이며 영속되지 않는다. 권위 있는 기록은 버퍼링된 `agent.message` 다.
5. 예산은 USD 센트 문자열의 list cost 상한 하나뿐이다(토큰·시간 단위 상한 없음). 생성 시에만 붙일 수 있고, 상한에 도달하면 idle(`budget_reached`)이 되며, 예산을 올리거나 제거하면 자동으로 재개된다. 웹훅은 type과 id만 보내고, 서명 검증(`unwrap()`, 5분), 최대 3회 재시도, 순서 미보장, 중복 제거가 필요하다.

---

## 출처

- https://platform.claude.com/docs/en/managed-agents/sessions
- https://platform.claude.com/docs/en/managed-agents/session-operations
- https://platform.claude.com/docs/en/managed-agents/events-and-streaming
- https://platform.claude.com/docs/en/managed-agents/event-deltas
- https://platform.claude.com/docs/en/managed-agents/session-threads
- https://platform.claude.com/docs/en/managed-agents/budgets
- https://platform.claude.com/docs/en/managed-agents/session-observability
- https://platform.claude.com/docs/en/managed-agents/webhooks
- https://platform.claude.com/docs/en/managed-agents/reference (이벤트 타입 카탈로그)
