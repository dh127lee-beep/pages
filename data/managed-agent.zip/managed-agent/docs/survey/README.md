# Claude Managed Agents 조사

> 조사일: 2026-10-14 · 주 출처: [공식 문서](https://platform.claude.com/docs/en/managed-agents/overview) 40개 페이지 전체 + 공식 가격 페이지·릴리스 노트·3자 리뷰
> 상태: **Beta** (2026-04-08 공개 베타). 모든 엔드포인트에 `managed-agents-2026-04-01` 베타 헤더 필요(SDK가 자동 설정).

## 문서 구성

| # | 문서 | 내용 |
|---|------|------|
| 01 | [개요와 에이전트 정의](01-overview-and-agents.md) | Messages API·Agent SDK와의 차이, 4대 개념, 퀵스타트(Python/curl/`ant`), Agent 필드·버저닝, Console, 마이그레이션, 레이트 리밋 |
| 02 | [세션과 이벤트](02-sessions-and-events.md) | 세션 수명주기·상태, 이벤트 카탈로그, SSE 스트리밍·재연결, event deltas, 인터럽트, 스레드, 예산(budget), 관측, 웹훅 |
| 03 | [환경과 샌드박스](03-environments-and-sandboxes.md) | Environment 설정(packages/networking), 클라우드 샌드박스 사양, Self-hosted 샌드박스(worker 구조·배포·운영·보안) |
| 04 | [도구와 연동](04-tools-and-integrations.md) | 내장 toolset, custom tools, 웹 도메인 제한, MCP connector, Skills, Files, GitHub, Vaults, 권한 정책 |
| 05 | [고급 기능](05-advanced-features.md) | Memory stores, Dreams, Outcomes, Multiagent orchestration, Scheduled deployments, Workflow runs |
| 06 | [보안](06-security.md) | 위협 모델, 샌드박스 경계, 프롬프트 인젝션, 자격 증명 처리, 통제 체크리스트, 모니터링 |
| 07 | [가격·시장·비교](07-pricing-market-and-comparison.md) | 가격 구조, 출시 타임라인, 고객 사례, 비판, OpenAI/Vertex/AgentCore/자체 호스팅 비교 |

## 한눈에 보기

**무엇인가.** Anthropic이 호스팅하는 에이전트 하네스. 직접 에이전트 루프·도구 실행·샌드박스를 만들지 않고, Claude가 관리형 컨테이너에서 bash·파일 편집·웹 검색·MCP를 써서 수 분~수 시간짜리 작업을 비동기로 수행한다. 대화 이력·샌드박스 상태·산출물이 서버에 저장되는 **상태 유지형(stateful)** 서비스.

**4대 개념**

```
Agent (모델·system·tools·MCP·skills, 버전 관리)
   +  Environment (cloud 샌드박스 | self_hosted 워커 큐)
   →  Session (실행 인스턴스: idle / running / rescheduling / terminated)
   ⇄  Events (user.* 전송 ↔ agent.* / session.* SSE 수신, 서버에 영구 저장)
```

**핵심 사실**

- **가격 [공식]**: 모델 토큰 표준 단가 + **세션 런타임 $0.08/시간**(`running` 상태만, ms 단위) + 웹 검색 $10/1,000회. idle 대기는 무과금. Batch 할인 미적용, Bedrock/Vertex 미제공(Claude Platform on AWS는 제공).
- **내장 도구**: `agent_toolset_20260401` = bash, read, write, edit, glob, grep, web_fetch, web_search. 기본 권한 정책 `always_allow`, MCP는 `always_ask`, `auto` 정책(2026-09) 추가.
- **클라우드 샌드박스**: Ubuntu 24.04, 메모리 최대 8GB, 디스크 최대 10GB, 주요 언어 런타임·Playwright 사전 설치. API에서 `networking` 생략 시 `unrestricted`(Console은 `limited`). 샌드박스 상태 30일 보존.
- **Self-hosted**: 워커가 아웃바운드 HTTPS로 작업을 폴링해 도구를 로컬에서 실행. 단, 도구 입출력은 Anthropic 제어 평면을 거친다.
- **비밀 관리**: Vault에 자격 증명(`mcp_oauth`, `static_bearer`, `environment_variable`)을 두고 세션 생성 시 `vault_ids`로 연결. 환경 변수형은 샌드박스에 placeholder만 두고 egress 시 실제 값으로 치환해 모델이 비밀을 보지 못한다.
- **제어**: `user.interrupt`로 방향 전환, `requires_action` → `user.tool_confirmation`로 승인, 세션 예산(`max_list_cost`, USD)으로 비용 상한.
- **고급 기능 상태**: Memory·Outcomes·Multiagent·Scheduled deployments·Workflow runs는 beta, **Dreams와 MCP tunnels는 research preview(별도 신청)**.
- **한도**: 생성 300 RPM / 조회 1,200 RPM(조직), 자식 스레드 25개, 워크플로 실행당 에이전트 1,000개, 메모리 스토어 세션당 8개.
- **제약**: **ZDR·HIPAA BAA 비대상**. Claude 모델 전용 → 벤더 종속 우려. 비용은 토큰+런타임 혼합이라 예측이 어렵다는 지적.

## 이 프로젝트(managed-agent)에 주는 시사점

현재 이 저장소는 DeepSeek 기반으로 유사한 "관리형 에이전트" 플랫폼(에이전트 빌더, 세션, SSE, 스킬, MCP, 채널·멀티에이전트)을 만들고 있으므로, 설계 참고 포인트는 다음과 같다.

- **리소스 분리**: Agent(버전 있는 설정) / Environment(실행 위치) / Session / Event 4계층 분리와 `agent_with_overrides`(세션 단위 일회성 덮어쓰기) 패턴.
- **이벤트 모델**: 이벤트를 서버에 전부 저장하고, 스트림은 "열린 이후 이벤트만" + 재연결 시 이력 조회 후 ID로 중복 제거. idle 상태에 `stop_reason`(`end_turn` / `requires_action` / `budget_reached`)을 붙이는 방식.
- **권한·승인 흐름**: 도구별 `always_allow` / `always_ask` / `auto` 정책과 확인 이벤트.
- **비밀 처리**: 모델 컨텍스트에 비밀을 넣지 않고 egress 프록시에서 치환하는 Vault 방식.
- **멀티에이전트**: 위임 1단계 제한, 스레드 수 상한, 하위 에이전트는 권한을 좁히기만 가능(도메인 allow는 교집합, block은 합집합). 현재 구현한 hand-off 6홉 제한과 비교해볼 만하다.
- **비용 통제**: 세션 예산 상한과 `session.usage` 이벤트로 비용 추적.

## 조사 방법과 주의

- 공식 문서 `llms.txt`에 나열된 Managed Agents 페이지 40개를 모두 받아 주제별로 정리했다. 각 장 끝의 "출처"에 원문 URL이 있다.
- 07장은 웹 검색으로 보강했고 `[1차]`(공식), `[3자]`, `[불일치]` 태그로 출처 신뢰도를 표시했다. 3자 자료의 날짜·수치는 서로 다른 경우가 있다(예: 기능 출시일 05-06 vs 05-19).
- 베타 제품이라 사양이 자주 바뀐다(최근 변경: 10-07 웹 도구가 `allowed_hosts` 준수, 10-09 dynamic workflows beta). 구현 전에 원문을 다시 확인할 것.
