# 5장. 고급 기능: 메모리, 드리밍, 아웃컴, 멀티에이전트, 스케줄 배포, 워크플로 런

> 기준일: 2026-10-14. 이 장은 `platform.claude.com/docs/en/managed-agents/` 아래 공식 문서 6개(memory, dreams, define-outcomes, multiagent-orchestration, scheduled-deployments, workflow-runs)만 근거로 정리했다. 문서에 없는 내용은 추측하지 않았다.
> 기본 베타 헤더는 `managed-agents-2026-04-01`이지만, **메모리 스토어**(`agent-memory-2026-07-22`)와 **드림**(`dreaming-2026-04-21`)은 별도 헤더를 쓴다.

---

## 5.0 한눈에 보기: 기능별 상태 요약

| 기능 | 상태 | 베타 헤더 | 핵심 리소스 / 엔드포인트 | 대표 제한 |
| --- | --- | --- | --- | --- |
| 메모리 스토어 (Memory stores) | beta | `agent-memory-2026-07-22` (스토어 API), 세션 부착은 `managed-agents-2026-04-01` | `/v1/memory_stores`, `/memories`, `/memory_versions` | 메모리당 100 kB, 스토어당 10,000개, 세션당 스토어 8개 |
| 드림 (Dreaming) | **research preview** (접근 신청 필요) | `managed-agents-2026-04-01,dreaming-2026-04-21` | `/v1/dreams`, `/cancel`, `/archive` | 드림당 세션 100개, `instructions` 4,096자 |
| 아웃컴 (Outcomes) | beta | `managed-agents-2026-04-01` | `user.define_outcome` 이벤트, `span.outcome_evaluation_*` | `max_iterations` 기본 3, 최대 20, 동시에 1개 |
| 멀티에이전트 오케스트레이션 | beta | `managed-agents-2026-04-01` | 에이전트 정의의 `multiagent` 블록 (`multiagent_20261001`) | 1단계 위임, 자식 스레드 25개, 목록당 에이전트 20개 |
| 스케줄 배포 (Scheduled deployments) | beta | `managed-agents-2026-04-01` | `/v1/deployments`, `/v1/deployment_runs` | 조직당 1,000개, 분 단위 |
| 워크플로 런 (Workflow runs) | beta | `managed-agents-2026-04-01` | `workflow_run.*` 이벤트 (조회 엔드포인트 없음) | 동시 스레드 64, 총 에이전트 1,000, 수명 24h, 세션당 열린 런 10 |

overview 문서는 베타 안에서도 "MCP tunnels와 dreaming은 더 제한된 research preview"이며 [접근 신청](https://claude.com/form/claude-managed-agents)이 필요하다고 명시한다. 이 장의 나머지 기능은 문서 frontmatter 기준 `status: beta`다.

---

## 5.1 메모리 스토어 (Memory stores)

### 무엇인가

Managed Agents 세션은 기본적으로 매번 빈 컨텍스트로 시작하고, 세션이 끝나면 쌓인 상태는 사라진다. **메모리 스토어**는 세션을 넘어 정보를 이어가게 해 준다(사용자 선호, 프로젝트 관례, 이전 실수, 도메인 맥락 등).

- **memory store**: 워크스페이스 범위의, Claude에 최적화된 텍스트 문서 모음. ID 접두사 `memstore_...`
- **memory**: 스토어 안에서 `path`로 주소 지정되는 개별 문서. API나 Claude Console에서 직접 읽고 수정할 수 있다.
- **memory version**: 메모리가 바뀔 때마다 생성되는 불변 버전(`memver_...`). 감사 추적과 시점 복구에 쓴다.

### 상태와 헤더

- `status: beta`, 베타 헤더 `agent-memory-2026-07-22`.
- 메모리 스토어 요청에 `agent-memory-2026-07-22`와 `managed-agents-2026-04-01`을 **함께 보내면 `400`**이다. 헤더를 직접 설정하는 코드라면 스토어 호출에서는 `managed-agents-2026-04-01`을 `agent-memory-2026-07-22`로 **교체**해야 한다.
- 세션 엔드포인트(세션에 스토어를 붙이는 호출 포함)는 계속 `managed-agents-2026-04-01`을 쓴다.

### 동작 방식

1. 세션 생성 시 `resources` 배열에 `{"type": "memory_store", ...}`로 붙인다. **세션 생성 시점에만** 붙일 수 있고, 실행 중 추가/제거는 지원하지 않는다.
2. 붙은 스토어는 샌드박스의 `/mnt/memory/` 아래 디렉터리로 마운트된다. 디렉터리 이름은 스토어 표시 이름을 슬러그화한 것(소문자, 영숫자가 아닌 연속 문자는 하이픈 하나)이다. 예: "Demo Memory" → `/mnt/memory/demo-memory/`. 실제 경로는 세션 리소스의 `mount_path`에서 읽으라고 문서는 권장한다.
3. 에이전트는 일반 파일 도구(agent toolset)로 읽고 쓴다. 그래서 에이전트 생성 시 agent toolset을 켜야 한다. 마운트 경로 아래 쓰기는 스토어에 반영되고 같은 스토어를 공유하는 세션 간에 동기화된다. `/mnt/memory/`의 다른 경로는 읽기 전용이라 쓰기가 실패한다.
4. 각 마운트 설명(표시 이름, 마운트 경로, 접근 모드, 스토어 `description`, `instructions`)이 시스템 프롬프트에 자동으로 추가된다.
5. 읽기와 쓰기는 이벤트 스트림에 일반 `agent.tool_use` / `agent.tool_result` 이벤트로 나타난다.

**접근 모드** `access`: 기본값 `read_write`, 그 밖에 `read_only`. 파일시스템 수준에서 강제된다. `read_write` 마운트에 쓰면 세션에 귀속된 메모리 버전이 생긴다.

**보안 경고**: 기본값이 `read_write`이므로, 신뢰할 수 없는 입력(사용자 프롬프트, 웹 콘텐츠, 서드파티 도구 출력)을 처리하는 에이전트는 프롬프트 인젝션으로 악성 내용이 스토어에 기록될 수 있고, 이후 세션이 이를 신뢰된 메모리로 읽게 된다. 참조 자료와 공유 조회용 스토어는 `read_only`를 쓰라고 문서는 권고한다.

**self-hosted 샌드박스**: 라이브 마운트가 아니다. 환경 워커가 각 스토어를 로컬 사본으로 내려받고, 도구 호출 뒤 sync interval(기본 15초)마다 최대 한 번, 세션 종료 시 한 번 더 동기화한다. 따라서 다른 self-hosted 세션은 양쪽 워커가 동기화한 뒤에야 변경을 본다. self-hosted 환경은 `memory_store` 리소스만 받는다.

### 주요 API

| 동작 | 엔드포인트 |
| --- | --- |
| 스토어 생성 / 조회 / 수정 / 목록 | `POST /v1/memory_stores`, `GET /v1/memory_stores/{id}`, update, `GET /v1/memory_stores?include_archived=true` |
| 스토어 아카이브 | `POST /v1/memory_stores/{id}/archive` (읽기 전용이 되고 새 세션에 붙일 수 없음, 단방향) |
| 스토어 삭제 | `DELETE /v1/memory_stores/{id}` (모든 메모리와 버전 영구 삭제) |
| 메모리 목록 | `GET /v1/memory_stores/{id}/memories?path_prefix=/&depth=...` |
| 메모리 생성 | `POST /v1/memory_stores/{id}/memories` (`path`, `content`). 이미 있는 경로는 덮어쓰지 않음 |
| 메모리 조회 / 수정 / 삭제 | `GET` / `POST` / `DELETE /v1/memory_stores/{id}/memories/{memory_id}` |
| 버전 목록 / 조회 | `GET /v1/memory_stores/{id}/memory_versions?memory_id=...`, `GET .../memory_versions/{version_id}` |
| 버전 redact | `POST /v1/memory_stores/{id}/memory_versions/{version_id}/redact` |

세부 규칙:

- `path_prefix`는 `/`로 끝나야 하고 경로 세그먼트 단위로 매칭된다(`/notes/`는 `/notes-archive/`와 매칭되지 않음). `depth`는 생략 또는 `0`(전체 하위 트리), `1`(직계 자식)만 허용되며 다른 값은 `400`이다.
- 수정은 `content`, `path`(이름 변경), 또는 둘 다 바꿀 수 있다.
- **낙관적 동시성**: `precondition: {"type": "content_sha256", "content_sha256": ...}`를 주면 저장된 해시가 일치할 때만 적용된다. 불일치하면 다시 읽고 재시도한다.
- 세션 리소스의 `instructions`는 4,096자 제한이다.

### 버전과 감사

- 버전은 메모리가 아니라 **스토어**에 속하며, 메모리를 삭제해도 버전은 남는다(보존 기간 내).
- 버전은 작성 후 **30일** 보존된다. 다만 살아 있는 메모리의 최근 버전은 나이와 관계없이 유지된다. 더 오래 보존하려면 API로 내보내야 한다.
- **전용 restore 엔드포인트는 없다.** 원하는 버전을 조회해 `content`를 update로 다시 쓰거나, 메모리가 삭제됐다면 create로 다시 만든다.
- **redact**는 이력 버전의 내용을 지우되 누가/언제 했는지는 남긴다(유출된 비밀, PII, 삭제 요청 대응). 살아 있는 메모리의 현재 head 버전은 redact할 수 없으므로 먼저 새 버전을 쓰거나 메모리를 삭제해야 한다.

### 제약과 한도

| 항목 | 값 |
| --- | --- |
| 메모리 1개 크기 | 100 kB (약 25k 토큰) |
| 스토어당 메모리 수 | 10,000개. 도달 시 새 메모리 쓰기(API create, 에이전트의 새 경로 쓰기)가 실패하고, 기존 메모리는 읽기/수정 가능 |
| 세션당 스토어 수 | 최대 8개 |
| 세션 리소스 `instructions` | 4,096자 |
| 버전 보존 | 30일 (최근 버전은 예외) |

문서의 권장 사항: 큰 파일 몇 개보다 작고 집중된 파일 여러 개로 구성하기, 사용자별/공유 도메인 지식/프로젝트별로 스토어 나누기(스토어마다 한도가 따로), 가득 차기 전에 정리하거나 드리밍으로 압축하기, 범위를 벗어난 스토어는 `read_only`로 붙이고 새 스토어에 쓰기, 쓰기 권한은 실제로 쓰는 세션에만 주기.

### 예시

```bash
# 1) 스토어 생성 (메모리 전용 헤더만 사용)
curl -s https://api.anthropic.com/v1/memory_stores \
  -H "x-api-key: $ANTHROPIC_API_KEY" \
  -H "anthropic-version: 2023-06-01" \
  -H "anthropic-beta: agent-memory-2026-07-22" \
  -H "content-type: application/json" \
  -d '{"name": "User Preferences", "description": "Per-user preferences and project context."}'

# 2) 세션에 부착 (세션 헤더 사용)
curl -s https://api.anthropic.com/v1/sessions \
  -H "x-api-key: $ANTHROPIC_API_KEY" \
  -H "anthropic-version: 2023-06-01" \
  -H "anthropic-beta: managed-agents-2026-04-01" \
  -H "content-type: application/json" \
  -d '{
    "agent": "'"$agent_id"'",
    "environment_id": "'"$environment_id"'",
    "resources": [{
      "type": "memory_store",
      "memory_store_id": "'"$store_id"'",
      "access": "read_write",
      "instructions": "User preferences and project context. Check before starting any task."
    }]
  }'
```

---

## 5.2 드림 (Dreams / Dreaming)

### 무엇인가

에이전트는 작업하면서 메모리 스토어에 조금씩 쓰기 때문에, 세션이 쌓이면 중복, 모순, 오래된 항목이 늘어난다. **드림**은 기존 메모리 스토어와 과거 세션 트랜스크립트를 읽고 **새로 재구성된 메모리 스토어**를 만드는 비동기 작업이다. 중복을 합치고, 오래되었거나 모순된 항목을 최신 값으로 바꾸고, 새 인사이트를 드러낸다. **입력 스토어는 절대 수정되지 않으므로** 결과를 검토한 뒤 버릴 수 있다.

### 상태

- **research preview**. [접근 신청](https://claude.com/form/claude-managed-agents)이 필요하다.
- 드림 엔드포인트는 `dreaming-2026-04-21` 헤더로 열린다. `managed-agents-2026-04-01`만으로는 접근할 수 없다. 문서 예시는 드림 엔드포인트에 두 헤더를 모두 보낸다(`managed-agents-2026-04-01,dreaming-2026-04-21`). SDK는 자동으로 설정한다.
- research preview 기간에는 드림 생성에 기본 rate limit이 적용되며, 더 필요하면 지원팀에 문의한다.

### 입력과 출력

- 입력 `inputs`:
  - `{"type": "memory_store", "memory_store_id": ...}`: 검증, 중복 제거, 재구성 대상 스토어 1개
  - `{"type": "sessions", "session_ids": [...]}`: 패턴과 인사이트를 캘 과거 세션 1~100개
- `model`: 파이프라인을 실행할 모델. 지원 모델은 `claude-opus-5-5`, `claude-fable-5-1`, `claude-opus-5`, `claude-fable-5`, `claude-opus-4-8`, `claude-opus-4-7`, `claude-sonnet-5-5`, `claude-sonnet-5`, `claude-sonnet-4-6`.
- `instructions`(선택, 4,096자): 무엇에 집중할지, 무엇을 그대로 둘지, 출력 구조 관례 같은 **상위 수준의 합성 지침**. 파이프라인은 텍스트 편집기가 아니라 합성 과정이라, "문장 X를 Y로 바꿔라" 같은 특정 줄 지시는 대체로 반영되지 않는다. 특정 메모리 수정은 출력 스토어에 Memory Stores API로 직접 한다.
- 출력 `outputs`: 별도의 새 memory store. 드림이 `running`이 되고 입력 스토어 복제가 끝난 직후 ID가 나타난다. `running` 초기에는 잠깐 빈 배열일 수 있다.
- 세션 트랜스크립트만 있고 스토어가 없다면, 빈 메모리 스토어를 먼저 만들어 입력으로 넘긴다.

### 엔드포인트와 라이프사이클

| 동작 | 엔드포인트 |
| --- | --- |
| 생성 | `POST /v1/dreams` → `status: "pending"`인 `dream` 리소스(`drm_...`) |
| 조회(폴링) | `GET /v1/dreams/{dream_id}` |
| 목록 | `GET /v1/dreams?limit=20` (기본 20, 최대 100, `page` 커서, `include_archived`) |
| 취소 | `POST /v1/dreams/{dream_id}/cancel` |
| 아카이브 | `POST /v1/dreams/{dream_id}/archive` |

| `status` | 의미 |
| --- | --- |
| `pending` | 생성되어 대기열에 있음 |
| `running` | 처리 중. `usage`가 진행에 따라 갱신됨 |
| `completed` | 성공. `outputs`가 새 메모리 스토어 |
| `failed` | 오류로 종료. 출력 스토어는 실패 전까지 쓴 내용 그대로 남음 |
| `canceled` | 취소됨. 출력 스토어는 그대로 남음 |

- 소요 시간은 입력 트랜스크립트 수에 따라 **수 분에서 수 시간**이다.
- `running` 상태에서는 `session_id`가 파이프라인을 실행하는 내부 세션을 가리킨다. 그 세션의 이벤트를 스트리밍해 드림이 무엇을 읽고 쓰는지 실시간으로 볼 수 있다. 종료 시 그 세션은 삭제되지 않고 아카이브된다.
- **취소**: `pending`/`running` → `canceled` 즉시 전환. 이미 `canceled`면 멱등 no-op, `completed`/`failed`면 400. 취소 후 몇 초간 `usage`가 더 갱신될 수 있다.
- **아카이브**: 종료 상태에서만 가능하며 `archived_at`만 설정하고 `status`는 바꾸지 않는다. `pending`/`running`이면 400(먼저 취소). unarchive는 없다. 드림을 아카이브해도 출력 스토어에는 영향이 없다.
- 실행 중 **입력** 스토어를 아카이브/삭제하거나 입력 세션을 삭제하면 드림이 `input_memory_store_unavailable` 또는 `input_session_unavailable`로 실패한다.

### 오류 타입 (일부)

`timeout`(런타임 예산 초과), `internal_error`, `memory_store_org_limit_exceeded`(작업용 스토리지 생성 중 조직 스토어 한도 도달), `input_memory_store_too_large`, `input_memory_store_unavailable`, `input_session_unavailable`.

### 과금

선택한 모델의 표준 API 토큰 요금으로 과금되며, 정확한 합계는 리소스의 `usage`에 나온다. 비용은 입력 세션의 수와 길이에 대략 선형으로 늘어난다. 문서는 작은 세션 묶음으로 시작해 품질을 확인한 뒤 늘리라고 권한다.

### 결과 활용

`completed`가 되면 출력 스토어는 워크스페이스의 일반 메모리 스토어다. API나 Console로 검토한 뒤 (a) 이후 세션에 입력 스토어 대신 또는 함께 붙이거나, (b) 삭제/아카이브한다. 메모리 문서는 스토어가 10,000개 한도에 다가갈 때 드림으로 정리한 출력 스토어로 세션을 옮기고 원본을 아카이브/삭제하는 방법을 제시한다.

### 예시

```python
dream = client.beta.dreams.create(
    inputs=[
        {"type": "memory_store", "memory_store_id": store_id},
        {"type": "sessions", "session_ids": [session_a, session_b]},
    ],
    model="claude-opus-5-5",
    instructions="Focus on coding-style preferences; ignore one-off debugging notes.",
)
while dream.status in ("pending", "running"):
    time.sleep(10)
    dream = client.beta.dreams.retrieve(dream.id)

output_store_id = next(o.memory_store_id for o in dream.outputs if o.type == "memory_store")
session = client.beta.sessions.create(
    agent=agent_id,
    environment_id=environment_id,
    resources=[{"type": "memory_store", "memory_store_id": output_store_id}],
)
```

---

## 5.3 아웃컴 (Outcomes): 루브릭, 그레이더, 자기 평가 반복

### 무엇인가

**아웃컴**은 세션에 최종 결과물이 어떤 모습이어야 하는지, 품질을 어떻게 잴지 알려 준다. 에이전트는 그 목표를 향해 일하면서 **자기 평가와 반복**을 이어가 아웃컴이 충족될 때까지 작업한다.

- 아웃컴을 정의하면 하네스가 자동으로 **grader**를 띄워 산출물을 루브릭에 비추어 평가한다.
- grader는 **별도의 컨텍스트 윈도**를 써서 메인 에이전트의 구현 선택에 영향을 받지 않는다.
- grader는 어떤 기준이 통과/실패했는지 요약한 설명(또는 루브릭을 만족한다는 확인)을 돌려주고, 이 피드백이 다음 반복에서 에이전트에게 전달된다.

### 상태

`status: beta`, 헤더 `managed-agents-2026-04-01`.

### 루브릭 (rubric)

- 기준별 채점을 서술한 **마크다운 문서**이며 **필수**다.
- grader는 기준을 하나씩 독립적으로 채점하므로, "데이터가 좋아 보인다"보다 "CSV에 숫자 값의 price 열이 있다"처럼 명시적이고 채점 가능한 기준으로 쓰라고 권한다.
- 루브릭이 없으면 잘된 산출물 예시를 Claude에게 주고 무엇이 좋은지 분석하게 한 뒤 그 분석을 루브릭으로 바꾸는 방법을 제안한다.
- 전달 방식: 인라인 `{"type": "text", "content": "..."}` 또는 Files API로 올린 뒤 `{"type": "file", "file_id": "..."}`(여러 세션에서 재사용).

### 동작 방식과 이벤트

1. 세션을 만들고 `user.define_outcome` 이벤트를 보낸다. **수신 즉시 작업이 시작되며** 별도 `user.message`는 필요 없다. 세션 생성 요청의 `initial_events`에 `user.define_outcome` 하나를 넣어 한 번에 시작할 수도 있다.
2. `user.define_outcome` 필드: `description`, `rubric`, `max_iterations`(선택, **기본 3, 최대 20**). 수신 시 `processed_at`과 `outcome_id`(`outc_...`)가 붙어 에코된다.
3. 진행 상황은 이벤트 스트림에 나타난다.
   - `agent.*`: 메시지, 도구 사용 등 작업 진행
   - `span.outcome_evaluation_start`: grader가 한 반복을 평가하기 시작. `iteration`은 0부터 시작하는 수정 횟수 카운터
   - `span.outcome_evaluation_ongoing`: grader 실행 중 하트비트. grader의 내부 추론은 공개되지 않는다
   - `span.outcome_evaluation_end`: 평가 한 사이클 종료. `result`, `explanation`, `iteration`, `usage` 포함

| `result` | 다음 동작 |
| --- | --- |
| `satisfied` | 세션이 `idle`로 전환 |
| `needs_revision` | 에이전트가 새 반복 사이클 시작 |
| `max_iterations_reached` | 마지막 확인 턴 1회 후 `idle`. 추가 평가 없음 |
| `failed` | `idle`로 전환. 루브릭이 산출물에 적용되지 않을 때(예: description과 루브릭이 모순) |
| `interrupted` | 아웃컴 진행 중 세션이 인터럽트됨. 평가 시작 전이면 `outcome_evaluation_start_id`는 빈 문자열 |

### 제약과 운용 규칙

- **한 번에 아웃컴 하나만** 지원한다. 순차 연결은 가능하다: 이전 아웃컴의 종료 `span.outcome_evaluation_end` 뒤에 새 `user.define_outcome`을 보낸다.
- 진행 중에도 `user.message`로 방향을 줄 수 있지만 필수는 아니다.
- `user.interrupt`는 현재 아웃컴 작업을 멈추고 `result`를 `interrupted`로 표시하며, 새 아웃컴을 시작할 수 있게 한다.
- 최종 평가 후 세션은 대화형 세션으로 이어 가거나 새 아웃컴을 시작할 수 있고, 이전 아웃컴 이력은 유지된다.
- 워크플로 런과의 관계: 런이 열려 있는 동안(running이든 idle이든) **평가가 시작되지 않는다**. 에이전트가 런 결과를 읽는 턴에서 평가가 시작될 수 있다(workflow-runs 문서).

### 상태 확인과 산출물 회수

- 이벤트 스트림에서 `span.outcome_evaluation_end`를 기다리거나, `GET /v1/sessions/{session_id}`의 `outcome_evaluations[].result`를 폴링한다. 평가가 끝나기 전에는 `pending`, `running`, `evaluating` 중 하나다.
- 에이전트는 산출물을 샌드박스의 `/mnt/session/outputs/`에 쓴다. Files API에서 `scope_id=<session_id>`로 목록을 조회하고(이 필터에는 `managed-agents-2026-04-01` 헤더 필요) ID로 내려받는다. 세션이 idle이 된 뒤 몇 초 늦게 목록에 나타날 수 있다.

### 예시

```bash
curl -fsSL "https://api.anthropic.com/v1/sessions/$SESSION_ID/events" \
  -H "x-api-key: $ANTHROPIC_API_KEY" \
  -H "anthropic-version: 2023-06-01" \
  -H "anthropic-beta: managed-agents-2026-04-01" \
  --json '{
    "events": [{
      "type": "user.define_outcome",
      "description": "Build a DCF model for Costco in .xlsx",
      "rubric": {"type": "file", "file_id": "'"$RUBRIC_ID"'"},
      "max_iterations": 5
    }]
  }'
```

종료 이벤트 예:

```json
{
  "type": "span.outcome_evaluation_end",
  "outcome_id": "outc_01a...",
  "result": "satisfied",
  "explanation": "All 12 criteria met: ...",
  "iteration": 0,
  "usage": {"input_tokens": 2400, "output_tokens": 350, "cache_creation_input_tokens": 0, "cache_read_input_tokens": 1800}
}
```

---

## 5.4 멀티에이전트 오케스트레이션

### 무엇인가

한 에이전트가 다른 에이전트들과 협업해 복잡한 일을 처리하게 한다. 에이전트들은 각자 격리된 컨텍스트로 병렬 작업할 수 있어 출력 품질과 완료 시간을 개선할 수 있다. 세션이 실행하는 에이전트가 일을 넘기는 방식은 세 가지다.

| 방식 | 내용 | 적합한 경우 | 고려 사항 |
| --- | --- | --- | --- |
| **Subagents** | 에이전트가 직접 하위 에이전트에 작업을 위임하고 보고를 읽음. 각 하위 에이전트는 자기 session thread에서 동작 | 보고 후 후속 지시가 필요하거나, 별도 시스템 프롬프트/도구를 가진 전문가가 필요할 때 | 위임은 1단계. 세션당 자식 스레드 최대 25개(idle 포함). advisor와 워크플로 런 스레드는 제외 |
| **Dynamic workflows** | 에이전트가 여러 에이전트를 단계별로 실행하고 결과를 합치는 프로그램(workflow)을 작성, 서버가 백그라운드에서 workflow run으로 실행 | 여러 에이전트가 필요한 대부분의 작업: 조각이 많은 일, 병렬 작업, 빨리 끝내야 할 긴 작업(감사, 마이그레이션, 딥 리서치, 교차 검증) | 모든 에이전트가 토큰을 쓰므로 세션 budget 권장. 시스템 프롬프트에 언제 런을 쓸지 명시 |
| **Advisor** | primary thread가 턴 중간에 advisor 모델에 자문(계획, 막힘 해소, 최종 검토)하고 작업은 직접 수행 | 한 에이전트가 일하되 핵심 순간에 상위 모델의 판단이 필요할 때 | primary thread만 자문 가능, advisor 모델 요금으로 과금 |

어떤 방식을 쓸 수 있는지는 사용자가 정하고, 언제 쓸지는 에이전트가 판단한다.

### 상태

`status: beta`, 헤더 `managed-agents-2026-04-01`. 에이전트 정의의 `multiagent` 블록에서 `type`으로 설정한다.

- `multiagent_20261001`: 세 방식을 모두 쓸 수 있고 각각 켜고 끌 수 있다. 기본값은 `subagents`와 `workflows` 활성, 둘 다 `inline_agents` 활성, `advisor` 비활성.
- `coordinator`: 이전 타입. 나열한 subagent 위임과 advisor는 되지만 워크플로 런 시작과 subagent 자체 정의(inline)는 안 된다. API는 두 타입을 모두 받는다.

```json
{ "multiagent": { "type": "multiagent_20261001" } }
```

| 설정 | 켜는 기능 | 에이전트 목록 | 기본값 |
| --- | --- | --- | --- |
| `workflows` | Dynamic workflows | `workflows.predefined_agents`, 최대 20 | Enabled |
| `subagents` | Subagent 위임(나열한 에이전트와 에이전트가 직접 정의한 에이전트) | `subagents.predefined_agents`, 최대 20 | Enabled |
| `advisor` | Advisor 모델 | 없음. `model` 지정 | Disabled |

### Predefined agent와 inline agent

- **Predefined agent**: 미리 생성해 `multiagent` 블록에 나열한 에이전트. 자기 설정(모델, 시스템 프롬프트, 도구, MCP 서버, 스킬)을 쓴다.
- **Inline agent**: 저장되지 않은 에이전트. 세션 에이전트나 워크플로가 일을 넘길 때 정의한다. 세션 에이전트의 모델, 도구, MCP 서버, 스킬을 쓴다.
- `subagents.predefined_agents`와 `workflows.predefined_agents`는 **서로 독립된 목록**이며 기본적으로 비어 있다.
- 목록 항목 형식: `{"type": "agent", "id": ...}`(버전 미지정 시 생성/업데이트 시점의 최신 버전에 고정), `{"type": "agent", "id": ..., "version": N}`, ID 문자열 단축형, `{"type": "self"}`(자기 자신의 사본. 세션 생성 시 agent configuration override가 있으면 사본에도 적용).
- inline 에이전트만 막으려면 `inline_agents: {"type": "disabled"}`. 이때 해당 `predefined_agents`에 최소 1개가 있어야 하며, 비어 있으면 400.

### 나열한 에이전트에 대한 규칙

- **Pinning**: 에이전트 설정과 목록은 생성/업데이트 시점에 스냅숏된다. 참조 에이전트는 그때 해석된 버전에 고정되며 이후 업데이트를 자동으로 따르지 않는다.
- **One level**: 위임은 한 단계만 가능하다. `multiagent`가 설정된 에이전트를 참조하면 400.
- **Up to 20 agents**: 목록당 고유 에이전트 20개. 같은 subagent의 사본은 스레드 한도 안에서 여러 개 호출할 수 있다.
- **Inference geography**: 에이전트와 나열된 모든 에이전트는 같은 `inference_geo`를 고정하거나 모두 고정하지 않아야 한다. 불일치는 400(저장 시와 세션 생성 override 시 모두 검사).

### 동작 방식: 스레드와 공유 자원

- 모든 에이전트는 **같은 샌드박스, 파일시스템, vault 자격 증명**을 공유하지만, 각자 **session thread**(컨텍스트가 격리된 이벤트 스트림, 자기 대화 이력)에서 동작한다.
- 세션 에이전트는 **primary thread**(세션 수준 이벤트 스트림)에 활동을 보고한다. 위임하면 런타임에 추가 스레드가 생기며, 워크플로 런도 스레드를 만든다.
- subagent 스레드는 **지속적**이다. 에이전트는 앞서 부른 subagent에게 후속 메시지를 보낼 수 있고 subagent는 이전 턴을 모두 기억한다. 사용자가 아카이브할 때까지 유지된다. 세션 스레드 문서에 따르면 idle 스레드도 아카이브 전까지 25개 한도에 포함되고, 아카이브하면 자리가 비워진다.
- **MCP 서버는 에이전트 범위, vault는 세션 범위**다. 세션 생성 시 `vault_ids`는 모든 스레드에 적용된다. 따라서 모든 에이전트가 쓰는 MCP 서버의 자격 증명을 vault에 넣어야 하고, 접근을 제한하려면 해당 에이전트 정의에 필요한 서버만 선언한다. inline 에이전트는 이런 식으로 제한할 수 없으므로, 나열한 에이전트만 허용하려면 `subagents`와 `workflows` 양쪽에서 `inline_agents`를 끄고 각각 최소 1개를 나열한다.
- `limited` 네트워크 환경에서는 에이전트나 나열된 에이전트가 `allowed_hosts`에 없는 MCP 서버를 선언하면 세션 생성이 400이다. 환경 네트워킹의 `allow_mcp_servers: true`로 이 검사를 끈다.

### Advisor

- `"advisor": {"type": "enabled", "model": "..."}`. 필드는 `type`과 `model` 두 개뿐이다. Messages API advisor 도구와 달리 `max_uses`, `max_tokens`, `caching` 필드가 없고, 자문은 `advisor_tool_result` 블록이 아니라 스레드 이벤트로 온다.
- advisor 모델은 최소 능력 기준을 충족해야 하고, 에이전트 모델이 advisor보다 더 능력 있으면 안 된다(동급은 가능). 잘못된 조합은 저장 시와 세션 생성 시 400이며, 자문마다 다시 검사해 유효하지 않으면 그 자문만 실패한다.
- 각 자문은 `anthropic.advisor`라는 이름의 플랫폼 생성 스레드에서 실행된다. 이벤트 순서는 대체로 `session.thread_created` → `session.thread_status_running` → `agent.thread_message_received`(자문 내용) → `session.thread_status_idle` → `session.thread_status_terminated`다. 자문 전달이 idle/terminated보다 먼저 온다는 보장은 없다.
- advisor는 subagent가 아니다. `list_agents`에 보이지 않고 `send_to_agent`로 닿지 않으며, subagent는 자문할 수 없다. advisor 스레드는 25개 한도에서 제외된다. `anthropic.advisor` 이름은 예약된다.
- 자문 내용의 가독성은 모델 정책을 따른다. 문서 기준 Claude Opus 5.5는 redacted 결과를 반환하므로 클라이언트에는 `[{"type": "redacted"}]`만 보이고(에이전트는 서버 측에서 전체를 읽음), Claude Opus 4.8 같은 plaintext 모델은 읽을 수 있다. 클라이언트는 `text`와 `redacted`를 모두 처리해야 한다.
- 실패하거나 인터럽트된 자문은 에이전트 턴을 실패시키지 않는다. advisor 측 프롬프트 캐싱은 자동이고, 비용은 advisor 모델 요금이며 session budget에도 계산된다. 자문마다 primary thread의 대화 전체를 보내므로 긴 세션 후반일수록 입력 토큰이 늘어난다.

### 업데이트 의미론과 기타 주의

- `multiagent_20261001` 타입을 유지하는 업데이트: 빠진 설정은 기존 값 유지, `null`은 기본값으로 리셋, 보낸 `predefined_agents`는 기존 목록을 대체, `type`이 다른 설정은 통째로 대체, 모든 객체에 `type` 필요, 활성 advisor에는 `model` 필요.
- 끄려면 `{"type": "disabled"}`. `null`을 보내면 기본값(enabled)으로 켜진다.
- 세션은 생성 시점에 설정을 복사하므로, 나중에 에이전트를 바꿔도 기존 세션은 바뀌지 않는다.
- `ant__` 접두사 도구 이름은 예약되어 있다. 이런 커스텀 도구가 있으면 업데이트와 세션 생성이 400이다.
- `coordinator` → `multiagent_20261001` 이전 시에는 블록 전체가 대체되므로 목록과 advisor를 다시 보내야 한다. 생략하면 `workflows`와 `subagents.inline_agents`가 기본값(enabled)이 되니, 원치 않으면 같은 업데이트에서 `{"type": "disabled"}`로 둔다.

### 예시: subagent 2개를 둔 리드 에이전트

```python
lead_agent = client.beta.agents.create(
    name="Engineering Lead",
    model="claude-opus-5-5",
    system="You coordinate engineering work. Delegate code review to the reviewer agent and test writing to the test agent.",
    tools=[{"type": "agent_toolset_20260401"}],
    multiagent={
        "type": "multiagent_20261001",
        "subagents": {
            "type": "enabled",
            "predefined_agents": [
                {"type": "agent", "id": reviewer_agent.id},
                {"type": "agent", "id": test_writer_agent.id},
            ],
        },
    },
)
session = client.beta.sessions.create(agent=lead_agent.id, environment_id=environment.id)
```

나열한 에이전트만 허용하고 advisor까지 붙인 예:

```json
{
  "multiagent": {
    "type": "multiagent_20261001",
    "subagents": {
      "type": "enabled",
      "inline_agents": { "type": "disabled" },
      "predefined_agents": ["agent_01J8XkN5uT3vHpLqRfWdY2", { "type": "self" }]
    },
    "workflows": { "type": "disabled" },
    "advisor": { "type": "enabled", "model": "claude-opus-5-5" }
  }
}
```

---

## 5.5 워크플로 런 (Workflow runs)

### 무엇인가

- **workflow**: 에이전트가 작성하는 프로그램으로, 여러 에이전트를 실행하고 결과를 합친다.
- **workflow run**: 워크플로 하나의 실행(`wrun_...`).
- **Dynamic workflows**: 에이전트가 워크플로를 작성하고 런을 시작하게 하는 기능. `multiagent` 블록의 `workflows` 설정으로 켜고 끈다(`multiagent_20261001`에서 기본 활성).

수백 개 문서 검토처럼 한 대화에 담기 어려운 작업을 맡기기 위한 기능이다.

### 상태

`status: beta`, 헤더 `managed-agents-2026-04-01`.

### 런이 시작되는 방식

- **별도 API 호출이 없다.** 사용자가 `user.message`로 일을 설명하면 에이전트가 런을 시작할지와 시점을 판단한다. `user.message`나 시스템 프롬프트에 언제 런을 쓸지 적어 판단에 영향을 준다. 권한 정책은 런 시작 자체가 아니라 런의 에이전트가 호출하는 도구에 적용된다.
- 문서의 시스템 프롬프트 예: "You review contracts. When you're asked to review more than a few contracts, start a workflow run that reads them in parallel and combines the findings. Review one or two contracts yourself, without a run."
- 런의 작업 방식도 지시할 수 있다: 작업 분할(계약서당 에이전트 하나, 두 번째 에이전트가 전체 재검토), 실패 처리(에이전트 하나의 실패가 런 전체를 실패시키지 않게), 시간 제한("Give the run a one-hour time limit").
- 에이전트는 inline 에이전트(워크플로가 시스템 프롬프트를 작성), `workflows.predefined_agents`의 에이전트, 또는 둘 다 쓴다. 아무것도 나열하지 않으면 워크플로가 전부 정의한다. inline 에이전트는 세션 에이전트의 모델을 쓰므로, 다른 모델을 쓰게 하려면 그 모델로 에이전트를 만들어 `workflows.predefined_agents`에 넣는다.

### 구조

- **Workflow run**: 서버가 백그라운드에서 실행. 한 세션에 여러 런이 동시에 열릴 수 있다.
- **Phases**: 이름 붙은 단계(예: "Read the contracts"). 진행은 phase 이벤트로 따라간다.
- **Agent threads**: 각 단계에서 프로그램이 작성한 프롬프트로 에이전트를 실행하며, 에이전트마다 자기 session thread를 쓴다.

프로그램이 할 수 있는 일: 여러 에이전트를 동시에 실행(fan-out), 한 에이전트의 결과를 다른 에이전트에 전달, 다음 단계를 스스로 결정(결과는 세션 에이전트가 아니라 프로그램으로 감), 단계 안에서 반복과 분기(리뷰를 통과하거나 정해진 횟수가 될 때까지 수정), 실패한 에이전트 처리. 런이 끝나면 세션 에이전트가 결과를 읽는 턴을 받아 답하거나 다른 런을 시작한다.

### 상태 전이

런은 running 또는 idle로 시작한다. budget에 도달하면 running이 idle(일시정지)이 되고, budget을 올리거나 없애면 다시 실행된다(인터럽트로도 멈춘 경우는 예외). 종료 원인은 워크플로 완료, 에이전트의 중지, 실패, 수명 만료, 세션 아카이브다. 런은 `workflow_run.created`부터 `workflow_run.status_ended`까지 **open** 상태이며, 일시정지 중에도 수명은 계속 흐르므로 `timeout_error`로 끝날 수 있다.

### 런 이벤트 (세션 primary stream으로 전달, webhook은 발생하지 않음)

| 이벤트 | 의미 |
| --- | --- |
| `workflow_run.created` | 런 시작. `workflow_run_id`, `name`, `description`, `phases`(`id`, `name`, `description`) 포함 |
| `workflow_run.status_running` | 실행 시작 또는 budget 일시정지 후 재개 |
| `workflow_run.status_idle` | 일시정지(이유는 표시하지 않음) |
| `workflow_run.phase_started` / `phase_ended` | 단계 진입/이탈. `workflow_run_phase_id`, 종료에는 `phase_started_id`. 이름은 `created`의 `phases`에서 찾음 |
| `workflow_run.status_ended` | 항상 런의 마지막 이벤트. `result` 포함 |
| `workflow_run.error` | 런 오류 또는 시작 거부. 시작 거부면 `workflow_run_id`가 `null`. 종료 신호로 간주하지 말 것 |

`result` 값: `{"type": "completed"}`(워크플로가 끝났다는 뜻일 뿐, 스레드 작업의 성공을 의미하지 않음), `{"type": "stopped"}`(에이전트가 중지했거나 세션 아카이브), `error`의 `timeout_error`, `program_error`, `thread_limit_error`, `unknown_error`.

문서는 단계 순서와 1회 실행이 보장되지 않으므로, 열린 단계가 여러 개인 경우, `phases`에 없는 단계, 시작되지 않는 단계를 모두 처리하라고 한다. 시작된 단계는 모두 `status_ended` 전에 끝난다.

### 런의 스레드

- 런의 스레드와 이를 알리는 `session.thread_created`에는 `workflow_run_id`가 있다(다른 스레드는 `null`).
- inline 에이전트 스레드의 `agent`는 `type: inline`(id/version 없음)이며 워크플로가 쓴 시스템 프롬프트를 갖는다. 모델은 세션 에이전트의 것이고, 도구/MCP/스킬은 세션 에이전트의 부분집합이다(전부 받지만 API가 보장하지는 않음). 도구 권한 정책은 유지된다.
- 모든 스레드는 같은 샌드박스와 파일(세션이 마운트한 메모리 스토어 포함)을 공유하고, 대화 이력은 스레드별로 따로다.
- 스레드 상태 이벤트는 primary stream에도 오고, 메시지 이벤트는 각 스레드 스트림에만 있다. 어느 단계에서 일하는지 알려 주는 필드는 없다.
- 서버가 늦어도 런 종료 시점까지 스레드를 아카이브한다(`terminated`). 직접 아카이브할 필요가 없고, 런이 열려 있으면 아카이브할 수도 없다.
- 같은 작업에 스레드가 둘 이상 생길 수 있으므로 도구는 **두 번 호출해도 안전하게** 만들어야 한다.
- 워크플로 코드는 볼 수 없지만, 런 종료 후 세션이 idle일 때 에이전트에게 원문 출력을 요청할 수 있다.

### 작업 완료 판정

런이 실행 중이면 세션은 스레드가 쉬고 있어도 `running`을 유지한다. 완료 조건은 (1) 본 모든 런에 `workflow_run.status_ended`가 왔고, (2) 그 뒤 사용자 요청(인터럽트 등) 때문이 아닌 `session.status_idle`(`stop_reason: end_turn`)이 오는 것이다. 일시정지된 런은 세션을 running으로 유지하지 않으므로(예: `budget_reached` idle) idle만으로 판단하면 안 된다. `retries_exhausted` idle 뒤에도 런이 돌고 있을 수 있다.

### 런이 열려 있는 동안의 요청

- 세션 아카이브/삭제: 400(`error.details.error_code: "workflow_run_open"`)일 수도, 성공할 수도 있다. 아카이브가 성공하면 열린 런은 `stopped`로 끝난다.
- 런 스레드 아카이브: 400.
- 세션 `agent` 업데이트: 400(일시정지 런 포함). 함께 보낸 다른 필드도 통째로 거부된다.
- 런 스레드의 도구 호출/확인 응답: 허용. primary stream에 오며 `session_thread_id`로 스레드를 식별한다. idle을 기다리지 말고 즉시, 결과마다 별도 요청으로 응답한다.
- `user.interrupt`: 에이전트 턴만 멈추고 **런은 끝내지 않는다.** 런을 멈추려면 `user.message`로 에이전트에게 중지를 요청한다(`stopped`로 종료). 사용자가 보내는 어떤 이벤트도 직접 런을 끝내지 않으며, 세션 아카이브만 가능하다.
- 재연결 시 스트림은 놓친 이벤트를 재생하지 않으므로 `types` 필터로 이벤트를 나열해 상태를 재구성한다. **런을 나열하는 엔드포인트는 없다.**

### 비용과 한도

- 런 자체 가격은 없고, 에이전트들의 토큰이 각 모델 요금으로 과금되며 session budget에 포함된다. 런 하나의 사용량은 해당 `workflow_run_id`를 가진 스레드들의 `usage`를 합산해 구한다.
- budget에 도달하면 모든 열린 런이 일시정지된다. 각 스레드는 이미 시작한 모델 요청을 마치므로 작업 중 스레드 수만큼 요청 1개씩 초과될 수 있다. session budget은 세션 생성 시에만 설정할 수 있다.

| 한도 | 값 | 도달 시 |
| --- | --- | --- |
| 런 하나에서 동시에 작업하는 스레드 | 64 (보장값 아님) | 하나가 끝날 때까지 새로 만들지 않음 |
| 런 수명 동안 시작하는 에이전트 | 1,000 | `thread_limit_error`로 종료(재시도 스레드로 1,000개를 넘을 수는 있음) |
| 런 수명 | 기본 24시간 또는 에이전트가 설정한 값 | `timeout_error` |
| 세션당 동시에 열린 런 | 기본 10 (idle 포함) | 시작 거부, `workflow_run.error`의 `max_workflow_runs_error` |

- 런/단계 `name`은 64자, `description`은 256자로 잘린다.
- 런을 시작할 수 있는 것은 primary thread의 에이전트뿐이며 **런은 중첩되지 않는다.** 런 스레드는 세션의 25개 자식 스레드 한도에서 제외된다.
- 런의 모델 요청은 조직의 Messages API rate limit에 포함되고, 세션/스레드/이벤트 조회는 Managed Agents read limit에 포함된다. 폴링보다 이벤트 스트림을 권장한다.

### 예시: 런을 따라가는 클라이언트 루프 (요약)

```python
open_runs = {}
with client.beta.sessions.events.stream(session_id) as stream:
    client.beta.sessions.events.send(
        session_id,
        events=[
            {
                "type": "user.message",
                "content": [
                    {
                        "type": "text",
                        "text": "Which contracts in /contracts have a change-of-control clause?",
                    }
                ],
            }
        ],
    )
    for event in stream:
        match event.type:
            case "workflow_run.created":
                open_runs[event.workflow_run_id] = event.name
            case "workflow_run.status_ended":
                open_runs.pop(event.workflow_run_id, None)
                print("Run ended:", event.result.type)
            case "agent.custom_tool_use":
                ...  # 즉시 user.custom_tool_result로 응답 (session은 running 유지 가능)
            case "session.status_idle":
                if not open_runs and event.stop_reason.type == "end_turn":
                    break
                if event.stop_reason.type not in ("end_turn", "requires_action"):
                    break
            case "session.status_terminated":
                break
```

---

## 5.6 스케줄 배포 (Scheduled deployments)

### 무엇인가

**scheduled deployment**는 에이전트가 정해진 주기로 세션을 **스스로 시작**하게 한다. Claude API의 Deployments API로 만들고 관리한다(`depl_...`).

### 상태

`status: beta`, 헤더 `managed-agents-2026-04-01`. 문서 예시는 엔드포인트에 `?beta=true` 쿼리를 붙인다.

### 생성 요소

- 필수: 에이전트(`agent`)와 환경(`environment_id`) 설정.
- 선택: files, GitHub, memory stores, vaults. self-hosted 환경 대상 배포도 메모리 스토어를 붙일 수 있지만 `file`과 `github_repository` 리소스는 클라우드 환경이 필요하다. Console 배포 폼은 self-hosted용 메모리 스토어를 아직 제공하지 않아 API/SDK로 붙여야 한다.
- 필수: 최소 1개의 `initial_events`(`user.message` 또는 `user.define_outcome`). 즉 스케줄 실행을 아웃컴 기반으로 돌릴 수 있다. `ant apply`용 배포 파일에서는 frontmatter 아래 본문이 `user.message`가 된다.
- `schedule`: `{"type": "cron", "expression": ..., "timezone": ...}`. 분 단위가 최소 단위다.
- 선택: `budget`(session budget과 같은 형태).

### cron과 시간대

- 표준 POSIX cron(`minute hour day-of-month month day-of-week`). Claude Console에서 생성/검증할 수 있다.
- IANA 시간대(예: `America/Los_Angeles`).
- DST: 벽시계 시간을 그대로 매칭한다. `"0 20 * * *"` + `America/New_York`은 EST/EDT와 관계없이 현지 오후 8시에 실행된다. 봄 전환일에 존재하지 않는 시각(예: 오전 2시)은 실행되지 않고, 가을 전환일에 두 번 나타나는 시각은 **두 번** 실행된다. 누락이나 중복이 안 되면 현지 1~3시를 피하거나 UTC를 쓰라고 권한다.
- 응답의 `schedule.upcoming_runs_at`으로 다음 실행 시각을 확인할 수 있다. 실제 실행에는 부하 분산용 **jitter**가 들어간다: 실행 간격의 최대 15%, 최소 5초, 최대 9분.

### Budget

배포의 `budget`은 **각 실행 세션에 개별 적용**되며 누적 상한이 아니다(`"2000"` 상한이면 실행마다 약 $20까지). 해당 세션은 일반 budget 세션처럼 상한에 도달하면 `budget_reached`로 일시정지한다. 배포 budget 변경은 이후 실행부터 적용된다. session budget과 달리 `"budget": null`로 제거했다가 다시 설정할 수 있다.

### Deployment runs

- 실행 시도마다 **deployment run**(`drun_...`) 기록이 생겨 세션 라이프사이클과 별도로 성공/실패를 추적한다. 성공한 run에는 `session_id`가 있다.
- `GET /v1/deployment_runs?deployment_id=...`(옵션 `has_error=true`), `GET /v1/deployment_runs/{deployment_run_id}`.
- `trigger_context.type`은 `schedule`(`scheduled_at` 포함) 또는 `manual`.
- 실패 시 `error.type` 예: `environment_archived_error`, `agent_archived_error`, `session_rate_limited_error`.
- 배포 라이프사이클 변경과 각 스케줄 실행 결과는 webhook 이벤트로도 전달된다.

### 라이프사이클

| 동작 | 엔드포인트 | 의미 |
| --- | --- | --- |
| 생성 | `POST /v1/deployments` | `status: "active"`, `upcoming_runs_at` 반환 |
| 수정 | `POST /v1/deployments/{id}` | 예: budget 설정 |
| 일시정지 | `POST /v1/deployments/{id}/pause` | 이후 스케줄 트리거 중단. 실행 중인 세션은 계속됨. 수동 run은 허용. `paused_reason: {"type": "manual"}` |
| 재개 | `POST /v1/deployments/{id}/unpause` | 다음 예정 시각부터 재개. **놓친 트리거는 backfill하지 않음** |
| 아카이브 | `POST /v1/deployments/{id}/archive` | 종료 상태. 스케줄 종료, 수정 불가 |
| 수동 실행 | `POST /v1/deployments/{id}/run` | 즉시 세션 생성, `trigger_context.type: "manual"`. 스케줄 확정 전 테스트용 |

### 실패 동작

- 세션 생성 rate limit은 재시도 없이 즉시 `session_rate_limited_error` run으로 기록되고, 다음 예정 시각에 다시 시도한다. 세션 내부 API 호출의 rate limit은 세션이 처리한다.
- 에이전트가 아카이브되면 배포도 같은 작업으로 자동 아카이브된다. 에이전트가 삭제되면 다음 트리거에서 감지해 자동 아카이브한다. 두 경우 모두 run 기록은 남지 않는다.
- 참조된 subagent가 아카이브되었거나, 환경이나 vault가 아카이브되는 등 복구할 수 없는 세션 생성 오류는 실패 run을 기록하고 배포를 **자동 일시정지**한다. `paused_reason.error.type`은 실패 run의 `error.type`과 같다.

### 한도

조직당 scheduled deployment **최대 1,000개**(더 필요하면 지원팀 문의). 분 단위가 최소 단위다.

### 예시

```bash
curl --fail-with-body -sS "https://api.anthropic.com/v1/deployments?beta=true" \
  -H "x-api-key: $ANTHROPIC_API_KEY" \
  -H "anthropic-version: 2023-06-01" \
  -H "anthropic-beta: managed-agents-2026-04-01" \
  -H "content-type: application/json" \
  -d '{
    "name": "Weekly compliance scan",
    "agent": "'"$AGENT_ID"'",
    "environment_id": "'"$ENVIRONMENT_ID"'",
    "initial_events": [
      {"type": "user.message", "content": [{"type": "text", "text": "Run the weekly compliance scan."}]}
    ],
    "schedule": {"type": "cron", "expression": "0 20 * * 5", "timezone": "America/New_York"},
    "budget": {"type": "limit", "max_list_cost": {"amount": "2000", "currency": "USD"}}
  }'
```

`ant apply`용 배포 파일 형식:

```markdown
---
name: Weekly compliance scan
agent: agent_011CYm1BLqPXpQRk5khsSXrs
environment_id: env_01595EKxaaTTGwwY3kyXdtbs
schedule:
  type: cron
  expression: "0 20 * * 5"
  timezone: America/New_York
---

Run the weekly compliance scan.
```

---

## 5.7 기능 간 관계와 정리

- **메모리 + 드림**: 메모리 스토어는 세션 간 지속 상태이고, 드림은 그 스토어를 과거 세션과 함께 정리해 새 스토어를 만드는 유지보수 도구다. 드림은 입력을 수정하지 않으므로 "검토 후 교체" 흐름을 쓴다.
- **멀티에이전트 + 워크플로 런**: 워크플로 런은 `multiagent_20261001`의 `workflows` 설정이 켜는 실행 단위다. subagent는 지속 스레드와 후속 대화가 강점이고, 워크플로 런은 대규모 병렬 처리와 프로그램 기반 조율이 강점이다. 같은 샌드박스(마운트된 메모리 스토어 포함)를 공유한다.
- **아웃컴 + 워크플로 런**: 런이 열려 있는 동안에는 아웃컴 평가가 시작되지 않는다.
- **스케줄 배포 + 아웃컴/메모리/budget**: 배포의 `initial_events`에 `user.define_outcome`을 넣을 수 있고, 메모리 스토어를 붙일 수 있으며, budget은 실행마다 개별 적용된다.
- **비용 통제**: advisor 자문, 워크플로 런의 모든 스레드, 배포 실행 세션은 모두 session budget에 포함된다. 드림은 별도로 모델 토큰 요금이 과금된다.

| 기능 | 상태 | 접근 조건 | 비고 |
| --- | --- | --- | --- |
| Memory stores | beta | 기본 제공, 별도 헤더 `agent-memory-2026-07-22` | `managed-agents-2026-04-01`과 동시 사용 시 400 |
| Dreams | research preview | 접근 신청 필요, 헤더 `dreaming-2026-04-21` | 출력은 새 스토어 |
| Outcomes | beta | 기본 헤더 | grader는 별도 컨텍스트 |
| Multiagent (subagents / advisor) | beta | 기본 헤더 | `multiagent_20261001`, 레거시 `coordinator` |
| Workflow runs (dynamic workflows) | beta | 기본 헤더, `workflows` 기본 활성 | 런 조회 엔드포인트 없음, 이벤트로만 추적 |
| Scheduled deployments | beta | 기본 헤더 | 조직당 1,000개, jitter 최대 9분 |

---

## 출처

- Using agent memory: https://platform.claude.com/docs/en/managed-agents/memory
- Dreams: https://platform.claude.com/docs/en/managed-agents/dreams
- Define outcomes: https://platform.claude.com/docs/en/managed-agents/define-outcomes
- Multiagent orchestration: https://platform.claude.com/docs/en/managed-agents/multiagent-orchestration
- Scheduled deployments: https://platform.claude.com/docs/en/managed-agents/scheduled-deployments
- Workflow runs: https://platform.claude.com/docs/en/managed-agents/workflow-runs
- 보조 참조(상태 및 스레드 한도 확인용): https://platform.claude.com/docs/en/managed-agents/overview , https://platform.claude.com/docs/en/managed-agents/session-threads
