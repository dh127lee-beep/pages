import { notFound } from 'next/navigation';
import { PublicFormPage } from '@/components/public-form-page';
import { getSystem } from '@/lib/store';

export const dynamic = 'force-dynamic';

export default async function Page({ params }: { params: Promise<{ id: string; viewId: string }> }) {
    const { id, viewId } = await params;
    const s = await getSystem(id).catch(() => null);
    const table = s?.tables.find((t) => t.views.some((v) => v.id === viewId && v.type === 'form'));
    const view = table?.views.find((v) => v.id === viewId);
    if (!s || !table || !view) notFound();
    // Only what the form needs is sent to the browser — no records.
    const slim = { ...s, tables: [{ ...table, records: [] }], dashboards: [], workflows: [], chat: [], shares: [] };
    return <PublicFormPage system={slim} tableId={table.id} viewId={view.id} />;
}
