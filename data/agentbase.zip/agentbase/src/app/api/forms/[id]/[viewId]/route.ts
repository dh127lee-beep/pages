import { mutate } from '@/lib/mutate';
import { withSystem } from '@/lib/store';

export const runtime = 'nodejs';

/** Public form submission: only fields visible on that form view are accepted. */
export async function POST(req: Request, { params }: { params: Promise<{ id: string; viewId: string }> }) {
    const { id, viewId } = await params;
    const { cells } = (await req.json()) as { cells?: Record<string, unknown> };
    try {
        const ok = await withSystem(id, (s) => {
            const t = s.tables.find((x) => x.views.some((v) => v.id === viewId && v.type === 'form'));
            const v = t?.views.find((x) => x.id === viewId);
            if (!t || !v) throw new Error('양식을 찾을 수 없습니다');
            const allowed = new Set(t.fields.filter((f) => !v.hiddenFieldIds?.includes(f.id) && f.type !== 'link').map((f) => f.id));
            const clean = Object.fromEntries(Object.entries(cells ?? {}).filter(([k]) => allowed.has(k)));
            mutate(s, { action: 'addRecord', tableId: t.id, cells: clean });
            return true;
        });
        return ok ? Response.json({ ok: true }) : Response.json({ error: 'not found' }, { status: 404 });
    } catch (e) {
        return Response.json({ error: (e as Error).message }, { status: 400 });
    }
}
