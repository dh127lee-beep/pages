import * as XLSX from 'xlsx';

export const runtime = 'nodejs';

/** Parses CSV / Excel into { name, headers, rows } for the agent to map into a table. */
export async function POST(req: Request) {
    const form = await req.formData();
    const out = [];
    for (const file of form.getAll('files')) {
        if (!(file instanceof File)) continue;
        if (file.size > 20 * 1024 * 1024) return Response.json({ error: `${file.name}: 20MB 이하 파일만 가능합니다` }, { status: 400 });
        try {
            const buf = Buffer.from(await file.arrayBuffer());
            const wb = /\.csv$/i.test(file.name) ? XLSX.read(buf.toString('utf8').replace(/^﻿/, ''), { type: 'string', cellDates: true }) : XLSX.read(buf, { type: 'buffer', cellDates: true });
            const sheet = wb.Sheets[wb.SheetNames[0]];
            const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(sheet, { defval: '', raw: false, dateNF: 'yyyy-mm-dd' });
            const headers = rows.length ? Object.keys(rows[0]) : [];
            out.push({ name: file.name, headers, rows });
        } catch (e) {
            return Response.json({ error: `${file.name}: 읽을 수 없는 파일입니다 (${(e as Error).message})` }, { status: 400 });
        }
    }
    return Response.json(out);
}
