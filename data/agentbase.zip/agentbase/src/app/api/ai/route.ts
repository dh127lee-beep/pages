import { LLM_MODEL, LLM_URL } from '@/lib/llm';

export const runtime = 'nodejs';

export async function GET() {
    let online = false;
    try {
        const r = await fetch(`${LLM_URL}/models`, { signal: AbortSignal.timeout(3000) });
        online = r.ok;
    } catch {}
    return Response.json({ url: LLM_URL, model: LLM_MODEL, online });
}
