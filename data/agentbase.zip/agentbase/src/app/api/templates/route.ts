import { TEMPLATES } from '@/lib/templates';

export function GET() {
    return Response.json(TEMPLATES.map(({ ops, ...t }) => ({ ...t, tables: ops().filter((o) => o.op === 'create_table').map((o) => o.name) })));
}
