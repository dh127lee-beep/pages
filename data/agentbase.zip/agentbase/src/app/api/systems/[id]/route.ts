import { deleteSystem, getSystem } from '@/lib/store';

export const runtime = 'nodejs';

export async function GET(_: Request, { params }: { params: Promise<{ id: string }> }) {
    const s = await getSystem((await params).id);
    return s ? Response.json(s) : Response.json({ error: 'not found' }, { status: 404 });
}

export async function DELETE(_: Request, { params }: { params: Promise<{ id: string }> }) {
    return Response.json({ ok: await deleteSystem((await params).id) });
}
