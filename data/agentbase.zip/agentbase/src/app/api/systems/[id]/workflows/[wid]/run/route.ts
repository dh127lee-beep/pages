import { getSystem } from '@/lib/store';
import { runWorkflow } from '@/lib/workflow';

export const runtime = 'nodejs';
export const maxDuration = 300;

export async function POST(req: Request, { params }: { params: Promise<{ id: string; wid: string }> }) {
    const { id, wid } = await params;
    const { test = true } = (await req.json().catch(() => ({}))) as { test?: boolean };
    const run = await runWorkflow(id, wid, test);
    if (!run) return Response.json({ error: 'not found' }, { status: 404 });
    return Response.json({ run, system: await getSystem(id) });
}
