import { runAgent, type AgentEvent, type Attachment } from '@/lib/agent';

export const runtime = 'nodejs';
export const maxDuration = 600;

/** Streams agent events as NDJSON while operations are applied live. */
export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
    const { id } = await params;
    const body = (await req.json()) as { message?: string; attachments?: Attachment[] };
    const message = String(body.message ?? '').trim();
    if (!message) return Response.json({ error: 'message required' }, { status: 400 });
    const encoder = new TextEncoder();
    const stream = new ReadableStream({
        async start(controller) {
            const emit = (e: AgentEvent) => {
                try {
                    controller.enqueue(encoder.encode(JSON.stringify(e) + '\n'));
                } catch {
                    /* client went away; keep applying so the system stays consistent */
                }
            };
            try {
                await runAgent(id, message, body.attachments ?? [], emit);
            } catch (e) {
                emit({ type: 'error', text: (e as Error).message });
            }
            try {
                controller.close();
            } catch {}
        },
    });
    return new Response(stream, { headers: { 'Content-Type': 'application/x-ndjson; charset=utf-8', 'Cache-Control': 'no-cache', 'X-Accel-Buffering': 'no' } });
}
