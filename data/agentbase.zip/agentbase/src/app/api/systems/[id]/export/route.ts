import { cellText } from '@/lib/data';
import { getSystem } from '@/lib/store';

export const runtime = 'nodejs';

const esc = (v: string) => (/[",\n]/.test(v) ? `"${v.replace(/"/g, '""')}"` : v);

export async function GET(req: Request, { params }: { params: Promise<{ id: string }> }) {
    const s = await getSystem((await params).id);
    const t = s?.tables.find((x) => x.id === new URL(req.url).searchParams.get('table'));
    if (!s || !t) return new Response('not found', { status: 404 });
    const lines = [t.fields.map((f) => esc(f.name)).join(',')];
    for (const r of t.records) lines.push(t.fields.map((f) => esc(cellText(f, r.cells[f.id], s))).join(','));
    return new Response('﻿' + lines.join('\n'), {
        headers: { 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': `attachment; filename*=UTF-8''${encodeURIComponent(t.name)}.csv` },
    });
}
