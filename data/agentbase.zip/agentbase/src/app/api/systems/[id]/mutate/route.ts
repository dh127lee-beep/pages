import { mutate, type Mutation } from '@/lib/mutate';
import { withSystem } from '@/lib/store';

export const runtime = 'nodejs';

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
    const m = (await req.json()) as Mutation;
    try {
        const out = await withSystem((await params).id, (s) => ({ result: mutate(s, m), system: s }));
        if (!out) return Response.json({ error: 'not found' }, { status: 404 });
        return Response.json(out);
    } catch (e) {
        return Response.json({ error: (e as Error).message }, { status: 400 });
    }
}
