import { applyOps } from '@/lib/ops';
import { emptySystem, listSystems, saveSystem, summarize } from '@/lib/store';
import { TEMPLATES } from '@/lib/templates';

export const runtime = 'nodejs';

export async function GET() {
    return Response.json((await listSystems()).map(summarize));
}

/** Body: { templateId } builds from a template instantly; { name, prompt } creates an empty system for the agent to build. */
export async function POST(req: Request) {
    const body = (await req.json().catch(() => ({}))) as { templateId?: string; name?: string; prompt?: string };
    if (body.templateId) {
        const tpl = TEMPLATES.find((t) => t.id === body.templateId);
        if (!tpl) return Response.json({ error: '템플릿을 찾을 수 없습니다' }, { status: 404 });
        const s = emptySystem(tpl.name, tpl.icon, tpl.description);
        s.color = tpl.color as typeof s.color;
        applyOps(s, tpl.ops());
        s.chat.push({ id: 'welcome', role: 'assistant', content: `**${tpl.name}** 템플릿으로 시스템을 만들었어요. 테이블·대시보드·워크플로를 둘러보고, 바꾸고 싶은 점을 말씀해 주세요.`, at: new Date().toISOString() });
        await saveSystem(s);
        return Response.json(summarize(s));
    }
    const name = (body.name ?? body.prompt ?? '새 시스템').trim().slice(0, 40) || '새 시스템';
    const s = emptySystem(name, '✨');
    await saveSystem(s);
    return Response.json(summarize(s));
}
