import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
    title: 'AgentBase — AI로 만드는 업무 시스템',
    description: '말 한마디로 CRM, 대시보드, 운영 시스템을 만드는 AI 빌더',
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
    return (
        <html lang="ko">
            <head>
                <link rel="preconnect" href="https://fonts.googleapis.com" />
                <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet" />
                <link href="https://cdn.jsdelivr.net/gh/orioncactus/pretendard@v1.3.9/dist/web/variable/pretendardvariable-dynamic-subset.min.css" rel="stylesheet" />
            </head>
            <body>{children}</body>
        </html>
    );
}
