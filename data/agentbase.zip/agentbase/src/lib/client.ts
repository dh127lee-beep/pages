'use client';

import type { AgentEvent, Attachment } from './agent';
import type { Mutation } from './mutate';
import type { System } from './types';

export type { AgentEvent, Attachment, Mutation };

export async function api<T>(url: string, init?: RequestInit & { json?: unknown }): Promise<T> {
    const res = await fetch(url, {
        ...init,
        headers: init?.json !== undefined ? { 'Content-Type': 'application/json', ...init?.headers } : init?.headers,
        body: init?.json !== undefined ? JSON.stringify(init.json) : init?.body,
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error ?? `요청 실패 (${res.status})`);
    return data as T;
}

export async function sendMutation(systemId: string, m: Mutation) {
    return api<{ result: unknown; system: System }>(`/api/systems/${systemId}/mutate`, { method: 'POST', json: m });
}

export async function uploadFiles(files: File[]): Promise<Attachment[]> {
    const fd = new FormData();
    files.forEach((f) => fd.append('files', f));
    return api<Attachment[]>('/api/upload', { method: 'POST', body: fd });
}

/** Reads the agent's NDJSON event stream. */
export async function streamAgent(systemId: string, message: string, attachments: Attachment[], onEvent: (e: AgentEvent) => void, signal?: AbortSignal) {
    const res = await fetch(`/api/systems/${systemId}/agent`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message, attachments }),
        signal,
    });
    if (!res.ok || !res.body) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.error ?? `요청 실패 (${res.status})`);
    }
    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buf = '';
    for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        buf += decoder.decode(value, { stream: true });
        let i: number;
        while ((i = buf.indexOf('\n')) >= 0) {
            const line = buf.slice(0, i).trim();
            buf = buf.slice(i + 1);
            if (line) {
                try {
                    onEvent(JSON.parse(line));
                } catch {}
            }
        }
    }
}
