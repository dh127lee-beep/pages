import { nanoid } from 'nanoid';
import { matchFilter, nextRunAt, primaryField, recordTitle } from './data';
import {
    CHOICE_COLORS,
    FIELD_TYPES,
    type CellValue,
    type Choice,
    type ChoiceColor,
    type Dashboard,
    type Field,
    type FieldType,
    type Filter,
    type FilterOp,
    type System,
    type Table,
    type View,
    type ViewType,
    type Widget,
    type Workflow,
    type WorkflowStep,
} from './types';

/**
 * Agent operations. The AI (and the built-in templates) describe changes as a list of
 * name-based operations; this module resolves names to ids and applies them to a System.
 */
/* eslint-disable @typescript-eslint/no-explicit-any */
export type Op = { op: string; [k: string]: any };

type FieldSpec = { name: string; type?: string; choices?: (string | Choice)[]; link?: string; symbol?: string; primary?: boolean };
type FilterSpec = { field: string; op?: string; value?: CellValue };

const FIELD_TYPE_SET = new Set(FIELD_TYPES.map((f) => f.type));
const TYPE_ALIASES: Record<string, FieldType> = {
    string: 'text', singleLineText: 'text', long_text: 'longText', textarea: 'longText', integer: 'number', float: 'number',
    money: 'currency', select: 'singleSelect', single_select: 'singleSelect', status: 'singleSelect', multi_select: 'multiSelect',
    tags: 'multiSelect', boolean: 'checkbox', bool: 'checkbox', datetime: 'date', user: 'person', owner: 'person', relation: 'link',
    linkedRecord: 'link', star: 'rating',
};
const VIEW_TYPES: ViewType[] = ['grid', 'kanban', 'gallery', 'calendar', 'form'];
const FILTER_OPS: FilterOp[] = ['eq', 'neq', 'contains', 'gt', 'gte', 'lt', 'lte', 'empty', 'notEmpty', 'withinDays', 'pastDays', 'overdue'];
const FILTER_ALIASES: Record<string, FilterOp> = {
    '=': 'eq', '==': 'eq', is: 'eq', equals: 'eq', '!=': 'neq', not: 'neq', '>': 'gt', '>=': 'gte', '<': 'lt', '<=': 'lte',
    isEmpty: 'empty', is_empty: 'empty', notempty: 'notEmpty', not_empty: 'notEmpty', next_days: 'withinDays', last_days: 'pastDays',
};

const norm = (s: unknown) => String(s ?? '').trim().toLowerCase();

export function findTable(s: System, name: unknown): Table | undefined {
    const n = norm(name);
    return s.tables.find((t) => norm(t.name) === n || t.id === name) ?? s.tables.find((t) => norm(t.name).includes(n) && n.length > 1);
}

export function findField(t: Table, name: unknown): Field | undefined {
    const n = norm(name);
    return t.fields.find((f) => norm(f.name) === n || f.id === name);
}

function findDashboard(s: System, name: unknown): Dashboard | undefined {
    const n = norm(name);
    return s.dashboards.find((d) => norm(d.name) === n || d.id === name) ?? (s.dashboards.length === 1 && !n ? s.dashboards[0] : undefined);
}

function fieldType(t: unknown): FieldType {
    const s = String(t ?? 'text');
    if (FIELD_TYPE_SET.has(s as FieldType)) return s as FieldType;
    return TYPE_ALIASES[s] ?? TYPE_ALIASES[s.toLowerCase()] ?? 'text';
}

function color(i: number): ChoiceColor {
    return CHOICE_COLORS[i % CHOICE_COLORS.length];
}

function toChoices(list: unknown): Choice[] | undefined {
    if (!Array.isArray(list)) return undefined;
    return list.map((c, i) =>
        typeof c === 'string'
            ? { name: c, color: color(i) }
            : { name: String(c.name), color: (CHOICE_COLORS as readonly string[]).includes(c.color) ? c.color : color(i) },
    );
}

function buildField(spec: FieldSpec, s: System): Field {
    const type = fieldType(spec.type);
    const f: Field = { id: `fld${nanoid(8)}`, name: String(spec.name), type };
    if (type === 'singleSelect' || type === 'multiSelect') f.choices = toChoices(spec.choices) ?? [];
    if (type === 'currency') f.symbol = spec.symbol ?? '₩';
    if (type === 'link') {
        const lt = findTable(s, spec.link);
        if (lt) f.linkTableId = lt.id;
        else f.linkTableName = String(spec.link ?? '');
    }
    if (spec.primary) f.primary = true;
    return f;
}

/** Relative date tokens keep template data fresh: "today", "+3d", "-2w", "+1m". */
function resolveDate(v: unknown): string | null {
    if (v === null || v === undefined || v === '') return null;
    const s = String(v).trim().replace(/^\+-/, '-').replace(/^(\d+[dwmy])$/i, '+$1');
    const m = /^(today|오늘)?\s*([+-]\d+)\s*([dwmy])?$/i.exec(s) ?? (/^(today|오늘)$/i.test(s) ? [s, s, '0', 'd'] : null);
    if (m) {
        const n = Number(m[2] ?? 0);
        const unit = (m[3] ?? 'd').toLowerCase();
        const d = new Date();
        if (unit === 'd') d.setDate(d.getDate() + n);
        if (unit === 'w') d.setDate(d.getDate() + n * 7);
        if (unit === 'm') d.setMonth(d.getMonth() + n);
        if (unit === 'y') d.setFullYear(d.getFullYear() + n);
        return localDate(d);
    }
    if (/^\d{4}-\d{2}-\d{2}/.test(s)) return s.slice(0, 10);
    const t = Date.parse(s);
    return Number.isFinite(t) ? localDate(new Date(t)) : s;
}

function localDate(d: Date): string {
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function ensureChoice(f: Field, name: string) {
    if (!name) return;
    f.choices ??= [];
    if (!f.choices.some((c) => c.name === name)) f.choices.push({ name, color: color(f.choices.length) });
}

export function coerce(s: System, f: Field, v: unknown): CellValue {
    if (v === undefined || v === null || v === '') return null;
    switch (f.type) {
        case 'number':
        case 'currency':
        case 'percent':
        case 'rating': {
            if (typeof v === 'number') return v;
            const n = Number(String(v).replace(/[^0-9.\-]/g, ''));
            return Number.isFinite(n) && String(v).match(/\d/) ? n : null;
        }
        case 'checkbox':
            return v === true || ['true', 'yes', 'y', '1', '예', 'o', '✓', 'v'].includes(norm(v));
        case 'multiSelect': {
            const arr = Array.isArray(v) ? v.map(String) : String(v).split(/[,;]/).map((x) => x.trim()).filter(Boolean);
            arr.forEach((x) => ensureChoice(f, x));
            return arr;
        }
        case 'singleSelect': {
            const x = String(Array.isArray(v) ? v[0] : v).trim();
            ensureChoice(f, x);
            return x;
        }
        case 'date':
            return resolveDate(v);
        case 'link': {
            const lt = s.tables.find((t) => t.id === f.linkTableId);
            if (!lt) return null;
            const names = Array.isArray(v) ? v.map(String) : String(v).split(/[,;]/).map((x) => x.trim());
            const ids = names
                .map((n) => lt.records.find((r) => r.id === n || norm(recordTitle(lt, r)) === norm(n))?.id)
                .filter((x): x is string => !!x);
            return ids.length ? ids : null;
        }
        default:
            return Array.isArray(v) ? v.join(', ') : String(v);
    }
}

function toFilters(t: Table, list: unknown): Filter[] {
    if (!Array.isArray(list)) return [];
    return (list as FilterSpec[])
        .map((x) => {
            const field = findField(t, x.field);
            if (!field) return null;
            const op = (FILTER_OPS.includes(x.op as FilterOp) ? x.op : FILTER_ALIASES[String(x.op)] ?? 'eq') as FilterOp;
            const value = field.type === 'date' && ['eq', 'neq', 'gt', 'gte', 'lt', 'lte'].includes(op) ? resolveDate(x.value) : x.value;
            return { fieldId: field.id, op, value: value ?? null } as Filter;
        })
        .filter((x): x is Filter => !!x);
}

function buildView(t: Table, spec: any): View {
    const type: ViewType = VIEW_TYPES.includes(spec.type) ? spec.type : spec.type === 'table' ? 'grid' : 'grid';
    const v: View = { id: `viw${nanoid(8)}`, name: String(spec.name ?? defaultViewName(type)), type };
    const group = findField(t, spec.groupBy) ?? (type === 'kanban' ? t.fields.find((f) => f.type === 'singleSelect') : undefined);
    if (group) v.groupByFieldId = group.id;
    const date = findField(t, spec.dateField) ?? (type === 'calendar' ? t.fields.find((f) => f.type === 'date') : undefined);
    if (date) v.dateFieldId = date.id;
    const cover = findField(t, spec.coverField);
    if (cover) v.coverFieldId = cover.id;
    const filters = toFilters(t, spec.filters);
    if (filters.length) v.filters = filters;
    const sortField = spec.sort ? findField(t, spec.sort.field) : undefined;
    if (sortField) v.sort = { fieldId: sortField.id, dir: spec.sort.dir === 'desc' ? 'desc' : 'asc' };
    if (type === 'form') {
        v.formTitle = spec.formTitle ?? t.name;
        v.formDescription = spec.formDescription;
    }
    return v;
}

export function defaultViewName(type: ViewType): string {
    return { grid: '그리드', kanban: '칸반', gallery: '갤러리', calendar: '캘린더', form: '양식' }[type];
}

function buildWidget(s: System, spec: any): Widget | null {
    const t = findTable(s, spec.table);
    if (!t) return null;
    const type = (['kpi', 'bar', 'hbar', 'line', 'donut', 'list'].includes(spec.type) ? spec.type : spec.type === 'pie' ? 'donut' : 'kpi') as Widget['type'];
    const valueField = findField(t, spec.field ?? spec.valueField);
    const agg = (['count', 'sum', 'avg', 'min', 'max'].includes(spec.agg) ? spec.agg : valueField ? 'sum' : 'count') as Widget['agg'];
    const w: Widget = {
        id: `wdg${nanoid(8)}`,
        type,
        title: String(spec.title ?? t.name),
        tableId: t.id,
        agg: valueField ? agg : 'count',
        width: [1, 2, 3, 4].includes(spec.width) ? spec.width : type === 'kpi' ? 1 : 2,
    };
    if (valueField) w.valueFieldId = valueField.id;
    const g = findField(t, spec.groupBy);
    if (g) w.groupByFieldId = g.id;
    else if (['bar', 'hbar', 'donut'].includes(type)) w.groupByFieldId = t.fields.find((f) => f.type === 'singleSelect')?.id;
    const d = findField(t, spec.dateField) ?? (type === 'line' ? t.fields.find((f) => f.type === 'date') : undefined);
    if (d) w.dateFieldId = d.id;
    if (spec.bucket) w.bucket = spec.bucket;
    const filters = toFilters(t, spec.filters);
    if (filters.length) w.filters = filters;
    if (Array.isArray(spec.fields)) w.fieldIds = spec.fields.map((n: string) => findField(t, n)?.id).filter(Boolean);
    if (spec.limit) w.limit = Number(spec.limit);
    if ((CHOICE_COLORS as readonly string[]).includes(spec.color)) w.color = spec.color;
    return w;
}

function buildStep(s: System, spec: any): WorkflowStep {
    const type = (['filter', 'update', 'aiSummary', 'email'].includes(spec.type) ? spec.type : 'filter') as WorkflowStep['type'];
    const step: WorkflowStep = { id: `stp${nanoid(6)}`, type, title: String(spec.title ?? type) };
    const t = findTable(s, spec.table);
    if (t) {
        step.tableId = t.id;
        const filters = toFilters(t, spec.filters);
        if (filters.length) step.filters = filters;
        if (spec.set && typeof spec.set === 'object') {
            step.set = {};
            for (const [k, v] of Object.entries(spec.set)) {
                const f = findField(t, k);
                if (f) step.set[f.id] = coerce(s, f, v);
            }
        }
    }
    if (spec.prompt) step.prompt = String(spec.prompt);
    if (spec.to) step.to = String(spec.to);
    if (spec.subject) step.subject = String(spec.subject);
    return step;
}

function addRecords(s: System, t: Table, rows: unknown): number {
    if (!Array.isArray(rows)) return 0;
    const now = new Date().toISOString();
    let n = 0;
    for (const row of rows) {
        if (!row || typeof row !== 'object') continue;
        const cells: Record<string, CellValue> = {};
        for (const [k, v] of Object.entries(row)) {
            const f = findField(t, k);
            if (f) cells[f.id] = coerce(s, f, v);
        }
        t.records.push({ id: `rec${nanoid(10)}`, cells, createdAt: now });
        n++;
    }
    return n;
}

export interface ApplyResult {
    actions: string[];
    focus?: { kind: 'table' | 'dashboard' | 'workflow'; id: string };
}

/** Applies ops in order. Unknown or invalid ops are skipped; returns human-readable action log. */
export function applyOps(s: System, ops: Op[]): ApplyResult {
    const res: ApplyResult = { actions: [] };
    for (const op of ops) {
        try {
            const a = applyOp(s, op, res);
            if (a) res.actions.push(a);
        } catch (e) {
            res.actions.push(`⚠️ ${op.op} 실패: ${(e as Error).message}`);
        }
        resolveLinks(s);
    }
    return res;
}

/** Link fields can point at tables created by later ops. */
function resolveLinks(s: System) {
    for (const t of s.tables)
        for (const f of t.fields) {
            if (f.type !== 'link' || !f.linkTableName) continue;
            const lt = findTable(s, f.linkTableName);
            if (lt) {
                f.linkTableId = lt.id;
                delete f.linkTableName;
            }
        }
}

function applyOp(s: System, op: Op, res: ApplyResult): string | null {
    switch (op.op) {
        case 'rename_system': {
            if (op.name) s.name = String(op.name);
            if (op.icon) s.icon = String(op.icon);
            if (op.description) s.description = String(op.description);
            if ((CHOICE_COLORS as readonly string[]).includes(op.color)) s.color = op.color;
            return `시스템 이름: ${s.name}`;
        }
        case 'create_table': {
            const existing = findTable(s, op.name);
            if (existing && norm(existing.name) === norm(op.name)) return addRecords(s, existing, op.records) ? `'${existing.name}'에 레코드 추가` : null;
            const t: Table = { id: `tbl${nanoid(8)}`, name: String(op.name), icon: String(op.icon ?? '📋'), description: op.description, fields: [], records: [], views: [] };
            for (const spec of (op.fields ?? []) as FieldSpec[]) if (spec?.name) t.fields.push(buildField(spec, s));
            if (!t.fields.length) t.fields.push({ id: `fld${nanoid(8)}`, name: '이름', type: 'text' });
            if (!t.fields.some((f) => f.primary)) t.fields[0].primary = true;
            s.tables.push(t);
            resolveLinks(s);
            const n = addRecords(s, t, op.records);
            t.views.push({ id: `viw${nanoid(8)}`, name: '전체 그리드', type: 'grid' });
            for (const v of (op.views ?? []) as any[]) t.views.push(buildView(t, v));
            res.focus ??= { kind: 'table', id: t.id };
            return `테이블 '${t.name}' 생성 — 필드 ${t.fields.length}개, 레코드 ${n}개`;
        }
        case 'delete_table': {
            const t = findTable(s, op.table ?? op.name);
            if (!t) return null;
            s.tables = s.tables.filter((x) => x !== t);
            return `테이블 '${t.name}' 삭제`;
        }
        case 'rename_table': {
            const t = findTable(s, op.table);
            if (!t) return null;
            const old = t.name;
            if (op.name) t.name = String(op.name);
            if (op.icon) t.icon = String(op.icon);
            return `테이블 '${old}' → '${t.name}'`;
        }
        case 'add_fields': {
            const t = findTable(s, op.table);
            if (!t) throw new Error(`테이블 없음: ${op.table}`);
            const names: string[] = [];
            for (const spec of (op.fields ?? []) as FieldSpec[]) {
                if (!spec?.name || findField(t, spec.name)) continue;
                t.fields.push(buildField(spec, s));
                names.push(spec.name);
            }
            // Optional values for the new fields, matched by record title.
            if (op.values && typeof op.values === 'object') fillValues(s, t, op.values);
            res.focus ??= { kind: 'table', id: t.id };
            return names.length ? `'${t.name}'에 필드 추가: ${names.join(', ')}` : null;
        }
        case 'update_field': {
            const t = findTable(s, op.table);
            const f = t && findField(t, op.field);
            if (!t || !f) throw new Error(`필드 없음: ${op.field}`);
            if (op.name) f.name = String(op.name);
            if (op.type) {
                const nt = fieldType(op.type);
                if (nt !== f.type) {
                    f.type = nt;
                    if ((nt === 'singleSelect' || nt === 'multiSelect') && !f.choices) f.choices = [];
                    for (const r of t.records) r.cells[f.id] = coerce(s, f, Array.isArray(r.cells[f.id]) ? (r.cells[f.id] as string[]).join(',') : r.cells[f.id]);
                }
            }
            if (op.choices) f.choices = toChoices(op.choices);
            return `필드 '${f.name}' 수정`;
        }
        case 'delete_field': {
            const t = findTable(s, op.table);
            const f = t && findField(t, op.field);
            if (!t || !f) return null;
            t.fields = t.fields.filter((x) => x !== f);
            if (f.primary && t.fields[0]) t.fields[0].primary = true;
            return `필드 '${f.name}' 삭제`;
        }
        case 'add_records': {
            const t = findTable(s, op.table);
            if (!t) throw new Error(`테이블 없음: ${op.table}`);
            const n = addRecords(s, t, op.records);
            res.focus ??= { kind: 'table', id: t.id };
            return `'${t.name}'에 레코드 ${n}개 추가`;
        }
        case 'update_records': {
            const t = findTable(s, op.table);
            if (!t) throw new Error(`테이블 없음: ${op.table}`);
            const where = toFilters(t, op.where);
            const targets = matchWhere(t, where, op.where);
            let n = 0;
            for (const r of targets) {
                for (const [k, v] of Object.entries(op.set ?? {})) {
                    const f = findField(t, k);
                    if (f) r.cells[f.id] = coerce(s, f, v);
                }
                n++;
            }
            res.focus ??= { kind: 'table', id: t.id };
            return `'${t.name}' 레코드 ${n}개 수정`;
        }
        case 'delete_records': {
            const t = findTable(s, op.table);
            if (!t) return null;
            const targets = new Set(matchWhere(t, toFilters(t, op.where), op.where));
            if (!targets.size) return null;
            t.records = t.records.filter((r) => !targets.has(r));
            return `'${t.name}' 레코드 ${targets.size}개 삭제`;
        }
        case 'create_view': {
            const t = findTable(s, op.table);
            if (!t) throw new Error(`테이블 없음: ${op.table}`);
            const v = buildView(t, op);
            t.views.push(v);
            res.focus ??= { kind: 'table', id: t.id };
            return `'${t.name}'에 ${defaultViewName(v.type)} 뷰 '${v.name}' 추가`;
        }
        case 'delete_view': {
            const t = findTable(s, op.table);
            if (!t || t.views.length <= 1) return null;
            const before = t.views.length;
            t.views = t.views.filter((v) => norm(v.name) !== norm(op.view));
            return before !== t.views.length ? `뷰 '${op.view}' 삭제` : null;
        }
        case 'create_dashboard': {
            const d: Dashboard = { id: `dsh${nanoid(8)}`, name: String(op.name ?? '대시보드'), icon: String(op.icon ?? '📊'), description: op.description, widgets: [] };
            for (const w of (op.widgets ?? []) as any[]) {
                const built = buildWidget(s, w);
                if (built) d.widgets.push(built);
            }
            s.dashboards.push(d);
            res.focus = { kind: 'dashboard', id: d.id };
            return `대시보드 '${d.name}' 생성 — 위젯 ${d.widgets.length}개`;
        }
        case 'add_widgets': {
            const d = findDashboard(s, op.dashboard) ?? s.dashboards[0];
            if (!d) throw new Error('대시보드가 없습니다');
            let n = 0;
            for (const w of (op.widgets ?? []) as any[]) {
                const built = buildWidget(s, w);
                if (built) {
                    d.widgets.push(built);
                    n++;
                }
            }
            res.focus = { kind: 'dashboard', id: d.id };
            return `'${d.name}'에 위젯 ${n}개 추가`;
        }
        case 'remove_widget': {
            const d = findDashboard(s, op.dashboard) ?? s.dashboards[0];
            if (!d) return null;
            const before = d.widgets.length;
            d.widgets = d.widgets.filter((w) => norm(w.title) !== norm(op.title));
            return before !== d.widgets.length ? `위젯 '${op.title}' 제거` : null;
        }
        case 'delete_dashboard': {
            const d = findDashboard(s, op.dashboard ?? op.name);
            if (!d) return null;
            s.dashboards = s.dashboards.filter((x) => x !== d);
            return `대시보드 '${d.name}' 삭제`;
        }
        case 'create_workflow': {
            const schedule: Workflow['schedule'] = {
                freq: (['daily', 'weekly', 'monthly', 'hourly'].includes(op.schedule?.freq) ? op.schedule.freq : 'weekly') as Workflow['schedule']['freq'],
                time: /^\d{1,2}:\d{2}$/.test(op.schedule?.time ?? '') ? op.schedule.time.padStart(5, '0') : '09:00',
                dayOfWeek: op.schedule?.dayOfWeek ?? 1,
                dayOfMonth: op.schedule?.dayOfMonth ?? 1,
                timezone: op.schedule?.timezone ?? 'Asia/Seoul',
            };
            const wf: Workflow = {
                id: `wfl${nanoid(8)}`,
                name: String(op.name ?? '새 워크플로'),
                description: op.description,
                enabled: Boolean(op.enabled),
                schedule,
                steps: ((op.steps ?? []) as any[]).map((st) => buildStep(s, st)),
                runs: [],
            };
            wf.nextRunAt = nextRunAt(schedule);
            s.workflows.push(wf);
            res.focus ??= { kind: 'workflow', id: wf.id };
            return `워크플로 '${wf.name}' 생성 — 단계 ${wf.steps.length}개`;
        }
        case 'delete_workflow': {
            const before = s.workflows.length;
            s.workflows = s.workflows.filter((w) => norm(w.name) !== norm(op.name ?? op.workflow));
            return before !== s.workflows.length ? `워크플로 '${op.name ?? op.workflow}' 삭제` : null;
        }
        default:
            return null;
    }
}

/** `where` may also be a plain object {Field: value} or a record title string. */
function matchWhere(t: Table, filters: Filter[], raw: unknown) {
    if (filters.length) {
        return t.records.filter((r) => filters.every((f) => matchOne(t, r, f)));
    }
    if (raw && typeof raw === 'object' && !Array.isArray(raw)) {
        const fs = Object.entries(raw).map(([k, v]) => ({ field: k, op: 'eq', value: v as CellValue }));
        const parsed = toFilters(t, fs);
        return parsed.length ? t.records.filter((r) => parsed.every((f) => matchOne(t, r, f))) : [];
    }
    if (typeof raw === 'string') {
        return t.records.filter((r) => norm(recordTitle(t, r)) === norm(raw));
    }
    return [];
}

function matchOne(t: Table, r: Table['records'][number], f: Filter) {
    return matchFilter(t.fields.find((x) => x.id === f.fieldId), r, f);
}

function fillValues(s: System, t: Table, values: Record<string, Record<string, unknown>>) {
    const pf = primaryField(t);
    if (!pf) return;
    for (const [title, cells] of Object.entries(values)) {
        const r = t.records.find((x) => norm(x.cells[pf.id]) === norm(title));
        if (!r) continue;
        for (const [k, v] of Object.entries(cells)) {
            const f = findField(t, k);
            if (f) r.cells[f.id] = coerce(s, f, v);
        }
    }
}
