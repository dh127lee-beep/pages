import type { Op } from './ops';

export interface Template {
    id: string;
    category: string;
    name: string;
    icon: string;
    color: string;
    description: string;
    highlights: string[];
    ops: () => Op[];
}

export const TEMPLATE_CATEGORIES = ['전체', '영업 · CRM', '인사 · HR', '프로젝트', '운영 · 재고', '마케팅', '재무'];

/** Deterministic pseudo-random so template data is stable but varied. */
function rng(seed: number) {
    let x = seed;
    return () => {
        x = (x * 1103515245 + 12345) % 2147483648;
        return x / 2147483648;
    };
}
const pick = <T,>(r: () => number, arr: T[]) => arr[Math.floor(r() * arr.length)];

const PEOPLE = ['김민준', '이서연', '박지호', '최유나', '정도윤', '한지민'];

function crm(): Op[] {
    const r = rng(7);
    const companies = ['한빛소프트', '누리테크', '바른물류', '하늘항공', '초록에너지', '미래헬스케어', '다온푸드', '세움건설', '온새미로', '큐브랩스', '블루오션커머스', '라온교육'];
    const industries = ['IT', '물류', '제조', '헬스케어', '유통', '교육', '에너지'];
    const stages = ['리드', '미팅', '제안', '협상', '수주', '실주'];
    const deals: Record<string, unknown>[] = [];
    for (let i = 0; i < 22; i++) {
        const stage = pick(r, stages);
        deals.push({
            '딜 이름': `${companies[i % companies.length]} ${pick(r, ['도입', '확장', '갱신', '파일럿', '연간계약'])}`,
            고객사: companies[i % companies.length],
            단계: stage,
            금액: Math.round((r() * 90 + 5) * 1_000_000 / 100000) * 100000,
            담당자: pick(r, PEOPLE.slice(0, 4)),
            '예상 마감일': `${Math.round(r() * 80 - 20)}d`.replace(/^(\d)/, '+$1'),
            확률: { 리드: 10, 미팅: 25, 제안: 50, 협상: 75, 수주: 100, 실주: 0 }[stage],
            생성일: `-${Math.floor(r() * 170)}d`,
        });
    }
    return [
        { op: 'rename_system', name: '영업 CRM', icon: '🤝', description: '고객사·영업 기회·활동을 한 곳에서 관리하는 CRM' },
        {
            op: 'create_table', name: '고객사', icon: '🏢',
            fields: [
                { name: '회사명', type: 'text', primary: true }, { name: '업종', type: 'singleSelect', choices: industries },
                { name: '등급', type: 'singleSelect', choices: ['VIP', '일반', '잠재'] }, { name: '담당자', type: 'person' },
                { name: '이메일', type: 'email' }, { name: '연락처', type: 'phone' }, { name: '웹사이트', type: 'url' },
                { name: '최근 연락일', type: 'date' },
            ],
            records: companies.map((c, i) => ({
                회사명: c, 업종: industries[i % industries.length], 등급: pick(r, ['VIP', '일반', '일반', '잠재']), 담당자: PEOPLE[i % 4],
                이메일: `contact@company${i + 1}.co.kr`, 연락처: `02-${3000 + i * 37}-${1000 + i * 91}`, 웹사이트: `https://company${i + 1}.co.kr`,
                '최근 연락일': `-${Math.floor(r() * 50)}d`,
            })),
            views: [{ name: '업종별', type: 'kanban', groupBy: '업종' }],
        },
        {
            op: 'create_table', name: '영업 기회', icon: '💼',
            fields: [
                { name: '딜 이름', type: 'text', primary: true }, { name: '고객사', type: 'link', link: '고객사' },
                { name: '단계', type: 'singleSelect', choices: stages.map((n, i) => ({ name: n, color: ['gray', 'blue', 'purple', 'amber', 'green', 'red'][i] })) },
                { name: '금액', type: 'currency', symbol: '₩' }, { name: '담당자', type: 'person' }, { name: '예상 마감일', type: 'date' },
                { name: '확률', type: 'percent' }, { name: '생성일', type: 'date' },
            ],
            records: deals,
            views: [
                { name: '파이프라인', type: 'kanban', groupBy: '단계' },
                { name: '마감 캘린더', type: 'calendar', dateField: '예상 마감일' },
                { name: '신규 리드 등록', type: 'form', formTitle: '신규 영업 기회 등록', formDescription: '새 리드 정보를 입력해 주세요.' },
            ],
        },
        {
            op: 'create_table', name: '영업 활동', icon: '📞',
            fields: [
                { name: '활동', type: 'text', primary: true }, { name: '유형', type: 'singleSelect', choices: ['전화', '미팅', '이메일', '데모'] },
                { name: '고객사', type: 'link', link: '고객사' }, { name: '일자', type: 'date' }, { name: '담당자', type: 'person' },
                { name: '완료', type: 'checkbox' }, { name: '메모', type: 'longText' },
            ],
            records: Array.from({ length: 14 }, (_, i) => ({
                활동: `${companies[(i * 5) % companies.length]} ${pick(r, ['후속 통화', '제안서 발표', '견적 송부', '제품 데모', '킥오프 미팅'])}`,
                유형: pick(r, ['전화', '미팅', '이메일', '데모']), 고객사: companies[(i * 5) % companies.length],
                일자: `${i < 7 ? '-' : '+'}${Math.floor(r() * 14)}d`, 담당자: PEOPLE[i % 4], 완료: i < 7, 메모: '고객 요구사항 정리 필요',
            })),
            views: [{ name: '활동 캘린더', type: 'calendar', dateField: '일자' }],
        },
        {
            op: 'create_dashboard', name: '영업 현황', icon: '📈',
            widgets: [
                { type: 'kpi', title: '진행 중 파이프라인', table: '영업 기회', agg: 'sum', field: '금액', filters: [{ field: '단계', op: 'neq', value: '수주' }, { field: '단계', op: 'neq', value: '실주' }], color: 'blue' },
                { type: 'kpi', title: '수주 금액', table: '영업 기회', agg: 'sum', field: '금액', filters: [{ field: '단계', op: 'eq', value: '수주' }], color: 'green' },
                { type: 'kpi', title: '전체 딜 수', table: '영업 기회', agg: 'count', color: 'purple' },
                { type: 'kpi', title: '30일 내 마감 예정', table: '영업 기회', agg: 'count', filters: [{ field: '예상 마감일', op: 'withinDays', value: 30 }], color: 'amber' },
                { type: 'bar', title: '단계별 금액', table: '영업 기회', agg: 'sum', field: '금액', groupBy: '단계', width: 2 },
                { type: 'donut', title: '담당자별 딜', table: '영업 기회', agg: 'count', groupBy: '담당자', width: 2 },
                { type: 'line', title: '월별 신규 딜', table: '영업 기회', agg: 'count', dateField: '생성일', bucket: 'month', width: 2 },
                { type: 'list', title: '곧 마감되는 딜', table: '영업 기회', fields: ['딜 이름', '단계', '금액', '예상 마감일'], filters: [{ field: '예상 마감일', op: 'withinDays', value: 30 }], limit: 6, width: 2 },
            ],
        },
        {
            op: 'create_workflow', name: '주간 영업 리포트', description: '매주 월요일 파이프라인을 요약해 팀에 보고합니다.',
            schedule: { freq: 'weekly', time: '09:00', dayOfWeek: 1 },
            steps: [
                { type: 'filter', title: '이번 달 마감 예정 딜 찾기', table: '영업 기회', filters: [{ field: '예상 마감일', op: 'withinDays', value: 30 }] },
                { type: 'aiSummary', title: '파이프라인 분석', prompt: '단계별 금액, 이번 달 마감 예정 딜, 리스크가 있는 딜과 다음 액션을 정리해줘' },
                { type: 'email', title: '영업팀에 발송', to: 'sales@company.com', subject: '[주간] 영업 파이프라인 리포트' },
            ],
        },
    ];
}

function hr(): Op[] {
    const r = rng(11);
    const positions = ['프론트엔드 개발자', '백엔드 개발자', '프로덕트 디자이너', '데이터 분석가', '마케팅 매니저'];
    const stages = ['서류 검토', '1차 면접', '과제', '2차 면접', '처우 협의', '합격', '불합격'];
    const names = ['강하늘', '윤소희', '임재현', '오세린', '서지훈', '배수아', '조민성', '신예린', '권태양', '황보라', '송다인', '문현우', '양지수', '구본혁'];
    return [
        { op: 'rename_system', name: '채용 · 인사 관리', icon: '🧑‍💼', description: '채용 파이프라인과 직원 정보를 관리하는 HR 시스템' },
        {
            op: 'create_table', name: '채용 공고', icon: '📢',
            fields: [
                { name: '포지션', type: 'text', primary: true }, { name: '부서', type: 'singleSelect', choices: ['개발', '디자인', '데이터', '마케팅'] },
                { name: '상태', type: 'singleSelect', choices: [{ name: '진행 중', color: 'green' }, { name: '보류', color: 'amber' }, { name: '마감', color: 'gray' }] },
                { name: '채용 인원', type: 'number' }, { name: '마감일', type: 'date' }, { name: '채용 담당', type: 'person' },
            ],
            records: positions.map((p, i) => ({ 포지션: p, 부서: ['개발', '개발', '디자인', '데이터', '마케팅'][i], 상태: i === 4 ? '보류' : '진행 중', '채용 인원': 1 + (i % 2), 마감일: `+${10 + i * 6}d`, '채용 담당': PEOPLE[4 + (i % 2)] })),
        },
        {
            op: 'create_table', name: '지원자', icon: '👤',
            fields: [
                { name: '이름', type: 'text', primary: true }, { name: '포지션', type: 'link', link: '채용 공고' },
                { name: '단계', type: 'singleSelect', choices: stages.map((n, i) => ({ name: n, color: ['gray', 'blue', 'cyan', 'purple', 'amber', 'green', 'red'][i] })) },
                { name: '경력(년)', type: 'number' }, { name: '평가', type: 'rating' }, { name: '지원 경로', type: 'singleSelect', choices: ['원티드', '링크드인', '추천', '홈페이지'] },
                { name: '면접일', type: 'date' }, { name: '이메일', type: 'email' }, { name: '지원일', type: 'date' }, { name: '프로필 사진', type: 'url' },
            ],
            records: names.map((n, i) => ({
                이름: n, 포지션: positions[i % positions.length], 단계: pick(r, stages), '경력(년)': Math.floor(r() * 10) + 1, 평가: Math.floor(r() * 3) + 3,
                '지원 경로': pick(r, ['원티드', '링크드인', '추천', '홈페이지']), 면접일: `${Math.floor(r() * 20) - 5}d`, 이메일: `applicant${i + 1}@mail.com`,
                지원일: `-${Math.floor(r() * 60)}d`, '프로필 사진': `https://i.pravatar.cc/300?img=${i + 10}`,
            })),
            views: [
                { name: '채용 파이프라인', type: 'kanban', groupBy: '단계' },
                { name: '면접 일정', type: 'calendar', dateField: '면접일' },
                { name: '지원자 카드', type: 'gallery', coverField: '프로필 사진' },
                { name: '지원서 접수', type: 'form', formTitle: '입사 지원서', formDescription: '지원해 주셔서 감사합니다. 아래 정보를 입력해 주세요.' },
            ],
        },
        {
            op: 'create_table', name: '직원', icon: '🪪',
            fields: [
                { name: '이름', type: 'text', primary: true }, { name: '부서', type: 'singleSelect', choices: ['개발', '디자인', '데이터', '마케팅', '경영지원'] },
                { name: '직급', type: 'singleSelect', choices: ['사원', '선임', '책임', '수석', '리드'] }, { name: '입사일', type: 'date' },
                { name: '연차 잔여', type: 'number' }, { name: '재직 상태', type: 'singleSelect', choices: [{ name: '재직', color: 'green' }, { name: '휴직', color: 'amber' }, { name: '퇴사', color: 'gray' }] },
                { name: '이메일', type: 'email' },
            ],
            records: PEOPLE.concat(['노을', '유채원', '전민호', '홍서진']).map((n, i) => ({
                이름: n, 부서: pick(r, ['개발', '디자인', '데이터', '마케팅', '경영지원']), 직급: pick(r, ['사원', '선임', '책임', '수석', '리드']),
                입사일: `-${Math.floor(r() * 60) + 2}m`, '연차 잔여': Math.floor(r() * 15), '재직 상태': i === 8 ? '휴직' : '재직', 이메일: `emp${i + 1}@company.com`,
            })),
            views: [{ name: '부서별', type: 'kanban', groupBy: '부서' }],
        },
        {
            op: 'create_dashboard', name: '채용 대시보드', icon: '📊',
            widgets: [
                { type: 'kpi', title: '전체 지원자', table: '지원자', agg: 'count', color: 'blue' },
                { type: 'kpi', title: '진행 중 공고', table: '채용 공고', agg: 'count', filters: [{ field: '상태', op: 'eq', value: '진행 중' }], color: 'green' },
                { type: 'kpi', title: '합격자', table: '지원자', agg: 'count', filters: [{ field: '단계', op: 'eq', value: '합격' }], color: 'purple' },
                { type: 'kpi', title: '평균 평가', table: '지원자', agg: 'avg', field: '평가', color: 'amber' },
                { type: 'hbar', title: '단계별 지원자', table: '지원자', agg: 'count', groupBy: '단계', width: 2 },
                { type: 'donut', title: '지원 경로', table: '지원자', agg: 'count', groupBy: '지원 경로', width: 2 },
                { type: 'list', title: '이번 주 면접', table: '지원자', fields: ['이름', '단계', '면접일'], filters: [{ field: '면접일', op: 'withinDays', value: 7 }], width: 2 },
                { type: 'bar', title: '부서별 인원', table: '직원', agg: 'count', groupBy: '부서', width: 2 },
            ],
        },
        {
            op: 'create_workflow', name: '면접 일정 알림', description: '매일 아침 3일 내 면접 일정을 정리해 면접관에게 알립니다.',
            schedule: { freq: 'daily', time: '08:30' },
            steps: [
                { type: 'filter', title: '3일 내 면접 찾기', table: '지원자', filters: [{ field: '면접일', op: 'withinDays', value: 3 }] },
                { type: 'email', title: '면접관에게 알림', to: 'interviewers@company.com', subject: '[알림] 다가오는 면접 일정' },
            ],
        },
    ];
}

function project(): Op[] {
    const r = rng(23);
    const projects = ['모바일 앱 2.0', '결제 시스템 개편', '데이터 웨어하우스', '고객센터 챗봇'];
    const status = ['백로그', '할 일', '진행 중', '리뷰', '완료'];
    const tasks = ['요구사항 정리', '와이어프레임', 'API 설계', 'DB 스키마', '로그인 구현', '결제 연동', 'QA 테스트', '성능 최적화', '배포 파이프라인', '사용자 인터뷰', '대시보드 UI', '알림 기능', '문서화', '보안 점검', '데이터 마이그레이션', '릴리즈 노트'];
    return [
        { op: 'rename_system', name: '프로젝트 트래커', icon: '🚀', description: '프로젝트와 작업, 마일스톤을 추적하는 시스템' },
        {
            op: 'create_table', name: '프로젝트', icon: '📁',
            fields: [
                { name: '프로젝트명', type: 'text', primary: true }, { name: '상태', type: 'singleSelect', choices: [{ name: '계획', color: 'gray' }, { name: '진행', color: 'blue' }, { name: '위험', color: 'red' }, { name: '완료', color: 'green' }] },
                { name: 'PM', type: 'person' }, { name: '시작일', type: 'date' }, { name: '마감일', type: 'date' }, { name: '예산', type: 'currency' }, { name: '진척률', type: 'percent' },
            ],
            records: projects.map((p, i) => ({ 프로젝트명: p, 상태: ['진행', '위험', '진행', '계획'][i], PM: PEOPLE[i], 시작일: `-${30 + i * 10}d`, 마감일: `+${20 + i * 15}d`, 예산: (i + 2) * 35_000_000, 진척률: [65, 40, 30, 5][i] })),
        },
        {
            op: 'create_table', name: '작업', icon: '✅',
            fields: [
                { name: '작업명', type: 'text', primary: true }, { name: '프로젝트', type: 'link', link: '프로젝트' },
                { name: '상태', type: 'singleSelect', choices: status.map((n, i) => ({ name: n, color: ['gray', 'cyan', 'blue', 'purple', 'green'][i] })) },
                { name: '우선순위', type: 'singleSelect', choices: [{ name: '긴급', color: 'red' }, { name: '높음', color: 'orange' }, { name: '보통', color: 'blue' }, { name: '낮음', color: 'gray' }] },
                { name: '담당자', type: 'person' }, { name: '마감일', type: 'date' }, { name: '예상 시간', type: 'number' }, { name: '태그', type: 'multiSelect', choices: ['프론트', '백엔드', '디자인', '인프라', '기획'] },
            ],
            records: tasks.map((t, i) => ({
                작업명: t, 프로젝트: projects[i % 4], 상태: pick(r, status), 우선순위: pick(r, ['긴급', '높음', '보통', '보통', '낮음']), 담당자: pick(r, PEOPLE),
                마감일: `${Math.floor(r() * 30) - 8}d`.replace(/^(\d)/, '+$1'), '예상 시간': Math.floor(r() * 16) + 2, 태그: [pick(r, ['프론트', '백엔드', '디자인', '인프라', '기획'])],
            })),
            views: [{ name: '스프린트 보드', type: 'kanban', groupBy: '상태' }, { name: '일정', type: 'calendar', dateField: '마감일' }, { name: '작업 요청', type: 'form', formTitle: '작업 요청서' }],
        },
        {
            op: 'create_dashboard', name: '프로젝트 현황', icon: '🎯',
            widgets: [
                { type: 'kpi', title: '진행 중 작업', table: '작업', agg: 'count', filters: [{ field: '상태', op: 'eq', value: '진행 중' }], color: 'blue' },
                { type: 'kpi', title: '완료된 작업', table: '작업', agg: 'count', filters: [{ field: '상태', op: 'eq', value: '완료' }], color: 'green' },
                { type: 'kpi', title: '지연된 작업', table: '작업', agg: 'count', filters: [{ field: '마감일', op: 'overdue' }, { field: '상태', op: 'neq', value: '완료' }], color: 'red' },
                { type: 'kpi', title: '총 예산', table: '프로젝트', agg: 'sum', field: '예산', color: 'purple' },
                { type: 'bar', title: '상태별 작업', table: '작업', agg: 'count', groupBy: '상태', width: 2 },
                { type: 'donut', title: '담당자별 작업', table: '작업', agg: 'count', groupBy: '담당자', width: 2 },
                { type: 'hbar', title: '프로젝트별 진척률', table: '프로젝트', agg: 'max', field: '진척률', groupBy: '프로젝트명', width: 2 },
                { type: 'list', title: '지연된 작업', table: '작업', fields: ['작업명', '담당자', '마감일', '우선순위'], filters: [{ field: '마감일', op: 'overdue' }, { field: '상태', op: 'neq', value: '완료' }], width: 2 },
            ],
        },
        {
            op: 'create_workflow', name: '지연 작업 점검', description: '매일 마감이 지난 작업을 찾아 우선순위를 높이고 팀에 알립니다.',
            schedule: { freq: 'daily', time: '09:00' },
            steps: [
                { type: 'filter', title: '지연된 작업 찾기', table: '작업', filters: [{ field: '마감일', op: 'overdue' }, { field: '상태', op: 'neq', value: '완료' }] },
                { type: 'update', title: '우선순위 긴급으로 변경', table: '작업', filters: [{ field: '마감일', op: 'overdue' }, { field: '상태', op: 'neq', value: '완료' }], set: { 우선순위: '긴급' } },
                { type: 'email', title: '팀에 알림', to: 'dev-team@company.com', subject: '[알림] 지연된 작업' },
            ],
        },
    ];
}

function inventory(): Op[] {
    const r = rng(31);
    const items = ['무선 마우스', '기계식 키보드', '27인치 모니터', 'USB-C 허브', '노트북 거치대', '웹캠 FHD', '블루투스 스피커', '외장 SSD 1TB', 'HDMI 케이블', '무선 충전기', '노이즈캔슬링 헤드폰', '태블릿 펜'];
    const cats = ['입력장치', '디스플레이', '액세서리', '저장장치', '오디오'];
    return [
        { op: 'rename_system', name: '재고 관리', icon: '📦', description: '상품 재고·입출고·공급업체를 관리하는 운영 시스템' },
        {
            op: 'create_table', name: '공급업체', icon: '🏭',
            fields: [{ name: '업체명', type: 'text', primary: true }, { name: '담당자', type: 'person' }, { name: '연락처', type: 'phone' }, { name: '리드타임(일)', type: 'number' }, { name: '평가', type: 'rating' }],
            records: ['테크서플라이', '디지털원', '하나전자', '스마트유통'].map((n, i) => ({ 업체명: n, 담당자: ['이정훈', '박소영', '김태호', '최다은'][i], 연락처: `031-${400 + i}-${2000 + i * 11}`, '리드타임(일)': 3 + i * 2, 평가: 5 - (i % 3) })),
        },
        {
            op: 'create_table', name: '상품', icon: '🛒',
            fields: [
                { name: '상품명', type: 'text', primary: true }, { name: 'SKU', type: 'text' }, { name: '카테고리', type: 'singleSelect', choices: cats },
                { name: '현재 재고', type: 'number' }, { name: '안전 재고', type: 'number' }, { name: '단가', type: 'currency' }, { name: '공급업체', type: 'link', link: '공급업체' },
                { name: '재고 상태', type: 'singleSelect', choices: [{ name: '정상', color: 'green' }, { name: '부족', color: 'amber' }, { name: '품절', color: 'red' }] },
                { name: '이미지', type: 'url' },
            ],
            records: items.map((n, i) => {
                const stock = Math.floor(r() * 120);
                const safe = 20 + Math.floor(r() * 20);
                return {
                    상품명: n, SKU: `SKU-${1000 + i * 7}`, 카테고리: cats[i % cats.length], '현재 재고': i % 5 === 3 ? 0 : stock, '안전 재고': safe,
                    단가: (Math.floor(r() * 30) + 1) * 10000, 공급업체: ['테크서플라이', '디지털원', '하나전자', '스마트유통'][i % 4],
                    '재고 상태': i % 5 === 3 ? '품절' : stock < safe ? '부족' : '정상', 이미지: `https://picsum.photos/seed/item${i}/400/300`,
                };
            }),
            views: [{ name: '상품 카탈로그', type: 'gallery', coverField: '이미지' }, { name: '재고 상태별', type: 'kanban', groupBy: '재고 상태' }],
        },
        {
            op: 'create_table', name: '입출고 내역', icon: '🔄',
            fields: [
                { name: '내역', type: 'text', primary: true }, { name: '상품', type: 'link', link: '상품' }, { name: '구분', type: 'singleSelect', choices: [{ name: '입고', color: 'blue' }, { name: '출고', color: 'orange' }] },
                { name: '수량', type: 'number' }, { name: '일자', type: 'date' }, { name: '처리자', type: 'person' },
            ],
            records: Array.from({ length: 24 }, (_, i) => {
                const kind = r() > 0.45 ? '출고' : '입고';
                const item = items[Math.floor(r() * items.length)];
                return { 내역: `${item} ${kind}`, 상품: item, 구분: kind, 수량: Math.floor(r() * 40) + 5, 일자: `-${Math.floor(r() * 120)}d`, 처리자: pick(r, PEOPLE) };
            }),
            views: [{ name: '입출고 캘린더', type: 'calendar', dateField: '일자' }, { name: '입출고 등록', type: 'form', formTitle: '입출고 등록' }],
        },
        {
            op: 'create_dashboard', name: '재고 현황', icon: '📊',
            widgets: [
                { type: 'kpi', title: '전체 상품', table: '상품', agg: 'count', color: 'blue' },
                { type: 'kpi', title: '총 재고 수량', table: '상품', agg: 'sum', field: '현재 재고', color: 'green' },
                { type: 'kpi', title: '부족 · 품절', table: '상품', agg: 'count', filters: [{ field: '재고 상태', op: 'neq', value: '정상' }], color: 'red' },
                { type: 'kpi', title: '이번 달 출고량', table: '입출고 내역', agg: 'sum', field: '수량', filters: [{ field: '구분', op: 'eq', value: '출고' }, { field: '일자', op: 'pastDays', value: 30 }], color: 'amber' },
                { type: 'hbar', title: '상품별 재고', table: '상품', agg: 'sum', field: '현재 재고', groupBy: '상품명', width: 2 },
                { type: 'donut', title: '카테고리 구성', table: '상품', agg: 'count', groupBy: '카테고리', width: 2 },
                { type: 'line', title: '월별 출고 수량', table: '입출고 내역', agg: 'sum', field: '수량', dateField: '일자', bucket: 'month', filters: [{ field: '구분', op: 'eq', value: '출고' }], width: 2 },
                { type: 'list', title: '발주 필요 상품', table: '상품', fields: ['상품명', '현재 재고', '안전 재고', '재고 상태'], filters: [{ field: '재고 상태', op: 'neq', value: '정상' }], width: 2 },
            ],
        },
        {
            op: 'create_workflow', name: '재고 부족 알림', description: '매일 재고 부족 상품을 찾아 구매팀에 발주 요청을 보냅니다.',
            schedule: { freq: 'daily', time: '10:00' },
            steps: [
                { type: 'filter', title: '부족 · 품절 상품 찾기', table: '상품', filters: [{ field: '재고 상태', op: 'neq', value: '정상' }] },
                { type: 'aiSummary', title: '발주 요청서 작성', prompt: '재고 부족 상품별 권장 발주 수량(안전재고의 2배 기준)과 공급업체를 표로 정리한 발주 요청서를 작성해줘' },
                { type: 'email', title: '구매팀에 발송', to: 'purchase@company.com', subject: '[발주 요청] 재고 부족 상품' },
            ],
        },
    ];
}

function marketing(): Op[] {
    const r = rng(41);
    const channels = ['인스타그램', '유튜브', '네이버 검색', '카카오', '이메일', '블로그'];
    const camps = ['봄 신상 런칭', '회원가입 이벤트', '브랜드 인지도', '리타겟팅', '뉴스레터 3월호', '인플루언서 협업', '여름 프로모션', '앱 설치 캠페인', '추석 기획전', '블랙프라이데이'];
    return [
        { op: 'rename_system', name: '마케팅 캠페인 허브', icon: '📣', description: '캠페인 성과와 콘텐츠 일정을 관리합니다.' },
        {
            op: 'create_table', name: '캠페인', icon: '🎯',
            fields: [
                { name: '캠페인명', type: 'text', primary: true }, { name: '채널', type: 'singleSelect', choices: channels },
                { name: '상태', type: 'singleSelect', choices: [{ name: '기획', color: 'gray' }, { name: '진행 중', color: 'blue' }, { name: '종료', color: 'green' }] },
                { name: '예산', type: 'currency' }, { name: '집행액', type: 'currency' }, { name: '노출수', type: 'number' }, { name: '클릭수', type: 'number' }, { name: '전환수', type: 'number' },
                { name: '시작일', type: 'date' }, { name: '담당자', type: 'person' },
            ],
            records: camps.map((c, i) => {
                const budget = (Math.floor(r() * 20) + 3) * 1_000_000;
                const imp = Math.floor(r() * 400000) + 20000;
                const clk = Math.floor(imp * (0.01 + r() * 0.04));
                return { 캠페인명: c, 채널: channels[i % channels.length], 상태: i < 6 ? '종료' : i < 9 ? '진행 중' : '기획', 예산: budget, 집행액: i < 9 ? Math.floor(budget * (0.6 + r() * 0.4)) : 0, 노출수: imp, 클릭수: clk, 전환수: Math.floor(clk * (0.02 + r() * 0.08)), 시작일: `-${(9 - i) * 18}d`, 담당자: pick(r, PEOPLE) };
            }),
            views: [{ name: '상태별', type: 'kanban', groupBy: '상태' }, { name: '캠페인 일정', type: 'calendar', dateField: '시작일' }],
        },
        {
            op: 'create_table', name: '콘텐츠 캘린더', icon: '🗓️',
            fields: [
                { name: '콘텐츠', type: 'text', primary: true }, { name: '채널', type: 'singleSelect', choices: channels }, { name: '게시일', type: 'date' },
                { name: '상태', type: 'singleSelect', choices: [{ name: '아이디어', color: 'gray' }, { name: '제작 중', color: 'amber' }, { name: '검수', color: 'purple' }, { name: '게시 완료', color: 'green' }] },
                { name: '작성자', type: 'person' }, { name: '썸네일', type: 'url' },
            ],
            records: Array.from({ length: 12 }, (_, i) => ({ 콘텐츠: pick(r, ['신제품 리뷰', '사용 팁 카드뉴스', '고객 인터뷰', '비하인드 영상', 'Q&A 라이브', '시즌 룩북']) + ` #${i + 1}`, 채널: pick(r, channels), 게시일: `${i - 4}d`.replace(/^(\d)/, '+$1'), 상태: pick(r, ['아이디어', '제작 중', '검수', '게시 완료']), 작성자: pick(r, PEOPLE), 썸네일: `https://picsum.photos/seed/content${i}/400/300` })),
            views: [{ name: '게시 캘린더', type: 'calendar', dateField: '게시일' }, { name: '콘텐츠 보드', type: 'gallery', coverField: '썸네일' }],
        },
        {
            op: 'create_dashboard', name: '캠페인 성과', icon: '📈',
            widgets: [
                { type: 'kpi', title: '총 집행액', table: '캠페인', agg: 'sum', field: '집행액', color: 'blue' },
                { type: 'kpi', title: '총 노출수', table: '캠페인', agg: 'sum', field: '노출수', color: 'purple' },
                { type: 'kpi', title: '총 클릭수', table: '캠페인', agg: 'sum', field: '클릭수', color: 'cyan' },
                { type: 'kpi', title: '총 전환수', table: '캠페인', agg: 'sum', field: '전환수', color: 'green' },
                { type: 'bar', title: '채널별 전환수', table: '캠페인', agg: 'sum', field: '전환수', groupBy: '채널', width: 2 },
                { type: 'donut', title: '채널별 집행액', table: '캠페인', agg: 'sum', field: '집행액', groupBy: '채널', width: 2 },
                { type: 'line', title: '월별 클릭수', table: '캠페인', agg: 'sum', field: '클릭수', dateField: '시작일', bucket: 'month', width: 2 },
                { type: 'list', title: '이번 주 게시 콘텐츠', table: '콘텐츠 캘린더', fields: ['콘텐츠', '채널', '게시일', '상태'], filters: [{ field: '게시일', op: 'withinDays', value: 7 }], width: 2 },
            ],
        },
        {
            op: 'create_workflow', name: '월간 캠페인 리포트', description: '매월 1일 캠페인 성과(CTR, CVR, CPA)를 분석해 보고합니다.',
            schedule: { freq: 'monthly', time: '09:00', dayOfMonth: 1 },
            steps: [
                { type: 'aiSummary', title: '성과 분석', prompt: '캠페인별 CTR(클릭/노출), CVR(전환/클릭), CPA(집행액/전환)를 계산해 표로 정리하고, 가장 효율 좋은 채널과 개선점을 제안해줘' },
                { type: 'email', title: '마케팅팀 발송', to: 'marketing@company.com', subject: '[월간] 캠페인 성과 리포트' },
            ],
        },
    ];
}

function finance(): Op[] {
    const r = rng(53);
    const cats = ['인건비', '임대료', '마케팅', '소프트웨어', '출장', '복리후생', '사무용품'];
    return [
        { op: 'rename_system', name: '경비 · 예산 관리', icon: '💰', description: '부서별 경비 신청과 예산 집행을 관리합니다.' },
        {
            op: 'create_table', name: '경비 신청', icon: '🧾',
            fields: [
                { name: '내역', type: 'text', primary: true }, { name: '카테고리', type: 'singleSelect', choices: cats }, { name: '금액', type: 'currency' },
                { name: '부서', type: 'singleSelect', choices: ['개발', '디자인', '마케팅', '영업', '경영지원'] }, { name: '신청자', type: 'person' }, { name: '사용일', type: 'date' },
                { name: '승인 상태', type: 'singleSelect', choices: [{ name: '대기', color: 'amber' }, { name: '승인', color: 'green' }, { name: '반려', color: 'red' }] },
                { name: '영수증', type: 'checkbox' },
            ],
            records: Array.from({ length: 26 }, () => {
                const c = pick(r, cats);
                return { 내역: `${c} - ${pick(r, ['3월분', '팀 행사', '구독료', '고객 미팅', '비품 구매', '세미나'])}`, 카테고리: c, 금액: (Math.floor(r() * 50) + 1) * 50000, 부서: pick(r, ['개발', '디자인', '마케팅', '영업', '경영지원']), 신청자: pick(r, PEOPLE), 사용일: `-${Math.floor(r() * 150)}d`, '승인 상태': pick(r, ['대기', '승인', '승인', '승인', '반려']), 영수증: r() > 0.2 };
            }),
            views: [{ name: '승인 보드', type: 'kanban', groupBy: '승인 상태' }, { name: '경비 신청서', type: 'form', formTitle: '경비 신청서', formDescription: '영수증을 꼭 첨부해 주세요.' }],
        },
        {
            op: 'create_table', name: '부서 예산', icon: '🏦',
            fields: [{ name: '부서', type: 'text', primary: true }, { name: '연간 예산', type: 'currency' }, { name: '집행률', type: 'percent' }, { name: '예산 담당', type: 'person' }],
            records: ['개발', '디자인', '마케팅', '영업', '경영지원'].map((d, i) => ({ 부서: d, '연간 예산': [300, 80, 200, 150, 100][i] * 1_000_000, 집행률: [62, 48, 81, 55, 40][i], '예산 담당': PEOPLE[i] })),
        },
        {
            op: 'create_dashboard', name: '재무 현황', icon: '💹',
            widgets: [
                { type: 'kpi', title: '승인된 경비', table: '경비 신청', agg: 'sum', field: '금액', filters: [{ field: '승인 상태', op: 'eq', value: '승인' }], color: 'green' },
                { type: 'kpi', title: '승인 대기', table: '경비 신청', agg: 'count', filters: [{ field: '승인 상태', op: 'eq', value: '대기' }], color: 'amber' },
                { type: 'kpi', title: '평균 경비', table: '경비 신청', agg: 'avg', field: '금액', color: 'blue' },
                { type: 'kpi', title: '총 연간 예산', table: '부서 예산', agg: 'sum', field: '연간 예산', color: 'purple' },
                { type: 'donut', title: '카테고리별 지출', table: '경비 신청', agg: 'sum', field: '금액', groupBy: '카테고리', width: 2 },
                { type: 'bar', title: '부서별 지출', table: '경비 신청', agg: 'sum', field: '금액', groupBy: '부서', width: 2 },
                { type: 'line', title: '월별 지출 추이', table: '경비 신청', agg: 'sum', field: '금액', dateField: '사용일', bucket: 'month', width: 2 },
                { type: 'list', title: '승인 대기 목록', table: '경비 신청', fields: ['내역', '신청자', '금액', '사용일'], filters: [{ field: '승인 상태', op: 'eq', value: '대기' }], width: 2 },
            ],
        },
        {
            op: 'create_workflow', name: '경비 승인 리마인더', description: '매주 금요일 승인 대기 중인 경비를 결재권자에게 알립니다.',
            schedule: { freq: 'weekly', time: '16:00', dayOfWeek: 5 },
            steps: [
                { type: 'filter', title: '승인 대기 경비 찾기', table: '경비 신청', filters: [{ field: '승인 상태', op: 'eq', value: '대기' }] },
                { type: 'email', title: '결재권자에게 알림', to: 'finance@company.com', subject: '[리마인더] 승인 대기 경비' },
            ],
        },
    ];
}

function support(): Op[] {
    const r = rng(61);
    const cats = ['결제', '로그인', '배송', '버그', '기능 요청', '환불'];
    return [
        { op: 'rename_system', name: '고객 문의 관리', icon: '🎧', description: '고객 문의 티켓과 처리 현황(SLA)을 관리합니다.' },
        {
            op: 'create_table', name: '문의 티켓', icon: '🎫',
            fields: [
                { name: '제목', type: 'text', primary: true }, { name: '고객', type: 'text' }, { name: '이메일', type: 'email' }, { name: '유형', type: 'singleSelect', choices: cats },
                { name: '우선순위', type: 'singleSelect', choices: [{ name: '긴급', color: 'red' }, { name: '높음', color: 'orange' }, { name: '보통', color: 'blue' }, { name: '낮음', color: 'gray' }] },
                { name: '상태', type: 'singleSelect', choices: [{ name: '신규', color: 'cyan' }, { name: '처리 중', color: 'blue' }, { name: '답변 대기', color: 'amber' }, { name: '해결', color: 'green' }] },
                { name: '담당자', type: 'person' }, { name: '접수일', type: 'date' }, { name: '만족도', type: 'rating' }, { name: '내용', type: 'longText' },
            ],
            records: Array.from({ length: 20 }, (_, i) => {
                const c = pick(r, cats);
                const st = pick(r, ['신규', '처리 중', '답변 대기', '해결', '해결']);
                return { 제목: `${c} 관련 문의 #${1040 + i}`, 고객: pick(r, ['김하나', '이두리', '박세찬', '최나래', '정가람', '한별']), 이메일: `user${i}@mail.com`, 유형: c, 우선순위: pick(r, ['긴급', '높음', '보통', '보통', '낮음']), 상태: st, 담당자: pick(r, PEOPLE.slice(2)), 접수일: `-${Math.floor(r() * 45)}d`, 만족도: st === '해결' ? Math.floor(r() * 2) + 4 : null, 내용: '고객 문의 상세 내용입니다.' };
            }),
            views: [{ name: '티켓 보드', type: 'kanban', groupBy: '상태' }, { name: '문의 접수', type: 'form', formTitle: '고객 문의하기', formDescription: '문의 내용을 남겨주시면 빠르게 답변드릴게요.' }],
        },
        {
            op: 'create_dashboard', name: 'CS 현황', icon: '📊',
            widgets: [
                { type: 'kpi', title: '미해결 티켓', table: '문의 티켓', agg: 'count', filters: [{ field: '상태', op: 'neq', value: '해결' }], color: 'red' },
                { type: 'kpi', title: '해결된 티켓', table: '문의 티켓', agg: 'count', filters: [{ field: '상태', op: 'eq', value: '해결' }], color: 'green' },
                { type: 'kpi', title: '평균 만족도', table: '문의 티켓', agg: 'avg', field: '만족도', color: 'amber' },
                { type: 'kpi', title: '최근 7일 접수', table: '문의 티켓', agg: 'count', filters: [{ field: '접수일', op: 'pastDays', value: 7 }], color: 'blue' },
                { type: 'bar', title: '유형별 문의', table: '문의 티켓', agg: 'count', groupBy: '유형', width: 2 },
                { type: 'donut', title: '상태별 티켓', table: '문의 티켓', agg: 'count', groupBy: '상태', width: 2 },
                { type: 'line', title: '주별 접수 추이', table: '문의 티켓', agg: 'count', dateField: '접수일', bucket: 'week', width: 2 },
                { type: 'list', title: '긴급 미해결 티켓', table: '문의 티켓', fields: ['제목', '담당자', '접수일'], filters: [{ field: '우선순위', op: 'eq', value: '긴급' }, { field: '상태', op: 'neq', value: '해결' }], width: 2 },
            ],
        },
        {
            op: 'create_workflow', name: 'SLA 초과 티켓 에스컬레이션', description: '매시간 3일 이상 미해결 티켓을 긴급으로 올립니다.',
            schedule: { freq: 'hourly', time: '00:00' },
            steps: [
                { type: 'filter', title: '3일 초과 미해결 티켓', table: '문의 티켓', filters: [{ field: '접수일', op: 'lt', value: '-3d' }, { field: '상태', op: 'neq', value: '해결' }] },
                { type: 'update', title: '우선순위 긴급으로', table: '문의 티켓', filters: [{ field: '접수일', op: 'lt', value: '-3d' }, { field: '상태', op: 'neq', value: '해결' }], set: { 우선순위: '긴급' } },
            ],
        },
    ];
}

function event(): Op[] {
    const r = rng(71);
    return [
        { op: 'rename_system', name: '행사 · 이벤트 운영', icon: '🎪', description: '행사 참가자 등록과 일정, 체크인을 관리합니다.' },
        {
            op: 'create_table', name: '세션', icon: '🎤',
            fields: [{ name: '세션명', type: 'text', primary: true }, { name: '연사', type: 'person' }, { name: '일시', type: 'date' }, { name: '장소', type: 'singleSelect', choices: ['메인홀', '세미나룸 A', '세미나룸 B'] }, { name: '정원', type: 'number' }],
            records: ['오프닝 키노트', 'AI 트렌드 2026', '데이터 기반 의사결정', '스타트업 성장 전략', '네트워킹 세션', '클로징 패널'].map((n, i) => ({ 세션명: n, 연사: pick(r, ['정재승', '김은희', '박현우', '이수진']), 일시: `+${14 + Math.floor(i / 3)}d`, 장소: pick(r, ['메인홀', '세미나룸 A', '세미나룸 B']), 정원: [300, 120, 80, 80, 200, 300][i] })),
            views: [{ name: '세션 일정', type: 'calendar', dateField: '일시' }],
        },
        {
            op: 'create_table', name: '참가자', icon: '🙋',
            fields: [
                { name: '이름', type: 'text', primary: true }, { name: '소속', type: 'text' }, { name: '이메일', type: 'email' },
                { name: '티켓', type: 'singleSelect', choices: [{ name: '얼리버드', color: 'cyan' }, { name: '일반', color: 'blue' }, { name: 'VIP', color: 'purple' }] },
                { name: '관심 세션', type: 'multiSelect', choices: ['AI 트렌드 2026', '데이터 기반 의사결정', '스타트업 성장 전략'] }, { name: '결제 금액', type: 'currency' },
                { name: '체크인', type: 'checkbox' }, { name: '등록일', type: 'date' },
            ],
            records: Array.from({ length: 18 }, (_, i) => {
                const t = pick(r, ['얼리버드', '일반', '일반', 'VIP']);
                return { 이름: pick(r, ['김', '이', '박', '최', '정', '강', '조', '윤']) + pick(r, ['서준', '하은', '도현', '지유', '시우', '수아', '예준', '지안']), 소속: pick(r, ['네이버', '카카오', '토스', '당근', '쿠팡', '스타트업']), 이메일: `guest${i}@mail.com`, 티켓: t, '관심 세션': [pick(r, ['AI 트렌드 2026', '데이터 기반 의사결정', '스타트업 성장 전략'])], '결제 금액': { 얼리버드: 49000, 일반: 79000, VIP: 199000 }[t], 체크인: false, 등록일: `-${Math.floor(r() * 40)}d` };
            }),
            views: [{ name: '참가 신청', type: 'form', formTitle: '행사 참가 신청', formDescription: '자리가 한정되어 있으니 서둘러 신청해 주세요!' }, { name: '티켓별', type: 'kanban', groupBy: '티켓' }],
        },
        {
            op: 'create_dashboard', name: '행사 현황', icon: '🎟️',
            widgets: [
                { type: 'kpi', title: '총 참가자', table: '참가자', agg: 'count', color: 'blue' },
                { type: 'kpi', title: '티켓 매출', table: '참가자', agg: 'sum', field: '결제 금액', color: 'green' },
                { type: 'kpi', title: 'VIP', table: '참가자', agg: 'count', filters: [{ field: '티켓', op: 'eq', value: 'VIP' }], color: 'purple' },
                { type: 'kpi', title: '세션 수', table: '세션', agg: 'count', color: 'amber' },
                { type: 'donut', title: '티켓 구성', table: '참가자', agg: 'count', groupBy: '티켓', width: 2 },
                { type: 'bar', title: '관심 세션', table: '참가자', agg: 'count', groupBy: '관심 세션', width: 2 },
                { type: 'line', title: '주별 등록 추이', table: '참가자', agg: 'count', dateField: '등록일', bucket: 'week', width: 2 },
                { type: 'list', title: '세션 일정', table: '세션', fields: ['세션명', '연사', '일시', '장소'], width: 2 },
            ],
        },
        {
            op: 'create_workflow', name: '등록 현황 일일 보고', description: '매일 저녁 신규 등록과 매출을 요약합니다.',
            schedule: { freq: 'daily', time: '18:00' },
            steps: [
                { type: 'filter', title: '최근 1일 등록자', table: '참가자', filters: [{ field: '등록일', op: 'pastDays', value: 1 }] },
                { type: 'aiSummary', title: '등록 현황 요약', prompt: '오늘 신규 등록, 누적 참가자와 티켓 매출, 티켓 유형별 비중을 요약해줘' },
                { type: 'email', title: '운영팀 발송', to: 'event@company.com', subject: '[일일] 행사 등록 현황' },
            ],
        },
    ];
}

export const TEMPLATES: Template[] = [
    { id: 'crm', category: '영업 · CRM', name: '영업 CRM', icon: '🤝', color: 'blue', description: '고객사, 영업 기회 파이프라인, 활동 기록과 영업 대시보드', highlights: ['파이프라인 칸반', '마감 캘린더', '주간 리포트 자동화'], ops: crm },
    { id: 'hr', category: '인사 · HR', name: '채용 · 인사 관리', icon: '🧑‍💼', color: 'purple', description: '채용 공고, 지원자 파이프라인, 직원 디렉토리', highlights: ['지원서 양식', '면접 캘린더', '면접 알림'], ops: hr },
    { id: 'project', category: '프로젝트', name: '프로젝트 트래커', icon: '🚀', color: 'cyan', description: '프로젝트·작업·담당자·마감 관리와 지연 작업 자동 점검', highlights: ['스프린트 보드', '지연 작업 감지', '작업 요청서'], ops: project },
    { id: 'inventory', category: '운영 · 재고', name: '재고 관리', icon: '📦', color: 'amber', description: '상품 카탈로그, 입출고, 공급업체, 재고 부족 알림', highlights: ['상품 갤러리', '발주 필요 목록', '재고 부족 알림'], ops: inventory },
    { id: 'support', category: '운영 · 재고', name: '고객 문의 관리', icon: '🎧', color: 'teal', description: '문의 티켓 접수·배정·SLA 관리', highlights: ['문의 접수 양식', '티켓 보드', 'SLA 에스컬레이션'], ops: support },
    { id: 'marketing', category: '마케팅', name: '마케팅 캠페인 허브', icon: '📣', color: 'pink', description: '캠페인 성과 추적과 콘텐츠 캘린더', highlights: ['채널별 성과', '콘텐츠 캘린더', '월간 리포트'], ops: marketing },
    { id: 'event', category: '마케팅', name: '행사 · 이벤트 운영', icon: '🎪', color: 'orange', description: '참가 신청, 세션 일정, 티켓 매출 관리', highlights: ['참가 신청 양식', '세션 캘린더', '일일 등록 보고'], ops: event },
    { id: 'finance', category: '재무', name: '경비 · 예산 관리', icon: '💰', color: 'green', description: '경비 신청·승인과 부서별 예산 집행 현황', highlights: ['경비 신청서', '승인 보드', '승인 리마인더'], ops: finance },
];
