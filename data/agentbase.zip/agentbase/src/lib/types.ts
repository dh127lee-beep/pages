export type FieldType =
    | 'text'
    | 'longText'
    | 'number'
    | 'currency'
    | 'percent'
    | 'date'
    | 'singleSelect'
    | 'multiSelect'
    | 'checkbox'
    | 'email'
    | 'phone'
    | 'url'
    | 'rating'
    | 'person'
    | 'link';

export const FIELD_TYPES: { type: FieldType; label: string }[] = [
    { type: 'text', label: '텍스트' },
    { type: 'longText', label: '긴 텍스트' },
    { type: 'number', label: '숫자' },
    { type: 'currency', label: '통화' },
    { type: 'percent', label: '퍼센트' },
    { type: 'date', label: '날짜' },
    { type: 'singleSelect', label: '단일 선택' },
    { type: 'multiSelect', label: '다중 선택' },
    { type: 'checkbox', label: '체크박스' },
    { type: 'email', label: '이메일' },
    { type: 'phone', label: '전화번호' },
    { type: 'url', label: 'URL' },
    { type: 'rating', label: '평점' },
    { type: 'person', label: '담당자' },
    { type: 'link', label: '테이블 연결' },
];

export const CHOICE_COLORS = ['blue', 'green', 'amber', 'red', 'purple', 'pink', 'cyan', 'orange', 'gray', 'teal'] as const;
export type ChoiceColor = (typeof CHOICE_COLORS)[number];

export interface Choice {
    name: string;
    color: ChoiceColor;
}

export interface Field {
    id: string;
    name: string;
    type: FieldType;
    choices?: Choice[];
    /** link: id of the linked table. Cell value is an array of record ids. */
    linkTableId?: string;
    /** link target named before that table existed; resolved by ops */
    linkTableName?: string;
    /** currency symbol, e.g. "₩" or "$" */
    symbol?: string;
    primary?: boolean;
}

export type CellValue = string | number | boolean | string[] | null;

export interface RecordRow {
    id: string;
    cells: Record<string, CellValue>;
    createdAt: string;
}

export type ViewType = 'grid' | 'kanban' | 'gallery' | 'calendar' | 'form';

export type FilterOp = 'eq' | 'neq' | 'contains' | 'gt' | 'gte' | 'lt' | 'lte' | 'empty' | 'notEmpty' | 'withinDays' | 'pastDays' | 'overdue';

export interface Filter {
    fieldId: string;
    op: FilterOp;
    value?: CellValue;
}

export interface View {
    id: string;
    name: string;
    type: ViewType;
    groupByFieldId?: string;
    dateFieldId?: string;
    coverFieldId?: string;
    filters?: Filter[];
    sort?: { fieldId: string; dir: 'asc' | 'desc' };
    hiddenFieldIds?: string[];
    formTitle?: string;
    formDescription?: string;
}

export interface Table {
    id: string;
    name: string;
    icon: string;
    description?: string;
    fields: Field[];
    records: RecordRow[];
    views: View[];
}

export type WidgetType = 'kpi' | 'bar' | 'hbar' | 'line' | 'donut' | 'list';
export type Agg = 'count' | 'sum' | 'avg' | 'min' | 'max';

export interface Widget {
    id: string;
    type: WidgetType;
    title: string;
    tableId: string;
    agg: Agg;
    /** numeric field for sum/avg/min/max */
    valueFieldId?: string;
    /** category field (bar/hbar/donut) */
    groupByFieldId?: string;
    /** date field (line) — bucketed by month or week */
    dateFieldId?: string;
    bucket?: 'day' | 'week' | 'month';
    filters?: Filter[];
    /** list: fields to show, max rows */
    fieldIds?: string[];
    limit?: number;
    /** grid width out of 4 */
    width?: 1 | 2 | 3 | 4;
    color?: ChoiceColor;
}

export interface Dashboard {
    id: string;
    name: string;
    icon: string;
    description?: string;
    widgets: Widget[];
}

export type WorkflowStepType = 'filter' | 'update' | 'aiSummary' | 'email';

export interface WorkflowStep {
    id: string;
    type: WorkflowStepType;
    title: string;
    tableId?: string;
    filters?: Filter[];
    /** update: field → value */
    set?: Record<string, CellValue>;
    /** aiSummary: instruction */
    prompt?: string;
    /** email */
    to?: string;
    subject?: string;
}

export interface WorkflowRun {
    id: string;
    at: string;
    test: boolean;
    status: 'success' | 'error';
    log: string[];
    output?: string;
}

export interface Workflow {
    id: string;
    name: string;
    description?: string;
    enabled: boolean;
    schedule: { freq: 'daily' | 'weekly' | 'monthly' | 'hourly'; time: string; dayOfWeek?: number; dayOfMonth?: number; timezone: string };
    steps: WorkflowStep[];
    runs: WorkflowRun[];
    nextRunAt?: string;
}

export interface ChatMessage {
    id: string;
    role: 'user' | 'assistant';
    content: string;
    /** human-readable list of what the agent changed */
    actions?: string[];
    at: string;
}

export interface Share {
    email: string;
    role: 'viewer' | 'editor' | 'owner';
    scope: 'workspace' | string;
}

export interface System {
    id: string;
    name: string;
    icon: string;
    color: ChoiceColor;
    description?: string;
    tables: Table[];
    dashboards: Dashboard[];
    workflows: Workflow[];
    chat: ChatMessage[];
    shares: Share[];
    createdAt: string;
    updatedAt: string;
}

export interface SystemSummary {
    id: string;
    name: string;
    icon: string;
    color: ChoiceColor;
    description?: string;
    tables: number;
    records: number;
    dashboards: number;
    workflows: number;
    updatedAt: string;
}
