import 'server-only';

/** Any OpenAI-compatible endpoint. Defaults to the local Claude CLI API. */
export const LLM_URL = (process.env.AGENTBASE_AI_BASE_URL ?? 'http://127.0.0.1:8899/v1').replace(/\/$/, '');
export const LLM_KEY = process.env.AGENTBASE_AI_API_KEY ?? 'dummy';
export const LLM_MODEL = process.env.AGENTBASE_AI_MODEL ?? 'sonnet';

export interface LlmMessage {
    role: 'system' | 'user' | 'assistant';
    content: string;
}

export class LlmError extends Error {}

/** Streams completion text; calls onDelta for every chunk and resolves with the full text. */
export async function streamChat(messages: LlmMessage[], onDelta: (t: string) => void, opts: { model?: string; signal?: AbortSignal } = {}): Promise<string> {
    let res: Response;
    try {
        res = await fetch(`${LLM_URL}/chat/completions`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${LLM_KEY}` },
            body: JSON.stringify({ model: opts.model ?? LLM_MODEL, messages, stream: true }),
            signal: opts.signal,
        });
    } catch (e) {
        throw new LlmError(`AI 서버(${LLM_URL})에 연결할 수 없습니다: ${(e as Error).message}`);
    }
    if (!res.ok || !res.body) {
        const body = await res.text().catch(() => '');
        throw new LlmError(`AI 서버 오류 ${res.status}: ${body.slice(0, 300)}`);
    }
    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buf = '';
    let full = '';
    for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        buf += decoder.decode(value, { stream: true });
        let i: number;
        while ((i = buf.indexOf('\n')) >= 0) {
            const line = buf.slice(0, i).trim();
            buf = buf.slice(i + 1);
            if (!line.startsWith('data:')) continue;
            const data = line.slice(5).trim();
            if (data === '[DONE]') continue;
            try {
                const j = JSON.parse(data);
                const delta: string = j.choices?.[0]?.delta?.content ?? j.choices?.[0]?.message?.content ?? '';
                if (delta) {
                    full += delta;
                    onDelta(delta);
                }
                if (j.error) throw new LlmError(String(j.error.message ?? j.error));
            } catch (e) {
                if (e instanceof LlmError) throw e;
            }
        }
    }
    return full;
}

export async function chat(messages: LlmMessage[], opts: { model?: string } = {}): Promise<string> {
    return streamChat(messages, () => {}, opts);
}
