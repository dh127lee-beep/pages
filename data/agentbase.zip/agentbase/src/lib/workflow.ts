import 'server-only';
import { nanoid } from 'nanoid';
import { applyFilters, cellText, nextRunAt, recordTitle, todayISO } from './data';
import { chat } from './llm';
import { describeSystem } from './agent';
import { getSystem, listSystems, withSystem } from './store';
import type { RecordRow, System, Table, WorkflowRun } from './types';

function listText(s: System, t: Table, rows: RecordRow[]): string {
    const cols = t.fields.slice(0, 5);
    return rows
        .slice(0, 30)
        .map((r) => `- ${recordTitle(t, r)} · ${cols.slice(1).map((f) => cellText(f, r.cells[f.id], s)).filter(Boolean).join(' · ')}`)
        .join('\n');
}

/** Runs a workflow. Test runs simulate side effects (no record updates, emails stay drafts). */
export async function runWorkflow(systemId: string, workflowId: string, test: boolean): Promise<WorkflowRun | null> {
    const s = await getSystem(systemId);
    const wf = s?.workflows.find((w) => w.id === workflowId);
    if (!s || !wf) return null;

    const log: string[] = [];
    let output = '';
    let status: WorkflowRun['status'] = 'success';
    const updates: { tableId: string; ids: string[]; set: Record<string, unknown> }[] = [];

    try {
        for (const [i, step] of wf.steps.entries()) {
            const n = i + 1;
            const t = s.tables.find((x) => x.id === step.tableId);
            if (step.type === 'filter') {
                if (!t) throw new Error(`${n}단계: 테이블이 없습니다`);
                const rows = applyFilters(t, t.records, step.filters);
                log.push(`${n}. ${step.title} — '${t.name}'에서 ${rows.length}건 발견`);
                output = rows.length ? `**${step.title}** (${rows.length}건)\n${listText(s, t, rows)}` : `**${step.title}** — 해당 항목이 없습니다.`;
            } else if (step.type === 'update') {
                if (!t) throw new Error(`${n}단계: 테이블이 없습니다`);
                const rows = applyFilters(t, t.records, step.filters);
                updates.push({ tableId: t.id, ids: rows.map((r) => r.id), set: step.set ?? {} });
                const what = Object.entries(step.set ?? {})
                    .map(([fid, v]) => `${t.fields.find((f) => f.id === fid)?.name ?? fid}=${Array.isArray(v) ? v.join(',') : v}`)
                    .join(', ');
                log.push(`${n}. ${step.title} — ${rows.length}건 ${test ? '수정 예정 (테스트: 적용 안 함)' : '수정'} [${what}]`);
            } else if (step.type === 'aiSummary') {
                log.push(`${n}. ${step.title} — AI 보고서 작성 중`);
                output = await chat([
                    {
                        role: 'system',
                        content: 'You are an operations analyst. Write a concise report in Korean markdown (headings, bullets, exact numbers from the data). No preamble.',
                    },
                    {
                        role: 'user',
                        content: `Today is ${todayISO()}.\n\nDATA:\n${describeSystem(s)}\n\n${output ? `PREVIOUS STEP OUTPUT:\n${output}\n\n` : ''}TASK: ${step.prompt ?? step.title}`,
                    },
                ]);
                log.push(`   ↳ 보고서 ${output.length}자 생성`);
            } else if (step.type === 'email') {
                log.push(`${n}. ${step.title} — 받는 사람 ${step.to ?? '(미지정)'}: 메일함이 연결되지 않아 초안으로 저장`);
                output = `**To:** ${step.to ?? '-'}\n**Subject:** ${step.subject ?? wf.name}\n\n${output || '(본문 없음)'}`;
            }
        }
    } catch (e) {
        status = 'error';
        log.push(`❌ ${(e as Error).message}`);
    }

    const run: WorkflowRun = { id: nanoid(8), at: new Date().toISOString(), test, status, log, output };
    await withSystem(systemId, (cur) => {
        const w = cur.workflows.find((x) => x.id === workflowId);
        if (!w) return;
        if (!test && status === 'success') {
            for (const u of updates) {
                const t = cur.tables.find((x) => x.id === u.tableId);
                for (const r of t?.records ?? []) if (u.ids.includes(r.id)) Object.assign(r.cells, u.set);
            }
        }
        w.runs = [run, ...w.runs].slice(0, 20);
        if (!test) w.nextRunAt = nextRunAt(w.schedule);
    });
    return run;
}

const g = globalThis as unknown as { __agentbaseScheduler?: NodeJS.Timeout; __agentbaseRunning?: Set<string> };

/** Polls every 30s and fires enabled workflows whose next run time has passed. */
export function startScheduler() {
    if (g.__agentbaseScheduler) return;
    g.__agentbaseRunning = new Set();
    g.__agentbaseScheduler = setInterval(async () => {
        try {
            const now = Date.now();
            for (const s of await listSystems()) {
                for (const w of s.workflows) {
                    const key = `${s.id}/${w.id}`;
                    if (!w.enabled || !w.nextRunAt || Date.parse(w.nextRunAt) > now || g.__agentbaseRunning!.has(key)) continue;
                    g.__agentbaseRunning!.add(key);
                    runWorkflow(s.id, w.id, false)
                        .catch((e) => console.error('[agentbase] workflow failed', key, e))
                        .finally(() => g.__agentbaseRunning!.delete(key));
                }
            }
        } catch (e) {
            console.error('[agentbase] scheduler', e);
        }
    }, 30_000);
}
