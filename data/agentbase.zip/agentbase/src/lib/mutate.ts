import { nanoid } from 'nanoid';
import { nextRunAt } from './data';
import { coerce, defaultViewName } from './ops';
import { CHOICE_COLORS, type CellValue, type Field, type FieldType, type Share, type System, type View, type Widget, type Workflow } from './types';

/** Direct, id-based edits from the UI (the agent uses name-based ops instead). */
/* eslint-disable @typescript-eslint/no-explicit-any */
export type Mutation = { action: string; [k: string]: any };

export function mutate(s: System, m: Mutation): unknown {
    const table = m.tableId ? s.tables.find((t) => t.id === m.tableId) : undefined;
    const needTable = () => {
        if (!table) throw new Error('테이블을 찾을 수 없습니다');
        return table;
    };
    switch (m.action) {
        case 'renameSystem':
            if (m.name) s.name = String(m.name);
            if (m.icon) s.icon = String(m.icon);
            if (m.description !== undefined) s.description = String(m.description);
            return null;
        case 'setCell': {
            const t = needTable();
            const r = t.records.find((x) => x.id === m.recordId);
            const f = t.fields.find((x) => x.id === m.fieldId);
            if (!r || !f) throw new Error('셀을 찾을 수 없습니다');
            r.cells[f.id] = f.type === 'link' ? (Array.isArray(m.value) && m.value.length ? m.value : null) : coerce(s, f, m.value);
            return r;
        }
        case 'addRecord': {
            const t = needTable();
            const cells: Record<string, CellValue> = {};
            for (const [fid, v] of Object.entries(m.cells ?? {})) {
                const f = t.fields.find((x) => x.id === fid);
                if (f) cells[fid] = f.type === 'link' ? (v as CellValue) : coerce(s, f, v);
            }
            const rec = { id: `rec${nanoid(10)}`, cells, createdAt: new Date().toISOString() };
            t.records.push(rec);
            return rec;
        }
        case 'deleteRecords': {
            const t = needTable();
            const ids = new Set<string>(m.ids ?? []);
            t.records = t.records.filter((r) => !ids.has(r.id));
            return null;
        }
        case 'addTable': {
            const t = {
                id: `tbl${nanoid(8)}`,
                name: String(m.name ?? '새 테이블'),
                icon: String(m.icon ?? '📋'),
                fields: [
                    { id: `fld${nanoid(8)}`, name: '이름', type: 'text' as FieldType, primary: true },
                    { id: `fld${nanoid(8)}`, name: '메모', type: 'longText' as FieldType },
                ],
                records: [],
                views: [{ id: `viw${nanoid(8)}`, name: '전체 그리드', type: 'grid' as const }],
            };
            s.tables.push(t);
            return t;
        }
        case 'updateTable': {
            const t = needTable();
            if (m.name) t.name = String(m.name);
            if (m.icon) t.icon = String(m.icon);
            return null;
        }
        case 'deleteTable':
            s.tables = s.tables.filter((t) => t.id !== m.tableId);
            for (const d of s.dashboards) d.widgets = d.widgets.filter((w) => w.tableId !== m.tableId);
            return null;
        case 'addField': {
            const t = needTable();
            const f: Field = { id: `fld${nanoid(8)}`, name: String(m.name ?? '새 필드'), type: (m.type ?? 'text') as FieldType };
            if (f.type === 'singleSelect' || f.type === 'multiSelect') f.choices = (m.choices ?? []).map((c: string, i: number) => ({ name: c, color: CHOICE_COLORS[i % CHOICE_COLORS.length] }));
            if (f.type === 'currency') f.symbol = '₩';
            if (f.type === 'link') f.linkTableId = m.linkTableId;
            t.fields.push(f);
            return f;
        }
        case 'updateField': {
            const t = needTable();
            const f = t.fields.find((x) => x.id === m.fieldId);
            if (!f) throw new Error('필드를 찾을 수 없습니다');
            if (m.name) f.name = String(m.name);
            if (m.choices) f.choices = m.choices;
            if (m.type && m.type !== f.type) {
                f.type = m.type;
                if ((f.type === 'singleSelect' || f.type === 'multiSelect') && !f.choices) f.choices = [];
                if (f.type === 'link') f.linkTableId = m.linkTableId;
                for (const r of t.records) {
                    const v = r.cells[f.id];
                    r.cells[f.id] = f.type === 'link' ? null : coerce(s, f, Array.isArray(v) ? v.join(',') : v);
                }
            }
            return f;
        }
        case 'deleteField': {
            const t = needTable();
            const f = t.fields.find((x) => x.id === m.fieldId);
            if (!f || t.fields.length <= 1) return null;
            t.fields = t.fields.filter((x) => x !== f);
            if (f.primary) t.fields[0].primary = true;
            for (const r of t.records) delete r.cells[f.id];
            return null;
        }
        case 'addView': {
            const t = needTable();
            const type = m.type as View['type'];
            const v: View = { id: `viw${nanoid(8)}`, name: m.name ?? defaultViewName(type), type };
            if (type === 'kanban') v.groupByFieldId = t.fields.find((f) => f.type === 'singleSelect')?.id;
            if (type === 'calendar') v.dateFieldId = t.fields.find((f) => f.type === 'date')?.id;
            if (type === 'gallery') v.coverFieldId = t.fields.find((f) => f.type === 'url' && /이미지|사진|썸네일|image|photo|cover/i.test(f.name))?.id;
            if (type === 'form') v.formTitle = t.name;
            t.views.push(v);
            return v;
        }
        case 'updateView': {
            const t = needTable();
            const v = t.views.find((x) => x.id === m.viewId);
            if (!v) throw new Error('뷰를 찾을 수 없습니다');
            Object.assign(v, m.patch ?? {});
            return v;
        }
        case 'deleteView': {
            const t = needTable();
            if (t.views.length > 1) t.views = t.views.filter((v) => v.id !== m.viewId);
            return null;
        }
        case 'addDashboard': {
            const d = { id: `dsh${nanoid(8)}`, name: String(m.name ?? '새 대시보드'), icon: '📊', widgets: [] as Widget[] };
            s.dashboards.push(d);
            return d;
        }
        case 'updateDashboard': {
            const d = s.dashboards.find((x) => x.id === m.dashboardId);
            if (!d) throw new Error('대시보드를 찾을 수 없습니다');
            if (m.name) d.name = String(m.name);
            if (m.icon) d.icon = String(m.icon);
            if (Array.isArray(m.widgetOrder)) d.widgets.sort((a, b) => m.widgetOrder.indexOf(a.id) - m.widgetOrder.indexOf(b.id));
            return d;
        }
        case 'deleteDashboard':
            s.dashboards = s.dashboards.filter((d) => d.id !== m.dashboardId);
            return null;
        case 'addWidget': {
            const d = s.dashboards.find((x) => x.id === m.dashboardId);
            if (!d) throw new Error('대시보드를 찾을 수 없습니다');
            const w: Widget = { id: `wdg${nanoid(8)}`, width: 1, agg: 'count', ...m.widget };
            d.widgets.push(w);
            return w;
        }
        case 'updateWidget': {
            const d = s.dashboards.find((x) => x.id === m.dashboardId);
            const w = d?.widgets.find((x) => x.id === m.widgetId);
            if (!w) throw new Error('위젯을 찾을 수 없습니다');
            Object.assign(w, m.patch ?? {});
            return w;
        }
        case 'deleteWidget': {
            const d = s.dashboards.find((x) => x.id === m.dashboardId);
            if (d) d.widgets = d.widgets.filter((w) => w.id !== m.widgetId);
            return null;
        }
        case 'updateWorkflow': {
            const w = s.workflows.find((x) => x.id === m.workflowId);
            if (!w) throw new Error('워크플로를 찾을 수 없습니다');
            const patch = (m.patch ?? {}) as Partial<Workflow>;
            if (patch.name !== undefined) w.name = patch.name;
            if (patch.enabled !== undefined) w.enabled = patch.enabled;
            if (patch.schedule) w.schedule = { ...w.schedule, ...patch.schedule };
            if (patch.steps) w.steps = patch.steps;
            w.nextRunAt = nextRunAt(w.schedule);
            return w;
        }
        case 'deleteWorkflow':
            s.workflows = s.workflows.filter((w) => w.id !== m.workflowId);
            return null;
        case 'addShare': {
            const email = String(m.email ?? '').trim().toLowerCase();
            if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) throw new Error('올바른 이메일을 입력하세요');
            const share: Share = { email, role: m.role ?? 'viewer', scope: m.scope ?? 'workspace' };
            s.shares = [...s.shares.filter((x) => !(x.email === email && x.scope === share.scope)), share];
            return share;
        }
        case 'removeShare':
            s.shares = s.shares.filter((x) => !(x.email === m.email && x.scope === m.scope));
            return null;
        case 'clearChat':
            s.chat = [];
            return null;
        default:
            throw new Error(`알 수 없는 작업: ${m.action}`);
    }
}
