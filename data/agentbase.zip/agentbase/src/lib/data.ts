import type { CellValue, Field, Filter, RecordRow, System, Table, Widget, Workflow } from './types';

export const DAY = 86_400_000;

export function todayISO(): string {
    return new Date().toISOString().slice(0, 10);
}

export function primaryField(t: Table): Field | undefined {
    return t.fields.find((f) => f.primary) ?? t.fields[0];
}

export function recordTitle(t: Table, r: RecordRow): string {
    const f = primaryField(t);
    const v = f ? r.cells[f.id] : null;
    return v === null || v === undefined || v === '' ? '이름 없음' : String(v);
}

export function toNumber(v: CellValue | undefined): number | null {
    if (v === null || v === undefined || v === '') return null;
    if (typeof v === 'number') return v;
    if (typeof v === 'boolean') return v ? 1 : 0;
    const n = Number(String(v).replace(/[^0-9.\-]/g, ''));
    return Number.isFinite(n) ? n : null;
}

function dateMs(v: CellValue | undefined): number | null {
    if (!v || typeof v !== 'string') return null;
    const t = Date.parse(v.length === 10 ? `${v}T00:00:00` : v);
    return Number.isFinite(t) ? t : null;
}

function startOfToday(): number {
    const d = new Date();
    d.setHours(0, 0, 0, 0);
    return d.getTime();
}

export function matchFilter(field: Field | undefined, r: RecordRow, f: Filter): boolean {
    if (!field) return true;
    const v = r.cells[field.id];
    const isEmpty = v === null || v === undefined || v === '' || (Array.isArray(v) && v.length === 0) || v === false;
    switch (f.op) {
        case 'empty':
            return isEmpty;
        case 'notEmpty':
            return !isEmpty;
        case 'eq':
            if (Array.isArray(v)) return v.includes(String(f.value));
            if (field.type === 'checkbox') return Boolean(v) === Boolean(f.value);
            return String(v ?? '').toLowerCase() === String(f.value ?? '').toLowerCase();
        case 'neq':
            if (Array.isArray(v)) return !v.includes(String(f.value));
            if (field.type === 'checkbox') return Boolean(v) !== Boolean(f.value);
            return String(v ?? '').toLowerCase() !== String(f.value ?? '').toLowerCase();
        case 'contains':
            return (Array.isArray(v) ? v.join(' ') : String(v ?? '')).toLowerCase().includes(String(f.value ?? '').toLowerCase());
        case 'gt':
        case 'gte':
        case 'lt':
        case 'lte': {
            const a = field.type === 'date' ? dateMs(v) : toNumber(v);
            const b = field.type === 'date' ? dateMs(f.value) : toNumber(f.value);
            if (a === null || b === null) return false;
            return f.op === 'gt' ? a > b : f.op === 'gte' ? a >= b : f.op === 'lt' ? a < b : a <= b;
        }
        case 'withinDays': {
            const t = dateMs(v);
            const n = toNumber(f.value) ?? 7;
            const s = startOfToday();
            return t !== null && t >= s && t <= s + n * DAY;
        }
        case 'pastDays': {
            const t = dateMs(v);
            const n = toNumber(f.value) ?? 7;
            const s = startOfToday();
            return t !== null && t <= s + DAY && t >= s - n * DAY;
        }
        case 'overdue': {
            const t = dateMs(v);
            return t !== null && t < startOfToday();
        }
    }
    return true;
}

export function applyFilters(t: Table, records: RecordRow[], filters?: Filter[]): RecordRow[] {
    if (!filters?.length) return records;
    return records.filter((r) => filters.every((f) => matchFilter(t.fields.find((x) => x.id === f.fieldId), r, f)));
}

export function sortRecords(t: Table, records: RecordRow[], sort?: { fieldId: string; dir: 'asc' | 'desc' }): RecordRow[] {
    if (!sort) return records;
    const field = t.fields.find((f) => f.id === sort.fieldId);
    if (!field) return records;
    const numeric = ['number', 'currency', 'percent', 'rating'].includes(field.type);
    const out = [...records].sort((a, b) => {
        const av = a.cells[field.id];
        const bv = b.cells[field.id];
        if (numeric) return (toNumber(av) ?? -Infinity) - (toNumber(bv) ?? -Infinity);
        return String(av ?? '').localeCompare(String(bv ?? ''), 'ko');
    });
    return sort.dir === 'desc' ? out.reverse() : out;
}

export function cellText(field: Field, v: CellValue | undefined, system?: System): string {
    if (v === null || v === undefined || v === '') return '';
    switch (field.type) {
        case 'currency': {
            const n = toNumber(v);
            return n === null ? String(v) : `${field.symbol ?? '₩'}${formatNumber(n)}`;
        }
        case 'percent': {
            const n = toNumber(v);
            return n === null ? String(v) : `${formatNumber(n)}%`;
        }
        case 'number': {
            const n = toNumber(v);
            return n === null ? String(v) : formatNumber(n);
        }
        case 'checkbox':
            return v ? '✓' : '';
        case 'multiSelect':
            return Array.isArray(v) ? v.join(', ') : String(v);
        case 'link': {
            const ids = Array.isArray(v) ? v : [String(v)];
            const lt = system?.tables.find((t) => t.id === field.linkTableId);
            if (!lt) return ids.join(', ');
            return ids.map((id) => {
                const r = lt.records.find((x) => x.id === id);
                return r ? recordTitle(lt, r) : '';
            }).filter(Boolean).join(', ');
        }
        case 'rating':
            return '★'.repeat(Math.max(0, Math.min(5, toNumber(v) ?? 0)));
        default:
            return Array.isArray(v) ? v.join(', ') : String(v);
    }
}

export function formatNumber(n: number): string {
    if (Math.abs(n) >= 1e8) return `${(n / 1e8).toFixed(Math.abs(n) >= 1e9 ? 0 : 1)}억`;
    if (Math.abs(n) >= 1e5 && Math.abs(n) % 1e4 === 0) return `${(n / 1e4).toLocaleString('ko-KR')}만`;
    return Number.isInteger(n) ? n.toLocaleString('ko-KR') : n.toLocaleString('ko-KR', { maximumFractionDigits: 2 });
}

export function formatCompact(n: number): string {
    const a = Math.abs(n);
    if (a >= 1e8) return `${+(n / 1e8).toFixed(1)}억`;
    if (a >= 1e4) return `${+(n / 1e4).toFixed(1)}만`;
    return Number.isInteger(n) ? n.toLocaleString('ko-KR') : n.toFixed(1);
}

export function aggregate(values: number[], agg: Widget['agg'], count: number): number {
    if (agg === 'count') return count;
    if (!values.length) return 0;
    switch (agg) {
        case 'sum':
            return values.reduce((a, b) => a + b, 0);
        case 'avg':
            return values.reduce((a, b) => a + b, 0) / values.length;
        case 'min':
            return Math.min(...values);
        case 'max':
            return Math.max(...values);
    }
}

export interface Series {
    label: string;
    value: number;
    color?: string;
}

export interface WidgetResult {
    value?: number;
    series?: Series[];
    rows?: RecordRow[];
    table?: Table;
    valueField?: Field;
    groupField?: Field;
}

function bucketKey(ms: number, bucket: 'day' | 'week' | 'month'): string {
    const d = new Date(ms);
    if (bucket === 'month') return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
    if (bucket === 'week') {
        const s = new Date(d);
        s.setDate(d.getDate() - ((d.getDay() + 6) % 7));
        return s.toISOString().slice(0, 10);
    }
    return d.toISOString().slice(0, 10);
}

/** Numbers on dashboards are always computed from table data — the AI only chooses what to show. */
export function computeWidget(system: System, w: Widget, extra?: Filter[]): WidgetResult {
    const table = system.tables.find((t) => t.id === w.tableId);
    if (!table) return {};
    const rows = applyFilters(table, table.records, [...(w.filters ?? []), ...(extra ?? [])]);
    const valueField = table.fields.find((f) => f.id === w.valueFieldId);
    const nums = (rs: RecordRow[]) => (valueField ? rs.map((r) => toNumber(r.cells[valueField.id])).filter((n): n is number => n !== null) : []);
    const groupField = table.fields.find((f) => f.id === w.groupByFieldId);
    const base = { table, valueField, groupField };

    if (w.type === 'kpi') return { ...base, value: aggregate(nums(rows), valueField ? w.agg : 'count', rows.length) };
    if (w.type === 'list') return { ...base, rows: rows.slice(0, w.limit ?? 6) };

    if (w.type === 'line') {
        const df = table.fields.find((f) => f.id === w.dateFieldId);
        if (!df) return base;
        const bucket = w.bucket ?? 'month';
        const groups = new Map<string, RecordRow[]>();
        for (const r of rows) {
            const t = dateMs(r.cells[df.id]);
            if (t === null) continue;
            const k = bucketKey(t, bucket);
            groups.set(k, [...(groups.get(k) ?? []), r]);
        }
        const series = [...groups.entries()]
            .sort(([a], [b]) => a.localeCompare(b))
            .map(([k, rs]) => ({ label: bucket === 'month' ? `${Number(k.slice(5, 7))}월` : k.slice(5), value: aggregate(nums(rs), valueField ? w.agg : 'count', rs.length) }));
        return { ...base, series };
    }

    if (!groupField) return base;
    const groups = new Map<string, RecordRow[]>();
    for (const r of rows) {
        const v = r.cells[groupField.id];
        const keys = Array.isArray(v)
            ? groupField.type === 'link'
                ? v.map((id) => cellText(groupField, [id], system)).filter(Boolean)
                : v
            : [v === null || v === undefined || v === '' ? '(없음)' : cellText(groupField, v, system)];
        for (const k of keys.length ? keys : ['(없음)']) groups.set(String(k), [...(groups.get(String(k)) ?? []), r]);
    }
    const order = groupField.choices?.map((c) => c.name) ?? [];
    const series = [...groups.entries()].map(([label, rs]) => ({
        label,
        value: aggregate(nums(rs), valueField ? w.agg : 'count', rs.length),
        color: groupField.choices?.find((c) => c.name === label)?.color,
    }));
    if (order.length) series.sort((a, b) => (order.indexOf(a.label) + 1 || 999) - (order.indexOf(b.label) + 1 || 999));
    else series.sort((a, b) => b.value - a.value);
    return { ...base, series: series.slice(0, 12) };
}

const DOW = ['일', '월', '화', '수', '목', '금', '토'];

export function scheduleText(s: Workflow['schedule']): string {
    if (s.freq === 'hourly') return '매시간';
    if (s.freq === 'daily') return `매일 ${s.time}`;
    if (s.freq === 'weekly') return `매주 ${DOW[s.dayOfWeek ?? 1]}요일 ${s.time}`;
    return `매월 ${s.dayOfMonth ?? 1}일 ${s.time}`;
}

/** Next run time in the server's local timezone. */
export function nextRunAt(s: Workflow['schedule'], from = new Date()): string {
    const [hh, mm] = (s.time || '09:00').split(':').map(Number);
    const d = new Date(from);
    d.setSeconds(0, 0);
    if (s.freq === 'hourly') {
        d.setMinutes(mm || 0);
        if (d <= from) d.setHours(d.getHours() + 1);
        return d.toISOString();
    }
    d.setHours(hh || 0, mm || 0);
    if (s.freq === 'daily') {
        if (d <= from) d.setDate(d.getDate() + 1);
    } else if (s.freq === 'weekly') {
        const target = s.dayOfWeek ?? 1;
        let add = (target - d.getDay() + 7) % 7;
        if (add === 0 && d <= from) add = 7;
        d.setDate(d.getDate() + add);
    } else {
        d.setDate(Math.min(s.dayOfMonth ?? 1, 28));
        if (d <= from) d.setMonth(d.getMonth() + 1);
    }
    return d.toISOString();
}

export function relTime(iso: string): string {
    const diff = Date.now() - Date.parse(iso);
    const m = Math.round(diff / 60000);
    if (m < 1) return '방금 전';
    if (m < 60) return `${m}분 전`;
    const h = Math.round(m / 60);
    if (h < 24) return `${h}시간 전`;
    const d = Math.round(h / 24);
    if (d < 30) return `${d}일 전`;
    return new Date(iso).toLocaleDateString('ko-KR');
}
