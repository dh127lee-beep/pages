import 'server-only';
import { promises as fs } from 'fs';
import path from 'path';
import { nanoid } from 'nanoid';
import type { System, SystemSummary } from './types';

const DATA_DIR = process.env.AGENTBASE_DATA_DIR ?? path.join(process.cwd(), 'data', 'systems');
const ID_PATTERN = /^[A-Za-z0-9_-]{6,32}$/;

async function ensureDir() {
    await fs.mkdir(DATA_DIR, { recursive: true });
}

function fileFor(id: string): string {
    if (!ID_PATTERN.test(id)) throw new Error('Invalid system id');
    return path.join(DATA_DIR, `${id}.json`);
}

export function summarize(s: System): SystemSummary {
    return {
        id: s.id,
        name: s.name,
        icon: s.icon,
        color: s.color,
        description: s.description,
        tables: s.tables.length,
        records: s.tables.reduce((n, t) => n + t.records.length, 0),
        dashboards: s.dashboards.length,
        workflows: s.workflows.length,
        updatedAt: s.updatedAt,
    };
}

export async function listSystems(): Promise<System[]> {
    await ensureDir();
    const files = (await fs.readdir(DATA_DIR)).filter((f) => f.endsWith('.json'));
    const systems = await Promise.all(
        files.map(async (f) => {
            try {
                return JSON.parse(await fs.readFile(path.join(DATA_DIR, f), 'utf8')) as System;
            } catch {
                return null;
            }
        }),
    );
    return systems.filter((s): s is System => !!s).sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
}

export async function getSystem(id: string): Promise<System | null> {
    try {
        return JSON.parse(await fs.readFile(fileFor(id), 'utf8')) as System;
    } catch {
        return null;
    }
}

/** Writes are serialized per system so concurrent edits (UI + agent + scheduler) never interleave. */
const locks = new Map<string, Promise<unknown>>();

export function withSystem<T>(id: string, fn: (s: System) => T | Promise<T>): Promise<T | null> {
    const prev = locks.get(id) ?? Promise.resolve();
    const run = prev.then(async () => {
        const s = await getSystem(id);
        if (!s) return null;
        const result = await fn(s);
        s.updatedAt = new Date().toISOString();
        await write(s);
        return result;
    });
    locks.set(id, run.catch(() => undefined));
    return run;
}

async function write(s: System) {
    await ensureDir();
    const target = fileFor(s.id);
    const tmp = `${target}.${process.pid}.${nanoid(4)}.tmp`;
    await fs.writeFile(tmp, JSON.stringify(s), 'utf8');
    await fs.rename(tmp, target);
}

export async function saveSystem(s: System) {
    s.updatedAt = new Date().toISOString();
    await write(s);
}

export function emptySystem(name: string, icon = '✨', description?: string): System {
    const now = new Date().toISOString();
    return {
        id: nanoid(10),
        name,
        icon,
        color: 'blue',
        description,
        tables: [],
        dashboards: [],
        workflows: [],
        chat: [],
        shares: [],
        createdAt: now,
        updatedAt: now,
    };
}

export async function deleteSystem(id: string): Promise<boolean> {
    try {
        await fs.unlink(fileFor(id));
        return true;
    } catch {
        return false;
    }
}
