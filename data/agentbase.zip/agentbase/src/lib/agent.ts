import 'server-only';
import { nanoid } from 'nanoid';
import { cellText, scheduleText, todayISO } from './data';
import { streamChat, type LlmMessage } from './llm';
import { applyOps, type Op } from './ops';
import { withSystem } from './store';
import type { ChatMessage, System } from './types';

export interface Attachment {
    name: string;
    headers: string[];
    rows: Record<string, unknown>[];
}

export type AgentEvent =
    | { type: 'status'; text: string }
    | { type: 'say'; text: string }
    | { type: 'action'; text: string }
    | { type: 'suggest'; items: string[] }
    | { type: 'system'; system: System; focus?: { kind: 'table' | 'dashboard' | 'workflow'; id: string } }
    | { type: 'done'; message: ChatMessage }
    | { type: 'error'; text: string };

const MAX_ROWS_PER_TABLE = 120;
const MAX_IMPORT_ROWS = 5000;

const SYSTEM_PROMPT = `You are AgentBase, an AI agent that builds and operates business systems
(CRMs, HR systems, project trackers, inventory, ops dashboards) inside a no-code workspace.
A system has three layers: Tables (relational data) → Views & Dashboards → Workflows (scheduled automations).

You reply ONLY with JSON Lines: one JSON object per line, no markdown fences, no prose outside JSON.
Each line is an operation that is applied immediately, so emit them in dependency order
(create a table before adding views/widgets that reference it; create linked-to tables first when possible).

Operations (all references are by NAME, never by id):
{"op":"say","text":"..."}                          — message to the user (markdown ok). Start with a short plan, end with a summary.
{"op":"rename_system","name":"...","icon":"emoji","description":"..."}
{"op":"create_table","name":"Customers","icon":"emoji","description":"...",
  "fields":[{"name":"Name","type":"text","primary":true},{"name":"Stage","type":"singleSelect","choices":["Lead","Won"]},
            {"name":"Account","type":"link","link":"Accounts"},{"name":"Amount","type":"currency","symbol":"₩"}],
  "records":[{"Name":"...","Stage":"Lead","Account":"Acme","Amount":1200000}],
  "views":[{"name":"Pipeline","type":"kanban","groupBy":"Stage"}]}
{"op":"add_fields","table":"...","fields":[...],"values":{"<record title>":{"<field>":value}}}
{"op":"update_field","table":"...","field":"...","name":"new name","type":"...","choices":[...]}
{"op":"delete_field","table":"...","field":"..."}
{"op":"add_records","table":"...","records":[{...}]}
{"op":"update_records","table":"...","where":[{"field":"...","op":"eq","value":"..."}],"set":{"Field":value}}
{"op":"delete_records","table":"...","where":[...]}
{"op":"create_view","table":"...","name":"...","type":"grid|kanban|gallery|calendar|form","groupBy":"field","dateField":"field","coverField":"url field","filters":[...],"sort":{"field":"...","dir":"desc"}}
{"op":"create_dashboard","name":"...","icon":"emoji","widgets":[widget,...]}
{"op":"add_widgets","dashboard":"...","widgets":[widget,...]}
{"op":"remove_widget","dashboard":"...","title":"..."}
{"op":"create_workflow","name":"...","description":"...","schedule":{"freq":"daily|weekly|monthly|hourly","time":"09:00","dayOfWeek":1},
  "steps":[step,...],"enabled":false}
{"op":"delete_table"|"delete_dashboard"|"delete_workflow","name":"..."}
{"op":"import_file","file":"<attachment name>","table":"Table name","icon":"emoji","fields":[{"source":"original header","name":"Clean Name","type":"...","primary":true}]}
{"op":"suggest","items":["short follow-up request 1","2","3"]}  — always the LAST line: 3 next steps the user could ask for.

Field types: text, longText, number, currency, percent, date (YYYY-MM-DD), singleSelect, multiSelect (array), checkbox, email, phone, url, rating (1-5), person (name string), link (value = title(s) of records in the linked table).
Dates: you may use relative tokens "today", "+3d", "-2w", "+1m" so sample data stays current.
Filter ops: eq, neq, contains, gt, gte, lt, lte, empty, notEmpty, withinDays (date in next N days), pastDays (date in last N days), overdue (date before today).
Widget: {"type":"kpi|bar|hbar|line|donut|list","title":"...","table":"...","agg":"count|sum|avg|min|max","field":"numeric field for agg",
  "groupBy":"category field (bar/hbar/donut)","dateField":"date field (line)","bucket":"month|week|day","filters":[...],
  "fields":["list columns"],"limit":6,"width":1-4 (grid of 4 columns; kpi=1, charts=2, list=2-4),"color":"blue|green|amber|red|purple|pink|cyan|orange|teal"}
Workflow step: {"type":"filter","title":"...","table":"...","filters":[...]}   — finds records that need attention
               {"type":"update","title":"...","table":"...","filters":[...],"set":{"Field":value}}
               {"type":"aiSummary","title":"...","prompt":"what to summarize/analyze"}  — AI writes a report from the current data
               {"type":"email","title":"...","to":"team@company.com","subject":"..."}   — sends the previous output (saved as a draft until a mailbox is connected)

Rules:
- Dashboard numbers are computed from table data by the platform — never invent totals; just choose fields/aggregations.
- When building a new system: 2-4 related tables with realistic Korean sample data (8-15 records each, varied values so charts are meaningful),
  useful views (kanban for stages, calendar for dates, gallery for visual records, a form for intake), one dashboard with 4 KPIs + 2-4 charts + a list,
  and one useful workflow (enabled:false). Name things in the user's language.
- When the user asks a question about data, answer with "say" using the data provided (cite table/record names and exact numbers); don't modify anything.
- For edits, change only what was asked. Keep existing names exactly when referencing them.
- Keep each JSON object on ONE line. Use the user's language (default Korean) for all names and messages.`;

export function describeSystem(s: System): string {
    if (!s.tables.length && !s.dashboards.length) return '(empty system — nothing built yet)';
    const out: string[] = [`System: ${s.icon} ${s.name}${s.description ? ` — ${s.description}` : ''}`];
    for (const t of s.tables) {
        out.push(`\n## Table "${t.name}" (${t.records.length} records)`);
        out.push(
            'Fields: ' +
                t.fields
                    .map((f) => {
                        let d = `${f.name}:${f.type}`;
                        if (f.choices?.length) d += `[${f.choices.map((c) => c.name).join('|')}]`;
                        if (f.type === 'link') d += `→${s.tables.find((x) => x.id === f.linkTableId)?.name ?? '?'}`;
                        return d;
                    })
                    .join(', '),
        );
        out.push(`Views: ${t.views.map((v) => `${v.name}(${v.type})`).join(', ')}`);
        const rows = t.records.slice(0, MAX_ROWS_PER_TABLE);
        if (rows.length) {
            out.push('Rows (JSON arrays in field order):');
            for (const r of rows) out.push(JSON.stringify(t.fields.map((f) => cellText(f, r.cells[f.id], s).slice(0, 80))));
            if (t.records.length > rows.length) out.push(`… ${t.records.length - rows.length} more rows not shown`);
        }
    }
    for (const d of s.dashboards) out.push(`\n## Dashboard "${d.name}": ${d.widgets.map((w) => `${w.title}(${w.type})`).join(', ')}`);
    for (const w of s.workflows)
        out.push(`\n## Workflow "${w.name}" ${w.enabled ? 'ON' : 'OFF'} ${scheduleText(w.schedule)}: ${w.steps.map((x) => `${x.type}:${x.title}`).join(' → ')}`);
    return out.join('\n');
}

function describeAttachments(atts: Attachment[]): string {
    return atts
        .map((a) => `Attachment "${a.name}" — ${a.rows.length} rows. Headers: ${JSON.stringify(a.headers)}\nSample rows:\n${a.rows.slice(0, 15).map((r) => JSON.stringify(r)).join('\n')}`)
        .join('\n\n');
}

/** Turns an import_file op into a create_table op that carries every row, mapped through the AI's field plan. */
function expandImport(op: Op, atts: Attachment[]): Op | null {
    const att = atts.find((a) => a.name === op.file) ?? atts[0];
    if (!att) return null;
    const plan: { source: string; name: string; type?: string; primary?: boolean }[] = Array.isArray(op.fields) && op.fields.length
        ? op.fields
        : att.headers.map((h, i) => ({ source: h, name: h, primary: i === 0 }));
    const records = att.rows.slice(0, MAX_IMPORT_ROWS).map((row) => {
        const rec: Record<string, unknown> = {};
        for (const p of plan) rec[p.name] = row[p.source] ?? row[p.name];
        return rec;
    });
    return { op: 'create_table', name: op.table ?? att.name.replace(/\.[^.]+$/, ''), icon: op.icon ?? '📥', fields: plan, records, views: op.views };
}

function parseLine(line: string): Op | null {
    const t = line.trim().replace(/^```(json|jsonl)?/, '').replace(/```$/, '').replace(/,$/, '').trim();
    if (!t.startsWith('{')) return null;
    try {
        const j = JSON.parse(t);
        return j && typeof j.op === 'string' ? j : null;
    } catch {
        return null;
    }
}

export async function runAgent(systemId: string, userText: string, atts: Attachment[], emit: (e: AgentEvent) => void, signal?: AbortSignal) {
    const userMsg: ChatMessage = { id: nanoid(8), role: 'user', content: userText + (atts.length ? `\n\n📎 ${atts.map((a) => a.name).join(', ')}` : ''), at: new Date().toISOString() };
    const snapshot = await withSystem(systemId, (s) => {
        s.chat.push(userMsg);
        return structuredClone(s);
    });
    if (!snapshot) return emit({ type: 'error', text: '시스템을 찾을 수 없습니다.' });

    const history: LlmMessage[] = snapshot.chat
        .slice(-9, -1)
        .map((m) => ({ role: m.role, content: m.role === 'assistant' ? `{"op":"say","text":${JSON.stringify(m.content.slice(0, 1500))}}` : m.content }));
    const messages: LlmMessage[] = [
        { role: 'system', content: SYSTEM_PROMPT },
        ...history,
        {
            role: 'user',
            content: `Today is ${todayISO()}.\n\nCURRENT SYSTEM STATE:\n${describeSystem(snapshot)}${atts.length ? `\n\nATTACHED FILES:\n${describeAttachments(atts)}` : ''}\n\nUSER REQUEST:\n${userText}`,
        },
    ];

    emit({ type: 'status', text: '요청을 분석하고 있어요…' });
    const says: string[] = [];
    const actions: string[] = [];
    let suggestions: string[] = [];
    let buf = '';
    let queue = Promise.resolve();

    const handle = (op: Op) => {
        if (op.op === 'say') {
            says.push(String(op.text ?? ''));
            emit({ type: 'say', text: String(op.text ?? '') });
            return;
        }
        if (op.op === 'suggest') {
            suggestions = (op.items ?? []).map(String).slice(0, 4);
            return;
        }
        const real = op.op === 'import_file' ? expandImport(op, atts) : op;
        if (!real) return;
        emit({ type: 'status', text: statusFor(real) });
        queue = queue.then(async () => {
            const result = await withSystem(systemId, (s) => ({ ...applyOps(s, [real]), system: structuredClone(s) }));
            if (!result) return;
            for (const a of result.actions) {
                actions.push(a);
                emit({ type: 'action', text: a });
            }
            emit({ type: 'system', system: result.system, focus: result.focus });
        });
    };

    try {
        const full = await streamChat(
            messages,
            (delta) => {
                buf += delta;
                let i: number;
                while ((i = buf.indexOf('\n')) >= 0) {
                    const op = parseLine(buf.slice(0, i));
                    buf = buf.slice(i + 1);
                    if (op) handle(op);
                }
            },
            { signal },
        );
        const last = parseLine(buf);
        if (last) handle(last);
        // A reply that is plain prose (no JSON at all) is still shown to the user.
        if (!says.length && !actions.length && full.trim() && !full.trim().startsWith('{')) {
            says.push(full.trim());
            emit({ type: 'say', text: full.trim() });
        }
        await queue;
    } catch (e) {
        await queue.catch(() => {});
        emit({ type: 'error', text: (e as Error).message });
        says.push(`⚠️ ${(e as Error).message}`);
    }

    const reply: ChatMessage = {
        id: nanoid(8),
        role: 'assistant',
        content: says.join('\n\n') || (actions.length ? '완료했어요.' : '응답이 비어 있어요. 다시 시도해 주세요.'),
        actions,
        at: new Date().toISOString(),
    };
    await withSystem(systemId, (s) => {
        s.chat.push(reply);
    });
    if (suggestions.length) emit({ type: 'suggest', items: suggestions });
    emit({ type: 'done', message: reply });
}

function statusFor(op: Op): string {
    switch (op.op) {
        case 'create_table':
            return `테이블 '${op.name}' 만드는 중…`;
        case 'create_dashboard':
            return `대시보드 '${op.name}' 구성 중…`;
        case 'create_workflow':
            return `워크플로 '${op.name}' 설정 중…`;
        case 'create_view':
            return `뷰 '${op.name}' 추가 중…`;
        case 'add_records':
            return `'${op.table}'에 데이터 입력 중…`;
        default:
            return '시스템 업데이트 중…';
    }
}
