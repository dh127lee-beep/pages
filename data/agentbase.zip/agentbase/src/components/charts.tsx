'use client';

import { useState } from 'react';
import { formatCompact, type Series } from '@/lib/data';
import type { ChoiceColor } from '@/lib/types';
import { HEX, PALETTE } from './ui';

const colorOf = (s: Series, i: number, base?: string) => (s.color ? HEX[s.color as ChoiceColor] : base ?? PALETTE[i % PALETTE.length]);

interface ChartProps {
    data: Series[];
    color?: string;
    format?: (n: number) => string;
    onSelect?: (label: string) => void;
    selected?: string;
}

function Empty() {
    return <div className="flex h-full items-center justify-center text-xs text-faint">표시할 데이터가 없어요</div>;
}

export function BarChart({ data, color, format = formatCompact, onSelect, selected }: ChartProps) {
    const [hover, setHover] = useState<number | null>(null);
    if (!data.length) return <Empty />;
    const max = Math.max(...data.map((d) => d.value), 1);
    const ticks = [0, 0.5, 1].map((t) => t * max);
    return (
        <div className="flex h-full flex-col">
            <div className="relative flex min-h-0 flex-1 gap-2 pl-9">
                {ticks.map((t, i) => (
                    <div key={i} className="pointer-events-none absolute left-0 right-0 flex items-center" style={{ bottom: `${(t / max) * 100}%` }}>
                        <span className="w-8 pr-1 text-right text-[10px] text-faint">{format(t)}</span>
                        <div className="h-px flex-1 border-t border-dashed border-line" />
                    </div>
                ))}
                {data.map((d, i) => {
                    const dim = selected && selected !== d.label;
                    return (
                        <div
                            key={d.label}
                            className="group relative flex flex-1 cursor-pointer flex-col justify-end"
                            onMouseEnter={() => setHover(i)}
                            onMouseLeave={() => setHover(null)}
                            onClick={() => onSelect?.(d.label)}
                        >
                            {hover === i && (
                                <div className="absolute -top-1 left-1/2 z-10 -translate-x-1/2 -translate-y-full whitespace-nowrap rounded-md bg-ink px-2 py-1 text-[11px] text-white shadow">
                                    {d.label}: <b>{format(d.value)}</b>
                                </div>
                            )}
                            <div
                                className="mx-auto w-full max-w-10 rounded-t-md transition-all"
                                style={{ height: `${Math.max((d.value / max) * 100, 1)}%`, background: colorOf(d, i, color), opacity: dim ? 0.25 : hover === i ? 0.85 : 1 }}
                            />
                        </div>
                    );
                })}
            </div>
            <div className="mt-1.5 flex gap-2 pl-9">
                {data.map((d) => (
                    <div key={d.label} className="flex-1 truncate text-center text-[10px] text-muted" title={d.label}>
                        {d.label}
                    </div>
                ))}
            </div>
        </div>
    );
}

export function HBarChart({ data, color, format = formatCompact, onSelect, selected }: ChartProps) {
    if (!data.length) return <Empty />;
    const max = Math.max(...data.map((d) => d.value), 1);
    return (
        <div className="ab-scroll flex h-full flex-col justify-center gap-1.5 overflow-y-auto pr-1">
            {data.map((d, i) => (
                <button key={d.label} onClick={() => onSelect?.(d.label)} className={`group flex items-center gap-2 text-left ${selected && selected !== d.label ? 'opacity-30' : ''}`}>
                    <span className="w-20 shrink-0 truncate text-xs text-ink-2" title={d.label}>
                        {d.label}
                    </span>
                    <span className="relative h-5 flex-1 overflow-hidden rounded-md bg-soft">
                        <span className="absolute inset-y-0 left-0 rounded-md transition-all group-hover:opacity-80" style={{ width: `${Math.max((d.value / max) * 100, 1.5)}%`, background: colorOf(d, i, color) }} />
                    </span>
                    <span className="w-14 shrink-0 text-right text-xs font-medium tabular-nums">{format(d.value)}</span>
                </button>
            ))}
        </div>
    );
}

export function LineChart({ data, color = '#4f46e5', format = formatCompact }: ChartProps) {
    const [hover, setHover] = useState<number | null>(null);
    if (!data.length) return <Empty />;
    const W = 400;
    const H = 150;
    const max = Math.max(...data.map((d) => d.value), 1);
    const x = (i: number) => (data.length === 1 ? W / 2 : (i / (data.length - 1)) * (W - 16) + 8);
    const y = (v: number) => H - 8 - (v / max) * (H - 24);
    const path = data.map((d, i) => `${i ? 'L' : 'M'}${x(i)},${y(d.value)}`).join(' ');
    const area = `${path} L${x(data.length - 1)},${H} L${x(0)},${H} Z`;
    const gid = `g${color.replace('#', '')}`;
    return (
        <div className="flex h-full flex-col">
            <div className="relative min-h-0 flex-1">
                <svg viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" className="h-full w-full overflow-visible">
                    <defs>
                        <linearGradient id={gid} x1="0" x2="0" y1="0" y2="1">
                            <stop offset="0%" stopColor={color} stopOpacity="0.25" />
                            <stop offset="100%" stopColor={color} stopOpacity="0" />
                        </linearGradient>
                    </defs>
                    {[0.25, 0.5, 0.75].map((t) => (
                        <line key={t} x1="0" x2={W} y1={H * t} y2={H * t} stroke="#ececf0" strokeDasharray="3 4" vectorEffect="non-scaling-stroke" />
                    ))}
                    <path d={area} fill={`url(#${gid})`} />
                    <path d={path} fill="none" stroke={color} strokeWidth="2.2" vectorEffect="non-scaling-stroke" strokeLinejoin="round" strokeLinecap="round" />
                </svg>
                <div className="absolute inset-0 flex">
                    {data.map((d, i) => (
                        <div key={i} className="relative flex-1" onMouseEnter={() => setHover(i)} onMouseLeave={() => setHover(null)}>
                            {hover === i && (
                                <>
                                    <div className="absolute h-2.5 w-2.5 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-white shadow" style={{ left: `${(x(i) / W) * 100 * data.length - i * 100}%`, top: `${(y(d.value) / H) * 100}%`, background: color }} />
                                    <div className="absolute z-10 -translate-x-1/2 -translate-y-[130%] whitespace-nowrap rounded-md bg-ink px-2 py-1 text-[11px] text-white" style={{ left: `${(x(i) / W) * 100 * data.length - i * 100}%`, top: `${(y(d.value) / H) * 100}%` }}>
                                        {d.label}: <b>{format(d.value)}</b>
                                    </div>
                                </>
                            )}
                        </div>
                    ))}
                </div>
            </div>
            <div className="mt-1.5 flex justify-between text-[10px] text-muted">
                {data.map((d, i) => (
                    <span key={i} className={data.length > 8 && i % Math.ceil(data.length / 8) ? 'invisible' : ''}>
                        {d.label}
                    </span>
                ))}
            </div>
        </div>
    );
}

export function DonutChart({ data, format = formatCompact, onSelect, selected }: ChartProps) {
    const [hover, setHover] = useState<number | null>(null);
    const total = data.reduce((a, b) => a + b.value, 0);
    if (!data.length || !total) return <Empty />;
    const R = 42;
    const C = 2 * Math.PI * R;
    let acc = 0;
    const active = hover !== null ? data[hover] : null;
    return (
        <div className="flex h-full items-center gap-4">
            <div className="relative aspect-square h-full max-h-40 shrink-0">
                <svg viewBox="0 0 100 100" className="h-full w-full -rotate-90">
                    <circle cx="50" cy="50" r={R} fill="none" stroke="#f3f3f5" strokeWidth="13" />
                    {data.map((d, i) => {
                        const len = (d.value / total) * C;
                        const el = (
                            <circle
                                key={d.label}
                                cx="50"
                                cy="50"
                                r={R}
                                fill="none"
                                stroke={colorOf(d, i)}
                                strokeWidth={hover === i ? 15 : 13}
                                strokeDasharray={`${Math.max(len - 0.8, 0.1)} ${C}`}
                                strokeDashoffset={-acc}
                                className="cursor-pointer transition-all"
                                opacity={selected && selected !== d.label ? 0.25 : 1}
                                onMouseEnter={() => setHover(i)}
                                onMouseLeave={() => setHover(null)}
                                onClick={() => onSelect?.(d.label)}
                            />
                        );
                        acc += len;
                        return el;
                    })}
                </svg>
                <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center text-center">
                    <div className="text-[15px] font-semibold tabular-nums">{format(active ? active.value : total)}</div>
                    <div className="max-w-16 truncate text-[10px] text-muted">{active ? active.label : '합계'}</div>
                </div>
            </div>
            <div className="ab-scroll min-w-0 flex-1 space-y-1 overflow-y-auto">
                {data.map((d, i) => (
                    <button
                        key={d.label}
                        onClick={() => onSelect?.(d.label)}
                        onMouseEnter={() => setHover(i)}
                        onMouseLeave={() => setHover(null)}
                        className={`flex w-full items-center gap-2 rounded px-1 text-left text-xs hover:bg-soft ${selected && selected !== d.label ? 'opacity-40' : ''}`}
                    >
                        <span className="h-2 w-2 shrink-0 rounded-full" style={{ background: colorOf(d, i) }} />
                        <span className="min-w-0 flex-1 truncate text-ink-2">{d.label}</span>
                        <span className="tabular-nums text-muted">{Math.round((d.value / total) * 100)}%</span>
                    </button>
                ))}
            </div>
        </div>
    );
}
