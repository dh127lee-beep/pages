'use client';

import {
    ArrowUp,
    Database,
    FileSpreadsheet,
    LayoutDashboard,
    Loader2,
    Mail,
    MoreHorizontal,
    Paperclip,
    Plus,
    Sparkles,
    Table2,
    Trash2,
    Workflow as WorkflowIcon,
    X,
} from 'lucide-react';
import { useRouter } from 'next/navigation';
import { useEffect, useRef, useState } from 'react';
import { api, uploadFiles, type Attachment } from '@/lib/client';
import { relTime } from '@/lib/data';
import type { ChoiceColor, SystemSummary } from '@/lib/types';
import { HEX, Logo, MenuItem, Modal, Popover, SOFT_BG } from './ui';

interface TemplateInfo {
    id: string;
    category: string;
    name: string;
    icon: string;
    color: ChoiceColor;
    description: string;
    highlights: string[];
    tables: string[];
}

const CATEGORIES = ['전체', '영업 · CRM', '인사 · HR', '프로젝트', '운영 · 재고', '마케팅', '재무'];

const EXAMPLES = [
    { icon: '🤝', text: '고객사와 영업 딜, 미팅 기록을 관리하는 CRM을 만들어줘' },
    { icon: '🧑‍💼', text: '채용 공고별 지원자 파이프라인과 면접 일정을 관리하고 싶어' },
    { icon: '📦', text: '상품 재고와 입출고를 기록하고 재고가 부족하면 알려주는 시스템' },
    { icon: '🏋️', text: '헬스장 회원권, 출석, PT 예약을 관리하는 운영 시스템' },
    { icon: '🏫', text: '학원 학생, 수강 반, 출결과 수납을 관리하는 시스템' },
];

const SOURCES = [
    { name: 'Gmail', icon: <Mail size={14} className="text-rose-500" /> },
    { name: 'Outlook', icon: <Mail size={14} className="text-blue-600" /> },
    { name: 'HubSpot', icon: <span className="text-[13px] font-bold text-orange-500">H</span> },
    { name: 'Salesforce', icon: <span className="text-[13px] font-bold text-sky-500">S</span> },
    { name: 'PostgreSQL', icon: <Database size={14} className="text-indigo-600" /> },
];

export function Home() {
    const router = useRouter();
    const [systems, setSystems] = useState<SystemSummary[] | null>(null);
    const [templates, setTemplates] = useState<TemplateInfo[]>([]);
    const [cat, setCat] = useState('전체');
    const [prompt, setPrompt] = useState('');
    const [files, setFiles] = useState<File[]>([]);
    const [busy, setBusy] = useState<string | null>(null);
    const [error, setError] = useState<string | null>(null);
    const [preview, setPreview] = useState<TemplateInfo | null>(null);
    const [source, setSource] = useState<string | null>(null);
    const [ai, setAi] = useState<{ online: boolean; model: string } | null>(null);
    const fileRef = useRef<HTMLInputElement>(null);
    const taRef = useRef<HTMLTextAreaElement>(null);

    useEffect(() => {
        api<SystemSummary[]>('/api/systems').then(setSystems).catch(() => setSystems([]));
        api<TemplateInfo[]>('/api/templates').then(setTemplates).catch(() => {});
        api<{ online: boolean; model: string }>('/api/ai').then(setAi).catch(() => {});
    }, []);

    useEffect(() => {
        const ta = taRef.current;
        if (!ta) return;
        ta.style.height = 'auto';
        ta.style.height = `${Math.min(ta.scrollHeight, 220)}px`;
    }, [prompt]);

    async function start() {
        const text = prompt.trim() || (files.length ? '첨부한 파일로 시스템을 만들어줘. 데이터에 맞는 테이블, 뷰, 대시보드를 구성해줘.' : '');
        if (!text) return;
        setBusy('prompt');
        setError(null);
        try {
            let attachments: Attachment[] = [];
            if (files.length) attachments = await uploadFiles(files);
            const s = await api<SystemSummary>('/api/systems', { method: 'POST', json: { name: shortName(text, files) } });
            sessionStorage.setItem(`ab-pending-${s.id}`, JSON.stringify({ message: text, attachments }));
            router.push(`/s/${s.id}`);
        } catch (e) {
            setError((e as Error).message);
            setBusy(null);
        }
    }

    async function useTemplate(t: TemplateInfo) {
        setBusy(t.id);
        try {
            const s = await api<SystemSummary>('/api/systems', { method: 'POST', json: { templateId: t.id } });
            router.push(`/s/${s.id}`);
        } catch (e) {
            setError((e as Error).message);
            setBusy(null);
        }
    }

    async function remove(id: string) {
        if (!confirm('이 시스템을 삭제할까요? 모든 데이터가 사라집니다.')) return;
        await api(`/api/systems/${id}`, { method: 'DELETE' });
        setSystems((s) => s?.filter((x) => x.id !== id) ?? null);
    }

    const shown = templates.filter((t) => cat === '전체' || t.category === cat);

    return (
        <div className="min-h-screen bg-white">
            <header className="sticky top-0 z-30 flex h-14 items-center justify-between border-b border-transparent bg-white/80 px-5 backdrop-blur">
                <div className="flex items-center gap-2.5">
                    <Logo />
                    <span className="text-[15px] font-semibold tracking-tight">AgentBase</span>
                    <span className="rounded-full bg-mutedbg px-2 py-0.5 text-[11px] font-medium text-muted">Preview</span>
                </div>
                <div className="flex items-center gap-3 text-sm text-muted">
                    {ai && (
                        <span className="flex items-center gap-1.5 rounded-full border border-line px-2.5 py-1 text-xs">
                            <span className={`h-1.5 w-1.5 rounded-full ${ai.online ? 'bg-emerald-500' : 'bg-rose-500'}`} />
                            Claude {ai.model} {ai.online ? '' : '· 오프라인'}
                        </span>
                    )}
                    <a href="#systems" className="hover:text-ink">내 시스템</a>
                    <a href="#templates" className="hover:text-ink">템플릿</a>
                </div>
            </header>

            <section className="ab-dots relative px-5 pb-16 pt-16">
                <div className="pointer-events-none absolute inset-x-0 top-0 h-full bg-gradient-to-b from-white/0 via-white/70 to-white" />
                <div className="relative mx-auto max-w-3xl text-center">
                    <div className="mx-auto mb-5 inline-flex items-center gap-1.5 rounded-full border border-line bg-white px-3 py-1 text-xs text-muted shadow-sm">
                        <Sparkles size={13} className="text-accent" /> AI가 만드는 나만의 업무 시스템
                    </div>
                    <h1 className="text-[44px] font-bold leading-tight tracking-tight sm:text-[52px]">
                        <span className="ab-gradient-text">AgentBase</span>
                    </h1>
                    <p className="mx-auto mt-3 max-w-xl text-[15px] leading-relaxed text-muted">
                        필요한 시스템을 설명하거나 파일을 올리세요. AI 에이전트가 <b className="font-semibold text-ink-2">테이블 · 대시보드 · 워크플로</b>를
                        만들고, 대화로 계속 고쳐 나갑니다.
                    </p>

                    <div className="ab-glow mx-auto mt-8 rounded-[22px] bg-white p-3 text-left">
                        {files.length > 0 && (
                            <div className="mb-2 flex flex-wrap gap-2 px-1">
                                {files.map((f, i) => (
                                    <span key={i} className="flex items-center gap-1.5 rounded-lg border border-line bg-soft px-2 py-1 text-xs">
                                        <FileSpreadsheet size={14} className="text-emerald-600" />
                                        {f.name}
                                        <button onClick={() => setFiles(files.filter((_, j) => j !== i))} className="text-faint hover:text-ink">
                                            <X size={12} />
                                        </button>
                                    </span>
                                ))}
                            </div>
                        )}
                        <textarea
                            ref={taRef}
                            value={prompt}
                            onChange={(e) => setPrompt(e.target.value)}
                            onKeyDown={(e) => {
                                if (e.key === 'Enter' && !e.shiftKey && !e.nativeEvent.isComposing) {
                                    e.preventDefault();
                                    start();
                                }
                            }}
                            rows={2}
                            placeholder="어떤 시스템을 만들고 싶으세요? 예) 고객과 영업 딜을 관리하는 CRM을 만들어줘"
                            className="block w-full resize-none bg-transparent px-2 py-1.5 text-[15px] leading-relaxed outline-none placeholder:text-faint"
                        />
                        <div className="mt-2 flex items-center justify-between gap-2">
                            <div className="flex flex-wrap items-center gap-1.5">
                                <input
                                    ref={fileRef}
                                    type="file"
                                    multiple
                                    accept=".csv,.xlsx,.xls"
                                    className="hidden"
                                    onChange={(e) => {
                                        setFiles([...files, ...Array.from(e.target.files ?? [])]);
                                        e.target.value = '';
                                    }}
                                />
                                <button onClick={() => fileRef.current?.click()} className="ab-btn-outline !rounded-full !px-2.5 !py-1 !text-xs" title="CSV · Excel 업로드">
                                    <Paperclip size={14} /> 파일 업로드
                                </button>
                                <Popover
                                    trigger={(toggle) => (
                                        <button onClick={toggle} className="ab-btn-outline !rounded-full !px-2.5 !py-1 !text-xs">
                                            <Plus size={14} /> 데이터 연결
                                        </button>
                                    )}
                                >
                                    {(close) => (
                                        <>
                                            <div className="px-2.5 pb-1 pt-1.5 text-[11px] font-medium text-faint">데이터 소스</div>
                                            {SOURCES.map((s) => (
                                                <MenuItem key={s.name} icon={s.icon} onClick={() => { close(); setSource(s.name); }}>
                                                    {s.name}
                                                </MenuItem>
                                            ))}
                                            <MenuItem icon={<FileSpreadsheet size={14} className="text-emerald-600" />} onClick={() => { close(); fileRef.current?.click(); }}>
                                                CSV · Excel 파일
                                            </MenuItem>
                                        </>
                                    )}
                                </Popover>
                            </div>
                            <button
                                onClick={start}
                                disabled={busy === 'prompt' || (!prompt.trim() && !files.length)}
                                className="flex h-9 w-9 items-center justify-center rounded-full bg-ink text-white transition hover:bg-black/80 disabled:bg-zinc-200 disabled:text-zinc-400"
                                aria-label="만들기"
                            >
                                {busy === 'prompt' ? <Loader2 size={17} className="animate-spin" /> : <ArrowUp size={18} />}
                            </button>
                        </div>
                    </div>
                    {error && <p className="mt-3 text-sm text-rose-600">{error}</p>}

                    <div className="mt-5 flex flex-wrap justify-center gap-2">
                        {EXAMPLES.map((ex) => (
                            <button
                                key={ex.text}
                                onClick={() => {
                                    setPrompt(ex.text);
                                    taRef.current?.focus();
                                }}
                                className="flex items-center gap-1.5 rounded-full border border-line bg-white px-3 py-1.5 text-xs text-ink-2 transition hover:border-line-strong hover:bg-soft"
                            >
                                <span>{ex.icon}</span>
                                {ex.text.length > 22 ? ex.text.slice(0, 22) + '…' : ex.text}
                            </button>
                        ))}
                    </div>

                    <div className="mx-auto mt-10 grid max-w-2xl grid-cols-3 gap-3 text-left">
                        {[
                            { icon: <Table2 size={16} />, t: '테이블', d: '관계형 데이터 · 5가지 뷰' },
                            { icon: <LayoutDashboard size={16} />, t: '대시보드', d: 'KPI · 차트 · 클릭 필터' },
                            { icon: <WorkflowIcon size={16} />, t: '워크플로', d: '예약 실행 · AI 리포트' },
                        ].map((x) => (
                            <div key={x.t} className="rounded-xl border border-line bg-white/80 px-3.5 py-3">
                                <div className="flex items-center gap-1.5 text-sm font-semibold">
                                    <span className="text-accent">{x.icon}</span>
                                    {x.t}
                                </div>
                                <div className="mt-0.5 text-xs text-muted">{x.d}</div>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            <section id="systems" className="mx-auto max-w-6xl px-5 pb-14">
                <div className="mb-4 flex items-end justify-between">
                    <div>
                        <h2 className="text-lg font-semibold tracking-tight">내 시스템</h2>
                        <p className="text-sm text-muted">AgentBase로 만든 시스템</p>
                    </div>
                </div>
                {systems === null ? (
                    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                        {[0, 1, 2].map((i) => (
                            <div key={i} className="ab-shimmer h-36 rounded-2xl" />
                        ))}
                    </div>
                ) : systems.length === 0 ? (
                    <div className="rounded-2xl border border-dashed border-line-strong bg-soft px-6 py-10 text-center text-sm text-muted">
                        아직 만든 시스템이 없어요. 위에서 설명하거나 아래 템플릿으로 시작해 보세요.
                    </div>
                ) : (
                    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                        {systems.map((s) => (
                            <div
                                key={s.id}
                                onClick={() => router.push(`/s/${s.id}`)}
                                className="group cursor-pointer rounded-2xl border border-line bg-white p-4 transition hover:-translate-y-0.5 hover:border-line-strong hover:shadow-[0_8px_30px_-12px_rgba(0,0,0,0.15)]"
                            >
                                <div className="flex items-start justify-between">
                                    <div className={`flex h-10 w-10 items-center justify-center rounded-xl text-xl ${SOFT_BG[s.color] ?? 'bg-mutedbg'}`}>{s.icon}</div>
                                    <div onClick={(e) => e.stopPropagation()}>
                                        <Popover
                                            align="right"
                                            trigger={(t) => (
                                                <button onClick={t} className="rounded-md p-1 text-faint opacity-0 hover:bg-mutedbg hover:text-ink group-hover:opacity-100">
                                                    <MoreHorizontal size={16} />
                                                </button>
                                            )}
                                        >
                                            {(close) => (
                                                <MenuItem danger icon={<Trash2 size={14} />} onClick={() => { close(); remove(s.id); }}>
                                                    삭제
                                                </MenuItem>
                                            )}
                                        </Popover>
                                    </div>
                                </div>
                                <div className="mt-3 truncate font-semibold">{s.name}</div>
                                <div className="mt-0.5 line-clamp-1 h-5 text-sm text-muted">{s.description ?? ''}</div>
                                <div className="mt-3 flex items-center gap-3 text-xs text-muted">
                                    <span className="flex items-center gap-1"><Table2 size={12} /> {s.tables}</span>
                                    <span className="flex items-center gap-1"><LayoutDashboard size={12} /> {s.dashboards}</span>
                                    <span className="flex items-center gap-1"><WorkflowIcon size={12} /> {s.workflows}</span>
                                    <span>레코드 {s.records.toLocaleString()}</span>
                                    <span className="ml-auto text-faint">{relTime(s.updatedAt)}</span>
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </section>

            <section id="templates" className="border-t border-line bg-soft px-5 py-14">
                <div className="mx-auto max-w-6xl">
                    <h2 className="text-lg font-semibold tracking-tight">템플릿 센터</h2>
                    <p className="text-sm text-muted">바로 쓸 수 있는 시스템으로 시작하고, AI와 대화하며 맞춤화하세요.</p>
                    <div className="mt-5 flex flex-wrap gap-1.5">
                        {CATEGORIES.map((c) => (
                            <button
                                key={c}
                                onClick={() => setCat(c)}
                                className={`rounded-full px-3.5 py-1.5 text-sm transition ${cat === c ? 'bg-ink text-white' : 'bg-white text-ink-2 ring-1 ring-line hover:bg-mutedbg'}`}
                            >
                                {c}
                            </button>
                        ))}
                    </div>
                    <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                        {shown.map((t) => (
                            <button key={t.id} onClick={() => setPreview(t)} className="group overflow-hidden rounded-2xl border border-line bg-white text-left transition hover:-translate-y-0.5 hover:shadow-[0_8px_30px_-12px_rgba(0,0,0,0.18)]">
                                <TemplateArt t={t} />
                                <div className="p-4">
                                    <div className="flex items-center gap-2 font-semibold">
                                        <span>{t.icon}</span> {t.name}
                                    </div>
                                    <p className="mt-1 line-clamp-2 text-xs leading-relaxed text-muted">{t.description}</p>
                                    <div className="mt-3 text-[11px] text-faint">{t.category}</div>
                                </div>
                            </button>
                        ))}
                    </div>
                </div>
            </section>

            <footer className="px-5 py-8 text-center text-xs text-faint">AgentBase · onlook · table-pocket 기반 로컬 구현</footer>

            <Modal open={!!preview} onClose={() => setPreview(null)} title={preview ? `${preview.icon} ${preview.name}` : ''} width="max-w-xl">
                {preview && (
                    <div className="p-5">
                        <TemplateArt t={preview} big />
                        <p className="mt-4 text-sm text-ink-2">{preview.description}</p>
                        <div className="mt-4 grid grid-cols-2 gap-4 text-sm">
                            <div>
                                <div className="mb-1.5 text-xs font-medium text-muted">포함된 테이블</div>
                                {preview.tables.map((x) => (
                                    <div key={x} className="flex items-center gap-1.5 py-0.5">
                                        <Table2 size={13} className="text-faint" /> {x}
                                    </div>
                                ))}
                            </div>
                            <div>
                                <div className="mb-1.5 text-xs font-medium text-muted">주요 기능</div>
                                {preview.highlights.map((x) => (
                                    <div key={x} className="flex items-center gap-1.5 py-0.5">
                                        <Sparkles size={13} className="text-accent" /> {x}
                                    </div>
                                ))}
                            </div>
                        </div>
                        <div className="mt-6 flex justify-end gap-2">
                            <button className="ab-btn" onClick={() => setPreview(null)}>닫기</button>
                            <button className="ab-btn-primary" disabled={!!busy} onClick={() => useTemplate(preview)}>
                                {busy === preview.id && <Loader2 size={14} className="animate-spin" />} 이 템플릿 사용
                            </button>
                        </div>
                    </div>
                )}
            </Modal>

            <Modal open={!!source} onClose={() => setSource(null)} title={`${source} 연결`}>
                <div className="space-y-3 p-5 text-sm text-ink-2">
                    <p>
                        <b>{source}</b> 연결은 계정 인증(OAuth · 토큰)이 필요해 로컬 버전에서는 아직 지원하지 않아요.
                    </p>
                    <p className="text-muted">대신 {source}에서 내보낸 CSV · Excel 파일을 올리면 AI가 필드를 매핑해 테이블로 가져옵니다.</p>
                    <div className="flex justify-end gap-2 pt-2">
                        <button className="ab-btn" onClick={() => setSource(null)}>닫기</button>
                        <button className="ab-btn-primary" onClick={() => { setSource(null); fileRef.current?.click(); }}>
                            <Paperclip size={14} /> 파일 올리기
                        </button>
                    </div>
                </div>
            </Modal>
        </div>
    );
}

function shortName(text: string, files: File[]) {
    if (files.length && text.startsWith('첨부한 파일')) return files[0].name.replace(/\.[^.]+$/, '');
    return text.replace(/(을|를)?\s*(만들어\s*줘|만들어\s*주세요|만들고\s*싶어|관리하고\s*싶어).*$/, '').slice(0, 30) || '새 시스템';
}

/** Decorative mini-dashboard illustration for template cards. */
function TemplateArt({ t, big }: { t: TemplateInfo; big?: boolean }) {
    const c = HEX[t.color] ?? '#4f46e5';
    const bars = [0.45, 0.7, 0.55, 0.9, 0.65, 0.8];
    return (
        <div className={`relative overflow-hidden ${big ? 'h-44 rounded-xl' : 'h-28'} ${SOFT_BG[t.color] ?? 'bg-mutedbg'}`}>
            <div className="absolute left-4 top-4 w-[46%] rounded-lg bg-white p-2 shadow-sm">
                <div className="h-1.5 w-10 rounded bg-zinc-200" />
                <div className="mt-1.5 text-[13px] font-bold" style={{ color: c }}>
                    {t.icon}
                </div>
                <div className="mt-1 flex h-8 items-end gap-1">
                    {bars.map((b, i) => (
                        <div key={i} className="flex-1 rounded-sm" style={{ height: `${b * 100}%`, background: c, opacity: 0.35 + i * 0.1 }} />
                    ))}
                </div>
            </div>
            <div className="absolute right-[-10px] top-6 w-[48%] space-y-1.5 rounded-lg bg-white p-2 shadow-sm">
                {[0, 1, 2, 3].map((i) => (
                    <div key={i} className="flex items-center gap-1.5">
                        <div className="h-1.5 w-1.5 rounded-full" style={{ background: c, opacity: 1 - i * 0.2 }} />
                        <div className="h-1.5 flex-1 rounded bg-zinc-100" />
                        <div className="h-1.5 w-5 rounded" style={{ background: c, opacity: 0.25 }} />
                    </div>
                ))}
            </div>
        </div>
    );
}
