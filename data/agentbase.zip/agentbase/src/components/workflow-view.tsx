'use client';

import { Bot, CheckCircle2, ChevronDown, Clock, Filter as FilterIcon, FlaskConical, Loader2, Mail, PenLine, Play, Trash2, XCircle, Zap } from 'lucide-react';
import { useState, type ReactNode } from 'react';
import { api, type Mutation } from '@/lib/client';
import { relTime, scheduleText } from '@/lib/data';
import type { System, Workflow, WorkflowRun, WorkflowStep } from '@/lib/types';
import { filterText } from './table-view';
import { Markdown, Toggle } from './ui';

const STEP_META: Record<WorkflowStep['type'], { label: string; icon: ReactNode; tone: string }> = {
    filter: { label: '레코드 찾기', icon: <FilterIcon size={15} />, tone: 'bg-blue-50 text-blue-600' },
    update: { label: '레코드 수정', icon: <PenLine size={15} />, tone: 'bg-amber-50 text-amber-600' },
    aiSummary: { label: 'AI 보고서', icon: <Bot size={15} />, tone: 'bg-violet-50 text-violet-600' },
    email: { label: '이메일 보내기', icon: <Mail size={15} />, tone: 'bg-rose-50 text-rose-600' },
};

const DOW = ['일', '월', '화', '수', '목', '금', '토'];

export function WorkflowView({ system, workflow: wf, mutate, onSystem }: { system: System; workflow: Workflow; mutate: (m: Mutation) => Promise<unknown>; onSystem: (s: System) => void }) {
    const [running, setRunning] = useState<'test' | 'live' | null>(null);
    const [openRun, setOpenRun] = useState<string | null>(wf.runs[0]?.id ?? null);
    const update = (patch: Partial<Workflow>) => mutate({ action: 'updateWorkflow', workflowId: wf.id, patch });

    const run = async (test: boolean) => {
        setRunning(test ? 'test' : 'live');
        try {
            const res = await api<{ run: WorkflowRun; system: System }>(`/api/systems/${system.id}/workflows/${wf.id}/run`, { method: 'POST', json: { test } });
            onSystem(res.system);
            setOpenRun(res.run.id);
        } catch (e) {
            alert((e as Error).message);
        } finally {
            setRunning(null);
        }
    };

    return (
        <div className="ab-scroll h-full overflow-y-auto bg-soft">
            <div className="mx-auto max-w-3xl px-6 py-6">
                <div className="flex flex-wrap items-start justify-between gap-3">
                    <div className="min-w-0">
                        <div className="flex items-center gap-2">
                            <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-ink text-white"><Zap size={16} /></span>
                            <h1 className="truncate text-xl font-semibold tracking-tight">{wf.name}</h1>
                            <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${wf.enabled ? 'bg-emerald-50 text-emerald-700' : 'bg-mutedbg text-muted'}`}>{wf.enabled ? '켜짐' : '꺼짐'}</span>
                        </div>
                        {wf.description && <p className="mt-1.5 text-sm text-muted">{wf.description}</p>}
                    </div>
                    <div className="flex items-center gap-2">
                        <button className="ab-btn-outline" disabled={!!running} onClick={() => run(true)}>
                            {running === 'test' ? <Loader2 size={14} className="animate-spin" /> : <FlaskConical size={14} />} 테스트
                        </button>
                        <button className="ab-btn-outline" disabled={!!running} onClick={() => confirm('지금 실제로 실행할까요? 레코드 수정 단계가 적용됩니다.') && run(false)}>
                            {running === 'live' ? <Loader2 size={14} className="animate-spin" /> : <Play size={14} />} 지금 실행
                        </button>
                        <div className="flex items-center gap-2 rounded-lg border border-line bg-white px-3 py-1.5 text-sm">
                            <span className="text-ink-2">{wf.enabled ? 'On' : 'Off'}</span>
                            <Toggle on={wf.enabled} onChange={(enabled) => update({ enabled })} />
                        </div>
                    </div>
                </div>

                <div className="mt-6">
                    <Node icon={<Clock size={15} />} tone="bg-emerald-50 text-emerald-600" kind="트리거 · 예약 실행" title={scheduleText(wf.schedule)}>
                        <div className="mt-3 flex flex-wrap items-end gap-2 text-sm">
                            <select className="ab-input !w-28 !py-1" value={wf.schedule.freq} onChange={(e) => update({ schedule: { ...wf.schedule, freq: e.target.value as Workflow['schedule']['freq'] } })}>
                                <option value="hourly">매시간</option>
                                <option value="daily">매일</option>
                                <option value="weekly">매주</option>
                                <option value="monthly">매월</option>
                            </select>
                            {wf.schedule.freq === 'weekly' && (
                                <select className="ab-input !w-24 !py-1" value={wf.schedule.dayOfWeek ?? 1} onChange={(e) => update({ schedule: { ...wf.schedule, dayOfWeek: Number(e.target.value) } })}>
                                    {DOW.map((d, i) => <option key={i} value={i}>{d}요일</option>)}
                                </select>
                            )}
                            {wf.schedule.freq === 'monthly' && (
                                <select className="ab-input !w-24 !py-1" value={wf.schedule.dayOfMonth ?? 1} onChange={(e) => update({ schedule: { ...wf.schedule, dayOfMonth: Number(e.target.value) } })}>
                                    {Array.from({ length: 28 }, (_, i) => <option key={i} value={i + 1}>{i + 1}일</option>)}
                                </select>
                            )}
                            <input type="time" className="ab-input !w-32 !py-1" value={wf.schedule.time} onChange={(e) => update({ schedule: { ...wf.schedule, time: e.target.value } })} />
                            <span className="rounded-md bg-soft px-2 py-1 text-xs text-muted">{wf.schedule.timezone}</span>
                        </div>
                        <div className="mt-2 text-xs text-muted">
                            다음 실행: <b className="font-medium text-ink-2">{wf.nextRunAt ? new Date(wf.nextRunAt).toLocaleString('ko-KR', { dateStyle: 'medium', timeStyle: 'short' }) : '-'}</b>
                            {!wf.enabled && ' (켜면 이 시간에 자동 실행돼요)'}
                        </div>
                    </Node>
                    {wf.steps.map((st, i) => (
                        <Node
                            key={st.id}
                            icon={STEP_META[st.type].icon}
                            tone={STEP_META[st.type].tone}
                            kind={`${i + 1}단계 · ${STEP_META[st.type].label}`}
                            title={st.title}
                            onDelete={() => update({ steps: wf.steps.filter((x) => x.id !== st.id) })}
                        >
                            <StepDetail system={system} step={st} onChange={(p) => update({ steps: wf.steps.map((x) => (x.id === st.id ? { ...x, ...p } : x)) })} />
                        </Node>
                    ))}
                    <div className="ml-[22px] border-l-2 border-dashed border-line-strong py-3 pl-7 text-xs text-muted">
                        단계를 추가하거나 바꾸려면 AI에게 요청하세요. 예) “마지막에 슬랙 대신 이메일로 보내줘”, “지연된 건은 상태를 위험으로 바꾸는 단계 추가”
                    </div>
                </div>

                <div className="mt-8">
                    <h2 className="mb-3 text-sm font-semibold">실행 기록</h2>
                    {wf.runs.length === 0 ? (
                        <div className="rounded-xl border border-dashed border-line-strong bg-white px-4 py-8 text-center text-sm text-muted">아직 실행 기록이 없어요. <b>테스트</b>로 결과를 미리 확인해 보세요.</div>
                    ) : (
                        <div className="space-y-2">
                            {wf.runs.map((r) => (
                                <div key={r.id} className="ab-card overflow-hidden">
                                    <button onClick={() => setOpenRun(openRun === r.id ? null : r.id)} className="flex w-full items-center gap-3 px-4 py-3 text-left text-sm hover:bg-soft">
                                        {r.status === 'success' ? <CheckCircle2 size={16} className="text-emerald-500" /> : <XCircle size={16} className="text-rose-500" />}
                                        <span className="font-medium">{r.test ? '테스트 실행' : '실행'}</span>
                                        {r.test && <span className="rounded bg-amber-50 px-1.5 py-0.5 text-[11px] text-amber-700">시뮬레이션</span>}
                                        <span className="text-xs text-muted">{new Date(r.at).toLocaleString('ko-KR')} · {relTime(r.at)}</span>
                                        <ChevronDown size={15} className={`ml-auto text-faint transition ${openRun === r.id ? 'rotate-180' : ''}`} />
                                    </button>
                                    {openRun === r.id && (
                                        <div className="border-t border-line px-4 py-3">
                                            <div className="space-y-0.5 font-mono text-xs text-ink-2">
                                                {r.log.map((l, i) => <div key={i} className="whitespace-pre-wrap">{l}</div>)}
                                            </div>
                                            {r.output && (
                                                <div className="mt-3 rounded-lg border border-line bg-soft p-3 text-sm">
                                                    <div className="mb-1 text-[11px] font-medium uppercase tracking-wide text-faint">출력</div>
                                                    <Markdown text={r.output} />
                                                </div>
                                            )}
                                        </div>
                                    )}
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}

function Node({ icon, tone, kind, title, children, onDelete }: { icon: ReactNode; tone: string; kind: string; title: string; children?: ReactNode; onDelete?: () => void }) {
    return (
        <div className="relative pb-3 pl-14">
            <div className="absolute bottom-0 left-[22px] top-11 w-0.5 bg-line-strong/70" />
            <div className={`absolute left-0 top-0 flex h-11 w-11 items-center justify-center rounded-xl ring-4 ring-soft ${tone}`}>{icon}</div>
            <div className="group ab-card p-4">
                <div className="flex items-start justify-between">
                    <div>
                        <div className="text-[11px] font-medium text-faint">{kind}</div>
                        <div className="text-[15px] font-semibold">{title}</div>
                    </div>
                    {onDelete && (
                        <button onClick={onDelete} className="rounded p-1 text-faint opacity-0 hover:bg-rose-50 hover:text-rose-600 group-hover:opacity-100" title="단계 삭제">
                            <Trash2 size={14} />
                        </button>
                    )}
                </div>
                {children}
            </div>
        </div>
    );
}

function StepDetail({ system, step, onChange }: { system: System; step: WorkflowStep; onChange: (p: Partial<WorkflowStep>) => void }) {
    const t = system.tables.find((x) => x.id === step.tableId);
    return (
        <div className="mt-2 space-y-2 text-sm">
            {t && (
                <div className="flex flex-wrap items-center gap-1.5 text-xs">
                    <span className="rounded-md bg-soft px-2 py-1 ring-1 ring-line">{t.icon} {t.name}</span>
                    {(step.filters ?? []).map((f, i) => <span key={i} className="rounded-md bg-blue-50 px-2 py-1 text-blue-700">{filterText(t, f)}</span>)}
                    {step.set && Object.entries(step.set).map(([fid, v]) => (
                        <span key={fid} className="rounded-md bg-amber-50 px-2 py-1 text-amber-700">
                            {t.fields.find((f) => f.id === fid)?.name} → {Array.isArray(v) ? v.join(', ') : String(v)}
                        </span>
                    ))}
                </div>
            )}
            {step.type === 'aiSummary' && <textarea className="ab-input min-h-16 text-sm" defaultValue={step.prompt} onBlur={(e) => e.target.value !== step.prompt && onChange({ prompt: e.target.value })} />}
            {step.type === 'email' && (
                <div className="grid grid-cols-2 gap-2">
                    <input className="ab-input !py-1 text-xs" defaultValue={step.to} placeholder="받는 사람" onBlur={(e) => onChange({ to: e.target.value })} />
                    <input className="ab-input !py-1 text-xs" defaultValue={step.subject} placeholder="제목" onBlur={(e) => onChange({ subject: e.target.value })} />
                    <p className="col-span-2 text-xs text-muted">메일함(Gmail · Outlook)이 연결되지 않아 실행 결과는 초안으로 저장돼요.</p>
                </div>
            )}
        </div>
    );
}
