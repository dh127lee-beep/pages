'use client';

import { ArrowUpRight, BarChart3, Hash, LineChart as LineIcon, List, MoreHorizontal, PieChart, Pencil, Plus, Rows3, Trash2, X, RefreshCw } from 'lucide-react';
import { useMemo, useState } from 'react';
import type { Mutation } from '@/lib/client';
import { computeWidget, formatCompact, formatNumber } from '@/lib/data';
import { CHOICE_COLORS, type ChoiceColor, type Dashboard, type Filter, type System, type Widget, type WidgetType } from '@/lib/types';
import { CellDisplay } from './cells';
import { BarChart, DonutChart, HBarChart, LineChart } from './charts';
import { HEX, MenuItem, Modal, Popover, SOFT_BG } from './ui';

interface CrossFilter {
    tableId: string;
    fieldId: string;
    value: string;
    label: string;
}

const TYPE_META: Record<WidgetType, { label: string; icon: React.ReactNode }> = {
    kpi: { label: 'KPI 카드', icon: <Hash size={14} /> },
    bar: { label: '막대 차트', icon: <BarChart3 size={14} /> },
    hbar: { label: '가로 막대', icon: <Rows3 size={14} /> },
    line: { label: '추이 (라인)', icon: <LineIcon size={14} /> },
    donut: { label: '도넛 차트', icon: <PieChart size={14} /> },
    list: { label: '레코드 목록', icon: <List size={14} /> },
};

const AGG_LABEL = { count: '개수', sum: '합계', avg: '평균', min: '최소', max: '최대' };
const COL: Record<number, string> = { 1: 'lg:col-span-1', 2: 'lg:col-span-2', 3: 'lg:col-span-3', 4: 'lg:col-span-4' };

export function DashboardView({ system, dashboard, mutate, onOpenTable }: { system: System; dashboard: Dashboard; mutate: (m: Mutation) => Promise<unknown>; onOpenTable: (tableId: string, filters?: Filter[]) => void }) {
    const [cross, setCross] = useState<CrossFilter[]>([]);
    const [editing, setEditing] = useState<Widget | 'new' | null>(null);

    const select = (w: Widget, label: string) => {
        if (!w.groupByFieldId) return;
        const field = system.tables.find((t) => t.id === w.tableId)?.fields.find((f) => f.id === w.groupByFieldId);
        const exists = cross.find((c) => c.tableId === w.tableId && c.fieldId === w.groupByFieldId);
        if (exists && exists.value === label) setCross(cross.filter((c) => c !== exists));
        else setCross([...cross.filter((c) => c !== exists), { tableId: w.tableId, fieldId: w.groupByFieldId, value: label, label: `${field?.name ?? ''}: ${label}` }]);
    };
    const extraFor = (w: Widget): Filter[] => cross.filter((c) => c.tableId === w.tableId && c.fieldId !== w.groupByFieldId).map((c) => ({ fieldId: c.fieldId, op: 'eq', value: c.value }));

    const updated = useMemo(() => new Date(system.updatedAt).toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' }), [system.updatedAt]);

    return (
        <div className="ab-scroll h-full overflow-y-auto bg-soft">
            <div className="mx-auto max-w-[1400px] px-6 py-5">
                <div className="flex flex-wrap items-start justify-between gap-3">
                    <div>
                        <div className="flex items-center gap-2">
                            <span className="text-2xl">{dashboard.icon}</span>
                            <h1 className="text-xl font-semibold tracking-tight">{dashboard.name}</h1>
                        </div>
                        <p className="mt-1 flex items-center gap-1.5 text-xs text-muted">
                            <span className="relative flex h-2 w-2">
                                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-60" />
                                <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-500" />
                            </span>
                            실시간 · 테이블 데이터로 계산 · {updated} 업데이트
                        </p>
                    </div>
                    <button className="ab-btn-outline" onClick={() => setEditing('new')}>
                        <Plus size={15} /> 위젯 추가
                    </button>
                </div>

                {cross.length > 0 && (
                    <div className="mt-4 flex flex-wrap items-center gap-1.5">
                        <span className="text-xs text-muted">필터:</span>
                        {cross.map((c) => (
                            <span key={c.fieldId} className="flex items-center gap-1 rounded-full bg-indigo-600 px-2.5 py-1 text-xs text-white">
                                {c.label}
                                <button onClick={() => setCross(cross.filter((x) => x !== c))}><X size={12} /></button>
                            </span>
                        ))}
                        <button onClick={() => setCross([])} className="flex items-center gap-1 text-xs text-muted hover:text-ink"><RefreshCw size={11} /> 초기화</button>
                    </div>
                )}

                {dashboard.widgets.length === 0 ? (
                    <div className="mt-6 rounded-2xl border border-dashed border-line-strong bg-white px-6 py-16 text-center">
                        <div className="text-sm text-muted">위젯이 없어요. 직접 추가하거나 AI에게 “매출 KPI와 월별 추이 차트 추가해줘”처럼 요청해 보세요.</div>
                        <button className="ab-btn-primary mt-4" onClick={() => setEditing('new')}><Plus size={14} /> 위젯 추가</button>
                    </div>
                ) : (
                    <div className="mt-5 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
                        {dashboard.widgets.map((w) => (
                            <WidgetCard
                                key={w.id}
                                system={system}
                                widget={w}
                                extra={extraFor(w)}
                                selected={cross.find((c) => c.tableId === w.tableId && c.fieldId === w.groupByFieldId)?.value}
                                onSelect={(label) => select(w, label)}
                                onEdit={() => setEditing(w)}
                                onDelete={() => mutate({ action: 'deleteWidget', dashboardId: dashboard.id, widgetId: w.id })}
                                onOpenTable={() => onOpenTable(w.tableId, [...(w.filters ?? []), ...cross.filter((c) => c.tableId === w.tableId).map((c) => ({ fieldId: c.fieldId, op: 'eq' as const, value: c.value }))])}
                            />
                        ))}
                    </div>
                )}
            </div>
            {editing && (
                <WidgetEditor
                    system={system}
                    initial={editing === 'new' ? null : editing}
                    onClose={() => setEditing(null)}
                    onSave={(w) => {
                        if (editing === 'new') mutate({ action: 'addWidget', dashboardId: dashboard.id, widget: w });
                        else mutate({ action: 'updateWidget', dashboardId: dashboard.id, widgetId: editing.id, patch: w });
                        setEditing(null);
                    }}
                />
            )}
        </div>
    );
}

function WidgetCard({ system, widget: w, extra, selected, onSelect, onEdit, onDelete, onOpenTable }: { system: System; widget: Widget; extra: Filter[]; selected?: string; onSelect: (l: string) => void; onEdit: () => void; onDelete: () => void; onOpenTable: () => void }) {
    const res = computeWidget(system, w, extra);
    const color = HEX[w.color ?? 'blue'] ?? '#4f46e5';
    const fmt = (n: number) => {
        if (res.valueField?.type === 'currency') return `${res.valueField.symbol ?? '₩'}${formatCompact(n)}`;
        if (res.valueField?.type === 'percent') return `${formatCompact(n)}%`;
        return formatCompact(n);
    };
    const menu = (
        <Popover
            align="right"
            trigger={(t) => (
                <button onClick={t} className="rounded-md p-1 text-faint opacity-0 transition hover:bg-mutedbg hover:text-ink group-hover:opacity-100">
                    <MoreHorizontal size={15} />
                </button>
            )}
        >
            {(close) => (
                <>
                    <MenuItem icon={<Pencil size={13} />} onClick={() => { close(); onEdit(); }}>위젯 편집</MenuItem>
                    <MenuItem icon={<ArrowUpRight size={13} />} onClick={() => { close(); onOpenTable(); }}>테이블에서 보기</MenuItem>
                    <MenuItem danger icon={<Trash2 size={13} />} onClick={() => { close(); onDelete(); }}>삭제</MenuItem>
                </>
            )}
        </Popover>
    );

    if (w.type === 'kpi') {
        const v = res.value ?? 0;
        const full = res.valueField?.type === 'currency' ? `${res.valueField.symbol ?? '₩'}${formatNumber(Math.round(v))}` : formatNumber(Math.round(v * 10) / 10);
        return (
            <div className={`group ab-card relative overflow-hidden p-4 ${COL[w.width ?? 1]}`}>
                <div className="absolute right-0 top-0 h-full w-1" style={{ background: color }} />
                <div className="flex items-start justify-between">
                    <div className="text-[13px] font-medium text-muted">{w.title}</div>
                    {menu}
                </div>
                <div className="mt-2 truncate text-[28px] font-semibold leading-none tracking-tight tabular-nums" title={full}>
                    {fmt(v)}
                </div>
                <button onClick={onOpenTable} className="mt-3 flex items-center gap-1 text-xs text-faint hover:text-accent">
                    <span className={`flex h-4 w-4 items-center justify-center rounded ${SOFT_BG[w.color ?? 'blue']}`} style={{ color }}><Hash size={10} /></span>
                    {res.table?.name} · {w.valueFieldId ? `${res.valueField?.name} ${AGG_LABEL[w.agg]}` : '레코드 수'}
                    <ArrowUpRight size={11} />
                </button>
            </div>
        );
    }

    return (
        <div className={`group ab-card flex flex-col p-4 ${COL[w.width ?? 2]} ${w.type === 'list' ? 'min-h-64' : 'h-72'}`}>
            <div className="mb-3 flex items-start justify-between">
                <div>
                    <div className="text-sm font-semibold">{w.title}</div>
                    <div className="text-[11px] text-faint">
                        {res.table?.name}
                        {w.type !== 'list' && ` · ${w.valueFieldId ? `${res.valueField?.name} ${AGG_LABEL[w.agg]}` : '개수'}`}
                        {w.groupByFieldId && ['bar', 'hbar', 'donut'].includes(w.type) && ' · 클릭해서 필터'}
                    </div>
                </div>
                {menu}
            </div>
            <div className="min-h-0 flex-1">
                {w.type === 'bar' && <BarChart data={res.series ?? []} color={w.color ? color : undefined} format={fmt} onSelect={onSelect} selected={selected} />}
                {w.type === 'hbar' && <HBarChart data={res.series ?? []} color={w.color ? color : undefined} format={fmt} onSelect={onSelect} selected={selected} />}
                {w.type === 'line' && <LineChart data={res.series ?? []} color={w.color ? color : '#4f46e5'} format={fmt} />}
                {w.type === 'donut' && <DonutChart data={res.series ?? []} format={fmt} onSelect={onSelect} selected={selected} />}
                {w.type === 'list' && res.table && (
                    <div className="overflow-x-auto">
                        <table className="w-full text-sm">
                            <thead>
                                <tr className="border-b border-line text-left text-[11px] text-faint">
                                    {(w.fieldIds?.length ? w.fieldIds : res.table.fields.slice(0, 4).map((f) => f.id)).map((fid) => (
                                        <th key={fid} className="pb-1.5 pr-3 font-medium">{res.table!.fields.find((f) => f.id === fid)?.name}</th>
                                    ))}
                                </tr>
                            </thead>
                            <tbody>
                                {(res.rows ?? []).map((r) => (
                                    <tr key={r.id} className="border-b border-line/60 last:border-0">
                                        {(w.fieldIds?.length ? w.fieldIds : res.table!.fields.slice(0, 4).map((f) => f.id)).map((fid) => {
                                            const f = res.table!.fields.find((x) => x.id === fid);
                                            return <td key={fid} className="max-w-48 truncate py-2 pr-3">{f && <CellDisplay field={f} value={r.cells[f.id]} system={system} compact />}</td>;
                                        })}
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                        {!res.rows?.length && <div className="py-8 text-center text-xs text-faint">해당하는 레코드가 없어요</div>}
                    </div>
                )}
            </div>
        </div>
    );
}

function WidgetEditor({ system, initial, onClose, onSave }: { system: System; initial: Widget | null; onClose: () => void; onSave: (w: Partial<Widget>) => void }) {
    const [w, setW] = useState<Partial<Widget>>(initial ?? { type: 'kpi', title: '', tableId: system.tables[0]?.id, agg: 'count', width: 1 });
    const table = system.tables.find((t) => t.id === w.tableId);
    const numeric = table?.fields.filter((f) => ['number', 'currency', 'percent', 'rating'].includes(f.type)) ?? [];
    const set = (p: Partial<Widget>) => setW({ ...w, ...p });
    return (
        <Modal open onClose={onClose} title={initial ? '위젯 편집' : '위젯 추가'}>
            <div className="space-y-4 p-5">
                <div className="grid grid-cols-3 gap-2">
                    {(Object.keys(TYPE_META) as WidgetType[]).map((t) => (
                        <button key={t} onClick={() => set({ type: t, width: t === 'kpi' ? 1 : 2 })} className={`flex items-center gap-2 rounded-lg border px-3 py-2 text-sm ${w.type === t ? 'border-ink bg-ink text-white' : 'border-line hover:bg-soft'}`}>
                            {TYPE_META[t].icon} {TYPE_META[t].label}
                        </button>
                    ))}
                </div>
                <Field label="제목"><input className="ab-input" value={w.title ?? ''} onChange={(e) => set({ title: e.target.value })} placeholder="예) 이번 달 매출" /></Field>
                <div className="grid grid-cols-2 gap-3">
                    <Field label="테이블">
                        <select className="ab-input" value={w.tableId} onChange={(e) => set({ tableId: e.target.value, valueFieldId: undefined, groupByFieldId: undefined, dateFieldId: undefined, fieldIds: undefined })}>
                            {system.tables.map((t) => <option key={t.id} value={t.id}>{t.icon} {t.name}</option>)}
                        </select>
                    </Field>
                    {w.type !== 'list' && (
                        <Field label="집계">
                            <div className="flex gap-1.5">
                                <select className="ab-input" value={w.valueFieldId ? w.agg : 'count'} onChange={(e) => set({ agg: e.target.value as Widget['agg'], valueFieldId: e.target.value === 'count' ? undefined : w.valueFieldId ?? numeric[0]?.id })}>
                                    {Object.entries(AGG_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
                                </select>
                                {w.valueFieldId !== undefined && (
                                    <select className="ab-input" value={w.valueFieldId} onChange={(e) => set({ valueFieldId: e.target.value })}>
                                        {numeric.map((f) => <option key={f.id} value={f.id}>{f.name}</option>)}
                                    </select>
                                )}
                            </div>
                        </Field>
                    )}
                </div>
                {['bar', 'hbar', 'donut'].includes(w.type ?? '') && (
                    <Field label="그룹 기준">
                        <select className="ab-input" value={w.groupByFieldId ?? ''} onChange={(e) => set({ groupByFieldId: e.target.value })}>
                            <option value="">선택…</option>
                            {table?.fields.filter((f) => ['singleSelect', 'multiSelect', 'person', 'text', 'link', 'checkbox'].includes(f.type)).map((f) => <option key={f.id} value={f.id}>{f.name}</option>)}
                        </select>
                    </Field>
                )}
                {w.type === 'line' && (
                    <div className="grid grid-cols-2 gap-3">
                        <Field label="날짜 필드">
                            <select className="ab-input" value={w.dateFieldId ?? ''} onChange={(e) => set({ dateFieldId: e.target.value })}>
                                <option value="">선택…</option>
                                {table?.fields.filter((f) => f.type === 'date').map((f) => <option key={f.id} value={f.id}>{f.name}</option>)}
                            </select>
                        </Field>
                        <Field label="단위">
                            <select className="ab-input" value={w.bucket ?? 'month'} onChange={(e) => set({ bucket: e.target.value as Widget['bucket'] })}>
                                <option value="month">월</option>
                                <option value="week">주</option>
                                <option value="day">일</option>
                            </select>
                        </Field>
                    </div>
                )}
                {w.type === 'list' && (
                    <Field label="표시할 필드">
                        <div className="flex flex-wrap gap-1.5">
                            {table?.fields.map((f) => {
                                const on = w.fieldIds?.includes(f.id);
                                return (
                                    <button key={f.id} onClick={() => set({ fieldIds: on ? w.fieldIds?.filter((x) => x !== f.id) : [...(w.fieldIds ?? []), f.id] })} className={`rounded-full px-2.5 py-1 text-xs ${on ? 'bg-ink text-white' : 'bg-mutedbg text-ink-2'}`}>
                                        {f.name}
                                    </button>
                                );
                            })}
                        </div>
                    </Field>
                )}
                <div className="grid grid-cols-2 gap-3">
                    <Field label="너비">
                        <select className="ab-input" value={w.width ?? 1} onChange={(e) => set({ width: Number(e.target.value) as Widget['width'] })}>
                            <option value={1}>1/4</option>
                            <option value={2}>2/4</option>
                            <option value={3}>3/4</option>
                            <option value={4}>전체</option>
                        </select>
                    </Field>
                    <Field label="색상">
                        <div className="flex flex-wrap gap-1.5 pt-1">
                            {CHOICE_COLORS.filter((c) => c !== 'gray').map((c) => (
                                <button key={c} onClick={() => set({ color: c as ChoiceColor })} className={`h-6 w-6 rounded-full ${w.color === c ? 'ring-2 ring-ink ring-offset-2' : ''}`} style={{ background: HEX[c] }} />
                            ))}
                        </div>
                    </Field>
                </div>
                {initial?.filters?.length ? <p className="text-xs text-muted">이 위젯에는 AI가 설정한 필터 {initial.filters.length}개가 적용되어 있어요.</p> : null}
                <div className="flex justify-end gap-2 pt-2">
                    <button className="ab-btn" onClick={onClose}>취소</button>
                    <button className="ab-btn-primary" disabled={!w.tableId || !w.title?.trim()} onClick={() => onSave(w)}>저장</button>
                </div>
            </div>
        </Modal>
    );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
    return (
        <div className="block">
            <span className="mb-1.5 block text-xs font-medium text-muted">{label}</span>
            {children}
        </div>
    );
}
