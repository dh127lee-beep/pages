'use client';

import {
    Check,
    ChevronRight,
    Home as HomeIcon,
    LayoutDashboard,
    Loader2,
    MoreHorizontal,
    PanelRightOpen,
    Pencil,
    Plus,
    Share2,
    Sparkles,
    Table2,
    Trash2,
    Upload,
    Workflow as WorkflowIcon,
} from 'lucide-react';
import Link from 'next/link';
import { useCallback, useEffect, useRef, useState, type ReactNode } from 'react';
import { api, sendMutation, streamAgent, uploadFiles, type Attachment, type Mutation } from '@/lib/client';
import { mutate as applyMutation } from '@/lib/mutate';
import type { Filter, Share, System } from '@/lib/types';
import { ChatPanel, type LiveRun } from './chat-panel';
import { DashboardView } from './dashboard-view';
import { TableView } from './table-view';
import { Logo, MenuItem, Modal, Popover, SOFT_BG, Toggle } from './ui';
import { WorkflowView } from './workflow-view';

type Sel = { kind: 'table' | 'dashboard' | 'workflow'; id: string };

export function Workspace({ id }: { id: string }) {
    const [system, setSystem] = useState<System | null>(null);
    const [notFound, setNotFound] = useState(false);
    const [sel, setSel] = useState<Sel | null>(null);
    const [viewIds, setViewIds] = useState<Record<string, string>>({});
    const [external, setExternal] = useState<{ tableId: string; filters: Filter[] } | null>(null);
    const [live, setLive] = useState<LiveRun | null>(null);
    const [suggestions, setSuggestions] = useState<string[]>([]);
    const [chatOpen, setChatOpen] = useState(true);
    const [share, setShare] = useState(false);
    const [model, setModel] = useState<string>();
    const [saving, setSaving] = useState(false);
    const abortRef = useRef<AbortController | null>(null);
    const startedRef = useRef(false);
    const systemRef = useRef<System | null>(null);
    systemRef.current = system;

    // Default selection: first dashboard, else first table.
    const ensureSel = useCallback((s: System, cur: Sel | null): Sel | null => {
        const exists = cur && (cur.kind === 'table' ? s.tables : cur.kind === 'dashboard' ? s.dashboards : s.workflows).some((x) => x.id === cur.id);
        if (exists) return cur;
        if (s.dashboards[0]) return { kind: 'dashboard', id: s.dashboards[0].id };
        if (s.tables[0]) return { kind: 'table', id: s.tables[0].id };
        return null;
    }, []);

    useEffect(() => {
        api<System>(`/api/systems/${id}`)
            .then((s) => {
                setSystem(s);
                // Deep link: #table/<id>[/<viewId>], #dashboard/<id>, #workflow/<id>
                const [kind, sid, vid] = window.location.hash.slice(1).split('/');
                const fromHash = (['table', 'dashboard', 'workflow'] as const).find((k) => k === kind);
                if (fromHash && sid) {
                    setSel(ensureSel(s, { kind: fromHash, id: sid }));
                    if (vid) setViewIds({ [sid]: vid });
                } else setSel((cur) => ensureSel(s, cur));
            })
            .catch(() => setNotFound(true));
        api<{ model: string }>('/api/ai').then((r) => setModel(r.model)).catch(() => {});
    }, [id, ensureSel]);

    const mutate = useCallback(
        async (m: Mutation) => {
            const cur = systemRef.current;
            if (cur) {
                // Optimistic: apply locally first; the server response is authoritative.
                try {
                    const draft = structuredClone(cur);
                    applyMutation(draft, m);
                    setSystem(draft);
                } catch {}
            }
            setSaving(true);
            try {
                const res = await sendMutation(id, m);
                setSystem(res.system);
                setSel((s) => ensureSel(res.system, s));
                return res;
            } catch (e) {
                alert((e as Error).message);
                api<System>(`/api/systems/${id}`).then(setSystem).catch(() => {});
            } finally {
                setSaving(false);
            }
        },
        [id, ensureSel],
    );

    const runAgent = useCallback(
        async (text: string, attachments: Attachment[]) => {
            const ctrl = new AbortController();
            abortRef.current = ctrl;
            setSuggestions([]);
            const userText = text + (attachments.length ? `\n\n📎 ${attachments.map((a) => a.name).join(', ')}` : '');
            setLive({ status: '요청을 분석하고 있어요…', says: [], actions: [], userText });
            const building = !systemRef.current?.tables.length;
            try {
                await streamAgent(
                    id,
                    text,
                    attachments,
                    (e) => {
                        if (e.type === 'status') setLive((l) => l && { ...l, status: e.text });
                        else if (e.type === 'say') setLive((l) => l && { ...l, says: [...l.says, e.text] });
                        else if (e.type === 'action') setLive((l) => l && { ...l, actions: [...l.actions, e.text] });
                        else if (e.type === 'suggest') setSuggestions(e.items);
                        else if (e.type === 'system') {
                            setSystem(e.system);
                            if (e.focus && (building || e.focus.kind === 'dashboard' || e.focus.kind === 'workflow')) setSel(e.focus);
                            else setSel((s) => ensureSel(e.system, s));
                        } else if (e.type === 'done') {
                            setSystem((s) => (s && !s.chat.some((m) => m.id === e.message.id) ? { ...s, chat: [...s.chat, e.message] } : s));
                        } else if (e.type === 'error') setLive((l) => l && { ...l, says: [...l.says, `⚠️ ${e.text}`] });
                    },
                    ctrl.signal,
                );
            } catch (e) {
                if ((e as Error).name !== 'AbortError') alert((e as Error).message);
            } finally {
                setLive(null);
                abortRef.current = null;
                // Re-sync: picks up the persisted chat history and final state.
                api<System>(`/api/systems/${id}`).then((s) => {
                    setSystem(s);
                    setSel((cur) => ensureSel(s, cur));
                }).catch(() => {});
            }
        },
        [id, ensureSel],
    );

    useEffect(() => {
        if (!sel) return;
        const hash = `#${sel.kind}/${sel.id}${sel.kind === 'table' && viewIds[sel.id] ? `/${viewIds[sel.id]}` : ''}`;
        if (window.location.hash !== hash) history.replaceState(null, '', hash);
    }, [sel, viewIds]);

    // A prompt typed on the home page is handed over via sessionStorage and started once.
    useEffect(() => {
        if (!system || startedRef.current) return;
        startedRef.current = true;
        const key = `ab-pending-${id}`;
        const raw = sessionStorage.getItem(key);
        if (!raw) return;
        sessionStorage.removeItem(key);
        try {
            const p = JSON.parse(raw) as { message: string; attachments: Attachment[] };
            runAgent(p.message, p.attachments ?? []);
        } catch {}
    }, [system, id, runAgent]);

    const send = async (text: string, files: File[]) => {
        let atts: Attachment[] = [];
        if (files.length) {
            try {
                atts = await uploadFiles(files);
            } catch (e) {
                return alert((e as Error).message);
            }
        }
        runAgent(text, atts);
    };

    if (notFound)
        return (
            <div className="flex h-screen flex-col items-center justify-center gap-3 text-sm text-muted">
                시스템을 찾을 수 없어요.
                <Link href="/" className="ab-btn-primary">홈으로</Link>
            </div>
        );
    if (!system)
        return (
            <div className="flex h-screen items-center justify-center">
                <Loader2 className="animate-spin text-faint" />
            </div>
        );

    const table = sel?.kind === 'table' ? system.tables.find((t) => t.id === sel.id) : undefined;
    const dashboard = sel?.kind === 'dashboard' ? system.dashboards.find((d) => d.id === sel.id) : undefined;
    const workflow = sel?.kind === 'workflow' ? system.workflows.find((w) => w.id === sel.id) : undefined;
    const crumb = table ? `${table.icon} ${table.name}` : dashboard ? `${dashboard.icon} ${dashboard.name}` : workflow ? `⚡ ${workflow.name}` : '';

    return (
        <div className="flex h-screen flex-col overflow-hidden bg-white">
            <header className="flex h-12 shrink-0 items-center gap-2 border-b border-line px-3">
                <Link href="/" className="flex items-center gap-2 rounded-lg px-1.5 py-1 hover:bg-mutedbg" title="홈">
                    <Logo size={24} />
                </Link>
                <ChevronRight size={14} className="text-faint" />
                <SystemTitle system={system} mutate={mutate} />
                {crumb && (
                    <>
                        <ChevronRight size={14} className="text-faint" />
                        <span className="truncate text-sm text-muted">{crumb}</span>
                    </>
                )}
                <span className="ml-2 flex items-center gap-1 text-xs text-faint">
                    {saving || live ? <><Loader2 size={11} className="animate-spin" /> 저장 중</> : <><Check size={11} /> 저장됨</>}
                </span>
                <div className="ml-auto flex items-center gap-2">
                    <button className="ab-btn-outline !py-1" onClick={() => setShare(true)}>
                        <Share2 size={14} /> 공유
                    </button>
                    {!chatOpen && (
                        <button className="ab-btn-primary !py-1" onClick={() => setChatOpen(true)}>
                            <Sparkles size={14} /> AI 에이전트
                        </button>
                    )}
                </div>
            </header>

            <div className="flex min-h-0 flex-1">
                <Sidebar system={system} sel={sel} onSelect={(s) => { setSel(s); setExternal(null); }} mutate={mutate} onImport={(files) => send('첨부한 파일을 새 테이블로 가져와줘. 필드 이름과 유형을 알맞게 정리하고, 기존 테이블과 연결할 수 있으면 연결해줘.', files)} />

                <main className="min-w-0 flex-1">
                    {table ? (
                        <TableView
                            key={table.id}
                            system={system}
                            table={table}
                            viewId={viewIds[table.id]}
                            onViewChange={(v) => setViewIds({ ...viewIds, [table.id]: v })}
                            mutate={mutate}
                            externalFilters={external?.tableId === table.id ? external.filters : undefined}
                            onClearExternal={() => setExternal(null)}
                        />
                    ) : dashboard ? (
                        <DashboardView
                            key={dashboard.id}
                            system={system}
                            dashboard={dashboard}
                            mutate={mutate}
                            onOpenTable={(tableId, filters) => {
                                setSel({ kind: 'table', id: tableId });
                                const t = system.tables.find((x) => x.id === tableId);
                                if (t) setViewIds({ ...viewIds, [tableId]: t.views.find((v) => v.type === 'grid')?.id ?? t.views[0].id });
                                setExternal(filters?.length ? { tableId, filters } : null);
                            }}
                        />
                    ) : workflow ? (
                        <WorkflowView key={workflow.id} system={system} workflow={workflow} mutate={mutate} onSystem={setSystem} />
                    ) : (
                        <EmptyState building={!!live} live={live} onPick={(t) => runAgent(t, [])} />
                    )}
                </main>

                {chatOpen && (
                    <div className="w-[380px] shrink-0 border-l border-line">
                        <ChatPanel
                            messages={system.chat}
                            live={live}
                            suggestions={suggestions}
                            onSend={send}
                            onStop={() => abortRef.current?.abort()}
                            onClear={() => { if (confirm('대화 기록을 지울까요? (시스템은 그대로 유지돼요)')) mutate({ action: 'clearChat' }); }}
                            onClose={() => setChatOpen(false)}
                            model={model}
                        />
                    </div>
                )}
                {!chatOpen && (
                    <button onClick={() => setChatOpen(true)} className="absolute bottom-5 right-5 flex h-12 w-12 items-center justify-center rounded-full bg-ink text-white shadow-xl hover:bg-black/80" title="AI 에이전트 열기">
                        <PanelRightOpen size={18} />
                    </button>
                )}
            </div>

            <ShareDialog open={share} onClose={() => setShare(false)} system={system} mutate={mutate} />
        </div>
    );
}

function SystemTitle({ system, mutate }: { system: System; mutate: (m: Mutation) => Promise<unknown> }) {
    const [editing, setEditing] = useState(false);
    if (editing)
        return (
            <input
                autoFocus
                defaultValue={system.name}
                className="w-56 rounded-md border border-line px-2 py-0.5 text-sm font-semibold outline-none"
                onBlur={(e) => {
                    setEditing(false);
                    if (e.target.value.trim() && e.target.value !== system.name) mutate({ action: 'renameSystem', name: e.target.value.trim() });
                }}
                onKeyDown={(e) => e.key === 'Enter' && (e.target as HTMLInputElement).blur()}
            />
        );
    return (
        <button onClick={() => setEditing(true)} className="flex min-w-0 items-center gap-1.5 rounded-lg px-1.5 py-1 text-sm font-semibold hover:bg-mutedbg" title="이름 변경">
            <span className={`flex h-6 w-6 items-center justify-center rounded-md text-sm ${SOFT_BG[system.color] ?? 'bg-mutedbg'}`}>{system.icon}</span>
            <span className="max-w-60 truncate">{system.name}</span>
        </button>
    );
}

function Sidebar({ system, sel, onSelect, mutate, onImport }: { system: System; sel: Sel | null; onSelect: (s: Sel) => void; mutate: (m: Mutation) => Promise<unknown>; onImport: (files: File[]) => void }) {
    const fileRef = useRef<HTMLInputElement>(null);
    const add = async (action: 'addDashboard' | 'addTable') => {
        const res = (await mutate({ action })) as { result?: { id: string } } | undefined;
        if (res?.result) onSelect({ kind: action === 'addTable' ? 'table' : 'dashboard', id: res.result.id });
    };
    return (
        <nav className="ab-scroll flex w-60 shrink-0 flex-col overflow-y-auto border-r border-line bg-soft px-2 py-3">
            <Section title="대시보드" icon={<LayoutDashboard size={13} />} onAdd={() => add('addDashboard')}>
                {system.dashboards.map((d) => (
                    <Item key={d.id} active={sel?.kind === 'dashboard' && sel.id === d.id} icon={d.icon} label={d.name} onClick={() => onSelect({ kind: 'dashboard', id: d.id })}
                        onRename={(name) => mutate({ action: 'updateDashboard', dashboardId: d.id, name })}
                        onDelete={() => confirm(`대시보드 '${d.name}'을(를) 삭제할까요?`) && mutate({ action: 'deleteDashboard', dashboardId: d.id })} />
                ))}
                {!system.dashboards.length && <Empty text="대시보드 없음" />}
            </Section>
            <Section title="테이블" icon={<Table2 size={13} />} onAdd={() => add('addTable')}>
                {system.tables.map((t) => (
                    <Item key={t.id} active={sel?.kind === 'table' && sel.id === t.id} icon={t.icon} label={t.name} count={t.records.length} onClick={() => onSelect({ kind: 'table', id: t.id })}
                        onRename={(name) => mutate({ action: 'updateTable', tableId: t.id, name })}
                        onDelete={() => confirm(`테이블 '${t.name}'과(와) 모든 레코드를 삭제할까요?`) && mutate({ action: 'deleteTable', tableId: t.id })} />
                ))}
                {!system.tables.length && <Empty text="테이블 없음" />}
            </Section>
            <Section title="워크플로" icon={<WorkflowIcon size={13} />}>
                {system.workflows.map((w) => (
                    <Item key={w.id} active={sel?.kind === 'workflow' && sel.id === w.id} icon="⚡" label={w.name} onClick={() => onSelect({ kind: 'workflow', id: w.id })}
                        right={<Toggle size="sm" on={w.enabled} onChange={(enabled) => mutate({ action: 'updateWorkflow', workflowId: w.id, patch: { enabled } })} />}
                        onDelete={() => confirm(`워크플로 '${w.name}'을(를) 삭제할까요?`) && mutate({ action: 'deleteWorkflow', workflowId: w.id })} />
                ))}
                {!system.workflows.length && <Empty text="AI에게 자동화를 요청하세요" />}
            </Section>
            <div className="mt-auto pt-4">
                <input ref={fileRef} type="file" multiple accept=".csv,.xlsx,.xls" className="hidden" onChange={(e) => { const f = Array.from(e.target.files ?? []); e.target.value = ''; if (f.length) onImport(f); }} />
                <button onClick={() => fileRef.current?.click()} className="flex w-full items-center gap-2 rounded-lg px-2.5 py-2 text-sm text-ink-2 hover:bg-mutedbg">
                    <Upload size={14} className="text-muted" /> 데이터 가져오기
                </button>
                <Link href="/" className="flex w-full items-center gap-2 rounded-lg px-2.5 py-2 text-sm text-ink-2 hover:bg-mutedbg">
                    <HomeIcon size={14} className="text-muted" /> 내 시스템
                </Link>
            </div>
        </nav>
    );
}

function Section({ title, icon, onAdd, children }: { title: string; icon: ReactNode; onAdd?: () => void; children: ReactNode }) {
    return (
        <div className="mb-4">
            <div className="group flex items-center gap-1.5 px-2.5 pb-1 text-[11px] font-semibold uppercase tracking-wide text-faint">
                {icon} {title}
                {onAdd && (
                    <button onClick={onAdd} className="ml-auto rounded p-0.5 opacity-0 hover:bg-mutedbg hover:text-ink group-hover:opacity-100" title="추가">
                        <Plus size={13} />
                    </button>
                )}
            </div>
            <div className="space-y-px">{children}</div>
        </div>
    );
}

function Empty({ text }: { text: string }) {
    return <div className="px-2.5 py-1 text-xs text-faint">{text}</div>;
}

function Item({ active, icon, label, count, right, onClick, onRename, onDelete }: { active: boolean; icon: string; label: string; count?: number; right?: ReactNode; onClick: () => void; onRename?: (n: string) => void; onDelete?: () => void }) {
    const [renaming, setRenaming] = useState(false);
    return (
        <div onClick={onClick} className={`group flex cursor-pointer items-center gap-2 rounded-lg px-2.5 py-1.5 text-sm transition ${active ? 'bg-white font-medium text-ink shadow-[0_1px_2px_rgba(0,0,0,0.06)] ring-1 ring-line' : 'text-ink-2 hover:bg-mutedbg'}`}>
            <span className="w-4 text-center text-[13px]">{icon}</span>
            {renaming ? (
                <input autoFocus defaultValue={label} onClick={(e) => e.stopPropagation()} className="min-w-0 flex-1 rounded border border-line px-1 text-sm outline-none" onBlur={(e) => { setRenaming(false); if (e.target.value.trim()) onRename?.(e.target.value.trim()); }} onKeyDown={(e) => e.key === 'Enter' && (e.target as HTMLInputElement).blur()} />
            ) : (
                <span className="min-w-0 flex-1 truncate">{label}</span>
            )}
            {count !== undefined && <span className="text-[11px] text-faint group-hover:hidden">{count}</span>}
            {right}
            {(onRename || onDelete) && (
                <span onClick={(e) => e.stopPropagation()} className="hidden group-hover:block">
                    <Popover align="right" trigger={(t) => <button onClick={t} className="rounded p-0.5 text-faint hover:bg-white hover:text-ink"><MoreHorizontal size={13} /></button>}>
                        {(close) => (
                            <>
                                {onRename && <MenuItem icon={<Pencil size={13} />} onClick={() => { close(); setRenaming(true); }}>이름 변경</MenuItem>}
                                {onDelete && <MenuItem danger icon={<Trash2 size={13} />} onClick={() => { close(); onDelete(); }}>삭제</MenuItem>}
                            </>
                        )}
                    </Popover>
                </span>
            )}
        </div>
    );
}

function EmptyState({ building, live, onPick }: { building: boolean; live: LiveRun | null; onPick: (t: string) => void }) {
    if (building)
        return (
            <div className="flex h-full flex-col bg-soft p-6">
                <div className="mb-4 flex items-center gap-2 text-sm font-medium">
                    <Loader2 size={15} className="animate-spin text-accent" /> AgentBase가 시스템을 만들고 있어요
                    <span className="truncate text-muted">· {live?.status}</span>
                </div>
                <div className="grid grid-cols-4 gap-4">
                    {[0, 1, 2, 3].map((i) => <div key={i} className="ab-shimmer h-24 rounded-2xl" />)}
                    <div className="ab-shimmer col-span-2 h-64 rounded-2xl" />
                    <div className="ab-shimmer col-span-2 h-64 rounded-2xl" />
                </div>
                <p className="mt-6 text-center text-xs text-muted">테이블이 만들어지는 대로 이 화면에 바로 나타나요. 보통 1~3분 정도 걸려요.</p>
            </div>
        );
    const ideas = ['고객과 영업 딜을 관리하는 CRM으로 만들어줘', '프로젝트와 작업을 관리하는 트래커로 만들어줘', '재고와 발주를 관리하는 시스템으로 만들어줘'];
    return (
        <div className="ab-dots flex h-full items-center justify-center p-6">
            <div className="max-w-md rounded-2xl border border-line bg-white p-6 text-center shadow-sm">
                <Sparkles className="mx-auto text-accent" />
                <div className="mt-3 font-semibold">아직 비어 있는 시스템이에요</div>
                <p className="mt-1 text-sm text-muted">오른쪽 AI 에이전트에게 만들고 싶은 시스템을 설명하거나, 파일을 가져오세요.</p>
                <div className="mt-4 space-y-2">
                    {ideas.map((t) => (
                        <button key={t} onClick={() => onPick(t)} className="block w-full rounded-xl border border-line px-3 py-2 text-left text-sm text-ink-2 hover:bg-soft">{t}</button>
                    ))}
                </div>
            </div>
        </div>
    );
}

function ShareDialog({ open, onClose, system, mutate }: { open: boolean; onClose: () => void; system: System; mutate: (m: Mutation) => Promise<unknown> }) {
    const [email, setEmail] = useState('');
    const [role, setRole] = useState<Share['role']>('viewer');
    const [scope, setScope] = useState('workspace');
    const scopeName = (s: string) => (s === 'workspace' ? '전체 워크스페이스' : system.dashboards.find((d) => d.id === s)?.name ?? system.tables.find((t) => t.id === s)?.name ?? s);
    const ROLE = { viewer: '뷰어 · 보기만', editor: '편집자 · 데이터 수정', owner: '소유자 · 공유 관리' };
    return (
        <Modal open={open} onClose={onClose} title={`'${system.name}' 공유`}>
            <div className="p-5">
                <div className="mb-3">
                    <div className="mb-1.5 text-xs font-medium text-muted">공유 범위</div>
                    <select className="ab-input" value={scope} onChange={(e) => setScope(e.target.value)}>
                        <option value="workspace">전체 워크스페이스</option>
                        <optgroup label="대시보드">{system.dashboards.map((d) => <option key={d.id} value={d.id}>{d.icon} {d.name}</option>)}</optgroup>
                        <optgroup label="테이블">{system.tables.map((t) => <option key={t.id} value={t.id}>{t.icon} {t.name}</option>)}</optgroup>
                    </select>
                </div>
                <div className="flex gap-2">
                    <input className="ab-input" placeholder="이메일 주소" value={email} onChange={(e) => setEmail(e.target.value)} />
                    <select className="ab-input !w-40" value={role} onChange={(e) => setRole(e.target.value as Share['role'])}>
                        <option value="viewer">뷰어</option>
                        <option value="editor">편집자</option>
                        <option value="owner">소유자</option>
                    </select>
                    <button className="ab-btn-primary shrink-0" disabled={!email.trim()} onClick={async () => { await mutate({ action: 'addShare', email, role, scope }); setEmail(''); }}>
                        초대
                    </button>
                </div>
                <div className="mt-5 text-xs font-medium text-muted">접근 권한이 있는 사람</div>
                <div className="mt-2 divide-y divide-line rounded-xl border border-line">
                    <div className="flex items-center gap-3 px-3 py-2.5 text-sm">
                        <span className="flex h-7 w-7 items-center justify-center rounded-full bg-ink text-xs text-white">나</span>
                        <span className="flex-1">나 (이 컴퓨터)</span>
                        <span className="text-xs text-muted">소유자</span>
                    </div>
                    {system.shares.map((s) => (
                        <div key={`${s.email}-${s.scope}`} className="flex items-center gap-3 px-3 py-2.5 text-sm">
                            <span className="flex h-7 w-7 items-center justify-center rounded-full bg-indigo-100 text-xs font-semibold text-indigo-700">{s.email[0].toUpperCase()}</span>
                            <div className="min-w-0 flex-1">
                                <div className="truncate">{s.email}</div>
                                <div className="text-xs text-faint">{scopeName(s.scope)}</div>
                            </div>
                            <span className="text-xs text-muted">{ROLE[s.role]}</span>
                            <button onClick={() => mutate({ action: 'removeShare', email: s.email, scope: s.scope })} className="rounded p-1 text-faint hover:bg-rose-50 hover:text-rose-600"><Trash2 size={13} /></button>
                        </div>
                    ))}
                </div>
                <p className="mt-4 text-xs text-muted">접근은 링크가 아니라 초대로 결정돼요. 로컬 버전에서는 초대 목록만 기록되며, 같은 네트워크의 사용자는 이 주소로 접속할 수 있어요.</p>
            </div>
        </Modal>
    );
}

