'use client';

import { X } from 'lucide-react';
import { useEffect, useRef, useState, type ReactNode } from 'react';
import type { ChoiceColor } from '@/lib/types';

export const CHIP: Record<ChoiceColor, string> = {
    blue: 'bg-blue-50 text-blue-700 ring-blue-200/60',
    green: 'bg-emerald-50 text-emerald-700 ring-emerald-200/60',
    amber: 'bg-amber-50 text-amber-800 ring-amber-200/60',
    red: 'bg-rose-50 text-rose-700 ring-rose-200/60',
    purple: 'bg-violet-50 text-violet-700 ring-violet-200/60',
    pink: 'bg-pink-50 text-pink-700 ring-pink-200/60',
    cyan: 'bg-cyan-50 text-cyan-700 ring-cyan-200/60',
    orange: 'bg-orange-50 text-orange-700 ring-orange-200/60',
    gray: 'bg-zinc-100 text-zinc-700 ring-zinc-200/60',
    teal: 'bg-teal-50 text-teal-700 ring-teal-200/60',
};

export const DOT: Record<ChoiceColor, string> = {
    blue: 'bg-blue-500', green: 'bg-emerald-500', amber: 'bg-amber-500', red: 'bg-rose-500', purple: 'bg-violet-500',
    pink: 'bg-pink-500', cyan: 'bg-cyan-500', orange: 'bg-orange-500', gray: 'bg-zinc-400', teal: 'bg-teal-500',
};

export const HEX: Record<ChoiceColor, string> = {
    blue: '#3b82f6', green: '#10b981', amber: '#f59e0b', red: '#f43f5e', purple: '#8b5cf6',
    pink: '#ec4899', cyan: '#06b6d4', orange: '#f97316', gray: '#a1a1aa', teal: '#14b8a6',
};

export const PALETTE = ['#4f46e5', '#06b6d4', '#10b981', '#f59e0b', '#ec4899', '#8b5cf6', '#f97316', '#14b8a6', '#3b82f6', '#f43f5e', '#84cc16', '#a1a1aa'];

export const SOFT_BG: Record<ChoiceColor, string> = {
    blue: 'bg-blue-50', green: 'bg-emerald-50', amber: 'bg-amber-50', red: 'bg-rose-50', purple: 'bg-violet-50',
    pink: 'bg-pink-50', cyan: 'bg-cyan-50', orange: 'bg-orange-50', gray: 'bg-zinc-100', teal: 'bg-teal-50',
};

export function Chip({ color = 'gray', children, className = '' }: { color?: ChoiceColor; children: ReactNode; className?: string }) {
    return <span className={`inline-flex max-w-full items-center truncate rounded-full px-2 py-0.5 text-xs font-medium ring-1 ring-inset ${CHIP[color]} ${className}`}>{children}</span>;
}

export function Modal({ open, onClose, title, children, width = 'max-w-lg' }: { open: boolean; onClose: () => void; title?: ReactNode; children: ReactNode; width?: string }) {
    useEffect(() => {
        if (!open) return;
        const h = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
        window.addEventListener('keydown', h);
        return () => window.removeEventListener('keydown', h);
    }, [open, onClose]);
    if (!open) return null;
    return (
        <div className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-black/30 p-4 pt-[8vh] backdrop-blur-[2px]" onMouseDown={onClose}>
            <div className={`ab-pop w-full ${width} rounded-2xl bg-white shadow-2xl ring-1 ring-black/5`} onMouseDown={(e) => e.stopPropagation()}>
                {title !== undefined && (
                    <div className="flex items-center justify-between border-b border-line px-5 py-3.5">
                        <div className="text-[15px] font-semibold">{title}</div>
                        <button className="rounded-md p-1 text-muted hover:bg-mutedbg" onClick={onClose} aria-label="닫기">
                            <X size={16} />
                        </button>
                    </div>
                )}
                {children}
            </div>
        </div>
    );
}

/** Small popover menu anchored to its trigger. */
export function Popover({ trigger, children, align = 'left', className = '' }: { trigger: (open: () => void) => ReactNode; children: (close: () => void) => ReactNode; align?: 'left' | 'right'; className?: string }) {
    const [open, setOpen] = useState(false);
    const ref = useRef<HTMLDivElement>(null);
    useEffect(() => {
        if (!open) return;
        const h = (e: MouseEvent) => ref.current && !ref.current.contains(e.target as Node) && setOpen(false);
        document.addEventListener('mousedown', h);
        return () => document.removeEventListener('mousedown', h);
    }, [open]);
    return (
        <div className="relative" ref={ref}>
            {trigger(() => setOpen((o) => !o))}
            {open && (
                <div className={`ab-pop absolute z-40 mt-1 min-w-48 rounded-xl border border-line bg-white p-1 shadow-xl ${align === 'right' ? 'right-0' : 'left-0'} ${className}`}>
                    {children(() => setOpen(false))}
                </div>
            )}
        </div>
    );
}

export function MenuItem({ icon, children, onClick, danger, active }: { icon?: ReactNode; children: ReactNode; onClick?: () => void; danger?: boolean; active?: boolean }) {
    return (
        <button
            onClick={onClick}
            className={`flex w-full items-center gap-2 rounded-lg px-2.5 py-1.5 text-left text-sm transition ${danger ? 'text-rose-600 hover:bg-rose-50' : 'text-ink-2 hover:bg-mutedbg'} ${active ? 'bg-mutedbg font-medium' : ''}`}
        >
            {icon && <span className="flex w-4 justify-center text-muted">{icon}</span>}
            {children}
        </button>
    );
}

export function Toggle({ on, onChange, size = 'md' }: { on: boolean; onChange: (v: boolean) => void; size?: 'sm' | 'md' }) {
    const w = size === 'sm' ? 'h-4 w-7' : 'h-5 w-9';
    const k = size === 'sm' ? 'h-3 w-3' : 'h-4 w-4';
    const tx = size === 'sm' ? 'translate-x-3' : 'translate-x-4';
    return (
        <button
            role="switch"
            aria-checked={on}
            onClick={(e) => {
                e.stopPropagation();
                onChange(!on);
            }}
            className={`relative inline-flex shrink-0 items-center rounded-full transition ${w} ${on ? 'bg-emerald-500' : 'bg-zinc-300'}`}
        >
            <span className={`inline-block transform rounded-full bg-white shadow transition ${k} ${on ? tx : 'translate-x-0.5'}`} />
        </button>
    );
}

/** Minimal, safe markdown → React (bold, code, lists, headings, tables). */
export function Markdown({ text }: { text: string }) {
    const lines = text.split('\n');
    const out: ReactNode[] = [];
    let i = 0;
    let key = 0;
    while (i < lines.length) {
        const line = lines[i];
        if (/^\s*\|.*\|\s*$/.test(line) && i + 1 < lines.length && /^\s*\|[\s:\-|]+\|\s*$/.test(lines[i + 1])) {
            const head = splitRow(line);
            i += 2;
            const body: string[][] = [];
            while (i < lines.length && /^\s*\|.*\|\s*$/.test(lines[i])) body.push(splitRow(lines[i++]));
            out.push(
                <div key={key++} className="overflow-x-auto">
                    <table>
                        <thead>
                            <tr>{head.map((h, j) => <th key={j}>{inline(h)}</th>)}</tr>
                        </thead>
                        <tbody>
                            {body.map((r, j) => (
                                <tr key={j}>{r.map((c, k) => <td key={k}>{inline(c)}</td>)}</tr>
                            ))}
                        </tbody>
                    </table>
                </div>,
            );
            continue;
        }
        if (/^\s*[-*•]\s+/.test(line)) {
            const items: string[] = [];
            while (i < lines.length && /^\s*[-*•]\s+/.test(lines[i])) items.push(lines[i++].replace(/^\s*[-*•]\s+/, ''));
            out.push(<ul key={key++}>{items.map((t, j) => <li key={j}>{inline(t)}</li>)}</ul>);
            continue;
        }
        if (/^\s*\d+[.)]\s+/.test(line)) {
            const items: string[] = [];
            while (i < lines.length && /^\s*\d+[.)]\s+/.test(lines[i])) items.push(lines[i++].replace(/^\s*\d+[.)]\s+/, ''));
            out.push(<ol key={key++}>{items.map((t, j) => <li key={j}>{inline(t)}</li>)}</ol>);
            continue;
        }
        const h = /^(#{1,4})\s+(.*)$/.exec(line);
        if (h) out.push(h[1].length === 1 ? <h1 key={key++}>{inline(h[2])}</h1> : h[1].length === 2 ? <h2 key={key++}>{inline(h[2])}</h2> : <h3 key={key++}>{inline(h[2])}</h3>);
        else if (line.trim()) out.push(<p key={key++}>{inline(line)}</p>);
        i++;
    }
    return <div className="ab-prose">{out}</div>;
}

function splitRow(line: string) {
    return line.trim().replace(/^\||\|$/g, '').split('|').map((c) => c.trim());
}

function inline(t: string): ReactNode[] {
    const parts = t.split(/(\*\*[^*]+\*\*|`[^`]+`)/g);
    return parts.map((p, i) =>
        p.startsWith('**') && p.endsWith('**') ? <strong key={i}>{p.slice(2, -2)}</strong> : p.startsWith('`') && p.endsWith('`') ? <code key={i}>{p.slice(1, -1)}</code> : p,
    );
}

export function Logo({ size = 28 }: { size?: number }) {
    return (
        <div className="flex items-center justify-center rounded-[9px] bg-ink text-white" style={{ width: size, height: size }}>
            <svg width={size * 0.6} height={size * 0.6} viewBox="0 0 24 24" fill="none">
                <rect x="3" y="3" width="8" height="8" rx="2" fill="white" />
                <rect x="13" y="3" width="8" height="8" rx="4" fill="white" opacity=".55" />
                <rect x="3" y="13" width="8" height="8" rx="4" fill="white" opacity=".55" />
                <path d="M17 13l1.2 2.8L21 17l-2.8 1.2L17 21l-1.2-2.8L13 17l2.8-1.2z" fill="white" />
            </svg>
        </div>
    );
}
