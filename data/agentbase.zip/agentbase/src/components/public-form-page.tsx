'use client';

import type { System } from '@/lib/types';
import { PublicForm } from './table-view';
import { Logo } from './ui';

export function PublicFormPage({ system, tableId, viewId }: { system: System; tableId: string; viewId: string }) {
    const table = system.tables.find((t) => t.id === tableId)!;
    const view = table.views.find((v) => v.id === viewId)!;
    return (
        <div className="ab-dots min-h-screen bg-soft px-4 py-12">
            <PublicForm system={system} table={table} view={view} />
            <div className="mt-6 flex items-center justify-center gap-1.5 text-xs text-faint">
                <Logo size={16} /> AgentBase로 만든 양식
            </div>
        </div>
    );
}
