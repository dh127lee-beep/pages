'use client';

import {
    ArrowDownUp,
    CalendarDays,
    ChevronLeft,
    ChevronRight,
    Copy,
    Download,
    EyeOff,
    Filter as FilterIcon,
    FormInput,
    GalleryHorizontalEnd,
    Kanban,
    Maximize2,
    MoreHorizontal,
    Pencil,
    Plus,
    Search,
    Settings2,
    Sheet,
    Trash2,
    X,
    ExternalLink,
    Check,
} from 'lucide-react';
import { useMemo, useState, type ReactNode } from 'react';
import type { Mutation } from '@/lib/client';
import { applyFilters, cellText, recordTitle, sortRecords } from '@/lib/data';
import { FIELD_TYPES, type CellValue, type Field, type FieldType, type Filter, type FilterOp, type RecordRow, type System, type Table, type View, type ViewType } from '@/lib/types';
import { CellDisplay, CellEditor, FIELD_ICON, RecordModal } from './cells';
import { Chip, DOT, MenuItem, Popover, Toggle } from './ui';

export const VIEW_META: Record<ViewType, { label: string; icon: ReactNode; desc: string }> = {
    grid: { label: '그리드', icon: <Sheet size={14} />, desc: '전체 필드 보기 · 일괄 편집' },
    kanban: { label: '칸반', icon: <Kanban size={14} />, desc: '단계별 진행 관리' },
    gallery: { label: '갤러리', icon: <GalleryHorizontalEnd size={14} />, desc: '카드 · 이미지 중심' },
    calendar: { label: '캘린더', icon: <CalendarDays size={14} />, desc: '날짜 기반 일정' },
    form: { label: '양식', icon: <FormInput size={14} />, desc: '공유 가능한 입력 양식' },
};

const OP_LABEL: Record<FilterOp, string> = {
    eq: '같음', neq: '같지 않음', contains: '포함', gt: '>', gte: '≥', lt: '<', lte: '≤', empty: '비어 있음', notEmpty: '비어 있지 않음',
    withinDays: '앞으로 N일 이내', pastDays: '지난 N일 이내', overdue: '오늘 이전',
};

function opsFor(f?: Field): FilterOp[] {
    if (!f) return ['eq'];
    if (f.type === 'date') return ['eq', 'gt', 'lt', 'withinDays', 'pastDays', 'overdue', 'empty', 'notEmpty'];
    if (['number', 'currency', 'percent', 'rating'].includes(f.type)) return ['eq', 'neq', 'gt', 'gte', 'lt', 'lte', 'empty', 'notEmpty'];
    if (f.type === 'checkbox') return ['eq'];
    if (['singleSelect', 'multiSelect', 'person'].includes(f.type)) return ['eq', 'neq', 'empty', 'notEmpty'];
    return ['contains', 'eq', 'neq', 'empty', 'notEmpty'];
}

export function filterText(t: Table, f: Filter) {
    const field = t.fields.find((x) => x.id === f.fieldId);
    if (f.op === 'withinDays') return `${field?.name ?? '?'} 앞으로 ${f.value ?? 7}일 이내`;
    if (f.op === 'pastDays') return `${field?.name ?? '?'} 지난 ${f.value ?? 7}일 이내`;
    const noValue = ['empty', 'notEmpty', 'overdue'].includes(f.op);
    return `${field?.name ?? '?'} ${OP_LABEL[f.op]}${noValue ? '' : ` ${String(f.value ?? '')}`}`;
}

interface Props {
    system: System;
    table: Table;
    viewId?: string;
    onViewChange: (id: string) => void;
    mutate: (m: Mutation) => Promise<unknown>;
    externalFilters?: Filter[];
    onClearExternal?: () => void;
}

export function TableView({ system, table, viewId, onViewChange, mutate, externalFilters, onClearExternal }: Props) {
    const view = table.views.find((v) => v.id === viewId) ?? table.views[0];
    const [q, setQ] = useState('');
    const [openRecord, setOpenRecord] = useState<string | null>(null);
    const [renaming, setRenaming] = useState<string | null>(null);

    const records = useMemo(() => {
        let rs = applyFilters(table, table.records, [...(view?.filters ?? []), ...(externalFilters ?? [])]);
        if (q.trim()) {
            const n = q.trim().toLowerCase();
            rs = rs.filter((r) => table.fields.some((f) => cellText(f, r.cells[f.id], system).toLowerCase().includes(n)));
        }
        return sortRecords(table, rs, view?.sort);
    }, [table, view, q, externalFilters, system]);

    if (!view) return null;
    const updateView = (patch: Partial<View>) => mutate({ action: 'updateView', tableId: table.id, viewId: view.id, patch });
    const setCell = (recordId: string, fieldId: string, value: CellValue) => mutate({ action: 'setCell', tableId: table.id, recordId, fieldId, value });
    const addRecord = async (cells: Record<string, CellValue> = {}, open = true) => {
        const res = (await mutate({ action: 'addRecord', tableId: table.id, cells })) as { result?: RecordRow } | undefined;
        if (open && res?.result) setOpenRecord(res.result.id);
    };
    const rec = openRecord ? table.records.find((r) => r.id === openRecord) ?? null : null;
    const visible = table.fields.filter((f) => !view.hiddenFieldIds?.includes(f.id));

    return (
        <div className="flex h-full min-h-0 flex-col">
            <div className="flex items-center gap-2 border-b border-line px-5 pt-4">
                <div className="mr-2 flex min-w-0 items-center gap-2 pb-2.5">
                    <span className="text-xl">{table.icon}</span>
                    <h1 className="truncate text-lg font-semibold tracking-tight">{table.name}</h1>
                    <span className="rounded-full bg-mutedbg px-2 py-0.5 text-xs text-muted">{table.records.length}</span>
                </div>
            </div>
            <div className="flex items-center gap-1 border-b border-line px-4">
                <div className="ab-scroll flex min-w-0 flex-1 items-center gap-0.5 overflow-x-auto">
                    {table.views.map((v) => (
                        <div key={v.id} className={`group flex shrink-0 items-center border-b-2 ${v.id === view.id ? 'border-ink' : 'border-transparent'}`}>
                            {renaming === v.id ? (
                                <input
                                    autoFocus
                                    defaultValue={v.name}
                                    className="my-1.5 w-28 rounded border border-line px-1.5 py-0.5 text-sm outline-none"
                                    onBlur={(e) => {
                                        setRenaming(null);
                                        if (e.target.value.trim()) mutate({ action: 'updateView', tableId: table.id, viewId: v.id, patch: { name: e.target.value.trim() } });
                                    }}
                                    onKeyDown={(e) => e.key === 'Enter' && (e.target as HTMLInputElement).blur()}
                                />
                            ) : (
                                <button
                                    onClick={() => onViewChange(v.id)}
                                    onDoubleClick={() => setRenaming(v.id)}
                                    className={`flex items-center gap-1.5 px-2.5 py-2.5 text-sm ${v.id === view.id ? 'font-medium text-ink' : 'text-muted hover:text-ink'}`}
                                >
                                    <span className={v.id === view.id ? 'text-accent' : ''}>{VIEW_META[v.type].icon}</span>
                                    {v.name}
                                </button>
                            )}
                            {v.id === view.id && (
                                <Popover
                                    trigger={(t) => (
                                        <button onClick={t} className="mr-1 rounded p-0.5 text-faint hover:bg-mutedbg hover:text-ink">
                                            <MoreHorizontal size={14} />
                                        </button>
                                    )}
                                >
                                    {(close) => (
                                        <>
                                            <MenuItem icon={<Pencil size={13} />} onClick={() => { close(); setRenaming(v.id); }}>이름 변경</MenuItem>
                                            {table.views.length > 1 && (
                                                <MenuItem danger icon={<Trash2 size={13} />} onClick={() => { close(); mutate({ action: 'deleteView', tableId: table.id, viewId: v.id }); onViewChange(table.views.find((x) => x.id !== v.id)!.id); }}>
                                                    뷰 삭제
                                                </MenuItem>
                                            )}
                                        </>
                                    )}
                                </Popover>
                            )}
                        </div>
                    ))}
                    <Popover
                        trigger={(t) => (
                            <button onClick={t} className="ml-1 flex shrink-0 items-center gap-1 rounded-md px-2 py-1 text-sm text-muted hover:bg-mutedbg hover:text-ink">
                                <Plus size={14} /> 뷰 추가
                            </button>
                        )}
                    >
                        {(close) =>
                            (Object.keys(VIEW_META) as ViewType[]).map((type) => (
                                <button
                                    key={type}
                                    onClick={async () => {
                                        close();
                                        const res = (await mutate({ action: 'addView', tableId: table.id, type })) as { result?: View };
                                        if (res?.result) onViewChange(res.result.id);
                                    }}
                                    className="flex w-60 items-start gap-2.5 rounded-lg px-2.5 py-2 text-left hover:bg-mutedbg"
                                >
                                    <span className="mt-0.5 text-accent">{VIEW_META[type].icon}</span>
                                    <span>
                                        <span className="block text-sm font-medium">{VIEW_META[type].label}</span>
                                        <span className="block text-xs text-muted">{VIEW_META[type].desc}</span>
                                    </span>
                                </button>
                            ))
                        }
                    </Popover>
                </div>
            </div>

            {view.type !== 'form' && (
                <div className="flex flex-wrap items-center gap-1.5 px-4 py-2">
                    <div className="relative">
                        <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-faint" />
                        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="검색" className="h-8 w-44 rounded-lg border border-line bg-white pl-8 pr-2 text-sm outline-none focus:border-ink/30" />
                    </div>
                    <FilterButton table={table} filters={view.filters ?? []} onChange={(filters) => updateView({ filters })} />
                    <SortButton table={table} sort={view.sort} onChange={(sort) => updateView({ sort })} />
                    {view.type === 'grid' && <HideButton table={table} hidden={view.hiddenFieldIds ?? []} onChange={(hiddenFieldIds) => updateView({ hiddenFieldIds })} />}
                    {view.type !== 'grid' && <ViewSettings table={table} view={view} onChange={updateView} />}
                    {externalFilters?.length ? (
                        <span className="flex items-center gap-1 rounded-lg bg-indigo-50 px-2 py-1 text-xs text-indigo-700 ring-1 ring-indigo-100">
                            대시보드 필터: {externalFilters.map((f) => filterText(table, f)).join(', ')}
                            <button onClick={onClearExternal} className="ml-0.5 hover:text-indigo-900">
                                <X size={12} />
                            </button>
                        </span>
                    ) : null}
                    <div className="ml-auto flex items-center gap-1.5">
                        <a href={`/api/systems/${system.id}/export?table=${table.id}`} className="ab-btn !px-2 !text-xs" title="CSV 내보내기">
                            <Download size={14} /> CSV
                        </a>
                        <AddFieldButton system={system} table={table} mutate={mutate} />
                        <button onClick={() => addRecord()} className="ab-btn-primary !py-1 !text-xs">
                            <Plus size={14} /> 레코드
                        </button>
                    </div>
                </div>
            )}

            <div className="min-h-0 flex-1">
                {view.type === 'grid' && <GridView system={system} table={table} fields={visible} records={records} setCell={setCell} mutate={mutate} onOpen={setOpenRecord} onAdd={() => addRecord({}, false)} sort={view.sort} onSort={(sort) => updateView({ sort })} onHide={(id) => updateView({ hiddenFieldIds: [...(view.hiddenFieldIds ?? []), id] })} />}
                {view.type === 'kanban' && <KanbanView system={system} table={table} view={view} records={records} setCell={setCell} onOpen={setOpenRecord} onAdd={(cells) => addRecord(cells)} />}
                {view.type === 'gallery' && <GalleryView system={system} table={table} view={view} records={records} onOpen={setOpenRecord} onAdd={() => addRecord()} />}
                {view.type === 'calendar' && <CalendarView system={system} table={table} view={view} records={records} setCell={setCell} onOpen={setOpenRecord} onAdd={(cells) => addRecord(cells)} />}
                {view.type === 'form' && <FormBuilder system={system} table={table} view={view} onChange={updateView} />}
            </div>

            <RecordModal
                system={system}
                table={table}
                record={rec}
                onClose={() => setOpenRecord(null)}
                onSet={(fid, v) => rec && setCell(rec.id, fid, v)}
                onDelete={() => {
                    if (!rec) return;
                    mutate({ action: 'deleteRecords', tableId: table.id, ids: [rec.id] });
                    setOpenRecord(null);
                }}
            />
        </div>
    );
}

/* ───────────── toolbar controls ───────────── */

function ToolbarButton({ icon, label, count, onClick, active }: { icon: ReactNode; label: string; count?: number; onClick: () => void; active?: boolean }) {
    return (
        <button onClick={onClick} className={`flex h-8 items-center gap-1.5 rounded-lg px-2.5 text-sm transition ${active ? 'bg-indigo-50 text-indigo-700' : 'text-ink-2 hover:bg-mutedbg'}`}>
            {icon} {label}
            {count ? <span className="rounded bg-indigo-100 px-1 text-[11px] font-semibold text-indigo-700">{count}</span> : null}
        </button>
    );
}

function FilterButton({ table, filters, onChange }: { table: Table; filters: Filter[]; onChange: (f: Filter[]) => void }) {
    return (
        <Popover trigger={(t) => <ToolbarButton icon={<FilterIcon size={14} />} label="필터" count={filters.length} active={!!filters.length} onClick={t} />}>
            {() => (
                <div className="w-[440px] p-2">
                    {filters.length === 0 && <div className="px-1 py-2 text-xs text-muted">조건을 추가해 이 뷰에 보이는 레코드를 좁히세요.</div>}
                    {filters.map((f, i) => {
                        const field = table.fields.find((x) => x.id === f.fieldId);
                        const set = (patch: Partial<Filter>) => onChange(filters.map((x, j) => (j === i ? { ...x, ...patch } : x)));
                        return (
                            <div key={i} className="mb-1.5 flex items-center gap-1.5">
                                <span className="w-10 text-center text-xs text-faint">{i === 0 ? '조건' : '그리고'}</span>
                                <select className="ab-input !w-32 !py-1 text-xs" value={f.fieldId} onChange={(e) => set({ fieldId: e.target.value, op: opsFor(table.fields.find((x) => x.id === e.target.value))[0], value: '' })}>
                                    {table.fields.map((x) => (
                                        <option key={x.id} value={x.id}>{x.name}</option>
                                    ))}
                                </select>
                                <select className="ab-input !w-32 !py-1 text-xs" value={f.op} onChange={(e) => set({ op: e.target.value as FilterOp })}>
                                    {opsFor(field).map((op) => (
                                        <option key={op} value={op}>{OP_LABEL[op]}</option>
                                    ))}
                                </select>
                                {!['empty', 'notEmpty', 'overdue'].includes(f.op) &&
                                    (field?.type === 'singleSelect' || field?.type === 'multiSelect' ? (
                                        <select className="ab-input !py-1 text-xs" value={String(f.value ?? '')} onChange={(e) => set({ value: e.target.value })}>
                                            <option value="">선택…</option>
                                            {field.choices?.map((c) => <option key={c.name}>{c.name}</option>)}
                                        </select>
                                    ) : field?.type === 'checkbox' ? (
                                        <select className="ab-input !py-1 text-xs" value={f.value ? '1' : ''} onChange={(e) => set({ value: !!e.target.value })}>
                                            <option value="1">체크됨</option>
                                            <option value="">체크 안 됨</option>
                                        </select>
                                    ) : (
                                        <input
                                            className="ab-input !py-1 text-xs"
                                            type={field?.type === 'date' && !['withinDays', 'pastDays'].includes(f.op) ? 'date' : 'text'}
                                            placeholder={['withinDays', 'pastDays'].includes(f.op) ? '일수' : '값'}
                                            value={String(f.value ?? '')}
                                            onChange={(e) => set({ value: e.target.value })}
                                        />
                                    ))}
                                <button onClick={() => onChange(filters.filter((_, j) => j !== i))} className="rounded p-1 text-faint hover:bg-mutedbg hover:text-ink">
                                    <X size={14} />
                                </button>
                            </div>
                        );
                    })}
                    <button onClick={() => onChange([...filters, { fieldId: table.fields[0].id, op: opsFor(table.fields[0])[0], value: '' }])} className="mt-1 flex items-center gap-1 rounded-md px-2 py-1 text-xs text-muted hover:bg-mutedbg hover:text-ink">
                        <Plus size={13} /> 조건 추가
                    </button>
                </div>
            )}
        </Popover>
    );
}

function SortButton({ table, sort, onChange }: { table: Table; sort?: View['sort']; onChange: (s: View['sort'] | undefined) => void }) {
    return (
        <Popover trigger={(t) => <ToolbarButton icon={<ArrowDownUp size={14} />} label="정렬" count={sort ? 1 : 0} active={!!sort} onClick={t} />}>
            {(close) => (
                <div className="w-72 p-2">
                    <div className="flex items-center gap-1.5">
                        <select className="ab-input !py-1 text-xs" value={sort?.fieldId ?? ''} onChange={(e) => onChange(e.target.value ? { fieldId: e.target.value, dir: sort?.dir ?? 'asc' } : undefined)}>
                            <option value="">정렬 없음</option>
                            {table.fields.map((f) => (
                                <option key={f.id} value={f.id}>{f.name}</option>
                            ))}
                        </select>
                        {sort && (
                            <select className="ab-input !w-28 !py-1 text-xs" value={sort.dir} onChange={(e) => onChange({ ...sort, dir: e.target.value as 'asc' | 'desc' })}>
                                <option value="asc">오름차순</option>
                                <option value="desc">내림차순</option>
                            </select>
                        )}
                    </div>
                    {sort && (
                        <button onClick={() => { onChange(undefined); close(); }} className="mt-2 text-xs text-muted hover:text-ink">
                            정렬 해제
                        </button>
                    )}
                </div>
            )}
        </Popover>
    );
}

function HideButton({ table, hidden, onChange }: { table: Table; hidden: string[]; onChange: (h: string[]) => void }) {
    return (
        <Popover trigger={(t) => <ToolbarButton icon={<EyeOff size={14} />} label="필드 숨기기" count={hidden.length} active={!!hidden.length} onClick={t} />}>
            {() => (
                <div className="w-60 p-1">
                    {table.fields.map((f) => (
                        <label key={f.id} className="flex cursor-pointer items-center gap-2 rounded-md px-2 py-1.5 text-sm hover:bg-mutedbg">
                            <Toggle size="sm" on={!hidden.includes(f.id)} onChange={(on) => onChange(on ? hidden.filter((x) => x !== f.id) : [...hidden, f.id])} />
                            <span className="text-muted">{FIELD_ICON[f.type]}</span>
                            <span className="truncate">{f.name}</span>
                        </label>
                    ))}
                </div>
            )}
        </Popover>
    );
}

function ViewSettings({ table, view, onChange }: { table: Table; view: View; onChange: (p: Partial<View>) => void }) {
    const fieldSelect = (label: string, value: string | undefined, types: FieldType[], key: keyof View) => (
        <label className="block">
            <span className="mb-1 block text-xs text-muted">{label}</span>
            <select className="ab-input !py-1 text-xs" value={value ?? ''} onChange={(e) => onChange({ [key]: e.target.value || undefined })}>
                <option value="">없음</option>
                {table.fields.filter((f) => types.includes(f.type)).map((f) => (
                    <option key={f.id} value={f.id}>{f.name}</option>
                ))}
            </select>
        </label>
    );
    return (
        <Popover trigger={(t) => <ToolbarButton icon={<Settings2 size={14} />} label="뷰 설정" onClick={t} />}>
            {() => (
                <div className="w-64 space-y-3 p-2.5">
                    {view.type === 'kanban' && fieldSelect('그룹 기준 (단일 선택)', view.groupByFieldId, ['singleSelect', 'person'], 'groupByFieldId')}
                    {view.type === 'calendar' && fieldSelect('날짜 필드', view.dateFieldId, ['date'], 'dateFieldId')}
                    {view.type === 'gallery' && fieldSelect('커버 이미지 (URL)', view.coverFieldId, ['url'], 'coverFieldId')}
                </div>
            )}
        </Popover>
    );
}

function AddFieldButton({ system, table, mutate }: { system: System; table: Table; mutate: Props['mutate'] }) {
    const [name, setName] = useState('');
    const [type, setType] = useState<FieldType>('text');
    const [choices, setChoices] = useState('');
    const [link, setLink] = useState('');
    return (
        <Popover align="right" trigger={(t) => <button onClick={t} className="ab-btn-outline !py-1 !text-xs"><Plus size={14} /> 필드</button>}>
            {(close) => (
                <div className="w-72 space-y-2 p-2.5">
                    <input autoFocus className="ab-input !py-1.5" placeholder="필드 이름" value={name} onChange={(e) => setName(e.target.value)} />
                    <select className="ab-input !py-1.5" value={type} onChange={(e) => setType(e.target.value as FieldType)}>
                        {FIELD_TYPES.map((f) => <option key={f.type} value={f.type}>{f.label}</option>)}
                    </select>
                    {(type === 'singleSelect' || type === 'multiSelect') && <input className="ab-input !py-1.5" placeholder="옵션 (쉼표로 구분)" value={choices} onChange={(e) => setChoices(e.target.value)} />}
                    {type === 'link' && (
                        <select className="ab-input !py-1.5" value={link} onChange={(e) => setLink(e.target.value)}>
                            <option value="">연결할 테이블…</option>
                            {system.tables.filter((t) => t.id !== table.id).map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
                        </select>
                    )}
                    <button
                        className="ab-btn-primary w-full"
                        disabled={!name.trim() || (type === 'link' && !link)}
                        onClick={() => {
                            mutate({ action: 'addField', tableId: table.id, name: name.trim(), type, choices: choices.split(',').map((x) => x.trim()).filter(Boolean), linkTableId: link });
                            setName('');
                            setChoices('');
                            close();
                        }}
                    >
                        필드 추가
                    </button>
                </div>
            )}
        </Popover>
    );
}

/* ───────────── Grid ───────────── */

function GridView({ system, table, fields, records, setCell, mutate, onOpen, onAdd, sort, onSort, onHide }: {
    system: System; table: Table; fields: Field[]; records: RecordRow[]; setCell: (r: string, f: string, v: CellValue) => void; mutate: Props['mutate'];
    onOpen: (id: string) => void; onAdd: () => void; sort?: View['sort']; onSort: (s: View['sort']) => void; onHide: (id: string) => void;
}) {
    const [editing, setEditing] = useState<{ r: string; f: string } | null>(null);
    const [selected, setSelected] = useState<Set<string>>(new Set());
    const [renameField, setRenameField] = useState<string | null>(null);
    const width = (f: Field) => (f.primary ? 220 : f.type === 'longText' ? 260 : ['checkbox', 'rating'].includes(f.type) ? 110 : ['multiSelect', 'link'].includes(f.type) ? 200 : 160);
    const total = 44 + fields.reduce((a, f) => a + width(f), 0) + 40;

    return (
        <div className="relative flex h-full min-h-0 flex-col">
            {selected.size > 0 && (
                <div className="absolute bottom-4 left-1/2 z-20 flex -translate-x-1/2 items-center gap-3 rounded-xl bg-ink px-4 py-2 text-sm text-white shadow-xl">
                    {selected.size}개 선택됨
                    <button onClick={() => { mutate({ action: 'deleteRecords', tableId: table.id, ids: [...selected] }); setSelected(new Set()); }} className="flex items-center gap-1 rounded-md bg-white/10 px-2 py-1 text-xs hover:bg-white/20">
                        <Trash2 size={13} /> 삭제
                    </button>
                    <button onClick={() => setSelected(new Set())} className="text-white/60 hover:text-white"><X size={14} /></button>
                </div>
            )}
            <div className="ab-scroll min-h-0 flex-1 overflow-auto border-t border-line">
                <div style={{ minWidth: total }} className="text-sm">
                    <div className="sticky top-0 z-10 flex border-b border-line bg-soft">
                        <div className="flex w-11 shrink-0 items-center justify-center border-r border-line">
                            <input type="checkbox" className="accent-ink" checked={selected.size > 0 && selected.size === records.length} onChange={(e) => setSelected(e.target.checked ? new Set(records.map((r) => r.id)) : new Set())} />
                        </div>
                        {fields.map((f) => (
                            <div key={f.id} style={{ width: width(f) }} className={`group flex shrink-0 items-center gap-1.5 border-r border-line px-2.5 py-2 text-xs font-medium text-ink-2 ${f.primary ? 'sticky left-11 z-10 bg-soft' : ''}`}>
                                <span className="text-faint">{FIELD_ICON[f.type]}</span>
                                {renameField === f.id ? (
                                    <input autoFocus defaultValue={f.name} className="w-full rounded border border-line px-1 text-xs outline-none" onBlur={(e) => { setRenameField(null); if (e.target.value.trim()) mutate({ action: 'updateField', tableId: table.id, fieldId: f.id, name: e.target.value.trim() }); }} onKeyDown={(e) => e.key === 'Enter' && (e.target as HTMLInputElement).blur()} />
                                ) : (
                                    <span className="truncate">{f.name}</span>
                                )}
                                {sort?.fieldId === f.id && <span className="text-[10px] text-accent">{sort.dir === 'asc' ? '↑' : '↓'}</span>}
                                <span className="ml-auto opacity-0 group-hover:opacity-100">
                                    <FieldMenu system={system} table={table} field={f} mutate={mutate} onRename={() => setRenameField(f.id)} onSort={(dir) => onSort({ fieldId: f.id, dir })} onHide={() => onHide(f.id)} />
                                </span>
                            </div>
                        ))}
                        <div className="w-10 shrink-0" />
                    </div>
                    {records.map((r, i) => (
                        <div key={r.id} className={`group flex border-b border-line ${selected.has(r.id) ? 'bg-indigo-50/50' : 'bg-white hover:bg-soft/70'}`}>
                            <div className="relative flex w-11 shrink-0 items-center justify-center border-r border-line text-xs text-faint">
                                <span className={`group-hover:hidden ${selected.has(r.id) ? 'hidden' : ''}`}>{i + 1}</span>
                                <input type="checkbox" className={`accent-ink group-hover:block ${selected.has(r.id) ? 'block' : 'hidden'}`} checked={selected.has(r.id)} onChange={(e) => { const n = new Set(selected); if (e.target.checked) n.add(r.id); else n.delete(r.id); setSelected(n); }} />
                            </div>
                            {fields.map((f) => {
                                const isEditing = editing?.r === r.id && editing.f === f.id;
                                const popup = ['singleSelect', 'multiSelect', 'link'].includes(f.type);
                                return (
                                    <div
                                        key={f.id}
                                        style={{ width: width(f) }}
                                        onClick={() => {
                                            if (f.type === 'checkbox') return setCell(r.id, f.id, !r.cells[f.id]);
                                            if (!isEditing) setEditing({ r: r.id, f: f.id });
                                        }}
                                        className={`relative flex h-9 shrink-0 cursor-default items-center border-r border-line px-2.5 ${isEditing ? 'z-20 ring-2 ring-inset ring-indigo-500' : ''} ${f.primary ? `sticky left-11 z-[5] font-medium ${selected.has(r.id) ? 'bg-indigo-50' : 'bg-white group-hover:bg-soft'}` : ''}`}
                                    >
                                        {isEditing && !popup && f.type !== 'rating' ? (
                                            <div className="absolute inset-0 z-30 bg-white" style={f.type === 'longText' ? { height: 'auto' } : undefined}>
                                                <CellEditor field={f} value={r.cells[f.id]} system={system} onCommit={(v) => { setCell(r.id, f.id, v); setEditing(null); }} onCancel={() => setEditing(null)} />
                                            </div>
                                        ) : f.type === 'rating' && isEditing ? (
                                            <CellEditor field={f} value={r.cells[f.id]} system={system} onCommit={(v) => { setCell(r.id, f.id, v); setEditing(null); }} />
                                        ) : (
                                            <span className="flex min-w-0 flex-1 items-center overflow-hidden whitespace-nowrap">
                                                <CellDisplay field={f} value={r.cells[f.id]} system={system} compact />
                                            </span>
                                        )}
                                        {isEditing && popup && (
                                            <div className="absolute left-0 top-full z-40 mt-1 rounded-xl border border-line bg-white p-2 shadow-xl" onClick={(e) => e.stopPropagation()}>
                                                <CellEditor field={f} value={r.cells[f.id]} system={system} onCommit={(v) => { setCell(r.id, f.id, v); if (f.type === 'singleSelect') setEditing(null); }} />
                                                <button className="mt-1 w-full rounded-md py-1 text-xs text-muted hover:bg-mutedbg" onClick={() => setEditing(null)}>닫기</button>
                                            </div>
                                        )}
                                        {f.primary && !isEditing && (
                                            <button onClick={(e) => { e.stopPropagation(); onOpen(r.id); }} className="ml-1 hidden rounded p-0.5 text-faint hover:bg-white hover:text-accent group-hover:block" title="펼치기">
                                                <Maximize2 size={13} />
                                            </button>
                                        )}
                                    </div>
                                );
                            })}
                            <div className="w-10 shrink-0" />
                        </div>
                    ))}
                    <button onClick={onAdd} className="flex w-full items-center gap-1.5 border-b border-line px-4 py-2 text-left text-sm text-muted hover:bg-soft">
                        <Plus size={14} /> 새 레코드
                    </button>
                    {editing && <div className="fixed inset-0 z-10" onClick={() => setEditing(null)} />}
                </div>
            </div>
            <div className="border-t border-line bg-soft px-4 py-1.5 text-xs text-muted">{records.length}개 레코드</div>
        </div>
    );
}

function FieldMenu({ system, table, field, mutate, onRename, onSort, onHide }: { system: System; table: Table; field: Field; mutate: Props['mutate']; onRename: () => void; onSort: (d: 'asc' | 'desc') => void; onHide: () => void }) {
    return (
        <Popover
            align="right"
            trigger={(t) => (
                <button onClick={(e) => { e.stopPropagation(); t(); }} className="rounded p-0.5 text-faint hover:bg-white hover:text-ink">
                    <MoreHorizontal size={13} />
                </button>
            )}
        >
            {(close) => (
                <div className="w-52">
                    <MenuItem icon={<Pencil size={13} />} onClick={() => { close(); onRename(); }}>이름 변경</MenuItem>
                    <div className="px-2.5 pb-1 pt-2 text-[11px] text-faint">필드 유형</div>
                    <select
                        className="ab-input mx-1 mb-1 !w-[calc(100%-8px)] !py-1 text-xs"
                        value={field.type}
                        onChange={(e) => {
                            close();
                            const type = e.target.value as FieldType;
                            const linkTableId = type === 'link' ? system.tables.find((t) => t.id !== table.id)?.id : undefined;
                            mutate({ action: 'updateField', tableId: table.id, fieldId: field.id, type, linkTableId });
                        }}
                    >
                        {FIELD_TYPES.map((f) => <option key={f.type} value={f.type}>{f.label}</option>)}
                    </select>
                    <MenuItem icon={<span className="text-xs">↑</span>} onClick={() => { close(); onSort('asc'); }}>오름차순 정렬</MenuItem>
                    <MenuItem icon={<span className="text-xs">↓</span>} onClick={() => { close(); onSort('desc'); }}>내림차순 정렬</MenuItem>
                    <MenuItem icon={<EyeOff size={13} />} onClick={() => { close(); onHide(); }}>이 뷰에서 숨기기</MenuItem>
                    {!field.primary && (
                        <MenuItem danger icon={<Trash2 size={13} />} onClick={() => { close(); if (confirm(`'${field.name}' 필드를 삭제할까요?`)) mutate({ action: 'deleteField', tableId: table.id, fieldId: field.id }); }}>
                            필드 삭제
                        </MenuItem>
                    )}
                </div>
            )}
        </Popover>
    );
}

/* ───────────── Kanban ───────────── */

function CardFields({ system, table, record, exclude }: { system: System; table: Table; record: RecordRow; exclude: string[] }) {
    const fields = table.fields.filter((f) => !f.primary && !exclude.includes(f.id) && f.type !== 'longText' && f.type !== 'url' && record.cells[f.id] !== null && record.cells[f.id] !== undefined && record.cells[f.id] !== '').slice(0, 4);
    return (
        <div className="mt-2 space-y-1">
            {fields.map((f) => (
                <div key={f.id} className="flex items-center gap-1.5 text-xs text-muted">
                    <span className="shrink-0 text-faint">{FIELD_ICON[f.type]}</span>
                    <span className="min-w-0 truncate text-ink-2">
                        <CellDisplay field={f} value={record.cells[f.id]} system={system} compact />
                    </span>
                </div>
            ))}
        </div>
    );
}

function KanbanView({ system, table, view, records, setCell, onOpen, onAdd }: { system: System; table: Table; view: View; records: RecordRow[]; setCell: (r: string, f: string, v: CellValue) => void; onOpen: (id: string) => void; onAdd: (cells: Record<string, CellValue>) => void }) {
    const field = table.fields.find((f) => f.id === view.groupByFieldId);
    const [dragOver, setDragOver] = useState<string | null>(null);
    if (!field) return <div className="p-10 text-center text-sm text-muted">뷰 설정에서 그룹 기준 필드(단일 선택)를 고르세요.</div>;
    const columns: { name: string; color: keyof typeof DOT }[] =
        field.type === 'singleSelect'
            ? [...(field.choices ?? []).map((c) => ({ name: c.name, color: c.color })), { name: '', color: 'gray' as const }]
            : [...new Set(records.map((r) => String(r.cells[field.id] ?? '')))].map((n) => ({ name: n, color: 'gray' as const }));
    return (
        <div className="ab-scroll flex h-full gap-3 overflow-x-auto bg-soft p-4">
            {columns.map((col) => {
                const items = records.filter((r) => String(r.cells[field.id] ?? '') === col.name);
                if (!col.name && !items.length) return null;
                return (
                    <div
                        key={col.name || '__none'}
                        onDragOver={(e) => { e.preventDefault(); setDragOver(col.name); }}
                        onDragLeave={() => setDragOver(null)}
                        onDrop={(e) => { setDragOver(null); const id = e.dataTransfer.getData('text/plain'); if (id) setCell(id, field.id, col.name || null); }}
                        className={`flex w-72 shrink-0 flex-col rounded-xl transition ${dragOver === col.name ? 'bg-indigo-50 ring-2 ring-indigo-200' : 'bg-mutedbg/70'}`}
                    >
                        <div className="flex items-center gap-2 px-3 py-2.5">
                            <span className={`h-2 w-2 rounded-full ${DOT[col.color]}`} />
                            <span className="text-sm font-medium">{col.name || '미지정'}</span>
                            <span className="text-xs text-faint">{items.length}</span>
                            <button onClick={() => onAdd(col.name ? { [field.id]: col.name } : {})} className="ml-auto rounded p-0.5 text-faint hover:bg-white hover:text-ink">
                                <Plus size={14} />
                            </button>
                        </div>
                        <div className="ab-scroll min-h-16 flex-1 space-y-2 overflow-y-auto px-2 pb-2">
                            {items.map((r) => (
                                <div
                                    key={r.id}
                                    draggable
                                    onDragStart={(e) => e.dataTransfer.setData('text/plain', r.id)}
                                    onClick={() => onOpen(r.id)}
                                    className="cursor-pointer rounded-lg border border-line bg-white p-3 shadow-[0_1px_2px_rgba(0,0,0,0.04)] transition hover:border-line-strong hover:shadow-md active:cursor-grabbing"
                                >
                                    <div className="text-sm font-medium leading-snug">{recordTitle(table, r)}</div>
                                    <CardFields system={system} table={table} record={r} exclude={[field.id]} />
                                </div>
                            ))}
                        </div>
                    </div>
                );
            })}
        </div>
    );
}

/* ───────────── Gallery ───────────── */

function GalleryView({ system, table, view, records, onOpen, onAdd }: { system: System; table: Table; view: View; records: RecordRow[]; onOpen: (id: string) => void; onAdd: () => void }) {
    const cover = table.fields.find((f) => f.id === view.coverFieldId);
    const tones = ['from-indigo-100 to-violet-50', 'from-cyan-100 to-sky-50', 'from-emerald-100 to-teal-50', 'from-amber-100 to-orange-50', 'from-pink-100 to-rose-50'];
    return (
        <div className="ab-scroll h-full overflow-y-auto bg-soft p-4">
            <div className="grid grid-cols-[repeat(auto-fill,minmax(220px,1fr))] gap-4">
                {records.map((r, i) => {
                    const src = cover ? String(r.cells[cover.id] ?? '') : '';
                    return (
                        <div key={r.id} onClick={() => onOpen(r.id)} className="cursor-pointer overflow-hidden rounded-xl border border-line bg-white transition hover:-translate-y-0.5 hover:shadow-lg">
                            {src ? (
                                // eslint-disable-next-line @next/next/no-img-element
                                <img src={src} alt="" className="h-36 w-full bg-mutedbg object-cover" loading="lazy" />
                            ) : (
                                <div className={`flex h-36 items-center justify-center bg-gradient-to-br text-4xl ${tones[i % tones.length]}`}>{table.icon}</div>
                            )}
                            <div className="p-3">
                                <div className="truncate text-sm font-semibold">{recordTitle(table, r)}</div>
                                <CardFields system={system} table={table} record={r} exclude={cover ? [cover.id] : []} />
                            </div>
                        </div>
                    );
                })}
                <button onClick={onAdd} className="flex min-h-48 items-center justify-center rounded-xl border-2 border-dashed border-line-strong text-sm text-muted hover:bg-white">
                    <Plus size={16} /> 새 레코드
                </button>
            </div>
        </div>
    );
}

/* ───────────── Calendar ───────────── */

function CalendarView({ system, table, view, records, setCell, onOpen, onAdd }: { system: System; table: Table; view: View; records: RecordRow[]; setCell: (r: string, f: string, v: CellValue) => void; onOpen: (id: string) => void; onAdd: (cells: Record<string, CellValue>) => void }) {
    const [month, setMonth] = useState(() => {
        const d = new Date();
        return new Date(d.getFullYear(), d.getMonth(), 1);
    });
    const field = table.fields.find((f) => f.id === view.dateFieldId);
    const color = table.fields.find((f) => f.type === 'singleSelect');
    if (!field) return <div className="p-10 text-center text-sm text-muted">뷰 설정에서 날짜 필드를 고르세요.</div>;
    const start = new Date(month);
    start.setDate(1 - month.getDay());
    const days = Array.from({ length: 42 }, (_, i) => {
        const d = new Date(start);
        d.setDate(start.getDate() + i);
        return d;
    });
    const key = (d: Date) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    const byDay = new Map<string, RecordRow[]>();
    for (const r of records) {
        const v = String(r.cells[field.id] ?? '').slice(0, 10);
        if (v) byDay.set(v, [...(byDay.get(v) ?? []), r]);
    }
    const today = key(new Date());
    const noDate = records.filter((r) => !r.cells[field.id]).length;
    return (
        <div className="flex h-full flex-col p-4 pt-1">
            <div className="mb-2 flex items-center gap-2">
                <button className="ab-btn !p-1.5" onClick={() => setMonth(new Date(month.getFullYear(), month.getMonth() - 1, 1))}><ChevronLeft size={16} /></button>
                <div className="w-32 text-center text-[15px] font-semibold">{month.getFullYear()}년 {month.getMonth() + 1}월</div>
                <button className="ab-btn !p-1.5" onClick={() => setMonth(new Date(month.getFullYear(), month.getMonth() + 1, 1))}><ChevronRight size={16} /></button>
                <button className="ab-btn-outline !py-1 !text-xs" onClick={() => { const d = new Date(); setMonth(new Date(d.getFullYear(), d.getMonth(), 1)); }}>오늘</button>
                <span className="ml-2 text-xs text-muted">{field.name} 기준{noDate ? ` · 날짜 없음 ${noDate}건` : ''}</span>
            </div>
            <div className="grid grid-cols-7 border-l border-t border-line text-xs text-muted">
                {['일', '월', '화', '수', '목', '금', '토'].map((d, i) => (
                    <div key={d} className={`border-b border-r border-line bg-soft px-2 py-1.5 font-medium ${i === 0 ? 'text-rose-500' : i === 6 ? 'text-blue-500' : ''}`}>{d}</div>
                ))}
            </div>
            <div className="grid min-h-0 flex-1 grid-cols-7 grid-rows-6 border-l border-line">
                {days.map((d) => {
                    const k = key(d);
                    const items = byDay.get(k) ?? [];
                    const inMonth = d.getMonth() === month.getMonth();
                    return (
                        <div
                            key={k}
                            onDragOver={(e) => e.preventDefault()}
                            onDrop={(e) => { const id = e.dataTransfer.getData('text/plain'); if (id) setCell(id, field.id, k); }}
                            onDoubleClick={() => onAdd({ [field.id]: k })}
                            className={`group min-h-0 overflow-hidden border-b border-r border-line p-1 ${inMonth ? 'bg-white' : 'bg-soft/60'}`}
                        >
                            <div className="mb-0.5 flex items-center justify-between">
                                <span className={`flex h-5 min-w-5 items-center justify-center rounded-full px-1 text-xs ${k === today ? 'bg-ink font-semibold text-white' : inMonth ? 'text-ink-2' : 'text-faint'}`}>{d.getDate()}</span>
                                <button onClick={() => onAdd({ [field.id]: k })} className="hidden rounded p-0.5 text-faint hover:bg-mutedbg hover:text-ink group-hover:block"><Plus size={12} /></button>
                            </div>
                            <div className="ab-scroll max-h-[calc(100%-22px)] space-y-0.5 overflow-y-auto">
                                {items.map((r) => {
                                    const c = color ? color.choices?.find((x) => x.name === r.cells[color.id])?.color : undefined;
                                    return (
                                        <div key={r.id} draggable onDragStart={(e) => e.dataTransfer.setData('text/plain', r.id)} onClick={() => onOpen(r.id)} className="flex cursor-pointer items-center gap-1 truncate rounded-md bg-mutedbg px-1.5 py-0.5 text-[11px] text-ink-2 hover:bg-indigo-50">
                                            <span className={`h-1.5 w-1.5 shrink-0 rounded-full ${DOT[c ?? 'blue']}`} />
                                            <span className="truncate">{recordTitle(table, r)}</span>
                                        </div>
                                    );
                                })}
                            </div>
                        </div>
                    );
                })}
            </div>
        </div>
    );
}

/* ───────────── Form ───────────── */

function FormBuilder({ system, table, view, onChange }: { system: System; table: Table; view: View; onChange: (p: Partial<View>) => void }) {
    const [copied, setCopied] = useState(false);
    const url = typeof window !== 'undefined' ? `${window.location.origin}/f/${system.id}/${view.id}` : '';
    const hidden = view.hiddenFieldIds ?? [];
    return (
        <div className="flex h-full min-h-0">
            <div className="ab-scroll w-72 shrink-0 overflow-y-auto border-r border-line p-4">
                <div className="mb-2 text-xs font-medium text-muted">양식 필드</div>
                {table.fields.map((f) => (
                    <label key={f.id} className={`flex items-center gap-2 rounded-md px-2 py-1.5 text-sm hover:bg-mutedbg ${f.type === 'link' ? 'opacity-50' : ''}`}>
                        <Toggle size="sm" on={!hidden.includes(f.id) && f.type !== 'link'} onChange={(on) => f.type !== 'link' && onChange({ hiddenFieldIds: on ? hidden.filter((x) => x !== f.id) : [...hidden, f.id] })} />
                        <span className="text-faint">{FIELD_ICON[f.type]}</span>
                        <span className="truncate">{f.name}</span>
                    </label>
                ))}
                <div className="mt-6 rounded-xl border border-line bg-soft p-3">
                    <div className="mb-1.5 text-xs font-medium">공유 링크</div>
                    <div className="truncate rounded-md bg-white px-2 py-1 text-xs text-muted ring-1 ring-line">{url}</div>
                    <div className="mt-2 flex gap-1.5">
                        <button className="ab-btn-outline flex-1 !py-1 !text-xs" onClick={() => { navigator.clipboard.writeText(url); setCopied(true); setTimeout(() => setCopied(false), 1500); }}>
                            {copied ? <Check size={13} /> : <Copy size={13} />} {copied ? '복사됨' : '복사'}
                        </button>
                        <a className="ab-btn-outline flex-1 !py-1 !text-xs" href={url} target="_blank" rel="noreferrer"><ExternalLink size={13} /> 열기</a>
                    </div>
                </div>
            </div>
            <div className="ab-scroll min-w-0 flex-1 overflow-y-auto bg-soft p-8">
                <PublicForm system={system} table={table} view={view} editable onChangeMeta={onChange} />
            </div>
        </div>
    );
}

export function PublicForm({ system, table, view, editable, onChangeMeta }: { system: System; table: Table; view: View; editable?: boolean; onChangeMeta?: (p: Partial<View>) => void }) {
    const fields = table.fields.filter((f) => !view.hiddenFieldIds?.includes(f.id) && f.type !== 'link');
    const [values, setValues] = useState<Record<string, CellValue>>({});
    const [state, setState] = useState<'idle' | 'sending' | 'done' | 'error'>('idle');
    const [err, setErr] = useState('');
    const submit = async () => {
        setState('sending');
        try {
            const res = await fetch(`/api/forms/${system.id}/${view.id}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ cells: values }) });
            if (!res.ok) throw new Error((await res.json()).error ?? '제출 실패');
            setState('done');
            setValues({});
        } catch (e) {
            setErr((e as Error).message);
            setState('error');
        }
    };
    return (
        <div className="mx-auto max-w-xl overflow-hidden rounded-2xl border border-line bg-white shadow-sm">
            <div className="h-2 bg-gradient-to-r from-indigo-500 via-violet-500 to-pink-500" />
            <div className="p-7">
                {editable ? (
                    <>
                        <input className="w-full text-2xl font-bold outline-none" defaultValue={view.formTitle ?? table.name} onBlur={(e) => onChangeMeta?.({ formTitle: e.target.value })} />
                        <textarea className="mt-1 w-full resize-none text-sm text-muted outline-none" placeholder="양식 설명 (선택)" defaultValue={view.formDescription ?? ''} onBlur={(e) => onChangeMeta?.({ formDescription: e.target.value })} />
                    </>
                ) : (
                    <>
                        <h1 className="text-2xl font-bold">{view.formTitle ?? table.name}</h1>
                        {view.formDescription && <p className="mt-1 text-sm text-muted">{view.formDescription}</p>}
                    </>
                )}
                {state === 'done' ? (
                    <div className="py-12 text-center">
                        <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-emerald-50 text-emerald-600"><Check size={24} /></div>
                        <div className="font-semibold">제출되었습니다. 감사합니다!</div>
                        <button className="ab-btn mt-4" onClick={() => setState('idle')}>다시 작성</button>
                    </div>
                ) : (
                    <div className="mt-6 space-y-5">
                        {fields.map((f) => (
                            <div key={f.id}>
                                <label className="mb-1.5 flex items-center gap-1.5 text-sm font-medium">
                                    {f.name}
                                    {f.primary && <span className="text-rose-500">*</span>}
                                </label>
                                <FormInputFor field={f} value={values[f.id]} onChange={(v) => setValues({ ...values, [f.id]: v })} />
                            </div>
                        ))}
                        {state === 'error' && <p className="text-sm text-rose-600">{err}</p>}
                        <button className="ab-btn-primary w-full !py-2.5" disabled={state === 'sending' || !values[fields.find((f) => f.primary)?.id ?? '']} onClick={submit}>
                            {state === 'sending' ? '제출 중…' : '제출'}
                        </button>
                    </div>
                )}
            </div>
        </div>
    );
}

function FormInputFor({ field, value, onChange }: { field: Field; value: CellValue | undefined; onChange: (v: CellValue) => void }) {
    switch (field.type) {
        case 'singleSelect':
            return (
                <div className="flex flex-wrap gap-1.5">
                    {field.choices?.map((c) => (
                        <button key={c.name} type="button" onClick={() => onChange(value === c.name ? null : c.name)} className={`rounded-full ${value === c.name ? 'ring-2 ring-ink ring-offset-1' : ''}`}>
                            <Chip color={c.color}>{c.name}</Chip>
                        </button>
                    ))}
                </div>
            );
        case 'multiSelect': {
            const arr = Array.isArray(value) ? value : [];
            return (
                <div className="flex flex-wrap gap-1.5">
                    {field.choices?.map((c) => (
                        <button key={c.name} type="button" onClick={() => onChange(arr.includes(c.name) ? arr.filter((x) => x !== c.name) : [...arr, c.name])} className={`rounded-full ${arr.includes(c.name) ? 'ring-2 ring-ink ring-offset-1' : ''}`}>
                            <Chip color={c.color}>{c.name}</Chip>
                        </button>
                    ))}
                </div>
            );
        }
        case 'checkbox':
            return <input type="checkbox" className="h-5 w-5 accent-ink" checked={Boolean(value)} onChange={(e) => onChange(e.target.checked)} />;
        case 'rating':
            return (
                <div className="flex text-2xl">
                    {[1, 2, 3, 4, 5].map((n) => (
                        <button key={n} type="button" onClick={() => onChange(n)} className={n <= (Number(value) || 0) ? 'text-amber-400' : 'text-zinc-200'}>★</button>
                    ))}
                </div>
            );
        case 'longText':
            return <textarea className="ab-input min-h-24" value={String(value ?? '')} onChange={(e) => onChange(e.target.value)} />;
        default:
            return (
                <input
                    className="ab-input"
                    type={field.type === 'date' ? 'date' : ['number', 'currency', 'percent'].includes(field.type) ? 'number' : field.type === 'email' ? 'email' : field.type === 'url' ? 'url' : 'text'}
                    value={String(value ?? '')}
                    onChange={(e) => onChange(e.target.value)}
                />
            );
    }
}
