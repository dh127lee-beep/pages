'use client';

import {
    AlignLeft,
    AtSign,
    Calendar,
    CheckSquare,
    ChevronDown,
    CircleDot,
    DollarSign,
    Hash,
    Link2,
    List,
    Percent,
    Phone,
    Star,
    Trash2,
    Type,
    User,
    Globe,
    Check,
    Plus,
} from 'lucide-react';
import { useEffect, useRef, useState, type ReactNode } from 'react';
import { cellText, recordTitle } from '@/lib/data';
import type { CellValue, Field, FieldType, RecordRow, System, Table } from '@/lib/types';
import { Chip, Modal } from './ui';

export const FIELD_ICON: Record<FieldType, ReactNode> = {
    text: <Type size={13} />,
    longText: <AlignLeft size={13} />,
    number: <Hash size={13} />,
    currency: <DollarSign size={13} />,
    percent: <Percent size={13} />,
    date: <Calendar size={13} />,
    singleSelect: <CircleDot size={13} />,
    multiSelect: <List size={13} />,
    checkbox: <CheckSquare size={13} />,
    email: <AtSign size={13} />,
    phone: <Phone size={13} />,
    url: <Globe size={13} />,
    rating: <Star size={13} />,
    person: <User size={13} />,
    link: <Link2 size={13} />,
};

const AVATAR = ['bg-blue-500', 'bg-emerald-500', 'bg-violet-500', 'bg-amber-500', 'bg-pink-500', 'bg-cyan-500'];

export function Avatar({ name, size = 18 }: { name: string; size?: number }) {
    const idx = [...name].reduce((a, c) => a + c.charCodeAt(0), 0) % AVATAR.length;
    return (
        <span className={`inline-flex shrink-0 items-center justify-center rounded-full text-[10px] font-semibold text-white ${AVATAR[idx]}`} style={{ width: size, height: size }}>
            {name.slice(0, 1)}
        </span>
    );
}

export function CellDisplay({ field, value, system, compact }: { field: Field; value: CellValue | undefined; system: System; compact?: boolean }) {
    if (value === null || value === undefined || value === '' || (Array.isArray(value) && !value.length)) {
        return field.type === 'checkbox' ? <span className="inline-block h-3.5 w-3.5 rounded border border-line-strong" /> : null;
    }
    switch (field.type) {
        case 'singleSelect': {
            const c = field.choices?.find((x) => x.name === value);
            return <Chip color={c?.color ?? 'gray'}>{String(value)}</Chip>;
        }
        case 'multiSelect':
            return (
                <span className="flex flex-wrap gap-1">
                    {(Array.isArray(value) ? value : [String(value)]).map((v) => (
                        <Chip key={v} color={field.choices?.find((x) => x.name === v)?.color ?? 'gray'}>
                            {v}
                        </Chip>
                    ))}
                </span>
            );
        case 'checkbox':
            return value ? (
                <span className="inline-flex h-3.5 w-3.5 items-center justify-center rounded bg-emerald-500 text-white">
                    <Check size={11} strokeWidth={3} />
                </span>
            ) : (
                <span className="inline-block h-3.5 w-3.5 rounded border border-line-strong" />
            );
        case 'rating': {
            const n = Number(value) || 0;
            return (
                <span className="text-amber-400">
                    {'★'.repeat(n)}
                    <span className="text-zinc-200">{'★'.repeat(Math.max(0, 5 - n))}</span>
                </span>
            );
        }
        case 'person':
            return (
                <span className="inline-flex items-center gap-1.5">
                    <Avatar name={String(value)} />
                    <span className="truncate">{String(value)}</span>
                </span>
            );
        case 'link': {
            const lt = system.tables.find((t) => t.id === field.linkTableId);
            const ids = Array.isArray(value) ? value : [String(value)];
            return (
                <span className="flex flex-wrap gap-1">
                    {ids.map((id) => {
                        const r = lt?.records.find((x) => x.id === id);
                        return r && lt ? (
                            <span key={id} className="truncate rounded-md bg-blue-50 px-1.5 py-0.5 text-xs text-blue-700 ring-1 ring-inset ring-blue-100">
                                {recordTitle(lt, r)}
                            </span>
                        ) : null;
                    })}
                </span>
            );
        }
        case 'url':
            return (
                <a href={String(value)} target="_blank" rel="noreferrer" onClick={(e) => e.stopPropagation()} className="truncate text-blue-600 hover:underline">
                    {String(value).replace(/^https?:\/\//, '')}
                </a>
            );
        case 'email':
            return <span className="truncate text-blue-600">{String(value)}</span>;
        case 'number':
        case 'currency':
        case 'percent':
            return <span className="tabular-nums">{cellText(field, value, system)}</span>;
        case 'date':
            return <span className="tabular-nums">{String(value)}</span>;
        case 'longText':
            return <span className={compact ? 'line-clamp-1' : 'whitespace-pre-wrap'}>{String(value)}</span>;
        default:
            return <span className="truncate">{String(value)}</span>;
    }
}

/** Inline editor; calls onCommit with the new value. */
export function CellEditor({ field, value, system, onCommit, onCancel, autoFocus = true }: { field: Field; value: CellValue | undefined; system: System; onCommit: (v: CellValue) => void; onCancel?: () => void; autoFocus?: boolean }) {
    const [draft, setDraft] = useState<string>(value === null || value === undefined ? '' : Array.isArray(value) ? value.join(', ') : String(value));
    const ref = useRef<HTMLInputElement & HTMLTextAreaElement>(null);
    useEffect(() => {
        if (autoFocus) ref.current?.focus();
    }, [autoFocus]);
    const commit = () => onCommit(draft);
    const keys = (e: React.KeyboardEvent) => {
        if (e.key === 'Enter' && !e.shiftKey && !e.nativeEvent.isComposing) {
            e.preventDefault();
            commit();
        }
        if (e.key === 'Escape') onCancel?.();
    };

    switch (field.type) {
        case 'checkbox':
            return <input type="checkbox" className="h-4 w-4 accent-emerald-500" checked={Boolean(value)} onChange={(e) => onCommit(e.target.checked)} />;
        case 'rating':
            return (
                <span className="flex">
                    {[1, 2, 3, 4, 5].map((n) => (
                        <button key={n} onClick={() => onCommit(n === Number(value) ? 0 : n)} className={`text-lg leading-none ${n <= (Number(value) || 0) ? 'text-amber-400' : 'text-zinc-200 hover:text-amber-200'}`}>
                            ★
                        </button>
                    ))}
                </span>
            );
        case 'singleSelect':
            return <SelectEditor field={field} value={value ? [String(value)] : []} onCommit={(v) => onCommit(v[0] ?? null)} single />;
        case 'multiSelect':
            return <SelectEditor field={field} value={Array.isArray(value) ? value : value ? [String(value)] : []} onCommit={(v) => onCommit(v)} />;
        case 'link':
            return <LinkEditor field={field} system={system} value={Array.isArray(value) ? value : []} onCommit={(v) => onCommit(v)} />;
        case 'longText':
            return <textarea ref={ref} className="ab-input min-h-24" value={draft} onChange={(e) => setDraft(e.target.value)} onBlur={commit} onKeyDown={(e) => e.key === 'Escape' && onCancel?.()} />;
        case 'date':
            return <input ref={ref} type="date" className="ab-input !py-1" value={draft} onChange={(e) => { setDraft(e.target.value); onCommit(e.target.value); }} onKeyDown={keys} />;
        default:
            return (
                <input
                    ref={ref}
                    type={['number', 'currency', 'percent'].includes(field.type) ? 'number' : field.type === 'email' ? 'email' : 'text'}
                    className="ab-input !py-1"
                    value={draft}
                    onChange={(e) => setDraft(e.target.value)}
                    onBlur={commit}
                    onKeyDown={keys}
                />
            );
    }
}

function SelectEditor({ field, value, onCommit, single }: { field: Field; value: string[]; onCommit: (v: string[]) => void; single?: boolean }) {
    const [q, setQ] = useState('');
    const choices = field.choices ?? [];
    const filtered = choices.filter((c) => c.name.toLowerCase().includes(q.toLowerCase()));
    const toggle = (name: string) => {
        if (single) return onCommit(value[0] === name ? [] : [name]);
        onCommit(value.includes(name) ? value.filter((x) => x !== name) : [...value, name]);
    };
    return (
        <div className="w-full min-w-44">
            <input autoFocus className="ab-input mb-1 !py-1 text-xs" placeholder="검색하거나 새 옵션 입력" value={q} onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => {
                if (e.key === 'Enter' && q.trim() && !e.nativeEvent.isComposing) {
                    toggle(filtered[0]?.name ?? q.trim());
                    setQ('');
                }
            }} />
            <div className="ab-scroll max-h-52 overflow-y-auto">
                {filtered.map((c) => (
                    <button key={c.name} onClick={() => toggle(c.name)} className="flex w-full items-center gap-2 rounded-md px-1.5 py-1 hover:bg-mutedbg">
                        <span className={`flex h-3.5 w-3.5 items-center justify-center rounded ${value.includes(c.name) ? 'bg-ink text-white' : 'border border-line-strong'}`}>{value.includes(c.name) && <Check size={10} strokeWidth={3} />}</span>
                        <Chip color={c.color}>{c.name}</Chip>
                    </button>
                ))}
                {q.trim() && !choices.some((c) => c.name === q.trim()) && (
                    <button onClick={() => { toggle(q.trim()); setQ(''); }} className="flex w-full items-center gap-1.5 rounded-md px-1.5 py-1 text-xs text-muted hover:bg-mutedbg">
                        <Plus size={12} /> &apos;{q.trim()}&apos; 추가
                    </button>
                )}
            </div>
        </div>
    );
}

function LinkEditor({ field, system, value, onCommit }: { field: Field; system: System; value: string[]; onCommit: (v: string[]) => void }) {
    const [q, setQ] = useState('');
    const lt = system.tables.find((t) => t.id === field.linkTableId);
    if (!lt) return <span className="text-xs text-faint">연결된 테이블이 없어요</span>;
    const list = lt.records.filter((r) => recordTitle(lt, r).toLowerCase().includes(q.toLowerCase())).slice(0, 50);
    return (
        <div className="w-full min-w-52">
            <input autoFocus className="ab-input mb-1 !py-1 text-xs" placeholder={`${lt.name} 검색`} value={q} onChange={(e) => setQ(e.target.value)} />
            <div className="ab-scroll max-h-52 overflow-y-auto">
                {list.map((r) => (
                    <button key={r.id} onClick={() => onCommit(value.includes(r.id) ? value.filter((x) => x !== r.id) : [...value, r.id])} className="flex w-full items-center gap-2 rounded-md px-1.5 py-1 text-left text-sm hover:bg-mutedbg">
                        <span className={`flex h-3.5 w-3.5 items-center justify-center rounded ${value.includes(r.id) ? 'bg-ink text-white' : 'border border-line-strong'}`}>{value.includes(r.id) && <Check size={10} strokeWidth={3} />}</span>
                        <span className="truncate">{recordTitle(lt, r)}</span>
                    </button>
                ))}
            </div>
        </div>
    );
}

/** Full record editor (expand row / click card). */
export function RecordModal({ system, table, record, onClose, onSet, onDelete }: { system: System; table: Table; record: RecordRow | null; onClose: () => void; onSet: (fieldId: string, v: CellValue) => void; onDelete: () => void }) {
    const [editing, setEditing] = useState<string | null>(null);
    useEffect(() => setEditing(null), [record?.id]);
    if (!record) return null;
    return (
        <Modal open onClose={onClose} title={<span className="flex items-center gap-2"><span>{table.icon}</span>{recordTitle(table, record)}</span>} width="max-w-2xl">
            <div className="ab-scroll max-h-[70vh] space-y-1 overflow-y-auto p-5">
                {table.fields.map((f) => (
                    <div key={f.id} className="grid grid-cols-[150px_1fr] items-start gap-3 rounded-lg px-1 py-1.5 hover:bg-soft">
                        <div className="flex items-center gap-1.5 pt-1 text-sm text-muted">
                            {FIELD_ICON[f.type]} <span className="truncate">{f.name}</span>
                        </div>
                        <div className="min-h-8 text-sm">
                            {editing === f.id || ['checkbox', 'rating'].includes(f.type) ? (
                                <div className={['singleSelect', 'multiSelect', 'link'].includes(f.type) ? 'rounded-lg border border-line p-1.5 shadow-sm' : ''}>
                                    <CellEditor
                                        field={f}
                                        value={record.cells[f.id]}
                                        system={system}
                                        onCommit={(v) => {
                                            onSet(f.id, v);
                                            if (!['multiSelect', 'link'].includes(f.type)) setEditing(null);
                                        }}
                                        onCancel={() => setEditing(null)}
                                    />
                                    {['multiSelect', 'link', 'singleSelect'].includes(f.type) && (
                                        <button className="mt-1 text-xs text-muted hover:text-ink" onClick={() => setEditing(null)}>
                                            완료
                                        </button>
                                    )}
                                </div>
                            ) : (
                                <button onClick={() => setEditing(f.id)} className="flex min-h-8 w-full items-center rounded-lg border border-transparent px-2 text-left hover:border-line">
                                    <CellDisplay field={f} value={record.cells[f.id]} system={system} />
                                    {['singleSelect', 'multiSelect', 'link'].includes(f.type) && <ChevronDown size={13} className="ml-auto text-faint" />}
                                </button>
                            )}
                        </div>
                    </div>
                ))}
                <LinkedFrom system={system} table={table} record={record} />
            </div>
            <div className="flex items-center justify-between border-t border-line px-5 py-3 text-xs text-faint">
                <span>생성 {new Date(record.createdAt).toLocaleString('ko-KR')}</span>
                <button onClick={onDelete} className="ab-btn !text-rose-600 hover:!bg-rose-50">
                    <Trash2 size={14} /> 레코드 삭제
                </button>
            </div>
        </Modal>
    );
}

/** Reverse links: records in other tables that point at this one. */
function LinkedFrom({ system, table, record }: { system: System; table: Table; record: RecordRow }) {
    const groups = system.tables
        .flatMap((t) => t.fields.filter((f) => f.type === 'link' && f.linkTableId === table.id).map((f) => ({ t, f })))
        .map(({ t, f }) => ({ t, f, rows: t.records.filter((r) => Array.isArray(r.cells[f.id]) && (r.cells[f.id] as string[]).includes(record.id)) }))
        .filter((g) => g.rows.length);
    if (!groups.length) return null;
    return (
        <div className="mt-4 border-t border-line pt-4">
            {groups.map(({ t, f, rows }) => (
                <div key={`${t.id}-${f.id}`} className="mb-3">
                    <div className="mb-1.5 text-xs font-medium text-muted">
                        {t.icon} {t.name} · {rows.length}건
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                        {rows.slice(0, 20).map((r) => (
                            <span key={r.id} className="rounded-lg border border-line bg-soft px-2 py-1 text-xs">
                                {recordTitle(t, r)}
                            </span>
                        ))}
                    </div>
                </div>
            ))}
        </div>
    );
}
