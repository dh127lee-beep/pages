'use client';

import { ArrowUp, Check, ChevronDown, FileSpreadsheet, Loader2, Paperclip, PanelRightClose, RotateCcw, Sparkles, Square, X } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';
import type { ChatMessage } from '@/lib/types';
import { Logo, Markdown } from './ui';

export interface LiveRun {
    status: string;
    says: string[];
    actions: string[];
    userText: string;
}

const QUICK = [
    { icon: '📊', text: '대시보드에 핵심 KPI와 추이 차트를 추가해줘' },
    { icon: '🔍', text: '데이터에서 주의가 필요한 항목을 찾아 요약해줘' },
    { icon: '⚡', text: '매주 월요일 아침 요약 리포트를 이메일로 보내는 워크플로 만들어줘' },
    { icon: '🧩', text: '새 필드를 추가하고 기존 레코드에 값을 채워줘' },
];

export function ChatPanel({
    messages,
    live,
    suggestions,
    onSend,
    onStop,
    onClear,
    onClose,
    model,
}: {
    messages: ChatMessage[];
    live: LiveRun | null;
    suggestions: string[];
    onSend: (text: string, files: File[]) => void;
    onStop: () => void;
    onClear: () => void;
    onClose: () => void;
    model?: string;
}) {
    const [text, setText] = useState('');
    const [files, setFiles] = useState<File[]>([]);
    const endRef = useRef<HTMLDivElement>(null);
    const taRef = useRef<HTMLTextAreaElement>(null);
    const fileRef = useRef<HTMLInputElement>(null);

    useEffect(() => {
        endRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' });
    }, [messages.length, live?.actions.length, live?.says.length, live?.status]);

    useEffect(() => {
        const ta = taRef.current;
        if (!ta) return;
        ta.style.height = 'auto';
        ta.style.height = `${Math.min(ta.scrollHeight, 160)}px`;
    }, [text]);

    const send = (t = text) => {
        if ((!t.trim() && !files.length) || live) return;
        onSend(t.trim() || '첨부한 파일을 새 테이블로 가져와줘. 필드 이름과 유형을 알맞게 정리해줘.', files);
        setText('');
        setFiles([]);
    };

    return (
        <aside className="flex h-full w-full flex-col bg-white">
            <div className="flex h-12 shrink-0 items-center gap-2 border-b border-line px-4">
                <Sparkles size={16} className="text-accent" />
                <span className="text-sm font-semibold">AI 에이전트</span>
                {model && <span className="rounded-full bg-mutedbg px-2 py-0.5 text-[11px] text-muted">Claude {model}</span>}
                <div className="ml-auto flex items-center gap-0.5">
                    <button onClick={onClear} className="rounded-md p-1.5 text-faint hover:bg-mutedbg hover:text-ink" title="대화 지우기">
                        <RotateCcw size={14} />
                    </button>
                    <button onClick={onClose} className="rounded-md p-1.5 text-faint hover:bg-mutedbg hover:text-ink" title="패널 닫기">
                        <PanelRightClose size={15} />
                    </button>
                </div>
            </div>

            <div className="ab-scroll min-h-0 flex-1 space-y-5 overflow-y-auto px-4 py-4">
                {messages.length === 0 && !live && (
                    <div className="pt-6">
                        <div className="mb-1 text-[15px] font-semibold">무엇을 도와드릴까요?</div>
                        <p className="mb-4 text-sm text-muted">시스템을 만들고, 고치고, 데이터에 대해 묻고, 자동화를 설정할 수 있어요.</p>
                        <div className="space-y-2">
                            {QUICK.map((q) => (
                                <button key={q.text} onClick={() => send(q.text)} className="flex w-full items-start gap-2 rounded-xl border border-line px-3 py-2.5 text-left text-sm text-ink-2 transition hover:border-line-strong hover:bg-soft">
                                    <span>{q.icon}</span>
                                    {q.text}
                                </button>
                            ))}
                        </div>
                    </div>
                )}
                {messages.map((m) => (m.role === 'user' ? <UserBubble key={m.id} text={m.content} /> : <AssistantMessage key={m.id} message={m} />))}
                {live && (
                    <>
                        {live.userText && !messages.some((m) => m.role === 'user' && m.content.startsWith(live.userText)) && <UserBubble text={live.userText} />}
                        <div className="flex gap-2.5">
                            <div className="shrink-0 pt-0.5"><Logo size={24} /></div>
                            <div className="min-w-0 flex-1 space-y-2 text-sm">
                                {live.says.map((s, i) => <Markdown key={i} text={s} />)}
                                <div className="rounded-xl border border-line bg-soft p-3">
                                    <div className="flex items-center gap-2 text-[13px] font-medium">
                                        <Loader2 size={14} className="animate-spin text-accent" />
                                        <span className="truncate">{live.status}</span>
                                    </div>
                                    {live.actions.length > 0 && (
                                        <div className="mt-2 space-y-1.5 border-t border-line pt-2">
                                            {live.actions.map((a, i) => (
                                                <div key={i} className="ab-pop flex items-start gap-2 text-xs text-ink-2">
                                                    <span className="mt-0.5 flex h-3.5 w-3.5 shrink-0 items-center justify-center rounded-full bg-emerald-500 text-white"><Check size={9} strokeWidth={3} /></span>
                                                    {a}
                                                </div>
                                            ))}
                                        </div>
                                    )}
                                </div>
                            </div>
                        </div>
                    </>
                )}
                {!live && suggestions.length > 0 && (
                    <div className="space-y-1.5 pl-[34px]">
                        {suggestions.map((s) => (
                            <button key={s} onClick={() => send(s)} className="block w-full rounded-lg border border-line bg-white px-3 py-2 text-left text-xs text-ink-2 transition hover:border-indigo-200 hover:bg-indigo-50/50">
                                {s} <span className="text-faint">→</span>
                            </button>
                        ))}
                    </div>
                )}
                <div ref={endRef} />
            </div>

            <div className="shrink-0 p-3">
                <div className="rounded-2xl border border-line bg-white p-2 shadow-[0_2px_12px_-4px_rgba(0,0,0,0.08)] focus-within:border-ink/30">
                    {files.length > 0 && (
                        <div className="mb-1.5 flex flex-wrap gap-1.5 px-1">
                            {files.map((f, i) => (
                                <span key={i} className="flex items-center gap-1 rounded-md bg-soft px-1.5 py-0.5 text-xs">
                                    <FileSpreadsheet size={12} className="text-emerald-600" /> {f.name}
                                    <button onClick={() => setFiles(files.filter((_, j) => j !== i))}><X size={11} /></button>
                                </span>
                            ))}
                        </div>
                    )}
                    <textarea
                        ref={taRef}
                        rows={1}
                        value={text}
                        onChange={(e) => setText(e.target.value)}
                        onKeyDown={(e) => {
                            if (e.key === 'Enter' && !e.shiftKey && !e.nativeEvent.isComposing) {
                                e.preventDefault();
                                send();
                            }
                        }}
                        placeholder={live ? '에이전트가 작업 중이에요…' : '수정 요청, 데이터 질문, 자동화…'}
                        className="block w-full resize-none bg-transparent px-1.5 py-1 text-sm outline-none placeholder:text-faint"
                    />
                    <div className="mt-1 flex items-center justify-between">
                        <input ref={fileRef} type="file" multiple accept=".csv,.xlsx,.xls" className="hidden" onChange={(e) => { setFiles([...files, ...Array.from(e.target.files ?? [])]); e.target.value = ''; }} />
                        <button onClick={() => fileRef.current?.click()} className="rounded-md p-1.5 text-faint hover:bg-mutedbg hover:text-ink" title="CSV · Excel 첨부">
                            <Paperclip size={15} />
                        </button>
                        {live ? (
                            <button onClick={onStop} className="flex h-7 w-7 items-center justify-center rounded-full bg-ink text-white" title="중지">
                                <Square size={11} fill="white" />
                            </button>
                        ) : (
                            <button onClick={() => send()} disabled={!text.trim() && !files.length} className="flex h-7 w-7 items-center justify-center rounded-full bg-ink text-white disabled:bg-zinc-200 disabled:text-zinc-400">
                                <ArrowUp size={15} />
                            </button>
                        )}
                    </div>
                </div>
            </div>
        </aside>
    );
}

function UserBubble({ text }: { text: string }) {
    return (
        <div className="flex justify-end">
            <div className="max-w-[85%] whitespace-pre-wrap rounded-2xl rounded-tr-md bg-mutedbg px-3.5 py-2 text-sm">{text}</div>
        </div>
    );
}

function AssistantMessage({ message }: { message: ChatMessage }) {
    const [open, setOpen] = useState(false);
    const actions = message.actions ?? [];
    return (
        <div className="flex gap-2.5">
            <div className="shrink-0 pt-0.5"><Logo size={24} /></div>
            <div className="min-w-0 flex-1 text-sm leading-relaxed">
                <Markdown text={message.content} />
                {actions.length > 0 && (
                    <div className="mt-2 rounded-xl border border-line">
                        <button onClick={() => setOpen(!open)} className="flex w-full items-center gap-2 px-3 py-2 text-xs text-ink-2">
                            <span className="flex h-4 w-4 items-center justify-center rounded-full bg-emerald-500 text-white"><Check size={10} strokeWidth={3} /></span>
                            작업 {actions.length}개 완료
                            <ChevronDown size={13} className={`ml-auto text-faint transition ${open ? 'rotate-180' : ''}`} />
                        </button>
                        {open && (
                            <div className="space-y-1 border-t border-line px-3 py-2">
                                {actions.map((a, i) => <div key={i} className="text-xs text-muted">• {a}</div>)}
                            </div>
                        )}
                    </div>
                )}
            </div>
        </div>
    );
}
