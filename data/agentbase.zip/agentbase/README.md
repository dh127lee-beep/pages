# AgentBase (로컬 구현)

GenSpark **AgentBase** 컨셉을 구현한 AI 업무 시스템 빌더입니다.
만들고 싶은 시스템을 말로 설명하거나 CSV·Excel 파일을 올리면, AI 에이전트가 **테이블 → 뷰·대시보드 → 워크플로**를 만들어 주고, 이후 대화로 계속 고쳐 나갑니다.

`onlook`(에디터 구조·채팅 패널 패턴)과 `table-pocker`(AI는 구성만 정하고 숫자는 데이터로 직접 계산)의 방식을 참고했습니다.

## 실행

```bash
cd agentbase
npm install
npm run build && npm start      # http://localhost:3100
# 개발 모드: npm run dev
```

AI는 OpenAI 호환 엔드포인트를 씁니다. 기본값은 로컬 Claude CLI API입니다.

| 환경 변수 | 기본값 |
|---|---|
| `AGENTBASE_AI_BASE_URL` | `http://127.0.0.1:8899/v1` |
| `AGENTBASE_AI_API_KEY` | `dummy` |
| `AGENTBASE_AI_MODEL` | `sonnet` |
| `AGENTBASE_DATA_DIR` | `./data/systems` |

## 기능

| 영역 | 내용 |
|---|---|
| 홈 | 프롬프트 입력, 파일 업로드(CSV·XLSX), 데이터 연결 메뉴, 예시 프롬프트, 내 시스템, 템플릿 센터(카테고리 탭 6개, 템플릿 8종) |
| 워크스페이스 | 왼쪽 사이드바(대시보드 / 테이블 / 워크플로), 가운데 작업 영역, 오른쪽 AI 에이전트 패널 |
| 테이블 | 필드 유형 15가지(선택, 연결, 통화, 평점, 담당자 등), 관계형 연결과 역참조 표시, 인라인 편집, 레코드 상세, 필터·정렬·검색·필드 숨기기, CSV 내보내기 |
| 뷰 | 그리드 · 칸반(드래그 앤 드롭) · 갤러리 · 캘린더(드래그로 날짜 변경) · 양식(공유 링크 `/f/<id>/<viewId>`) |
| 대시보드 | KPI · 막대 · 가로 막대 · 라인 · 도넛 · 목록 위젯. **차트를 클릭하면 교차 필터**가 걸리고, "테이블에서 보기"로 해당 레코드를 엽니다. 숫자는 항상 테이블 데이터로 실시간 계산 |
| 워크플로 | 예약 트리거(매시간/매일/매주/매월 + 다음 실행 시각), 단계: 레코드 찾기 → 레코드 수정 → AI 보고서 → 이메일(메일함이 없어 초안으로 저장). **테스트** 실행(시뮬레이션), 지금 실행, On/Off, 실행 기록. 서버가 30초마다 예약을 확인해 자동 실행 |
| AI 에이전트 | 시스템 생성·수정, 데이터 질문(근거 수치 포함), 파일 가져오기(필드 매핑), 자동화 설정. 작업이 **스트리밍으로 하나씩 적용**되어 화면에 바로 나타나고, 끝나면 다음에 할 일 제안 칩을 보여줍니다 |
| 공유 | 범위(워크스페이스 / 대시보드 / 테이블)와 역할(뷰어 / 편집자 / 소유자) 초대 목록 |

## 구조

```
src/lib/ops.ts        에이전트 작업(이름 기반: create_table, add_widgets, create_workflow …) → 시스템에 적용
src/lib/agent.ts      프롬프트와 시스템 상태 요약 → LLM이 JSON Lines로 작업 스트리밍 → 하나씩 적용, NDJSON 이벤트 전송
src/lib/mutate.ts     UI의 직접 편집(id 기반). 클라이언트에서 낙관적 업데이트에도 같은 코드 사용
src/lib/data.ts       필터, 정렬, 위젯 집계, 일정 계산 (서버·클라이언트 공용)
src/lib/workflow.ts   워크플로 실행과 스케줄러 (instrumentation.ts에서 시작)
src/lib/templates.ts  템플릿 = 에이전트와 같은 형식의 작업 목록 (상대 날짜 "+3d" 사용으로 데이터가 항상 최신)
src/components/       home, workspace, table-view(5개 뷰), dashboard-view, charts(SVG), workflow-view, chat-panel
data/systems/*.json   시스템 하나 = 파일 하나 (쓰기는 시스템별로 순서대로 처리)
```

## 로컬 버전의 제약

- Gmail · Outlook · HubSpot · Salesforce · DB 연결은 인증이 필요해 지원하지 않습니다. 내보낸 CSV·Excel 파일을 올리면 됩니다.
- 이메일 단계는 실제로 보내지 않고 실행 기록에 초안으로 저장합니다.
- 인증 기능이 없습니다. 외부에 공개할 때는 앞단에 인증을 두세요. 공유 초대는 목록만 기록합니다.
