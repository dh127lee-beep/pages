# Browser Bridge

AI 에이전트가 사용자의 실제 Chrome/Edge 브라우저를 **세션 단위로 안전하게**
조작하도록 해주는 Chrome MV3 확장과 그 주변 도구 모음이다. 확장이 1차 런타임이며
agent 연결, 세션, 세션별 탭 그룹, 탭 lease, 권한, audit을 소유한다.

설계 기준은 [spec/](spec/README.md), 구현 단계별 계획·현황은 [task/](task/),
외부 레퍼런스 정리는 [reference/guide.md](reference/guide.md)를 본다.

## 패키지 구성

```text
packages/
  shared-protocol/   프로토콜 타입·스키마·RPC·프레이밍 (의존성 없는 코어)
  extension/         Chrome MV3 확장 (service worker, content script, popup/options)
  agent-adapter/     dev WebSocket 엔드포인트 + 최소 MCP 서버
  native-host/       Native Messaging 호스트 (프로덕션 전송)
  artifact-store/    아티팩트 저장 인터페이스
```

## 빠른 시작 (MVP 개발)

```bash
corepack enable && corepack prepare pnpm@9.15.0 --activate   # 최초 1회
pnpm install
pnpm typecheck   # tsc -b
pnpm test        # vitest
pnpm build       # 전 패키지 빌드 + 확장 번들(packages/extension/dist)
pnpm lint
```

### 확장 로드

1. `pnpm build`
2. `chrome://extensions` → 개발자 모드 ON → "압축해제된 확장 프로그램 로드"
3. `packages/extension/dist` 선택

자세히는 [docs/install-extension.md](docs/install-extension.md).

### 에이전트 연결 (개발: WebSocket)

확장은 기본적으로 **자동 연결**된다(토큰/동의 없음 — [연결 정책](spec/02-security-permissions.md)).
프로덕션은 Native Messaging을 우선 사용하고, 없으면 dev WebSocket(`127.0.0.1:18470`)으로
폴백한다.

- **터미널 없이(권장)**: Native Messaging. Chrome이 호스트를 자동 실행하고, 호스트가
  외부 에이전트용 릴레이(`127.0.0.1:18480`)도 연다. 확장만 설치돼 있으면 외부 프로그램을
  아무 때나 실행해 접속 → [docs/install-native-host.md](docs/install-native-host.md).
- **자동 연결 (Codex `@chrome` 같은 UX)**: 에이전트 앱이 엔드포인트를 띄워두면, 확장이
  Chrome 시작/주기적으로 자동 재접속 → 사용자는 확장 1회 설치 외 아무것도 안 함.
  → [docs/auto-connect.md](docs/auto-connect.md).
- **매니페스트 없이(가장 단순)**: 내 프로그램이 곧 서버. `@browser-bridge/agent-adapter`의
  `DevWsServer`를 임베드해 `127.0.0.1:18470`에 띄우면 확장이 자동 접속. 매니페스트 설치 불필요.
  → [docs/connect-without-host.md](docs/connect-without-host.md), 예제 [examples/agent.mjs](examples/agent.mjs).
- **개발용 데모 WS**: `pnpm adapter` 또는 `pnpm demo` (어댑터가 `127.0.0.1:18470` 서버).

### 수동 확인 (탭 그룹·동작 데모)

```bash
pnpm demo       # 데모 어댑터 실행 → 확장 로드 시 세션/탭그룹/액션 자동 시연
```

Chrome에 `BB · demo-agent · …` 탭 그룹이 생기고 snapshot/screenshot/navigate가
실행되는 것을 확인한다. 자세히는 [docs/manual-verification.md](docs/manual-verification.md).

## 핵심 개념

- **세션**: 작업 단위. 한 에이전트가 여러 세션, 여러 에이전트가 동시 세션 소유.
- **탭 그룹**: 세션마다 하나의 Chrome tab group으로 사용자에게 드러남.
- **observe → act → verify**: 모든 조작은 snapshot에서 발급된 element uid를 대상으로.
- **권한 경계**: 쿠키/세션 토큰 추출 없음, 민감 값 redaction, 모든 액션 audit.

## 문서

- **설치**: [확장](docs/install-extension.md) · [Native Host](docs/install-native-host.md)
- **연결**: [자동 연결(Codex식)](docs/auto-connect.md) · [매니페스트 없이](docs/connect-without-host.md) · [멀티 윈도우·멀티 어댑터·가변 포트](docs/windows-and-ports.md)
- **수동 확인**: [manual-verification](docs/manual-verification.md) (탭 그룹·동작 데모)
- **통신 규약**: [protocol](docs/protocol.md) (envelope·핸드셰이크·도구·에러)
- **에이전트 활용**: [agent-usage](docs/agent-usage.md) (루프·claim/finalize·codex/devtools 매핑)
- **샘플 에이전트**: [agent/](agent/) (LangGraph + Claude, Python) · [examples/agent.mjs](examples/agent.mjs) (no-LLM, Node)
- **운영/보안**: [트러블슈팅](docs/troubleshooting.md) · [알려진 한계](docs/known-limitations.md) · [프라이버시](docs/privacy.md) · [위협 모델](docs/threat-model.md)
- **설계/구현**: [스펙](spec/README.md) · [구현 task](task/) · [레퍼런스 가이드](reference/guide.md)

## 상태

Phase 0~10 구현 완료(자동 게이트 통과). 브라우저/네이티브 호스트 수동 확인은
각 `task/0X-*.md`의 "수동 확인" 항목 참고.
