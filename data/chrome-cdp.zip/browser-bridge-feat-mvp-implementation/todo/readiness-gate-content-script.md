# TODO: Readiness gate via content-script bridge (ID-free)

> 상태: **설계(미구현)**. 목적: 확장이 죽은 서버를 블라인드로 찌르며 내는 Chrome 연결 에러를
> 없앤다 — **앱(소켓 호스트)이 떠 있다는 신호를 받은 뒤에만 연결**한다. 신호 채널로
> **content script 브리지**를 써서 **확장 ID 고정·`externally_connectable`이 필요 없게** 한다.
> 배경/대안 비교: [todo/ws-readiness-signaling.md](ws-readiness-signaling.md).
> 적용 대상: Electron 단독 앱([../agent-electron](../agent-electron)) 또는 dev 어댑터 — 둘 다 localhost 페어링 페이지를 서빙.

## 1. 목표 / 원칙
- 서버 down 시 **연결 시도 자체를 안 함** → Chrome 빨간 에러 0.
- 서버 up이면 자동 연결(수동 조작 최소).
- 전송(WS/HTTP) **무관**. 게이트는 전송과 직교.
- **확장 ID 의존 제거**(고정·핀닝 단계 불필요).

## 2. 왜 content script 브리지인가 (ID 불필요)
신호를 보낼 채널 후보와 ID 요구:

| 채널 | extension ID 필요? | 이유 |
| --- | --- | --- |
| `externally_connectable`(페이지→확장 직접) | **필요** | 웹페이지가 `chrome.runtime.sendMessage(extId, …)`에 대상 ID를 반드시 지정 |
| Native Messaging | **필요** | 호스트 매니페스트 `allowed_origins`에 `chrome-extension://<id>/` |
| **content script 브리지** | **불필요** | content script ↔ SW는 **확장 내부 메시징**(`chrome.runtime.sendMessage(message)`, 대상 지정 X) |

→ content script를 localhost 페어링 페이지에 주입해 다리로 쓰면 ID가 전혀 필요 없다.

## 3. 구조

```text
앱(Electron/adapter)이 서빙하는 localhost 페어링 페이지  (사용자 Chrome 탭)
   │  window.postMessage({ source:"bb-pair", ready, port, token })  +  heartbeat
   ▼
content script  (확장 주입; matches http://127.0.0.1:*/* 등)
   │  chrome.runtime.sendMessage({ type:"bb-ready"|"bb-gone", port, token })   ← ID 불필요(내부)
   ▼
service worker  (readiness 게이트)
   │  검증 → chrome.storage.session 저장 → 그 port로만 transport start / stop
   ▼
WS(또는 HTTP) 연결  — 신호 있을 때만 시도 → 실패 핸드셰이크 0
```

- content script ↔ 페이지: `window.postMessage`(또는 CustomEvent). 페이지는 확장 ID를 몰라도 됨.
- content script ↔ SW: 확장 내부 `chrome.runtime.sendMessage` / `onMessage`. ID 없음.
- SW ↔ 익스텐션 백엔드: 기존 트랜스포트(WS 18470 등)를 **게이트로** 켜고 끔.

## 4. 페어링 페이지 ↔ content script 계약
페이지가 보내는 메시지(예):
```js
// 페어링 페이지 (앱이 서빙). 로드 시 + 주기적으로:
window.postMessage({ source: "bb-pair", v: 1, ready: true, port: 18470, token: "<발급 토큰>" }, "*");
window.addEventListener("pagehide", () =>
  window.postMessage({ source: "bb-pair", v: 1, ready: false }, "*"));
```
content script:
```js
window.addEventListener("message", (e) => {
  const d = e.data;
  if (e.source !== window || !d || d.source !== "bb-pair") return;   // 자기 윈도우 + 태그 검증
  chrome.runtime.sendMessage({ type: d.ready ? "bb-ready" : "bb-gone", port: d.port, token: d.token });
});
```

## 5. SW 상태 머신 / 게이트
```
IDLE ──(bb-ready: 검증 통과)──▶ CONNECTING ──open──▶ CONNECTED
  ▲                                                  │
  └────────(bb-gone / 신호 TTL 만료 / detach)─────────┘
```
- `bb-ready`: 토큰·port 검증 → `chrome.storage.session`에 `{port, token, ts}` 저장 → **그 port로만** transport start.
- `bb-gone` 또는 신호 TTL(예: heartbeat 15s 미수신) 만료: transport `stop()` → IDLE. **재시도 안 함.**
- IDLE에선 **어떤 포트도 connect 안 함** → 에러 0.
- 기존 `bb-connect` 알람: "신선한 ready 신호가 있을 때만" 점검(없으면 no-op).

## 6. 재연결 규칙
- CONNECTED 중 소켓이 끊겼는데 ready 신호가 **신선**하면(페이지 열려 있음) 빠르게 재시도(앱 재시작 중).
- ready 신호가 없거나 만료면 재시도 안 함.

## 7. 보안
- content script `matches`를 **localhost로 한정**(`http://127.0.0.1:*/*`, `http://localhost:*/*`).
- 페이지 메시지는 `e.source === window` + `source:"bb-pair"` 태그 검증.
- **공유 토큰**: 앱이 생성 → 페어링 페이지가 전달 → SW가 대조(임의 localhost 페이지의 위조/하이재킹 방지).
- 수신 `port`는 허용 범위(18470–18479) 내로 제한.
- 페이지 콘텐츠는 untrusted — 신호 메시지 외에는 신뢰하지 않음([../docs/threat-model.md](../docs/threat-model.md)).

## 8. 트레이드오프
- **페어링 탭이 (최소 연결 시점에) 열려 있어야** 함 — content script는 그 탭에서만 동작.
  완화: 앱이 기동 시 사용자 Chrome에 페어링 탭을 자동으로 열거나, 콘솔/상태 페이지를 페어링 페이지로 겸용.
- localhost 페이지에 content script가 도는 표면이 생김 → matches를 좁히고 토큰으로 제한.
- 탭조차 없이 가려면 → Native Messaging(Chrome이 호스트 실행, 신호 불필요. 단 OS 설치).

## 9. 구현 체크리스트
- [ ] **manifest.json**: `content_scripts`(matches localhost, js: 브리지) 추가. (`externally_connectable`/`key` 불필요)
- [ ] **bridge content script**: 페이지 postMessage ↔ `chrome.runtime.sendMessage`(`bb-ready`/`bb-gone`).
- [ ] **service worker**: `chrome.runtime.onMessage`에서 `bb-ready`/`bb-gone` 처리 → 토큰/port 검증 →
      `chrome.storage.session` 상태 → transport start/stop. 블라인드 스캔 제거(신호 게이트로 대체),
      `bb-connect` 알람은 신호 신선도만 점검.
- [ ] **앱(페어링 페이지)**: localhost 페이지가 토큰을 받아 `ready`/`gone`/heartbeat postMessage.
      (Electron 앱은 토큰을 생성해 페이지에 주입; 어댑터는 콘솔 페이지에 스니펫 삽입.)
- [ ] **transport.ts/service-worker.ts**: 신호 없으면 connect 금지.

## 10. 수용 기준
- 앱 down + 페어링 탭 없음 → SW 콘솔 WS/fetch 연결 에러 **0건**.
- 페어링 탭 로드 → 즉시 연결(실패 핸드셰이크 없이).
- 앱 종료/탭 닫힘 → 깔끔히 끊기고, 재오픈/재기동 시 재연결.
- **확장 ID를 코드/매니페스트에 박지 않음**(핀닝 불필요).
- onMessage 게이트·storage 상태 전이 단위 테스트 추가.
