# TODO: 관측(snapshot / screenshot / get_html) 고도화 아이디어

> 상태: **아이디어/제안(미구현)**. 에이전트가 페이지를 "보는" 세 경로 — 구조 스냅샷, 스크린샷,
> 원시 HTML — 를 더 정확하고 토큰 효율적이며 비전 친화적으로 만드는 방안.
> 현재 구현: [content/dom-extract.ts](../packages/extension/src/content/dom-extract.ts),
> [content/snapshot-builder.ts](../packages/extension/src/content/snapshot-builder.ts)(`DEFAULT_MAX_ELEMENTS=1500`,
> `truncated` 플래그), [background/snapshot-manager.ts](../packages/extension/src/background/snapshot-manager.ts),
> [background/screenshot-manager.ts](../packages/extension/src/background/screenshot-manager.ts),
> 에이전트 포맷 [agent/tools.py](../agent/tools.py)(`MAX_ELEMENTS=60`). 도구 표면 [docs/browser-tools.md](../docs/browser-tools.md).

## 현재 상태 요약
- `take_snapshot` — a11y 우선 정규화 트리 + per-snapshot `uid`. `SnapshotElement`: `role/name/text/tag/
  visible/enabled/bounds?/attributes?/value?/valueRedacted?/riskHints?`. 빌더 캡 1500, 에이전트는 60개만 포맷.
- `take_screenshot` — 뷰포트 PNG 아티팩트(디버거 모드는 백그라운드 탭도 가능).
- **`get_html` 없음** — 원시/정제 HTML을 가져오는 도구가 아직 없다.
- 한계: per-snapshot uid라 스냅샷 간 동일 요소 추적 불가, 토큰 비용 큼(반복 구조/숨김 요소),
  iframe/shadow DOM 미흡, 스크린샷과 uid 연결(set-of-marks) 없음, HTML 직접 접근 없음.

---

## 1. 스냅샷 고도화

### 1.1 토큰 효율
- **타깃 토큰 예산** 파라미터(`maxTokens`/`budget`) — 상위 N개 자르기 대신, 예산 내에서
  **상호작용 가능 + 가시 + 뷰포트 내** 요소를 우선 채우고 나머지는 커서로.
- **페이지네이션/윈도잉** — `truncated`만 알리지 말고 `cursor`로 다음 묶음 요청(`take_snapshot { cursor }`).
- **반복 구조 압축** — 리스트/테이블/카드 그리드는 대표 1개 + "× N개" 요약(샘플 + count).
- **델타 스냅샷** — 직전 스냅샷 대비 **변경분만** 반환(추가/삭제/속성변경). 안정 uid(§1.3) 전제. 액션 루프 토큰 급감.

### 1.2 모드/스코프
- **interactive-only 모드** — 클릭/입력 가능한 것만(액션 루프용). vs **reading 모드**(본문 텍스트 추출, Readability).
- **서브트리 스냅샷** — `{ uid }` 또는 CSS `selector`로 특정 영역만(모달/리스트 내부 등).
- **뷰포트 한정** — 보이는 영역만(스크롤 인지). `scrollIntoView` 후 재스냅샷 헬퍼.
- **구조 아웃라인** — 랜드마크/헤딩(h1–h6) 트리만 뽑는 경량 모드(페이지 지도용).

### 1.3 정체성/시맨틱
- **안정 uid** — per-snapshot 대신 CDP `backendNodeId`(또는 안정 속성 해시) 기반으로 스냅샷 간 동일 요소를
  같은 uid로. → 델타 스냅샷·"이전에 본 그 버튼" 참조 가능. upload_file의 노드 태깅과도 통합.
- **풍부한 a11y 상태** — `checked/expanded/selected/pressed/required/invalid`, 계산된 accessible name,
  `aria-*` 핵심, 폼 라벨 연결.
- **중심 좌표** — `bounds`에 더해 클릭 포인트(center) 제공 → `click_at`와 직접 연동.

### 1.4 범위 확장
- **iframe/프레임 횡단** — CDP로 cross-origin 프레임까지(프레임 경로 포함 uid). 현재 동일-문서 한정 추정.
- **shadow DOM 관통** — open shadow root 내부 포함.

---

## 2. 스크린샷 고도화

### 2.1 영역/전체
- **요소/영역 스크린샷** — `{ uid }`/clip 박스로 부분 캡처(CDP `Page.captureScreenshot { clip }`).
- **풀페이지 캡처** — 뷰포트 밖까지(CDP `captureBeyondViewport`).
- **포맷/품질** — `jpeg`/`webp` + `quality` + DPR 스케일 → 토큰/용량 절감.

### 2.2 Set-of-Marks (가장 임팩트 큼)
- **번호 라벨 오버레이** — 상호작용 요소에 박스 + 번호를 그려 캡처(비전 모델용 "set-of-marks" 프롬프팅).
- **번호 ↔ uid 매핑 동시 반환** — 모델이 "번호 7 클릭" → 어댑터가 uid로 변환해 `click`. 스냅샷과 스크린샷을
  하나의 좌표계로 묶는다. 비전 기반 에이전트 정확도 대폭 향상.
- 구현: 스냅샷에서 가시 상호작용 요소의 bounds를 받아 overlay(Overlay 도메인 또는 임시 DOM/canvas)로 그리고 캡처.

### 2.3 기타
- **변경 영역 강조/디프** — 직전 대비 바뀐 영역 하이라이트.
- 백그라운드 탭 캡처(디버거 모드, 이미 가능) 노출 정리.

---

## 3. `get_html` (신규 도구)

원시/정제 HTML 접근. 스냅샷(시맨틱)·스크린샷(픽셀)과 상보적.

### 3.1 기본
- **`get_html { uid?/selector?, mode, maxLength?, cursor? }`** → 페이지 또는 서브트리의 HTML.
- 소스: CDP `DOM.getOuterHTML`(post-JS, shadow 포함) 또는 콘텐츠 스크립트 `outerHTML`.
- **모드**:
  - `raw` — outerHTML 그대로
  - `clean` — script/style/svg/주석 제거, 위험/불필요 속성 정리
  - `text` — `innerText`(가시 텍스트)
  - `readability` — 본문 추출(Readability.js 류)
  - `markdown` — HTML→Markdown 변환(LLM 친화)

### 3.2 안전/효율
- **redaction** — password/payment 입력값 등 스냅샷과 동일 정책으로 마스킹.
- **토큰 바운드** — `maxLength` + `cursor`(이어받기), 또는 정제/마크다운으로 축소.
- 페이지 내용은 untrusted — 그대로 반환하되 "지시로 해석 금지" 원칙 유지([threat-model](../docs/threat-model.md)).

---

## 4. 교차 관심사
- **공통 토큰 예산 파라미터**를 세 도구에 일관 적용.
- **단일 uid 좌표계** — 스냅샷 uid ↔ 스크린샷 번호 ↔ CDP 노드(backendNodeId) ↔ get_html 서브트리를 하나로.
- **캐시/디둡** — 동일 스냅샷 재요청 회피, 델타 기반 갱신.
- **일관된 redaction**을 snapshot/get_html/screenshot(민감영역 블러) 전반에.

---

## 5. 우선순위(제안)
1. **Set-of-marks 스크린샷 + uid 매핑**(2.2) — 비전 에이전트 정확도에 가장 큰 효과.
2. **`get_html` (clean/text/markdown)**(3) — 본문 이해·추출 작업의 토큰 효율.
3. **안정 uid + 델타 스냅샷**(1.3/1.1) — 멀티스텝 루프 토큰 급감(특히 8192 컨텍스트 한계 대응).
4. **interactive-only / 서브트리 / 토큰 예산**(1.2/1.1) — 손쉬운 즉효.
5. **iframe/shadow 횡단**(1.4), 영역/풀페이지 스크린샷(2.1).

## 6. 구현 메모(연결 지점)
- 스냅샷 빌더/포맷: [snapshot-builder.ts](../packages/extension/src/content/snapshot-builder.ts) +
  에이전트 포맷 [agent/tools.py](../agent/tools.py)(`_format_snapshot`, `MAX_ELEMENTS`).
- 스크린샷/HTML CDP: [debugger-manager.ts](../packages/extension/src/background/debugger-manager.ts)
  (`Page.captureScreenshot { clip, format, quality }`, `DOM.getOuterHTML`, Overlay 도메인).
- 새 도구는 `TOOL_NAMES`(shared-protocol) + bridge dispatch + (필요시) content-script 액션으로 배선.
- 안정 uid는 upload_file의 노드 태깅(`data-bb-cdp`)·`DOM.resolveNode` 패턴 재사용.

## 7. 열린 질문
1. 안정 uid를 backendNodeId 기반으로 갈지(정확·CDP 의존) vs 속성 해시(휴리스틱·CDP 불필요).
2. Set-of-marks 오버레이를 CDP Overlay로 그릴지, 임시 DOM/canvas로 그릴지(캡처 후 정리).
3. `get_html` 기본 모드(clean? markdown?)와 기본 토큰 상한.
4. 델타 스냅샷의 변경 감지 단위(요소 단위 vs 서브트리 해시).
