# TODO: 폴링 없는 WS 연결 (readiness 신호 기반)

> 상태: **설계(미구현)**. 목적: 현재 WebSocket 경로를 유지하면서, 확장이 포트 범위를
> **블라인드로 무한 재시도**하다 Chrome이 빨간 핸드셰이크 에러를 찍는 것을 없앤다.
> 관련: [docs/auto-connect.md](../docs/auto-connect.md), [docs/windows-and-ports.md](../docs/windows-and-ports.md),
> 재연결 구현 [packages/extension/src/bridge/transport.ts](../packages/extension/src/bridge/transport.ts),
> [packages/extension/src/service-worker.ts](../packages/extension/src/service-worker.ts).

## 1. 문제

- MV3 확장은 서버를 못 연다 → **확장이 밖으로** WS 연결을 개시해야 한다.
- 어댑터가 언제/어느 포트에 뜰지 모르니 18470–18479를 30초 주기로 계속 시도(`bb-connect` 알람 + 백오프).
- 어댑터 미실행 시 매 시도마다 **Chrome 네트워크 스택이 직접** `WebSocket connection to 'ws://…' failed`를
  콘솔에 찍는다. 이 로그는 **JS로 억제 불가**(try/catch·onerror·console 패칭 모두 무효).
- 시스템 부하는 미미하나(loopback refused = 즉시 RST), **서비스 워커 DevTools 콘솔 노이즈**가 남는다.
  (일반 사용자에겐 안 보임 — SW를 inspect할 때만 보인다.)

## 2. 왜 "파일/스토리지 공유 후 연결"은 안 되나

| 채널 | 확장이 백그라운드에서 읽기 | Node(어댑터)가 쓰기 | 결론 |
| --- | --- | --- | --- |
| 로컬 파일 (`~/.browser-bridge/ws-port`) | ❌ MV3 SW는 FS 접근 없음. File System Access API는 제스처+권한+문서 필요(SW 불가) | ✅ | **불가** — 확장이 못 읽음 |
| `chrome.storage` | ✅ (확장 전용) | ❌ 확장 전용 저장소, 외부 프로세스가 못 씀 | **불가** — 어댑터가 못 씀 |

→ 둘 다 **공유 채널이 아니다.** 확장이 백그라운드에서 읽을 수 있으면서 Node도 쓸 수 있는 교집합은
사실상 **네트워크 엔드포인트뿐**이고, 그게 지금 찔러보는 WS다. 그래서 파일/스토리지로는 해결 안 됨.

## 3. 채택안: `externally_connectable` readiness 신호

같은 로컬 가정에서, **localhost 페이지가 확장에 "나 떴다"를 push** → 확장이 `chrome.storage`에 저장 →
**그 포트로만 WS 연결**. 떠 있음을 확인한 뒤에만 연결하므로 실패 핸드셰이크(=빨간 에러)가 사라진다.

```text
어댑터(Node, 같은 로컬)
  ├─ WS 서버 (기존)                         127.0.0.1:18470
  └─ HTTP 상태 페이지 + /bb-ready 신호       (같은 포트에 HTTP 한 줄 추가)
         │  탭에서 페이지 로드 시
         ▼
  page.js: chrome.runtime.sendMessage("<extId>", { type:"bb-adapter-ready", port })
         │  (externally_connectable)
         ▼
  확장 SW: onMessageExternal → chrome.storage.session에 { ready:true, port } 저장
         → 그 포트로 WS connect (실패 핸드셰이크 없음)
         페이지 unload/heartbeat 끊김 → { ready:false } → WS stop
```

### 3.1 동작 흐름
1. 사용자가 어댑터의 localhost 페이지(예: 콘솔 `127.0.0.1:8500` 또는 어댑터 상태 페이지)를 연다.
2. 페이지 JS가 `chrome.runtime.sendMessage(<extId>, { type:"bb-adapter-ready", port, token? })`.
3. 확장 SW `chrome.runtime.onMessageExternal`이 sender origin(localhost)·메시지 검증 후
   `chrome.storage.session`에 `{ ready, port }` 저장하고 **해당 포트로만** `startTransports`/`kick`.
4. 페이지가 닫히면(`pagehide`) `{ type:"bb-adapter-gone" }` → 확장이 그 포트 트랜스포트 `stop()`.
5. 신호가 없으면 **확장은 배경에서 아무 포트도 찌르지 않는다** → 에러 0.

### 3.2 변경 지점 (구현 TODO)
- [ ] **manifest.json**: `"externally_connectable": { "matches": ["http://127.0.0.1:*/*", "http://localhost:*/*"] }` 추가.
- [ ] **어댑터**: WS 서버와 같은 포트에 최소 HTTP 응답(상태/페어링 스크립트) 추가
      ([ws-server.ts](../packages/agent-adapter/src/ws-server.ts)는 `ws`의 내장 http 서버를 가지므로 `upgrade`가
      아닌 요청에 200 + 작은 JS 반환). 또는 콘솔(agent-frontend)에 페어링 스니펫 삽입.
- [ ] **페어링 스니펫(page)**: 로드 시 `sendMessage(extId, ready)`, `pagehide` 시 `gone`,
      주기적 heartbeat(선택). `extId`는 고정 ID(아래 §5) 또는 설정.
- [ ] **service-worker.ts**: `chrome.runtime.onMessageExternal` 핸들러 →
      origin·token 검증 → `chrome.storage.session`에 ready 상태 저장 → ready 포트만 연결,
      gone이면 `stop()`. 기존 `bb-connect` 알람의 **블라인드 스캔은 비활성/긴 주기 fallback**으로 강등.
- [ ] **discovery.ts**: 스캔 기본 동작을 "signal-gated"로 변경(신호 없으면 connect 안 함).
- [ ] (선택) 배경 fallback: 신호를 한참 못 받으면 아주 긴 간격(예: 5분)으로 1회 probe.

### 3.3 트레이드오프
- **신호 페이지가 한 번은 열려 있어야** 한다(연결 시점). 콘솔 탭을 이 신호 페이지로 겸하면 자연스러움.
- 페이지를 닫으면 연결이 끊길 수 있음 → heartbeat/유예시간으로 완화하거나, "한 번 ready면 세션 동안 유지".
- 멀티 에이전트(여러 포트)면 각 어댑터 페이지가 자기 포트를 신호.

## 4. 보안 고려
- `externally_connectable` matches를 **localhost로만** 한정.
- `onMessageExternal`에서 `sender.url`/`sender.origin`이 `http://127.0.0.1`/`localhost`인지 검증.
- 메시지에 **공유 토큰**(설치 시 생성, 페이지와 확장이 합의)을 넣어 임의 localhost 페이지의 위조 방지.
- ready로 받은 포트만 연결(임의 포트 주입 금지: 허용 범위 18470–18479 내로 제한).
- 위협 모델 일반 원칙은 [docs/threat-model.md](../docs/threat-model.md).

## 5. 의존: 확장 ID 고정
페어링 스니펫이 `sendMessage(<extId>, …)`에 ID가 필요하므로 **ID 고정**이 사실상 전제.
- `manifest.json`에 `"key"`(공개키) 추가 → 경로/머신 무관 고정 ID.
- 생성: `chrome://extensions` → 확장 압축 → `.pem` → 공개키 base64를 `key`에 기입. 자세히는 별도 TODO.
- 또는 페이지가 ID를 모를 때: 확장이 먼저 페이지에 `window.postMessage`로 자기 ID를 알리는 핸드셰이크(콘텐츠 스크립트 경유)도 가능.

## 6. 대안 (참고)
- **네이티브 메시징**: Chrome이 호스트를 자동 실행 → outbound 폴링 자체가 없음(실패 0). 단 OS별 설치 등록 필요.
  [docs/install-native-host.md](../docs/install-native-host.md).
- **이벤트 트리거(팝업)**: 사용자가 팝업 열 때만 connect. 신호 페이지 불필요하나 자동성↓.
- **노이즈 최소화(현행 유지)**: 백오프 상한↑(30s→5분) + 스캔 포트수↓(10→1~2). 에러를 "거의 0"으로.
  코드 상수만 바꾸면 됨, 리스크 최소.

## 7. 결정 필요
1. 신호 페이지를 **콘솔(8500) 겸용**으로 할지, 어댑터(18470)에 별도 상태 페이지를 둘지.
2. 페이지 닫힘 시 정책: 즉시 끊기 vs 세션 동안 유지(유예시간).
3. 확장 ID 고정 방식(manifest `key` vs 런타임 핸드셰이크).
4. 블라인드 스캔 fallback을 남길지(완전 제거 vs 5분 1회).

## 8. 수용 기준
- 어댑터 미실행 + 신호 페이지 없음 → SW 콘솔에 WS 실패 에러 **0건**.
- 신호 수신 후 즉시 연결(실패 핸드셰이크 없이).
- 어댑터 종료/페이지 닫힘 → 깔끔히 끊기고, 재기동/재오픈 시 재연결.
- 기존 테스트 통과 + onMessageExternal 게이트·storage 상태 전이 단위 테스트 추가.
