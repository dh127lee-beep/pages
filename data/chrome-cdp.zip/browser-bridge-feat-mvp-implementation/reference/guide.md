# Reference Guide

이 폴더의 외부 레퍼런스를 우리 프로젝트(`spec/`, `task/`) 관점에서 정리한 문서다.
무엇을 참고하고, 무엇을 그대로 베끼면 안 되는지, 현재 단계(Phase 2)에 바로 쓸 수
있는 패턴을 중심으로 적었다.

## 레퍼런스가 무엇인지

| 레퍼런스 | 정체 | 우리 제품과의 관계 |
| --- | --- | --- |
| `chrome-devtools-mcp/` | Google의 공식 Chrome DevTools MCP 서버. Puppeteer로 Chrome에 CDP로 붙어 MCP tool을 노출하는 **별도 Node 프로세스** | 우리에겐 "에이전트에 붙는 adapter transport 중 하나"([00 §제품 포지셔닝](../spec/00-product-scope.md)). **tool 설계·스냅샷·응답 패턴**을 빌려오되 아키텍처(프로세스가 직접 브라우저 소유)는 채택하지 않는다 |
| `codex-control-chrome-skill.md` | Codex의 Chrome 제어 skill 문서. 확장 기반 브라우저를 에이전트가 다루는 **운영 규약** | 우리의 tab claim/finalize, snapshot-first, 세션 수명, 안전 경계의 직접적 모델. **런타임 동작 규약**을 빌려온다 |

핵심 구분: **chrome-devtools-mcp = "어떻게 tool을 만들까"의 코드 레퍼런스**,
**codex skill = "에이전트가 브라우저를 어떻게 다뤄야 안전한가"의 동작 레퍼런스**.

우리 제품은 둘 중 어느 쪽도 아니다 — 우리는 **MV3 확장이 1차 런타임**이고
브라우저 권한의 주인이다([01 §Architecture](../spec/01-architecture.md)). 두 레퍼런스는
서로 다른 층위에서 우리 설계를 보강한다.

---

## 1. chrome-devtools-mcp에서 가져올 것

### 1.1 설계 원칙 (그대로 채택 권장)

`chrome-devtools-mcp/docs/design-principles.md`의 원칙은 우리 spec과 거의
일치하며, 그대로 프로토콜/tool 설계 기준으로 삼을 만하다.

- **Agent-Agnostic API** — MCP 같은 표준에 묶이지 말고 transport 독립. 우리는
  이미 "하나의 command 프로토콜, 여러 transport(MCP/WS/Native)" 구조([03 §Protocol shape](../spec/03-protocol-and-mcp-tools.md))로 이걸 반영.
- **Token-Optimized** — JSON 50k 줄 대신 의미 요약. snapshot element cap,
  truncation warning([07 §Performance](../spec/07-test-and-quality-gates.md))과 직결.
- **Small, Deterministic Blocks** — magic button 말고 click/snapshot/screenshot
  같은 조합 가능한 작은 tool. 우리 `browser.*` tool 분할과 일치.
- **Self-Healing Errors** — 에러에 원인+다음 행동을 담는다. `handleActionError`가
  "element did not become interactive within the configured timeout"처럼 행동
  가능한 문구를 던지는 게 좋은 예. 우리 [03 §Error codes](../spec/03-protocol-and-mcp-tools.md)를
  채울 때 message/details를 이 톤으로.
- **Reference over Value** — 스크린샷/트레이스는 raw가 아니라 path/URI. 우리
  artifact store([05](../spec/05-local-bridge-and-cdp-backend.md))의 핵심 근거.
- **Progressive Complexity** — 기본은 단순, power user용 옵션 인자. `take_snapshot`의
  `verbose`, `filePath`가 예.

### 1.2 Tool 정의 구조 (`src/tools/ToolDefinition.ts`)

우리 `shared-protocol`의 tool 정의를 설계할 때 참고할 패턴:

- **선언적 tool 정의** — `{ name, description, annotations, schema(zod), handler }`
  한 객체로 tool을 기술. `annotations.readOnlyHint`로 read-only 여부를 명시 →
  우리 [02 §Permission tiers](../spec/02-security-permissions.md)의 Tier 0(read-only) 구분에 그대로 매핑.
- **page-scoped tool 분리** — `definePageTool`은 핸들러에 `page`를 주입해서 "이 tool은
  page 컨텍스트가 필요하다"를 타입으로 강제. 우리는 여기에 한 겹 더: page tool은
  `sessionId` + `pageId`가 **둘 다** 있어야 함([03](../spec/03-protocol-and-mcp-tools.md)).
  `definePageTool` 같은 헬퍼를 만들어 ownership 검증을 핸들러 진입 전에 강제하면 좋다.
- **공유 schema 조각** — `pageIdSchema`, `timeoutSchema`를 재사용. `timeout`의
  `.transform(v => v<=0 ? undefined : v)`처럼 zod transform으로 입력 정규화.
- **응답 빌더 패턴** — 핸들러가 값을 return하지 않고 `response.appendResponseLine()`,
  `response.includeSnapshot()`, `response.attachImage()`로 응답을 조립. 우리
  `{ ok, result, warnings, auditId }` envelope을 만들 때 이런 builder를 두면
  warnings/risk hints/audit을 일관되게 누적할 수 있다.

### 1.3 Snapshot + uid 매핑 (`src/TextSnapshot.ts`) — 가장 중요

우리 [04 §Element uid mapping](../spec/04-extension-backend.md), [03 §Snapshot contract](../spec/03-protocol-and-mcp-tools.md)의
직접 구현 레퍼런스. 단, **구현 수단이 다르다**(아래 "베끼면 안 되는 것" 참고).

가져올 개념:

- **a11y 트리 우선** — `accessibility.snapshot({ interestingOnly: !verbose })`로
  role/name 기반 스냅샷. 우리도 "role/name/label을 brittle CSS path보다 선호"([03](../spec/03-protocol-and-mcp-tools.md)).
- **snapshot-local uid** — `${snapshotId}_${idCounter++}` 형태로 스냅샷마다 id 발급.
  `idToNode` Map으로 uid→node 역매핑. 우리 "uid는 해당 snapshot 안에서만 유효"와 동일.
- **stale 검증** — 같은 backend node에 대해 이전 mcpId를 재사용하고, 사라진
  uniqueId는 정리. 우리는 여기서 더 나아가 uid resolution 시 role/name/tag가
  대략 일치하는지 확인하고 아니면 `SNAPSHOT_STALE`/`ELEMENT_NOT_FOUND` 반환([04](../spec/04-extension-backend.md)).
- **verbose 토글** — 기본은 `interestingOnly`, 옵션으로 전체 트리.

차이로 인해 **우리가 더 해야 할 것**: redaction(password value, hidden input),
risk hints(submit/payment/upload 등) 부착. chrome-devtools-mcp는 보안 redaction이
약하므로 이 부분은 우리 [02 §Redaction](../spec/02-security-permissions.md)을 기준으로 자체 구현.

### 1.4 액션 후 안정화 (`src/WaitForHelper.ts`, `src/tools/input.ts`)

우리 `observe → decide → act → verify` 루프와 `browser.wait_for`의 레퍼런스.

- **`waitForEventsAfterAction(action)`** — 클릭/입력 같은 action을 감싸서 (1)
  네비게이션이 시작될지 짧게 관찰 → (2) 시작되면 navigation 완료 대기 → (3)
  MutationObserver로 **DOM이 안정될 때까지**(stableDomFor 동안 변화 없음) 대기.
  우리 click/fill 핸들러가 끝나고 "결과 snapshot"을 줄 때 이 패턴을 쓰면 race가
  크게 준다.
- **dialog 처리** — action 중 뜬 dialog를 accept/dismiss로 자동 처리하고 결과에
  표시. 우리는 confirmation을 에이전트/사용자 몫으로 두므로(제품 비목표) 자동
  수락은 제한적으로. 단 dialog로 액션이 블록되는 상황 감지는 필요.
- **CPU/network multiplier** — 느린 환경에서 timeout을 배수로 늘림. 우리
  [07 §Performance targets](../spec/07-test-and-quality-gates.md)를 "non-strict"로 둔 것과 같은 맥락.
- **`select` 옵션 클릭 특수 처리**(`selectNativeSelectOption`) — native select는
  click이 아니라 value fill로 처리. content script 백엔드에서 동일한 edge case
  대비 필요.

### 1.5 동시성 / 명령 직렬화 (`src/Mutex.ts`)

41줄짜리 FIFO Mutex. `using guard = await mutex.acquire()` (Disposable) 패턴.
우리 [01 §Concurrency rules](../spec/01-architecture.md)의 "같은 page 명령은 직렬화,
같은 tab group 변경은 세션별 직렬화"를 구현할 때 이 정도 크기의 per-page /
per-group mutex면 충분하다. 무겁게 가지 말 것.

### 1.6 이벤트 수집 (`src/PageCollector.ts`)

`targetcreated`/`targetdestroyed`에 listener를 걸고 page별 console/network/issue를
WeakMap에 모으되 **navigation별로 최근 N개만 보관**(`maxNavigationSaved = 3`)하는
패턴. 우리 `list_console_messages` / `list_network_requests`([03](../spec/03-protocol-and-mcp-tools.md))의
저장 전략 참고:

- extension-tab 모드: content script/Performance API로 제한적 수집.
- extension-debugger 모드: CDP `Console`/`Log`/`Network` 이벤트로 강화([01 §Debugger Backend](../spec/01-architecture.md)).
- 어느 쪽이든 **헤더/민감 쿼리 redaction은 우리가 추가**해야 하는 부분.

### 1.7 베끼면 안 되는 것 ⚠️

- **Puppeteer로 Chrome 프로세스를 띄우거나 CDP로 직접 붙는 아키텍처.** 우리
  제품 비목표는 "별도 Chrome 프로세스 실행"이고, 확장은 로컬 프로세스를 못
  띄운다([00 §중요한 경계](../spec/00-product-scope.md)). chrome-devtools-mcp의 `browser.ts`/
  `McpContext`의 launch/connect 로직은 **adapter가 아니라 확장이 권한 주인**이라는
  우리 모델과 충돌한다. tool **인터페이스**만 보고 실행 메커니즘은 가져오지 말 것.
- **로컬 HTTP/SSE 서버를 확장 측에 여는 것.** 우리는 확장이 연결을 개시하고
  로컬 HTTP 포트를 열지 않는다([02 §144](../spec/02-security-permissions.md), [task/02](../task/02-agent-bridge-transport.md)).
- **`page.evaluate`로 임의 페이지 스크립트 실행 의존.** 우리 `evaluate_script`는
  기본 read-only/predefined probe로 제한([03](../spec/03-protocol-and-mcp-tools.md)).
- **redaction/scope가 약한 부분.** chrome-devtools-mcp는 디버깅 도구라 보안
  경계가 느슨하다. 우리 [02](../spec/02-security-permissions.md) 전체가 추가 책임.

---

## 2. Codex control-chrome skill에서 가져올 것

이 문서는 "확장 기반 브라우저를 에이전트가 다루는 런타임 규약"이라 우리 동작
설계에 가장 가깝다.

### 2.1 Tab 수명 모델 (claim / finalize)

우리 `browser.claim_tab` / `browser.release_tab` / `browser.end_session`([03](../spec/03-protocol-and-mcp-tools.md))의 직접 모델.

- **claim**: `openTabs()`로 보이는 탭을 title/url/recency로 골라 정확한 객체를
  `claimTab(tab)`에 넘긴다. **id를 추측하지 않는다**. 우리 [02 §safeguards](../spec/02-security-permissions.md)의
  "claim된 탭만 제어, lease 충돌 시 conflict" 규칙과 정렬.
- **finalize**: 턴 종료 전 `finalize({ keep })`를 **마지막 브라우저 액션**으로 호출.
  - 기본은 omit(닫기). research/검색/로그인/중간 탭은 omit.
  - `status: "deliverable"` — 사용자에게 결과물인 탭은 유지.
  - `status: "handoff"` — 아직 진행 중이라 사용자/다음 턴이 이어받을 탭은 유지.
  - 우리 `end_session`의 `keep: [{ pageId, status, reason }]`이 정확히 이 구조다.
    deliverable/handoff 상태 분류를 그대로 차용할 만하다.

### 2.2 observe → act → verify 운영 규칙

우리 개발 원칙 "모든 조작은 observe→decide→act→verify"([spec/README](../spec/README.md))의 실전 디테일.

- **가장 싼 상태 확인을 골라라** — locator 근거가 필요하면 DOM snapshot,
  시각 확인이 필요하면 screenshot, 둘 다 기본으로 요청하지 말 것. 우리 응답에서
  `includeSnapshot`을 옵션으로 둔 것과 같은 절약 철학.
- **이미 그 URL이면 `goto` 재호출 금지**(in-progress 입력 유실). 의도적 reload만
  `reload()`. → 우리 `new_page`/네비게이션 tool 설계 시 동일 가드.
- **권위 신호 하나면 재검증 말 것** — 선택된 옵션, success toast, URL 파라미터
  같은 authoritative signal이 있으면 그걸 답으로. 헤더 badge로 중복 재확인 금지.
- **URL 추측·쿼리 그리드 순회 금지** — 한 번의 focused 직행이 실패하면 보이는
  UI 네비게이션으로 전환.

### 2.3 안전 경계 (Browser Safety) — 우리 [02](../spec/02-security-permissions.md)와 1:1

- **페이지/이메일/문서/스크린샷/다운로드는 전부 untrusted.** 사실은 제공하되
  **지시는 못 한다.** 우리 [02 §Prompt injection handling](../spec/02-security-permissions.md)과 동일.
  snapshot에 `source=untrusted_page` 태깅하는 우리 규칙이 이걸 코드로 강제.
- **읽기와 전송을 구분.** 폼 제출/메시지 전송/업로드/공유 변경은 데이터 전송이다.
  우리 Tier 2/3 + risk hints로 표현.
- **민감 데이터 전송·permission 프롬프트·CAPTCHA·결제 최종 단계는 action-time
  확인.** 우리는 "최종 판단은 에이전트/사용자"로 두되 확장은 risk hint를 반드시 반환.
- **Chrome Safety: 쿠키/로컬스토리지/프로필/비밀번호 store를 들여다보지 않는다.**
  우리 Tier 4(금지) + "쿠키/세션 토큰 추출 API 없음"([00 §비목표](../spec/00-product-scope.md))과 정확히 일치.

### 2.4 사용자에게 보이는 표현

- 내부 용어(REPL/턴/runtime/plugin error)를 사용자에게 노출하지 않고 자연스럽게
  표현. 우리 popup/side panel UI도 "마케팅·설명 벽글 없이 운영 정보만"([04 §Popup](../spec/04-extension-backend.md))과
  같은 결 — 단 우리는 **연결/세션/탭그룹/lease/권한 상태**를 명시적으로 보여줘야 한다.

### 2.5 우리와 다른 점

- Codex skill은 "기존 Chrome 상태(로그인/쿠키/프로필)가 필요할 때만 Chrome을
  쓴다"는 라우팅 규약. 우리는 **확장 자체가 제품**이라 라우팅 판단은 범위 밖.
- skill은 단일 에이전트 1턴 흐름 가정. 우리는 **멀티 에이전트·멀티 세션·세션별
  탭 그룹**([00](../spec/00-product-scope.md))이 1차 요구사항 → claim/finalize 규칙을
  세션 스코프로 확장해야 한다(탭은 한 세션에만 lease, 충돌 시 `TAB_ALREADY_LEASED`).

---

## 3. 현재 단계(Phase 2)에 바로 적용할 것

[task/02-agent-bridge-transport.md](../task/02-agent-bridge-transport.md) 작업 중이라면:

> ⚠️ task/02는 spec/02의 pairing-토큰 필수 규칙과 **의도적으로 상충**한다. 현재
> 결정은 **토큰/사용자 동의 없는 자동 연결**(확장↔adapter가 뜨면 즉시 연결)이고,
> 유지하는 최소 안전선은 (1) adapter WS를 `127.0.0.1` 루프백에만 바인딩, (2)
> 웹 페이지發 명령 거부 둘뿐이다. 아래 참고 패턴은 이 자동 연결 모델 위에서 본다.

- **envelope 라우팅 + pending map + timeout** — chrome-devtools-mcp의 tool dispatch는
  단일 프로세스라 pending map이 단순하지만, 우리는 확장↔adapter WS 왕복이므로
  `id` 매칭/미매칭 응답 거부/per-message timeout을 직접 구현. (WaitForHelper의
  `AbortController` + `Promise.race(timeout)` 패턴이 timeout 구현에 참고됨.)
- **자동 연결 + 재연결 backoff** — 확장 SW가 포트파일(`~/.browser-bridge/ws-port`)을
  읽어 adapter에 접속하고 실패 시 backoff. Codex skill의 "browser 연결/재연결"
  자연어 표현처럼 popup에는 내부 용어 없이 연결/재연결 상태만 노출.
- **zod schema 재사용 패턴** — `ToolDefinition`처럼 control 메시지(hello/identify/ping)도
  zod 스키마로 검증하고 공유 조각을 만들어 두기. 단 **토큰 필드 없음**(식별·버전 협상용).
- **self-healing 에러 문구** — 핸드셰이크 버전 불일치(`TRANSPORT_UNAVAILABLE`)나
  미연결(`EXTENSION_NOT_CONNECTED`)에서 행동 가능한 진단 메시지. chrome-devtools-mcp의
  에러 톤 차용.
- **capabilities 응답 형태** — 지원 backend 목록, 권한 가용성, 버전. 단 **시크릿
  비노출**([03 §get_capabilities](../spec/03-protocol-and-mcp-tools.md)).

> 주의: 이 자동 연결 결정 때문에 §2.3의 "pairing 켜기 전 bridge 비활성"
> 안전 규칙은 **Phase 2에서는 적용되지 않는다**. 동의 단계 없이 로컬 프로세스가
> 붙을 수 있는 위험을 task/02가 명시적으로 감수한 상태이며, spec/02는 추후 이
> 결정에 맞춰 갱신 대상이다.

## 4. 이후 단계 매핑 요약

| 우리 Phase | 주 레퍼런스 | 무엇을 |
| --- | --- | --- |
| P3 세션/탭그룹 | Codex finalize/keep, Mutex | 세션 스코프 claim, per-group 직렬화 |
| P4 page lease | Codex claim/finalize | id 추측 금지, lease 충돌 처리 |
| P5 snapshot/artifact | TextSnapshot, design-principles(Reference over Value) | a11y uid 매핑 + redaction/risk hint 추가, artifact는 path/URI |
| P6 page actions | WaitForHelper, input.ts | act 후 DOM 안정화, select edge case, stale uid 거부 |
| P7 debugger | PageCollector, chrome-devtools CDP 사용부 | CDP console/network, **헤더 redaction 추가** |
| P8 native/ MCP | design-principles(Agent-Agnostic), MCP adapter | tool list를 우리 command 프로토콜에 매핑 |

## 한 줄 요약

> **chrome-devtools-mcp에서는 "tool을 어떻게 설계·직렬화·스냅샷하는가"를, Codex
> skill에서는 "에이전트가 브라우저를 어떻게 안전하게 다루는가"를 가져온다.
> 둘의 실행 아키텍처(별도 프로세스가 브라우저 소유)는 버리고, 우리의 확장-1차·
> 멀티세션·보안 경계 모델 위에 패턴만 이식한다.**
