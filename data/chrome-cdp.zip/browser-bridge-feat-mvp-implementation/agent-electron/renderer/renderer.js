// Browser Bridge — standalone Agent (Electron renderer).
// Same timeline/rendering as the web console, but the transport is IPC (window.api)
// instead of fetch + WebSocket. Main process hosts the socket and runs the agent.

const state = {
  agents: [],
  selected: null,
  logs: {},        // id -> [event]
  bubbles: {},     // id -> { run_id -> {item, kind} }
  busy: {},        // id -> bool
  thinkStart: {},  // id -> ts
};

const $ = (sel) => document.querySelector(sel);
const el = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; };

// ---------- data ----------
async function loadAgents() {
  state.agents = await window.api.listAgents();
  renderAgentList();
  if (!state.selected && state.agents.length) selectAgent(state.agents[0].id);
  renderAgentDetail();
}

async function createAgent(ev) {
  ev.preventDefault();
  $("#na-error").textContent = "";
  const body = {
    name: $("#na-name").value,
    startUrl: $("#na-url").value,
    model: $("#na-model").value,
    baseUrl: $("#na-baseurl").value,
    apiKey: $("#na-apikey").value,
  };
  try {
    const agent = await window.api.createAgent(body);
    $("#new-agent").reset();
    state.logs[agent.id] = state.logs[agent.id] || [];
    state.bubbles[agent.id] = state.bubbles[agent.id] || {};
    await loadAgents();
    selectAgent(agent.id);
  } catch (e) {
    $("#na-error").textContent = e.message || String(e);
  }
}

async function deleteAgent(id, e) {
  e.stopPropagation();
  if (!confirm("Remove this agent and end its browser session?")) return;
  await window.api.removeAgent(id);
  delete state.logs[id]; delete state.bubbles[id]; delete state.busy[id];
  if (state.selected === id) state.selected = null;
  await loadAgents();
  if (!state.selected && state.agents.length) selectAgent(state.agents[0].id);
  else if (!state.agents.length) { renderTimeline(); renderAgentDetail(); $("#sessions").innerHTML = ""; }
}

// ---------- events (single IPC stream, tagged by agent id) ----------
function handleEvent(id, ev) {
  state.logs[id] = state.logs[id] || [];
  state.bubbles[id] = state.bubbles[id] || {};
  const bubbles = state.bubbles[id];
  switch (ev.type) {
    case "status":
      if (ev.sessionId) {
        const a = state.agents.find((x) => x.id === id);
        if (a) { a.sessionId = ev.sessionId; a.tabGroupTitle = ev.tabGroupTitle; if (id === state.selected) renderAgentDetail(); }
      }
      break;
    case "turn_start": state.busy[id] = true; state.thinkStart[id] = performance.now(); if (id === state.selected) updateComposer(); break;
    case "turn_end":
      state.busy[id] = false;
      for (const k of Object.keys(bubbles)) {
        const b = bubbles[k];
        if (b.kind === "tool" && b.item && !b.item.done) { b.item.done = true; b.item.interrupted = true; }
        delete bubbles[k];
      }
      pushItem(id, { kind: "loopend", reason: ev.reason || "completed" });
      if (id === state.selected) { renderTimeline(); updateComposer(); refreshSessions(); }
      break;
    case "info": pushItem(id, { kind: "system", text: ev.message }); break;
    case "error": pushItem(id, { kind: "error", text: ev.message }); break;
    case "final_response":
      pushItem(id, { kind: "final", text: ev.content, llmMs: elapsedSince(id) });
      if (id === state.selected) renderTimeline();
      break;
    case "token": {
      let b = bubbles[ev.run_id];
      if (!b) { b = bubbles[ev.run_id] = { kind: "assistant", item: pushItem(id, { kind: "assistant", text: "", streaming: true }) }; }
      b.item.text += ev.content;
      if (id === state.selected) renderTimeline();
      break;
    }
    case "assistant_message": {
      const llmMs = elapsedSince(id);
      const b = bubbles[ev.run_id];
      if (b) {
        b.item.streaming = false;
        if (!b.item.text && ev.content) b.item.text = ev.content;
        if (!b.item.text) b.item.removed = true;
        else b.item.llmMs = llmMs;
        delete bubbles[ev.run_id];
      } else if (ev.content) {
        pushItem(id, { kind: "assistant", text: ev.content, llmMs });
      }
      if (id === state.selected) renderTimeline();
      break;
    }
    case "tool_call": {
      const item = pushItem(id, { kind: "tool", name: ev.name, args: ev.args, output: null, done: false, llmMs: elapsedSince(id) });
      bubbles["tool:" + ev.run_id] = { kind: "tool", item };
      if (id === state.selected) renderTimeline();
      break;
    }
    case "tool_result": {
      const b = bubbles["tool:" + ev.run_id];
      if (b) { b.item.output = ev.output; b.item.done = true; delete bubbles["tool:" + ev.run_id]; }
      else pushItem(id, { kind: "tool", name: ev.name, output: ev.output, done: true });
      state.thinkStart[id] = performance.now();
      if (id === state.selected) renderTimeline();
      break;
    }
  }
}

function pushItem(id, item) { (state.logs[id] = state.logs[id] || []).push(item); return item; }

function elapsedSince(id) {
  const t = state.thinkStart[id];
  return t != null ? Math.round(performance.now() - t) : null;
}
function fmtMs(ms) {
  if (ms == null) return "";
  return ms >= 1000 ? `${(ms / 1000).toFixed(1)}s` : `${ms}ms`;
}

// ---------- rendering ----------
function renderAgentList() {
  const ul = $("#agent-list");
  ul.innerHTML = "";
  for (const a of state.agents) {
    const li = el("li", "agent-item" + (a.id === state.selected ? " active" : ""));
    li.onclick = () => selectAgent(a.id);
    const dot = el("span", "dot" + (a.connected ? " connected" : ""));
    const name = el("span", "name", a.name);
    const port = el("span", "port", ":" + a.port);
    const del = el("button", "del", "✕");
    del.title = "Remove agent";
    del.onclick = (e) => deleteAgent(a.id, e);
    li.append(dot, name, port, del);
    ul.append(li);
  }
}

function selectAgent(id) {
  state.selected = id;
  renderAgentList();
  renderTimeline();
  renderAgentDetail();
  refreshSessions();
  updateComposer();
}

function currentAgent() { return state.agents.find((a) => a.id === state.selected); }

function updateComposer() {
  const a = currentAgent();
  const busy = state.busy[state.selected];
  $("#send-btn").disabled = !a || busy;
  $("#send-btn").textContent = busy ? "Running…" : "Send";
  $("#composer-input").disabled = !a;
}

function renderTimeline() {
  const tl = $("#timeline");
  const a = currentAgent();
  if (!a) { tl.innerHTML = '<div class="empty-state">Create an agent on the left, then start chatting.</div>'; return; }
  const log = (state.logs[state.selected] || []).filter((i) => !i.removed);
  tl.innerHTML = "";
  if (!log.length) tl.append(el("div", "empty-state", `Say hello to “${a.name}”. The agent will open a tab group and drive it.`));
  for (const item of log) tl.append(renderItem(item));
  tl.scrollTop = tl.scrollHeight;
}

function renderItem(item) {
  if (item.kind === "user" || item.kind === "assistant") {
    const m = el("div", `msg ${item.kind}` + (item.streaming ? " streaming" : ""));
    const role = el("div", "role", item.kind);
    if (item.kind === "assistant" && item.llmMs != null) role.append(el("span", "llm", fmtMs(item.llmMs)));
    m.append(role);
    m.append(document.createTextNode(item.text || ""));
    return m;
  }
  if (item.kind === "final") {
    const m = el("div", "msg final");
    const role = el("div", "role", "response");
    if (item.llmMs != null) role.append(el("span", "llm", fmtMs(item.llmMs)));
    m.append(role);
    m.append(document.createTextNode(item.text || ""));
    return m;
  }
  if (item.kind === "system") return el("div", "msg system", item.text);
  if (item.kind === "error") return el("div", "msg error", "⚠ " + item.text);
  if (item.kind === "loopend") {
    const labels = {
      completed: "● agent loop ended — final response above",
      limit: "● agent loop ended — step limit reached",
      error: "● agent loop ended — stopped on error",
    };
    return el("div", "loopend " + (item.reason || "completed"), labels[item.reason] || labels.completed);
  }
  if (item.kind === "tool") {
    const d = el("details", "tool");
    d.open = !item.done;
    const s = el("summary");
    s.append(el("span", "tname", item.name || "tool"));
    const intent = toolIntent(item.name, item.args);
    if (intent) s.append(el("span", "tintent", intent));
    const statusCls = item.done ? (item.interrupted ? " interrupted" : " done") : "";
    s.append(el("span", "tstatus" + statusCls, item.done ? (item.interrupted ? "interrupted" : "done") : "running…"));
    if (item.llmMs != null) s.append(el("span", "tllm", fmtMs(item.llmMs)));
    d.append(s);
    if (item.args != null) { d.append(el("div", "label", "args")); d.append(el("pre", null, prettyArgs(item.args))); }
    if (item.output != null) { d.append(el("div", "label", "result")); d.append(el("pre", null, item.output || "(empty)")); }
    return d;
  }
  return el("div");
}

function prettyArgs(args) {
  try { return typeof args === "string" ? args : JSON.stringify(args, null, 2); }
  catch { return String(args); }
}

function toolIntent(name, args) {
  let a = args;
  if (typeof a === "string") { try { a = JSON.parse(a); } catch { a = {}; } }
  if (!a || typeof a !== "object") a = {};
  const v = (x) => { try { return JSON.stringify(x); } catch { return String(x); } };
  switch (name) {
    case "navigate": return a.url ? `→ ${a.url}${a.reload ? " (reload)" : ""}` : "navigate";
    case "take_snapshot": return "snapshot the page";
    case "click": return a.uid != null ? `click ${a.uid}` : "click element";
    case "fill": return a.uid != null ? `fill ${a.uid} = ${v(a.value ?? "")}` : "fill field";
    case "scroll": return a.direction ? `scroll ${a.direction}` : "scroll";
    case "read_console": return "read console messages";
    default: return "";
  }
}

function renderAgentDetail() {
  const a = currentAgent();
  const d = $("#agent-detail");
  const titleEl = $("#chat-title"), metaEl = $("#chat-meta");
  if (!a) { d.innerHTML = '<span class="muted">No agent selected.</span>'; titleEl.textContent = "No agent selected"; metaEl.textContent = ""; return; }
  titleEl.textContent = a.name;
  metaEl.innerHTML = `<span class="dot ${a.connected ? "connected" : ""}" style="display:inline-block"></span> ` +
    (a.connected ? "extension connected" : "waiting for extension") + ` · port ${a.port}`;
  d.innerHTML = `
    <div><b>clientName</b> ${a.clientName}</div>
    <div><b>port</b> ${a.port}</div>
    <div><b>model</b> ${a.model || "—"}</div>
    <div><b>start url</b> ${a.startUrl || "—"}</div>
    <div><b>session</b> ${a.sessionId || "—"}</div>
    <div><b>tab group</b> ${a.tabGroupTitle || "—"}</div>`;
}

async function refreshSessions() {
  const a = currentAgent();
  const box = $("#sessions");
  if (!a) { box.innerHTML = ""; return; }
  try {
    const data = await window.api.getSessions(a.id);
    a.connected = data.connected; renderAgentList(); renderAgentDetail();
    const sessions = data.sessions || [];
    box.innerHTML = "";
    if (!sessions.length) { box.append(el("div", "muted", data.connected ? "No sessions yet." : "Extension not connected.")); return; }
    for (const s of sessions) {
      const card = el("div", "session-card");
      card.append(el("div", "stitle", s.tabGroupTitle || s.sessionId));
      const meta = el("div", "smeta");
      meta.append(el("span", "badge", s.status));
      meta.append(el("span", null, `${s.pageCount} page(s)`));
      meta.append(el("span", null, s.sessionId));
      card.append(meta);
      box.append(card);
    }
  } catch (e) {
    box.innerHTML = `<div class="muted">${e.message || e}</div>`;
  }
}

// ---------- composer ----------
function sendMessage(ev) {
  ev.preventDefault();
  const a = currentAgent();
  const input = $("#composer-input");
  const content = input.value.trim();
  if (!a || !content || state.busy[a.id]) return;
  pushItem(a.id, { kind: "user", text: content });
  renderTimeline();
  window.api.send(a.id, content);
  input.value = "";
}

// ---------- boot ----------
function init() {
  window.api.onEvent((id, ev) => handleEvent(id, ev));
  $("#new-agent").addEventListener("submit", createAgent);
  $("#composer").addEventListener("submit", sendMessage);
  $("#refresh-sessions").addEventListener("click", refreshSessions);

  const composerInput = $("#composer-input");
  let lastCompositionEndAt = 0;
  composerInput.addEventListener("compositionend", () => { lastCompositionEndAt = Date.now(); });
  composerInput.addEventListener("keydown", (e) => {
    if (e.key !== "Enter" || e.shiftKey) return;
    if (e.isComposing || e.keyCode === 229) return;
    if (Date.now() - lastCompositionEndAt < 100) return;
    e.preventDefault();
    sendMessage(e);
  });

  window.api.getConfig().then((c) => { $("#na-model").placeholder = `model (default: ${c.defaultModel})`; }).catch(() => {});
  loadAgents();

  // Poll connection status so the dots update as the extension attaches.
  setInterval(async () => {
    try {
      const agents = await window.api.listAgents();
      const map = Object.fromEntries(agents.map((a) => [a.id, a]));
      let changed = false;
      for (const a of state.agents) { const n = map[a.id]; if (n && n.connected !== a.connected) { a.connected = n.connected; changed = true; } }
      if (changed) { renderAgentList(); renderAgentDetail(); }
    } catch {}
  }, 3000);
}

init();
