/**
 * Preload (context-isolated). Exposes a small IPC-backed API to the renderer SPA.
 * No Node access leaks to the page; everything goes through these typed channels.
 */
const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("api", {
  getConfig: () => ipcRenderer.invoke("config:get"),
  listAgents: () => ipcRenderer.invoke("agents:list"),
  createAgent: (body) => ipcRenderer.invoke("agents:create", body),
  removeAgent: (id) => ipcRenderer.invoke("agents:remove", id),
  getSessions: (id) => ipcRenderer.invoke("agents:sessions", id),
  send: (id, content) => ipcRenderer.send("agents:send", { id, content }),
  onEvent: (cb) => {
    const h = (_e, { id, ev }) => cb(id, ev);
    ipcRenderer.on("agent:event", h);
    return () => ipcRenderer.removeListener("agent:event", h);
  },
  onStatus: (cb) => {
    const h = (_e, s) => cb(s);
    ipcRenderer.on("status", h);
    return () => ipcRenderer.removeListener("status", h);
  },
});
