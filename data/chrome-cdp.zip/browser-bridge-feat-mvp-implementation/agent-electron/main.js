/**
 * Electron main process — standalone agent console.
 *
 * Hosts the adapter WebSocket endpoint IN-PROCESS (the extension auto-connects to
 * ws://127.0.0.1:18470) and runs the JS agent loop locally. No Python, no separate
 * frontend server. The renderer talks to main over IPC; main forwards browser tool
 * calls to the extension via the embedded socket.
 */

const { app, BrowserWindow, ipcMain, shell, Menu } = require("electron");
const path = require("node:path");
const fs = require("node:fs");
const { pathToFileURL } = require("node:url");
const { AgentManager } = require("./manager.js");

const REPO_ROOT = path.resolve(__dirname, "..");
const WS_PORT = Number(process.env.BB_WS_PORT || 18470);

const DEFAULTS = {
  port: WS_PORT,
  baseUrl: process.env.OPENAI_BASE_URL || "http://127.0.0.1:10001/v1",
  model: process.env.OPENAI_MODEL || "mlx-community/gemma-4-12B-it-8bit",
  apiKey: process.env.OPENAI_API_KEY || "local",
  maxTokens: Number(process.env.OPENAI_MAX_TOKENS || 1024),
};

let server = null;
let manager = null;
let win = null;

function adapterDist() {
  return path.join(REPO_ROOT, "packages", "agent-adapter", "dist", "index.js");
}

async function startSocket() {
  const dist = adapterDist();
  if (!fs.existsSync(dist)) {
    throw new Error(`agent-adapter is not built. Run \`pnpm build\` at the repo root.\n(missing ${dist})`);
  }
  const adapter = await import(pathToFileURL(dist).href);
  server = new adapter.DevWsServer({
    port: WS_PORT,
    clientName: "agent-electron",
    onConnected: (cid) => {
      console.error(`[agent-electron] extension connected (${cid})`);
      win?.webContents.send("status", { connected: true });
    },
    onDisconnected: () => {
      console.error("[agent-electron] extension disconnected");
      win?.webContents.send("status", { connected: false });
    },
  });
  const { port } = await server.start();
  DEFAULTS.port = port;
  console.error(`[agent-electron] socket listening on ws://127.0.0.1:${port}`);
  manager = new AgentManager(server, DEFAULTS);
}

function registerIpc() {
  ipcMain.handle("config:get", () => ({
    defaultModel: DEFAULTS.model,
    defaultBaseUrl: DEFAULTS.baseUrl,
    port: DEFAULTS.port,
  }));
  ipcMain.handle("agents:list", () => manager.list());
  ipcMain.handle("agents:create", (_e, body) => manager.create(body || {}));
  ipcMain.handle("agents:remove", (_e, id) => manager.remove(id));
  ipcMain.handle("agents:sessions", (_e, id) => manager.sessions(id));
  ipcMain.on("agents:send", (_e, { id, content }) => {
    const emit = (ev) => win?.webContents.send("agent:event", { id, ev });
    void manager.send(id, content, emit);
  });
}

function errorHtml(message) {
  return `data:text/html,${encodeURIComponent(
    `<html><body style="font:14px system-ui;padding:24px;color:#222">
      <h2>Agent console failed to start</h2>
      <pre style="white-space:pre-wrap">${message}</pre>
    </body></html>`,
  )}`;
}

async function createWindow(errorMessage) {
  win = new BrowserWindow({
    width: 1280,
    height: 860,
    title: "Browser Bridge — Agent (standalone)",
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      preload: path.join(__dirname, "preload.js"),
    },
  });
  win.webContents.setWindowOpenHandler(({ url }) => {
    void shell.openExternal(url);
    return { action: "deny" };
  });
  if (errorMessage) await win.loadURL(errorHtml(errorMessage));
  else await win.loadFile(path.join(__dirname, "renderer", "index.html"));
}

app.whenReady().then(async () => {
  Menu.setApplicationMenu(
    Menu.buildFromTemplate([
      { role: "appMenu" },
      { role: "editMenu" },
      { label: "View", submenu: [{ role: "reload" }, { role: "forceReload" }, { role: "toggleDevTools" }, { type: "separator" }, { role: "togglefullscreen" }] },
      { role: "windowMenu" },
    ]),
  );
  try {
    await startSocket();
    registerIpc();
    await createWindow();
  } catch (e) {
    console.error("[agent-electron]", e);
    await createWindow(e.message || String(e));
  }
  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) void createWindow();
  });
});

async function shutdown() {
  try {
    await server?.stop();
  } catch {
    /* ignore */
  }
}

app.on("window-all-closed", () => {
  void shutdown();
  if (process.platform !== "darwin") app.quit();
});
app.on("before-quit", () => {
  void shutdown();
});
