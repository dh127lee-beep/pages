/**
 * Agent manager (Electron main side).
 * Owns the agents and drives turns over the embedded adapter socket (DevWsServer).
 * One socket / one extension connection; each agent is an isolated session.
 */

const { runTurn } = require("./agent.js");

function toDict(a) {
  return {
    id: a.id,
    name: a.name,
    clientName: a.clientName,
    port: a.port,
    connected: a.server.connected,
    model: a.llm.model,
    baseUrl: a.llm.baseUrl,
    startUrl: a.startUrl,
    sessionId: a.sessionId,
    tabGroupTitle: a.tabGroupTitle,
  };
}

async function waitConnected(server, timeoutMs = 60000) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    if (server.connected) return true;
    await new Promise((r) => setTimeout(r, 300));
  }
  return false;
}

class AgentManager {
  constructor(server, defaults) {
    this.server = server;
    this.defaults = defaults; // { baseUrl, model, apiKey, maxTokens, port }
    this.agents = new Map();
    this.seq = 0;
  }

  list() {
    return [...this.agents.values()].map(toDict);
  }

  get(id) {
    return this.agents.get(id);
  }

  create({ name, startUrl, model, baseUrl, apiKey }) {
    name = (name || "").trim();
    if (!name) throw new Error("agent name is required");
    if ([...this.agents.values()].some((a) => a.name === name)) {
      throw new Error(`agent name '${name}' is already in use`);
    }
    this.seq += 1;
    const id = `agent_${this.seq}`;
    const agent = {
      id,
      name,
      clientName: name,
      port: this.defaults.port,
      server: this.server,
      startUrl: startUrl || "https://example.com/",
      llm: {
        baseUrl: baseUrl || this.defaults.baseUrl,
        model: model || this.defaults.model,
        apiKey: apiKey || this.defaults.apiKey,
        maxTokens: this.defaults.maxTokens,
      },
      recursionLimit: 40,
      history: [],
      busy: false,
      ready: false,
      sessionId: null,
      pageId: null,
      tabGroupTitle: null,
      snapshotId: null,
    };
    this.agents.set(id, agent);
    return toDict(agent);
  }

  async ensureReady(agent, emit) {
    if (agent.ready) return;
    if (!this.server.connected) emit({ type: "info", message: "waiting for the extension to connect…" });
    if (!(await waitConnected(this.server))) throw new Error("extension did not connect");
    const s = await this.server.request("browser.start_session", {
      mode: "extension-tab",
      clientName: agent.clientName,
      sessionLabel: agent.name,
    });
    if (!s.ok) throw new Error(`${s.error.code}: ${s.error.message}`);
    agent.sessionId = s.result.sessionId;
    agent.tabGroupTitle = s.result.tabGroup && s.result.tabGroup.title;
    const p = await this.server.request("browser.new_page", { url: agent.startUrl }, { sessionId: agent.sessionId });
    if (!p.ok) throw new Error(`${p.error.code}: ${p.error.message}`);
    agent.pageId = p.result.pageId;
    agent.ready = true;
  }

  async send(id, content, emit) {
    const agent = this.agents.get(id);
    if (!agent) throw new Error("unknown agent");
    if (agent.busy) return;
    agent.busy = true;
    emit({ type: "turn_start" });
    try {
      await this.ensureReady(agent, emit);
      emit({ type: "status", connected: true, sessionId: agent.sessionId, tabGroupTitle: agent.tabGroupTitle });
      const { reason } = await runTurn({ server: this.server, agent, task: content, emit });
      emit({ type: "turn_end", reason });
    } catch (e) {
      emit({ type: "error", message: `${e.name || "Error"}: ${e.message}` });
      emit({ type: "turn_end", reason: "error" });
    } finally {
      agent.busy = false;
    }
  }

  async sessions(id) {
    const agent = this.agents.get(id);
    if (!agent) return { connected: false, sessions: [] };
    if (!this.server.connected) return { connected: false, sessions: [] };
    const res = await this.server.request("browser.list_sessions");
    return { connected: true, sessions: res.ok && Array.isArray(res.result) ? res.result : [] };
  }

  async remove(id) {
    const agent = this.agents.get(id);
    if (!agent) return;
    if (agent.sessionId) {
      try {
        await this.server.request("browser.end_session", {}, { sessionId: agent.sessionId });
      } catch {
        /* best-effort */
      }
    }
    this.agents.delete(id);
  }
}

module.exports = { AgentManager };
