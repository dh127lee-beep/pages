# Agent (standalone Electron app)

A self-contained desktop app that **hosts the bridge socket itself** and runs the
agent loop **in-process** — no Python, no separate frontend server.

```
Electron main
 ├─ DevWsServer  ws://127.0.0.1:18470   ◀── Chrome extension (auto-connects)
 ├─ JS agent loop (OpenAI-compatible LLM, native tool calling)
 └─ IPC ─▶ renderer (chat + tool timeline + sessions)
```

It embeds `@browser-bridge/agent-adapter`'s `DevWsServer` (the extension connects
out to it) and drives browser tools via `server.request`. The agent brain is a
JS port of `agent/agent.py` (observe → act → verify, ending with `final_response`).

## Run

```bash
# 1) build the workspace (produces packages/agent-adapter/dist used by the app)
pnpm build

# 2) install Electron for this app (standalone, not in the pnpm workspace)
cd agent-electron && npm install

# 3) point at a local OpenAI-compatible LLM (defaults shown)
export OPENAI_BASE_URL=http://127.0.0.1:10001/v1
export OPENAI_MODEL=mlx-community/gemma-4-12B-it-8bit
# export OPENAI_API_KEY=local   OPENAI_MAX_TOKENS=1024   BB_WS_PORT=18470

# 4) launch
npm start
```

Then load the extension (`chrome://extensions` → load unpacked →
`packages/extension/dist`). It auto-connects to `ws://127.0.0.1:18470`; the agent
dot turns green. Create an agent, chat, watch tool cards + the final response.

## Layout

- `main.js` — starts the embedded socket, registers IPC, opens the window.
- `manager.js` — agents + sessions; drives turns over the socket.
- `agent.js` — the LLM loop + browser tools (take_snapshot/navigate/click/fill/scroll/read_console + final_response).
- `preload.js` — context-isolated IPC bridge (`window.api`).
- `renderer/` — the SPA (chat, tool timeline, sessions); same UI as the web console, IPC transport.

## Notes

- One socket / one extension connection; each agent is an isolated session.
- LLM config via env (`OPENAI_BASE_URL`/`OPENAI_MODEL`/`OPENAI_API_KEY`/`OPENAI_MAX_TOKENS`).
  `max_tokens` is sent as the legacy field so MLX-VLM honors it.
- Requires `pnpm build` first so `packages/agent-adapter/dist` (and `shared-protocol`) exist;
  the app `import()`s the built adapter and resolves `ws` from the repo's `node_modules`.
