# 09. Multi-Agent Lifecycle Hardening

버려진 세션·혼합 소유권·stale 탭 그룹을 방지하는 단계.

- 대응 로드맵: [06 Phase 9](../spec/06-development-roadmap-tasks.md#L221)
- 근거: [01 §Concurrency rules](../spec/01-architecture.md#L264), [02 §Audit events](../spec/02-security-permissions.md#L192)

## 목표

- 세션 idle 타임아웃, page lease 만료(세션 단위)
- 세션별 명령 큐 제한
- 탭 lease 충돌 처리(`TAB_ALREADY_LEASED`, 기구현)
- 재연결 후 세션 resume, SW rehydration
- 빈/detached 탭 그룹 정리
- 세션/탭그룹 id를 포함한 audit 연결

## 설계 포인트

- **AuditLog**(bounded): tool 호출마다 `{auditId, agentId, sessionId, pageId, tabGroupId, type, ok, code, ts}` 기록(페이로드 없음), 성공 응답에 `auditId` 부착.
- **명령 큐 제한**: 세션별 in-flight 카운터, 초과 시 `COMMAND_LIMIT_EXCEEDED`(신규 에러코드).
- **idle reaper**: `SessionManager.listIdle(idleMs, now)` → bridge `reapIdleSessions`가 detach+탭정리+finalize. SW는 `chrome.alarms`로 주기 호출.
- **빈 그룹 정리**: 마지막 page 제거 시 `SessionManager.finalizeIfEmpty` → tabGroup `closed` + 세션 finalized(기본 정책).
- **resume/rehydration**: agentId(=clientName 파생) + store 영속으로 재연결/재시작 후 세션·페이지 복원.

## 변경/추가 파일

### shared-protocol
- `errors.ts`: `COMMAND_LIMIT_EXCEEDED` 추가.

### extension
- `background/audit-log.ts` (신규): `AuditLog`.
- `background/session-manager.ts`: `listIdle`/`finalizeIfEmpty`.
- `background/page-manager.ts`: onTabRemoved/release 시 `finalizeIfEmpty`.
- `background/bridge.ts`: audit + 큐 제한 + `reapIdleSessions` (dispatch 분리).
- `service-worker.ts`: `chrome.alarms` reaper, audit 배선.
- `manifest.json`: `alarms` 권한.

## 완료 기준 (Acceptance)

[06 Phase 9](../spec/06-development-roadmap-tasks.md#L236) 기준:

- [x] finalized/released page를 어떤 액션도 대상으로 못 한다 (requireActive + lease 확인)
- [x] 충돌 claim은 `TAB_ALREADY_LEASED`를 반환한다 (기구현, 테스트 존재)
- [x] 재연결한 에이전트가 non-finalized 세션을 resume한다 (agentId 파생 + 영속)
- [x] 빈 세션 그룹이 정책대로 finalize/handoff된다 (finalizeIfEmpty → closed)
- [x] audit 이벤트가 agent/session/page/tab group id를 포함한다

### 추가 자동 검증
- [x] `pnpm typecheck` / `test`(124) / `build` / `lint` 통과
- [x] audit/명령제한/idle reaper/빈그룹/resume/rehydration 단위테스트

## 구현 현황

상태 범례: ⬜ 미착수 · 🟡 진행중 · ✅ 완료

| # | 항목 | 산출물 | 상태 | 비고 |
| --- | --- | --- | --- | --- |
| 1 | 에러코드 | shared-protocol `errors.ts` + spec/03 | ✅ | COMMAND_LIMIT_EXCEEDED |
| 2 | AuditLog | extension `background/audit-log.ts` | ✅ | bounded, id 연결 |
| 3 | idle/empty 정리 | extension `background/session-manager.ts` | ✅ | listIdle/finalizeIfEmpty |
| 4 | page 정리 훅 | extension `background/page-manager.ts` | ✅ | onTabRemoved/release |
| 5 | bridge audit+제한+reaper | extension `background/bridge.ts` | ✅ | dispatch 분리, 큐 제한 |
| 6 | SW alarms + 배선 | extension `service-worker.ts`/`manifest.json` | ✅ | alarms 권한, 5분 주기 |
| 7 | 테스트 | `tests/hardening.test.ts` | ✅ | 6 영역 |
| 8 | 자동 게이트 | typecheck/test/build/lint | ✅ | 124 passed |
| 9 | 수동 확인 | idle/정리/재연결 (브라우저) | ⬜ | 수동 확인 필요 |

## 다음 task 연결

- 완료 후 [06 Phase 10](../spec/06-development-roadmap-tasks.md#L244) **Hardening and docs**.
