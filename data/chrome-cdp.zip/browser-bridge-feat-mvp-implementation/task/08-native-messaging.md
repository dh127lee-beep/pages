# 08. Native Messaging Production Path

Phase 2의 dev WebSocket를 더 안전한 Native Messaging 경로로 보완하는 단계.

- 대응 로드맵: [06 Phase 8](../spec/06-development-roadmap-tasks.md#L198)
- 근거: [05 §Native Messaging host](../spec/05-local-bridge-and-cdp-backend.md#L69), [02 §Native Messaging safety](../spec/02-security-permissions.md#L181)

## 목표

- Native Messaging 프레이밍(4-byte LE length + JSON) encode/decode
- native host manifest 생성 + 설치 안내
- 핸드셰이크 버전 협상, 확장 id 검증, 진단(누락/불일치)
- 메시지 타임아웃, 로컬 HTTP 포트 불필요
- MCP 어댑터에서 tool 목록 제공

## 테스트 전략

- **framing**(pure): encode/Decoder round-trip + partial chunk.
- **AdapterEndpoint**(pure): ws/native 공용 어댑터측 핸드셰이크+RPC. fake send로 테스트.
- **NativeHost**(주입 스트림): hello→identify, welcome→ready, request 왕복, 확장 id 검증.
- **host-manifest**(pure), **McpServer**(주입 스트림, initialize/tools/list).

## 설계 포인트

- 확장↔호스트는 native messaging(stdio). **확장은 framing 안 함**(Chrome이 처리), **호스트만 framing**.
- ws-server와 native-host는 `AdapterEndpoint`(shared-protocol)로 핸드셰이크/RPC 로직 공유 → DevWsServer 리팩터링.
- 확장 id 검증: 호스트가 caller origin(argv)에서 추출한 id를 allowlist와 대조.
- 확장 부팅: native 우선 시도 → 불가 시 WS fallback, capabilities.nativeHostAvailable 반영.
- MCP: newline-delimited JSON-RPC로 `initialize`/`tools/list`(정적 tool 목록) 응답. 실행 브리지(호스트↔별도 MCP 클라이언트 프로세스 IPC)는 후속.

## 변경/추가 파일

### shared-protocol
- `native-framing.ts` (신규): `encodeFrame`/`FrameDecoder`.
- `adapter-endpoint.ts` (신규): `AdapterEndpoint`.

### agent-adapter
- `ws-server.ts`: `AdapterEndpoint` 사용으로 리팩터링.
- `mcp-server.ts`: 최소 JSON-RPC(`initialize`/`tools/list`).

### native-host
- `host-manifest.ts` (신규): `generateHostManifest`.
- `native-host.ts` (신규): `NativeHost`(framing+endpoint+확장 id 검증).
- `index.ts`: `startNativeHost` 배선.

### extension
- `bridge/native-transport.ts` (신규): `connectNative` + ConnectionSession.
- `background/capabilities.ts`: nativeHostAvailable getter.
- `service-worker.ts`: native-first/WS-fallback.

## 완료 기준 (Acceptance)

[06 Phase 8](../spec/06-development-roadmap-tasks.md#L212) 기준:

- [x] 확장이 native messaging으로 연결된다 (NativeTransport↔NativeHost, framing+핸드셰이크)
- [x] MCP client가 adapter로 tool 목록을 조회한다 (initialize/tools/list)
- [x] 버전 불일치가 명확한 진단을 반환한다 (`bridge.reject` VERSION_MISMATCH)
- [x] native host 누락이 명확한 설정 메시지를 반환한다 (onUnavailable→WS fallback + 로그)
- [x] 메시지 타임아웃이 처리된다 (RpcClient/AdapterEndpoint)
- [x] 프로덕션에서 로컬 HTTP 포트가 필요 없다 (native messaging stdio)

### 일부 후속
- 호스트↔별도 MCP 클라이언트 프로세스 IPC로 tool **실행** 브리지 (이번엔 목록까지).

### 추가 자동 검증
- [x] `pnpm typecheck` / `test`(118) / `build` / `lint` 통과
- [x] framing/AdapterEndpoint/NativeHost/host-manifest/McpServer 단위테스트

## 구현 현황

상태 범례: ⬜ 미착수 · 🟡 진행중 · ✅ 완료

| # | 항목 | 산출물 | 상태 | 비고 |
| --- | --- | --- | --- | --- |
| 1 | native framing | shared-protocol `native-framing.ts` | ✅ | 4-byte LE, 스트림 디코더 |
| 2 | AdapterEndpoint | shared-protocol `adapter-endpoint.ts` | ✅ | ws/native 공용 |
| 3 | DevWsServer 리팩터 | agent-adapter `ws-server.ts` | ✅ | endpoint 사용 |
| 4 | MCP 최소 서버 | agent-adapter `mcp-server.ts` | ✅ | initialize/tools/list |
| 5 | host-manifest | native-host `host-manifest.ts` | ✅ | allowed_origins |
| 6 | NativeHost | native-host `native-host.ts` | ✅ | framing+확장 id 검증 |
| 7 | startNativeHost | native-host `index.ts` | ✅ | stdio 배선 |
| 8 | NativeTransport | extension `bridge/native-transport.ts` | ✅ | connectNative |
| 9 | native-first/fallback | extension `service-worker.ts`/`capabilities.ts` | ✅ | nativeHostAvailable |
| 10 | 테스트 | `tests/` (framing/endpoint/host/manifest/mcp) | ✅ | +16 tests |
| 11 | 자동 게이트 | typecheck/test/build/lint | ✅ | 118 passed |
| 12 | 수동 확인 | 실제 native messaging (브라우저+호스트 설치) | ⬜ | 수동 확인 필요 |

## 다음 task 연결

- 완료 후 [06 Phase 9](../spec/06-development-roadmap-tasks.md#L221) **Multi-agent lifecycle hardening**.
