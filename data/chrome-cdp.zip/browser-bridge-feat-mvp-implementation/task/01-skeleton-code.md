# 01. Skeleton Code

스켈레톤 코드 구성을 위한 세부 구현 계획과 구현 현황 문서다.

- 대응 로드맵: [06-development-roadmap-tasks.md](../spec/06-development-roadmap-tasks.md) **Phase 0 (Repository baseline)** 전체 + **Phase 1 (MV3 extension shell)** 의 비기능 골격
- 패키지 레이아웃 근거: [05-local-bridge-and-cdp-backend.md](../spec/05-local-bridge-and-cdp-backend.md#L18)
- 프로토콜 근거: [03-protocol-and-mcp-tools.md](../spec/03-protocol-and-mcp-tools.md)

## 목표

브라우저 기능은 아직 구현하지 않는다. 이 단계의 목표는 **빌드/타입/테스트가
돌아가는 빈 골격**을 세우는 것이다.

- monorepo 패키지 레이아웃 구성
- TypeScript 빌드 + lint + test 파이프라인 동작
- `shared-protocol`이 기본 id/타입/에러코드/툴 이름을 export
- `extension`이 브라우저 기능 없이 컴파일되고 unpacked 로드 가능
- `agent-adapter` / `native-host` / `artifact-store`는 인터페이스와 stub만

## 비목표 (이 task 범위 밖)

- 실제 세션/탭 그룹/lease 동작 → 이후 task
- 실제 snapshot/click/fill 등 액션 실행 → 이후 task
- 실제 transport 연결(WebSocket/Native Messaging) 동작 → 이후 task
- 에이전트 로직 자체 → 제품 비목표 ([00-product-scope.md](../spec/00-product-scope.md))

## 제안 기술 스택

| 영역 | 선택 | 비고 |
| --- | --- | --- |
| 패키지 관리 | pnpm workspaces | `pnpm-workspace.yaml`로 monorepo 구성 |
| 언어 | TypeScript (strict) | 전 패키지 공통 |
| 런타임 스키마 검증 | zod | `shared-protocol`에서 envelope/payload 검증, adapter·extension 공유 |
| 확장 번들러 | esbuild | service worker / content / popup / options를 각각 단일 파일로 번들 |
| 테스트 | vitest | 노드 환경, 패키지별 + 루트 |
| lint/format | ESLint(flat) + Prettier | CI 스크립트로 묶음 |
| 타입 경계 | TS project references | 패키지 간 타입 빌드 순서 보장 |

## 대상 디렉터리 트리

```text
browser-bridge/
  package.json                # 루트 스크립트 + devDependencies
  pnpm-workspace.yaml         # workspace 패키지 글롭
  tsconfig.base.json          # 공통 컴파일러 옵션
  tsconfig.json               # project references 루트
  eslint.config.js
  .prettierrc
  vitest.config.ts
  .gitignore
  packages/
    shared-protocol/
      package.json
      tsconfig.json
      src/
        index.ts              # 공개 진입점 re-export
        ids.ts                # id 타입/브랜드 + 생성 헬퍼 stub
        envelopes.ts          # transport/request/response envelope 타입
        tools.ts              # tool 이름 상수 + payload 타입
        errors.ts             # 에러 코드 상수/유니온
        schemas.ts            # zod 스키마 (stub)
    extension/
      package.json
      tsconfig.json
      manifest.json           # MV3, 초기 권한 세트
      build.mjs               # esbuild 빌드 스크립트
      src/
        service-worker.ts     # SW 진입점, bridge bootstrap stub
        background/
          bridge.ts           # 연결/메시지 라우팅 골격
          session-manager.ts  # 세션 상태 머신 stub
          tab-group-manager.ts# tab group 관리 stub
          scope-guard.ts      # 소유권/권한 검증 stub
          backends/
            content-backend.ts# content script 위임 stub
            debugger-backend.ts# chrome.debugger 위임 stub
        content/
          content-script.ts   # snapshot/action 메시지 핸들러 stub
        popup/
          popup.html
          popup.ts            # 연결 상태 표시 stub
          popup.css
        options/
          options.html
          options.ts          # 기본 설정 저장 stub
        lib/
          storage.ts          # chrome.storage 헬퍼
          logger.ts
        state/
          connection-state.ts # connected/disconnected 모델
    agent-adapter/
      package.json
      tsconfig.json
      src/
        index.ts              # 진입점 stub
        ws-server.ts          # localhost WS 엔드포인트 stub
        mcp-server.ts         # MCP tool list stub
        transport.ts          # extension 프로토콜 변환 stub
        pairing.ts            # pairing token 핸드오프 stub
    native-host/
      package.json
      tsconfig.json
      src/
        index.ts              # framed JSON stdio stub
      host-manifest.template.json
    artifact-store/
      package.json
      tsconfig.json
      src/
        index.ts              # ArtifactStore 인터페이스
        local-fs-store.ts     # 세션 디렉터리 기반 구현 stub
  spec/                       # (기존)
  task/                       # (이 문서 포함)
  tests/
    smoke.test.ts             # 패키지 import/타입 스모크 테스트
```

## 패키지별 골격 상세

### shared-protocol

- `ids.ts`: `SessionId`, `AgentId`, `TabGroupId`, `PageId`, `SnapshotId`, `Uid`,
  `ArtifactId`, `AuditId`, `ConnectionId` 브랜디드 타입과 `newSessionId()` 류
  생성 헬퍼 stub. (id 종류는 [03 §Ids](../spec/03-protocol-and-mcp-tools.md#L47) 기준)
- `envelopes.ts`: transport 메시지 `{ id, version, type, sessionId?, pageId?, payload }`,
  성공 응답 `{ ok: true, ... }`, 에러 응답 `{ ok: false, error }` 타입.
- `tools.ts`: `browser.*` tool 이름 상수와 각 payload 타입 자리(미구현은 `unknown`).
- `errors.ts`: [03 §Error codes](../spec/03-protocol-and-mcp-tools.md#L462)의 코드 유니온.
- `schemas.ts`: zod 스키마 stub(우선 envelope만, tool payload는 점진 추가).

### extension

- `manifest.json`: MV3, `activeTab` / `scripting` / `tabs` / `tabGroups` /
  `storage` / `debugger` + `<all_urls>` host permission, optional `nativeMessaging`.
  (근거: [06 Phase 1](../spec/06-development-roadmap-tasks.md#L36), [02 §permission](../spec/02-security-permissions.md#L87))
- `service-worker.ts`: bridge bootstrap만. 실제 명령 처리는 stub (`UNSUPPORTED_ACTION` 반환).
- `background/*`: 클래스/모듈 골격과 메서드 시그니처만. 내부는 `throw new Error('not implemented')`
  또는 명시적 stub 반환.
- `content/content-script.ts`: message listener 등록만, 액션은 미구현.
- `popup` / `options`: 정적 HTML + 최소 TS. popup은 disconnected 상태 표시,
  options는 기본 설정 1개 저장/로드(Phase 1 acceptance 충족).
- `build.mjs`: esbuild로 각 진입점 번들 → `dist/`. manifest/HTML/CSS는 복사.

### agent-adapter / native-host / artifact-store

- 모두 컴파일되는 stub. 공개 인터페이스/타입만 정의하고 동작은 미구현.
- `artifact-store/index.ts`: `ArtifactStore` 인터페이스(`put`, `getPath`, `cleanup(sessionId)`)
  정의, `local-fs-store.ts`는 시그니처만.

## 루트 스크립트 (package.json)

| 스크립트 | 동작 |
| --- | --- |
| `pnpm build` | 전 패키지 tsc 빌드 + extension esbuild 번들 |
| `pnpm typecheck` | `tsc -b --noEmit` (project references) |
| `pnpm test` | vitest run |
| `pnpm lint` | eslint . |
| `pnpm format` | prettier --write |
| `pnpm build:ext` | extension만 번들 (`node packages/extension/build.mjs`) |

패키지 간 의존은 `workspace:*` 프로토콜로 참조한다.

## 완료 기준 (Acceptance)

[06 Phase 0](../spec/06-development-roadmap-tasks.md#L21) 기준 + 확장 셸 일부:

- [x] `pnpm test`가 실행되고 스모크 테스트 통과 (6 tests)
- [x] `pnpm build` 성공 (tsc -b + extension esbuild 번들)
- [x] `pnpm typecheck` 통과 (strict, `tsc -b`)
- [x] `pnpm lint` 통과 (eslint, 에러 없음)
- [x] `shared-protocol`이 기본 id/타입/에러코드/tool 이름 export
- [x] `extension`이 브라우저 기능 없이 컴파일되고 `dist/` 생성
- [x] `manifest.json`이 초기 고권한 세트를 의도적으로 포함
- [ ] 확장이 Chrome에 unpacked로 로드되고 popup이 disconnected 상태 표시 *(수동 확인 필요)*
- [ ] options 페이지가 기본 설정 1개를 저장/로드 *(수동 확인 필요)*

### 검증 명령

```bash
corepack enable && corepack prepare pnpm@9.15.0 --activate  # pnpm 준비 (최초 1회)
pnpm install
pnpm typecheck   # tsc -b
pnpm test        # vitest run → 6 passed
pnpm build       # dist/ 에 service-worker/popup/options/content + manifest/html/css
pnpm lint
```

빌드 산출물(`packages/extension/dist/`)을 Chrome `chrome://extensions` →
개발자 모드 → "압축해제된 확장 프로그램 로드"로 올려 popup/options를 수동 확인한다.

## 구현 현황

상태 범례: ⬜ 미착수 · 🟡 진행중 · ✅ 완료

| # | 항목 | 산출물 | 상태 | 비고 |
| --- | --- | --- | --- | --- |
| 1 | monorepo 베이스 | 루트 `package.json`, `pnpm-workspace.yaml`, `.gitignore` | ✅ | |
| 2 | TS 설정 | `tsconfig.base.json`, 루트 references, 패키지별 tsconfig | ✅ | project references 사용 |
| 3 | lint/format | `eslint.config.js`, `.prettierrc` | ✅ | eslint flat + typescript-eslint |
| 4 | 테스트 설정 | `vitest.config.ts`, `tests/smoke.test.ts` | ✅ | src alias로 빌드 비의존 |
| 5 | shared-protocol | `ids/envelopes/tools/errors/schemas/index` | ✅ | zod envelope 스키마 포함 |
| 6 | extension manifest | `manifest.json` (초기 권한) | ✅ | |
| 7 | extension 빌드 | `build.mjs` (esbuild) | ✅ | IIFE 번들 + 정적자산 복사 |
| 8 | extension SW/background | `service-worker.ts`, `background/*` stub | ✅ | 미구현 툴은 `UNSUPPORTED_ACTION` |
| 9 | extension content | `content-script.ts` stub | ✅ | manifest 자동주입 안 함 |
| 10 | extension popup | `popup.html/ts/css` (disconnected 표시) | ✅ | storage.session 구독 |
| 11 | extension options | `options.html/ts` (설정 저장/로드) | ✅ | adapterPort 저장 |
| 12 | extension lib/state | `storage.ts`, `logger.ts`, `connection-state.ts` | ✅ | |
| 13 | agent-adapter stub | `index/ws-server/mcp-server/transport/pairing` | ✅ | NullTransport 동작 |
| 14 | native-host stub | `index.ts`, `host-manifest.template.json` | ✅ | |
| 15 | artifact-store stub | `index.ts`(인터페이스), `local-fs-store.ts` | ✅ | |
| 16 | 루트 스크립트 | build/typecheck/test/lint/format | ✅ | |
| 17 | 완료 기준 검증 | 위 Acceptance 체크리스트 충족 | 🟡 | 자동 게이트 통과, 확장 수동 로드만 남음 |

## 다음 task 연결

- 스켈레톤 완료 후 [06 Phase 2](../spec/06-development-roadmap-tasks.md#L53) Agent bridge transport부터
  실제 동작 구현으로 이어진다.
