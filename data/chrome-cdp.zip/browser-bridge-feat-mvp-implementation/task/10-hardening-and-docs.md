# 10. Hardening And Docs

dogfooding 준비 단계: E2E 테스트와 설치/문서/프라이버시/한계 문서.

- 대응 로드맵: [06 Phase 10](../spec/06-development-roadmap-tasks.md#L244)
- 품질 게이트: [07-test-and-quality-gates.md](../spec/07-test-and-quality-gates.md)

## 목표

- E2E 테스트(실 loopback 소켓으로 adapter↔bridge 전체 흐름)
- 확장/네이티브 호스트 설치 문서, 트러블슈팅, 알려진 한계, 프라이버시, 위협 모델
- 루트 README로 신규 개발자가 MVP 실행 가능
- adapter/native-host 실행 진입점(CLI)

## 변경/추가 파일

- `tests/e2e.test.ts`: DevWsServer(adapter) ↔ ws로 연결된 실제 Bridge(fake 포트). start_session→new_page→take_snapshot→click→take_screenshot→list_console→end_session + 멀티세션.
- `packages/agent-adapter/src/cli.ts`, `packages/native-host/src/cli.ts`: 실행 진입점.
- `README.md`(루트): 퀵스타트.
- `docs/install-extension.md`, `docs/install-native-host.md`, `docs/troubleshooting.md`, `docs/known-limitations.md`, `docs/privacy.md`, `docs/threat-model.md`.

## 완료 기준 (Acceptance)

[06 Phase 10](../spec/06-development-roadmap-tasks.md#L258) 기준:

- [x] 테스트가 확장 bridge 기본을 커버한다 (E2E + bridge 단위)
- [x] 멀티에이전트·멀티세션 기본을 커버한다 (session-tools + E2E 멀티세션)
- [x] 세션 탭 그룹 수명을 커버한다 (materialized→closed)
- [x] adapter/native messaging 기본을 커버한다 (ws E2E + native-host/framing)
- [x] 보안 정책이 문서화되어 있다 (spec/02 + docs/threat-model)
- [x] 설정 실패 메시지가 actionable하다 (troubleshooting + 진단 메시지)
- [x] 프라이버시 민감 동작이 문서화되어 있다 (docs/privacy)
- [x] 신규 개발자가 README로 MVP를 실행할 수 있다 (루트 README 퀵스타트)

### 추가 자동 검증
- [x] `pnpm typecheck` / `test`(125) / `build` / `lint` 통과

## 구현 현황

상태 범례: ⬜ 미착수 · 🟡 진행중 · ✅ 완료

| # | 항목 | 산출물 | 상태 | 비고 |
| --- | --- | --- | --- | --- |
| 1 | E2E 테스트 | `tests/e2e.test.ts` | ✅ | 실소켓 풀 플로우 + 멀티세션 |
| 2 | CLI 진입점 | adapter/native-host `cli.ts` | ✅ | |
| 3 | 루트 README | `README.md` | ✅ | 퀵스타트 |
| 4 | 설치 문서 | `docs/install-extension.md`/`install-native-host.md` | ✅ | |
| 5 | 트러블슈팅/한계/프라이버시 | `docs/troubleshooting.md`/`known-limitations.md`/`privacy.md` | ✅ | |
| 6 | 위협 모델 | `docs/threat-model.md` | ✅ | spec/02 연계 |
| 7 | 자동 게이트 | typecheck/test/build/lint | ✅ | 125 passed |
| 8 | 수동 확인 | README대로 MVP 실행 (브라우저) | ⬜ | 수동 확인 필요 |

## MVP 완료

Phase 0~10 완료 시 [spec/README §MVP 완료 기준](../spec/README.md) 충족.
