# 11. Post-MVP Enhancements

Phase 0~10(MVP) 이후, 레퍼런스(chrome-devtools-mcp, codex control-chrome skill)
검토를 반영한 추가 작업과 "Codex식 자동 연결" UX 정리. 모든 자동 게이트 통과 유지.

- 레퍼런스: [reference/guide.md](../reference/guide.md), [reference/codex-control-chrome-skill.md](../reference/codex-control-chrome-skill.md)

## 1) codex/devtools 패리티 도구 추가

| 추가 도구 | 매핑 | 위치 |
| --- | --- | --- |
| `browser.list_tabs` | codex `openTabs()` / devtools `list_pages` | bridge + PageManager.listUserTabs + TabsPort.listTabs |
| `browser.claim_tab { strategy:"by-id", tabId }` | codex `claimTab(tab)` | PageManager.claimTab(tabId) |
| `browser.navigate { url, reload }` | codex `goto`/`reload` / devtools `navigate_page` | PageManager.navigate (snapshot 무효화) |

- 스키마/타입: `claimTabSchema`(tabId), `navigateSchema`, `TabSummary`/`NavigateInput`.
- 테스트: `tests/tab-tools.test.ts` (list/claim-by-id/navigate/도메인 정책/reload).
- spec/03에 세 도구 문서화.

## 2) 외부 프로그램 연결 (native host 릴레이)

- `native-host/agent-relay.ts`: 호스트가 `127.0.0.1:18480`에 loopback WS를 열어 **외부
  에이전트 프로그램**이 raw JSON tool 요청으로 접속 → 호스트가 확장으로 중계.
- `startNativeHost`가 stdio(확장) + 릴레이(외부) 동시 기동.
- `native-host/install.ts`: 매니페스트 + 런처 자동 설치 CLI (`node dist/install.js <ext-id>`).
- 테스트: `tests/agent-relay.test.ts`.

## 3) Codex식 자동 연결 (사용자 무작업)

- 구조: **에이전트 앱 = 서버, 확장 = 클라이언트**(MV3는 서버 불가). 앱 엔드포인트가
  떠 있으면 Chrome 켜질 때/주기적으로 확장이 자동 접속.
- 확장 강화(`service-worker.ts`): `onStartup` 연결, **재연결 alarm(~30s)**로 미연결 시
  재접속, 멱등 supervisor, WS 백오프, native 우선 → WS(18470) 폴백.
- 문서: [docs/auto-connect.md](../docs/auto-connect.md), [docs/connect-without-host.md](../docs/connect-without-host.md).

## 4) 수동 확인 + 예제

- `agent-adapter/demo.ts` (`pnpm demo`): 확장 연결 시 세션/탭그룹/snapshot/screenshot/
  navigate 자동 시연.
- `examples/agent.mjs`: "내 프로그램이 서버" 최소 예제(매니페스트 없이).
- [docs/manual-verification.md](../docs/manual-verification.md).

## 5) 문서 정리

- 루트 `README.md` 갱신(연결 방식 3종, 문서 색인).
- `docs/`: protocol(통신 규약), agent-usage(활용), auto-connect, connect-without-host,
  install-extension/native-host, manual-verification, troubleshooting, known-limitations,
  privacy, threat-model.

## 검증

- `pnpm typecheck` / `test`(132) / `build` / `lint` 통과.

## 남은 후속 (의도적)

- MCP stdio로 tool **실행**까지 잇는 브리지(현재 외부 연동은 릴레이 JSON).
- 탭 move/ungroup/window-move 정밀 reconcile.
- `evaluate_script`, 어댑터 파일 아티팩트 저장.
- 절대적 상시 가동이 필요하면 별도 브로커 데몬(launchd 상주).
