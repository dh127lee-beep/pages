# 02. Agent Bridge Transport

스켈레톤([01-skeleton-code.md](01-skeleton-code.md)) 위에서, 로컬 에이전트가
확장에 **직접 연결**되도록 transport 계층을 구현하는 단계의 세부 계획과 구현
현황 문서다.

- 대응 로드맵: [06-development-roadmap-tasks.md](../spec/06-development-roadmap-tasks.md) **Phase 2 (Agent bridge transport)**
- transport 근거: [04 §Agent connection transports](../spec/04-extension-backend.md#L83), [05 §Local WebSocket development path](../spec/05-local-bridge-and-cdp-backend.md#L88)
- 프로토콜: [03 §Protocol shape](../spec/03-protocol-and-mcp-tools.md), [03 §browser.get_capabilities](../spec/03-protocol-and-mcp-tools.md#L110)
- 레퍼런스 패턴: [reference/guide.md §3 (Phase 2에 바로 적용할 것)](../reference/guide.md)

## ⚠️ pairing 정책 결정 (spec divergence)

이 task는 **pairing 토큰/사용자 동의 없이 자동 연결**로 진행한다. 확장이 떠 있고
adapter가 떠 있으면 곧바로 연결되어 명령을 수락한다.

- 이는 [02 §Session and tab group safeguards](../spec/02-security-permissions.md#L114)의
  "pairing 세션을 켜기 전엔 bridge 비활성" 규칙과 **상충**한다.
  spec/02는 추후 이 결정에 맞춰 갱신 대상이다. (→ 별도 정리 필요)
- **위험**: 임의의 로컬 프로세스가 adapter인 척 붙으면 로그인된 브라우저를 무단
  제어할 수 있다. 사용자에게 제어 중임을 알리는 동의 단계가 없다.
- **유지하는 최소 안전선** (UX 마찰 0, pairing 아님):
  - adapter WS는 `127.0.0.1` 루프백에만 바인딩 (외부 네트워크 미노출).
  - 웹 페이지發 명령(`window.postMessage`)은 절대 수락하지 않는다.

## 목표

확장과 adapter가 뜨면 자동으로 연결되고, 에이전트가 `browser.get_capabilities`
까지 왕복하는 것.

- 확장 protocol envelope 송수신 구현 (요청/응답 라우팅, 메시지 id 매칭, 타임아웃)
- 개발용 localhost WebSocket **클라이언트(확장 측)** — 확장이 연결을 개시
- adapter 측 WebSocket **엔드포인트** (skeleton의 `DevWsServer` 채우기)
- client identity + 버전 핸드셰이크 (토큰 검증 없음, clientName만 식별용)
- heartbeat / disconnect 감지와 UI 반영
- `browser.get_capabilities` 실제 응답

## 비목표 (이 task 범위 밖)

- 세션/탭 그룹 생성 동작 → Phase 3 (다음 task)
- 페이지 lease·snapshot·action → Phase 4~6
- Native Messaging 프로덕션 경로 → Phase 8 (이번엔 dev WebSocket만)
- MCP 어댑터 tool 노출 동작 → Phase 8 근처 (이번엔 transport 골격까지)
- pairing 토큰/사용자 동의 플로우 → 의도적으로 제외 (위 결정)
- 에이전트 로직 자체 → 제품 비목표

## 연결 모델 (요약)

```text
Agent ──stdio/MCP──▶ Agent Adapter ──ws(127.0.0.1, 고정 포트 18470)──▶ Extension SW
```

- 확장이 연결을 **개시**한다 (확장은 로컬 HTTP 서버를 열지 않는다 — [02 §144](../spec/02-security-permissions.md#L144)).
- adapter가 `127.0.0.1`에 WS 엔드포인트를 띄운다.
- ⚠️ **포트 탐색 정정**: MV3 service worker는 **파일시스템 접근이 없어** 포트파일
  (`~/.browser-bridge/ws-port`)을 직접 읽을 수 없다. 따라서 확장은 **고정/설정 포트**
  (기본 `18470`, options에서 변경)로 접속한다. 포트파일은 adapter 측 **진단용**으로만 기록한다.
- 토큰/동의 없이 즉시 연결. 핸드셰이크는 식별·버전 협상 용도만.
- 웹 페이지로부터의 명령은 절대 수락하지 않는다.

## 설계 포인트

### 자동 연결
- 확장 SW 시작 시 고정/설정 포트(기본 `18470`)로 adapter에 접속 시도. (SW는 FS 접근이
  없어 포트파일을 읽지 못함 — 위 정정 참고.)
- 연결 실패 시 backoff 재시도(1s→최대 30s). 성공하면 `ConnectionState.status='connected'`.
- 사용자 조작 없음. popup은 상태 **표시 전용**.

### 핸드셰이크 (토큰 없음)
1. 확장 → adapter: `bridge.hello { protocolVersion, extensionVersion }`
2. adapter → 확장: `bridge.identify { clientName, clientVersion }`
3. 확장: `connectionId` 발급, `ConnectionState`에 client 추가
4. 버전 불일치 → 명확한 진단 코드 반환 (`TRANSPORT_UNAVAILABLE` 등)

### envelope 라우팅 (reference/guide.md §3)
- 요청마다 `id` 부여, 응답을 pending map과 매칭 (`05 §Transport message routing`).
- per-message timeout은 `AbortController` + `Promise.race(timeout)` 패턴
  (chrome-devtools-mcp `WaitForHelper` 차용). 미매칭/만료 응답은 거부.
- control 메시지(hello/identify/ping)도 zod **공유 스키마 조각**으로 검증
  ([03 §Tool definition conventions](../spec/03-protocol-and-mcp-tools.md)). 단 **토큰 필드 없음**.
- 응답은 빌더 패턴으로 조립해 `{ ok, result, warnings, auditId }`에 warnings를 누적.
- 에러는 [03 §Error codes](../spec/03-protocol-and-mcp-tools.md#L462)로 정규화하되 **self-healing 톤**
  (원인 + 다음 행동): `TRANSPORT_UNAVAILABLE`(버전 불일치), `EXTENSION_NOT_CONNECTED`, `ACTION_TIMEOUT` 등.

### get_capabilities
- 지원 backend 목록 + 권한 가용성 + protocol/extension 버전. **시크릿/크리덴셜 비노출**
  ([03 §get_capabilities](../spec/03-protocol-and-mcp-tools.md#L110)).

### heartbeat
- 주기적 ping/pong 또는 idle timeout. 끊기면 `status='disconnected'` + 재연결 backoff.
- popup에는 내부 용어 없이 연결/재연결 상태만 자연스럽게 노출 (Codex skill §2.4).

## 변경/추가 파일

### shared-protocol (`packages/shared-protocol/src`) — 구현됨
- `control.ts` (신규): `bridge.hello/identify/welcome/reject/ping/pong` 타입 + `isProtocolCompatible` (토큰 필드 없음).
- `rpc.ts` (신규): `RpcClient` — id 매칭 pending map + per-message timeout + `rejectAll`.
- `envelopes.ts`: `TransportResponse` + `makeResponse` + `isTransportResponse`.
- `schemas.ts`: control 메시지 zod discriminated union.

### extension (`packages/extension/src`) — 구현됨
- `bridge/transport.ts` (신규): `WebSocketTransport` — 확장이 adapter WS에 자동 접속, 재연결 backoff.
- `bridge/connection-session.ts` (신규): transport-agnostic 핸드셰이크/디스패치 상태머신 (테스트 대상).
- `bridge/discovery.ts` (신규): 고정/설정 포트(기본 18470) 반환. **포트파일 안 읽음**(SW FS 불가).
- `background/bridge.ts`: `get_capabilities` 실제 응답, 미구현 tool은 `UNSUPPORTED_ACTION`.
- `background/capabilities.ts` (신규): `CapabilitiesProvider` 인터페이스 + chrome 구현(주입형 → 테스트 가능).
- `background/connection-registry.ts` (신규): connectionId ↔ client 매핑 + onChange.
- `service-worker.ts`: transport 자동 부트스트랩 + connection state 발행.
- `options`: 기본 포트 18470.

### agent-adapter (`packages/agent-adapter/src`) — 구현됨
- `ws-server.ts`: `DevWsServer` — `127.0.0.1` 바인딩, 핸드셰이크, `RpcClient`로 tool 요청, 진단용 포트파일.
- `index.ts`: `startAdapter()` 실제 기동 + 포트파일 기록.
- 의존성: `ws` 추가 (루트 devDep에도 추가 — 통합 테스트용).

## 완료 기준 (Acceptance)

[06 Phase 2](../spec/06-development-roadmap-tasks.md#L67) 기준 (pairing 관련 항목은 자동 연결로 대체):

- [x] 확장과 adapter가 뜨면 **자동으로** 연결된다 (통합 테스트로 핸드셰이크 왕복 검증)
- [x] 여러 에이전트가 서로 다른 clientName으로 연결된다 (registry/identify)
- [x] popup이 연결된 client 이름을 표시한다 (connection-state 발행)
- [x] disconnect가 확장 UI에 반영되고 재연결된다 (backoff 재연결, onClose 처리)
- [x] adapter WS가 `127.0.0.1`에만 바인딩된다 (DevWsServer host 기본값)
- [x] 웹 페이지發 명령은 거부된다 (확장은 WS 클라이언트, postMessage 미수신)
- [x] `get_capabilities`가 protocol/extension 버전과 권한 상태를 반환한다

### 추가 자동 검증
- [x] `pnpm typecheck` / `pnpm test`(28) / `pnpm build` / `pnpm lint` 통과
- [x] transport 라우팅 단위테스트 (id 매칭, timeout, 미매칭 응답 거부, rejectAll)
- [x] 핸드셰이크/버전협상 단위테스트 + 실소켓 통합 테스트

## 구현 현황

상태 범례: ⬜ 미착수 · 🟡 진행중 · ✅ 완료

| # | 항목 | 산출물 | 상태 | 비고 |
| --- | --- | --- | --- | --- |
| 1 | control 메시지 타입/스키마 | shared-protocol `control.ts`/`schemas.ts` | ✅ | hello/identify/welcome/ping, 토큰 없음 |
| 2 | RPC 라우팅 코어 | shared-protocol `rpc.ts` + `envelopes`(TransportResponse) | ✅ | id 매칭 + timeout + rejectAll |
| 3 | adapter 엔드포인트 탐색 | extension `bridge/discovery.ts` | ✅ | 고정/설정 포트(18470), FS 안 읽음 |
| 4 | 확장 WS transport (자동연결) | extension `bridge/transport.ts` | ✅ | 재연결 backoff |
| 5 | 핸드셰이크/디스패치 상태머신 | extension `bridge/connection-session.ts` | ✅ | transport-agnostic, 테스트됨 |
| 6 | connection registry | extension `background/connection-registry.ts` | ✅ | onChange |
| 7 | bridge get_capabilities | extension `background/bridge.ts` + `capabilities.ts` | ✅ | caps 주입형 |
| 8 | 연결 상태 UI/발행 | extension `service-worker.ts` + `popup` | ✅ | 표시 전용 |
| 9 | adapter WS 서버 | agent-adapter `ws-server.ts` | ✅ | `ws`, 127.0.0.1, RpcClient |
| 10 | adapter 기동/포트파일 | agent-adapter `index.ts` | ✅ | 진단용 포트파일 |
| 11 | 단위/통합 테스트 | `tests/` (rpc/session/capabilities/integration) | ✅ | 28 passed |
| 12 | 자동 게이트 | typecheck/test/build/lint | ✅ | 전부 통과 |
| 13 | 수동 연결 확인 | adapter↔확장 자동 왕복 (브라우저) | ⬜ | 수동 확인 필요 |

## 다음 task 연결

- 완료 후 [06 Phase 3](../spec/06-development-roadmap-tasks.md#L77) **Session manager and tab groups**
  (`browser.start_session`/`list_sessions` + 세션별 Chrome tab group)로 이어진다.
- spec/02의 pairing 규칙은 자동 연결 정책으로 이미 갱신 완료(spec 전반 반영).
