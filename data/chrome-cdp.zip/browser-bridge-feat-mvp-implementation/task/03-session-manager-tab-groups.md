# 03. Session Manager And Tab Groups

Phase 2(transport) 위에서 **세션을 1차 작업 단위로** 만들고, 각 세션에 Chrome
tab group 메타데이터를 부여하는 단계의 세부 계획과 구현 현황 문서다.

- 대응 로드맵: [06 Phase 3](../spec/06-development-roadmap-tasks.md#L77)
- 세션 모델: [01 §Session model](../spec/01-architecture.md#L187), [01 §Tab group lifecycle](../spec/01-architecture.md#L244)
- 세션 tool 계약: [03 §Agent tools](../spec/03-protocol-and-mcp-tools.md)
- 안전 규칙: [02 §Session and tab group safeguards](../spec/02-security-permissions.md)
- 레퍼런스: [reference/guide.md §4 (P3: Codex finalize/keep, Mutex)](../reference/guide.md)

## 목표

연결된 에이전트가 세션을 만들고 조회/일시정지/재개/종료할 수 있다. 각 세션은
논리적 tab group 메타데이터(제목/색/상태)를 가지며, SW 재시작 후에도 복원된다.

- `browser.start_session` / `list_sessions` / `get_session` / `pause_session` /
  `resume_session` / `end_session`
- 세션 상태 저장 (`chrome.storage.session`) + SW 재시작 reconcile
- 세션 tab group 메타데이터: 제목·색 결정적 할당, 상태(logical)
- 멀티 에이전트·멀티 세션 동시 소유, agent별 격리

## 비목표 (이 task 범위 밖)

- 실제 Chrome 탭 생성/그룹 materialize → Phase 4 (`new_page`/`claim_tab`)
- 페이지 lease·snapshot·action → Phase 4~6
- agent 재연결 resume(동일 identity로 세션 인수) 심화 → Phase 9

## 식별·소유권 모델

토큰이 없으므로(자동 연결) **clientName에서 결정적으로 agentId를 파생**한다
(`agentIdFromClientName`). 세션은 agentId로 소유·격리되고, connectionId는 ephemeral
(재연결마다 새로 발급)이다.

- 같은 clientName으로 (재)연결하면 같은 agentId → SW 재시작 후 세션 reconcile.
- 핸드셰이크 완료(welcome) 후 tool 메시지에 `ToolContext { agentId, connectionId, clientName }`를 실어 ownership 검증.

## 상태 모델 결정 (minor deviation)

spec/01은 "세션이 pending으로 시작, 첫 탭에서 tab group materialize"라고 적지만,
구현에서는 **세션 status와 tab group state를 분리**한다:

- `status`: 명령 수락 가능 여부 — start 시 `active`로 생성. `paused`/`finalized` 전이.
- `tabGroup.state`: `logical`(아직 그룹 없음) → Phase 4에서 `materialized`.

즉 "탭 그룹 없음" 신호는 `tabGroup.state==='logical'`이 담당하고, `status`는 명령
수락 게이트만 담당한다. (`pending`은 enum에 남겨두되 사용하지 않는다.)

## 설계 포인트

- **SessionManager**: in-memory Map가 작업 사본, 변경 시 `SessionStore`로 write-through,
  boot 시 `hydrate()`로 복원. 시계(`now`)·저장소 주입형 → 테스트 가능.
- **tab group 계획**: `planTabGroup({clientName, sessionLabel, seed})` 순수 함수.
  제목 `BB · <client> · <label|shortId>`, 색은 seed 해시로 Chrome 9색 중 결정적 선택.
- **ownership 게이트**: `resolveOwned(ctx, sessionId)` + `requireActive(record)`
  (paused→`SESSION_PAUSED`, finalized→`SESSION_FINALIZED`). Phase 4 page action이 재사용.
- **직렬화**: per-session/per-group 변경은 작은 FIFO mutex로([01 §Concurrency](../spec/01-architecture.md#L264)). Phase 3에선 상태 전이만이라 경합 적음 — 훅만 마련.

## 변경/추가 파일

### shared-protocol
- `ids.ts`: `agentIdFromClientName(clientName): AgentId` (결정적, 무작위 아님).
- `tools.ts`: `SessionSummary` / `SessionDetail` / `SessionTabGroupInfo` 결과 타입.

### extension
- `background/context.ts` (신규): `ToolContext`.
- `background/session-manager.ts`: 레코드/스토어/시계 기반으로 재작성 (create/list/get/setStatus/remove/hydrate).
- `background/session-store.ts` (신규): `SessionStore` 인터페이스 + `ChromeSessionStore`(chrome.storage.session).
- `background/tab-group-manager.ts`: `planTabGroup` 순수 함수 추가 (materialize 등은 Phase 4 stub 유지).
- `background/bridge.ts`: 세션 6개 tool + ownership 게이트 + ctx 사용.
- `bridge/connection-session.ts`: welcome 후 `ToolContext` 구성, `handleTool(message, ctx)`.
- `bridge/transport.ts`: `handleTool` 시그니처 변경.
- `service-worker.ts`: SessionManager(chrome store) 생성·hydrate, ctx 전달.

## 완료 기준 (Acceptance)

[06 Phase 3](../spec/06-development-roadmap-tasks.md#L94) 기준:

- [x] 한 에이전트가 여러 세션을 만들 수 있다
- [x] 여러 에이전트가 동시에 active 세션을 소유한다 (agentId 격리)
- [x] 각 세션이 논리적 tab group 메타데이터(제목/색/state=logical)를 가진다
- [~] (Phase 4) 첫 탭 생성/claim 시 그룹 materialize — 이번엔 logical까지만 (의도적 보류)
- [x] popup이 active 세션 수/상태를 보여준다 (finalized 제외 카운트)
- [x] paused 세션은 page action을 거부한다 (`requireActive` 게이트 단위테스트)
- [x] SW 재시작 후 세션이 복원된다 (store hydrate 테스트)

### 추가 자동 검증
- [x] `pnpm typecheck` / `test`(42) / `build` / `lint` 통과
- [x] SessionManager 단위테스트 (create/list 격리/persist/hydrate)
- [x] 세션 tool 단위테스트 (start/list/get/pause/resume/end + ownership + 게이트)

## 구현 현황

상태 범례: ⬜ 미착수 · 🟡 진행중 · ✅ 완료

| # | 항목 | 산출물 | 상태 | 비고 |
| --- | --- | --- | --- | --- |
| 1 | agentId 파생 | shared-protocol `ids.ts` | ✅ | `agentIdFromClientName` 결정적 |
| 2 | 세션 결과 타입 | shared-protocol `tools.ts` | ✅ | Summary/Detail/TabGroupInfo |
| 3 | ToolContext | extension `background/context.ts` | ✅ | |
| 4 | SessionManager | extension `background/session-manager.ts` | ✅ | store/clock 주입, write-through |
| 5 | SessionStore | extension `background/session-store.ts` | ✅ | ChromeSessionStore |
| 6 | planTabGroup | extension `background/tab-group-manager.ts` | ✅ | 제목/색 결정적(9색 해시) |
| 7 | 세션 tool + 게이트 | extension `background/bridge.ts` | ✅ | 6 tools + resolveOwned/requireActive |
| 8 | ctx 스레딩 | `connection-session.ts`/`transport.ts`/`service-worker.ts` | ✅ | welcome 후 ToolContext |
| 9 | SessionManager 테스트 | `tests/session-manager.test.ts` | ✅ | 격리/persist/hydrate |
| 10 | 세션 tool 테스트 | `tests/session-tools.test.ts` | ✅ | 8 tests + ownership/게이트 |
| 11 | 자동 게이트 | typecheck/test/build/lint | ✅ | 42 passed |
| 12 | 수동 확인 | popup 세션 표시 (브라우저) | ⬜ | 수동 확인 필요 |

## 다음 task 연결

- 완료 후 [06 Phase 4](../spec/06-development-roadmap-tasks.md#L103) **Page leases and tab lifecycle**
  (`new_page`/`claim_tab`/`release_tab` + tab group materialize)로 이어진다.
