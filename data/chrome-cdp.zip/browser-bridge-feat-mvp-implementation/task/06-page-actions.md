# 06. Extension Page Actions

Phase 5(snapshot) 위에서 **행동**(act)을 구현하는 단계의 세부 계획과 구현 현황.

- 대응 로드맵: [06 Phase 6](../spec/06-development-roadmap-tasks.md#L150)
- tool 계약: [03 §click/fill/.../wait_for](../spec/03-protocol-and-mcp-tools.md#L331)
- 동시성: [01 §Concurrency rules](../spec/01-architecture.md#L264)
- 레퍼런스: [reference/guide.md §1.4 WaitForHelper, §1.5 Mutex](../reference/guide.md)

## 목표

- `click`/`fill`/`fill_form`/`press_key`/`scroll`/`wait_for`
- snapshot uid 대상, **stale snapshot 거부**(`SNAPSHOT_STALE`)
- **per-page 직렬화**(작은 FIFO Mutex)
- 위험 대상 risk hint 반환, Enter-in-form은 submit 힌트
- 액션 후 `includeSnapshot` 옵션, 결과에 url/title/navigation

## 테스트 전략

- **Mutex**(pure): 직렬화 단위테스트.
- **ActionManager**: `ContentMessenger` 주입 → stale 거부/직렬화/includeSnapshot 테스트.
- content script DOM 수행부는 얇음(테스트 제외); risk/stale/직렬화 로직은 background에서 테스트.

## 설계 포인트

- ActionManager: (1) stale 검증(`pages.isSnapshotCurrent`, `allowStale` 예외) → (2) per-page Mutex acquire → (3) content script에 액션 메시지 → (4) `includeSnapshot`시 후속 snapshot → release.
- content script: `idToEntry: uid→{el, riskHints}` (최근 snapshot 기준). uid 없으면 `ELEMENT_NOT_FOUND`.
- press_key Enter가 form 필드 위면 결과 riskHints에 `submit`.
- 액션 후 짧은 DOM settle 대기(WaitForHelper 축약) 후 url/title 반환, navigation 감지(best-effort).

## 변경/추가 파일

### shared-protocol
- `mutex.ts` (신규): `Mutex` (acquire→release).
- `tools.ts`: `ActionResult` 타입.

### extension
- `background/action-manager.ts` (신규): stale+mutex+dispatch+includeSnapshot.
- `content/content-script.ts`: 액션 핸들러 + idToEntry.
- `background/bridge.ts`: 6개 액션 tool.
- `service-worker.ts`: ActionManager 배선.

## 완료 기준 (Acceptance)

[06 Phase 6](../spec/06-development-roadmap-tasks.md#L166) 기준:

- [x] page action은 sessionId+pageId 일치를 요구한다 (resolveOwnedPage)
- [x] click이 최신 snapshot uid에 동작한다
- [x] fill이 text input uid에 동작한다
- [x] form 안의 Enter가 submit-유사 risk hint로 분류된다 (content script)
- [x] stale uid는 `SNAPSHOT_STALE`/`ELEMENT_NOT_FOUND`를 반환한다
- [x] 위험 대상은 risk hint를 반환한다 (snapshot riskHints 전달)
- [x] 결과에 url/title/navigation 변화가 가능 시 포함된다
- [x] 같은 page 명령은 직렬화된다 (per-page Mutex)

### 추가 자동 검증
- [x] `pnpm typecheck` / `test`(88) / `build` / `lint` 통과
- [x] Mutex 단위테스트
- [x] ActionManager 단위테스트(stale/직렬화/includeSnapshot/에러매핑)
- [x] action tool 단위테스트(소유권/gate/stale)

## 구현 현황

상태 범례: ⬜ 미착수 · 🟡 진행중 · ✅ 완료

| # | 항목 | 산출물 | 상태 | 비고 |
| --- | --- | --- | --- | --- |
| 1 | Mutex | shared-protocol `mutex.ts` | ✅ | FIFO |
| 2 | ActionResult 타입 | shared-protocol `tools.ts` | ✅ | |
| 3 | ActionManager | extension `background/action-manager.ts` | ✅ | stale+mutex+includeSnapshot |
| 4 | content 액션 핸들러 | extension `content/content-script.ts` | ✅ | idToEntry, settle |
| 5 | bridge 액션 tool | extension `background/bridge.ts` | ✅ | click/fill/fill_form/press_key/scroll/wait_for |
| 6 | SW 배선 | extension `service-worker.ts` | ✅ | 공유 messenger |
| 7 | Mutex 테스트 | `tests/mutex.test.ts` | ✅ | |
| 8 | ActionManager 테스트 | `tests/action-manager.test.ts` | ✅ | 5 tests |
| 9 | action tool 테스트 | `tests/action-tools.test.ts` | ✅ | 7 tests |
| 10 | 자동 게이트 | typecheck/test/build/lint | ✅ | 88 passed |
| 11 | 수동 확인 | 실제 click/fill (브라우저) | ⬜ | 수동 확인 필요 |

## 다음 task 연결

- 완료 후 [06 Phase 7](../spec/06-development-roadmap-tasks.md#L176) **Debugger read/action tools**로 이어진다.
