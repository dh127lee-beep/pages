# 05. Snapshot And Artifact Tools

Phase 4(page lease) 위에서 **행동 전 관찰**(observe)을 구현하는 단계의 세부 계획과
구현 현황 문서다.

- 대응 로드맵: [06 Phase 5](../spec/06-development-roadmap-tasks.md#L126)
- snapshot 계약: [03 §Snapshot contract](../spec/03-protocol-and-mcp-tools.md), [04 §Element uid mapping](../spec/04-extension-backend.md)
- redaction: [02 §Redaction](../spec/02-security-permissions.md)
- 레퍼런스: [reference/guide.md §1.3 TextSnapshot, §1.1 Reference over Value](../reference/guide.md)

## 목표

- leased 탭에 content script 주입 후 `browser.take_snapshot` — a11y 우선 normalize,
  snapshot-local uid, redaction(password/hidden), risk hints(submit/upload/payment).
- `browser.take_screenshot` — visible 캡처를 artifact로 저장(메타데이터 반환, raw 비포함).
- stale snapshot 감지 기반(page.latestSnapshotId).

## 테스트 전략

- **buildSnapshot**(pure): RawElement[] → Snapshot(uid/redaction/risk/필터). DOM 없이 단위테스트.
- **dom-extract**(DOM): content script에서 DOM→RawElement. 얇음, 테스트 제외.
- **SnapshotManager**: `ContentMessenger` 주입 → fake로 테스트.
- **ArtifactRegistry/decodeDataUrl**(pure), **ScreenshotManager**: `ScreenshotPort` 주입 → fake로 테스트.

## 설계 포인트

- uid = `${snapshotId}_${i}` (kept 요소 순서). content script가 uid→Element 맵 보관(Phase 6 액션용).
- redaction: password/payment-risk 필드는 `valueRedacted=true`(value 미포함). hidden 요소는 제외(includeHidden시 포함, value 미노출).
- risk hints: input[type=submit]/button submit, file→upload, password, name/autocomplete의 card/cc/payment→payment.
- screenshot: `chrome.tabs.captureVisibleTab`(visible 한정 — 배경 탭은 Phase 7 debugger). raw 바이너리는 응답에 넣지 않고 ArtifactRegistry에 저장 후 메타데이터 반환.
- snapshot 후 `page.latestSnapshotId` 기록 → Phase 6 click/fill의 stale 검증 기반.

## 변경/추가 파일

### shared-protocol
- `tools.ts`: `ElementBounds`/`SnapshotElement`/`Snapshot`/`ArtifactMetadata` + snapshot/screenshot 입력 타입.

### extension
- `content/snapshot-builder.ts` (신규, pure): `buildSnapshot`/`computeRiskHints`.
- `content/dom-extract.ts` (신규, DOM): `extractRawElements`.
- `content/content-script.ts`: 영속 핸들러(snapshot 메시지 → buildSnapshot → uid→node 맵 보관).
- `background/snapshot-manager.ts` (신규): `ContentMessenger` + `ChromeContentMessenger` + `SnapshotManager`.
- `background/artifacts.ts` (신규): `ArtifactRegistry` + `decodeDataUrl`.
- `background/screenshot-manager.ts` (신규): `ScreenshotPort` + `ChromeScreenshotPort` + `ScreenshotManager`.
- `background/page-manager.ts`: `latestSnapshotId` + `setLatestSnapshot`/`isSnapshotCurrent`.
- `background/bridge.ts`: `take_snapshot`/`take_screenshot` + `resolveOwnedPage`.
- `service-worker.ts`: 매니저 배선.

## 완료 기준 (Acceptance)

[06 Phase 5](../spec/06-development-roadmap-tasks.md#L140) 기준:

- [x] snapshot이 사용 가능한 요소 목록을 반환한다
- [x] password 필드 값이 redaction된다 (`valueRedacted`)
- [x] hidden input 값이 반환되지 않는다 (기본 제외, includeHidden시도 value 미노출)
- [x] screenshot이 artifact id/메타데이터를 반환한다
- [x] artifact가 session/page/tab group 메타데이터를 포함한다
- [x] 큰 바이너리가 tool 응답에 포함되지 않는다 (registry 저장, 메타데이터만)
- [x] stale snapshot id가 감지 가능하다 (`page.latestSnapshotId`/`isSnapshotCurrent`)

### 추가 자동 검증
- [x] `pnpm typecheck` / `test`(75) / `build` / `lint` 통과
- [x] buildSnapshot 단위테스트(redaction/risk/필터/uid/truncate)
- [x] SnapshotManager/ScreenshotManager/ArtifactRegistry 단위테스트
- [x] snapshot/screenshot tool 단위테스트(소유권/gate)

## 구현 현황

상태 범례: ⬜ 미착수 · 🟡 진행중 · ✅ 완료

| # | 항목 | 산출물 | 상태 | 비고 |
| --- | --- | --- | --- | --- |
| 1 | snapshot/artifact 타입 | shared-protocol `tools.ts` | ✅ | Snapshot/Element/ArtifactMetadata |
| 2 | buildSnapshot (pure) | extension `content/snapshot-builder.ts` | ✅ | redaction/risk/uid/truncate |
| 3 | dom-extract (DOM) | extension `content/dom-extract.ts` | ✅ | a11y name/role/bounds |
| 4 | content script 핸들러 | extension `content/content-script.ts` | ✅ | uid→node 맵 보관 |
| 5 | SnapshotManager | extension `background/snapshot-manager.ts` | ✅ | ContentMessenger 주입 |
| 6 | ArtifactRegistry+decode | extension `background/artifacts.ts` | ✅ | pure, 테스트됨 |
| 7 | ScreenshotManager | extension `background/screenshot-manager.ts` | ✅ | ScreenshotPort 주입 |
| 8 | PageManager latestSnapshot | extension `background/page-manager.ts` | ✅ | isSnapshotCurrent |
| 9 | bridge snapshot/screenshot | extension `background/bridge.ts` | ✅ | resolveOwnedPage |
| 10 | SW 배선 | extension `service-worker.ts` | ✅ | 매니저 4종 |
| 11 | 테스트 | `tests/` (builder/artifacts/managers/tools) | ✅ | +16 tests |
| 12 | 자동 게이트 | typecheck/test/build/lint | ✅ | 75 passed |
| 13 | 수동 확인 | 실제 snapshot/screenshot (브라우저) | ⬜ | 수동 확인 필요 |

## 다음 task 연결

- 완료 후 [06 Phase 6](../spec/06-development-roadmap-tasks.md#L150) **Extension page actions**(click/fill/scroll/...)로 이어진다.
