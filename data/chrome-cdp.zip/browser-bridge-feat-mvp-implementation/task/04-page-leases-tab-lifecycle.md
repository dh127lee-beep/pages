# 04. Page Leases And Tab Lifecycle

Phase 3(세션/탭그룹 메타데이터) 위에서, 각 세션에 **실제 Chrome 탭 surface**를
부여하는 단계의 세부 계획과 구현 현황 문서다.

- 대응 로드맵: [06 Phase 4](../spec/06-development-roadmap-tasks.md#L103)
- page 모델: [01 §Page model](../spec/01-architecture.md#L224), [01 §Tab group lifecycle](../spec/01-architecture.md#L244)
- tool 계약: [03 §new_page/claim_tab/release_tab](../spec/03-protocol-and-mcp-tools.md#L221)
- 안전 규칙: [02 §Session and tab group safeguards](../spec/02-security-permissions.md)
- 레퍼런스: [reference/guide.md §2.1 (claim/finalize), §4 P4](../reference/guide.md)

## 목표

세션이 탭을 열고(claim) 소유하며, 세션의 Chrome tab group이 실제로 materialize된다.

- `browser.new_page` (chrome.tabs.create) → 세션 그룹에 편입
- `browser.claim_tab` (active 탭 claim, scope 정책, 그룹 이동/보존)
- `browser.release_tab` (lease 해제, 탭은 닫지 않음)
- pageId ↔ chromeTabId ↔ tabGroupId 추적, lease 충돌(`TAB_ALREADY_LEASED`)
- 첫 탭 생성/claim 시 tab group materialize
- `end_session`이 agent-created 탭을 닫고 claimed 탭은 해제(열린 채)
- 탭 close 이벤트 → lease 정리

## 테스트 전략 (chrome 의존 격리)

chrome.tabs/tabGroups를 **`TabsPort` 인터페이스**로 추상화한다. PageManager는
TabsPort에만 의존 → `FakeTabsPort`로 lease/lifecycle 로직을 Node에서 단위테스트.
`ChromeTabsPort`는 얇은 chrome 어댑터(테스트 제외).

## 설계 포인트

- **TabsPort**: createTab/closeTab/getTab/getActiveTab/groupTabs/updateGroup/ungroupTabs.
- **PageManager**: PageRecord 보관 + `byTab`(chromeTabId→pageId) lease 인덱스. store·clock 주입.
  - `ensureGroup`: 세션 그룹 없으면 group 생성+제목/색 적용 → `SessionManager.materializeGroup`.
  - lease 충돌은 `ToolError("TAB_ALREADY_LEASED")`로 표현, Bridge가 envelope로 변환.
- **정책(pure)**: `parseTargetUrl`(http/https만), `isHostAllowed`(allowedDomains, 빈 목록=전체 허용).
- **scope**: `claim_tab`은 `tabScope==='agent-created-only'`이면 `POLICY_DENIED`.
- **gate**: page action은 `requireActive`로 paused/finalized 거부(Phase 3 게이트 재사용).
- **end_session**: `closeSessionPages` — agent-created는 close, claimed는 release(열린 채).

## 변경/추가 파일

### shared-protocol
- `errors.ts`: `ToolError` (code/message/details).
- `schemas.ts`: `newPageSchema`, `claimTabSchema`.
- `tools.ts`: `PageInfo`, `ClaimTabInput`.

### extension
- `background/tabs-port.ts` (신규): `TabsPort` + `ChromeTabsPort`.
- `background/page-manager.ts` (신규): `PageRecord`/`PageStore`/`PageManager`.
- `background/page-store.ts` (신규): `ChromePageStore`.
- `background/policy.ts` (신규): URL/도메인 정책 순수 함수.
- `background/session-manager.ts`: `materializeGroup`/`addPage`/`removePage`.
- `background/bridge.ts`: `new_page`/`claim_tab`/`release_tab` + `end_session` 탭 정리.
- `service-worker.ts`: TabsPort/PageManager 생성·hydrate, `chrome.tabs.onRemoved` 배선.

## 완료 기준 (Acceptance)

[06 Phase 4](../spec/06-development-roadmap-tasks.md#L117) 기준:

- [x] agent-created 탭이 세션 tab group에 열린다 (materialize 검증)
- [x] active 탭 claim은 scope 정책을 요구한다 (`agent-created-only`→POLICY_DENIED)
- [x] claim된 탭은 preserve가 아니면 세션 그룹으로 이동한다
- [x] 한 탭은 두 세션에 동시 lease되지 않는다 (`TAB_ALREADY_LEASED`)
- [x] release는 사용자 탭을 닫지 않고 lease만 제거한다
- [x] 세션 종료 시 agent-created 탭은 닫힌다 (claimed는 열린 채)
- [x] 탭 close 이벤트가 lease를 정리한다 (`onTabRemoved`)

### 일부 보류 (Phase 9 hardening으로 이관)
- 탭 move/ungroup/window-move 시 정밀 reconcile (이번엔 close만 처리).

### 추가 자동 검증
- [x] `pnpm typecheck` / `test`(59) / `build` / `lint` 통과
- [x] PageManager 단위테스트 (FakeTabsPort: new/claim/release/conflict/end/onRemoved)
- [x] page tool 단위테스트 (정책/scope/gate/소유권)

## 구현 현황

상태 범례: ⬜ 미착수 · 🟡 진행중 · ✅ 완료

| # | 항목 | 산출물 | 상태 | 비고 |
| --- | --- | --- | --- | --- |
| 1 | ToolError | shared-protocol `errors.ts` | ✅ | code/message/details |
| 2 | page/claim 스키마 | shared-protocol `schemas.ts` | ✅ | newPage/claimTab |
| 3 | PageInfo 타입 | shared-protocol `tools.ts` | ✅ | + ClaimTabInput |
| 4 | TabsPort + Chrome 구현 | extension `background/tabs-port.ts` | ✅ | 주입형 포트 |
| 5 | 정책 순수함수 | extension `background/policy.ts` | ✅ | parseTargetUrl/isHostAllowed |
| 6 | PageManager + store | extension `background/page-manager.ts`/`page-store.ts` | ✅ | byTab lease 인덱스 |
| 7 | SessionManager page/group | extension `background/session-manager.ts` | ✅ | materialize/add/remove |
| 8 | page tools + end 정리 | extension `background/bridge.ts` | ✅ | new/claim/release + closeSessionPages |
| 9 | SW 배선 + 탭 이벤트 | extension `service-worker.ts` | ✅ | onRemoved 배선 |
| 10 | PageManager 테스트 | `tests/page-manager.test.ts` | ✅ | FakeTabsPort 10 tests |
| 11 | page tool 테스트 | `tests/page-tools.test.ts` | ✅ | 8 tests |
| 12 | 자동 게이트 | typecheck/test/build/lint | ✅ | 59 passed |
| 13 | 수동 확인 | 실제 탭/그룹 동작 (브라우저) | ⬜ | 수동 확인 필요 |

## 다음 task 연결

- 완료 후 [06 Phase 5](../spec/06-development-roadmap-tasks.md#L126) **Snapshot and artifact tools**로 이어진다.
