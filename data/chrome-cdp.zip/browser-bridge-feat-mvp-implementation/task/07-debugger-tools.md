# 07. Debugger Read/Action Tools

Phase 6(page actions) 위에서 `chrome.debugger`(CDP)로 더 풍부한 브라우저 데이터를
얻는 단계의 세부 계획과 구현 현황.

- 대응 로드맵: [06 Phase 7](../spec/06-development-roadmap-tasks.md#L176)
- backend: [01 §Debugger Backend](../spec/01-architecture.md#L96)
- tool 계약: [03 §list_console_messages/list_network_requests](../spec/03-protocol-and-mcp-tools.md#L424)
- 안전: [02 §Redaction](../spec/02-security-permissions.md), [04 §Screenshot strategy](../spec/04-extension-backend.md)
- 레퍼런스: [reference/guide.md §1.6 PageCollector](../reference/guide.md)

## 목표

- `chrome.debugger` attach/detach 수명관리 (session-owned 탭만)
- CDP 기반 `list_console_messages` / `list_network_requests` (헤더/민감 쿼리 redaction)
- 배경 탭 스크린샷(`Page.captureScreenshot`) — extension-debugger 모드
- pause/release/end-session/tab-close 시 detach
- popup에 debugger 상태 표시

## 테스트 전략

- **redaction**(pure): 헤더/URL 파라미터 redaction 단위테스트.
- **DebuggerManager**: `DebuggerPort` 주입 → attach 시 domain enable, 이벤트 버퍼링, redaction, screenshot, detach 테스트.
- chrome.debugger 어댑터(`ChromeDebuggerPort`)는 얇음(테스트 제외).

## 설계 포인트

- `DebuggerManager`: `ensureAttached`(Log/Runtime/Network/Page enable), 이벤트→버퍼(console/network, cap으로 bounded), `listConsole`/`listNetwork`(redact), `captureScreenshot`(artifact), `detach`.
- attach는 bridge `resolveOwnedPage` 통과 후에만 호출 → session-owned 보장.
- network summary는 method/url(redacted)/status/resourceType/duration만 — **헤더는 노출하지 않음**.
- screenshot: `session.mode==='extension-debugger'`면 debugger 캡처(배경 탭 OK), 아니면 visible 캡처(Phase 5).
- detach 트리거: pause_session/release_tab/end_session/onRemoved.

## 변경/추가 파일

### shared-protocol
- `tools.ts`: `ConsoleMessage`, `NetworkRequestSummary` 타입.

### extension
- `background/redaction.ts` (신규, pure): `redactHeaders`/`redactUrl`.
- `background/debugger-port.ts` (신규): `DebuggerPort` + `ChromeDebuggerPort`.
- `background/debugger-manager.ts` (신규): attach/버퍼/list/screenshot/detach.
- `background/bridge.ts`: list_console/list_network, screenshot 분기, detach 수명관리, deps.debugger.
- `service-worker.ts`: DebuggerManager 배선, onRemoved detach, popup debugger 상태.
- `state/connection-state.ts` + popup: debugger attached 수.

## 완료 기준 (Acceptance)

[06 Phase 7](../spec/06-development-roadmap-tasks.md#L190) 기준:

- [x] debugger 권한이 초기 빌드에 존재한다 (manifest)
- [x] attach는 session-owned 탭에만 동작한다 (resolveOwnedPage 후 attach)
- [x] release/finalize/pause 시 detach된다 (+onRemoved)
- [x] debugger 모드가 더 풍부한 console/network 데이터를 반환한다
- [x] cookie/auth 헤더가 redaction된다 (헤더 미노출 + url 파라미터 redaction)

### 추가 자동 검증
- [x] `pnpm typecheck` / `test`(101) / `build` / `lint` 통과
- [x] redaction 단위테스트
- [x] DebuggerManager 단위테스트(attach/버퍼/redaction/screenshot/detach)
- [x] debugger tool 단위테스트(소유권/gate/detach/screenshot)

## 구현 현황

상태 범례: ⬜ 미착수 · 🟡 진행중 · ✅ 완료

| # | 항목 | 산출물 | 상태 | 비고 |
| --- | --- | --- | --- | --- |
| 1 | console/network 타입 | shared-protocol `tools.ts` | ✅ | ConsoleMessage/NetworkRequestSummary |
| 2 | redaction (pure) | extension `background/redaction.ts` | ✅ | header/url, 테스트됨 |
| 3 | DebuggerPort + Chrome | extension `background/debugger-port.ts` | ✅ | 주입형 |
| 4 | DebuggerManager | extension `background/debugger-manager.ts` | ✅ | bounded 버퍼/list/screenshot/detach |
| 5 | bridge debugger tools | extension `background/bridge.ts` | ✅ | list_console/list_network + screenshot 분기 |
| 6 | detach 수명관리 | `background/bridge.ts`/`service-worker.ts` | ✅ | pause/release/end/onRemoved |
| 7 | popup debugger 상태 | extension `state`/`popup` | ✅ | attached 수 |
| 8 | 테스트 | `tests/` (redaction/manager/tools) | ✅ | +14 tests |
| 9 | 자동 게이트 | typecheck/test/build/lint | ✅ | 101 passed |
| 10 | 수동 확인 | 실제 console/network/screenshot (브라우저) | ⬜ | 수동 확인 필요 |

## 다음 task 연결

- 완료 후 [06 Phase 8](../spec/06-development-roadmap-tasks.md#L198) **Native Messaging production path**로 이어진다.
