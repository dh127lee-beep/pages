# 06. Development Roadmap And Tasks

This is the implementation order for an extension-first, multi-session product.
Each phase should be completed before moving to the next one unless the team
explicitly accepts the risk.

## Phase 0: Repository baseline

Goal: create a maintainable project skeleton.

Tasks:

- Create monorepo or package layout.
- Add TypeScript build setup.
- Add lint/test commands.
- Add shared protocol package.
- Add extension package.
- Add basic CI command scripts.
- Add spec folder to repo root.

Acceptance criteria:

- `npm test` or equivalent runs.
- `npm run build` or equivalent runs.
- Shared protocol package exports basic ids/types.
- Extension package can compile without browser functionality.

## Phase 1: MV3 extension shell

Goal: create an installable high-permission Chrome extension that can show state
to the user.

Tasks:

- Create extension manifest.
- Include `activeTab`, `scripting`, `tabs`, `tabGroups`, `storage`, `debugger`,
  and `<all_urls>`.
- Add service worker.
- Add popup UI.
- Add options page.
- Add minimal content script.
- Add extension storage helpers.
- Add connected/disconnected state model.

Acceptance criteria:

- Extension builds.
- Extension can be loaded unpacked in Chrome.
- Popup shows disconnected state.
- Options page can store basic settings.
- Manifest includes initial high-permission scope intentionally.

## Phase 2: Agent bridge transport

Goal: let local agents connect directly to the extension (auto-connect, no
pairing token — see spec/02 connection policy).

Tasks:

- Implement extension protocol envelopes.
- Implement adapter endpoint discovery (port file / fixed port) in extension.
- Implement development localhost WebSocket client in extension (auto-connect).
- Implement small agent adapter WebSocket endpoint on `127.0.0.1`.
- Add client identity and version handshake.
- Add heartbeat/disconnect/reconnect handling.
- Add `browser.get_capabilities`.

Acceptance criteria:

- Extension and adapter auto-connect when both are running.
- Multiple agents can connect with distinct identities.
- Adapter WS binds only to `127.0.0.1`.
- Web-page-originated commands are rejected.
- Popup shows connected client names.
- Disconnect updates extension UI and reconnects.
- `get_capabilities` returns protocol, extension version, and permission state.

## Phase 3: Session manager and tab groups

Goal: make session the first-class work unit and give every session a Chrome tab
group.

Tasks:

- Implement `browser.start_session`.
- Implement `browser.list_sessions`.
- Implement `browser.get_session`.
- Implement `browser.pause_session`.
- Implement `browser.resume_session`.
- Implement session state storage.
- Implement session tab group metadata.
- Implement tab group title/color assignment.
- Reconcile sessions after service worker restart.

Acceptance criteria:

- One agent can create multiple sessions.
- Multiple agents can own active sessions concurrently.
- Each session has logical tab group metadata.
- First tab creation or claim materializes the Chrome tab group.
- Popup/side panel lists active sessions and group status.
- Paused sessions reject page actions.

## Phase 4: Page leases and tab lifecycle

Goal: give each session an isolated page surface through tab ownership.

Tasks:

- Implement `browser.new_page` using `chrome.tabs.create`.
- Add new tabs to the session tab group.
- Implement `browser.claim_tab`.
- Implement `browser.release_tab`.
- Track page ids, Chrome tab ids, and tab group ids.
- Detect user tab group changes.
- Handle tab close, move, ungroup, and window move events.

Acceptance criteria:

- Agent-created tab opens in the session tab group.
- Active tab claim requires configured scope.
- Claimed tab is moved into the session group unless preserved.
- A tab cannot be leased by two active sessions.
- Release removes lease without closing user tab.
- Session end closes agent-created tabs by default.

## Phase 5: Snapshot and artifact tools

Goal: implement observation before action.

Tasks:

- Implement content script injection for leased tabs.
- Implement `take_snapshot`.
- Normalize role/name/text/tag/bounds/enabled state.
- Generate snapshot-local uids.
- Add risk hints.
- Implement visible screenshot capture.
- Store or stream screenshot artifact.

Acceptance criteria:

- Snapshot returns usable element list.
- Password field values are redacted.
- Hidden input values are not returned.
- Screenshot returns artifact id/path/chunk metadata.
- Artifacts include session/page/tab group metadata.
- Large binary is not embedded in tool text response.
- Stale snapshot ids are detectable.

## Phase 6: Extension page actions

Goal: implement the basic interaction loop through content scripts.

Tasks:

- Implement `click`.
- Implement `fill`.
- Implement `fill_form`.
- Implement `press_key`.
- Implement `scroll`.
- Implement `wait_for`.
- Reject stale snapshot targets.
- Serialize commands per page.
- Optionally return updated snapshot after action.

Acceptance criteria:

- Page actions require matching `sessionId` and `pageId`.
- Click works against a uid from latest snapshot.
- Fill works against text input uid.
- Enter inside a form is classified with submit-like risk hint.
- Stale uid returns `SNAPSHOT_STALE` or `ELEMENT_NOT_FOUND`.
- Risky targets return risk hints to the agent.
- Action result includes URL/title/navigation change when available.

## Phase 7: Debugger read/action tools

Goal: use the initial `debugger` permission for richer browser data on
session-owned tabs.

Tasks:

- Implement debugger attach/detach lifecycle.
- Add debugger state to popup.
- Implement console/network read via CDP where allowed.
- Implement screenshot through debugger where useful.
- Ensure debugger attach only targets session-owned tabs.
- Add detach on pause/revoke/end-session/tab-close.

Acceptance criteria:

- Debugger permission is present in the normal initial build.
- Attach only works on session-owned tabs.
- Detach happens on release/finalize/pause.
- Debugger mode returns richer console/network data.
- Cookies and auth headers are redacted.

## Phase 8: Native Messaging production path

Goal: replace dev WebSocket dependency with safer native host path.

Tasks:

- Implement native host manifest generation/install instructions.
- Implement JSON message framing.
- Add handshake version negotiation.
- Add extension id verification.
- Add local agent identity verification.
- Add diagnostics for native host missing/invalid.
- Connect MCP adapter through native messaging.

Acceptance criteria:

- Extension connects through native messaging.
- MCP client can list tools through adapter.
- Version mismatch returns clear diagnostic.
- Missing native host returns clear setup message.
- Message timeouts are handled.
- No local HTTP port is required in production mode.

## Phase 9: Multi-agent lifecycle hardening

Goal: avoid abandoned sessions, mixed ownership, and stale tab groups.

Tasks:

- Add session idle timeout.
- Add page lease expiration.
- Add per-session command queue limits.
- Add conflict handling for tabs claimed by another session.
- Add session resume after reconnect.
- Add service worker rehydration tests.
- Add cleanup for empty/detached tab groups.
- Add audit linkage for session and tab group ids.

Acceptance criteria:

- No action can target finalized/released page.
- `TAB_ALREADY_LEASED` is returned for conflicting claims.
- Reconnected agent can resume non-finalized sessions.
- Empty session groups finalize or hand off according to policy.
- Audit events include agent, session, page, and tab group ids.

## Phase 10: Hardening and docs

Goal: prepare for dogfooding.

Tasks:

- Add end-to-end tests.
- Add threat model doc update.
- Add extension install docs.
- Add native messaging install docs.
- Add troubleshooting docs.
- Add known limitations.
- Add privacy statement.

Acceptance criteria:

- Test suite covers extension bridge basics.
- Test suite covers multi-agent and multi-session basics.
- Test suite covers session tab group lifecycle.
- Test suite covers adapter/native messaging basics.
- Security policy is documented.
- Setup failure messages are actionable.
- Privacy-sensitive behaviors are documented.
- A new developer can run MVP from README.
