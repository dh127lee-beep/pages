# 00. Product Scope

## 제품 정의

Browser Bridge는 AI 에이전트가 사용자의 Chrome/Edge 브라우저를 안전하게
조작하도록 해주는 Chrome MV3 확장이다.

확장은 단순한 content script 묶음이 아니라 에이전트와 직접 연결되는 브리지다.
확장 service worker가 에이전트 연결, 세션, 세션별 탭 그룹, 탭 lease, 권한
상태, audit를 관리하고, content script와 Chrome extension API에 명령을 위임한다.

세션은 제품의 기본 작업 단위다. 하나의 에이전트는 여러 세션을 만들 수 있고,
여러 에이전트가 동시에 각자의 세션을 유지할 수 있다. 각 세션은 하나의 Chrome
tab group을 소유하며, 세션에서 생성하거나 claim한 탭은 해당 그룹에 속한다.

이 제품의 초점은 에이전트를 위한 세션 연동과 액션 실행이다. 즉 연결·세션·탭
lease·권한·실행 백엔드를 제공하는 데 집중하고, 무엇을 클릭하고 어떤 순서로
작업을 진행할지와 같은 에이전트의 추론·계획·의사결정 로직은 다루지 않는다.
그런 판단은 전적으로 에이전트가 담당하며, 제품은 안전하고 검증 가능한 실행
표면만 제공한다.

브라우저 조작은 다음 모드로 제공한다.

| 모드 | 설명 | 기본 안전 수준 |
| --- | --- | --- |
| Extension Tab Mode | MV3 확장이 에이전트와 연결되고, 세션 탭 그룹 안의 실제 Chrome/Edge 탭을 content script로 제어 | 기본값, session-owned tab만 허용 |
| Extension Debugger Mode | 확장이 `chrome.debugger` 권한으로 세션 탭 그룹의 승인된 탭에 CDP-like 명령을 실행 | 초기 버전에 포함, 고권한 모드 |

중요한 경계:

- Chrome 확장 자체는 로컬 프로세스를 실행하거나 임시 Chrome 프로필을 직접 띄울 수 없다.
- 에이전트가 MCP stdio만 지원하면 작은 agent adapter/native host가 필요할 수 있다.
- 그래도 제품의 1차 브리지는 확장이다. 로컬 adapter는 transport 변환과 파일 저장을
  돕는 보조 구성 요소다.

## 사용자

- 로컬 코딩 에이전트 사용자
- 브라우저 기반 리서치/QA/업무 자동화 사용자
- 에이전트가 실제 브라우저 탭에 접근하는 범위를 직접 확인해야 하는 파워 유저
- 향후 외부 에이전트 SDK 또는 MCP 클라이언트 개발자

## 핵심 사용 사례

- 에이전트와 확장의 자동 연결 (dev WS는 토큰 없이 연결)
- 여러 에이전트의 동시 연결과 세션별 작업 분리
- 세션별 Chrome tab group 생성, 표시, 정리
- 현재 탭 또는 에이전트가 만든 탭을 세션에 claim/finalize
- 웹 페이지 열기, 읽기, 클릭, 입력, 스크롤
- 로그인된 실제 Chrome/Edge 탭에서 사용자가 허용한 범위의 자동화
- 해당 Chrome 윈도우나 탭이 활성화/포커스되지 않아도 백그라운드에서 명령 실행
- 개발 중인 localhost 앱 검증
- 콘솔 오류, 네트워크 요청, 스크린샷 수집
- 에이전트가 만든 탭에서 폼 입력과 작업 흐름 자동화

## 비목표

- 에이전트의 추론·계획·작업 선택 등 에이전트 로직 자체 구현
- CAPTCHA 우회
- paywall 우회
- 쿠키/세션 토큰 추출 API 제공
- browser history scraping
- 모든 사이트에서 완전 자율 동작을 보장하는 범용 RPA
- 원격 클라우드 브라우저 서비스
- 별도 Chrome 프로세스 실행

## 제품 포지셔닝

이 프로젝트는 세 가지 성격을 결합한다.

- Kimi WebBridge처럼 실제 브라우저 확장과 에이전트 런타임을 연결한다.
- Codex Extension처럼 탭 claim/finalize, snapshot-first 조작, 세션 수명 관리를 제공한다.
- Chrome DevTools MCP처럼 표준화된 tool protocol을 제공하되, MCP는 확장에
  붙는 adapter transport 중 하나로 취급한다.

## 기능 경계

초기 버전은 다음 기능만 포함한다.

- Chrome MV3 extension
- extension service worker 기반 agent bridge
- session manager
- session-scoped Chrome tab group
- popup 또는 side panel 상태 UI
- content script snapshot/action backend
- `debugger` permission
- `<all_urls>` host permission
- `tabGroups` permission
- Native Messaging 또는 local WebSocket agent transport
- 자동 연결과 client identity 표시 (dev WS 토큰 없음, native host는 allowlist)
- Snapshot, screenshot, click, fill, scroll, key press
- console/network read
- 비활성 윈도우·백그라운드 탭에서의 명령 실행 (사용자 포커스 비탈취)
- artifact 전달 또는 adapter file output
- audit event log

## 성공 기준

- 확장이 에이전트와 직접 연결되고 연결 상태를 사용자에게 보여준다.
- 여러 에이전트가 동시에 연결되어도 세션과 탭 그룹이 분리된다.
- 사용자가 어떤 에이전트의 어떤 세션이 어떤 탭 그룹을 제어하는지 확인할 수 있다.
- 모든 탭 제어는 session-owned tab group 또는 명시적으로 claim된 탭으로 제한된다.
- 세션 탭이 비활성이거나 백그라운드에 있어도 명령이 실행되고, 사용자의 현재 포커스를 강제로 빼앗지 않는다.
- 에이전트가 페이지를 볼 때와 행동할 때의 기준이 일관된다.
- `debugger`, `<all_urls>`, `tabGroups` 권한이 필요한 기능이 초기 버전에 포함된다.
- 세션 종료 시 세션 탭 그룹, 탭 lease, native connection이 정책에 맞게 정리된다.
