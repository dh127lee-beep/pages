# Browser Bridge Spec

이 폴더는 Chrome 확장 기반 에이전트 브리지 프로젝트를 구현하기 위한 개발
기준이다.

목표는 단순한 브라우저 자동화 확장이 아니다. 목표는 Chrome MV3 확장이
에이전트와 직접 연결되는 브리지 역할을 하면서, 사용자가 볼 수 있는 권한
상태, 세션, 세션별 탭 그룹을 사이에 두는 것이다.

## 참고한 설계 관찰

- Kimi WebBridge는 로컬 서비스와 브라우저 확장을 연결하고, 에이전트가
  기존 Chrome/Edge에서 탐색, 클릭, 입력, 스크린샷, 콘텐츠 읽기를 수행하게 한다.
- Codex Chrome Extension 스타일은 탭 claim/finalize, snapshot-first 조작,
  세션 수명 관리, action 후 검증 루프가 강점이다.
- Chrome DevTools MCP는 표준 tool API와 CDP 기반 디버깅 surface를 제공한다.
  이 프로젝트에서는 MCP를 확장에 붙는 adapter transport 중 하나로 취급한다.

## 최종 아키텍처

```mermaid
flowchart LR
  A["Agent Clients\nCodex / Claude / Cursor / Kimi"] --> B["Agent Adapter optional\nMCP / WS / Native Host"]
  A --> C["Chrome MV3 Extension\nAgent Bridge"]
  B <--> C
  C --> D["Session Manager\nmulti-agent / multi-session"]
  D --> E["Tab Group Manager\nChrome tabGroups"]
  D --> F["Scope Guard\nownership / permissions / redaction"]
  E --> G["Content Script Backend\nsnapshot / click / fill"]
  E --> H["Debugger Backend\nchrome.debugger"]
  B --> I["Artifacts\nscreenshots / traces / logs"]
  G --> J["User Chrome / Edge Tabs"]
  H --> J
```

## 문서 읽는 순서

1. [00-product-scope.md](00-product-scope.md)
2. [01-architecture.md](01-architecture.md)
3. [02-security-permissions.md](02-security-permissions.md)
4. [03-protocol-and-mcp-tools.md](03-protocol-and-mcp-tools.md)
5. [04-extension-backend.md](04-extension-backend.md)
6. [05-local-bridge-and-cdp-backend.md](05-local-bridge-and-cdp-backend.md)
7. [06-development-roadmap-tasks.md](06-development-roadmap-tasks.md)
8. [07-test-and-quality-gates.md](07-test-and-quality-gates.md)

외부 레퍼런스(chrome-devtools-mcp, Codex control-chrome skill)를 우리 설계
관점에서 정리한 가이드는 [reference/guide.md](../reference/guide.md)를 참고한다.
"tool 설계·스냅샷·응답 패턴"은 chrome-devtools-mcp에서, "에이전트가 브라우저를
안전하게 다루는 동작 규약"은 Codex skill에서 가져오되, 두 레퍼런스의 실행
아키텍처(별도 프로세스가 브라우저 소유)는 채택하지 않는다.

## 개발 원칙

- Chrome MV3 확장을 제품의 1차 런타임으로 둔다.
- 확장이 agent 연결, session, session tab group, tab lease를 소유한다.
- MCP는 필요한 에이전트를 위한 adapter transport로 제공한다.
- 각 세션은 하나의 Chrome tab group으로 사용자에게 드러난다.
- 모든 조작은 `observe -> decide -> act -> verify` 루프를 따른다.
- 클릭/입력은 snapshot에서 발급된 element uid를 대상으로 한다.
- 페이지 본문, 쿠키, 토큰, 네트워크 헤더는 기본적으로 저장하지 않는다.

## MVP 완료 기준

MVP는 다음이 가능해야 한다.

- 확장이 unpacked로 설치된다.
- 확장이 실행 중인 로컬 adapter에 자동 연결되고 여러 에이전트가 동시에 붙을 수 있다.
- 에이전트가 세션을 만들면 세션별 Chrome tab group이 생성된다.
- popup/side panel이 연결된 에이전트, 세션, tab group, tab lease를 보여준다.
- 에이전트가 세션 탭 그룹 안에 새 탭을 열고 URL로 이동한다.
- 현재 페이지 snapshot을 반환한다.
- snapshot uid를 대상으로 click/fill/press/scroll을 수행한다.
- screenshot을 artifact로 저장하거나 chunk로 전달한다.
- debugger 기반 console/network 정보를 반환한다.
- 세션 종료 시 session tab group, agent-created 탭, claimed user tab lease를 정리한다.
