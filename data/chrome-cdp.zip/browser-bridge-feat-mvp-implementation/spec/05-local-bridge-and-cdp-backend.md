# 05. Agent Adapter And Native Transport

## Purpose

The project is a Chrome extension first. A local adapter is useful when an agent
needs MCP stdio, when artifacts should be written to local files, or when Native
Messaging is the production transport.

The adapter must remain thinner than the extension:

- It translates transports.
- It stores large artifacts.
- It forwards client identity.
- It does not grant browser access.
- It does not create sessions or tab groups by itself.
- It does not override extension session ownership decisions.

## Suggested package layout

```text
browser-bridge/
  packages/
    extension/
    shared-protocol/
    agent-adapter/
    native-host/
    artifact-store/
  spec/
  tests/
```

## Agent adapter responsibilities

Responsibilities:

- expose MCP tools when needed
- expose development WebSocket endpoint when needed
- translate MCP/agent messages to extension protocol
- advertise the loopback WS endpoint (e.g. port file) for the extension to auto-connect
- forward client identity
- store artifacts under local session directories
- collect diagnostics
- handle shutdown cleanup

Non-responsibilities:

- browser automation without extension consent
- direct cookie/session extraction
- Chrome process launch
- hidden fallback to another backend

## MCP transport

MCP is an adapter-facing transport, not the only public API.

Support at least:

- stdio for local agents
- optional HTTP/SSE or Streamable HTTP if needed later

MCP adapter should expose:

- tool list matching the extension protocol
- resource list for artifacts
- capabilities/version info
- extension connection diagnostics
- session and tab group summaries

## Native Messaging host

Native Messaging host can serve as:

- production transport between extension and adapter
- artifact file writer
- MCP bridge process

Requirements:

- registered host manifest with exact extension `allowed_origins`
- framed JSON protocol
- version negotiation
- client identity forwarding
- per-session artifact root
- timeouts
- stderr-only debug logs
- clear setup diagnostics when host is missing

## Local WebSocket development path

Development may use a local WebSocket path:

- bind only to `127.0.0.1`
- fixed or port-file-advertised port
- no pairing token; extension auto-connects (see spec/02 connection policy)
- extension initiates the connection
- reject web-page-originated messages and non-loopback origins
- close connection on session end

This path is easier for dogfooding but should not be the only production path.

## Session-aware artifact store

Artifacts are written under a session directory when adapter/native host is
available.

Recommended structure:

```text
.browser-bridge/
  artifacts/
    sess_123/
      screenshot_001.png
      network_001.json
      console_001.json
```

Requirements:

- artifact ids are opaque
- artifact path is returned only if local client can access it
- raw binary is not embedded in MCP text results
- extension-only transports may stream chunks instead of file paths
- cleanup policy is tied to session lifecycle
- artifacts include `sessionId`, `pageId`, and `tabGroupId` metadata

## Transport message routing

Every message should preserve ownership context:

```json
{
  "id": "msg_123",
  "version": "0.1.0",
  "type": "browser.take_snapshot",
  "sessionId": "sess_123",
  "pageId": "page_123",
  "payload": {}
}
```

Routing rules:

- adapter does not infer a missing `sessionId` for page actions
- adapter rejects responses that do not match a pending request id
- extension rejects page actions whose `pageId` does not belong to `sessionId`
- adapter should surface `SESSION_NOT_FOUND`, `SESSION_PAUSED`, and
  `TAB_ALREADY_LEASED` clearly to the agent

## Diagnostics

The adapter and extension should expose diagnostics:

- extension installed/connected/disconnected
- active agent/client names
- native messaging host installed/missing
- debugger permission enabled/disabled
- tabGroups permission enabled/disabled
- current sessions/pages/leases
- session tab group ids/titles/colors
- artifact root and cleanup policy

Diagnostics must not expose cookies, tokens, or page body.

## Acceptance criteria

- Extension can connect to agent adapter.
- MCP adapter starts and lists tools when used.
- `browser.get_capabilities` reports extension, permission, native, and session support.
- Multiple agents can connect with distinct identities.
- Multiple sessions can be listed and queried.
- Agent-created tab opens in the session tab group.
- Artifact directory is created per session when adapter storage is enabled.
- Native host missing state returns actionable setup message.
- Backend errors are normalized into protocol error codes.
- Audit events are written without sensitive payloads.
