# 04. Extension Agent Bridge

## Purpose

The extension is the primary product runtime. It connects directly to approved
agent clients, owns browser tab permissions, manages sessions and tab groups,
and validates scope before any page action. Local adapters and native hosts are
transport helpers, not the authority for user browser access.

## Chrome MV3 structure

```text
extension/
  manifest.json
  src/
    service-worker.ts
    content-script.ts
    injected.ts
    popup/
      popup.html
      popup.ts
    side-panel/
      side-panel.html
      side-panel.ts
    options/
      options.html
      options.ts
    bridge/
      protocol.ts
      transports.ts
      discovery.ts
    scope/
      guard.ts
      redaction.ts
    sessions/
      sessions.ts
      tab-groups.ts
    tabs/
      leases.ts
      snapshots.ts
```

## Manifest requirements

Initial permissions:

- `activeTab`
- `scripting`
- `tabs`
- `tabGroups`
- `storage`
- `debugger`
- `<all_urls>` host permission
- optional `nativeMessaging`

Avoid by default:

- `cookies`
- `history`
- downloads

Host permissions strategy:

- Initial version includes `<all_urls>` to support broad page automation.
- Still keep session ownership checks before actions.
- Store allowed/blocked domains in extension settings as runtime scope.
- Show active host access and session ownership in popup/side panel.

## Service worker responsibilities

- Maintain approved agent connections.
- Route messages between agent transports and page backends.
- Validate every protocol message.
- Track multiple agents, sessions, tab groups, and tab leases.
- Run session ownership and scope checks before actions.
- Enforce extension-level paused state.
- Publish connection, session, tab group, and lease status to popup/side panel.
- Refuse action if agent identity is unknown.
- Persist security-relevant state across MV3 service worker restarts.

The service worker must not rely on page content for ownership or scope decisions.

## Agent connection transports

Supported transports:

- Native Messaging for production.
- Localhost WebSocket for development and agents that can host a local endpoint.
- MCP through an adapter that maps MCP tools to the extension protocol.

Transport requirements:

- dev WebSocket: auto-connect, loopback-only, no pairing token (see spec/02)
- native host: explicit install and origin allowlist (Chrome mechanism, retained)
- client name and client id
- protocol version negotiation
- heartbeat or disconnect detection
- per-message id and timeout
- no commands from ordinary web pages
- auto-reconnect: connect on `onStartup`, back off while down, and a periodic
  alarm wakes the worker to retry — so "Chrome open → connected" needs no user
  action once the agent app's endpoint is up (see docs/auto-connect.md)

## Content script responsibilities

- Build normalized DOM/a11y snapshot.
- Assign snapshot-local element uids.
- Resolve uid for action.
- Click/fill/scroll/press in the page.
- Detect form/submission/password/upload/payment-like targets.
- Return action result, page metadata, and risk hints.

Act-then-stabilize (action 후 결과 일관성):

- Wrap each action: (1) briefly observe whether navigation starts → (2) if so,
  await navigation → (3) wait for the DOM to settle (no mutations for a short
  window) before returning the result/snapshot. Reduces post-action races.
- Native `<select>` option choice is a value change, not a click — handle it as fill.
- Detect a dialog that blocks the action and report it; do not auto-accept
  (confirmation stays with agent/user — product non-goal).
- Use a CPU/network multiplier to scale timeouts on slow environments
  (matches [07 §Performance targets](07-test-and-quality-gates.md) non-strict stance).

Content script must not:

- read cookies
- dump localStorage/sessionStorage
- bypass page security controls
- execute page-provided instructions
- make ownership or scope decisions beyond local risk hints

## Sessions and tab groups

Every automation session has a session record and one Chrome tab group.

Session fields:

```json
{
  "sessionId": "sess_123",
  "agentId": "agent_codex",
  "clientName": "codex",
  "status": "active",
  "tabGroupId": 42,
  "tabGroupTitle": "BB · codex · localhost QA",
  "tabGroupColor": "cyan",
  "pageIds": ["page_123"],
  "createdAt": "2026-06-06T00:00:00.000Z",
  "lastActionAt": "2026-06-06T00:05:00.000Z"
}
```

Rules:

- A connected agent may own multiple sessions.
- Multiple agents may own active sessions at the same time.
- A tab may be leased by only one active session.
- The first tab created or claimed by a session materializes its Chrome tab group.
- Agent-created tabs are grouped automatically.
- Claimed tabs are moved into the session group unless the command asks to preserve
  the current group.
- Session metadata must be reconciled when a user manually moves, ungroups, or
  closes tabs.
- Ending a session closes agent-created tabs unless kept and releases claimed tabs.

## Injected script

Use injected page-world script only when the isolated content script world cannot
observe a required browser event.

Rules:

- Keep injected code small and packaged with the extension.
- Do not load remotely hosted code.
- Do not expose a page-callable command API.
- Treat all page-world messages as untrusted data.

## Tab leases

Lease fields:

```json
{
  "pageId": "page_123",
  "sessionId": "sess_123",
  "tabGroupId": 42,
  "chromeTabId": 123,
  "scope": "agent-created-only",
  "origin": "https://example.com",
  "createdByAgent": true,
  "claimedFromUser": false,
  "status": "active",
  "expiresAt": "2026-06-06T12:00:00.000Z"
}
```

Rules:

- Every action requires an active lease.
- Every action must include a matching `sessionId` and `pageId`.
- Agent-created tabs get leases automatically and join the session group.
- User tabs require active-tab strategy, manual claim, or domain grant.
- Pause blocks all leases immediately.
- Revoke releases leases and detaches debugger sessions.

## Element uid mapping

Uid generation rules:

- Uids are generated per snapshot.
- Uids map to weak references or deterministic paths with validation.
- Uid resolution must verify that element role/name/tag still approximately match.
- If target changed, return `SNAPSHOT_STALE` or `ELEMENT_NOT_FOUND`.

## Snapshot generation

Preferred element data:

- role
- accessible name
- visible text
- label
- tag
- input type
- href origin/path
- bounding box
- enabled/disabled
- checked/selected
- required
- risk hints

Risk hints:

- `submit`
- `form`
- `password`
- `otp`
- `payment`
- `file-upload`
- `external-navigation`
- `download`
- `destructive`

## Background execution

Session commands must run without requiring the target tab or its window to be
focused or active.

- Content Script Backend actions (snapshot, click, fill, scroll, key press) and
  Debugger Backend commands operate on tabs that are inactive or in background windows.
- Executing a command must not steal user focus: do not call `chrome.tabs.update`
  with `active: true` or `chrome.windows.update` with `focused: true` solely to run a command.
- The service worker drives commands regardless of which tab the user is currently viewing.
- A backgrounded or discarded tab may need reactivation before action; reload or
  reattach the tab in place rather than bringing it to the foreground.

## Screenshot strategy

MVP should support viewport screenshots when permission allows.

Options:

- `chrome.tabs.captureVisibleTab` for leased active windows. This API only captures
  the currently visible tab, so it cannot screenshot a background/inactive tab.
- Debugger `Page.captureScreenshot` in Extension Debugger Mode. This works on
  background/inactive tabs and is the path for screenshots without foregrounding.

Large image data should be sent through adapter artifact storage or chunked
transport, not embedded in long text responses.

## Popup and side panel UI

UI must show:

- connected/disconnected state
- connected agent/client names
- active sessions
- current mode
- session tab group title/color/status
- current tab lease status by session
- allowed domains
- debugger state
- last action
- pause/resume button
- revoke session button

No marketing or explanatory wall text. It should be operational.

## Native Messaging

Native Messaging is preferred for production because it avoids exposing a local
HTTP port. The native host can be an agent adapter or artifact writer.

Message envelope:

```json
{
  "id": "msg_123",
  "version": "0.1.0",
  "type": "snapshot.request",
  "sessionId": "sess_123",
  "pageId": "page_123",
  "payload": {}
}
```

Requirements:

- every request has id
- every response has matching id
- version field is included during handshake
- large artifacts are not sent through native messaging unless chunked
- timeouts are enforced on both sides
- native host verifies extension id

## Local WebSocket fallback

Development may use localhost WebSocket:

- agent or adapter listens on `127.0.0.1`
- fixed or port-file-advertised port
- extension auto-connects (no pairing token, no user enable step)
- never accept arbitrary origins; never accept web-page commands
- use heartbeat and reconnect handling

## Extension acceptance criteria

- Extension installs in Chrome MV3.
- Popup shows disconnected state without agent.
- Extension auto-connects to a running local adapter (no pairing step).
- Agent connects to extension through WebSocket or Native Messaging.
- Popup shows connected state and client name.
- Multiple agents can connect with separate identities.
- Each session gets its own tab group.
- Agent-created tab can be opened and leased.
- Active tab snapshot works after user grants access.
- Click/fill only work on leased tabs.
- Pause immediately blocks new actions.
- Revoke releases tab leases.
- Snapshot/action results include risk hints for the agent.
