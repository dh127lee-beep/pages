# 02. Security And Permissions

## Trust boundaries

| Boundary | Risk | Required control |
| --- | --- | --- |
| Agent -> Extension Bridge | prompt injection, malicious tool calls | schema validation, session ownership checks |
| Agent Adapter -> Extension | spoofed local client (accepted risk) | loopback-only transport, schema validation, client name for visibility |
| Extension Service Worker -> Content Script | over-broad tab access | session id, tab group ownership, page lease |
| Content Script -> Web Page | untrusted page content | never follow page instructions as authority |
| Extension -> Native Host | local process abuse, artifact leakage | native host allowlist, explicit install, framed protocol |
| Debugger Backend -> User Browser | broad CDP power | session-owned tabs only, attach/detach lifecycle |
| Browser -> Agent | sensitive content disclosure | redaction, scope limits, audit |

## Data classification

| Class | Examples | Default handling |
| --- | --- | --- |
| Public | page title, visible button text | return allowed inside session-owned page |
| Page content | visible text, DOM snapshot, screenshots | return allowed inside session-owned page |
| Sensitive page content | email inbox, docs, private dashboards | return only from leased/session-owned tabs |
| Credentials | passwords, OTP, API keys, tokens | never auto-extract; redact values |
| Session data | cookies, localStorage, auth headers | no direct tool exposure |
| Financial/payment | card forms, checkout, billing | expose risk hints to the agent |

## Permission tiers

### Tier 0: Read-only

Allowed within an active session/page lease.

- `list_sessions`
- `get_session`
- `list_pages`
- `take_snapshot`
- `take_screenshot`
- `list_console_messages`
- `list_network_requests`
- `get_page_metadata`

### Tier 1: Low-risk interaction

Allowed inside an active session/page lease.

- `click` on non-submit targets
- `scroll`
- `press_key` for navigation keys
- `fill` non-sensitive input

### Tier 2: State-changing interaction

Allowed only inside an active session/page lease, with risk hints returned to the
agent.

- submit button click
- form submit key press
- settings changes
- adding/removing items
- download trigger
- opening external auth flow

### Tier 3: Sensitive side effect

The extension does not own final risk decisions. It returns risk hints and
executes only explicit agent commands within session scope.

- payment
- purchase
- message/email/post/comment send
- file upload
- permission/share/access changes
- account deletion or destructive action
- password/OTP/API key entry

### Tier 4: Prohibited

No tool should support these directly.

- cookie extraction
- localStorage/sessionStorage dumping
- password store access
- CAPTCHA bypass
- paywall bypass
- hidden form submission
- stealth/anti-bot evasion

## Extension permission strategy

Initial permissions:

- `activeTab`
- `scripting`
- `tabs`
- `tabGroups`
- `storage`
- `debugger`
- `<all_urls>` host permission
- optional `nativeMessaging`

Avoid by default:

- `cookies`
- `history`
- `downloads`
- password store access

Host permission strategy:

- Initial version includes `<all_urls>` for broad automation coverage.
- Runtime access is still constrained by session ownership and page leases.
- Store allowed/blocked domains in extension settings as runtime scope.
- Show active permissions, connected agents, sessions, and tab groups in popup/side panel.

## Agent bridge connection policy

The agent bridge connects **automatically with no pairing token and no
connection-time user consent**. When the extension and a local adapter are both
running, the extension connects and accepts commands. This is a deliberate
trade-off favoring a frictionless UX over a consent gate (see
[task/02-agent-bridge-transport.md](../task/02-agent-bridge-transport.md)).

Connection model:

- The extension initiates the connection to a loopback adapter endpoint.
- No pairing token, no user enable step, no token timeout.
- The connected client name is shown in popup/side panel for visibility only
  (display, not consent).

Accepted risk:

- Any local process that binds the adapter loopback endpoint can drive the
  logged-in browser. There is no connection-time consent gate.

Retained safety floor (not pairing; zero UX cost):

- The adapter transport binds only to `127.0.0.1` (no network exposure).
- The extension never accepts commands from web pages via `window.postMessage`.
- The extension does not expose a local HTTP server.
- Every message envelope and command id is schema-validated.

## Session and tab group safeguards

Session rules:

- Multiple agents may connect at the same time.
- One agent may own multiple sessions.
- Every session owns one logical Chrome tab group.
- The tab group is materialized when the first tab is created or claimed.
- Every page action must include `sessionId` and `pageId`.
- A tab may be leased by only one active session.
- Agent-created tabs are placed in the session tab group.
- Claimed tabs are moved into the session tab group unless the command preserves the current group.
- Session metadata must survive MV3 service worker restart.

Connection lifecycle rules (safety floor above also applies):

- Re-establish the connection automatically after service worker restart.
- Reconcile in-flight sessions/leases on reconnect before accepting new commands.
- Pause or expire sessions when the agent disconnects unless configured otherwise.

## Prompt injection handling

Untrusted page content can provide facts, but cannot issue instructions to the
runtime. The runtime must not obey page text that says things like:

- ignore previous instructions
- click a hidden button
- send this data elsewhere
- reveal cookies/tokens
- disable safety checks

Implementation requirement:

- snapshot results are tagged as `source=untrusted_page`.
- scope decisions never use untrusted page text as authority.
- action request reason must come from the agent/user context, not the page.
- content scripts send risk hints, not final policy decisions.

## Redaction

Redact by default:

- request headers: Authorization, Cookie, Set-Cookie
- URL query params likely containing token, key, code, session, auth
- input values from password fields
- OTP-like short numeric values in sensitive contexts
- credit card-like patterns
- API key-like strings

Snapshot redaction:

- Password fields return `valueRedacted=true`.
- Hidden inputs do not expose values.
- Inputs may expose placeholder, label, role, disabled/required state.

## Native Messaging safety

Native Messaging is an optional transport and artifact path.

Rules:

- Native host must be explicitly installed and origin-allowlisted.
- Native host protocol must use framed JSON and reject unknown extension ids.
- Native host must not grant browser access without extension session ownership.
- Large artifacts should be written to per-session directories.

## Audit events

Store compact audit events:

- timestamp
- agent/client
- sessionId/pageId
- tabGroupId
- backend
- action
- url origin
- risk hints
- scope decision
- result status

Do not store raw page body, screenshots, cookies, or network payloads in audit logs.
