# 01. Architecture

## 구성 요소

### Chrome MV3 Extension

제품의 중심 런타임이다. 확장은 에이전트와 직접 연결되는 브리지이며, 브라우저
탭에 대한 실제 권한을 가진 유일한 구성 요소다.

책임:

- agent 연결과 connection lifecycle 관리 (dev WS는 자동 연결, native host는 allowlist)
- tool/protocol message 수신과 응답
- session id, page id, tab group id 관리
- session별 tab lease 관리
- 권한 상태와 session scope 검증
- Session Manager와 Tab Group Manager에 명령 위임
- popup/side panel 상태 표시
- audit event 기록 또는 adapter로 전달

### Agent Adapter

에이전트가 확장과 직접 말할 수 없는 transport를 쓸 때만 필요한 작은 로컬
프로세스다. 예를 들어 MCP stdio 클라이언트는 extension service worker에 직접
stdio로 붙을 수 없으므로 adapter가 MCP tool을 노출하고 확장 protocol로 변환한다.

책임:

- MCP stdio 또는 agent-specific transport 노출
- extension과 Native Messaging 또는 localhost WebSocket 연결 중계
- client identity 표시 (dev WS는 토큰 없이 자동 연결)
- 큰 artifact를 파일로 저장

Adapter는 브라우저 권한의 주인이 아니다. 최종 session, tab group, tab lease
상태는 확장이 결정한다.

### Session Manager

멀티 에이전트와 반복 사용을 위한 최상위 작업 관리자다.

책임:

- 여러 agent connection 관리
- agent별 다중 session 생성/조회/종료
- session 상태 전이 관리
- session별 tab group metadata 관리
- session별 command queue와 page 목록 관리
- session idle timeout과 cleanup 처리
- session 상태를 popup/side panel에 노출

### Permission And Scope Guard

확장 권한, agent identity, session scope, tab ownership을 검증한다.

책임:

- agent identity 검증
- command schema validation
- session ownership 검증
- tab group/page lease 검증
- domain allow/deny 결정
- sensitive data redaction
- audit event 생성

위험 동작에 대한 최종 판단은 에이전트가 담당한다. 확장은 권한과 소유권을
검증하고, 페이지/요소의 risk hint만 반환한다.

### Tab Group Manager

Chrome tab group을 session의 시각적/조작 단위로 관리한다.

책임:

- session tab group 생성 또는 재연결
- group title/color 지정
- session에서 만든 탭을 group에 추가
- claim한 기존 탭을 group에 편입
- group collapse/expand 상태 관리
- group이 사용자에 의해 변경/해제될 때 session metadata 동기화
- session 종료 시 group cleanup 또는 handoff 처리

### Content Script Backend

기본 실행 백엔드다. 실제 웹 페이지와 상호작용하되, page content를 신뢰하지
않는다.

책임:

- DOM/a11y snapshot 생성
- element uid 생성과 stale 검증
- click/fill/scroll/key action
- page metadata 읽기
- risk hint 생성
- content-script 범위 내 screenshot 보조 정보 제공

### Debugger Backend

초기 버전에 포함되는 고권한 백엔드다. `debugger` 권한으로 session-owned tab에
attach해 CDP-like 기능을 제공한다.

책임:

- console/network/performance read 강화
- CDP `Input`, `Page`, `Runtime`, `Network` 등 허용 domain 명령 실행
- attach/detach lifecycle 관리
- session end, tab release, group cleanup 시 detach

### Artifact Store

스크린샷, trace, HAR-like log, snapshot dump 같은 큰 결과물을 저장하거나
전달한다.

구현 옵션:

- adapter가 있는 경우 파일 artifact로 저장하고 path/resource URI 반환
- extension-only WebSocket의 경우 chunked artifact로 agent에 전송
- native messaging에서는 메시지 크기 제한을 고려해 큰 artifact는 adapter 파일로 저장

## 데이터 흐름

### Multi-agent session start

```mermaid
sequenceDiagram
  participant Agent
  participant Adapter
  participant Extension
  participant Session
  participant Tabs
  Agent->>Adapter: connect(clientName)
  Adapter->>Extension: bridge.connect (auto, loopback)
  Extension->>Extension: record client, negotiate version
  Agent->>Extension: browser.start_session
  Extension->>Session: create session metadata
  Session-->>Extension: sessionId + logical tabGroup
  Extension-->>Agent: session ready
  Agent->>Extension: browser.new_page(sessionId)
  Extension->>Tabs: chrome.tabs.create
  Extension->>Tabs: chrome.tabs.group / chrome.tabGroups.update
  Tabs-->>Extension: tabId + groupId
  Extension-->>Agent: pageId + tabGroupId
```

### Snapshot-first action

```mermaid
sequenceDiagram
  participant Agent
  participant Extension
  participant Guard
  participant Session
  participant ContentScript
  Agent->>Extension: take_snapshot(sessionId, pageId)
  Extension->>Guard: verify session/page ownership
  Guard-->>Extension: allow
  Extension->>Session: snapshot request
  Session->>ContentScript: collect DOM/a11y snapshot
  ContentScript-->>Session: snapshotId + element uids
  Session-->>Extension: normalized snapshot
  Extension-->>Agent: snapshot
  Agent->>Extension: click(sessionId, pageId, uid, snapshotId)
  Extension->>Guard: verify session/page ownership
  Guard-->>Extension: allow
  Extension->>Session: enqueue click
  Session->>ContentScript: resolve uid and click
  ContentScript-->>Session: action result
  Session-->>Extension: result
  Extension-->>Agent: result
```

## Backend selection

Default:

- `mode=extension-tab` uses Content Script Backend for session-owned tabs.
- `mode=extension-debugger` uses Debugger Backend for session-owned tabs.

Rules:

- Extension Tab Mode is the product default.
- Extension Debugger Mode is included in the initial version and may be used for richer read/action support.
- Every command must include `sessionId` unless it creates or lists sessions.
- Every page action must include both `sessionId` and `pageId`.
- A Chrome tab may be leased to only one active session at a time.
- If two agents try to claim the same tab, the second request returns a conflict error.
- Commands run on leased tabs even when the tab or its window is inactive or in the background.
- Command execution must not force the target tab/window to the foreground or steal user focus.

## Session model

Every session has:

- `sessionId`
- `agentId`
- `clientName`
- `connectionId`
- `mode`
- `status`
- `tabGroupId`
- `tabGroupTitle`
- `tabGroupColor`
- `windowId`
- `pageIds`
- `createdAt`
- `lastActionAt`
- `expiresAt`

Session states:

- `pending`: session exists but has no Chrome tab group yet
- `active`: session can accept commands
- `paused`: user or extension paused command execution
- `finalizing`: cleanup is in progress
- `finalized`: no further action allowed

Rules:

- Session starts as `pending`.
- The first created or claimed tab materializes the Chrome tab group.
- Session tab group title should include client name and short session id.
- Session tab group color should be deterministic per agent or session.
- Session metadata must survive MV3 service worker restart.
- Ending a session closes agent-created tabs unless kept.
- Claimed user tabs are released unless the user chooses group handoff.

## Page model

Every controllable page has:

- `pageId`
- `sessionId`
- `backend`
- `chromeTabId`
- `tabGroupId`
- `origin`
- `url`
- `title`
- `createdByAgent`
- `claimedFromUser`
- `leaseStatus`
- `latestSnapshotId`
- `debuggerAttached`
- `createdAt`
- `lastActionAt`

## Tab group lifecycle

States:

- `logical`: session has metadata but no browser group yet
- `materialized`: Chrome tab group exists
- `detached`: user moved tabs out of the group
- `handoff`: group remains for user continuation
- `closed`: group became empty or was removed

Rules:

- Agent-created tabs are always placed in the session group.
- Claimed tabs are moved into the session group by default.
- If moving a claimed tab would disrupt the user, the command may set `preserveGroup=true`
  and track the tab as an external lease.
- Tab group changes by the user must update session metadata.
- Empty groups are treated as closed and the session becomes finalized unless kept.
- Group cleanup must detach debugger sessions and release page leases.

## Concurrency rules

- Different sessions may run commands concurrently.
- Commands for the same page are serialized.
- Commands that mutate the same tab group are serialized per session.
- Serialization은 작은 FIFO mutex로 구현한다 (per-page, per-tab-group). 무거운
  스케줄러를 두지 않는다 — `acquire()`가 Disposable guard를 반환하는 수준이면 충분.
- A session has a max pending command limit.
- A disconnected agent does not receive new events, but its session may remain paused or expire.
- Reconnecting with the same agent identity may resume non-finalized sessions.

## MV3 lifecycle constraints

The service worker may be suspended. Therefore:

- durable session metadata is stored in `chrome.storage.session` or equivalent
- active ports are rehydrated after reconnect where possible
- tab group and tab ids are reconciled on startup
- no ownership decision depends only on in-memory state
- content scripts must tolerate reconnect and stale snapshot invalidation
