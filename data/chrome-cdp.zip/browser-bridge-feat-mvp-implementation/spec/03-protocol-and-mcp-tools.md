# 03. Protocol And Agent Tools

## Design principles

Tool/protocol 설계는 chrome-devtools-mcp의 design-principles를 기준으로 삼는다
(상세 매핑: [reference/guide.md §1.1](../reference/guide.md)).

- **Agent-Agnostic** — 하나의 command 프로토콜, 여러 transport(MCP/WS/Native). 특정 표준에 묶이지 않는다.
- **Token-Optimized** — raw dump 대신 의미 요약. snapshot element cap + truncation warning([07 §Performance targets](07-test-and-quality-gates.md)).
- **Small, Deterministic Blocks** — magic 버튼 대신 조합 가능한 작은 `browser.*` tool.
- **Self-Healing Errors** — 에러는 원인 + 다음 행동을 담는다(아래 §Error codes).
- **Reference over Value** — 큰 결과물은 raw가 아니라 artifact path/URI([05](05-local-bridge-and-cdp-backend.md)).
- **Progressive Complexity** — 기본은 단순, power user용 옵션 인자(`verbose`, `includeSnapshot` 등).

## Tool definition conventions

각 tool은 선언적으로 정의한다: `{ name, description, annotations, schema(zod), handler }`.

- `annotations.readOnlyHint`로 read-only 여부를 명시 → [02 §Permission tiers](02-security-permissions.md) Tier 0과 매핑.
- **page-scoped tool은 `sessionId` + `pageId`가 둘 다 필요**하다. 핸들러 진입 전에
  ownership을 강제하는 헬퍼(`definePageTool` 류)를 두어 검증을 누락할 수 없게 한다.
- 공유 schema 조각(`pageIdSchema`, `timeoutSchema` 등)을 재사용하고, zod transform으로
  입력을 정규화한다(예: `timeout<=0 → undefined`).
- 핸들러는 값을 직접 return하지 않고 **응답 빌더**로 조립한다
  (`appendLine`/`includeSnapshot`/`attachArtifact`). 이렇게 하면
  `{ ok, result, warnings, auditId }` envelope에 warnings/risk hints/audit을 일관되게 누적한다.

## Protocol shape

The extension exposes one transport-independent command protocol. MCP tools,
Native Messaging, and development WebSocket all map to the same command names
and response envelope.

Every tool response should include:

```json
{
  "ok": true,
  "sessionId": "sess_...",
  "pageId": "page_...",
  "result": {},
  "warnings": [],
  "auditId": "audit_..."
}
```

Errors should include:

```json
{
  "ok": false,
  "error": {
    "code": "TAB_ALREADY_LEASED",
    "message": "This tab is already leased by another active session.",
    "details": {}
  }
}
```

Transport messages should include:

```json
{
  "id": "msg_123",
  "version": "0.1.0",
  "type": "browser.click",
  "sessionId": "sess_123",
  "payload": {}
}
```

## Ids

- `sessionId`: one agent connection or browser work session
- `agentId`: one paired agent/client identity
- `tabGroupId`: one Chrome tab group owned by a session
- `pageId`: one browser page/tab lease
- `snapshotId`: one captured DOM/a11y state
- `uid`: element id valid only for a matching snapshot
- `artifactId`: screenshot/trace/log artifact
- `auditId`: policy/action log event
- `connectionId`: extension-agent transport connection

## Snapshot contract

`browser.take_snapshot` returns a normalized accessibility-first tree.

Required fields:

```json
{
  "snapshotId": "snap_123",
  "pageId": "page_123",
  "url": "https://example.com",
  "title": "Example",
  "capturedAt": "2026-06-06T00:00:00.000Z",
  "source": "untrusted_page",
  "elements": [
    {
      "uid": "el_1",
      "role": "button",
      "name": "Submit",
      "text": "Submit",
      "tag": "button",
      "visible": true,
      "enabled": true,
      "bounds": { "x": 10, "y": 20, "width": 80, "height": 32 },
      "attributes": {
        "type": "submit"
      },
      "riskHints": ["submit"]
    }
  ]
}
```

Rules:

- `uid` must be stable only within the snapshot (`${snapshotId}_<n>` form, backed by a uid→node map).
- `click` and `fill` must reject stale `snapshotId` unless `allowStale=true`.
- On uid resolution, re-check that the resolved node's role/name/tag still roughly
  matches the snapshot entry; if not, return `SNAPSHOT_STALE` or `ELEMENT_NOT_FOUND`.
- Hidden elements are excluded unless `includeHidden=true` and policy allows it.
- Password/input values are redacted.
- The snapshot should prefer role/name/label over brittle CSS paths (a11y-tree first).
- Snapshot content is always untrusted for policy purposes.

## Agent tools

Rules:

- Session management tools operate on `sessionId`.
- Page tools must include both `sessionId` and `pageId`.
- The extension rejects a page command if the page does not belong to the session.
- A page may belong to only one active session.

### `browser.get_capabilities`

Returns extension, transport, backend, and permission state.

Acceptance criteria:

- Includes protocol version.
- Includes extension version.
- Lists supported backends: `extension-tab`, `extension-debugger`.
- Reports whether native host, debugger permission, and tabGroups permission are available.
- Does not expose secrets or transport credentials.

### `browser.list_sessions`

Lists sessions visible to the connected agent.

Acceptance criteria:

- Returns active, paused, and recently finalized sessions for the agent.
- Includes `sessionId`, `clientName`, `status`, `tabGroupId`, `tabGroupTitle`,
  `tabGroupColor`, `pageCount`, and `lastActionAt`.
- Does not expose sessions owned by another agent unless operator/debug mode allows it.

### `browser.get_session`

Returns one session and its page/tab group summary.

Acceptance criteria:

- Requires the session to belong to the connected agent.
- Includes session state and page summaries.
- Reports whether the Chrome tab group is materialized, detached, handed off, or closed.

### `browser.pause_session`

Pauses command execution for one session.

Acceptance criteria:

- Requires session ownership.
- Leaves tabs open and leases intact.
- Rejects new page actions with `SESSION_PAUSED`.
- Updates popup/side panel session status.

### `browser.resume_session`

Resumes a paused session.

Acceptance criteria:

- Requires session ownership.
- Reconciles tab group and page lease state before accepting commands.
- Rejects finalized sessions.

### `browser.start_session`

Creates a browser automation session.

Input:

```json
{
  "mode": "extension-tab",
  "clientName": "codex",
  "sessionLabel": "localhost QA",
  "allowedDomains": ["localhost", "example.com"],
  "tabScope": "agent-created-only",
  "tabGroup": {
    "title": "BB · codex · localhost QA",
    "color": "cyan",
    "collapsed": false
  }
}
```

Acceptance criteria:

- Creates session id.
- Verifies paired agent connection.
- Selects backend.
- Applies default session scope.
- Creates logical session metadata.
- Does not require a browser tab group until the first tab is created or claimed.
- In extension-tab mode, prepares tab lease policy.
- In extension-debugger mode, verifies debugger permission.
- Returns `sessionId`, session status, and planned tab group metadata.

### `browser.end_session`

Ends a session and finalizes pages.

Input:

```json
{
  "sessionId": "sess_123",
  "keep": [
    { "pageId": "page_1", "status": "handoff", "reason": "waiting for user login" }
  ]
}
```

Acceptance criteria:

- Agent-created pages close unless kept.
- Claimed user tabs release control.
- Debugger attachments detach.
- Session tab group is closed when empty.
- Kept pages can leave the group in `handoff` state.
- No pending command remains active.

### `browser.new_page`

Opens a new agent-controlled tab.

Input:

```json
{
  "sessionId": "sess_123",
  "url": "https://example.com",
  "waitUntil": "domcontentloaded"
}
```

Acceptance criteria:

- Validates URL.
- Applies domain policy.
- Uses `chrome.tabs.create` in extension-tab mode.
- Materializes the session tab group if needed.
- Adds the new tab to the session tab group.
- Creates page id and tab lease.
- Waits for configured load state where available.
- Returns page metadata and `tabGroupId`.

### `browser.list_tabs`

Lists the user's open tabs for claim selection (codex `openTabs` 대응). Read-only.

Acceptance criteria:

- Returns `tabId`, `url`, `title`, `windowId`, `active`, `tabGroupId?`, `leased`.
- `leased=true` means another session already controls the tab.
- The agent must claim only tab ids returned here (id 추측 금지).

### `browser.claim_tab`

Claims an existing user tab — the active tab, or a specific `tabId` from
`browser.list_tabs` (codex `claimTab(tab)` 대응).

Input:

```json
{
  "sessionId": "sess_123",
  "strategy": "by-id",
  "tabId": 42,
  "moveToSessionGroup": true,
  "preserveExistingGroup": false
}
```

Acceptance criteria:

- Requires tab scope policy.
- Requires the tab to be unleased by another active session.
- Materializes the session tab group if needed.
- Moves the claimed tab into the session tab group unless `preserveExistingGroup=true`.
- Returns title/url and lease status.
- Does not reload the tab.
- Makes lease visible in popup/side panel.

### `browser.navigate`

Navigates (or reloads) a leased page (chrome-devtools `navigate_page`, codex
`goto`/`reload` 대응).

Input:

```json
{ "sessionId": "sess_123", "pageId": "page_123", "url": "https://example.com/x", "reload": false }
```

Acceptance criteria:

- Requires session ownership, active session, and a leased page.
- Applies domain policy for navigation (skipped for `reload=true`).
- Invalidates the page's latest snapshot.
- Returns the resulting url/title.

### `browser.release_tab`

Releases a claimed tab without closing it.

Acceptance criteria:

- Removes page lease.
- Detaches debugger if attached.
- Removes the tab from session ownership.
- Finalizes the session if no pages remain and no keep policy is set.
- Rejects future action for the page id.
- Updates extension UI.

### `browser.take_snapshot`

Captures current page state.

Input:

```json
{
  "sessionId": "sess_123",
  "pageId": "page_123",
  "includeBounds": true,
  "includeRiskHints": true
}
```

Acceptance criteria:

- Requires session ownership.
- Requires active lease.
- Returns snapshot id.
- Includes interactable elements.
- Redacts sensitive values.
- Marks risk hints for submit/upload/password/payment-like elements.

### `browser.take_screenshot`

Captures screenshot artifact.

Input:

```json
{
  "sessionId": "sess_123",
  "pageId": "page_123",
  "fullPage": false,
  "uid": "el_1"
}
```

Acceptance criteria:

- Requires session ownership.
- Requires active lease and screenshot permission path.
- Saves artifact through adapter when available.
- Returns artifact id and path/resource URI or chunk metadata.
- Does not return large binary by default.

### `browser.click`

Clicks an element by snapshot uid.

Input:

```json
{
  "sessionId": "sess_123",
  "pageId": "page_123",
  "snapshotId": "snap_123",
  "uid": "el_1",
  "includeSnapshot": true
}
```

Acceptance criteria:

- Requires session ownership.
- Verifies snapshot id and uid.
- Computes risk tier.
- Returns risk hints for risky targets.
- Performs click.
- Returns navigation/result metadata.
- Optionally returns updated snapshot.

### `browser.fill`

Fills an input by snapshot uid.

Input:

```json
{
  "sessionId": "sess_123",
  "pageId": "page_123",
  "snapshotId": "snap_123",
  "uid": "el_input",
  "value": "hello"
}
```

Acceptance criteria:

- Requires session ownership.
- Returns risk hints for password/OTP/API-key-like fields.
- Clears existing value before typing unless `append=true`.
- Verifies final visible value when safe.

### `browser.fill_form`

Fills multiple fields as one batch operation.

Acceptance criteria:

- Requires session ownership.
- Evaluates all fields before writing any field.
- Returns aggregate risk hints before writing fields when requested.
- Returns per-field result.

### `browser.press_key`

Presses keyboard key or chord.

Acceptance criteria:

- Requires session ownership.
- Allows navigation keys by default.
- Treats Enter inside a form as possible submit.
- Rejects unsupported raw key sequences.

### `browser.scroll`

Scrolls page or element.

Acceptance criteria:

- Requires session ownership.
- Supports page scroll.
- Supports element scroll by uid.
- Returns new scroll position if available.

### `browser.wait_for`

Waits for text, URL, selector uid invalidation, load state, or network idle.

Acceptance criteria:

- Requires session ownership.
- Has timeout.
- Returns the condition that matched.
- Does not busy-loop.

### `browser.list_console_messages`

Returns console messages.

Acceptance criteria:

- Requires session ownership.
- Extension-tab mode returns messages collected by injected/content script where available.
- Extension-debugger mode can use CDP Console/Log/Runtime events.
- Collection keeps only the most recent navigations per page (bounded buffer), not unbounded history.
- Supports level filter.
- Supports limit.
- Includes timestamp, level, message, source URL when available.

### `browser.list_network_requests`

Returns network request summaries.

Acceptance criteria:

- Requires session ownership.
- Extension-tab mode may be limited to page Performance APIs or approved instrumentation.
- Extension-debugger mode can use CDP Network events.
- Collection keeps only the most recent navigations per page (bounded buffer), not unbounded history.
- Redacts headers and sensitive query params.
- Includes method, URL origin/path, status, resource type, duration when available.

### `browser.evaluate_script`

Runs constrained read-only probes in page context.

Acceptance criteria:

- Requires session ownership.
- Default mode must be read-only and preferably limited to predefined probes.
- Mutating evaluation requires elevated permission and explicit agent request.
- Page-world script injection is not required for MVP.
- Return values are size-limited.
- Errors are captured with stack summary.

## Error codes

`message`는 self-healing 톤으로 작성한다 — 원인 + 에이전트가 취할 다음 행동을
담는다(예: "element did not become interactive within the configured timeout; take a
fresh snapshot and retry"). 기계 판별용 `code`와 분기 정보는 `details`에 둔다.

- `AGENT_NOT_PAIRED`
- `TRANSPORT_UNAVAILABLE`
- `BACKEND_UNAVAILABLE`
- `NATIVE_HOST_UNAVAILABLE`
- `BROWSER_NOT_RUNNING`
- `EXTENSION_NOT_CONNECTED`
- `DEBUGGER_PERMISSION_REQUIRED`
- `SESSION_NOT_FOUND`
- `SESSION_PAUSED`
- `SESSION_FINALIZED`
- `TAB_ALREADY_LEASED`
- `TAB_GROUP_UNAVAILABLE`
- `TAB_NOT_LEASED`
- `POLICY_DENIED`
- `SNAPSHOT_STALE`
- `ELEMENT_NOT_FOUND`
- `ELEMENT_NOT_INTERACTABLE`
- `NAVIGATION_TIMEOUT`
- `ACTION_TIMEOUT`
- `ARTIFACT_WRITE_FAILED`
- `COMMAND_LIMIT_EXCEEDED`
- `UNSUPPORTED_ACTION`

## Versioning

- Protocol version should be exposed by `browser.get_capabilities`.
- Breaking tool schema changes require major version bump.
- Experimental tools must be prefixed with `experimental_`.
