/**
 * Tool names and a few core payload shapes.
 * Full tool contracts live in spec/03-protocol-and-mcp-tools.md §Agent tools.
 * Payloads that are not needed for the skeleton are left as `unknown`.
 */

export const TOOL_NAMES = [
  "browser.get_capabilities",
  "browser.list_sessions",
  "browser.get_session",
  "browser.pause_session",
  "browser.resume_session",
  "browser.start_session",
  "browser.end_session",
  "browser.new_page",
  "browser.list_tabs",
  "browser.claim_tab",
  "browser.navigate",
  "browser.release_tab",
  "browser.take_snapshot",
  "browser.take_screenshot",
  "browser.click",
  "browser.click_at",
  "browser.hover",
  "browser.fill",
  "browser.fill_form",
  "browser.type_text",
  "browser.press_key",
  "browser.scroll",
  "browser.drag",
  "browser.wait_for",
  "browser.list_console_messages",
  "browser.list_network_requests",
  "browser.evaluate_script",
  "browser.resize_page",
  "browser.emulate",
  "browser.handle_dialog",
  "browser.get_tab_id",
  "browser.list_pages",
  "browser.close_page",
  "browser.select_page",
  "browser.upload_file",
  "browser.list_webmcp_tools",
  "browser.execute_webmcp_tool",
  "browser.cdp_command",
  "browser.cdp_events",
] as const;

export type ToolName = (typeof TOOL_NAMES)[number];

export function isToolName(value: string): value is ToolName {
  return (TOOL_NAMES as readonly string[]).includes(value);
}

export type BackendMode = "extension-tab" | "extension-debugger";

export type TabScope = "agent-created-only" | "active-tab" | "domain-grant";

/** Input for `browser.start_session`. */
export interface StartSessionInput {
  mode: BackendMode;
  clientName: string;
  sessionLabel?: string;
  allowedDomains?: string[];
  tabScope?: TabScope;
  /** Opt in to the raw CDP passthrough (browser.cdp_command) for this session. */
  allowRawCdp?: boolean;
  tabGroup?: {
    title?: string;
    color?: string;
    collapsed?: boolean;
  };
}

/** Input for `browser.cdp_command` (raw Chrome DevTools Protocol passthrough). */
export interface CdpCommandInput {
  /** CDP method, e.g. "DOM.getDocument". */
  method: string;
  /** CDP params object for the method. */
  params?: Record<string, unknown>;
}

/** Input for `browser.cdp_events` (poll buffered raw CDP events). */
export interface CdpEventsInput {
  /** Return events with seq greater than this cursor (from a prior response). */
  since?: number;
  /** Only return these CDP event methods, e.g. ["Network.responseReceived"]. */
  methods?: string[];
  /** Max events to return (newest kept). */
  limit?: number;
}

/** A buffered raw CDP event from `browser.cdp_events`. */
export interface CdpEvent {
  seq: number;
  method: string;
  params: unknown;
}

/** Input for `browser.new_page`. */
export interface NewPageInput {
  url: string;
  waitUntil?: "load" | "domcontentloaded" | "networkidle";
}

/** Input for `browser.claim_tab`. */
export interface ClaimTabInput {
  strategy: "active-tab" | "by-id";
  /** Required when strategy is "by-id"; from a prior browser.list_tabs result. */
  tabId?: number;
  moveToSessionGroup?: boolean;
  preserveExistingGroup?: boolean;
}

/** Input for `browser.navigate`. */
export interface NavigateInput {
  url: string;
  /** Reload instead of navigating (use when already on the URL). */
  reload?: boolean;
}

/** Input for `browser.evaluate_script`. Runs in the page (MAIN) world via CDP. */
export interface EvaluateScriptInput {
  /** A JS expression; its value (await-ed) is returned, JSON-serialized. */
  expression: string;
}

/** Input for `browser.resize_page` (CDP device-metrics override). */
export interface ResizePageInput {
  width: number;
  height: number;
  deviceScaleFactor?: number;
  mobile?: boolean;
  /** Clear the override instead of setting it. */
  reset?: boolean;
}

/** Input for `browser.emulate` (CDP device/network/CPU emulation). */
export interface EmulateInput {
  width?: number;
  height?: number;
  mobile?: boolean;
  network?: {
    offline?: boolean;
    latencyMs?: number;
    downloadKbps?: number;
    uploadKbps?: number;
  };
  /** 1 = no throttling, 4 = 4× slower, etc. */
  cpuThrottlingRate?: number;
  /** Clear all emulation overrides. */
  reset?: boolean;
}

/** Input for `browser.handle_dialog` (accept/dismiss a JS dialog via CDP). */
export interface HandleDialogInput {
  accept: boolean;
  /** Text for a `prompt()` dialog when accepting. */
  promptText?: string;
}

/** Input for `browser.upload_file` (CDP `DOM.setFileInputFiles`). */
export interface UploadFileInput {
  /** uid of the <input type=file> from the current snapshot. */
  uid: string;
  /** Absolute local file paths to attach (must exist on the browser machine). */
  files: string[];
  snapshotId?: string;
}

/** Input for `browser.execute_webmcp_tool`. */
export interface ExecuteWebmcpToolInput {
  toolName: string;
  /** Parameters for the tool: an object, or a JSON-stringified object. */
  input?: string | Record<string, unknown>;
}

/** A WebMCP tool the page exposes, from `browser.list_webmcp_tools`. */
export interface WebmcpToolSummary {
  name: string;
  description: string;
  inputSchema: unknown;
}

/** A page in a session, returned by `browser.list_pages`. */
export interface PageSummary {
  pageId: string;
  url: string;
  title: string;
  leaseStatus: LeaseStatus;
  active?: boolean;
}

/** A user tab returned by `browser.list_tabs` for claim selection. */
export interface TabSummary {
  tabId: number;
  url: string;
  title: string;
  windowId: number;
  active: boolean;
  tabGroupId?: number;
  leased: boolean;
}

export type LeaseStatus = "leased" | "released";

export interface ElementBounds {
  x: number;
  y: number;
  width: number;
  height: number;
}

export type RiskHint = "submit" | "upload" | "password" | "payment";

export interface SnapshotElement {
  uid: string;
  role: string;
  name: string;
  text?: string;
  tag: string;
  visible: boolean;
  enabled: boolean;
  bounds?: ElementBounds;
  attributes?: Record<string, string>;
  value?: string;
  valueRedacted?: boolean;
  riskHints?: RiskHint[];
}

export interface Snapshot {
  snapshotId: string;
  pageId: string;
  url: string;
  title: string;
  capturedAt: string;
  source: "untrusted_page";
  elements: SnapshotElement[];
  truncated?: boolean;
}

export interface TakeSnapshotInput {
  includeBounds?: boolean;
  includeRiskHints?: boolean;
  includeHidden?: boolean;
}

export interface ConsoleMessage {
  level: string;
  text: string;
  url?: string;
  timestamp: number;
}

export interface NetworkRequestSummary {
  method: string;
  url: string;
  status?: number;
  resourceType?: string;
  durationMs?: number;
}

/** Result of a page action (click/fill/...). */
export interface ActionResult {
  url: string;
  title: string;
  navigated?: boolean;
  riskHints?: RiskHint[];
  value?: string;
  matched?: string;
}

export interface ArtifactMetadata {
  artifactId: string;
  sessionId: string;
  pageId: string;
  tabGroupId?: number;
  kind: "screenshot" | "network" | "console" | "trace" | "snapshot";
  contentType: string;
  byteLength: number;
  path?: string;
}

/** Page view returned by page tools. */
export interface PageInfo {
  pageId: string;
  sessionId: string;
  url: string;
  title: string;
  tabGroupId?: number;
  leaseStatus: LeaseStatus;
  createdByAgent: boolean;
  claimedFromUser: boolean;
}

export interface Capabilities {
  protocolVersion: string;
  extensionVersion: string;
  backends: BackendMode[];
  nativeHostAvailable: boolean;
  debuggerPermission: boolean;
  tabGroupsPermission: boolean;
}

export type SessionStatus = "pending" | "active" | "paused" | "finalizing" | "finalized";

export type TabGroupState = "logical" | "materialized" | "detached" | "handoff" | "closed";

export interface SessionTabGroupInfo {
  tabGroupId?: number;
  windowId?: number;
  title: string;
  color: string;
  state: TabGroupState;
}

/** Compact session view for `browser.list_sessions`. */
export interface SessionSummary {
  sessionId: string;
  clientName: string;
  status: SessionStatus;
  tabGroupId?: number;
  tabGroupTitle: string;
  tabGroupColor: string;
  pageCount: number;
  lastActionAt: string;
}

/** Full session view for `browser.get_session` / `browser.start_session`. */
export interface SessionDetail extends SessionSummary {
  agentId: string;
  mode: BackendMode;
  sessionLabel?: string;
  allowedDomains: string[];
  tabScope: TabScope;
  allowRawCdp?: boolean;
  tabGroup: SessionTabGroupInfo;
  pageIds: string[];
  createdAt: string;
}
