/**
 * Transport-independent message and response envelopes.
 * See spec/03-protocol-and-mcp-tools.md §Protocol shape.
 */

import type { AuditId, PageId, SessionId } from "./ids.js";
import type { ProtocolError } from "./errors.js";

export const PROTOCOL_VERSION = "0.1.0";

/** A request flowing from agent/adapter to the extension. */
export interface TransportMessage<P = unknown> {
  id: string;
  version: string;
  type: string;
  sessionId?: SessionId;
  pageId?: PageId;
  payload: P;
}

export interface SuccessResponse<R = unknown> {
  ok: true;
  sessionId?: SessionId;
  pageId?: PageId;
  result: R;
  warnings: string[];
  auditId?: AuditId;
}

export interface ErrorResponse {
  ok: false;
  error: ProtocolError;
}

export type ToolResponse<R = unknown> = SuccessResponse<R> | ErrorResponse;

/** Wire response that echoes the request `id` so callers can match it. */
export interface TransportResponse<R = unknown> {
  id: string;
  version: string;
  response: ToolResponse<R>;
}

export function ok<R>(result: R, extra: Partial<Omit<SuccessResponse<R>, "ok" | "result">> = {}): SuccessResponse<R> {
  return { ok: true, result, warnings: [], ...extra };
}

export function err(error: ProtocolError): ErrorResponse {
  return { ok: false, error };
}

export function makeResponse(id: string, response: ToolResponse): TransportResponse {
  return { id, version: PROTOCOL_VERSION, response };
}

export function isTransportResponse(value: unknown): value is TransportResponse {
  return (
    typeof value === "object" &&
    value !== null &&
    typeof (value as { id?: unknown }).id === "string" &&
    "response" in value
  );
}
