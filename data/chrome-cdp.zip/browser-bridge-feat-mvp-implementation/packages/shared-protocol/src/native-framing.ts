/**
 * Chrome native messaging framing: a 4-byte length prefix (native byte order;
 * little-endian on common platforms) followed by UTF-8 JSON. Only the native
 * host needs this — the extension side is framed by Chrome itself.
 */

export function encodeFrame(message: unknown): Uint8Array {
  const json = new TextEncoder().encode(JSON.stringify(message));
  const frame = new Uint8Array(4 + json.length);
  new DataView(frame.buffer).setUint32(0, json.length, true);
  frame.set(json, 4);
  return frame;
}

/** Accumulates byte chunks and yields complete decoded messages. */
export class FrameDecoder {
  private buffer: Uint8Array = new Uint8Array(0);

  push(chunk: Uint8Array): unknown[] {
    this.buffer = concat(this.buffer, chunk);
    const messages: unknown[] = [];

    while (this.buffer.length >= 4) {
      const length = new DataView(this.buffer.buffer, this.buffer.byteOffset, 4).getUint32(0, true);
      if (this.buffer.length < 4 + length) break;
      const jsonBytes = this.buffer.subarray(4, 4 + length);
      messages.push(JSON.parse(new TextDecoder().decode(jsonBytes)));
      this.buffer = this.buffer.subarray(4 + length);
    }
    return messages;
  }
}

function concat(a: Uint8Array, b: Uint8Array): Uint8Array {
  const out = new Uint8Array(a.length + b.length);
  out.set(a, 0);
  out.set(b, a.length);
  return out;
}
