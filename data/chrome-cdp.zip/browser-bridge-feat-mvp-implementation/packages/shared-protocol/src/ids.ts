/**
 * Branded id types and generators.
 *
 * Id kinds follow spec/03-protocol-and-mcp-tools.md §Ids. Branding keeps the
 * different id namespaces from being accidentally mixed at compile time.
 */

export type Brand<T, B extends string> = T & { readonly __brand: B };

export type SessionId = Brand<string, "SessionId">;
export type AgentId = Brand<string, "AgentId">;
export type TabGroupId = Brand<string, "TabGroupId">;
export type PageId = Brand<string, "PageId">;
export type SnapshotId = Brand<string, "SnapshotId">;
export type Uid = Brand<string, "Uid">;
export type ArtifactId = Brand<string, "ArtifactId">;
export type AuditId = Brand<string, "AuditId">;
export type ConnectionId = Brand<string, "ConnectionId">;

/** Generate an opaque, prefixed id. */
function randomId(prefix: string): string {
  const uuid = globalThis.crypto.randomUUID().replace(/-/g, "").slice(0, 12);
  return `${prefix}_${uuid}`;
}

export const newSessionId = (): SessionId => randomId("sess") as SessionId;
export const newAgentId = (): AgentId => randomId("agent") as AgentId;

/**
 * Derive a stable agent id from a client name. Deterministic (no randomness) so a
 * client that reconnects with the same name maps to the same agent and reclaims
 * its sessions. See task/03 §식별·소유권 모델.
 */
export function agentIdFromClientName(clientName: string): AgentId {
  const slug =
    clientName
      .trim()
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "") || "anon";
  return `agent_${slug}` as AgentId;
}
export const newPageId = (): PageId => randomId("page") as PageId;
export const newSnapshotId = (): SnapshotId => randomId("snap") as SnapshotId;
export const newArtifactId = (): ArtifactId => randomId("artifact") as ArtifactId;
export const newAuditId = (): AuditId => randomId("audit") as AuditId;
export const newConnectionId = (): ConnectionId => randomId("conn") as ConnectionId;
