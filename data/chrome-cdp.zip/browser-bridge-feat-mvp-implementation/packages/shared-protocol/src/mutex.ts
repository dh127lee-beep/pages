/**
 * Minimal FIFO mutex for serializing per-page / per-group commands.
 * `const release = await mutex.acquire(); try { ... } finally { release(); }`.
 * See spec/01 §Concurrency rules and reference/guide.md §1.5.
 */

export class Mutex {
  private tail: Promise<void> = Promise.resolve();

  async acquire(): Promise<() => void> {
    let release!: () => void;
    const next = new Promise<void>((resolve) => {
      release = resolve;
    });
    const previous = this.tail;
    this.tail = previous.then(() => next);
    await previous;
    return release;
  }
}
