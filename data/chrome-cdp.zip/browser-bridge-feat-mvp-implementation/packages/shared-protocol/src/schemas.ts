/**
 * Runtime validation schemas. Skeleton covers the transport envelope; per-tool
 * payload schemas are added incrementally alongside their implementations.
 */

import { z } from "zod";

export const transportMessageSchema = z.object({
  id: z.string().min(1),
  version: z.string().min(1),
  type: z.string().min(1),
  sessionId: z.string().optional(),
  pageId: z.string().optional(),
  payload: z.unknown(),
});

export type TransportMessageInput = z.infer<typeof transportMessageSchema>;

/** Control (handshake/heartbeat) message schemas — no token fields. */
export const helloSchema = z.object({
  type: z.literal("bridge.hello"),
  protocolVersion: z.string().min(1),
  extensionVersion: z.string().min(1),
});

export const identifySchema = z.object({
  type: z.literal("bridge.identify"),
  protocolVersion: z.string().min(1),
  clientName: z.string().min(1),
  clientVersion: z.string().min(1),
});

export const welcomeSchema = z.object({
  type: z.literal("bridge.welcome"),
  protocolVersion: z.string().min(1),
  connectionId: z.string().min(1),
});

export const pingSchema = z.object({ type: z.literal("bridge.ping"), nonce: z.string() });
export const pongSchema = z.object({ type: z.literal("bridge.pong"), nonce: z.string() });

export const controlMessageSchema = z.discriminatedUnion("type", [
  helloSchema,
  identifySchema,
  welcomeSchema,
  pingSchema,
  pongSchema,
  z.object({
    type: z.literal("bridge.reject"),
    code: z.enum(["VERSION_MISMATCH", "MALFORMED"]),
    message: z.string(),
  }),
]);

export const newPageSchema = z.object({
  url: z.string().min(1),
  waitUntil: z.enum(["load", "domcontentloaded", "networkidle"]).optional(),
});

export const claimTabSchema = z.object({
  strategy: z.enum(["active-tab", "by-id"]).default("active-tab"),
  tabId: z.number().int().optional(),
  moveToSessionGroup: z.boolean().optional(),
  preserveExistingGroup: z.boolean().optional(),
});

export const navigateSchema = z.object({
  url: z.string().min(1),
  reload: z.boolean().optional(),
});

export const startSessionSchema = z.object({
  mode: z.enum(["extension-tab", "extension-debugger"]),
  clientName: z.string().min(1),
  sessionLabel: z.string().optional(),
  allowedDomains: z.array(z.string()).optional(),
  tabScope: z.enum(["agent-created-only", "active-tab", "domain-grant"]).optional(),
  /** Opt in to the raw CDP passthrough (browser.cdp_command) for this session. */
  allowRawCdp: z.boolean().optional(),
  tabGroup: z
    .object({
      title: z.string().optional(),
      color: z.string().optional(),
      collapsed: z.boolean().optional(),
    })
    .optional(),
});
