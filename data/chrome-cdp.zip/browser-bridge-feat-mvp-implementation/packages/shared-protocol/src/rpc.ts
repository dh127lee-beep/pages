/**
 * Transport-agnostic RPC client: matches responses to requests by id, with a
 * per-message timeout. Used by the side that issues tool requests (the adapter).
 * See task/02-agent-bridge-transport.md §envelope 라우팅.
 *
 * Never rejects — resolves with a normalized error envelope so callers always
 * receive a ToolResponse.
 */

import { PROTOCOL_VERSION, err, type ToolResponse, type TransportMessage, type TransportResponse } from "./envelopes.js";

/** Wire-level routing fields (ids are opaque strings on the transport). */
export interface RpcRoute {
  sessionId?: string;
  pageId?: string;
}

interface PendingEntry {
  resolve: (response: ToolResponse) => void;
  timer: ReturnType<typeof setTimeout>;
}

export const DEFAULT_RPC_TIMEOUT_MS = 30_000;

export class RpcClient {
  private seq = 0;
  private readonly pending = new Map<string, PendingEntry>();

  constructor(
    private readonly send: (message: TransportMessage) => void,
    private readonly timeoutMs: number = DEFAULT_RPC_TIMEOUT_MS,
  ) {}

  request(type: string, payload: unknown = {}, route: RpcRoute = {}): Promise<ToolResponse> {
    const id = `msg_${++this.seq}`;
    const message = { id, version: PROTOCOL_VERSION, type, payload, ...route } as TransportMessage;

    return new Promise<ToolResponse>((resolve) => {
      const timer = setTimeout(() => {
        this.pending.delete(id);
        resolve(
          err({
            code: "ACTION_TIMEOUT",
            message: `No response for ${type} within ${this.timeoutMs}ms; take a fresh state check and retry.`,
            details: { id, type },
          }),
        );
      }, this.timeoutMs);

      this.pending.set(id, { resolve, timer });
      this.send(message);
    });
  }

  /** Returns true if the response matched a pending request. Unmatched ones are ignored. */
  handleResponse(response: TransportResponse): boolean {
    const entry = this.pending.get(response.id);
    if (!entry) return false;
    clearTimeout(entry.timer);
    this.pending.delete(response.id);
    entry.resolve(response.response);
    return true;
  }

  /** Settle all in-flight requests with an error (e.g. on disconnect). */
  rejectAll(message = "Transport disconnected before a response arrived."): void {
    for (const entry of this.pending.values()) {
      clearTimeout(entry.timer);
      entry.resolve(err({ code: "TRANSPORT_UNAVAILABLE", message }));
    }
    this.pending.clear();
  }

  get inFlight(): number {
    return this.pending.size;
  }
}
