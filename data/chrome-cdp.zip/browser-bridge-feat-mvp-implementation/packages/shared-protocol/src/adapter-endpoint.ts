/**
 * Adapter-side endpoint shared by the dev WebSocket server and the native host.
 * Handles the handshake (replies to the extension's hello with identify, marks
 * ready on welcome, answers ping) and issues tool requests via RpcClient.
 * Transport-agnostic: the caller provides a `send` and feeds `handleIncoming`.
 */

import { isControlMessage, isProtocolCompatible, type ControlMessage } from "./control.js";
import { err, isTransportResponse, PROTOCOL_VERSION, type ToolResponse } from "./envelopes.js";
import { RpcClient, type RpcRoute } from "./rpc.js";

export interface AdapterEndpointOptions {
  clientName: string;
  clientVersion?: string;
  protocolVersion?: string;
  timeoutMs?: number;
  onConnected?: (connectionId: string) => void;
  onDisconnected?: () => void;
  onReject?: (message: string) => void;
}

export class AdapterEndpoint {
  private readonly rpc: RpcClient;
  private readonly protocolVersion: string;
  private ready = false;

  constructor(
    private readonly send: (message: unknown) => void,
    private readonly options: AdapterEndpointOptions,
  ) {
    this.protocolVersion = options.protocolVersion ?? PROTOCOL_VERSION;
    this.rpc = new RpcClient((message) => this.send(message), options.timeoutMs);
  }

  get connected(): boolean {
    return this.ready;
  }

  handleIncoming(raw: unknown): void {
    if (isControlMessage(raw)) {
      this.handleControl(raw);
      return;
    }
    if (isTransportResponse(raw)) {
      this.rpc.handleResponse(raw);
    }
  }

  request(type: string, payload: unknown = {}, route: RpcRoute = {}): Promise<ToolResponse> {
    if (!this.ready) {
      return Promise.resolve(
        err({ code: "EXTENSION_NOT_CONNECTED", message: "No extension is connected; start the extension and retry." }),
      );
    }
    return this.rpc.request(type, payload, route);
  }

  /** Call on transport disconnect. */
  reset(): void {
    this.ready = false;
    this.rpc.rejectAll();
    this.options.onDisconnected?.();
  }

  private handleControl(message: ControlMessage): void {
    switch (message.type) {
      case "bridge.hello": {
        if (!isProtocolCompatible(message.protocolVersion, this.protocolVersion)) {
          this.send({
            type: "bridge.reject",
            code: "VERSION_MISMATCH",
            message: `Extension protocol ${message.protocolVersion} is incompatible with ${this.protocolVersion}.`,
          });
          this.options.onReject?.("version mismatch");
          return;
        }
        this.send({
          type: "bridge.identify",
          protocolVersion: this.protocolVersion,
          clientName: this.options.clientName,
          clientVersion: this.options.clientVersion ?? this.protocolVersion,
        });
        return;
      }
      case "bridge.welcome":
        this.ready = true;
        this.options.onConnected?.(message.connectionId);
        return;
      case "bridge.ping":
        this.send({ type: "bridge.pong", nonce: message.nonce });
        return;
      default:
        return;
    }
  }
}
