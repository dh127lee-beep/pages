/**
 * Bridge control messages (handshake, heartbeat).
 * Auto-connect model: no pairing token. See spec/02 connection policy and
 * task/02-agent-bridge-transport.md.
 */

import type { ConnectionId } from "./ids.js";

/** Extension -> adapter, sent on connect. */
export interface BridgeHello {
  type: "bridge.hello";
  protocolVersion: string;
  extensionVersion: string;
}

/** Adapter -> extension, identifies the connecting client. */
export interface BridgeIdentify {
  type: "bridge.identify";
  protocolVersion: string;
  clientName: string;
  clientVersion: string;
}

/** Extension -> adapter, assigns a connection id once registered. */
export interface BridgeWelcome {
  type: "bridge.welcome";
  protocolVersion: string;
  connectionId: ConnectionId;
}

/** Either side -> the other, on handshake failure. */
export interface BridgeReject {
  type: "bridge.reject";
  code: "VERSION_MISMATCH" | "MALFORMED";
  message: string;
}

export interface BridgePing {
  type: "bridge.ping";
  nonce: string;
}

export interface BridgePong {
  type: "bridge.pong";
  nonce: string;
}

export type ControlMessage =
  | BridgeHello
  | BridgeIdentify
  | BridgeWelcome
  | BridgeReject
  | BridgePing
  | BridgePong;

export function isControlMessage(value: unknown): value is ControlMessage {
  return (
    typeof value === "object" &&
    value !== null &&
    typeof (value as { type?: unknown }).type === "string" &&
    (value as { type: string }).type.startsWith("bridge.")
  );
}

/**
 * Version compatibility. Major must match; during 0.x the minor is also breaking.
 * Malformed versions are treated as incompatible.
 */
export function isProtocolCompatible(a: string, b: string): boolean {
  const pa = parseVersion(a);
  const pb = parseVersion(b);
  if (!pa || !pb) return false;
  if (pa.major !== pb.major) return false;
  if (pa.major === 0) return pa.minor === pb.minor;
  return true;
}

function parseVersion(v: string): { major: number; minor: number } | undefined {
  const parts = v.split(".");
  const major = Number.parseInt(parts[0] ?? "", 10);
  const minor = Number.parseInt(parts[1] ?? "", 10);
  if (!Number.isInteger(major) || !Number.isInteger(minor)) return undefined;
  return { major, minor };
}
