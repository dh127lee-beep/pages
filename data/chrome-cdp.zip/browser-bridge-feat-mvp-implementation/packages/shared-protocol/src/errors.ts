/**
 * Protocol error codes. Mirrors spec/03-protocol-and-mcp-tools.md §Error codes.
 */

export const ERROR_CODES = [
  "AGENT_NOT_PAIRED",
  "TRANSPORT_UNAVAILABLE",
  "BACKEND_UNAVAILABLE",
  "NATIVE_HOST_UNAVAILABLE",
  "BROWSER_NOT_RUNNING",
  "EXTENSION_NOT_CONNECTED",
  "DEBUGGER_PERMISSION_REQUIRED",
  "SESSION_NOT_FOUND",
  "SESSION_PAUSED",
  "SESSION_FINALIZED",
  "TAB_ALREADY_LEASED",
  "TAB_GROUP_UNAVAILABLE",
  "TAB_NOT_LEASED",
  "POLICY_DENIED",
  "SNAPSHOT_STALE",
  "ELEMENT_NOT_FOUND",
  "ELEMENT_NOT_INTERACTABLE",
  "NAVIGATION_TIMEOUT",
  "ACTION_TIMEOUT",
  "ARTIFACT_WRITE_FAILED",
  "COMMAND_LIMIT_EXCEEDED",
  "UNSUPPORTED_ACTION",
] as const;

export type ErrorCode = (typeof ERROR_CODES)[number];

export interface ProtocolError {
  code: ErrorCode;
  message: string;
  details?: Record<string, unknown>;
}

/** Throwable carrying a protocol error code; converted to an error envelope by the bridge. */
export class ToolError extends Error {
  constructor(
    readonly code: ErrorCode,
    message: string,
    readonly details?: Record<string, unknown>,
  ) {
    super(message);
    this.name = "ToolError";
  }
}
