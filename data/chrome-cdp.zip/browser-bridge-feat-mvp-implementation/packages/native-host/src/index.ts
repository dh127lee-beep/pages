/**
 * Native Messaging host entry point.
 * Production transport between the extension and the agent. Chrome launches this
 * process and speaks framed JSON over stdio. See spec/05 §Native Messaging host.
 */

import { PROTOCOL_VERSION } from "@browser-bridge/shared-protocol";
import { AgentRelay } from "./agent-relay.js";
import { NativeHost } from "./native-host.js";

export { generateHostManifest, extensionIdFromOrigin, DEFAULT_HOST_NAME } from "./host-manifest.js";
export type { HostManifest, HostManifestInput } from "./host-manifest.js";
export { NativeHost } from "./native-host.js";
export type { NativeHostOptions } from "./native-host.js";
export { AgentRelay, handleAgentMessage } from "./agent-relay.js";

export const NATIVE_HOST_PROTOCOL_VERSION = PROTOCOL_VERSION;
export const DEFAULT_AGENT_PORT = 18480;

export interface StartNativeHostOptions {
  allowedExtensionIds?: string[];
  /** Loopback port external agent programs connect to (0 to disable the relay). */
  agentPort?: number;
}

/**
 * Wire process stdio to a NativeHost (Chrome ↔ extension) and open a loopback
 * relay so external agent programs can connect at any time. Chrome passes the
 * caller origin as argv[2].
 */
export function startNativeHost(options: StartNativeHostOptions = {}): NativeHost {
  const host = new NativeHost({
    write: (frame) => process.stdout.write(frame),
    clientName: "browser-bridge-native-host",
    clientVersion: PROTOCOL_VERSION,
    allowedExtensionIds: options.allowedExtensionIds,
    callerOrigin: process.argv[2],
    onConnected: (connectionId) => process.stderr.write(`[browser-bridge] extension connected (${connectionId})\n`),
    onRejected: (reason) => process.stderr.write(`[browser-bridge] rejected: ${reason}\n`),
  });

  process.stdin.on("data", (chunk: Buffer) => host.onData(new Uint8Array(chunk)));

  const agentPort = options.agentPort ?? DEFAULT_AGENT_PORT;
  if (agentPort > 0) {
    const relay = new AgentRelay((type, payload, route) => host.request(type, payload, route), { port: agentPort });
    relay
      .start()
      .then(({ port }) => process.stderr.write(`[browser-bridge] agent relay on 127.0.0.1:${port}\n`))
      .catch((error: unknown) => {
        // Another host instance likely owns the port; external agents use that one.
        process.stderr.write(`[browser-bridge] agent relay not started: ${String(error)}\n`);
      });
  }

  process.stderr.write(`[browser-bridge] native host started (protocol ${PROTOCOL_VERSION})\n`);
  return host;
}
