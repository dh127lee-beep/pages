/**
 * Installer CLI: writes the native messaging host manifest (and a launcher
 * script) to the OS location so Chrome can launch the host.
 *
 * Usage:
 *   node packages/native-host/dist/install.js <extension-id> [--edge|--chromium]
 *
 * Get <extension-id> from chrome://extensions after loading the unpacked
 * extension (it is stable as long as the dist path doesn't move).
 */

import { chmodSync, mkdirSync, writeFileSync } from "node:fs";
import { homedir, platform } from "node:os";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { DEFAULT_HOST_NAME, generateHostManifest } from "./host-manifest.js";

type Browser = "chrome" | "chromium" | "edge";

function manifestDir(browser: Browser): string {
  const home = homedir();
  if (platform() === "darwin") {
    const base = join(home, "Library", "Application Support");
    const sub = browser === "edge" ? ["Microsoft Edge"] : browser === "chromium" ? ["Chromium"] : ["Google", "Chrome"];
    return join(base, ...sub, "NativeMessagingHosts");
  }
  // Linux
  const sub = browser === "edge" ? "microsoft-edge" : browser === "chromium" ? "chromium" : "google-chrome";
  return join(home, ".config", sub, "NativeMessagingHosts");
}

export function install(extensionId: string, browser: Browser): { manifestPath: string; launcherPath: string } {
  if (!/^[a-p]{32}$/.test(extensionId)) {
    throw new Error(`Invalid extension id: ${extensionId} (expected 32 chars a–p from chrome://extensions)`);
  }
  const here = dirname(fileURLToPath(import.meta.url)); // .../native-host/dist
  const cliPath = resolve(here, "cli.js");
  const launcherPath = resolve(here, "..", "bb-native-host.sh");

  writeFileSync(launcherPath, `#!/usr/bin/env bash\nexec node ${JSON.stringify(cliPath)} "$@"\n`, { mode: 0o755 });
  chmodSync(launcherPath, 0o755);

  const manifest = generateHostManifest({ path: launcherPath, allowedExtensionIds: [extensionId] });
  const dir = manifestDir(browser);
  mkdirSync(dir, { recursive: true });
  const manifestPath = join(dir, `${DEFAULT_HOST_NAME}.json`);
  writeFileSync(manifestPath, JSON.stringify(manifest, null, 2));

  return { manifestPath, launcherPath };
}

function main(): void {
  const args = process.argv.slice(2);
  const extensionId = args.find((a) => !a.startsWith("--"));
  const browser: Browser = args.includes("--edge") ? "edge" : args.includes("--chromium") ? "chromium" : "chrome";
  if (!extensionId) {
    console.error("usage: node dist/install.js <extension-id> [--edge|--chromium]");
    process.exitCode = 1;
    return;
  }
  try {
    const { manifestPath, launcherPath } = install(extensionId, browser);
    console.log(`Installed native messaging host:\n  manifest: ${manifestPath}\n  launcher: ${launcherPath}`);
    console.log("Reload the extension; it will auto-connect via Native Messaging.");
  } catch (error) {
    console.error(`Install failed: ${error instanceof Error ? error.message : String(error)}`);
    process.exitCode = 1;
  }
}

main();
