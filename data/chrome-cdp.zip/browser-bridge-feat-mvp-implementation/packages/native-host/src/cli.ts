/** Native host CLI entry: Chrome launches this; it speaks framed JSON over stdio. */
import { startNativeHost } from "./index.js";

startNativeHost();
