/**
 * Agent relay: a loopback endpoint the native host exposes so external agent
 * programs can connect *to the host* (and thus to the extension) at any time.
 *
 * Chrome launches the host (via the extension's connectNative), the host keeps a
 * stdio link to the extension, and this relay accepts external agents on a local
 * port and forwards their tool requests over that link. This is what makes the
 * host feel like an always-on endpoint ("extension as server"). See task/08.
 */

import type { RpcRoute, ToolResponse } from "@browser-bridge/shared-protocol";
import { WebSocketServer, type WebSocket } from "ws";

export type RequestFn = (type: string, payload: unknown, route: RpcRoute) => Promise<ToolResponse>;

interface AgentRequest {
  id?: string | number;
  type: string;
  payload?: unknown;
  sessionId?: string;
  pageId?: string;
}

/** Pure: turn one agent request into a reply via the provided request fn. */
export async function handleAgentMessage(raw: unknown, request: RequestFn): Promise<unknown | undefined> {
  const msg = raw as AgentRequest | null;
  if (!msg || typeof msg.type !== "string") return undefined;
  const response = await request(msg.type, msg.payload ?? {}, { sessionId: msg.sessionId, pageId: msg.pageId });
  return { id: msg.id ?? null, response };
}

export interface AgentRelayOptions {
  port?: number;
  host?: string;
}

export class AgentRelay {
  private wss?: WebSocketServer;

  constructor(
    private readonly request: RequestFn,
    private readonly options: AgentRelayOptions = {},
  ) {}

  start(): Promise<{ port: number }> {
    const host = this.options.host ?? "127.0.0.1";
    return new Promise((resolve, reject) => {
      const wss = new WebSocketServer({ host, port: this.options.port ?? 18480 });
      this.wss = wss;
      wss.on("connection", (ws) => this.onConnection(ws));
      wss.on("error", reject);
      wss.on("listening", () => {
        const address = wss.address();
        resolve({ port: typeof address === "object" && address ? address.port : (this.options.port ?? 18480) });
      });
    });
  }

  stop(): Promise<void> {
    return new Promise((resolve) => {
      if (!this.wss) return resolve();
      this.wss.close(() => resolve());
    });
  }

  private onConnection(ws: WebSocket): void {
    ws.on("message", (data) => {
      let parsed: unknown;
      try {
        parsed = JSON.parse(data.toString());
      } catch {
        return;
      }
      void handleAgentMessage(parsed, this.request).then((reply) => {
        if (reply !== undefined) ws.send(JSON.stringify(reply));
      });
    });
  }
}
