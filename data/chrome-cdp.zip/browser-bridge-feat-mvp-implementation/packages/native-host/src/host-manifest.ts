/**
 * Native messaging host manifest generation.
 * See spec/05 §Native Messaging host and Chrome's native messaging docs.
 */

export const DEFAULT_HOST_NAME = "com.browser_bridge.native_host";

export interface HostManifestInput {
  hostName?: string;
  /** Absolute path to the host executable. */
  path: string;
  /** Extension ids allowed to talk to this host. */
  allowedExtensionIds: string[];
  description?: string;
}

export interface HostManifest {
  name: string;
  description: string;
  path: string;
  type: "stdio";
  allowed_origins: string[];
}

export function generateHostManifest(input: HostManifestInput): HostManifest {
  if (input.allowedExtensionIds.length === 0) {
    throw new Error("At least one allowed extension id is required.");
  }
  return {
    name: input.hostName ?? DEFAULT_HOST_NAME,
    description: input.description ?? "Browser Bridge native messaging host",
    path: input.path,
    type: "stdio",
    allowed_origins: input.allowedExtensionIds.map((id) => `chrome-extension://${id}/`),
  };
}

/** Extract the extension id from a `chrome-extension://<id>/` origin. */
export function extensionIdFromOrigin(origin: string): string | undefined {
  const match = /^chrome-extension:\/\/([a-p]{32})\/?$/.exec(origin);
  return match?.[1];
}
