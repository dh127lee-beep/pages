/**
 * Native messaging host (adapter side over framed stdio).
 * Decodes Chrome's length-prefixed frames, runs the shared AdapterEndpoint
 * handshake/RPC, and verifies the calling extension id. Stream-injectable so it
 * is testable without real stdio. See spec/02 §Native Messaging safety.
 */

import { AdapterEndpoint, FrameDecoder, encodeFrame, type RpcRoute, type ToolResponse } from "@browser-bridge/shared-protocol";
import { extensionIdFromOrigin } from "./host-manifest.js";

export interface NativeHostOptions {
  write: (frame: Uint8Array) => void;
  clientName: string;
  clientVersion?: string;
  timeoutMs?: number;
  /** If set, only these extension ids may talk to the host. */
  allowedExtensionIds?: string[];
  /** The calling origin Chrome passes to the host (e.g. argv). */
  callerOrigin?: string;
  onConnected?: (connectionId: string) => void;
  onRejected?: (reason: string) => void;
}

export class NativeHost {
  private readonly decoder = new FrameDecoder();
  private readonly endpoint: AdapterEndpoint;
  private readonly callerAllowed: boolean;

  constructor(private readonly options: NativeHostOptions) {
    this.callerAllowed = this.verifyCaller();
    this.endpoint = new AdapterEndpoint((message) => this.options.write(encodeFrame(message)), {
      clientName: options.clientName,
      clientVersion: options.clientVersion,
      timeoutMs: options.timeoutMs,
      onConnected: options.onConnected,
    });
  }

  /** Feed raw bytes from stdin. */
  onData(chunk: Uint8Array): void {
    if (!this.callerAllowed) {
      this.options.onRejected?.("extension id not allowed");
      return;
    }
    for (const message of this.decoder.push(chunk)) {
      this.endpoint.handleIncoming(message);
    }
  }

  request(type: string, payload: unknown = {}, route: RpcRoute = {}): Promise<ToolResponse> {
    return this.endpoint.request(type, payload, route);
  }

  get connected(): boolean {
    return this.endpoint.connected;
  }

  get allowed(): boolean {
    return this.callerAllowed;
  }

  private verifyCaller(): boolean {
    const allow = this.options.allowedExtensionIds;
    if (!allow || allow.length === 0) return true;
    const id = this.options.callerOrigin ? extensionIdFromOrigin(this.options.callerOrigin) : undefined;
    return id !== undefined && allow.includes(id);
  }
}
