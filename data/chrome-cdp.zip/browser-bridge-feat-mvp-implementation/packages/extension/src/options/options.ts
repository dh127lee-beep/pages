/**
 * Options page (skeleton).
 * Stores one basic setting (dev adapter port) in chrome.storage.local.
 * Phase 1 acceptance: options page can store basic settings.
 */

import { getLocal, setLocal } from "../lib/storage.js";

interface Settings {
  adapterPort: number;
}

const SETTINGS_KEY = "settings";
const DEFAULT_WS_PORT = 18470;
const DEFAULTS: Settings = { adapterPort: DEFAULT_WS_PORT };

async function loadSettings(): Promise<Settings> {
  return (await getLocal<Settings>(SETTINGS_KEY)) ?? DEFAULTS;
}

async function init(): Promise<void> {
  const input = document.getElementById("adapterPort") as HTMLInputElement | null;
  const saveBtn = document.getElementById("save");
  const savedMsg = document.getElementById("saved");
  if (!input || !saveBtn) return;

  const settings = await loadSettings();
  input.value = String(settings.adapterPort);

  saveBtn.addEventListener("click", () => {
    const port = Number.parseInt(input.value, 10);
    void setLocal<Settings>(SETTINGS_KEY, {
      adapterPort: Number.isFinite(port) && port > 0 ? port : DEFAULT_WS_PORT,
    }).then(() => {
      savedMsg?.classList.add("show");
      setTimeout(() => savedMsg?.classList.remove("show"), 1200);
    });
  });
}

void init();
