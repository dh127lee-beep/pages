/**
 * Popup UI (skeleton).
 * Reads connection state from chrome.storage.session and renders it. Phase 1
 * acceptance: popup shows disconnected state.
 */

import {
  CONNECTION_STATE_KEY,
  RECENT_ACTIVITY_KEY,
  initialConnectionState,
  initialRecentActivity,
  type ActivityEvent,
  type ConnectionState,
} from "../state/connection-state.js";

async function loadState(): Promise<ConnectionState> {
  const out = await chrome.storage.session.get(CONNECTION_STATE_KEY);
  return (out[CONNECTION_STATE_KEY] as ConnectionState | undefined) ?? initialConnectionState;
}

async function loadActivity(): Promise<ActivityEvent[]> {
  const out = await chrome.storage.session.get(RECENT_ACTIVITY_KEY);
  return (out[RECENT_ACTIVITY_KEY] as ActivityEvent[] | undefined) ?? initialRecentActivity;
}

function timeAgo(ts: number): string {
  const secs = Math.max(0, Math.round((Date.now() - ts) / 1000));
  if (secs < 60) return `${secs}s ago`;
  const mins = Math.round(secs / 60);
  if (mins < 60) return `${mins}m ago`;
  return `${Math.round(mins / 60)}h ago`;
}

/** Drop the "browser." prefix so the tool name reads compactly (e.g. "navigate"). */
function shortToolName(type: string): string {
  return type.replace(/^browser\./, "");
}

function renderActivity(events: ActivityEvent[]): void {
  const listEl = document.getElementById("activity");
  if (!listEl) return;
  listEl.innerHTML = "";
  if (events.length === 0) {
    const li = document.createElement("li");
    li.className = "empty";
    li.textContent = "none yet";
    listEl.append(li);
    return;
  }
  for (const ev of events) {
    const li = document.createElement("li");
    li.className = `activity-row ${ev.ok ? "ok" : "fail"}`;

    const dot = document.createElement("span");
    dot.className = "activity-dot";
    li.append(dot);

    const name = document.createElement("span");
    name.className = "activity-name";
    name.textContent = shortToolName(ev.type);
    name.title = ev.ok ? ev.type : `${ev.type} — ${ev.code ?? "error"}`;
    li.append(name);

    if (ev.clientName) {
      const who = document.createElement("span");
      who.className = "activity-who";
      who.textContent = ev.clientName;
      li.append(who);
    }

    const time = document.createElement("span");
    time.className = "activity-time";
    time.textContent = timeAgo(ev.ts);
    li.append(time);

    listEl.append(li);
  }
}

function render(state: ConnectionState): void {
  const statusEl = document.getElementById("status");
  if (statusEl) {
    statusEl.textContent = state.status;
    statusEl.className = `status status--${state.status}`;
  }

  const clientsEl = document.getElementById("clients");
  if (clientsEl) {
    clientsEl.innerHTML = "";
    if (state.clients.length === 0) {
      const li = document.createElement("li");
      li.className = "empty";
      li.textContent = "none";
      clientsEl.append(li);
    } else {
      for (const client of state.clients) {
        const li = document.createElement("li");
        li.textContent = client.clientName;
        clientsEl.append(li);
      }
    }
  }

  const sessionsEl = document.getElementById("sessions");
  if (sessionsEl) {
    sessionsEl.textContent = `${state.sessionCount} active`;
  }

  const debuggerEl = document.getElementById("debugger");
  if (debuggerEl) {
    debuggerEl.textContent = `${state.debuggerAttached} attached`;
  }
}

void loadState().then(render);
void loadActivity().then(renderActivity);

chrome.storage.session.onChanged.addListener((changes) => {
  const connChange = changes[CONNECTION_STATE_KEY];
  if (connChange) {
    render((connChange.newValue as ConnectionState | undefined) ?? initialConnectionState);
  }
  const activityChange = changes[RECENT_ACTIVITY_KEY];
  if (activityChange) {
    renderActivity((activityChange.newValue as ActivityEvent[] | undefined) ?? initialRecentActivity);
  }
});
