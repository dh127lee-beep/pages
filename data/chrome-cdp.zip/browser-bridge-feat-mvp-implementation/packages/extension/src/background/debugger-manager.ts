/**
 * Debugger manager (background side).
 * Attaches chrome.debugger to session-owned tabs, enables CDP domains, buffers
 * console/network events (bounded), and exposes redacted reads + screenshots.
 * Talks to the browser only through DebuggerPort. See spec/01 §Debugger Backend
 * and reference/guide.md §1.6 (PageCollector).
 */

import {
  ToolError,
  type ArtifactMetadata,
  type ConsoleMessage,
  type NetworkRequestSummary,
} from "@browser-bridge/shared-protocol";
import { ArtifactRegistry, decodeDataUrl } from "./artifacts.js";
import type { DebuggerPort } from "./debugger-port.js";
import { redactUrl } from "./redaction.js";

const MAX_CONSOLE = 500;
const MAX_NETWORK = 500;
const MAX_RAW_EVENTS = 500;

export interface RawCdpEvent {
  seq: number;
  method: string;
  params: unknown;
}
const ENABLE_DOMAINS = ["Log.enable", "Runtime.enable", "Network.enable", "Page.enable"];

interface NetEntry {
  requestId: string;
  method: string;
  url: string;
  status?: number;
  resourceType?: string;
  startTs: number;
  endTs?: number;
}

interface TabBuffers {
  console: ConsoleMessage[];
  network: Map<string, NetEntry>;
}

export interface ScreenshotTarget {
  sessionId: string;
  pageId: string;
  chromeTabId: number;
  tabGroupId?: number;
}

export class DebuggerManager {
  private readonly attached = new Set<number>();
  private readonly buffers = new Map<number, TabBuffers>();
  /** Currently-open JS dialog per tab, tracked from Page.javascriptDialogOpening. */
  private readonly openDialogs = new Map<number, { type: string; message: string }>();
  /** Raw CDP event capture (opt-in, Phase 2): per-tab ring buffer + global cursor. */
  private readonly rawCapture = new Set<number>();
  private readonly rawEvents = new Map<number, RawCdpEvent[]>();
  private rawSeq = 0;

  constructor(
    private readonly port: DebuggerPort,
    private readonly artifacts: ArtifactRegistry,
  ) {
    this.port.setEventListener((tabId, method, params) => this.onEvent(tabId, method, params));
  }

  attachedCount(): number {
    return this.attached.size;
  }

  isAttached(tabId: number): boolean {
    return this.attached.has(tabId);
  }

  async ensureAttached(tabId: number): Promise<void> {
    if (this.attached.has(tabId)) return;
    try {
      await this.port.attach(tabId);
      for (const method of ENABLE_DOMAINS) {
        await this.port.sendCommand(tabId, method);
      }
    } catch (error) {
      throw new ToolError(
        "BACKEND_UNAVAILABLE",
        `Could not attach the debugger: ${error instanceof Error ? error.message : String(error)}`,
      );
    }
    this.attached.add(tabId);
    this.buffers.set(tabId, { console: [], network: new Map() });
  }

  async detach(tabId: number): Promise<void> {
    if (!this.attached.has(tabId)) return;
    this.attached.delete(tabId);
    this.buffers.delete(tabId);
    this.openDialogs.delete(tabId);
    this.rawCapture.delete(tabId);
    this.rawEvents.delete(tabId);
    try {
      await this.port.detach(tabId);
    } catch {
      // tab may already be gone; nothing else to do.
    }
  }

  listConsole(tabId: number, opts: { level?: string; limit?: number } = {}): ConsoleMessage[] {
    const all = this.buffers.get(tabId)?.console ?? [];
    const filtered = opts.level ? all.filter((m) => m.level === opts.level) : all;
    return filtered.slice(-(opts.limit ?? 100));
  }

  listNetwork(tabId: number, opts: { limit?: number } = {}): NetworkRequestSummary[] {
    const entries = [...(this.buffers.get(tabId)?.network.values() ?? [])];
    const summaries = entries.map((e) => {
      const summary: NetworkRequestSummary = { method: e.method, url: e.url };
      if (e.status !== undefined) summary.status = e.status;
      if (e.resourceType !== undefined) summary.resourceType = e.resourceType;
      if (e.endTs !== undefined) summary.durationMs = Math.round((e.endTs - e.startTs) * 1000);
      return summary;
    });
    return summaries.slice(-(opts.limit ?? 100));
  }

  async captureScreenshot(target: ScreenshotTarget): Promise<ArtifactMetadata> {
    await this.ensureAttached(target.chromeTabId);
    const res = (await this.port.sendCommand(target.chromeTabId, "Page.captureScreenshot", { format: "png" })) as {
      data?: string;
    };
    if (!res?.data) {
      throw new ToolError("ARTIFACT_WRITE_FAILED", "Debugger screenshot returned no data.");
    }
    const { contentType, bytes } = decodeDataUrl(`data:image/png;base64,${res.data}`);
    return this.artifacts.put(
      {
        sessionId: target.sessionId,
        pageId: target.pageId,
        tabGroupId: target.tabGroupId,
        kind: "screenshot",
        contentType,
      },
      bytes,
    );
  }

  /** Raw CDP passthrough: attach on demand and forward the command verbatim. */
  async raw(tabId: number, method: string, params?: Record<string, unknown>): Promise<unknown> {
    await this.ensureAttached(tabId);
    return this.port.sendCommand(tabId, method, params);
  }

  /** Start capturing raw CDP events for the tab (idempotent). */
  async enableRawEvents(tabId: number): Promise<void> {
    await this.ensureAttached(tabId);
    if (!this.rawEvents.has(tabId)) this.rawEvents.set(tabId, []);
    this.rawCapture.add(tabId);
  }

  /** Buffered raw events with seq > since, optionally filtered by method, newest last. */
  listRawEvents(
    tabId: number,
    opts: { since?: number; methods?: string[]; limit?: number } = {},
  ): { events: RawCdpEvent[]; cursor: number } {
    const all = this.rawEvents.get(tabId) ?? [];
    const since = opts.since ?? 0;
    const methods = opts.methods && opts.methods.length ? new Set(opts.methods) : undefined;
    let events = all.filter((e) => e.seq > since && (!methods || methods.has(e.method)));
    if (opts.limit && events.length > opts.limit) events = events.slice(-opts.limit);
    const cursor = all.length ? all[all.length - 1]!.seq : since;
    return { events, cursor };
  }

  /** Evaluate a JS expression in the page (MAIN) world; return the value JSON-serialized. */
  async evaluate(tabId: number, expression: string): Promise<{ value: string }> {
    await this.ensureAttached(tabId);
    const res = (await this.port.sendCommand(tabId, "Runtime.evaluate", {
      expression,
      returnByValue: true,
      awaitPromise: true,
      userGesture: true,
    })) as {
      result?: { value?: unknown; description?: string };
      exceptionDetails?: { text?: string; exception?: { description?: string } };
    };
    if (res?.exceptionDetails) {
      const detail = res.exceptionDetails.exception?.description ?? res.exceptionDetails.text ?? "evaluation error";
      throw new ToolError("UNSUPPORTED_ACTION", `evaluate_script failed: ${detail}`);
    }
    const r = res?.result ?? {};
    let value: string;
    if (r.value !== undefined) {
      value = typeof r.value === "string" ? r.value : safeJson(r.value);
    } else {
      value = r.description ?? "";
    }
    return { value };
  }

  /** CDP device-metrics override (resize_page). */
  async setDeviceMetrics(
    tabId: number,
    m: { width: number; height: number; deviceScaleFactor?: number; mobile?: boolean },
  ): Promise<void> {
    await this.ensureAttached(tabId);
    await this.port.sendCommand(tabId, "Emulation.setDeviceMetricsOverride", {
      width: m.width,
      height: m.height,
      deviceScaleFactor: m.deviceScaleFactor ?? 0,
      mobile: m.mobile ?? false,
    });
  }

  async clearDeviceMetrics(tabId: number): Promise<void> {
    await this.ensureAttached(tabId);
    await this.port.sendCommand(tabId, "Emulation.clearDeviceMetricsOverride");
  }

  /** Device / network / CPU emulation (emulate). */
  async emulate(
    tabId: number,
    opts: {
      width?: number;
      height?: number;
      mobile?: boolean;
      network?: { offline?: boolean; latencyMs?: number; downloadKbps?: number; uploadKbps?: number };
      cpuThrottlingRate?: number;
      reset?: boolean;
    },
  ): Promise<void> {
    await this.ensureAttached(tabId);
    if (opts.reset) {
      await this.port.sendCommand(tabId, "Emulation.clearDeviceMetricsOverride");
      await this.port.sendCommand(tabId, "Network.emulateNetworkConditions", {
        offline: false,
        latency: 0,
        downloadThroughput: -1,
        uploadThroughput: -1,
      });
      await this.port.sendCommand(tabId, "Emulation.setCPUThrottlingRate", { rate: 1 });
      return;
    }
    if (opts.width != null && opts.height != null) {
      await this.port.sendCommand(tabId, "Emulation.setDeviceMetricsOverride", {
        width: opts.width,
        height: opts.height,
        deviceScaleFactor: 0,
        mobile: Boolean(opts.mobile),
      });
    }
    if (opts.network) {
      const n = opts.network;
      const kbpsToBps = (kbps?: number) => (kbps != null ? (kbps * 1024) / 8 : -1);
      await this.port.sendCommand(tabId, "Network.emulateNetworkConditions", {
        offline: Boolean(n.offline),
        latency: n.latencyMs ?? 0,
        downloadThroughput: kbpsToBps(n.downloadKbps),
        uploadThroughput: kbpsToBps(n.uploadKbps),
      });
    }
    if (opts.cpuThrottlingRate != null) {
      await this.port.sendCommand(tabId, "Emulation.setCPUThrottlingRate", { rate: opts.cpuThrottlingRate });
    }
  }

  /** Attach files to a <input type=file> (tagged with data-bb-cdp=token) via CDP. */
  async setFileInputFiles(tabId: number, token: string, files: string[]): Promise<void> {
    await this.ensureAttached(tabId);
    const selector = `[data-bb-cdp="${token}"]`;
    const evalRes = (await this.port.sendCommand(tabId, "Runtime.evaluate", {
      expression: `document.querySelector(${JSON.stringify(selector)})`,
      returnByValue: false,
    })) as { result?: { objectId?: string } };
    const objectId = evalRes?.result?.objectId;
    if (!objectId) {
      throw new ToolError("ELEMENT_NOT_FOUND", "Could not resolve the file input element for upload.");
    }
    try {
      await this.port.sendCommand(tabId, "DOM.setFileInputFiles", { objectId, files });
    } finally {
      // Best-effort cleanup of the transient marker attribute.
      await this.port
        .sendCommand(tabId, "Runtime.evaluate", {
          expression: `document.querySelector(${JSON.stringify(selector)})?.removeAttribute('data-bb-cdp')`,
        })
        .catch(() => undefined);
    }
  }

  /**
   * Read WebMCP tools the page exposes. Targets the page JS API
   * (navigator.modelContext or window.agent) via Runtime.evaluate; returns [] if
   * the page has no WebMCP provider.
   */
  async listWebmcpTools(tabId: number): Promise<unknown[]> {
    const expr = `(async () => {
      const mc = (typeof navigator !== 'undefined' && navigator.modelContext) || (typeof window !== 'undefined' && window.agent) || null;
      if (!mc) return [];
      let tools = mc.tools;
      if (typeof mc.listTools === 'function') tools = await mc.listTools();
      else if (typeof mc.getTools === 'function') tools = await mc.getTools();
      return (tools || []).map((t) => ({ name: t.name, description: t.description ?? '', inputSchema: t.inputSchema ?? t.parameters ?? null }));
    })()`;
    const { value } = await this.evaluate(tabId, expr);
    try {
      const arr = JSON.parse(value);
      return Array.isArray(arr) ? arr : [];
    } catch {
      return [];
    }
  }

  /** Execute a WebMCP tool the page exposes; returns its JSON-serialized result. */
  async executeWebmcpTool(tabId: number, name: string, input: Record<string, unknown>): Promise<{ value: string }> {
    const expr = `(async () => {
      const mc = (typeof navigator !== 'undefined' && navigator.modelContext) || (typeof window !== 'undefined' && window.agent);
      if (!mc) throw new Error('No WebMCP provider on this page');
      const name = ${JSON.stringify(name)};
      const input = ${JSON.stringify(input)};
      if (typeof mc.callTool === 'function') return await mc.callTool(name, input);
      let tools = mc.tools;
      if (typeof mc.listTools === 'function') tools = await mc.listTools();
      const tool = (tools || []).find((t) => t.name === name);
      if (!tool) throw new Error('WebMCP tool not found: ' + name);
      if (typeof tool.execute === 'function') return await tool.execute(input);
      if (typeof tool.call === 'function') return await tool.call(input);
      throw new Error('WebMCP tool is not callable: ' + name);
    })()`;
    return this.evaluate(tabId, expr);
  }

  /** Accept or dismiss the JS dialog currently open on the tab. */
  async handleDialog(
    tabId: number,
    accept: boolean,
    promptText?: string,
  ): Promise<{ handled: boolean; dialog?: { type: string; message: string } }> {
    await this.ensureAttached(tabId);
    const params: Record<string, unknown> = { accept };
    if (promptText !== undefined) params.promptText = promptText;
    await this.port.sendCommand(tabId, "Page.handleJavaScriptDialog", params);
    const dialog = this.openDialogs.get(tabId);
    this.openDialogs.delete(tabId);
    return { handled: true, dialog };
  }

  private onEvent(tabId: number, method: string, params: unknown): void {
    const p = params as Record<string, unknown>;

    // Dialog tracking does not depend on a console/network buffer.
    if (method === "Page.javascriptDialogOpening") {
      this.openDialogs.set(tabId, { type: String(p.type ?? "dialog"), message: String(p.message ?? "") });
      return;
    }
    if (method === "Page.javascriptDialogClosed") {
      this.openDialogs.delete(tabId);
      return;
    }

    // Raw event capture (opt-in): record every CDP event into a bounded ring buffer.
    if (this.rawCapture.has(tabId)) {
      const buf = this.rawEvents.get(tabId);
      if (buf) {
        buf.push({ seq: ++this.rawSeq, method, params: p });
        if (buf.length > MAX_RAW_EVENTS) buf.shift();
      }
    }

    const buffer = this.buffers.get(tabId);
    if (!buffer) return;

    switch (method) {
      case "Runtime.consoleAPICalled": {
        const args = Array.isArray(p.args) ? (p.args as Array<Record<string, unknown>>) : [];
        const text = args.map((a) => stringifyArg(a)).join(" ");
        push(buffer.console, { level: String(p.type ?? "log"), text, timestamp: Number(p.timestamp ?? 0) }, MAX_CONSOLE);
        return;
      }
      case "Log.entryAdded": {
        const entry = (p.entry ?? {}) as Record<string, unknown>;
        push(
          buffer.console,
          {
            level: String(entry.level ?? "info"),
            text: String(entry.text ?? ""),
            url: entry.url ? redactUrl(String(entry.url)) : undefined,
            timestamp: Number(entry.timestamp ?? 0),
          },
          MAX_CONSOLE,
        );
        return;
      }
      case "Network.requestWillBeSent": {
        const request = (p.request ?? {}) as Record<string, unknown>;
        const requestId = String(p.requestId ?? "");
        if (!requestId) return;
        if (buffer.network.size >= MAX_NETWORK) {
          const oldest = buffer.network.keys().next().value;
          if (oldest !== undefined) buffer.network.delete(oldest);
        }
        buffer.network.set(requestId, {
          requestId,
          method: String(request.method ?? "GET"),
          url: redactUrl(String(request.url ?? "")),
          resourceType: p.type ? String(p.type) : undefined,
          startTs: Number(p.timestamp ?? 0),
        });
        return;
      }
      case "Network.responseReceived": {
        const entry = buffer.network.get(String(p.requestId ?? ""));
        if (!entry) return;
        const response = (p.response ?? {}) as Record<string, unknown>;
        entry.status = Number(response.status ?? 0);
        if (p.type) entry.resourceType = String(p.type);
        return;
      }
      case "Network.loadingFinished": {
        const entry = buffer.network.get(String(p.requestId ?? ""));
        if (entry) entry.endTs = Number(p.timestamp ?? entry.startTs);
        return;
      }
      default:
        return;
    }
  }
}

function push<T>(arr: T[], item: T, max: number): void {
  arr.push(item);
  if (arr.length > max) arr.shift();
}

function stringifyArg(arg: Record<string, unknown>): string {
  if (arg.value !== undefined) return String(arg.value);
  if (arg.description !== undefined) return String(arg.description);
  return String(arg.type ?? "");
}

function safeJson(value: unknown): string {
  try {
    return JSON.stringify(value) ?? String(value);
  } catch {
    return String(value);
  }
}
