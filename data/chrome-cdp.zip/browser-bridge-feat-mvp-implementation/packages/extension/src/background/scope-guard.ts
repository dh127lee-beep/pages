/**
 * Permission And Scope Guard (skeleton).
 * Validates agent identity, session ownership, and tab/page leases.
 * See spec/01-architecture.md §Permission And Scope Guard.
 *
 * Stub: every method is declared but not yet implemented.
 */

import type { PageId, SessionId } from "@browser-bridge/shared-protocol";

export class ScopeGuard {
  verifyAgentPaired(_connectionId: string): boolean {
    throw new Error("ScopeGuard.verifyAgentPaired not implemented");
  }

  verifySessionOwnership(_connectionId: string, _sessionId: SessionId): boolean {
    throw new Error("ScopeGuard.verifySessionOwnership not implemented");
  }

  verifyPageLease(_sessionId: SessionId, _pageId: PageId): boolean {
    throw new Error("ScopeGuard.verifyPageLease not implemented");
  }

  isDomainAllowed(_sessionId: SessionId, _url: string): boolean {
    throw new Error("ScopeGuard.isDomainAllowed not implemented");
  }
}
