/**
 * Tab Group Manager.
 * Phase 3 provides `planTabGroup` (pure: deterministic title/color for a logical
 * group). Actual Chrome tab group materialization is Phase 4.
 * See spec/01-architecture.md §Tab Group Manager and §Tab group lifecycle.
 */

import type { SessionId, TabGroupId } from "@browser-bridge/shared-protocol";

/** Chrome tabGroups colors. */
export const TAB_GROUP_COLORS = [
  "grey",
  "blue",
  "red",
  "yellow",
  "green",
  "pink",
  "purple",
  "cyan",
  "orange",
] as const;

export interface TabGroupPlan {
  title: string;
  color: string;
}

export interface PlanTabGroupInput {
  clientName: string;
  sessionLabel?: string;
  seed: string;
}

function hash(seed: string): number {
  let h = 0;
  for (let i = 0; i < seed.length; i++) {
    h = (h * 31 + seed.charCodeAt(i)) >>> 0;
  }
  return h;
}

/** Deterministic title/color for a session's tab group. */
export function planTabGroup({ clientName, seed }: PlanTabGroupInput): TabGroupPlan {
  const shortId = seed.replace(/^[a-z]+_/, "").slice(0, 4);
  const color = TAB_GROUP_COLORS[hash(seed) % TAB_GROUP_COLORS.length]!;
  // Title is the agent name behind the "BB ·" marker (which signals an
  // agent-controlled group). The session's color still disambiguates when one
  // agent owns several sessions; fall back to the short id if the name is blank.
  const name = clientName.trim() || shortId;
  return {
    title: `BB · ${name}`,
    color,
  };
}

export class TabGroupManager {
  materialize(_sessionId: SessionId): Promise<{ tabGroupId: TabGroupId }> {
    throw new Error("TabGroupManager.materialize not implemented");
  }

  addTab(_sessionId: SessionId, _tabId: number): Promise<void> {
    throw new Error("TabGroupManager.addTab not implemented");
  }

  cleanup(_sessionId: SessionId): Promise<void> {
    throw new Error("TabGroupManager.cleanup not implemented");
  }
}
