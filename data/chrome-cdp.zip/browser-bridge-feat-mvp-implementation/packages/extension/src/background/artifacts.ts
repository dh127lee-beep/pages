/**
 * In-memory artifact registry + data URL decoding.
 * Large binaries are stored here (or, later, in the adapter file store) and only
 * metadata is returned to the agent. See spec/05 §artifact store and
 * reference/guide.md (Reference over Value). Pure/testable.
 */

import { newArtifactId, type ArtifactMetadata } from "@browser-bridge/shared-protocol";

export interface DecodedDataUrl {
  contentType: string;
  bytes: Uint8Array;
}

export function decodeDataUrl(dataUrl: string): DecodedDataUrl {
  const match = /^data:([^;,]+)?(;base64)?,(.*)$/s.exec(dataUrl);
  if (!match) throw new Error("Invalid data URL");
  const contentType = match[1] ?? "application/octet-stream";
  const isBase64 = Boolean(match[2]);
  const data = match[3] ?? "";
  if (isBase64) {
    const binary = atob(data);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    return { contentType, bytes };
  }
  return { contentType, bytes: new TextEncoder().encode(decodeURIComponent(data)) };
}

interface StoredArtifact {
  meta: ArtifactMetadata;
  bytes: Uint8Array;
}

export class ArtifactRegistry {
  private readonly items = new Map<string, StoredArtifact>();

  put(meta: Omit<ArtifactMetadata, "artifactId" | "byteLength">, bytes: Uint8Array): ArtifactMetadata {
    const full: ArtifactMetadata = { ...meta, artifactId: newArtifactId(), byteLength: bytes.byteLength };
    this.items.set(full.artifactId, { meta: full, bytes });
    return full;
  }

  get(artifactId: string): StoredArtifact | undefined {
    return this.items.get(artifactId);
  }

  get size(): number {
    return this.items.size;
  }
}
