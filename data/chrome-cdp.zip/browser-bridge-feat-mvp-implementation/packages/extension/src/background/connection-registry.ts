/**
 * Connection registry. Tracks connected clients (connectionId -> client) in
 * memory and emits changes so the service worker can mirror them into
 * chrome.storage for the popup. Pure (no chrome.*) for testability.
 */

import { newConnectionId, type ConnectionId } from "@browser-bridge/shared-protocol";

export interface RegisteredClient {
  connectionId: ConnectionId;
  clientName: string;
  clientVersion: string;
}

export class ConnectionRegistry {
  private readonly clients = new Map<ConnectionId, RegisteredClient>();
  private onChange?: (clients: RegisteredClient[]) => void;

  setOnChange(cb: (clients: RegisteredClient[]) => void): void {
    this.onChange = cb;
  }

  register(clientName: string, clientVersion: string): RegisteredClient {
    const client: RegisteredClient = {
      connectionId: newConnectionId(),
      clientName,
      clientVersion,
    };
    this.clients.set(client.connectionId, client);
    this.emit();
    return client;
  }

  unregister(connectionId: ConnectionId): void {
    if (this.clients.delete(connectionId)) {
      this.emit();
    }
  }

  list(): RegisteredClient[] {
    return [...this.clients.values()];
  }

  private emit(): void {
    this.onChange?.(this.list());
  }
}
