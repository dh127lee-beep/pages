/**
 * Session Manager.
 * Owns multi-agent, multi-session state. In-memory Map is the working copy;
 * mutations write through to an optional SessionStore and `hydrate()` restores
 * after a service worker restart. Store and clock are injected for testability.
 * See spec/01-architecture.md §Session model and task/03.
 */

import {
  newSessionId,
  type AgentId,
  type BackendMode,
  type PageId,
  type SessionId,
  type SessionStatus,
  type StartSessionInput,
  type TabGroupState,
  type TabScope,
} from "@browser-bridge/shared-protocol";
import { planTabGroup } from "./tab-group-manager.js";

export interface SessionTabGroup {
  tabGroupId?: number;
  /** Window the session is anchored to (set when the group materializes). */
  windowId?: number;
  title: string;
  color: string;
  state: TabGroupState;
}

export interface SessionRecord {
  sessionId: SessionId;
  agentId: AgentId;
  clientName: string;
  mode: BackendMode;
  status: SessionStatus;
  sessionLabel?: string;
  allowedDomains: string[];
  tabScope: TabScope;
  allowRawCdp: boolean;
  tabGroup: SessionTabGroup;
  pageIds: PageId[];
  createdAt: string;
  lastActionAt: string;
}

export interface SessionStore {
  load(): Promise<SessionRecord[]>;
  save(records: SessionRecord[]): Promise<void>;
}

export interface SessionOwner {
  agentId: AgentId;
  clientName: string;
}

export class SessionManager {
  private readonly sessions = new Map<SessionId, SessionRecord>();

  constructor(
    private readonly store?: SessionStore,
    private readonly now: () => string = () => new Date().toISOString(),
  ) {}

  /** Restore persisted sessions on boot. */
  async hydrate(): Promise<void> {
    if (!this.store) return;
    for (const record of await this.store.load()) {
      this.sessions.set(record.sessionId, record);
    }
  }

  list(agentId?: AgentId): SessionRecord[] {
    const all = [...this.sessions.values()];
    return agentId ? all.filter((s) => s.agentId === agentId) : all;
  }

  get(sessionId: SessionId): SessionRecord | undefined {
    return this.sessions.get(sessionId);
  }

  async create(owner: SessionOwner, input: StartSessionInput): Promise<SessionRecord> {
    const sessionId = newSessionId();
    const plan = planTabGroup({ clientName: owner.clientName, sessionLabel: input.sessionLabel, seed: sessionId });
    const ts = this.now();
    const record: SessionRecord = {
      sessionId,
      agentId: owner.agentId,
      clientName: owner.clientName,
      mode: input.mode,
      status: "active",
      sessionLabel: input.sessionLabel,
      allowedDomains: input.allowedDomains ?? [],
      tabScope: input.tabScope ?? "agent-created-only",
      allowRawCdp: input.allowRawCdp ?? false,
      tabGroup: { title: plan.title, color: plan.color, state: "logical" },
      pageIds: [],
      createdAt: ts,
      lastActionAt: ts,
    };
    this.sessions.set(sessionId, record);
    await this.persist();
    return record;
  }

  async setStatus(sessionId: SessionId, status: SessionStatus): Promise<SessionRecord | undefined> {
    const record = this.sessions.get(sessionId);
    if (!record) return undefined;
    record.status = status;
    record.lastActionAt = this.now();
    await this.persist();
    return record;
  }

  async remove(sessionId: SessionId): Promise<void> {
    if (this.sessions.delete(sessionId)) {
      await this.persist();
    }
  }

  async materializeGroup(sessionId: SessionId, tabGroupId: number, windowId?: number): Promise<void> {
    const record = this.sessions.get(sessionId);
    if (!record) return;
    record.tabGroup.tabGroupId = tabGroupId;
    if (windowId != null) record.tabGroup.windowId = windowId;
    record.tabGroup.state = "materialized";
    record.lastActionAt = this.now();
    await this.persist();
  }

  async addPage(sessionId: SessionId, pageId: PageId): Promise<void> {
    const record = this.sessions.get(sessionId);
    if (!record || record.pageIds.includes(pageId)) return;
    record.pageIds.push(pageId);
    record.lastActionAt = this.now();
    await this.persist();
  }

  async removePage(sessionId: SessionId, pageId: PageId): Promise<void> {
    const record = this.sessions.get(sessionId);
    if (!record) return;
    record.pageIds = record.pageIds.filter((id) => id !== pageId);
    record.lastActionAt = this.now();
    await this.persist();
  }

  /** Session ids idle (no action) for at least idleMs as of nowMs. */
  listIdle(idleMs: number, nowMs: number): SessionId[] {
    return this.list()
      .filter((s) => s.status !== "finalized" && nowMs - Date.parse(s.lastActionAt) >= idleMs)
      .map((s) => s.sessionId);
  }

  /** Finalize a session whose last page was removed (empty group cleanup). */
  async finalizeIfEmpty(sessionId: SessionId): Promise<boolean> {
    const record = this.sessions.get(sessionId);
    if (!record || record.status === "finalized" || record.pageIds.length > 0) return false;
    record.status = "finalized";
    record.tabGroup.state = "closed";
    record.lastActionAt = this.now();
    await this.persist();
    return true;
  }

  private async persist(): Promise<void> {
    await this.store?.save([...this.sessions.values()]);
  }
}
