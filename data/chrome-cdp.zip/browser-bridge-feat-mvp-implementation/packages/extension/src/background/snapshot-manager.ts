/**
 * Snapshot manager (background side).
 * Ensures the content script is injected into a leased tab, requests a snapshot,
 * and records latestSnapshotId for stale detection. Talks to the page only
 * through ContentMessenger so it is testable. See spec/03 §Snapshot contract.
 */

import {
  ToolError,
  newSnapshotId,
  type Snapshot,
  type TakeSnapshotInput,
} from "@browser-bridge/shared-protocol";
import type { PageManager, PageRecord } from "./page-manager.js";

export interface ContentMessenger {
  ensureInjected(tabId: number): Promise<void>;
  request(tabId: number, message: unknown): Promise<unknown>;
}

const CONTENT_SCRIPT_FILE = "content-script.js";

export class ChromeContentMessenger implements ContentMessenger {
  async ensureInjected(tabId: number): Promise<void> {
    try {
      await chrome.scripting.executeScript({ target: { tabId }, files: [CONTENT_SCRIPT_FILE] });
    } catch {
      // Already injected or a restricted page; the snapshot request will surface a real error.
    }
  }

  async request(tabId: number, message: unknown): Promise<unknown> {
    return chrome.tabs.sendMessage(tabId, message);
  }
}

export class SnapshotManager {
  constructor(
    private readonly messenger: ContentMessenger,
    private readonly pages: PageManager,
  ) {}

  async snapshot(page: PageRecord, input: TakeSnapshotInput): Promise<Snapshot> {
    await this.messenger.ensureInjected(page.chromeTabId);
    const snapshotId = newSnapshotId();

    let response: unknown;
    try {
      response = await this.messenger.request(page.chromeTabId, {
        type: "bb.snapshot",
        snapshotId,
        pageId: page.pageId,
        includeHidden: input.includeHidden,
        includeBounds: input.includeBounds,
        includeRiskHints: input.includeRiskHints,
      });
    } catch (error) {
      throw new ToolError(
        "ACTION_TIMEOUT",
        `Snapshot request failed: ${error instanceof Error ? error.message : String(error)}; reload the page and retry.`,
      );
    }

    const ok = (response as { ok?: boolean } | null)?.ok === true;
    if (!ok) {
      const detail = (response as { error?: string } | null)?.error ?? "unknown content error";
      throw new ToolError("ELEMENT_NOT_FOUND", `Snapshot failed: ${detail}`);
    }

    const snapshot = (response as { snapshot: Snapshot }).snapshot;
    await this.pages.setLatestSnapshot(page.pageId, snapshotId);
    return snapshot;
  }
}
