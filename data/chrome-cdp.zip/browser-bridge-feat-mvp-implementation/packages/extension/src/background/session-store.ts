/**
 * chrome.storage.session-backed session store. Survives service worker restart
 * within the browser session. See spec/01 §MV3 lifecycle constraints.
 */

import { getSession, setSession } from "../lib/storage.js";
import type { SessionRecord, SessionStore } from "./session-manager.js";

const SESSIONS_KEY = "sessions";

export class ChromeSessionStore implements SessionStore {
  async load(): Promise<SessionRecord[]> {
    return (await getSession<SessionRecord[]>(SESSIONS_KEY)) ?? [];
  }

  async save(records: SessionRecord[]): Promise<void> {
    await setSession(SESSIONS_KEY, records);
  }
}
