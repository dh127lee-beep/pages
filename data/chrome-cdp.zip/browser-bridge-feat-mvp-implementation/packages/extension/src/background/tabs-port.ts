/**
 * Tabs port: the chrome.tabs / chrome.tabGroups surface the PageManager needs.
 * Abstracted so lease/lifecycle logic is testable with a fake. ChromeTabsPort is
 * the thin real adapter. See task/04 §테스트 전략.
 */

export interface TabInfo {
  tabId: number;
  windowId: number;
  url: string;
  title: string;
  active?: boolean;
  tabGroupId?: number;
}

export interface CreateTabOptions {
  url: string;
  active?: boolean;
  windowId?: number;
}

export interface GroupTabsOptions {
  tabIds: number[];
  groupId?: number;
  windowId?: number;
}

export interface GroupUpdate {
  title?: string;
  color?: string;
  collapsed?: boolean;
}

export interface TabsPort {
  createTab(options: CreateTabOptions): Promise<TabInfo>;
  closeTab(tabId: number): Promise<void>;
  getTab(tabId: number): Promise<TabInfo | undefined>;
  getActiveTab(): Promise<TabInfo | undefined>;
  listTabs(): Promise<TabInfo[]>;
  activate(tabId: number): Promise<void>;
  navigate(tabId: number, url: string): Promise<void>;
  reload(tabId: number): Promise<void>;
  groupTabs(options: GroupTabsOptions): Promise<number>;
  updateGroup(groupId: number, update: GroupUpdate): Promise<void>;
  ungroupTabs(tabIds: number[]): Promise<void>;
}

const NO_GROUP = -1;

function mapTab(tab: chrome.tabs.Tab): TabInfo {
  return {
    tabId: tab.id ?? -1,
    windowId: tab.windowId,
    url: tab.url ?? tab.pendingUrl ?? "",
    title: tab.title ?? "",
    active: tab.active,
    tabGroupId: tab.groupId != null && tab.groupId !== NO_GROUP ? tab.groupId : undefined,
  };
}

export class ChromeTabsPort implements TabsPort {
  async createTab(options: CreateTabOptions): Promise<TabInfo> {
    const tab = await chrome.tabs.create({
      url: options.url,
      active: options.active ?? false,
      ...(options.windowId != null ? { windowId: options.windowId } : {}),
    });
    return mapTab(tab);
  }

  async closeTab(tabId: number): Promise<void> {
    await chrome.tabs.remove(tabId);
  }

  async getTab(tabId: number): Promise<TabInfo | undefined> {
    try {
      return mapTab(await chrome.tabs.get(tabId));
    } catch {
      return undefined;
    }
  }

  async getActiveTab(): Promise<TabInfo | undefined> {
    const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    return tab ? mapTab(tab) : undefined;
  }

  async listTabs(): Promise<TabInfo[]> {
    const tabs = await chrome.tabs.query({ windowType: "normal" });
    return tabs.map(mapTab).filter((t) => t.tabId >= 0);
  }

  async activate(tabId: number): Promise<void> {
    await chrome.tabs.update(tabId, { active: true });
  }

  async navigate(tabId: number, url: string): Promise<void> {
    await chrome.tabs.update(tabId, { url });
    await this.waitForNavigation(tabId);
  }

  async reload(tabId: number): Promise<void> {
    await chrome.tabs.reload(tabId);
    await this.waitForNavigation(tabId);
  }

  /**
   * Resolve once the navigation has progressed enough to read the new url/title,
   * without blocking on full subresource load. We resolve on the FIRST of:
   *  - the URL committing to the new page (+ a short grace for the document), or
   *  - the load completing,
   * with a timeout fallback. Reading the tab right after chrome.tabs.update() would
   * otherwise return the stale pre-navigation url/title.
   */
  private waitForNavigation(tabId: number, timeoutMs = 8000): Promise<void> {
    return new Promise((resolve) => {
      let settled = false;
      let graceTimer: ReturnType<typeof setTimeout> | undefined;
      const finish = () => {
        if (settled) return;
        settled = true;
        chrome.tabs.onUpdated.removeListener(listener);
        clearTimeout(timer);
        if (graceTimer) clearTimeout(graceTimer);
        resolve();
      };
      const listener = (changedId: number, info: chrome.tabs.TabChangeInfo) => {
        if (changedId !== tabId) return;
        if (info.status === "complete") {
          finish();
        } else if (info.url) {
          // URL committed to the new page: give the document a brief moment to
          // start rendering instead of waiting on the full load.
          if (graceTimer) clearTimeout(graceTimer);
          graceTimer = setTimeout(finish, 250);
        }
      };
      chrome.tabs.onUpdated.addListener(listener);
      const timer = setTimeout(finish, timeoutMs);
    });
  }

  async groupTabs({ tabIds, groupId, windowId }: GroupTabsOptions): Promise<number> {
    if (groupId != null) {
      return chrome.tabs.group({ tabIds, groupId });
    }
    return chrome.tabs.group({
      tabIds,
      createProperties: windowId != null ? { windowId } : {},
    });
  }

  async updateGroup(groupId: number, update: GroupUpdate): Promise<void> {
    await chrome.tabGroups.update(groupId, {
      title: update.title,
      color: update.color as chrome.tabGroups.UpdateProperties["color"],
      collapsed: update.collapsed,
    });
  }

  async ungroupTabs(tabIds: number[]): Promise<void> {
    await chrome.tabs.ungroup(tabIds);
  }
}
