/** Per-connection context attached to inbound tool messages for ownership checks. */

import type { AgentId, ConnectionId } from "@browser-bridge/shared-protocol";

export interface ToolContext {
  agentId: AgentId;
  connectionId: ConnectionId;
  clientName: string;
}
