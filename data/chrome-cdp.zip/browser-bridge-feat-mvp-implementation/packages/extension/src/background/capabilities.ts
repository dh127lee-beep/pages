/**
 * Capabilities provider. Bridge depends on this interface (not chrome.*) so it
 * stays unit-testable. See spec/03 §browser.get_capabilities.
 */

import { PROTOCOL_VERSION, type Capabilities } from "@browser-bridge/shared-protocol";

export interface CapabilitiesProvider {
  get(): Promise<Capabilities>;
}

/** chrome-backed provider used by the service worker. */
export class ChromeCapabilitiesProvider implements CapabilitiesProvider {
  constructor(private readonly nativeHostAvailable: () => boolean = () => false) {}

  async get(): Promise<Capabilities> {
    const extensionVersion = chrome.runtime.getManifest().version;
    const [debuggerPermission, tabGroupsPermission] = await Promise.all([
      chrome.permissions.contains({ permissions: ["debugger"] }),
      chrome.permissions.contains({ permissions: ["tabGroups"] }),
    ]);
    return {
      protocolVersion: PROTOCOL_VERSION,
      extensionVersion,
      backends: ["extension-tab", "extension-debugger"],
      nativeHostAvailable: this.nativeHostAvailable(),
      debuggerPermission,
      tabGroupsPermission,
    };
  }
}
