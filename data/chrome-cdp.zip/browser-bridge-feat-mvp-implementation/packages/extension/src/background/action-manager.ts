/**
 * Action manager (background side).
 * For each page action: reject stale snapshots, serialize per page (Mutex),
 * dispatch to the content script, and optionally return a fresh snapshot.
 * Talks to the page only through ContentMessenger. See spec/03 §click/fill and
 * spec/01 §Concurrency rules.
 */

import {
  Mutex,
  ToolError,
  type ActionResult,
  type ErrorCode,
  type PageId,
  type Snapshot,
} from "@browser-bridge/shared-protocol";
import type { PageManager, PageRecord } from "./page-manager.js";
import type { ContentMessenger } from "./snapshot-manager.js";
import type { SnapshotManager } from "./snapshot-manager.js";

export interface RunActionInput {
  type: string;
  payload: Record<string, unknown>;
  snapshotId?: string;
  allowStale?: boolean;
  includeSnapshot?: boolean;
}

export interface ActionRunResult {
  result: ActionResult;
  snapshot?: Snapshot;
}

/**
 * True for the Chrome runtime errors raised when a tab's content script goes away
 * mid-message — almost always because the action triggered a navigation and the old
 * document was frozen into the back/forward cache (or unloaded) before replying.
 */
function isPageFrozenError(error: unknown): boolean {
  const m = (error instanceof Error ? error.message : String(error)).toLowerCase();
  return (
    m.includes("back/forward cache") ||
    m.includes("message channel is closed") ||
    m.includes("message port closed")
  );
}

const CONTENT_ERROR_CODES = new Set<string>([
  "SNAPSHOT_STALE",
  "ELEMENT_NOT_FOUND",
  "ELEMENT_NOT_INTERACTABLE",
  "ACTION_TIMEOUT",
  "UNSUPPORTED_ACTION",
]);

export class ActionManager {
  private readonly mutexes = new Map<PageId, Mutex>();

  constructor(
    private readonly messenger: ContentMessenger,
    private readonly pages: PageManager,
    private readonly snapshots: SnapshotManager,
  ) {}

  async run(page: PageRecord, input: RunActionInput): Promise<ActionRunResult> {
    if (input.snapshotId && !input.allowStale && !this.pages.isSnapshotCurrent(page.pageId, input.snapshotId)) {
      throw new ToolError("SNAPSHOT_STALE", "Snapshot is stale; take a fresh snapshot and retry.");
    }

    const release = await this.mutex(page.pageId).acquire();
    try {
      await this.messenger.ensureInjected(page.chromeTabId);

      let response: { ok?: boolean; result?: ActionResult; code?: string; error?: string } | null;
      try {
        response = (await this.messenger.request(page.chromeTabId, {
          type: input.type,
          ...input.payload,
        })) as { ok?: boolean; result?: ActionResult; code?: string; error?: string } | null;
      } catch (error) {
        // The action navigated the page: its content script was frozen into the
        // back/forward cache before it could reply, so the message channel closed.
        // That's a successful navigating action, not a failure — read the new tab.
        if (isPageFrozenError(error)) {
          const result = await this.pages.syncFromTab(page);
          const out: ActionRunResult = { result };
          if (input.includeSnapshot) {
            try {
              out.snapshot = await this.snapshots.snapshot(page, {});
            } catch {
              // New page may not be ready yet; the agent will take a fresh snapshot.
            }
          }
          return out;
        }
        throw error;
      }

      if (!response || response.ok !== true) {
        throw this.contentError(response);
      }

      const result = response.result ?? ({ url: "", title: "" } as ActionResult);
      const out: ActionRunResult = { result };
      if (input.includeSnapshot) {
        out.snapshot = await this.snapshots.snapshot(page, {});
      }
      return out;
    } finally {
      release();
    }
  }

  private contentError(response: { code?: string; error?: string } | null): ToolError {
    const code = response?.code && CONTENT_ERROR_CODES.has(response.code) ? (response.code as ErrorCode) : "ELEMENT_NOT_FOUND";
    return new ToolError(code, response?.error ?? "Action failed in the page.");
  }

  private mutex(pageId: PageId): Mutex {
    let mutex = this.mutexes.get(pageId);
    if (!mutex) {
      mutex = new Mutex();
      this.mutexes.set(pageId, mutex);
    }
    return mutex;
  }
}
