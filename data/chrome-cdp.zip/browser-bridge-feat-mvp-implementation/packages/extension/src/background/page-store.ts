/** chrome.storage.session-backed page store. Survives service worker restart. */

import { getSession, setSession } from "../lib/storage.js";
import type { PageRecord, PageStore } from "./page-manager.js";

const PAGES_KEY = "pages";

export class ChromePageStore implements PageStore {
  async load(): Promise<PageRecord[]> {
    return (await getSession<PageRecord[]>(PAGES_KEY)) ?? [];
  }

  async save(records: PageRecord[]): Promise<void> {
    await setSession(PAGES_KEY, records);
  }
}
