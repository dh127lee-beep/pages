/**
 * Page lease manager. Owns PageRecord (lease) state and the chromeTabId->pageId
 * index that enforces "a tab is leased by only one active session". Talks to the
 * browser only through TabsPort, so it is unit-testable with a fake.
 * See spec/01 §Page model and task/04.
 */

import {
  ToolError,
  newPageId,
  type ActionResult,
  type ClaimTabInput,
  type LeaseStatus,
  type PageId,
  type SessionId,
  type TabSummary,
} from "@browser-bridge/shared-protocol";
import { safeOrigin } from "./policy.js";
import type { SessionManager, SessionRecord } from "./session-manager.js";
import type { TabsPort } from "./tabs-port.js";

export interface PageRecord {
  pageId: PageId;
  sessionId: SessionId;
  chromeTabId: number;
  tabGroupId?: number;
  windowId: number;
  url: string;
  title: string;
  origin: string;
  createdByAgent: boolean;
  claimedFromUser: boolean;
  leaseStatus: LeaseStatus;
  latestSnapshotId?: string;
  createdAt: string;
  lastActionAt: string;
}

export interface PageStore {
  load(): Promise<PageRecord[]>;
  save(records: PageRecord[]): Promise<void>;
}

export class PageManager {
  private readonly pages = new Map<PageId, PageRecord>();
  private readonly byTab = new Map<number, PageId>();

  constructor(
    private readonly tabs: TabsPort,
    private readonly sessions: SessionManager,
    private readonly store?: PageStore,
    private readonly now: () => string = () => new Date().toISOString(),
  ) {}

  async hydrate(): Promise<void> {
    if (!this.store) return;
    for (const record of await this.store.load()) {
      this.pages.set(record.pageId, record);
      if (record.leaseStatus === "leased") this.byTab.set(record.chromeTabId, record.pageId);
    }
  }

  list(sessionId: SessionId): PageRecord[] {
    return [...this.pages.values()].filter((p) => p.sessionId === sessionId);
  }

  get(pageId: PageId): PageRecord | undefined {
    return this.pages.get(pageId);
  }

  isTabLeased(chromeTabId: number): boolean {
    return this.byTab.has(chromeTabId);
  }

  async setLatestSnapshot(pageId: PageId, snapshotId: string): Promise<void> {
    const record = this.pages.get(pageId);
    if (!record) return;
    record.latestSnapshotId = snapshotId;
    record.lastActionAt = this.now();
    await this.persist();
  }

  /** True if the snapshotId is the page's most recent (stale detection for actions). */
  isSnapshotCurrent(pageId: PageId, snapshotId: string): boolean {
    return this.pages.get(pageId)?.latestSnapshotId === snapshotId;
  }

  /** Open a new agent-controlled tab inside the session's tab group (and window). */
  async newPage(session: SessionRecord, url: string, origin: string): Promise<PageRecord> {
    // Once a session is materialized, all its tabs open in the same window so the
    // tab group stays together. The first tab defines the window.
    const tab = await this.tabs.createTab({ url, active: false, windowId: session.tabGroup.windowId });
    const tabGroupId = await this.ensureGroup(session, tab.tabId, tab.windowId);
    const record = this.record({
      session,
      tab: { ...tab, url: tab.url || url },
      tabGroupId,
      origin,
      createdByAgent: true,
      claimedFromUser: false,
    });
    await this.commit(record);
    return record;
  }

  /** List the user's open tabs, flagging which are already leased. */
  async listUserTabs(): Promise<TabSummary[]> {
    const tabs = await this.tabs.listTabs();
    return tabs.map((t) => ({
      tabId: t.tabId,
      url: t.url,
      title: t.title,
      windowId: t.windowId,
      active: t.active ?? false,
      tabGroupId: t.tabGroupId,
      leased: this.byTab.has(t.tabId),
    }));
  }

  /** Navigate (or reload) a leased page. */
  async navigate(page: PageRecord, url: string, reload: boolean): Promise<ActionResult> {
    if (reload) {
      await this.tabs.reload(page.chromeTabId);
    } else {
      await this.tabs.navigate(page.chromeTabId, url);
    }
    const fresh = await this.tabs.getTab(page.chromeTabId);
    page.url = fresh?.url || url;
    page.title = fresh?.title ?? page.title;
    page.origin = safeOrigin(page.url);
    page.latestSnapshotId = undefined; // navigation invalidates the snapshot
    page.lastActionAt = this.now();
    await this.persist();
    return { url: page.url, title: page.title, navigated: true };
  }

  /**
   * Re-read a leased tab after an action that navigated the page. Used when a
   * click/fill caused navigation: the page hosting the content script is frozen
   * into bfcache before it can reply, so we read the new url/title from the tab
   * instead. Reports navigated=true when the url actually changed.
   */
  async syncFromTab(page: PageRecord): Promise<ActionResult> {
    const before = page.url;
    const fresh = await this.tabs.getTab(page.chromeTabId);
    if (fresh) {
      page.url = fresh.url || page.url;
      page.title = fresh.title ?? page.title;
      page.origin = safeOrigin(page.url);
    }
    page.latestSnapshotId = undefined; // navigation invalidates the snapshot
    page.lastActionAt = this.now();
    await this.persist();
    return { url: page.url, title: page.title, navigated: page.url !== before };
  }

  /** Claim a user tab (active tab, or a specific tabId from list_tabs) into the session. */
  async claimTab(session: SessionRecord, input: ClaimTabInput): Promise<PageRecord> {
    const tab = input.tabId != null ? await this.tabs.getTab(input.tabId) : await this.tabs.getActiveTab();
    if (!tab) {
      throw new ToolError("BROWSER_NOT_RUNNING", "No tab to claim (check the tabId from list_tabs).");
    }
    if (this.byTab.has(tab.tabId)) {
      throw new ToolError("TAB_ALREADY_LEASED", "This tab is already leased by another active session.");
    }

    const moveToGroup = (input.moveToSessionGroup ?? true) && !(input.preserveExistingGroup ?? false);
    const tabGroupId = moveToGroup ? await this.ensureGroup(session, tab.tabId, tab.windowId) : undefined;

    const record = this.record({
      session,
      tab,
      tabGroupId,
      origin: safeOrigin(tab.url),
      createdByAgent: false,
      claimedFromUser: true,
    });
    await this.commit(record);
    return record;
  }

  /** Release a lease without closing the tab. */
  async release(session: SessionRecord, pageId: PageId): Promise<void> {
    const record = this.pages.get(pageId);
    if (!record || record.sessionId !== session.sessionId) {
      throw new ToolError("TAB_NOT_LEASED", "Page is not leased by this session.");
    }
    this.drop(record);
    await this.sessions.removePage(session.sessionId, pageId);
    await this.sessions.finalizeIfEmpty(session.sessionId);
    await this.persist();
  }

  /** On session end: close agent-created tabs, release claimed tabs (leave open). */
  /** Activate (focus) a leased page's tab. */
  async activate(page: PageRecord): Promise<void> {
    await this.tabs.activate(page.chromeTabId);
  }

  /** Close one leased page: close its tab (if agent-created) and drop the lease. */
  async closePage(session: SessionRecord, pageId: PageId): Promise<void> {
    const record = this.get(pageId);
    if (!record) return;
    if (record.createdByAgent) {
      try {
        await this.tabs.closeTab(record.chromeTabId);
      } catch {
        // tab may already be gone; drop the lease regardless.
      }
    }
    this.drop(record);
    await this.sessions.removePage(session.sessionId, record.pageId);
    await this.persist();
  }

  async closeSessionPages(session: SessionRecord): Promise<void> {
    for (const record of this.list(session.sessionId)) {
      if (record.createdByAgent) {
        try {
          await this.tabs.closeTab(record.chromeTabId);
        } catch {
          // tab may already be gone; drop the lease regardless.
        }
      }
      this.drop(record);
      await this.sessions.removePage(session.sessionId, record.pageId);
    }
    await this.persist();
  }

  /** chrome.tabs.onRemoved handler: clean up the lease for a closed tab. */
  async onTabRemoved(chromeTabId: number): Promise<void> {
    const pageId = this.byTab.get(chromeTabId);
    if (!pageId) return;
    const record = this.pages.get(pageId);
    this.drop(record);
    if (record) {
      await this.sessions.removePage(record.sessionId, record.pageId);
      await this.sessions.finalizeIfEmpty(record.sessionId);
    }
    await this.persist();
  }

  private async ensureGroup(session: SessionRecord, tabId: number, windowId: number): Promise<number> {
    const existing = session.tabGroup.tabGroupId;
    if (existing != null) {
      await this.tabs.groupTabs({ tabIds: [tabId], groupId: existing });
      return existing;
    }
    const groupId = await this.tabs.groupTabs({ tabIds: [tabId], windowId });
    await this.tabs.updateGroup(groupId, {
      title: session.tabGroup.title,
      color: session.tabGroup.color,
      collapsed: false,
    });
    await this.sessions.materializeGroup(session.sessionId, groupId, windowId);
    return groupId;
  }

  private record(args: {
    session: SessionRecord;
    tab: { tabId: number; windowId: number; url: string; title: string };
    tabGroupId?: number;
    origin: string;
    createdByAgent: boolean;
    claimedFromUser: boolean;
  }): PageRecord {
    const ts = this.now();
    return {
      pageId: newPageId(),
      sessionId: args.session.sessionId,
      chromeTabId: args.tab.tabId,
      tabGroupId: args.tabGroupId,
      windowId: args.tab.windowId,
      url: args.tab.url,
      title: args.tab.title,
      origin: args.origin,
      createdByAgent: args.createdByAgent,
      claimedFromUser: args.claimedFromUser,
      leaseStatus: "leased",
      createdAt: ts,
      lastActionAt: ts,
    };
  }

  private async commit(record: PageRecord): Promise<void> {
    this.pages.set(record.pageId, record);
    this.byTab.set(record.chromeTabId, record.pageId);
    await this.sessions.addPage(record.sessionId, record.pageId);
    await this.persist();
  }

  private drop(record: PageRecord | undefined): void {
    if (!record) return;
    record.leaseStatus = "released";
    this.byTab.delete(record.chromeTabId);
    this.pages.delete(record.pageId);
  }

  private async persist(): Promise<void> {
    await this.store?.save([...this.pages.values()]);
  }
}
