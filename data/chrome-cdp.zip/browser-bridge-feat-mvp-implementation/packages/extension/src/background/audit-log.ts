/**
 * Compact in-memory audit log. Records one event per tool call with ownership
 * ids and result status — never page bodies, cookies, or payloads.
 * See spec/02 §Audit events.
 */

import { newAuditId, type AuditId, type ErrorCode } from "@browser-bridge/shared-protocol";

export interface AuditEvent {
  auditId: string;
  ts: number;
  agentId?: string;
  clientName?: string;
  sessionId?: string;
  pageId?: string;
  tabGroupId?: number;
  type: string;
  ok: boolean;
  code?: ErrorCode;
}

export class AuditLog {
  private readonly events: AuditEvent[] = [];

  constructor(
    private readonly max = 1000,
    private readonly now: () => number = () => Date.now(),
    /** Notified after each event is recorded (e.g. to surface activity in the popup). */
    private readonly onRecord?: (event: AuditEvent) => void,
  ) {}

  record(event: Omit<AuditEvent, "auditId" | "ts">): AuditId {
    const auditId = newAuditId();
    const full: AuditEvent = { ...event, auditId, ts: this.now() };
    this.events.push(full);
    if (this.events.length > this.max) this.events.shift();
    this.onRecord?.(full);
    return auditId;
  }

  list(): AuditEvent[] {
    return [...this.events];
  }

  /** Most recent events, newest first (for UI surfaces). */
  recent(limit: number): AuditEvent[] {
    return this.events.slice(-limit).reverse();
  }
}
