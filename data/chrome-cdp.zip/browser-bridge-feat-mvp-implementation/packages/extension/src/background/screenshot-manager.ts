/**
 * Screenshot capture. Uses chrome.tabs.captureVisibleTab via a port abstraction
 * so the manager is testable. captureVisibleTab only captures a *visible* tab;
 * background/inactive tabs need the debugger path (Phase 7).
 * See spec/04 §Screenshot strategy.
 */

import { ToolError, type ArtifactMetadata } from "@browser-bridge/shared-protocol";
import { ArtifactRegistry, decodeDataUrl } from "./artifacts.js";
import type { PageRecord } from "./page-manager.js";

export interface ScreenshotPort {
  /** Capture the visible tab of the given window as a data URL. */
  captureVisible(windowId: number): Promise<string>;
}

export class ChromeScreenshotPort implements ScreenshotPort {
  async captureVisible(windowId: number): Promise<string> {
    return chrome.tabs.captureVisibleTab(windowId, { format: "png" });
  }
}

export class ScreenshotManager {
  constructor(
    private readonly port: ScreenshotPort,
    private readonly artifacts: ArtifactRegistry,
  ) {}

  async capture(session: { tabGroupId?: number }, page: PageRecord): Promise<ArtifactMetadata> {
    let dataUrl: string;
    try {
      dataUrl = await this.port.captureVisible(page.windowId);
    } catch (error) {
      throw new ToolError(
        "ARTIFACT_WRITE_FAILED",
        `Screenshot capture failed: ${error instanceof Error ? error.message : String(error)}`,
      );
    }
    const { contentType, bytes } = decodeDataUrl(dataUrl);
    return this.artifacts.put(
      {
        sessionId: page.sessionId,
        pageId: page.pageId,
        tabGroupId: page.tabGroupId ?? session.tabGroupId,
        kind: "screenshot",
        contentType,
      },
      bytes,
    );
  }
}
