/**
 * Agent Bridge.
 * Validates protocol messages and routes them. Phase 2 added get_capabilities;
 * Phase 3 adds session management. Page tools arrive in later phases.
 * See spec/01-architecture.md and spec/03 §Agent tools.
 */

import {
  ok,
  err,
  isToolName,
  claimTabSchema,
  navigateSchema,
  newPageSchema,
  startSessionSchema,
  transportMessageSchema,
  ToolError,
  type ArtifactMetadata,
  type PageId,
  type PageInfo,
  type PageSummary,
  type SessionDetail,
  type SessionId,
  type SessionSummary,
  type Snapshot,
  type TakeSnapshotInput,
  type ToolResponse,
  type TransportMessage,
} from "@browser-bridge/shared-protocol";
import { logger } from "../lib/logger.js";
import type { ActionManager } from "./action-manager.js";
import type { AuditLog } from "./audit-log.js";
import type { CapabilitiesProvider } from "./capabilities.js";
import type { DebuggerManager } from "./debugger-manager.js";
import type { ToolContext } from "./context.js";
import type { PageManager, PageRecord } from "./page-manager.js";
import { isCdpMethodAllowed, isHostAllowed, parseTargetUrl } from "./policy.js";
import { ScopeGuard } from "./scope-guard.js";
import type { ScreenshotManager } from "./screenshot-manager.js";
import { SessionManager, type SessionRecord } from "./session-manager.js";
import type { SnapshotManager } from "./snapshot-manager.js";
import { TabGroupManager } from "./tab-group-manager.js";

export interface BridgeDeps {
  capabilities: CapabilitiesProvider;
  sessions: SessionManager;
  pages: PageManager;
  snapshots: SnapshotManager;
  screenshots: ScreenshotManager;
  actions: ActionManager;
  debugger: DebuggerManager;
  audit: AuditLog;
  maxPendingPerSession?: number;
}

export class Bridge {
  readonly sessions: SessionManager;
  readonly pages: PageManager;
  readonly tabGroups = new TabGroupManager();
  readonly guard = new ScopeGuard();

  private readonly pending = new Map<string, number>();
  private readonly maxPending: number;

  constructor(private readonly deps: BridgeDeps) {
    this.sessions = deps.sessions;
    this.pages = deps.pages;
    this.maxPending = deps.maxPendingPerSession ?? 16;
  }

  /** Entry point for one inbound tool message: enforces queue limits and audits. */
  async handleMessage(raw: unknown, ctx?: ToolContext): Promise<ToolResponse> {
    const parsed = transportMessageSchema.safeParse(raw);
    if (!parsed.success) {
      return err({
        code: "UNSUPPORTED_ACTION",
        message: "Malformed transport message; check the envelope shape and resend.",
        details: { issues: parsed.error.issues },
      });
    }

    const message = parsed.data as TransportMessage;
    if (!isToolName(message.type)) {
      return err({ code: "UNSUPPORTED_ACTION", message: `Unknown tool: ${message.type}` });
    }

    const sessionId = message.sessionId;
    if (sessionId) {
      const inFlight = this.pending.get(sessionId) ?? 0;
      if (inFlight >= this.maxPending) {
        return err({
          code: "COMMAND_LIMIT_EXCEEDED",
          message: `Too many concurrent commands for this session (max ${this.maxPending}); wait for one to finish.`,
        });
      }
      this.pending.set(sessionId, inFlight + 1);
    }

    try {
      const response = await this.dispatch(message, ctx);
      return this.withAudit(message, ctx, response);
    } finally {
      if (sessionId) {
        const remaining = (this.pending.get(sessionId) ?? 1) - 1;
        if (remaining <= 0) this.pending.delete(sessionId);
        else this.pending.set(sessionId, remaining);
      }
    }
  }

  private withAudit(message: TransportMessage, ctx: ToolContext | undefined, response: ToolResponse): ToolResponse {
    const auditId = this.deps.audit.record({
      agentId: ctx?.agentId,
      clientName: ctx?.clientName,
      sessionId: message.sessionId,
      pageId: message.pageId,
      tabGroupId: message.sessionId ? this.sessions.get(message.sessionId)?.tabGroup.tabGroupId : undefined,
      type: message.type,
      ok: response.ok,
      code: response.ok ? undefined : response.error.code,
    });
    if (response.ok) response.auditId = auditId;
    return response;
  }

  /** Reap sessions idle for at least idleMs, detaching and closing their tabs. */
  async reapIdleSessions(idleMs: number, nowMs: number = Date.now()): Promise<number> {
    const ids = this.sessions.listIdle(idleMs, nowMs);
    for (const id of ids) {
      const record = this.sessions.get(id);
      if (!record) continue;
      await this.detachSessionTabs(record);
      await this.pages.closeSessionPages(record);
      await this.sessions.setStatus(id, "finalized");
    }
    return ids.length;
  }

  private async dispatch(message: TransportMessage, ctx?: ToolContext): Promise<ToolResponse> {
    logger.debug("tool", message.type);

    switch (message.type) {
      case "browser.get_capabilities":
        return ok(await this.deps.capabilities.get());
      case "browser.start_session":
        return this.startSession(message, ctx);
      case "browser.list_sessions":
        return this.listSessions(ctx);
      case "browser.get_session":
        return this.getSession(message, ctx);
      case "browser.pause_session":
        return this.pauseSession(message, ctx);
      case "browser.resume_session":
        return this.resumeSession(message, ctx);
      case "browser.end_session":
        return this.endSession(message, ctx);
      case "browser.new_page":
        return this.newPage(message, ctx);
      case "browser.list_tabs":
        return this.listTabs(ctx);
      case "browser.claim_tab":
        return this.claimTab(message, ctx);
      case "browser.navigate":
        return this.navigate(message, ctx);
      case "browser.release_tab":
        return this.releaseTab(message, ctx);
      case "browser.take_snapshot":
        return this.takeSnapshot(message, ctx);
      case "browser.take_screenshot":
        return this.takeScreenshot(message, ctx);
      case "browser.click":
        return this.runAction(message, ctx, "bb.click");
      case "browser.click_at":
        return this.runAction(message, ctx, "bb.click_at");
      case "browser.hover":
        return this.runAction(message, ctx, "bb.hover");
      case "browser.fill":
        return this.runAction(message, ctx, "bb.fill");
      case "browser.fill_form":
        return this.runAction(message, ctx, "bb.fill_form");
      case "browser.type_text":
        return this.runAction(message, ctx, "bb.type_text");
      case "browser.press_key":
        return this.runAction(message, ctx, "bb.press_key");
      case "browser.scroll":
        return this.runAction(message, ctx, "bb.scroll");
      case "browser.drag":
        return this.runAction(message, ctx, "bb.drag");
      case "browser.wait_for":
        return this.runAction(message, ctx, "bb.wait_for");
      case "browser.list_console_messages":
        return this.listConsole(message, ctx);
      case "browser.list_network_requests":
        return this.listNetwork(message, ctx);
      case "browser.evaluate_script":
        return this.evaluateScript(message, ctx);
      case "browser.resize_page":
        return this.resizePage(message, ctx);
      case "browser.emulate":
        return this.emulatePage(message, ctx);
      case "browser.handle_dialog":
        return this.handleDialog(message, ctx);
      case "browser.get_tab_id":
        return this.getTabId(message, ctx);
      case "browser.list_pages":
        return this.listPages(message, ctx);
      case "browser.close_page":
        return this.closePage(message, ctx);
      case "browser.select_page":
        return this.selectPage(message, ctx);
      case "browser.upload_file":
        return this.uploadFile(message, ctx);
      case "browser.list_webmcp_tools":
        return this.listWebmcpTools(message, ctx);
      case "browser.execute_webmcp_tool":
        return this.executeWebmcpTool(message, ctx);
      case "browser.cdp_command":
        return this.cdpCommand(message, ctx);
      case "browser.cdp_events":
        return this.cdpEvents(message, ctx);
      default:
        return err({ code: "UNSUPPORTED_ACTION", message: `Tool not implemented yet: ${message.type}` });
    }
  }

  // --- session tools ---

  private async startSession(message: TransportMessage, ctx?: ToolContext): Promise<ToolResponse> {
    if (!ctx) return this.noContext();
    const input = startSessionSchema.safeParse(message.payload);
    if (!input.success) {
      return err({
        code: "UNSUPPORTED_ACTION",
        message: "Invalid start_session input; check mode and clientName.",
        details: { issues: input.error.issues },
      });
    }
    const record = await this.sessions.create(
      { agentId: ctx.agentId, clientName: ctx.clientName },
      input.data,
    );
    return ok<SessionDetail>(toDetail(record), { sessionId: record.sessionId });
  }

  private listSessions(ctx?: ToolContext): ToolResponse {
    if (!ctx) return this.noContext();
    return ok<SessionSummary[]>(this.sessions.list(ctx.agentId).map(toSummary));
  }

  private getSession(message: TransportMessage, ctx?: ToolContext): ToolResponse {
    const owned = this.resolveOwned(message.sessionId, ctx);
    if ("error" in owned) return owned.error;
    return ok<SessionDetail>(toDetail(owned.record), { sessionId: owned.record.sessionId });
  }

  private async pauseSession(message: TransportMessage, ctx?: ToolContext): Promise<ToolResponse> {
    const owned = this.resolveOwned(message.sessionId, ctx);
    if ("error" in owned) return owned.error;
    if (owned.record.status === "finalized") {
      return err({ code: "SESSION_FINALIZED", message: "Session is finalized; create a new session." });
    }
    await this.detachSessionTabs(owned.record);
    const updated = await this.sessions.setStatus(owned.record.sessionId, "paused");
    return ok<SessionSummary>(toSummary(updated!), { sessionId: owned.record.sessionId });
  }

  private async resumeSession(message: TransportMessage, ctx?: ToolContext): Promise<ToolResponse> {
    const owned = this.resolveOwned(message.sessionId, ctx);
    if ("error" in owned) return owned.error;
    if (owned.record.status === "finalized") {
      return err({ code: "SESSION_FINALIZED", message: "Session is finalized; create a new session." });
    }
    const updated = await this.sessions.setStatus(owned.record.sessionId, "active");
    return ok<SessionSummary>(toSummary(updated!), { sessionId: owned.record.sessionId });
  }

  private async endSession(message: TransportMessage, ctx?: ToolContext): Promise<ToolResponse> {
    const owned = this.resolveOwned(message.sessionId, ctx);
    if ("error" in owned) return owned.error;
    // Detach the debugger, then close agent-created tabs and release claimed tabs.
    await this.detachSessionTabs(owned.record);
    await this.pages.closeSessionPages(owned.record);
    const updated = await this.sessions.setStatus(owned.record.sessionId, "finalized");
    return ok<SessionSummary>(toSummary(updated!), { sessionId: owned.record.sessionId });
  }

  // --- page tools ---

  private async newPage(message: TransportMessage, ctx?: ToolContext): Promise<ToolResponse> {
    const owned = this.resolveOwned(message.sessionId, ctx);
    if ("error" in owned) return owned.error;
    const gate = this.requireActive(owned.record);
    if (gate) return gate;

    const input = newPageSchema.safeParse(message.payload);
    if (!input.success) {
      return err({ code: "UNSUPPORTED_ACTION", message: "Invalid new_page input; provide a url." });
    }
    const target = parseTargetUrl(input.data.url);
    if (!target) {
      return err({ code: "POLICY_DENIED", message: "Only http/https URLs are allowed." });
    }
    if (!isHostAllowed(target.host, owned.record.allowedDomains)) {
      return err({ code: "POLICY_DENIED", message: `Domain not allowed for this session: ${target.host}` });
    }
    try {
      const page = await this.pages.newPage(owned.record, input.data.url, target.origin);
      return ok<PageInfo>(toPageInfo(page), { sessionId: owned.record.sessionId, pageId: page.pageId });
    } catch (error) {
      return toErrorResponse(error);
    }
  }

  private async listTabs(ctx?: ToolContext): Promise<ToolResponse> {
    if (!ctx) return this.noContext();
    const tabs = await this.pages.listUserTabs();
    return ok(tabs);
  }

  private async navigate(message: TransportMessage, ctx?: ToolContext): Promise<ToolResponse> {
    const resolved = this.resolveOwnedPage(message, ctx);
    if ("error" in resolved) return resolved.error;
    const input = navigateSchema.safeParse(message.payload);
    if (!input.success) {
      return err({ code: "UNSUPPORTED_ACTION", message: "Invalid navigate input; provide a url." });
    }
    if (!input.data.reload) {
      const target = parseTargetUrl(input.data.url);
      if (!target) return err({ code: "POLICY_DENIED", message: "Only http/https URLs are allowed." });
      if (!isHostAllowed(target.host, resolved.session.allowedDomains)) {
        return err({ code: "POLICY_DENIED", message: `Domain not allowed for this session: ${target.host}` });
      }
    }
    try {
      const result = await this.pages.navigate(resolved.page, input.data.url, Boolean(input.data.reload));
      return ok(result, { sessionId: resolved.session.sessionId, pageId: resolved.page.pageId });
    } catch (error) {
      return toErrorResponse(error);
    }
  }

  private async claimTab(message: TransportMessage, ctx?: ToolContext): Promise<ToolResponse> {
    const owned = this.resolveOwned(message.sessionId, ctx);
    if ("error" in owned) return owned.error;
    const gate = this.requireActive(owned.record);
    if (gate) return gate;

    if (owned.record.tabScope === "agent-created-only") {
      return err({
        code: "POLICY_DENIED",
        message: "This session's tab scope does not allow claiming user tabs.",
      });
    }
    const input = claimTabSchema.safeParse(message.payload);
    if (!input.success) {
      return err({ code: "UNSUPPORTED_ACTION", message: "Invalid claim_tab input." });
    }
    try {
      const page = await this.pages.claimTab(owned.record, input.data);
      return ok<PageInfo>(toPageInfo(page), { sessionId: owned.record.sessionId, pageId: page.pageId });
    } catch (error) {
      return toErrorResponse(error);
    }
  }

  private async releaseTab(message: TransportMessage, ctx?: ToolContext): Promise<ToolResponse> {
    const owned = this.resolveOwned(message.sessionId, ctx);
    if ("error" in owned) return owned.error;
    if (!message.pageId) {
      return err({ code: "ELEMENT_NOT_FOUND", message: "pageId is required for release_tab." });
    }
    const releasing = this.pages.get(message.pageId as PageId);
    if (releasing) await this.deps.debugger.detach(releasing.chromeTabId);
    try {
      await this.pages.release(owned.record, message.pageId as PageId);
      return ok({ released: message.pageId }, { sessionId: owned.record.sessionId, pageId: message.pageId });
    } catch (error) {
      return toErrorResponse(error);
    }
  }

  // --- observation tools ---

  private async takeSnapshot(message: TransportMessage, ctx?: ToolContext): Promise<ToolResponse> {
    const resolved = this.resolveOwnedPage(message, ctx);
    if ("error" in resolved) return resolved.error;
    const input = (message.payload ?? {}) as TakeSnapshotInput;
    try {
      const snapshot = await this.deps.snapshots.snapshot(resolved.page, input);
      return ok<Snapshot>(snapshot, { sessionId: resolved.session.sessionId, pageId: resolved.page.pageId });
    } catch (error) {
      return toErrorResponse(error);
    }
  }

  private async takeScreenshot(message: TransportMessage, ctx?: ToolContext): Promise<ToolResponse> {
    const resolved = this.resolveOwnedPage(message, ctx);
    if ("error" in resolved) return resolved.error;
    try {
      // Debugger capture works on background/inactive tabs; visible capture needs a focused tab.
      const meta =
        resolved.session.mode === "extension-debugger"
          ? await this.deps.debugger.captureScreenshot({
              sessionId: resolved.session.sessionId,
              pageId: resolved.page.pageId,
              chromeTabId: resolved.page.chromeTabId,
              tabGroupId: resolved.session.tabGroup.tabGroupId,
            })
          : await this.deps.screenshots.capture(
              { tabGroupId: resolved.session.tabGroup.tabGroupId },
              resolved.page,
            );
      return ok<ArtifactMetadata>(meta, { sessionId: resolved.session.sessionId, pageId: resolved.page.pageId });
    } catch (error) {
      return toErrorResponse(error);
    }
  }

  // --- debugger read tools ---

  private async listConsole(message: TransportMessage, ctx?: ToolContext): Promise<ToolResponse> {
    const resolved = this.resolveOwnedPage(message, ctx);
    if ("error" in resolved) return resolved.error;
    const payload = (message.payload ?? {}) as { level?: string; limit?: number };
    try {
      await this.deps.debugger.ensureAttached(resolved.page.chromeTabId);
      const messages = this.deps.debugger.listConsole(resolved.page.chromeTabId, payload);
      return ok(messages, { sessionId: resolved.session.sessionId, pageId: resolved.page.pageId });
    } catch (error) {
      return toErrorResponse(error);
    }
  }

  private async listNetwork(message: TransportMessage, ctx?: ToolContext): Promise<ToolResponse> {
    const resolved = this.resolveOwnedPage(message, ctx);
    if ("error" in resolved) return resolved.error;
    const payload = (message.payload ?? {}) as { limit?: number };
    try {
      await this.deps.debugger.ensureAttached(resolved.page.chromeTabId);
      const requests = this.deps.debugger.listNetwork(resolved.page.chromeTabId, payload);
      return ok(requests, { sessionId: resolved.session.sessionId, pageId: resolved.page.pageId });
    } catch (error) {
      return toErrorResponse(error);
    }
  }

  // --- CDP-backed tools (debugger attached on demand) ---

  private async evaluateScript(message: TransportMessage, ctx?: ToolContext): Promise<ToolResponse> {
    const resolved = this.resolveOwnedPage(message, ctx);
    if ("error" in resolved) return resolved.error;
    const payload = (message.payload ?? {}) as { expression?: string; script?: string };
    const expression = String(payload.expression ?? payload.script ?? "");
    if (!expression) return err({ code: "UNSUPPORTED_ACTION", message: "evaluate_script requires `expression`." });
    try {
      const result = await this.deps.debugger.evaluate(resolved.page.chromeTabId, expression);
      return ok(result, { sessionId: resolved.session.sessionId, pageId: resolved.page.pageId });
    } catch (error) {
      return toErrorResponse(error);
    }
  }

  private async resizePage(message: TransportMessage, ctx?: ToolContext): Promise<ToolResponse> {
    const resolved = this.resolveOwnedPage(message, ctx);
    if ("error" in resolved) return resolved.error;
    const p = (message.payload ?? {}) as { width?: number; height?: number; deviceScaleFactor?: number; mobile?: boolean; reset?: boolean };
    try {
      if (p.reset) {
        await this.deps.debugger.clearDeviceMetrics(resolved.page.chromeTabId);
      } else if (typeof p.width === "number" && typeof p.height === "number") {
        await this.deps.debugger.setDeviceMetrics(resolved.page.chromeTabId, {
          width: p.width,
          height: p.height,
          deviceScaleFactor: p.deviceScaleFactor,
          mobile: p.mobile,
        });
      } else {
        return err({ code: "UNSUPPORTED_ACTION", message: "resize_page requires numeric width and height (or reset=true)." });
      }
      return ok({ width: p.width, height: p.height, reset: Boolean(p.reset) }, { sessionId: resolved.session.sessionId, pageId: resolved.page.pageId });
    } catch (error) {
      return toErrorResponse(error);
    }
  }

  private async emulatePage(message: TransportMessage, ctx?: ToolContext): Promise<ToolResponse> {
    const resolved = this.resolveOwnedPage(message, ctx);
    if ("error" in resolved) return resolved.error;
    const p = (message.payload ?? {}) as Parameters<DebuggerManager["emulate"]>[1];
    try {
      await this.deps.debugger.emulate(resolved.page.chromeTabId, p ?? {});
      return ok({ applied: true }, { sessionId: resolved.session.sessionId, pageId: resolved.page.pageId });
    } catch (error) {
      return toErrorResponse(error);
    }
  }

  private async handleDialog(message: TransportMessage, ctx?: ToolContext): Promise<ToolResponse> {
    const resolved = this.resolveOwnedPage(message, ctx);
    if ("error" in resolved) return resolved.error;
    const p = (message.payload ?? {}) as { accept?: boolean; promptText?: string };
    try {
      const result = await this.deps.debugger.handleDialog(resolved.page.chromeTabId, Boolean(p.accept), p.promptText);
      return ok(result, { sessionId: resolved.session.sessionId, pageId: resolved.page.pageId });
    } catch (error) {
      return toErrorResponse(error);
    }
  }

  // --- page / tab management ---

  private getTabId(message: TransportMessage, ctx?: ToolContext): ToolResponse {
    const resolved = this.resolveOwnedPage(message, ctx);
    if ("error" in resolved) return resolved.error;
    return ok({ tabId: resolved.page.chromeTabId }, { sessionId: resolved.session.sessionId, pageId: resolved.page.pageId });
  }

  private listPages(message: TransportMessage, ctx?: ToolContext): ToolResponse {
    const owned = this.resolveOwned(message.sessionId, ctx);
    if ("error" in owned) return owned.error;
    const pages: PageSummary[] = this.pages.list(owned.record.sessionId).map((r) => ({
      pageId: r.pageId,
      url: r.url,
      title: r.title,
      leaseStatus: r.leaseStatus,
    }));
    return ok(pages, { sessionId: owned.record.sessionId });
  }

  private async closePage(message: TransportMessage, ctx?: ToolContext): Promise<ToolResponse> {
    const resolved = this.resolveOwnedPage(message, ctx);
    if ("error" in resolved) return resolved.error;
    try {
      await this.deps.debugger.detach(resolved.page.chromeTabId);
      await this.pages.closePage(resolved.session, resolved.page.pageId);
      return ok({ closed: resolved.page.pageId }, { sessionId: resolved.session.sessionId });
    } catch (error) {
      return toErrorResponse(error);
    }
  }

  private async selectPage(message: TransportMessage, ctx?: ToolContext): Promise<ToolResponse> {
    const resolved = this.resolveOwnedPage(message, ctx);
    if ("error" in resolved) return resolved.error;
    try {
      await this.pages.activate(resolved.page);
      return ok({ active: resolved.page.pageId }, { sessionId: resolved.session.sessionId, pageId: resolved.page.pageId });
    } catch (error) {
      return toErrorResponse(error);
    }
  }

  private async uploadFile(message: TransportMessage, ctx?: ToolContext): Promise<ToolResponse> {
    const resolved = this.resolveOwnedPage(message, ctx);
    if ("error" in resolved) return resolved.error;
    const p = (message.payload ?? {}) as { uid?: string; files?: unknown; snapshotId?: string; allowStale?: boolean };
    if (typeof p.uid !== "string" || !p.uid) return err({ code: "ELEMENT_NOT_FOUND", message: "upload_file requires `uid`." });
    const files = Array.isArray(p.files) ? p.files.filter((f): f is string => typeof f === "string") : [];
    if (files.length === 0) return err({ code: "UNSUPPORTED_ACTION", message: "upload_file requires `files` (absolute paths)." });
    const token = `bbup_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
    try {
      // Tag the element in the page so CDP can resolve it, then attach the files.
      await this.deps.actions.run(resolved.page, {
        type: "bb.tag_node",
        payload: { uid: p.uid, token },
        snapshotId: typeof p.snapshotId === "string" ? p.snapshotId : undefined,
        allowStale: Boolean(p.allowStale),
      });
      await this.deps.debugger.setFileInputFiles(resolved.page.chromeTabId, token, files);
      return ok({ uploaded: files.length, uid: p.uid }, { sessionId: resolved.session.sessionId, pageId: resolved.page.pageId });
    } catch (error) {
      return toErrorResponse(error);
    }
  }

  private async listWebmcpTools(message: TransportMessage, ctx?: ToolContext): Promise<ToolResponse> {
    const resolved = this.resolveOwnedPage(message, ctx);
    if ("error" in resolved) return resolved.error;
    try {
      const tools = await this.deps.debugger.listWebmcpTools(resolved.page.chromeTabId);
      return ok({ tools }, { sessionId: resolved.session.sessionId, pageId: resolved.page.pageId });
    } catch (error) {
      return toErrorResponse(error);
    }
  }

  private async executeWebmcpTool(message: TransportMessage, ctx?: ToolContext): Promise<ToolResponse> {
    const resolved = this.resolveOwnedPage(message, ctx);
    if ("error" in resolved) return resolved.error;
    const p = (message.payload ?? {}) as { toolName?: string; input?: unknown };
    if (typeof p.toolName !== "string" || !p.toolName) return err({ code: "UNSUPPORTED_ACTION", message: "execute_webmcp_tool requires `toolName`." });
    let input: Record<string, unknown> = {};
    if (typeof p.input === "string") {
      try {
        const parsed = JSON.parse(p.input);
        if (parsed && typeof parsed === "object") input = parsed as Record<string, unknown>;
      } catch {
        return err({ code: "UNSUPPORTED_ACTION", message: "`input` must be a JSON object or JSON-stringified object." });
      }
    } else if (p.input && typeof p.input === "object") {
      input = p.input as Record<string, unknown>;
    }
    try {
      const { value } = await this.deps.debugger.executeWebmcpTool(resolved.page.chromeTabId, p.toolName, input);
      let result: unknown = value;
      try {
        result = JSON.parse(value);
      } catch {
        /* keep raw string */
      }
      return ok({ result }, { sessionId: resolved.session.sessionId, pageId: resolved.page.pageId });
    } catch (error) {
      return toErrorResponse(error);
    }
  }

  // --- raw CDP passthrough (opt-in; see docs/design-raw-cdp-passthrough.md) ---

  private async cdpCommand(message: TransportMessage, ctx?: ToolContext): Promise<ToolResponse> {
    const resolved = this.resolveOwnedPage(message, ctx);
    if ("error" in resolved) return resolved.error;
    if (!resolved.session.allowRawCdp) {
      return err({ code: "POLICY_DENIED", message: "Raw CDP is disabled for this session; start it with allowRawCdp: true." });
    }
    const p = (message.payload ?? {}) as { method?: unknown; params?: unknown };
    const method = typeof p.method === "string" ? p.method : "";
    if (!method) return err({ code: "UNSUPPORTED_ACTION", message: "cdp_command requires a `method`." });
    if (!isCdpMethodAllowed(method)) {
      return err({ code: "POLICY_DENIED", message: `CDP method blocked by policy: ${method}` });
    }
    const params = p.params && typeof p.params === "object" ? (p.params as Record<string, unknown>) : undefined;
    try {
      const result = await this.deps.debugger.raw(resolved.page.chromeTabId, method, params);
      return ok({ result }, { sessionId: resolved.session.sessionId, pageId: resolved.page.pageId });
    } catch (error) {
      return toErrorResponse(error);
    }
  }

  private async cdpEvents(message: TransportMessage, ctx?: ToolContext): Promise<ToolResponse> {
    const resolved = this.resolveOwnedPage(message, ctx);
    if ("error" in resolved) return resolved.error;
    if (!resolved.session.allowRawCdp) {
      return err({ code: "POLICY_DENIED", message: "Raw CDP is disabled for this session; start it with allowRawCdp: true." });
    }
    const p = (message.payload ?? {}) as { since?: number; methods?: string[]; limit?: number };
    try {
      // Idempotent: starts capture on first poll, then returns events since the cursor.
      await this.deps.debugger.enableRawEvents(resolved.page.chromeTabId);
      const out = this.deps.debugger.listRawEvents(resolved.page.chromeTabId, {
        since: typeof p.since === "number" ? p.since : undefined,
        methods: Array.isArray(p.methods) ? p.methods.filter((m): m is string => typeof m === "string") : undefined,
        limit: typeof p.limit === "number" ? p.limit : undefined,
      });
      return ok(out, { sessionId: resolved.session.sessionId, pageId: resolved.page.pageId });
    } catch (error) {
      return toErrorResponse(error);
    }
  }

  // --- action tools ---

  private async runAction(message: TransportMessage, ctx: ToolContext | undefined, contentType: string): Promise<ToolResponse> {
    const resolved = this.resolveOwnedPage(message, ctx);
    if ("error" in resolved) return resolved.error;
    const payload = (message.payload ?? {}) as Record<string, unknown>;
    try {
      const { result, snapshot } = await this.deps.actions.run(resolved.page, {
        type: contentType,
        payload,
        snapshotId: typeof payload.snapshotId === "string" ? payload.snapshotId : undefined,
        allowStale: Boolean(payload.allowStale),
        includeSnapshot: Boolean(payload.includeSnapshot),
      });
      return ok(
        { ...result, ...(snapshot ? { snapshot } : {}) },
        { sessionId: resolved.session.sessionId, pageId: resolved.page.pageId },
      );
    } catch (error) {
      return toErrorResponse(error);
    }
  }

  // --- ownership / status gates (reused by page + observation tools) ---

  private resolveOwnedPage(
    message: TransportMessage,
    ctx?: ToolContext,
  ): { session: SessionRecord; page: PageRecord } | { error: ToolResponse } {
    const owned = this.resolveOwned(message.sessionId, ctx);
    if ("error" in owned) return { error: owned.error };
    const gate = this.requireActive(owned.record);
    if (gate) return { error: gate };
    if (!message.pageId) {
      return { error: err({ code: "ELEMENT_NOT_FOUND", message: "pageId is required for this tool." }) };
    }
    const page = this.pages.get(message.pageId as PageId);
    if (!page || page.sessionId !== owned.record.sessionId || page.leaseStatus !== "leased") {
      return { error: err({ code: "TAB_NOT_LEASED", message: `Page not leased by this session: ${message.pageId}` }) };
    }
    return { session: owned.record, page };
  }

  private resolveOwned(
    sessionId: SessionId | undefined,
    ctx?: ToolContext,
  ): { record: SessionRecord } | { error: ToolResponse } {
    if (!ctx) return { error: this.noContext() };
    if (!sessionId) {
      return { error: err({ code: "SESSION_NOT_FOUND", message: "sessionId is required for this tool." }) };
    }
    const record = this.sessions.get(sessionId);
    if (!record || record.agentId !== ctx.agentId) {
      return { error: err({ code: "SESSION_NOT_FOUND", message: `Session not found: ${sessionId}` }) };
    }
    return { record };
  }

  /** Page tools (Phase 4+) call this to reject paused/finalized sessions. */
  requireActive(record: SessionRecord): ToolResponse | undefined {
    if (record.status === "finalized") {
      return err({ code: "SESSION_FINALIZED", message: "Session is finalized." });
    }
    if (record.status === "paused") {
      return err({ code: "SESSION_PAUSED", message: "Session is paused; resume it before acting." });
    }
    return undefined;
  }

  private async detachSessionTabs(session: SessionRecord): Promise<void> {
    for (const page of this.pages.list(session.sessionId)) {
      await this.deps.debugger.detach(page.chromeTabId);
    }
  }

  private noContext(): ToolResponse {
    return err({ code: "SESSION_NOT_FOUND", message: "No connection context; complete the handshake first." });
  }
}

function toSummary(record: SessionRecord): SessionSummary {
  return {
    sessionId: record.sessionId,
    clientName: record.clientName,
    status: record.status,
    tabGroupId: record.tabGroup.tabGroupId,
    tabGroupTitle: record.tabGroup.title,
    tabGroupColor: record.tabGroup.color,
    pageCount: record.pageIds.length,
    lastActionAt: record.lastActionAt,
  };
}

function toPageInfo(record: PageRecord): PageInfo {
  return {
    pageId: record.pageId,
    sessionId: record.sessionId,
    url: record.url,
    title: record.title,
    tabGroupId: record.tabGroupId,
    leaseStatus: record.leaseStatus,
    createdByAgent: record.createdByAgent,
    claimedFromUser: record.claimedFromUser,
  };
}

function toErrorResponse(error: unknown): ToolResponse {
  if (error instanceof ToolError) {
    return err({ code: error.code, message: error.message, details: error.details });
  }
  return err({
    code: "UNSUPPORTED_ACTION",
    message: error instanceof Error ? error.message : "Unexpected error.",
  });
}

function toDetail(record: SessionRecord): SessionDetail {
  return {
    ...toSummary(record),
    agentId: record.agentId,
    mode: record.mode,
    sessionLabel: record.sessionLabel,
    allowedDomains: record.allowedDomains,
    tabScope: record.tabScope,
    allowRawCdp: record.allowRawCdp,
    tabGroup: record.tabGroup,
    pageIds: record.pageIds,
    createdAt: record.createdAt,
  };
}
