/**
 * Debugger port: the chrome.debugger surface DebuggerManager needs, abstracted
 * for testability. ChromeDebuggerPort is the thin real adapter.
 * See spec/01 §Debugger Backend.
 */

export type DebuggerEventListener = (tabId: number, method: string, params: unknown) => void;

export interface DebuggerPort {
  attach(tabId: number): Promise<void>;
  detach(tabId: number): Promise<void>;
  sendCommand(tabId: number, method: string, params?: Record<string, unknown>): Promise<unknown>;
  setEventListener(listener: DebuggerEventListener): void;
}

const CDP_VERSION = "1.3";

export class ChromeDebuggerPort implements DebuggerPort {
  private listener?: DebuggerEventListener;

  constructor() {
    chrome.debugger.onEvent.addListener((source, method, params) => {
      if (source.tabId != null) this.listener?.(source.tabId, method, params);
    });
  }

  async attach(tabId: number): Promise<void> {
    await chrome.debugger.attach({ tabId }, CDP_VERSION);
  }

  async detach(tabId: number): Promise<void> {
    await chrome.debugger.detach({ tabId });
  }

  async sendCommand(tabId: number, method: string, params?: Record<string, unknown>): Promise<unknown> {
    return chrome.debugger.sendCommand({ tabId }, method, params);
  }

  setEventListener(listener: DebuggerEventListener): void {
    this.listener = listener;
  }
}
