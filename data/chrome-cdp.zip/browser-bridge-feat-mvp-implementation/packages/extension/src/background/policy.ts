/**
 * Pure URL / domain policy helpers. See spec/02 §Host permission strategy.
 */

export interface TargetUrl {
  origin: string;
  host: string;
}

/** Accept only http/https targets. Returns undefined for unsupported/invalid URLs. */
export function parseTargetUrl(raw: string): TargetUrl | undefined {
  let url: URL;
  try {
    url = new URL(raw);
  } catch {
    return undefined;
  }
  if (url.protocol !== "http:" && url.protocol !== "https:") return undefined;
  return { origin: url.origin, host: url.host };
}

/** Empty allowlist means "allow all" (initial broad scope). Otherwise exact or suffix match. */
export function isHostAllowed(host: string, allowed: string[]): boolean {
  if (allowed.length === 0) return true;
  return allowed.some((a) => host === a || host.endsWith(`.${a}`));
}

export function safeOrigin(rawUrl: string): string {
  try {
    return new URL(rawUrl).origin;
  } catch {
    return "";
  }
}

/**
 * Raw CDP passthrough policy (denylist mode). Blocks browser/target-level and
 * other high-blast-radius methods that would escape the per-tab, owned-session
 * scope. Everything else is allowed once the session opted in (allowRawCdp).
 * See docs/design-raw-cdp-passthrough.md §4.
 */
const CDP_DENY_PREFIXES = ["Browser.", "Target.", "Fetch.", "Tethering.", "SystemInfo."];
const CDP_DENY_METHODS = new Set<string>([
  "Storage.clearDataForOrigin",
  "Page.setDownloadBehavior",
  "Page.setBypassCSP",
]);

export function isCdpMethodAllowed(method: string): boolean {
  if (typeof method !== "string" || !method.includes(".")) return false;
  if (CDP_DENY_METHODS.has(method)) return false;
  return !CDP_DENY_PREFIXES.some((prefix) => method.startsWith(prefix));
}
