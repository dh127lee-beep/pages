/**
 * Debugger Backend delegate (skeleton).
 * High-permission backend using `chrome.debugger` on session-owned tabs.
 * See spec/01-architecture.md §Debugger Backend.
 *
 * Debugger `Page.captureScreenshot` is the path for screenshots of
 * background/inactive tabs (see spec/04-extension-backend.md §Screenshot strategy).
 *
 * Stub: signatures only.
 */

import type { PageId } from "@browser-bridge/shared-protocol";

export class DebuggerBackend {
  attach(_pageId: PageId): Promise<void> {
    throw new Error("DebuggerBackend.attach not implemented");
  }

  detach(_pageId: PageId): Promise<void> {
    throw new Error("DebuggerBackend.detach not implemented");
  }

  captureScreenshot(_pageId: PageId): Promise<unknown> {
    throw new Error("DebuggerBackend.captureScreenshot not implemented");
  }
}
