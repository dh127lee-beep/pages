/**
 * Content Script Backend delegate (skeleton).
 * Default execution backend. Talks to the content script in a leased tab; never
 * trusts page content. See spec/01-architecture.md §Content Script Backend.
 *
 * Background execution: actions must work on leased tabs even when the tab or
 * its window is inactive, without stealing user focus
 * (see spec/04-extension-backend.md §Background execution).
 *
 * Stub: signatures only.
 */

import type { PageId } from "@browser-bridge/shared-protocol";

export class ContentBackend {
  snapshot(_pageId: PageId): Promise<unknown> {
    throw new Error("ContentBackend.snapshot not implemented");
  }

  click(_pageId: PageId, _uid: string): Promise<unknown> {
    throw new Error("ContentBackend.click not implemented");
  }

  fill(_pageId: PageId, _uid: string, _value: string): Promise<unknown> {
    throw new Error("ContentBackend.fill not implemented");
  }
}
