/**
 * Extension-side connection state machine (transport-agnostic, unit-testable).
 *
 * Handshake (auto-connect, no token):
 *   1. on connect: extension sends `bridge.hello`
 *   2. adapter replies `bridge.identify`
 *   3. extension registers the client, replies `bridge.welcome`
 * Then it acts as an RPC server: tool requests in -> ToolResponse out, by id.
 * Heartbeat: `bridge.ping` -> `bridge.pong`.
 *
 * See task/02-agent-bridge-transport.md and spec/02 connection policy.
 */

import {
  agentIdFromClientName,
  controlMessageSchema,
  isProtocolCompatible,
  isTransportResponse,
  makeResponse,
  transportMessageSchema,
  type ConnectionId,
  type ControlMessage,
  type ToolResponse,
  type TransportMessage,
  type TransportResponse,
} from "@browser-bridge/shared-protocol";
import type { ConnectionRegistry } from "../background/connection-registry.js";
import type { ToolContext } from "../background/context.js";

export type SessionSend = (message: ControlMessage | TransportResponse) => void;

export interface ConnectionSessionDeps {
  registry: ConnectionRegistry;
  handleTool: (message: TransportMessage, ctx: ToolContext | undefined) => Promise<ToolResponse>;
  protocolVersion: string;
  extensionVersion: string;
  onConnected?: (connectionId: ConnectionId) => void;
}

export class ConnectionSession {
  private connectionId?: ConnectionId;
  private context?: ToolContext;

  constructor(
    private readonly send: SessionSend,
    private readonly deps: ConnectionSessionDeps,
  ) {}

  /** Call once the socket is open. */
  start(): void {
    this.send({
      type: "bridge.hello",
      protocolVersion: this.deps.protocolVersion,
      extensionVersion: this.deps.extensionVersion,
    });
  }

  /** Handle one parsed inbound message (control or tool request). */
  receive(raw: unknown): void {
    const control = controlMessageSchema.safeParse(raw);
    if (control.success) {
      this.handleControl(control.data as ControlMessage);
      return;
    }

    // Responses to our own requests are not expected on this side; ignore them.
    if (isTransportResponse(raw)) return;

    const tool = transportMessageSchema.safeParse(raw);
    if (tool.success) {
      void this.handleTool(tool.data as TransportMessage);
      return;
    }
    // Unknown shape: ignore (never trust arbitrary input).
  }

  /** Call when the socket closes. */
  close(): void {
    if (this.connectionId) {
      this.deps.registry.unregister(this.connectionId);
      this.connectionId = undefined;
      this.context = undefined;
    }
  }

  private handleControl(message: ControlMessage): void {
    switch (message.type) {
      case "bridge.identify": {
        if (!isProtocolCompatible(message.protocolVersion, this.deps.protocolVersion)) {
          this.send({
            type: "bridge.reject",
            code: "VERSION_MISMATCH",
            message: `Adapter protocol ${message.protocolVersion} is incompatible with ${this.deps.protocolVersion}.`,
          });
          return;
        }
        const client = this.deps.registry.register(message.clientName, message.clientVersion);
        this.connectionId = client.connectionId;
        this.context = {
          agentId: agentIdFromClientName(message.clientName),
          connectionId: client.connectionId,
          clientName: message.clientName,
        };
        this.send({
          type: "bridge.welcome",
          protocolVersion: this.deps.protocolVersion,
          connectionId: client.connectionId,
        });
        this.deps.onConnected?.(client.connectionId);
        return;
      }
      case "bridge.ping":
        this.send({ type: "bridge.pong", nonce: message.nonce });
        return;
      default:
        // hello/welcome/pong/reject are not expected inbound here; ignore.
        return;
    }
  }

  private async handleTool(message: TransportMessage): Promise<void> {
    const response = await this.deps.handleTool(message, this.context);
    this.send(makeResponse(message.id, response));
  }
}
