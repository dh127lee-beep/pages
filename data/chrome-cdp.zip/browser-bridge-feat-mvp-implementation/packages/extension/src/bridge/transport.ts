/**
 * WebSocket transport (browser side).
 * The extension is the WS *client*: it auto-connects to the adapter's loopback
 * endpoint, runs the handshake via ConnectionSession, and reconnects with
 * backoff. See spec/02 connection policy and task/02.
 */

import type { ControlMessage, TransportResponse } from "@browser-bridge/shared-protocol";
import { logger } from "../lib/logger.js";
import { ConnectionSession, type ConnectionSessionDeps } from "./connection-session.js";

export interface WebSocketTransportOptions {
  url: string;
  makeSessionDeps: (send: (message: ControlMessage | TransportResponse) => void) => ConnectionSessionDeps;
  onStatusChange?: (status: "connected" | "disconnected") => void;
  minBackoffMs?: number;
  maxBackoffMs?: number;
}

export class WebSocketTransport {
  private ws?: WebSocket;
  private session?: ConnectionSession;
  private backoffMs: number;
  private stopped = false;
  private reconnectTimer?: ReturnType<typeof setTimeout>;

  private readonly minBackoffMs: number;
  private readonly maxBackoffMs: number;

  constructor(private readonly options: WebSocketTransportOptions) {
    this.minBackoffMs = options.minBackoffMs ?? 1_000;
    this.maxBackoffMs = options.maxBackoffMs ?? 30_000;
    this.backoffMs = this.minBackoffMs;
  }

  start(): void {
    this.stopped = false;
    this.connect();
  }

  /**
   * Force a reconnect attempt now if the link is down. Safe to call repeatedly:
   * a no-op while OPEN or CONNECTING. This is the recovery hook for the MV3
   * lifecycle — when the service worker is suspended, the internal backoff
   * setTimeout is lost, so an external waker (the bb-connect alarm) calls kick()
   * to revive a stranded transport instead of waiting on a timer that won't fire.
   */
  kick(): void {
    if (this.stopped) return;
    if (this.ws && (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CONNECTING)) {
      return;
    }
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
    this.reconnectTimer = undefined;
    this.backoffMs = this.minBackoffMs;
    this.connect();
  }

  stop(): void {
    this.stopped = true;
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
    this.ws?.close();
    this.ws = undefined;
  }

  private connect(): void {
    if (this.stopped) return;
    logger.debug("connecting", this.options.url);

    let ws: WebSocket;
    try {
      ws = new WebSocket(this.options.url);
    } catch (error) {
      logger.warn("connect failed", error);
      this.scheduleReconnect();
      return;
    }
    this.ws = ws;

    const send = (message: ControlMessage | TransportResponse): void => {
      if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(message));
    };
    this.session = new ConnectionSession(send, this.options.makeSessionDeps(send));

    ws.onopen = () => {
      this.backoffMs = this.minBackoffMs;
      this.session?.start();
      this.options.onStatusChange?.("connected");
    };

    ws.onmessage = (event: MessageEvent) => {
      let parsed: unknown;
      try {
        parsed = JSON.parse(typeof event.data === "string" ? event.data : "");
      } catch {
        return;
      }
      this.session?.receive(parsed);
    };

    ws.onclose = () => {
      this.session?.close();
      this.session = undefined;
      this.options.onStatusChange?.("disconnected");
      this.scheduleReconnect();
    };

    ws.onerror = () => {
      // onclose follows; reconnect handled there.
      ws.close();
    };
  }

  private scheduleReconnect(): void {
    if (this.stopped) return;
    const delay = this.backoffMs;
    this.backoffMs = Math.min(this.backoffMs * 2, this.maxBackoffMs);
    this.reconnectTimer = setTimeout(() => this.connect(), delay);
  }
}
