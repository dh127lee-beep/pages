/**
 * Native messaging transport (browser side).
 * Uses chrome.runtime.connectNative; Chrome handles framing, so we exchange
 * plain objects. Mirrors WebSocketTransport but is the production path (no local
 * port). See spec/05 §Native Messaging host and task/08.
 */

import type { ControlMessage, TransportResponse } from "@browser-bridge/shared-protocol";
import { logger } from "../lib/logger.js";
import { ConnectionSession, type ConnectionSessionDeps } from "./connection-session.js";

export interface NativeTransportOptions {
  hostName: string;
  makeSessionDeps: (send: (message: ControlMessage | TransportResponse) => void) => ConnectionSessionDeps;
  onStatusChange?: (status: "connected" | "disconnected") => void;
  /** Called when the native host is missing/unavailable, with a setup hint. */
  onUnavailable?: (message: string) => void;
}

export class NativeTransport {
  private port?: chrome.runtime.Port;
  private session?: ConnectionSession;

  constructor(private readonly options: NativeTransportOptions) {}

  /** Returns false if connectNative could not even create a port. */
  start(): boolean {
    let port: chrome.runtime.Port;
    try {
      port = chrome.runtime.connectNative(this.options.hostName);
    } catch (error) {
      this.options.onUnavailable?.(error instanceof Error ? error.message : String(error));
      return false;
    }
    this.port = port;

    const send = (message: ControlMessage | TransportResponse): void => port.postMessage(message);
    this.session = new ConnectionSession(send, this.options.makeSessionDeps(send));

    port.onMessage.addListener((message: unknown) => this.session?.receive(message));
    port.onDisconnect.addListener(() => {
      const error = chrome.runtime.lastError;
      if (error) {
        logger.warn("native host unavailable", error.message);
        this.options.onUnavailable?.(error.message ?? "native host disconnected");
      }
      this.session?.close();
      this.session = undefined;
      this.options.onStatusChange?.("disconnected");
    });

    this.session.start();
    this.options.onStatusChange?.("connected");
    return true;
  }

  stop(): void {
    this.port?.disconnect();
    this.session?.close();
    this.port = undefined;
    this.session = undefined;
  }
}
