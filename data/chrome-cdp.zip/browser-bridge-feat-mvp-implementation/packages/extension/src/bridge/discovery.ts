/**
 * Adapter endpoint discovery.
 *
 * NOTE: a Chrome MV3 service worker has no filesystem access, so it cannot read
 * the adapter's port file (~/.browser-bridge/ws-port). The extension therefore
 * connects to a fixed/configured loopback port; the port file is adapter-side
 * diagnostics only. See task/02-agent-bridge-transport.md.
 */

import { getLocal } from "../lib/storage.js";

export const DEFAULT_WS_PORT = 18470;
/** How many consecutive ports to scan from the base. Each reachable adapter on a
 *  port is a separate agent connection (sessions isolate by agentId/tab group).
 *  A range also makes the dev WS path resilient to a busy base port. */
export const DEFAULT_WS_PORT_COUNT = 10;
export const NATIVE_HOST_NAME = "com.browser_bridge.native_host";
const SETTINGS_KEY = "settings";

interface Settings {
  adapterPort?: number;
  adapterPortCount?: number;
}

async function readSettings(): Promise<Settings> {
  return (await getLocal<Settings>(SETTINGS_KEY)) ?? {};
}

/** The set of loopback ports the extension connects to (base … base+count-1). */
export async function getAdapterPorts(): Promise<number[]> {
  const settings = await readSettings();
  const base = settings.adapterPort && settings.adapterPort > 0 ? settings.adapterPort : DEFAULT_WS_PORT;
  const count = settings.adapterPortCount && settings.adapterPortCount > 0 ? settings.adapterPortCount : DEFAULT_WS_PORT_COUNT;
  return Array.from({ length: count }, (_unused, i) => base + i);
}

export function adapterUrl(port: number): string {
  return `ws://127.0.0.1:${port}`;
}
