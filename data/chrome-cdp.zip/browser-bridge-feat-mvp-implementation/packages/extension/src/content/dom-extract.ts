/**
 * DOM extraction (page context). Walks interesting elements and produces
 * RawElement + the live Element. Thin and DOM-dependent (not unit-tested); the
 * normalization/redaction logic lives in snapshot-builder.ts.
 */

import type { ElementBounds } from "@browser-bridge/shared-protocol";
import type { RawElement } from "./snapshot-builder.js";

const SELECTOR = [
  "a[href]",
  "button",
  "input",
  "select",
  "textarea",
  "[role]",
  "[contenteditable=''],[contenteditable='true']",
  "summary",
  "label",
].join(",");

const SAFE_ATTRS = ["type", "name", "placeholder", "role", "aria-label", "autocomplete", "id", "href"];

export interface ExtractedElement {
  raw: RawElement;
  el: Element;
}

export function extractRawElements(): ExtractedElement[] {
  const out: ExtractedElement[] = [];
  const nodes = document.querySelectorAll(SELECTOR);
  for (const el of Array.from(nodes)) {
    out.push({ raw: toRaw(el), el });
  }
  return out;
}

function toRaw(el: Element): RawElement {
  const tag = el.tagName.toLowerCase();
  const input = el as HTMLInputElement;
  const type = (el.getAttribute("type") ?? "").toLowerCase();
  const style = el instanceof HTMLElement ? getComputedStyle(el) : undefined;
  const rect = el.getBoundingClientRect();
  const visible =
    (!style || (style.display !== "none" && style.visibility !== "hidden")) &&
    rect.width > 0 &&
    rect.height > 0;
  const isHidden = type === "hidden" || el.getAttribute("aria-hidden") === "true" || !visible;

  const attributes: Record<string, string> = {};
  for (const name of SAFE_ATTRS) {
    const value = el.getAttribute(name);
    if (value != null) attributes[name] = name === "href" ? originOf(value) : value;
  }

  const bounds: ElementBounds = {
    x: Math.round(rect.x),
    y: Math.round(rect.y),
    width: Math.round(rect.width),
    height: Math.round(rect.height),
  };

  const isFormField = tag === "input" || tag === "textarea" || tag === "select";

  return {
    tag,
    role: el.getAttribute("role") ?? undefined,
    name: accessibleName(el),
    text: textOf(el),
    type: type || undefined,
    attributes,
    visible,
    enabled: !(el as HTMLButtonElement).disabled,
    bounds,
    isPassword: type === "password",
    isHidden,
    value: isFormField ? (input.value ?? undefined) : undefined,
  };
}

function accessibleName(el: Element): string {
  const aria = el.getAttribute("aria-label");
  if (aria) return aria.trim();
  const placeholder = el.getAttribute("placeholder");
  if (placeholder) return placeholder.trim();
  const id = el.getAttribute("id");
  if (id) {
    const label = document.querySelector(`label[for="${CSS.escape(id)}"]`);
    if (label?.textContent) return label.textContent.trim();
  }
  return (el.textContent ?? "").trim().slice(0, 120);
}

function textOf(el: Element): string | undefined {
  const text = (el.textContent ?? "").trim().replace(/\s+/g, " ");
  return text ? text.slice(0, 200) : undefined;
}

function originOf(href: string): string {
  try {
    return new URL(href, location.href).origin;
  } catch {
    return "";
  }
}
