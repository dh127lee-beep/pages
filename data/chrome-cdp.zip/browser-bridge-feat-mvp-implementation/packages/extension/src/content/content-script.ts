/**
 * Content script (persistent in leased tabs).
 * Builds DOM/a11y snapshots, keeps a uid->Element map, and performs page actions
 * (click/fill/scroll/press_key/wait_for) resolved by uid. Never trusts page
 * content. Injected programmatically via chrome.scripting.
 */

import type { ActionResult, RiskHint } from "@browser-bridge/shared-protocol";
import { extractRawElements } from "./dom-extract.js";
import { buildSnapshot } from "./snapshot-builder.js";

interface Entry {
  el: Element;
  riskHints: RiskHint[];
}

type Ok = { ok: true; snapshot?: unknown; result?: ActionResult };
type Fail = { ok: false; code: string; error: string };

const runtime = globalThis as unknown as { __bbContentInit?: boolean };

if (!runtime.__bbContentInit) {
  runtime.__bbContentInit = true;
  let idToEntry = new Map<string, Entry>();

  chrome.runtime.onMessage.addListener((message: unknown, _sender, sendResponse) => {
    const msg = message as { type?: string } | null;
    if (!msg?.type?.startsWith("bb.")) return false;

    handle(msg as Record<string, unknown> & { type: string })
      .then(sendResponse)
      .catch((e: unknown) =>
        sendResponse({ ok: false, code: "UNSUPPORTED_ACTION", error: e instanceof Error ? e.message : String(e) }),
      );
    return true;
  });

  async function handle(msg: Record<string, unknown> & { type: string }): Promise<Ok | Fail> {
    switch (msg.type) {
      case "bb.snapshot":
        return doSnapshot(msg);
      case "bb.click":
        return doAction(msg, (el) => {
          (el as HTMLElement).click();
        });
      case "bb.click_at":
        return doClickAt(msg);
      case "bb.hover":
        return doAction(msg, (el) => hover(el));
      case "bb.fill":
        return doAction(msg, (el) => fill(el, String(msg.value ?? ""), Boolean(msg.append)));
      case "bb.fill_form":
        return doFillForm(msg);
      case "bb.type_text":
        return doAction(msg, (el) => typeText(el, String(msg.text ?? msg.value ?? "")));
      case "bb.scroll":
        return doScroll(msg);
      case "bb.press_key":
        return doPressKey(msg);
      case "bb.drag":
        return doDrag(msg);
      case "bb.wait_for":
        return doWaitFor(msg);
      case "bb.tag_node":
        return doTagNode(msg);
      default:
        return { ok: false, code: "UNSUPPORTED_ACTION", error: `Unknown action: ${msg.type}` };
    }
  }

  function doSnapshot(msg: Record<string, unknown>): Ok {
    const extracted = extractRawElements();
    const { snapshot, includedIndices } = buildSnapshot({
      rawElements: extracted.map((e) => e.raw),
      snapshotId: String(msg.snapshotId),
      pageId: String(msg.pageId),
      url: location.href,
      title: document.title,
      capturedAt: new Date().toISOString(),
      includeHidden: Boolean(msg.includeHidden),
      includeBounds: msg.includeBounds === undefined ? true : Boolean(msg.includeBounds),
      includeRiskHints: msg.includeRiskHints === undefined ? true : Boolean(msg.includeRiskHints),
    });

    idToEntry = new Map();
    snapshot.elements.forEach((el, i) => {
      const source = extracted[includedIndices[i]!];
      if (source) idToEntry.set(el.uid, { el: source.el, riskHints: el.riskHints ?? [] });
    });

    return { ok: true, snapshot };
  }

  function resolve(uid: unknown): Entry | undefined {
    return typeof uid === "string" ? idToEntry.get(uid) : undefined;
  }

  async function doAction(
    msg: Record<string, unknown>,
    perform: (el: Element) => void,
  ): Promise<Ok | Fail> {
    const entry = resolve(msg.uid);
    if (!entry) return { ok: false, code: "ELEMENT_NOT_FOUND", error: `uid not in current snapshot: ${String(msg.uid)}` };
    const before = location.href;
    perform(entry.el);
    await settle();
    return { ok: true, result: { ...status(before), riskHints: entry.riskHints } };
  }

  async function doFillForm(msg: Record<string, unknown>): Promise<Ok | Fail> {
    const fields = Array.isArray(msg.fields) ? (msg.fields as Array<{ uid: string; value: string }>) : [];
    for (const field of fields) {
      const entry = resolve(field.uid);
      if (!entry) return { ok: false, code: "ELEMENT_NOT_FOUND", error: `uid not found: ${field.uid}` };
    }
    const before = location.href;
    for (const field of fields) {
      fill(resolve(field.uid)!.el, String(field.value ?? ""), false);
    }
    await settle();
    return { ok: true, result: status(before) };
  }

  async function doScroll(msg: Record<string, unknown>): Promise<Ok | Fail> {
    const before = location.href;
    if (typeof msg.uid === "string") {
      const entry = resolve(msg.uid);
      if (!entry) return { ok: false, code: "ELEMENT_NOT_FOUND", error: `uid not found: ${msg.uid}` };
      entry.el.scrollIntoView({ block: "center" });
    } else {
      const amount = typeof msg.amount === "number" ? msg.amount : window.innerHeight * 0.8;
      window.scrollBy({ top: msg.direction === "up" ? -amount : amount });
    }
    await settle(150);
    return { ok: true, result: status(before) };
  }

  async function doPressKey(msg: Record<string, unknown>): Promise<Ok | Fail> {
    const key = String(msg.key ?? "");
    const target = typeof msg.uid === "string" ? resolve(msg.uid)?.el : document.activeElement;
    if (typeof msg.uid === "string" && !target) {
      return { ok: false, code: "ELEMENT_NOT_FOUND", error: `uid not found: ${msg.uid}` };
    }
    const el = (target ?? document.body) as HTMLElement;
    const before = location.href;
    const riskHints: RiskHint[] = [];
    if (key === "Enter" && el.closest("form")) riskHints.push("submit");

    for (const phase of ["keydown", "keypress", "keyup"] as const) {
      el.dispatchEvent(new KeyboardEvent(phase, { key, bubbles: true, cancelable: true }));
    }
    await settle();
    return { ok: true, result: { ...status(before), riskHints } };
  }

  async function doWaitFor(msg: Record<string, unknown>): Promise<Ok | Fail> {
    const timeoutMs = typeof msg.timeoutMs === "number" ? msg.timeoutMs : 5000;
    const deadline = Date.now() + timeoutMs;
    const text = typeof msg.text === "string" ? msg.text : undefined;
    const url = typeof msg.url === "string" ? msg.url : undefined;

    while (Date.now() < deadline) {
      if (text && document.body?.innerText.includes(text)) {
        return { ok: true, result: { ...status(location.href), matched: `text:${text}` } };
      }
      if (url && location.href.includes(url)) {
        return { ok: true, result: { ...status(location.href), matched: `url:${url}` } };
      }
      if (!text && !url) break;
      await delay(120);
    }
    if (!text && !url) return { ok: true, result: status(location.href) };
    return { ok: false, code: "ACTION_TIMEOUT", error: "wait_for condition not met before timeout" };
  }

  // Tag the uid element with a transient attribute so the background can resolve it
  // to a CDP node (used by upload_file -> DOM.setFileInputFiles).
  async function doTagNode(msg: Record<string, unknown>): Promise<Ok | Fail> {
    const entry = resolve(msg.uid);
    if (!entry) return { ok: false, code: "ELEMENT_NOT_FOUND", error: `uid not in current snapshot: ${String(msg.uid)}` };
    const token = String(msg.token ?? "");
    if (!token) return { ok: false, code: "UNSUPPORTED_ACTION", error: "tag_node requires a token" };
    entry.el.setAttribute("data-bb-cdp", token);
    return { ok: true, result: status(location.href) };
  }

  async function doClickAt(msg: Record<string, unknown>): Promise<Ok | Fail> {
    const x = Number(msg.x);
    const y = Number(msg.y);
    if (!Number.isFinite(x) || !Number.isFinite(y)) {
      return { ok: false, code: "UNSUPPORTED_ACTION", error: "click_at requires numeric x and y" };
    }
    const el = document.elementFromPoint(x, y);
    if (!el) return { ok: false, code: "ELEMENT_NOT_FOUND", error: `no element at (${x}, ${y})` };
    const before = location.href;
    for (const phase of ["pointerdown", "mousedown", "pointerup", "mouseup", "click"] as const) {
      el.dispatchEvent(new MouseEvent(phase, { bubbles: true, cancelable: true, clientX: x, clientY: y }));
    }
    await settle();
    return { ok: true, result: status(before) };
  }

  function hover(el: Element): void {
    el.dispatchEvent(new MouseEvent("pointerover", { bubbles: true }));
    el.dispatchEvent(new MouseEvent("mouseover", { bubbles: true }));
    el.dispatchEvent(new MouseEvent("pointerenter", { bubbles: false }));
    el.dispatchEvent(new MouseEvent("mouseenter", { bubbles: false }));
    el.dispatchEvent(new MouseEvent("mousemove", { bubbles: true }));
  }

  function typeText(el: Element, text: string): void {
    const node = el as HTMLElement;
    node.focus?.();
    const input = el as HTMLInputElement;
    for (const ch of text) {
      node.dispatchEvent(new KeyboardEvent("keydown", { key: ch, bubbles: true }));
      if ("value" in input) {
        input.value = `${input.value}${ch}`;
        input.dispatchEvent(new Event("input", { bubbles: true }));
      } else if (node.isContentEditable) {
        node.textContent = `${node.textContent ?? ""}${ch}`;
        node.dispatchEvent(new Event("input", { bubbles: true }));
      }
      node.dispatchEvent(new KeyboardEvent("keyup", { key: ch, bubbles: true }));
    }
    if ("value" in input) input.dispatchEvent(new Event("change", { bubbles: true }));
  }

  async function doDrag(msg: Record<string, unknown>): Promise<Ok | Fail> {
    const from = resolve(msg.fromUid ?? msg.uid);
    const to = resolve(msg.toUid);
    if (!from) return { ok: false, code: "ELEMENT_NOT_FOUND", error: `drag source uid not found: ${String(msg.fromUid ?? msg.uid)}` };
    if (!to) return { ok: false, code: "ELEMENT_NOT_FOUND", error: `drag target uid not found: ${String(msg.toUid)}` };
    const before = location.href;
    const dt = new DataTransfer();
    const ev = (type: string, el: Element) => el.dispatchEvent(new DragEvent(type, { bubbles: true, cancelable: true, dataTransfer: dt }));
    ev("dragstart", from.el);
    ev("dragenter", to.el);
    ev("dragover", to.el);
    ev("drop", to.el);
    ev("dragend", from.el);
    await settle();
    return { ok: true, result: status(before) };
  }

  function fill(el: Element, value: string, append: boolean): void {
    const input = el as HTMLInputElement;
    if ("value" in input) {
      input.value = append ? `${input.value}${value}` : value;
      input.dispatchEvent(new Event("input", { bubbles: true }));
      input.dispatchEvent(new Event("change", { bubbles: true }));
    } else if ((el as HTMLElement).isContentEditable) {
      (el as HTMLElement).textContent = append ? `${(el as HTMLElement).textContent ?? ""}${value}` : value;
    }
  }

  function status(before: string): ActionResult {
    return { url: location.href, title: document.title, navigated: location.href !== before };
  }

  function settle(ms = 150): Promise<void> {
    return new Promise((resolve) => {
      let timer = setTimeout(done, ms);
      const cap = setTimeout(done, 800);
      const observer = new MutationObserver(() => {
        clearTimeout(timer);
        timer = setTimeout(done, ms);
      });
      function done(): void {
        clearTimeout(timer);
        clearTimeout(cap);
        observer.disconnect();
        resolve();
      }
      // Watch structural changes only. Observing `attributes` made the timer reset
      // on every class/style tick from animations/ads, so it pegged the 2s cap on
      // active pages; childList+subtree is enough to detect the DOM settling.
      observer.observe(document, { subtree: true, childList: true });
    });
  }

  function delay(ms: number): Promise<void> {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
}

export {};
