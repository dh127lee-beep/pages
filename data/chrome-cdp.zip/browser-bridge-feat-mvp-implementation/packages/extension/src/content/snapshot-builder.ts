/**
 * Pure snapshot normalization: RawElement[] -> Snapshot.
 * Assigns snapshot-local uids, applies redaction and risk hints, filters hidden
 * elements. No DOM/chrome access so it is unit-testable. DOM extraction lives in
 * dom-extract.ts. See spec/03 §Snapshot contract and spec/02 §Redaction.
 */

import type {
  ElementBounds,
  RiskHint,
  Snapshot,
  SnapshotElement,
} from "@browser-bridge/shared-protocol";

export interface RawElement {
  tag: string;
  role?: string;
  name?: string;
  text?: string;
  type?: string;
  attributes: Record<string, string>;
  visible: boolean;
  enabled: boolean;
  bounds?: ElementBounds;
  isPassword?: boolean;
  isHidden?: boolean;
  value?: string;
}

export interface BuildSnapshotInput {
  rawElements: RawElement[];
  snapshotId: string;
  pageId: string;
  url: string;
  title: string;
  capturedAt: string;
  includeHidden?: boolean;
  includeBounds?: boolean;
  includeRiskHints?: boolean;
  maxElements?: number;
}

export interface BuildSnapshotResult {
  snapshot: Snapshot;
  /** Index into the input rawElements for each emitted element (uid order). */
  includedIndices: number[];
}

const DEFAULT_MAX_ELEMENTS = 1500;

export function computeRiskHints(raw: RawElement): RiskHint[] {
  const hints = new Set<RiskHint>();
  const type = (raw.type ?? raw.attributes.type ?? "").toLowerCase();
  const tag = raw.tag.toLowerCase();
  const role = (raw.role ?? raw.attributes.role ?? "").toLowerCase();
  const haystack = `${raw.name ?? ""} ${raw.attributes.name ?? ""} ${raw.attributes.autocomplete ?? ""} ${raw.attributes.id ?? ""}`.toLowerCase();

  if (raw.isPassword || type === "password") hints.add("password");
  if (type === "file") hints.add("upload");
  if (type === "submit" || (tag === "button" && (type === "submit" || type === ""))) hints.add("submit");
  if (role === "button" && /submit|search|continue|pay/.test(haystack)) hints.add("submit");
  if (/\b(card|cc|credit|payment|cvv|cvc|expir)\b/.test(haystack) || /^cc-/.test((raw.attributes.autocomplete ?? "").toLowerCase())) {
    hints.add("payment");
  }
  return [...hints];
}

export function buildSnapshot(input: BuildSnapshotInput): BuildSnapshotResult {
  const includeHidden = input.includeHidden ?? false;
  const includeBounds = input.includeBounds ?? true;
  const includeRiskHints = input.includeRiskHints ?? true;
  const max = input.maxElements ?? DEFAULT_MAX_ELEMENTS;

  const elements: SnapshotElement[] = [];
  const includedIndices: number[] = [];
  let truncated = false;

  for (let i = 0; i < input.rawElements.length; i++) {
    const raw = input.rawElements[i]!;
    const hidden = raw.isHidden || !raw.visible;
    if (hidden && !includeHidden) continue;

    if (elements.length >= max) {
      truncated = true;
      break;
    }

    const uid = `${input.snapshotId}_${elements.length}`;
    const riskHints = includeRiskHints ? computeRiskHints(raw) : [];
    const redacted = raw.isPassword || riskHints.includes("password") || riskHints.includes("payment");

    const element: SnapshotElement = {
      uid,
      role: raw.role ?? roleForTag(raw.tag, raw.type),
      name: raw.name ?? "",
      tag: raw.tag.toLowerCase(),
      visible: raw.visible,
      enabled: raw.enabled,
    };
    if (raw.text) element.text = raw.text;
    if (includeBounds && raw.bounds) element.bounds = raw.bounds;
    if (Object.keys(raw.attributes).length > 0) element.attributes = raw.attributes;
    if (riskHints.length > 0) element.riskHints = riskHints;

    // Redaction: never expose hidden values; redact password/payment values.
    if (raw.value !== undefined && !hidden) {
      if (redacted) {
        element.valueRedacted = true;
      } else {
        element.value = raw.value;
      }
    } else if (redacted) {
      element.valueRedacted = true;
    }

    elements.push(element);
    includedIndices.push(i);
  }

  const snapshot: Snapshot = {
    snapshotId: input.snapshotId,
    pageId: input.pageId,
    url: input.url,
    title: input.title,
    capturedAt: input.capturedAt,
    source: "untrusted_page",
    elements,
  };
  if (truncated) snapshot.truncated = true;

  return { snapshot, includedIndices };
}

function roleForTag(tag: string, type?: string): string {
  const t = tag.toLowerCase();
  if (t === "a") return "link";
  if (t === "button") return "button";
  if (t === "select") return "combobox";
  if (t === "textarea") return "textbox";
  if (t === "input") {
    const it = (type ?? "").toLowerCase();
    if (it === "checkbox") return "checkbox";
    if (it === "radio") return "radio";
    if (it === "button" || it === "submit") return "button";
    return "textbox";
  }
  return t;
}
