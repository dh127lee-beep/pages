/**
 * MV3 service worker entry point.
 * Bootstraps the bridge + session manager and auto-connects to the local adapter
 * over WebSocket. Auto-connect, no pairing token (spec/02 connection policy).
 */

import { PROTOCOL_VERSION } from "@browser-bridge/shared-protocol";
import { ActionManager } from "./background/action-manager.js";
import { ArtifactRegistry } from "./background/artifacts.js";
import { AuditLog } from "./background/audit-log.js";
import { Bridge } from "./background/bridge.js";
import { ChromeCapabilitiesProvider } from "./background/capabilities.js";
import { ConnectionRegistry, type RegisteredClient } from "./background/connection-registry.js";
import { DebuggerManager } from "./background/debugger-manager.js";
import { ChromeDebuggerPort } from "./background/debugger-port.js";
import { PageManager } from "./background/page-manager.js";
import { ChromePageStore } from "./background/page-store.js";
import { ChromeScreenshotPort, ScreenshotManager } from "./background/screenshot-manager.js";
import { SessionManager } from "./background/session-manager.js";
import { ChromeSessionStore } from "./background/session-store.js";
import { ChromeContentMessenger, SnapshotManager } from "./background/snapshot-manager.js";
import { ChromeTabsPort } from "./background/tabs-port.js";
import { NATIVE_HOST_NAME, adapterUrl, getAdapterPorts } from "./bridge/discovery.js";
import { NativeTransport } from "./bridge/native-transport.js";
import { WebSocketTransport } from "./bridge/transport.js";
import { logger } from "./lib/logger.js";
import { setSession } from "./lib/storage.js";
import {
  CONNECTION_STATE_KEY,
  RECENT_ACTIVITY_KEY,
  RECENT_ACTIVITY_LIMIT,
  initialConnectionState,
  initialRecentActivity,
  type ActivityEvent,
  type ConnectionState,
} from "./state/connection-state.js";

const sessions = new SessionManager(new ChromeSessionStore());
const pages = new PageManager(new ChromeTabsPort(), sessions, new ChromePageStore());
const artifacts = new ArtifactRegistry();
const messenger = new ChromeContentMessenger();
const snapshots = new SnapshotManager(messenger, pages);
const screenshots = new ScreenshotManager(new ChromeScreenshotPort(), artifacts);
const actions = new ActionManager(messenger, pages, snapshots);
const debuggerManager = new DebuggerManager(new ChromeDebuggerPort(), artifacts);
let nativeConnected = false;
// Surface each handled tool call to the popup's "Recent activity" list.
const audit = new AuditLog(1000, () => Date.now(), () => {
  void publishActivity();
});
const bridge = new Bridge({
  capabilities: new ChromeCapabilitiesProvider(() => nativeConnected),
  sessions,
  pages,
  snapshots,
  screenshots,
  actions,
  debugger: debuggerManager,
  audit,
});
const registry = new ConnectionRegistry();

const SESSION_IDLE_MS = 30 * 60 * 1000;
chrome.alarms.create("bb-reap-idle", { periodInMinutes: 5 });
// Reconnect supervisor: periodically wake the (MV3) service worker and reconnect
// if the link is down. This is what makes "Chrome open → auto-connect" reliable
// without the user doing anything — the agent app just needs its endpoint up.
chrome.alarms.create("bb-connect", { periodInMinutes: 0.5 });
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "bb-reap-idle") {
    void bridge.reapIdleSessions(SESSION_IDLE_MS).then(publishState);
  } else if (alarm.name === "bb-connect") {
    ensureConnected();
  }
});

chrome.runtime.onStartup.addListener(() => {
  void boot();
});

chrome.tabs.onRemoved.addListener((tabId) => {
  void Promise.all([pages.onTabRemoved(tabId), debuggerManager.detach(tabId)]).then(publishState);
});

let status: ConnectionState["status"] = "disconnected";
let clients: RegisteredClient[] = [];

async function publishState(): Promise<void> {
  const state: ConnectionState = {
    status,
    clients: clients.map((c) => ({ connectionId: c.connectionId, clientName: c.clientName })),
    sessionCount: sessions.list().filter((s) => s.status !== "finalized").length,
    debuggerAttached: debuggerManager.attachedCount(),
  };
  await setSession(CONNECTION_STATE_KEY, state);
}

async function publishActivity(): Promise<void> {
  const events: ActivityEvent[] = audit.recent(RECENT_ACTIVITY_LIMIT).map((e) => ({
    auditId: e.auditId,
    ts: e.ts,
    type: e.type,
    ok: e.ok,
    code: e.code,
    clientName: e.clientName,
    sessionId: e.sessionId,
  }));
  await setSession(RECENT_ACTIVITY_KEY, events);
}

registry.setOnChange((next) => {
  clients = next;
  void publishState();
});

chrome.runtime.onInstalled.addListener(async () => {
  logger.info("installed");
  await setSession(CONNECTION_STATE_KEY, initialConnectionState);
  await setSession(RECENT_ACTIVITY_KEY, initialRecentActivity);
});

function sessionDeps() {
  return {
    registry,
    handleTool: (message: unknown, ctx: Parameters<typeof bridge.handleMessage>[1]) => bridge.handleMessage(message, ctx),
    protocolVersion: PROTOCOL_VERSION,
    extensionVersion: chrome.runtime.getManifest().version,
  };
}

let nativeTransport: NativeTransport | undefined;
const wsTransports = new Map<string, WebSocketTransport>();
const connectedEndpoints = new Set<string>(); // keys of links currently up

function recomputeStatus(): void {
  status = connectedEndpoints.size > 0 ? "connected" : "disconnected";
  nativeConnected = connectedEndpoints.has("native");
  void publishState();
}

function endpointStatus(key: string): (next: ConnectionState["status"]) => void {
  return (next) => {
    if (next === "connected") connectedEndpoints.add(key);
    else connectedEndpoints.delete(key);
    recomputeStatus();
  };
}

/**
 * Idempotent: connect to every endpoint once. The extension is the hub — it
 * connects to Native Messaging AND each adapter port in the range concurrently;
 * each link is a separate agent (sessions isolate by agentId / tab group). Each
 * transport self-retries with backoff while the worker is alive.
 */
function startTransports(): void {
  if (nativeTransport === undefined) {
    nativeTransport = new NativeTransport({
      hostName: NATIVE_HOST_NAME,
      makeSessionDeps: sessionDeps,
      onStatusChange: endpointStatus("native"),
      onUnavailable: () => endpointStatus("native")("disconnected"),
    });
    nativeTransport.start();
  }
  void getAdapterPorts().then((ports) => {
    for (const port of ports) {
      const url = adapterUrl(port);
      const existing = wsTransports.get(url);
      if (existing) {
        // Already registered: revive it if its link is down. The reconnect alarm
        // funnels here, so a transport stranded by service-worker suspension
        // (its backoff setTimeout was lost) gets re-kicked instead of skipped.
        existing.kick();
        continue;
      }
      const transport = new WebSocketTransport({ url, onStatusChange: endpointStatus(url), makeSessionDeps: sessionDeps });
      wsTransports.set(url, transport);
      transport.start();
    }
    logger.info("connecting to adapters:", ports.join(", "));
  });
}

/**
 * Called by the reconnect alarm: create any missing transports and re-kick any
 * existing ones whose link is down. The alarm survives worker suspension, so this
 * is what makes a late-arriving agent connect without a manual extension reload.
 */
function ensureConnected(): void {
  startTransports();
}

async function boot(): Promise<void> {
  await sessions.hydrate();
  await pages.hydrate();
  await publishState();
  startTransports();
  logger.info("service worker started");
}

void boot();
