/**
 * Thin wrappers around chrome.storage. Durable session metadata uses
 * `chrome.storage.session`; user settings use `chrome.storage.local`.
 * See spec/01-architecture.md §MV3 lifecycle constraints.
 */

export async function getLocal<T>(key: string): Promise<T | undefined> {
  const out = await chrome.storage.local.get(key);
  return out[key] as T | undefined;
}

export async function setLocal<T>(key: string, value: T): Promise<void> {
  await chrome.storage.local.set({ [key]: value });
}

export async function getSession<T>(key: string): Promise<T | undefined> {
  const out = await chrome.storage.session.get(key);
  return out[key] as T | undefined;
}

export async function setSession<T>(key: string, value: T): Promise<void> {
  await chrome.storage.session.set({ [key]: value });
}
