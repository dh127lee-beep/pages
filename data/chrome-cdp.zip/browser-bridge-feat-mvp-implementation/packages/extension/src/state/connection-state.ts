/** Connected/disconnected model surfaced in the popup. */

export interface ConnectedClient {
  connectionId: string;
  clientName: string;
}

export interface ConnectionState {
  status: "disconnected" | "connected";
  clients: ConnectedClient[];
  sessionCount: number;
  debuggerAttached: number;
}

export const CONNECTION_STATE_KEY = "connectionState";

export const initialConnectionState: ConnectionState = {
  status: "disconnected",
  clients: [],
  sessionCount: 0,
  debuggerAttached: 0,
};

/** One recent tool call the extension handled, surfaced in the popup. */
export interface ActivityEvent {
  auditId: string;
  ts: number;
  type: string;
  ok: boolean;
  code?: string;
  clientName?: string;
  sessionId?: string;
}

export const RECENT_ACTIVITY_KEY = "recentActivity";

/** How many recent events the popup shows. */
export const RECENT_ACTIVITY_LIMIT = 50;

export const initialRecentActivity: ActivityEvent[] = [];
