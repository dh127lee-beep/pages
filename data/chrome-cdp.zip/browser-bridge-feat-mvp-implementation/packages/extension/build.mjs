// esbuild bundler for the MV3 extension.
// Each entry is bundled to a single IIFE file (no ESM in the browser), then the
// static manifest/HTML/CSS assets are copied into dist/.
import { build } from "esbuild";
import { cp, mkdir, rm } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const root = dirname(fileURLToPath(import.meta.url));
const srcDir = resolve(root, "src");
const distDir = resolve(root, "dist");
const sharedSrc = resolve(root, "../shared-protocol/src/index.ts");

const watch = process.argv.includes("--watch");

const entryPoints = {
  "service-worker": resolve(srcDir, "service-worker.ts"),
  "content-script": resolve(srcDir, "content/content-script.ts"),
  popup: resolve(srcDir, "popup/popup.ts"),
  options: resolve(srcDir, "options/options.ts"),
};

const staticAssets = [
  ["manifest.json", "manifest.json"],
  ["src/popup/popup.html", "popup.html"],
  ["src/popup/popup.css", "popup.css"],
  ["src/options/options.html", "options.html"],
];

async function copyAssets() {
  for (const [from, to] of staticAssets) {
    await cp(resolve(root, from), resolve(distDir, to));
  }
}

async function run() {
  await rm(distDir, { recursive: true, force: true });
  await mkdir(distDir, { recursive: true });

  await build({
    entryPoints,
    outdir: distDir,
    bundle: true,
    format: "iife",
    target: ["chrome116"],
    sourcemap: true,
    logLevel: "info",
    // Resolve the workspace package directly from source so the build does not
    // depend on shared-protocol being compiled first.
    alias: {
      "@browser-bridge/shared-protocol": sharedSrc,
    },
  });

  await copyAssets();
  console.log(`[browser-bridge] extension built to ${distDir}`);
}

run().catch((error) => {
  console.error(error);
  process.exit(1);
});

if (watch) {
  console.warn("[browser-bridge] --watch is not implemented in the skeleton build.");
}
