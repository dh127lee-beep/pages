/**
 * Local filesystem artifact store (skeleton).
 * Writes under a per-session directory; see spec/05 recommended structure:
 *   .browser-bridge/artifacts/<sessionId>/...
 *
 * Stub: signatures only.
 */

import type { ArtifactId, SessionId } from "@browser-bridge/shared-protocol";
import type { ArtifactMeta, ArtifactStore, PutResult } from "./index.js";

export class LocalFsStore implements ArtifactStore {
  constructor(private readonly rootDir: string) {}

  put(_meta: Omit<ArtifactMeta, "artifactId">, _data: Uint8Array): Promise<PutResult> {
    throw new Error("LocalFsStore.put not implemented");
  }

  getPath(_artifactId: ArtifactId): Promise<string | undefined> {
    throw new Error("LocalFsStore.getPath not implemented");
  }

  cleanup(_sessionId: SessionId): Promise<void> {
    throw new Error("LocalFsStore.cleanup not implemented");
  }
}
