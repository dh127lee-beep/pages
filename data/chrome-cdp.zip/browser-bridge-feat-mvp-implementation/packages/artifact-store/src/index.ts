/**
 * Artifact store interface (skeleton).
 * Stores/forwards large results (screenshots, traces, logs) keyed by session.
 * See spec/05-local-bridge-and-cdp-backend.md §Session-aware artifact store.
 */

import type { ArtifactId, PageId, SessionId, TabGroupId } from "@browser-bridge/shared-protocol";

export interface ArtifactMeta {
  artifactId: ArtifactId;
  sessionId: SessionId;
  pageId?: PageId;
  tabGroupId?: TabGroupId;
  kind: "screenshot" | "network" | "console" | "trace" | "snapshot";
  contentType: string;
}

export interface PutResult {
  artifactId: ArtifactId;
  /** Local path, returned only when the client can access it. */
  path?: string;
}

export interface ArtifactStore {
  put(meta: Omit<ArtifactMeta, "artifactId">, data: Uint8Array): Promise<PutResult>;
  getPath(artifactId: ArtifactId): Promise<string | undefined>;
  cleanup(sessionId: SessionId): Promise<void>;
}

export { LocalFsStore } from "./local-fs-store.js";
