/**
 * Declarative CDP recipes — define a browser tool as a sequence of raw CDP calls
 * in JSON, no code. A recipe compiles to a CdpTool (see cdp-tools.ts), so it
 * flows through the same MCP registration path. Skill-directory style loading
 * (browser-harness) is `loadRecipesFromDir`. See docs/design-raw-cdp-passthrough.md §2.3.
 */

import { readFile, readdir } from "node:fs/promises";
import { join } from "node:path";
import type { Cdp, CdpTool } from "./cdp-tools.js";

export interface CdpRecipeStep {
  method: string;
  params?: Record<string, unknown>;
}

export interface CdpRecipe {
  name: string;
  description: string;
  inputSchema?: { properties?: Record<string, unknown>; required?: string[] };
  steps: CdpRecipeStep[];
  /**
   * What to return. Omit → the last step's result. A number → that step's result
   * (0-based). A string → dotted path, optionally prefixed with "stepN." into a
   * step result, else into the last step (e.g. "root.nodeId", "1.root.nodeId").
   */
  result?: number | string;
}

const TEMPLATE = /^\{\{\s*([\w.[\]]+)\s*\}\}$/;

/** Resolve {{args.x}} / {{stepN.path}} templates inside a params object. */
function resolveTemplates(value: unknown, ctx: { args: Record<string, unknown>; steps: unknown[] }): unknown {
  if (typeof value === "string") {
    const m = TEMPLATE.exec(value);
    if (!m) return value;
    return readPath(m[1]!, ctx);
  }
  if (Array.isArray(value)) return value.map((v) => resolveTemplates(v, ctx));
  if (value && typeof value === "object") {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(value)) out[k] = resolveTemplates(v, ctx);
    return out;
  }
  return value;
}

/** Read a dotted path like "args.q" or "step0.root.nodeId" from the recipe context. */
function readPath(path: string, ctx: { args: Record<string, unknown>; steps: unknown[] }): unknown {
  const parts = path.split(".");
  const head = parts[0]!;
  let cur: unknown;
  if (head === "args") cur = ctx.args;
  else if (/^step\d+$/.test(head)) cur = ctx.steps[Number(head.slice(4))];
  else return undefined;
  for (const p of parts.slice(1)) {
    if (cur == null || typeof cur !== "object") return undefined;
    cur = (cur as Record<string, unknown>)[p];
  }
  return cur;
}

function extractResult(recipe: CdpRecipe, steps: unknown[]): unknown {
  const r = recipe.result;
  if (r === undefined) return steps[steps.length - 1];
  if (typeof r === "number") return steps[r];
  // string: optional "stepN." prefix, else into the last step
  const m = /^step(\d+)\.(.*)$/.exec(r);
  if (m) return readPath(`step${m[1]}.${m[2]}`, { args: {}, steps });
  const last = steps[steps.length - 1];
  let cur: unknown = last;
  for (const p of r.split(".")) {
    if (cur == null || typeof cur !== "object") return undefined;
    cur = (cur as Record<string, unknown>)[p];
  }
  return cur;
}

/** Compile a declarative recipe into an executable CdpTool. */
export function recipeToCdpTool(recipe: CdpRecipe): CdpTool<Record<string, unknown>, unknown> {
  return {
    name: recipe.name,
    description: recipe.description,
    inputSchema: recipe.inputSchema,
    async run(cdp: Cdp, args: Record<string, unknown>) {
      const results: unknown[] = [];
      for (const step of recipe.steps) {
        const params = resolveTemplates(step.params ?? {}, { args, steps: results }) as Record<string, unknown>;
        results.push(await cdp(step.method, params));
      }
      return extractResult(recipe, results);
    },
  };
}

function isRecipe(value: unknown): value is CdpRecipe {
  const r = value as CdpRecipe;
  return !!r && typeof r.name === "string" && typeof r.description === "string" && Array.isArray(r.steps);
}

/** Load *.json recipes from a directory (skill directory). Invalid files are skipped. */
export async function loadRecipesFromDir(dir: string): Promise<CdpRecipe[]> {
  let entries: string[];
  try {
    entries = await readdir(dir);
  } catch {
    return [];
  }
  const recipes: CdpRecipe[] = [];
  for (const file of entries.filter((f) => f.endsWith(".json"))) {
    try {
      const parsed = JSON.parse(await readFile(join(dir, file), "utf8"));
      if (isRecipe(parsed)) recipes.push(parsed);
    } catch {
      // skip malformed recipe files
    }
  }
  return recipes;
}
