/**
 * Agent adapter entry point.
 * Hosts the loopback WS endpoint the extension auto-connects to, and (later)
 * exposes MCP tools mapped onto the extension protocol. The adapter never grants
 * browser access or creates sessions. See spec/05-local-bridge-and-cdp-backend.md.
 */

import { mkdir, writeFile } from "node:fs/promises";
import { homedir } from "node:os";
import { dirname, join } from "node:path";
import { PROTOCOL_VERSION } from "@browser-bridge/shared-protocol";
import { DevWsServer } from "./ws-server.js";

export { NullTransport, type ExtensionTransport } from "./transport.js";
export { DevWsServer, type WsServerOptions } from "./ws-server.js";
export { McpServer, listMcpTools, type McpToolDef, type McpServerOptions } from "./mcp-server.js";
export {
  makeCdp,
  makeCdpEvents,
  defineCdpTool,
  runCdpTool,
  cdpToolToMcp,
  recentNetworkTool,
  exampleCdpTools,
  getLayoutMetrics,
  getFullText,
  highlightSelector,
  type Cdp,
  type CdpTool,
  type CdpRequester,
  type CdpEvent,
  type CdpEventsReader,
} from "./cdp-tools.js";
export {
  recipeToCdpTool,
  loadRecipesFromDir,
  type CdpRecipe,
  type CdpRecipeStep,
} from "./recipes.js";
export { runMcpStdio, buildCdpMcpTools, makeMcpCallTool, type McpStdioOptions } from "./mcp-stdio.js";

export const DEFAULT_WS_PORT = 18470;

export function adapterVersion(): string {
  return PROTOCOL_VERSION;
}

/** Port file is adapter-side diagnostics only; the extension uses a fixed port. */
export function portFilePath(): string {
  return join(homedir(), ".browser-bridge", "ws-port");
}

async function writePortFile(port: number): Promise<void> {
  const path = portFilePath();
  await mkdir(dirname(path), { recursive: true });
  await writeFile(path, String(port), "utf8");
}

export interface StartAdapterOptions {
  port?: number;
  clientName?: string;
}

export async function startAdapter(options: StartAdapterOptions = {}): Promise<DevWsServer> {
  const server = new DevWsServer({
    port: options.port ?? DEFAULT_WS_PORT,
    clientName: options.clientName ?? "browser-bridge-adapter",
    clientVersion: PROTOCOL_VERSION,
    onConnected: (connectionId) => {
      console.error(`[browser-bridge] extension connected (${connectionId})`);
    },
    onDisconnected: () => {
      console.error("[browser-bridge] extension disconnected");
    },
  });

  const { port } = await server.start();
  await writePortFile(port);
  console.error(`[browser-bridge] agent-adapter listening on 127.0.0.1:${port} (protocol ${PROTOCOL_VERSION})`);
  return server;
}
