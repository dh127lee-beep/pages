/** Adapter CLI entry: starts the dev WebSocket endpoint. */
import { startAdapter } from "./index.js";

void startAdapter().catch((error) => {
  console.error("[browser-bridge] adapter failed to start:", error);
  process.exitCode = 1;
});
