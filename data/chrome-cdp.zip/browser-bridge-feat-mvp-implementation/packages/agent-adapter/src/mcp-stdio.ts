/**
 * MCP stdio runner: hosts the adapter WS endpoint (extension auto-connects) and
 * speaks MCP over stdin/stdout. Protocol tools forward to the extension; example
 * + skill-directory CDP tools are auto-registered. See
 * docs/design-raw-cdp-passthrough.md §6 (Phase 2/3).
 */

import {
  cdpToolToMcp,
  exampleCdpTools,
  recentNetworkTool,
  type CdpRequester,
  type CdpTool,
} from "./cdp-tools.js";
import { startAdapter } from "./index.js";
import { McpServer, type McpToolDef } from "./mcp-server.js";
import { loadRecipesFromDir, recipeToCdpTool } from "./recipes.js";

/** Forward a protocol tool call: split routing (sessionId/pageId) from the payload. */
export function makeMcpCallTool(server: CdpRequester) {
  return async (name: string, args: Record<string, unknown>): Promise<unknown> => {
    const { sessionId, pageId, ...payload } = args;
    const route = {
      ...(typeof sessionId === "string" ? { sessionId } : {}),
      ...(typeof pageId === "string" ? { pageId } : {}),
    };
    const res = await server.request(name, payload, route);
    if (!res.ok) throw new Error(`${res.error.code}: ${res.error.message}`);
    return res.result;
  };
}

/** Build the MCP tool set: example CDP tools + skill-dir recipes + event tool. */
export async function buildCdpMcpTools(server: CdpRequester, skillsDir?: string): Promise<McpToolDef[]> {
  const recipes = skillsDir ? await loadRecipesFromDir(skillsDir) : [];
  const cdpTools: Array<CdpTool<never, unknown>> = [
    ...exampleCdpTools,
    ...recipes.map((r) => recipeToCdpTool(r) as CdpTool<never, unknown>),
  ];
  return [...cdpTools.map((t) => cdpToolToMcp(server, t)), recentNetworkTool(server)];
}

export interface McpStdioOptions {
  port?: number;
  /** Directory of *.json CDP recipes to register as tools (browser-harness style). */
  skillsDir?: string;
}

export async function runMcpStdio(options: McpStdioOptions = {}): Promise<void> {
  const server = await startAdapter({ port: options.port });
  const tools = await buildCdpMcpTools(server, options.skillsDir);
  const mcp = new McpServer({
    write: (line) => process.stdout.write(line),
    tools,
    callTool: makeMcpCallTool(server),
  });

  let buffer = "";
  process.stdin.setEncoding("utf8");
  process.stdin.on("data", (chunk: string) => {
    buffer += chunk;
    let nl: number;
    while ((nl = buffer.indexOf("\n")) >= 0) {
      const line = buffer.slice(0, nl);
      buffer = buffer.slice(nl + 1);
      void mcp.handleLine(line);
    }
  });
}
