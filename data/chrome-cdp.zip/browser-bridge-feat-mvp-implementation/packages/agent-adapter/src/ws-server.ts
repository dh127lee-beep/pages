/**
 * Development WebSocket endpoint (adapter side).
 * The adapter hosts a loopback WS server; the extension connects to it. Shared
 * handshake/RPC logic lives in AdapterEndpoint. Auto-connect, no pairing token.
 * See spec/05 §Local WebSocket development path.
 */

import { AdapterEndpoint, type RpcRoute, type ToolResponse } from "@browser-bridge/shared-protocol";
import { WebSocketServer, type WebSocket } from "ws";

export interface WsServerOptions {
  port?: number;
  /** When `port` is busy, try up to this many consecutive ports (default 8). */
  portCount?: number;
  host?: string;
  clientName: string;
  clientVersion?: string;
  timeoutMs?: number;
  onConnected?: (connectionId: string) => void;
  onDisconnected?: () => void;
}

export class DevWsServer {
  private wss?: WebSocketServer;
  private socket?: WebSocket;
  private endpoint?: AdapterEndpoint;

  constructor(private readonly options: WsServerOptions) {}

  /** Bind the first free port in [port … port+count-1]. Port 0 = ephemeral. */
  async start(): Promise<{ port: number }> {
    const host = this.options.host ?? "127.0.0.1";
    const base = this.options.port ?? 0;
    if (base === 0) return this.bind(host, 0);

    const count = this.options.portCount ?? 10;
    let lastError: unknown;
    for (let port = base; port < base + count; port++) {
      try {
        return await this.bind(host, port);
      } catch (error) {
        if ((error as { code?: string }).code === "EADDRINUSE") {
          lastError = error;
          continue;
        }
        throw error;
      }
    }
    throw lastError ?? new Error(`no free port in ${base}..${base + count - 1}`);
  }

  private bind(host: string, port: number): Promise<{ port: number }> {
    return new Promise((resolve, reject) => {
      const wss = new WebSocketServer({ host, port });
      const onBindError = (error: unknown) => {
        wss.removeAllListeners();
        wss.close();
        reject(error);
      };
      wss.on("error", onBindError);
      wss.on("listening", () => {
        wss.off("error", onBindError);
        wss.on("error", () => undefined); // ignore late runtime errors
        wss.on("connection", (ws) => this.handleConnection(ws));
        this.wss = wss;
        const address = wss.address();
        resolve({ port: typeof address === "object" && address ? address.port : port });
      });
    });
  }

  stop(): Promise<void> {
    this.socket?.close();
    return new Promise((resolve) => {
      if (!this.wss) return resolve();
      this.wss.close(() => resolve());
    });
  }

  request(type: string, payload: unknown = {}, route: RpcRoute = {}): Promise<ToolResponse> {
    if (!this.endpoint) {
      return Promise.resolve({
        ok: false,
        error: { code: "EXTENSION_NOT_CONNECTED", message: "No extension is connected; start the extension and retry." },
      });
    }
    return this.endpoint.request(type, payload, route);
  }

  get connected(): boolean {
    return this.endpoint?.connected ?? false;
  }

  private handleConnection(ws: WebSocket): void {
    this.socket = ws;
    this.endpoint = new AdapterEndpoint((message) => ws.send(JSON.stringify(message)), {
      clientName: this.options.clientName,
      clientVersion: this.options.clientVersion,
      timeoutMs: this.options.timeoutMs,
      onConnected: this.options.onConnected,
      onDisconnected: this.options.onDisconnected,
    });

    ws.on("message", (data) => {
      let parsed: unknown;
      try {
        parsed = JSON.parse(data.toString());
      } catch {
        return;
      }
      this.endpoint?.handleIncoming(parsed);
    });

    ws.on("close", () => {
      if (this.socket !== ws) return; // a newer connection replaced this one
      this.endpoint?.reset();
      this.endpoint = undefined;
      this.socket = undefined;
    });
  }
}
