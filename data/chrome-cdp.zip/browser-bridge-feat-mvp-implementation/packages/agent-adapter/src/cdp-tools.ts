/**
 * External browser tools defined over the raw CDP passthrough.
 *
 * The extension exposes a single generic relay (`browser.cdp_command`); new
 * browser tools can be authored here — or by any consumer — as plain functions of
 * a `cdp(method, params)` sender, without changing the extension. This is the
 * "define tools from outside via raw CDP" layer from
 * docs/design-raw-cdp-passthrough.md (§2.3).
 *
 * The session must have opted in (`start_session({ allowRawCdp: true })`).
 */

import type { RpcRoute, ToolResponse } from "@browser-bridge/shared-protocol";
import type { McpToolDef } from "./mcp-server.js";

/** Anything that can route a tool call to the extension (e.g. DevWsServer). */
export interface CdpRequester {
  request(type: string, payload?: unknown, route?: RpcRoute): Promise<ToolResponse>;
}

/** Sends a raw CDP command to one page; returns the CDP result or throws. */
export type Cdp = (method: string, params?: Record<string, unknown>) => Promise<unknown>;

/** Bind a raw-CDP sender to a single page (sessionId + pageId). */
export function makeCdp(server: CdpRequester, route: RpcRoute): Cdp {
  return async (method, params) => {
    const res = await server.request("browser.cdp_command", { method, params }, route);
    if (!res.ok) throw new Error(`${res.error.code}: ${res.error.message}`);
    return (res.result as { result: unknown }).result;
  };
}

/** A buffered raw CDP event (mirrors the extension's CdpEvent). */
export interface CdpEvent {
  seq: number;
  method: string;
  params: unknown;
}

/** Polls buffered CDP events for a page (browser.cdp_events). */
export type CdpEventsReader = (opts?: {
  since?: number;
  methods?: string[];
  limit?: number;
}) => Promise<{ events: CdpEvent[]; cursor: number }>;

/** Bind a CDP event reader to a single page. */
export function makeCdpEvents(server: CdpRequester, route: RpcRoute): CdpEventsReader {
  return async (opts = {}) => {
    const res = await server.request("browser.cdp_events", opts, route);
    if (!res.ok) throw new Error(`${res.error.code}: ${res.error.message}`);
    return res.result as { events: CdpEvent[]; cursor: number };
  };
}

/** A browser tool defined purely in terms of raw CDP. */
export interface CdpTool<A = Record<string, unknown>, R = unknown> {
  name: string;
  description: string;
  /** JSON Schema for the tool's args (excluding routing); merged with sessionId/pageId for MCP. */
  inputSchema?: { properties?: Record<string, unknown>; required?: string[] };
  run(cdp: Cdp, args: A): Promise<R>;
}

/** Identity helper for authoring tools with inferred arg/return types. */
export function defineCdpTool<A, R>(tool: CdpTool<A, R>): CdpTool<A, R> {
  return tool;
}

/** Execute a CDP tool against a bound page. */
export function runCdpTool<A, R>(server: CdpRequester, route: RpcRoute, tool: CdpTool<A, R>, args: A): Promise<R> {
  return tool.run(makeCdp(server, route), args);
}

/**
 * Adapt a CDP tool to an MCP tool definition. The MCP args carry routing
 * (sessionId/pageId) plus the tool's own args; invoke binds a cdp sender and runs it.
 */
export function cdpToolToMcp(server: CdpRequester, tool: CdpTool<never, unknown>): McpToolDef {
  return {
    name: tool.name,
    description: tool.description,
    inputSchema: {
      type: "object",
      properties: {
        sessionId: { type: "string", description: "Owning session id" },
        pageId: { type: "string", description: "Target page id" },
        ...(tool.inputSchema?.properties ?? {}),
      },
      required: ["sessionId", "pageId", ...(tool.inputSchema?.required ?? [])],
      additionalProperties: true,
    },
    invoke: (args) =>
      runCdpTool(server, { sessionId: String(args.sessionId), pageId: String(args.pageId) }, tool, args as never),
  };
}

// --- Example tools (usable as-is, and as authoring templates) ---

/** Page layout metrics (viewport + content size). */
export const getLayoutMetrics = defineCdpTool<Record<string, never>, unknown>({
  name: "get_layout_metrics",
  description: "Page layout metrics via Page.getLayoutMetrics.",
  run: (cdp) => cdp("Page.getLayoutMetrics"),
});

/** The page's visible text (document.body.innerText) in the page world. */
export const getFullText = defineCdpTool<Record<string, never>, string>({
  name: "get_full_text",
  description: "The page's visible text via Runtime.evaluate(document.body.innerText).",
  async run(cdp) {
    const r = (await cdp("Runtime.evaluate", {
      expression: "document.body ? document.body.innerText : ''",
      returnByValue: true,
    })) as { result?: { value?: string } };
    return r.result?.value ?? "";
  },
});

/** Outline the first element matching a CSS selector using the inspector overlay. */
export const highlightSelector = defineCdpTool<{ selector: string }, boolean>({
  name: "highlight_selector",
  description: "Outline the first element matching a CSS selector (Overlay.highlightNode).",
  async run(cdp, { selector }) {
    const doc = (await cdp("DOM.getDocument", { depth: 0 })) as { root?: { nodeId?: number } };
    const rootId = doc.root?.nodeId;
    if (rootId == null) return false;
    const found = (await cdp("DOM.querySelector", { nodeId: rootId, selector })) as { nodeId?: number };
    if (!found.nodeId) return false;
    await cdp("Overlay.enable");
    await cdp("Overlay.highlightNode", {
      nodeId: found.nodeId,
      highlightConfig: { contentColor: { r: 80, g: 200, b: 120, a: 0.4 } },
    });
    return true;
  },
});

/** Example event-based MCP tool: recent network activity from the CDP event buffer. */
export function recentNetworkTool(server: CdpRequester): McpToolDef {
  return {
    name: "recent_network_requests",
    description:
      "Network requests/responses captured since `since` (call once to start capture, then poll with the returned cursor).",
    inputSchema: {
      type: "object",
      properties: {
        sessionId: { type: "string" },
        pageId: { type: "string" },
        since: { type: "number", description: "cursor from a prior call" },
      },
      required: ["sessionId", "pageId"],
      additionalProperties: false,
    },
    invoke: async (args) => {
      const events = makeCdpEvents(server, { sessionId: String(args.sessionId), pageId: String(args.pageId) });
      const { events: evs, cursor } = await events({
        since: typeof args.since === "number" ? args.since : undefined,
        methods: ["Network.requestWillBeSent", "Network.responseReceived"],
      });
      return { cursor, events: evs };
    },
  };
}

export const exampleCdpTools: ReadonlyArray<CdpTool<never, unknown>> = [
  getLayoutMetrics as CdpTool<never, unknown>,
  getFullText as CdpTool<never, unknown>,
  highlightSelector as unknown as CdpTool<never, unknown>,
];
