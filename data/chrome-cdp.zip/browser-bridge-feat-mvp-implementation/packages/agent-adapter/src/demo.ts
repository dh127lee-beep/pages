/**
 * Manual verification driver.
 *
 * Run this, then load the extension (it auto-connects to ws://127.0.0.1:18470).
 * It creates a session (you should see a "BB · demo-agent · ..." tab group
 * appear in Chrome), opens a page, snapshots it, screenshots it, navigates, and
 * reads the console — printing each protocol response. The session is left open
 * so you can inspect the tab group; press Ctrl+C to exit.
 *
 * Build then run:
 *   pnpm --filter @browser-bridge/agent-adapter build
 *   node packages/agent-adapter/dist/demo.js
 */

import { getFullText, getLayoutMetrics, runCdpTool } from "./cdp-tools.js";
import { DevWsServer } from "./ws-server.js";

const PORT = Number(process.env.BB_WS_PORT ?? 18470);

function log(label: string, value: unknown): void {
  process.stdout.write(`\n▶ ${label}\n${JSON.stringify(value, null, 2)}\n`);
}

async function runFlow(server: DevWsServer): Promise<void> {
  log("get_capabilities", await server.request("browser.get_capabilities"));

  const started = await server.request("browser.start_session", {
    mode: "extension-tab",
    clientName: "demo-agent",
    sessionLabel: "manual smoke",
    allowRawCdp: true, // enable the raw CDP passthrough for the demo below
  });
  log("start_session", started);
  if (!started.ok) return;
  const sessionId = (started.result as { sessionId: string }).sessionId;

  const page = await server.request("browser.new_page", { url: "https://example.com/" }, { sessionId });
  log("new_page (watch for the tab group in Chrome)", page);
  if (!page.ok) return;
  const pageId = (page.result as { pageId: string }).pageId;

  log("get_session (tabGroup should be 'materialized')", await server.request("browser.get_session", {}, { sessionId }));
  log("take_snapshot", await server.request("browser.take_snapshot", {}, { sessionId, pageId }));
  log("take_screenshot", await server.request("browser.take_screenshot", {}, { sessionId, pageId }));
  log(
    "navigate",
    await server.request("browser.navigate", { url: "https://www.iana.org/help/example-domains" }, { sessionId, pageId }),
  );
  log("list_tabs", await server.request("browser.list_tabs"));
  log("list_console_messages", await server.request("browser.list_console_messages", {}, { sessionId, pageId }));

  // External tools defined purely over the raw CDP passthrough (no extension change).
  const route = { sessionId, pageId };
  log("cdp tool: get_layout_metrics", await runCdpTool(server, route, getLayoutMetrics, {}));
  log("cdp tool: get_full_text", await runCdpTool(server, route, getFullText, {}));

  process.stdout.write(
    `\n✅ Flow done. Session ${sessionId} left open — inspect the tab group in Chrome.\n` +
      `   End it any time with Ctrl+C (agent-created tabs are closed on disconnect policy is manual here).\n`,
  );
}

async function main(): Promise<void> {
  const server = new DevWsServer({
    port: PORT,
    clientName: "demo-agent",
    onConnected: (connectionId) => {
      process.stdout.write(`\n🔌 Extension connected (${connectionId}). Running demo flow...\n`);
      void runFlow(server).catch((error) => process.stderr.write(`flow error: ${String(error)}\n`));
    },
    onDisconnected: () => process.stdout.write("\n🔌 Extension disconnected.\n"),
  });

  const { port } = await server.start();
  process.stdout.write(
    `Browser Bridge demo adapter listening on ws://127.0.0.1:${port}\n` +
      `Now load the extension (chrome://extensions → load unpacked → packages/extension/dist).\n` +
      `Waiting for the extension to auto-connect...\n`,
  );
}

void main().catch((error) => {
  process.stderr.write(`demo failed: ${String(error)}\n`);
  process.exitCode = 1;
});
