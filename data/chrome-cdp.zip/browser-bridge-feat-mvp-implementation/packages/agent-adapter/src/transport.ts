/**
 * Transport translation (skeleton).
 * Maps agent/MCP requests onto the extension protocol envelope and back.
 * See spec/05-local-bridge-and-cdp-backend.md §Transport message routing.
 */

import type { ToolResponse, TransportMessage } from "@browser-bridge/shared-protocol";

export interface ExtensionTransport {
  send(message: TransportMessage): Promise<ToolResponse>;
}

/** Placeholder transport that is not yet connected to the extension. */
export class NullTransport implements ExtensionTransport {
  send(_message: TransportMessage): Promise<ToolResponse> {
    return Promise.resolve({
      ok: false,
      error: { code: "EXTENSION_NOT_CONNECTED", message: "No extension transport configured." },
    });
  }
}
