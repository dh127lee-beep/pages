/**
 * Minimal MCP server facade.
 * Speaks newline-delimited JSON-RPC over injected streams: `initialize`,
 * `tools/list`, and `tools/call`. The protocol tool set (TOOL_NAMES) is forwarded
 * to the extension via the injected `callTool`; extra tools (e.g. external CDP
 * tools, see cdp-tools.ts) are listed and executed via their own `invoke`.
 * See spec/05-local-bridge-and-cdp-backend.md §MCP transport.
 */

import { PROTOCOL_VERSION, TOOL_NAMES, isToolName, type ToolName } from "@browser-bridge/shared-protocol";

export function listMcpTools(): readonly ToolName[] {
  return TOOL_NAMES;
}

/** A tool exposed over MCP beyond the protocol set (e.g. an external CDP tool). */
export interface McpToolDef {
  name: string;
  description: string;
  inputSchema: object;
  /** Execute the tool. If omitted, the call is forwarded by name via `callTool`. */
  invoke?: (args: Record<string, unknown>) => Promise<unknown>;
}

interface JsonRpcRequest {
  jsonrpc: "2.0";
  id?: number | string | null;
  method: string;
  params?: unknown;
}

export interface McpServerOptions {
  write: (line: string) => void;
  serverName?: string;
  version?: string;
  /** Extra tools beyond the protocol set. */
  tools?: McpToolDef[];
  /** Executor for forwarded protocol tools (browser.*). */
  callTool?: (name: string, args: Record<string, unknown>) => Promise<unknown>;
}

export class McpServer {
  private readonly extra: McpToolDef[];
  constructor(private readonly options: McpServerOptions) {
    this.extra = options.tools ?? [];
  }

  /** Handle one newline-delimited JSON-RPC message. */
  async handleLine(line: string): Promise<void> {
    const trimmed = line.trim();
    if (!trimmed) return;
    let request: JsonRpcRequest;
    try {
      request = JSON.parse(trimmed) as JsonRpcRequest;
    } catch {
      return;
    }

    if (request.method === "tools/call") {
      await this.handleCall(request);
      return;
    }

    const result = this.dispatch(request);
    if (result === undefined || request.id === undefined) return; // notification
    this.options.write(JSON.stringify({ jsonrpc: "2.0", id: request.id, result }) + "\n");
  }

  private dispatch(request: JsonRpcRequest): unknown {
    switch (request.method) {
      case "initialize":
        return {
          protocolVersion: "2024-11-05",
          serverInfo: { name: this.options.serverName ?? "browser-bridge", version: this.options.version ?? PROTOCOL_VERSION },
          capabilities: { tools: {} },
        };
      case "tools/list":
        return {
          tools: [
            ...TOOL_NAMES.map((name) => ({
              name,
              description: `Browser Bridge tool: ${name}`,
              inputSchema: { type: "object" },
            })),
            ...this.extra.map((t) => ({ name: t.name, description: t.description, inputSchema: t.inputSchema })),
          ],
        };
      default:
        return undefined;
    }
  }

  private async handleCall(request: JsonRpcRequest): Promise<void> {
    const params = (request.params ?? {}) as { name?: string; arguments?: Record<string, unknown> };
    const name = params.name ?? "";
    const args = params.arguments ?? {};
    let text: string;
    let isError = false;
    try {
      const value = await this.execute(name, args);
      text = typeof value === "string" ? value : JSON.stringify(value);
    } catch (error) {
      isError = true;
      text = error instanceof Error ? error.message : String(error);
    }
    if (request.id === undefined) return;
    this.options.write(
      JSON.stringify({ jsonrpc: "2.0", id: request.id, result: { content: [{ type: "text", text }], isError } }) + "\n",
    );
  }

  private async execute(name: string, args: Record<string, unknown>): Promise<unknown> {
    const extra = this.extra.find((t) => t.name === name);
    if (extra?.invoke) return extra.invoke(args);
    if (this.options.callTool && isToolName(name)) return this.options.callTool(name, args);
    throw new Error(`Unknown or non-executable tool: ${name || "(missing name)"}`);
  }
}
