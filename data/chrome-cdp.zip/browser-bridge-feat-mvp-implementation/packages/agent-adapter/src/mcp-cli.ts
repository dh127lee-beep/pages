/** MCP stdio entry: `node packages/agent-adapter/dist/mcp-cli.js` (BB_SKILLS_DIR optional). */
import { runMcpStdio } from "./mcp-stdio.js";

void runMcpStdio({
  port: process.env.BB_WS_PORT ? Number(process.env.BB_WS_PORT) : undefined,
  skillsDir: process.env.BB_SKILLS_DIR,
}).catch((error) => {
  console.error("[browser-bridge] MCP stdio runner failed:", error);
  process.exitCode = 1;
});
