# 트러블슈팅

## 확장이 연결되지 않음 (popup `disconnected`)

- 어댑터가 떠 있는가? dev WS는 `node packages/agent-adapter/dist/cli.js`로 기동.
- 포트가 맞는가? 기본 `18470`. options 페이지에서 변경 가능. 확장은 FS를 읽지 못해
  포트파일을 사용하지 않으므로 **고정/설정 포트**로 접속한다.
- Native Messaging 사용 시: 매니페스트 위치/`path`/확장 ID allowlist 확인
  ([install-native-host.md](install-native-host.md)).

## `NATIVE_HOST_UNAVAILABLE` / native 연결 실패 후 WS로 폴백됨

- 매니페스트 `path`가 실행 가능한 절대 경로인지, 래퍼가 `chmod +x` 되었는지 확인.
- `allowed_origins`의 확장 ID가 현재 확장 ID와 일치하는지 확인.
- 호스트는 stderr로 진단을 출력한다.

## 버전 불일치 (`bridge.reject` VERSION_MISMATCH)

- 확장과 어댑터/호스트가 같은 빌드인지 확인. 0.x에서는 minor가 호환 경계다.
- `pnpm build` 후 모든 구성요소를 재시작/새로고침.

## 액션이 `SNAPSHOT_STALE`

- 페이지가 바뀌었다. `browser.take_snapshot`을 다시 호출해 새 uid를 받는다.

## 액션이 `SESSION_PAUSED` / `SESSION_FINALIZED`

- 세션이 일시정지/종료됨. `browser.resume_session` 또는 새 세션 생성.

## `COMMAND_LIMIT_EXCEEDED`

- 한 세션에 동시 명령이 너무 많다. 진행 중 명령이 끝난 뒤 재시도.

## `TAB_ALREADY_LEASED`

- 다른 세션이 그 탭을 소유 중. 다른 탭을 쓰거나 기존 세션을 종료.

## 스크린샷이 빈/잘못된 화면

- `extension-tab` 모드의 `captureVisibleTab`은 **보이는 탭만** 캡처한다. 배경 탭은
  `extension-debugger` 모드(디버거 캡처)를 사용한다.

## 서비스 워커가 종료됨 (MV3)

- 정상 동작이다. 세션/페이지 메타데이터는 `chrome.storage.session`에 저장되어
  재시작 시 복원된다. 같은 clientName으로 재연결하면 세션이 이어진다.
