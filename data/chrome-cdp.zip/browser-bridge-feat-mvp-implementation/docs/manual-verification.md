# 수동 확인 (Chrome에서 탭 그룹·동작 검증)

자동 테스트(125+개)는 fake 포트/실 소켓으로 로직을 검증하지만, **실제 Chrome에서
탭 그룹이 생기고 동작이 수행되는지**는 아래 데모로 직접 확인한다.

## 준비

```bash
pnpm install
pnpm build          # 확장 번들 + 패키지 빌드
```

## 1) 데모 어댑터 실행

데모 어댑터는 `127.0.0.1:18470`에 WebSocket 엔드포인트를 열고, 확장이 연결되면
스크립트 흐름(세션 생성 → 페이지 열기 → snapshot → screenshot → navigate →
console 읽기)을 실행하며 각 응답을 출력한다.

```bash
pnpm demo
# 또는: node packages/agent-adapter/dist/demo.js
```

출력 예:

```text
Browser Bridge demo adapter listening on ws://127.0.0.1:18470
Now load the extension ...
Waiting for the extension to auto-connect...
```

## 2) 확장 로드

1. `chrome://extensions` → 개발자 모드 ON → **압축해제된 확장 프로그램 로드**
2. `packages/extension/dist` 선택

확장이 로드되면 서비스 워커가 Native Messaging을 먼저 시도하고, 없으면 곧
`ws://127.0.0.1:18470`로 자동 연결한다(백오프 재시도). 연결되면 데모 콘솔에:

```text
🔌 Extension connected (conn_...). Running demo flow...
```

## 3) 무엇을 확인하나

- **탭 그룹**: Chrome에 `BB · demo-agent · manual smoke` 제목의 **탭 그룹**이 생기고
  그 안에 `example.com` 탭이 열린다. (= 세션 탭 그룹 materialize 확인)
- **get_session** 응답의 `tabGroup.state === "materialized"`.
- **take_snapshot** 응답에 요소 목록(uid 포함)이 온다. (= content script 주입·snapshot 동작)
- **take_screenshot** 응답이 `kind: "screenshot"` 메타데이터(바이너리 비포함)로 온다.
- **navigate** 후 탭이 다른 URL로 이동한다.
- **popup**(확장 아이콘 클릭): `connected`, client `demo-agent`, 세션 수 1.

## 4) 정리

- 데모는 세션을 열어둔 채 대기한다. `Ctrl+C`로 종료한다.
- 에이전트가 만든 탭을 정리하려면 데모 흐름에서 `browser.end_session`을 호출하거나,
  실제 에이전트 사용 시 턴 종료에 `end_session`을 호출한다(아래 [agent-usage](agent-usage.md)).

## 문제 해결

연결이 안 되면 [troubleshooting.md](troubleshooting.md) 참고. 자주 보는 원인:

- 데모 어댑터를 안 띄움 / 포트 불일치(options에서 포트 변경).
- 확장을 빌드 후 새로고침 안 함(`pnpm build` → `chrome://extensions` 새로고침).
- `localhost`가 아닌 사이트에서 `allowedDomains`가 설정돼 차단됨.

## 자동 테스트 실행

```bash
pnpm typecheck   # tsc -b
pnpm test        # vitest (단위/통합/E2E)
pnpm lint
```

`tests/e2e.test.ts`는 실제 loopback 소켓으로 어댑터↔브리지 전체 흐름을 검증하는
가장 가까운 자동화 버전이다(브라우저 없이).
