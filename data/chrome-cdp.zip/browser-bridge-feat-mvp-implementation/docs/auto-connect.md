# 자동 연결 (Codex `@chrome` 같은 UX)

목표: **사용자는 추가로 아무것도 안 한다.** 에이전트 챗 앱이 연결을 원할 때,
Chrome이 열려 있거나 새로 열리기만 하면 자동으로 커넥션이 성립된다.

## 구조 (Codex와 동일한 원리)

MV3 확장은 스스로 포트를 못 연다. 그래서 Codex도, 우리도 **에이전트 앱이 엔드포인트를
갖고 확장이 거기에 접속**한다. 사용자에게 매끄럽게 보이는 건 세 가지 덕분이다:

1. **확장이 항상 설치돼 있음** (1회).
2. **에이전트 앱이 실행 중**이라 엔드포인트가 떠 있음(앱이 곧 서버).
3. **확장이 Chrome 시작/주기적으로 자동 재접속**을 시도함.

```text
Agent Chat App (서버, 127.0.0.1:18470 또는 native host)
        ▲  자동 접속/재접속
Extension(client) ── Chrome 켜짐 / 주기적 alarm / 앱 엔드포인트 등장 시
```

## 확장이 하는 일 (이미 구현됨)

- 모듈 로드 + `chrome.runtime.onStartup`(브라우저 시작) 시 연결 시도.
- `chrome.alarms`(약 30초 주기)로 서비스 워커를 깨워 **미연결이면 재접속**.
- 연결 중엔 WS 활동으로 SW 수명 유지, 끊기면 백오프 재시도.
- native(있으면) 우선 → 없으면 dev WS(127.0.0.1:18470) 폴백.

→ 결과: 앱 엔드포인트가 떠 있으면 Chrome이 켜지는 순간/켜져 있으면 **수십 초 내 자동
연결**. 사용자 조작 없음.

## 에이전트 앱이 할 일

앱이 "연결 지점"이 되도록 어댑터를 임베드한다(= 앱이 서버).

```js
import { DevWsServer } from "@browser-bridge/agent-adapter"; // 또는 빌드 산출물 경로

const bridge = new DevWsServer({ port: 18470, clientName: "my-chat-app",
  onConnected: () => ui.markChromeConnected() });
await bridge.start();           // 앱 시작 시 한 번

// @chrome 사용 시:
const s = await bridge.request("browser.start_session", { mode: "extension-tab", clientName: "my-chat-app" });
```

- 앱은 항상(또는 @chrome 최초 사용 시) `bridge.start()`로 엔드포인트를 띄워둔다.
- 확장이 자동으로 붙으면 `onConnected`가 호출된다. 그때부터 `request(...)`로 도구 사용.
- 매니페스트 설치가 싫으면 이대로(WS) 충분하다 → [connect-without-host.md](connect-without-host.md).
- "앱조차 안 띄운 채" 대기시키려면 Native Messaging(터미널 0, Chrome이 호스트 자동 실행)
  → [install-native-host.md](install-native-host.md). 단 이 경우만 매니페스트 1회 필요.

## 한계 / 주의

- 첫 연결까지 최대 ~30초(알람 주기) 지연이 있을 수 있다. 앱이 이미 떠 있고 사용자가 막
   Chrome을 켰다면 보통 그보다 빠르다.
- MV3 SW는 유휴 시 종료되므로 "초저지연 상시 연결"이 필요하면 Native Messaging이 더 적합.
- 보안: 자동 연결은 토큰/동의가 없다(수락된 리스크) — [threat-model.md](threat-model.md).
