# 통신 규약 (Protocol)

전송과 무관한 단일 command 프로토콜이다. dev WebSocket, Native Messaging, (어댑터의)
MCP가 모두 같은 명령 이름과 응답 envelope로 매핑된다. 정식 정의는
[spec/03-protocol-and-mcp-tools.md](../spec/03-protocol-and-mcp-tools.md).

## 연결 토폴로지

```text
Agent ──(MCP/stdio)──▶ Adapter/NativeHost ──(WS 또는 Native Messaging)──▶ Extension SW ──▶ Tabs
```

- **확장이 연결을 개시**한다. 확장은 로컬 HTTP 서버를 열지 않는다.
- dev: 어댑터가 `127.0.0.1`에 WS 서버를 띄우고 확장이 접속(기본 포트 18470).
- prod: Chrome이 Native Messaging 호스트를 실행, 확장이 `connectNative`로 연결.
- **자동 연결**(pairing 토큰/동의 없음) — 정책·리스크는 [threat-model](threat-model.md).

## 핸드셰이크

1. 확장 → 어댑터: `{ "type": "bridge.hello", "protocolVersion", "extensionVersion" }`
2. 어댑터 → 확장: `{ "type": "bridge.identify", "protocolVersion", "clientName", "clientVersion" }`
   - 버전 비호환 시 `{ "type": "bridge.reject", "code": "VERSION_MISMATCH", "message" }`
3. 확장 → 어댑터: `{ "type": "bridge.welcome", "protocolVersion", "connectionId" }`
4. 이후 어댑터가 tool 요청을 보내고 확장이 응답. heartbeat는 `bridge.ping`/`bridge.pong`.

버전 호환: major 일치, 0.x에서는 minor도 호환 경계.

## 메시지 envelope

요청(어댑터 → 확장):

```json
{ "id": "msg_1", "version": "0.1.0", "type": "browser.click",
  "sessionId": "sess_…", "pageId": "page_…", "payload": { } }
```

성공 응답:

```json
{ "id": "msg_1", "version": "0.1.0",
  "response": { "ok": true, "sessionId": "sess_…", "pageId": "page_…",
                "result": { }, "warnings": [], "auditId": "audit_…" } }
```

에러 응답:

```json
{ "id": "msg_1", "version": "0.1.0",
  "response": { "ok": false, "error": { "code": "SNAPSHOT_STALE", "message": "…", "details": { } } } }
```

- 응답 `id`는 요청 `id`와 매칭(미매칭/타임아웃은 거부; 기본 30s 타임아웃).
- 세션 스코프 tool은 `sessionId`, 페이지 tool은 `sessionId`+`pageId`가 **둘 다** 필요.

## ID 체계

`sessionId`(sess_) · `agentId`(agent_, clientName 파생) · `tabGroupId` ·
`pageId`(page_) · `snapshotId`(snap_) · `uid`(snapshot 내에서만 유효) ·
`artifactId` · `auditId` · `connectionId`.

## 도구 목록

| 도구 | 스코프 | 설명 |
| --- | --- | --- |
| `browser.get_capabilities` | - | 버전/백엔드/권한 상태 |
| `browser.start_session` | - | 세션 생성(논리적 탭 그룹) |
| `browser.list_sessions` | agent | 에이전트 세션 목록 |
| `browser.get_session` | session | 세션 상세 |
| `browser.pause_session` / `resume_session` | session | 명령 수락 토글 |
| `browser.end_session` | session | 종료(agent 탭 닫기, claimed 해제) |
| `browser.new_page` | session | 탭 생성 후 세션 그룹 편입 |
| `browser.list_tabs` | agent | 사용자 탭 목록(claim 선택용) |
| `browser.claim_tab` | session | active 또는 tabId로 claim |
| `browser.navigate` | page | 페이지 이동/reload |
| `browser.release_tab` | page | lease 해제(탭 유지) |
| `browser.take_snapshot` | page | a11y 우선 snapshot + uid |
| `browser.take_screenshot` | page | 스크린샷 아티팩트 |
| `browser.click` / `fill` / `fill_form` / `press_key` / `scroll` / `wait_for` | page | 액션 |
| `browser.list_console_messages` / `list_network_requests` | page | 디버거 read |

## 스냅샷 계약

`take_snapshot`은 `source=untrusted_page`로 태깅된 정규화 트리를 반환한다.
요소는 `uid=${snapshotId}_${n}`를 가지며, 액션은 **현재 snapshot의 uid**만
대상으로 한다(오래된 snapshot은 `SNAPSHOT_STALE`). password/payment 값은 redaction.

## 에러 코드 (요약)

`AGENT_NOT_PAIRED`, `TRANSPORT_UNAVAILABLE`, `BACKEND_UNAVAILABLE`,
`NATIVE_HOST_UNAVAILABLE`, `EXTENSION_NOT_CONNECTED`, `DEBUGGER_PERMISSION_REQUIRED`,
`SESSION_NOT_FOUND`, `SESSION_PAUSED`, `SESSION_FINALIZED`, `TAB_ALREADY_LEASED`,
`TAB_GROUP_UNAVAILABLE`, `TAB_NOT_LEASED`, `POLICY_DENIED`, `SNAPSHOT_STALE`,
`ELEMENT_NOT_FOUND`, `ELEMENT_NOT_INTERACTABLE`, `NAVIGATION_TIMEOUT`,
`ACTION_TIMEOUT`, `ARTIFACT_WRITE_FAILED`, `COMMAND_LIMIT_EXCEEDED`,
`UNSUPPORTED_ACTION`. 메시지는 self-healing 톤(원인 + 다음 행동).
