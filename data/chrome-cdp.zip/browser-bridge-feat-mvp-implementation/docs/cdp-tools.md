# CDP 도구 — 사용법 & 구현

`chrome.debugger`(Chrome DevTools Protocol)를 통해 동작하는 도구와, 그 위에서 **외부에서 raw CDP로
브라우저 도구를 정의**하는 층을 정리한다. 설계·정책 배경은
[design-raw-cdp-passthrough.md](design-raw-cdp-passthrough.md), 전체 도구 표면은
[browser-tools.md](browser-tools.md).

요약: 확장은 `DebuggerManager`로 임의 CDP를 보낼 수 있고(`ensureAttached` + 온디맨드 attach), 그 위에
① 구체 CDP 도구(`evaluate_script`/`resize_page`/`emulate`/`handle_dialog`/`upload_file`/WebMCP), ②
범용 패스스루(`cdp_command`/`cdp_events`), ③ 어댑터의 외부 도구 정의 층(코드/선언적 레시피/스킬 디렉터리)
+ MCP 노출을 쌓았다.

---

## 1. 구체 CDP 도구

모두 page-scope. 호출 시 해당 탭에 디버거를 온디맨드 attach한다(`get_capabilities.debuggerPermission`로 권한 확인,
실패 시 `BACKEND_UNAVAILABLE`).

| 도구 | payload | 결과 | CDP |
| --- | --- | --- | --- |
| `evaluate_script` | `{ expression }` | `{ value }` (JSON 직렬화) | `Runtime.evaluate`(MAIN, awaitPromise, returnByValue) |
| `resize_page` | `{ width, height, deviceScaleFactor?, mobile?, reset? }` | `{ width, height, reset }` | `Emulation.setDeviceMetricsOverride` / `clear…` |
| `emulate` | `EmulateInput` | `{ applied: true }` | `setDeviceMetricsOverride` + `Network.emulateNetworkConditions` + `Emulation.setCPUThrottlingRate` |
| `handle_dialog` | `{ accept, promptText? }` | `{ handled, dialog? }` | `Page.handleJavaScriptDialog` (`javascriptDialogOpening`로 추적) |
| `upload_file` | `{ uid, files: string[], snapshotId? }` | `{ uploaded, uid }` | uid 태깅 → `Runtime.evaluate`로 노드 해석 → `DOM.setFileInputFiles` |
| `list_webmcp_tools` | — | `{ tools: WebmcpToolSummary[] }` | `Runtime.evaluate`(페이지 WebMCP 제공자 조회) |
| `execute_webmcp_tool` | `{ toolName, input? }` | `{ result }` | `Runtime.evaluate`(WebMCP 도구 실행) |

- `EmulateInput`: `width?`,`height?`,`mobile?`, `network?`(`offline?`,`latencyMs?`,`downloadKbps?`,`uploadKbps?`),
  `cpuThrottlingRate?`(1=없음,4=4×), `reset?`.
- `upload_file.files`는 **브라우저 머신의 절대 경로**여야 한다(CDP 제약).
- **WebMCP**는 페이지 JS API(`navigator.modelContext` 또는 `window.agent`)를 대상으로 한다(목록: `tools`/
  `listTools()`/`getTools()`, 실행: `callTool(name,input)` 또는 도구의 `execute`/`call`). 제공자 없으면 `[]`/에러.
  chrome-devtools-mcp의 flag-gated DevTools WebMCP 도메인과는 다른 **JS-API 기반 best-effort**.

---

## 2. Raw 패스스루 (`cdp_command` / `cdp_events`)

확장 코드 수정 없이 새 도구를 만들기 위한 통로. **세션 옵트인 필수**
(`start_session({ allowRawCdp: true })`, 기본 off → `POLICY_DENIED`). 소유 페이지에만 적용.

```ts
await server.request("browser.start_session",
  { mode: "extension-tab", clientName: "x", allowRawCdp: true });

// 명령
await server.request("browser.cdp_command",
  { method: "DOM.getDocument", params: { depth: 1 } }, { sessionId, pageId });

// 이벤트 (첫 호출이 캡처 시작 → 액션 → since 커서로 재폴링)
const a = await server.request("browser.cdp_events", {}, { sessionId, pageId });            // 캡처 시작
await server.request("browser.cdp_command", { method: "Page.reload" }, { sessionId, pageId });
const b = await server.request("browser.cdp_events",                                        // 이후 이벤트
  { since: a.result.cursor, methods: ["Network.responseReceived"] }, { sessionId, pageId });
```

- **denylist**(차단): `Browser.*`/`Target.*`/`Fetch.*`/`Tethering.*`/`SystemInfo.*` +
  `Storage.clearDataForOrigin`/`Page.setDownloadBehavior`/`Page.setBypassCSP` → `POLICY_DENIED`.
- 결과는 **redaction 없이** 그대로 반환된다(호출자 책임). 모든 호출은 audit된다.
- `cdp_events`: 탭당 최근 **500개** 링버퍼, `since` 커서 이후 + `methods` 필터 + `limit`.

---

## 3. 외부에서 도구 정의 (`@browser-bridge/agent-adapter`)

### 3.1 코드 레시피

```ts
import { makeCdp, makeCdpEvents, defineCdpTool, runCdpTool } from "@browser-bridge/agent-adapter";

const cdp = makeCdp(server, { sessionId, pageId });        // (method, params) => result
const events = makeCdpEvents(server, { sessionId, pageId }); // (opts) => { events, cursor }

const highlight = defineCdpTool<{ selector: string }, boolean>({
  name: "highlight_selector",
  description: "Outline the first element matching a selector",
  inputSchema: { properties: { selector: { type: "string" } }, required: ["selector"] },
  async run(cdp, { selector }) {
    const { root } = (await cdp("DOM.getDocument", { depth: 0 })) as any;
    const { nodeId } = (await cdp("DOM.querySelector", { nodeId: root.nodeId, selector })) as any;
    if (!nodeId) return false;
    await cdp("Overlay.enable");
    await cdp("Overlay.highlightNode", { nodeId, highlightConfig: { contentColor: { r: 80, g: 200, b: 120, a: 0.4 } } });
    return true;
  },
});
await runCdpTool(server, { sessionId, pageId }, highlight, { selector: "#go" });
```

기본 제공 예제: `getLayoutMetrics` · `getFullText` · `highlightSelector` · `recentNetworkTool`(이벤트 기반).

### 3.2 선언적 JSON 레시피 + 스킬 디렉터리

코드 없이 CDP 시퀀스를 JSON으로(`examples/skills/*.json`). `{{args.x}}` / `{{stepN.path}}` 템플릿팅,
`result`로 반환값 추출(인덱스 / `stepN.경로` / 생략=마지막 스텝).

```json
{ "name": "find_node", "description": "...",
  "inputSchema": { "properties": { "selector": { "type": "string" } }, "required": ["selector"] },
  "steps": [
    { "method": "DOM.getDocument", "params": { "depth": 0 } },
    { "method": "DOM.querySelector", "params": { "nodeId": "{{step0.root.nodeId}}", "selector": "{{args.selector}}" } }
  ],
  "result": "step1.nodeId" }
```

```ts
import { recipeToCdpTool, loadRecipesFromDir } from "@browser-bridge/agent-adapter";
const tools = (await loadRecipesFromDir("examples/skills")).map(recipeToCdpTool);
```

### 3.3 MCP로 노출 / 실행

```bash
pnpm mcp                       # = runMcpStdio: 확장 WS + MCP 서버(stdin/stdout)
BB_SKILLS_DIR=examples/skills pnpm mcp
```

- `tools/list` = 프로토콜 도구(`browser.*`) + 등록된 CDP/레시피/이벤트 도구.
- `tools/call`: 외부 도구는 `cdpToolToMcp`가 만든 `invoke`로 실행, 프로토콜 도구는 `makeMcpCallTool`이
  args의 `sessionId`/`pageId`를 라우팅으로 분리해 확장에 포워딩.
- MCP 인자에는 `sessionId`/`pageId`를 포함해야 한다(라우팅).

---

## 4. 구현 세부

### 확장 측
- [`debugger-manager.ts`](../packages/extension/src/background/debugger-manager.ts)
  - `ensureAttached(tabId)`: `chrome.debugger.attach` + Log/Runtime/Network/Page `enable`. attach 실패 →
    `BACKEND_UNAVAILABLE`. `detach`는 paused/탭 종료 시 호출되고 버퍼·다이얼로그·raw 캡처를 정리.
  - `raw`(패스스루), `evaluate`, `setDeviceMetrics`/`clearDeviceMetrics`/`emulate`, `handleDialog`,
    `setFileInputFiles`, `listWebmcpTools`/`executeWebmcpTool`.
  - raw 이벤트: `rawCapture`(Set) + `rawEvents`(탭별 링버퍼, `MAX_RAW_EVENTS=500`) + 전역 `rawSeq`.
    `onEvent`가 다이얼로그 추적 → raw 캡처 → console/network 버퍼 순으로 처리.
- [`bridge.ts`](../packages/extension/src/background/bridge.ts): `dispatch()`의 케이스 + 핸들러
  (`cdpCommand`/`cdpEvents`는 `allowRawCdp` 게이트 + `isCdpMethodAllowed`).
- [`policy.ts`](../packages/extension/src/background/policy.ts): `isCdpMethodAllowed`(denylist prefix/method).
- [`session-manager.ts`](../packages/extension/src/background/session-manager.ts): `allowRawCdp` 필드(기본 false),
  `SessionDetail.allowRawCdp`로 노출.
- `upload_file` 노드 해석: content script `bb.tag_node`가 uid 요소에 `data-bb-cdp=<token>` 부여 →
  배경에서 `Runtime.evaluate`로 `objectId` 얻어 `DOM.setFileInputFiles` → 속성 정리.

### 어댑터 측 (`packages/agent-adapter/src/`)
- [`cdp-tools.ts`](../packages/agent-adapter/src/cdp-tools.ts): `makeCdp`/`makeCdpEvents`/`defineCdpTool`/
  `runCdpTool`/`cdpToolToMcp` + 예제 도구.
- [`recipes.ts`](../packages/agent-adapter/src/recipes.ts): `recipeToCdpTool`(템플릿팅·결과 추출)/`loadRecipesFromDir`.
- [`mcp-server.ts`](../packages/agent-adapter/src/mcp-server.ts): `tools/list`/`tools/call` + 추가 도구 레지스트리.
- [`mcp-stdio.ts`](../packages/agent-adapter/src/mcp-stdio.ts): `runMcpStdio`/`buildCdpMcpTools`/`makeMcpCallTool`,
  엔트리 [`mcp-cli.ts`](../packages/agent-adapter/src/mcp-cli.ts).

### 테스트
- 확장: `tests/debugger-tools.test.ts`(CDP 도구 + `cdp_command`/`cdp_events` 게이트·필터·커서).
- 어댑터: `tests/cdp-tools.test.ts`, `tests/recipes.test.ts`, `tests/mcp-server.test.ts`.
- fake CDP 포트는 명령 전송만 검증한다 — **실제 CDP 런타임 동작은 라이브 디버거 attach로 확인**할 것.

---

## 5. 보안 메모

raw CDP는 정책 우회 수단이 될 수 있어 **옵트인(`allowRawCdp`) + denylist + 소유 페이지 한정 + 감사**로
제한한다. 단 결과는 redaction하지 않는다(호출자 책임). 전역 비활성화가 필요하면 세션을 옵트인하지 않으면 된다.
전문 [threat-model.md](threat-model.md).
