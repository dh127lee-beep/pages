# 설계: Raw CDP Passthrough (외부 도구 정의용)

> 상태: **Phase 1·2·3 구현됨.** 확장: `cdp_command`(옵트인+denylist+소유권), `cdp_events`(탭 링버퍼).
> 어댑터: `makeCdp`/`makeCdpEvents`/`defineCdpTool`/`runCdpTool` + 예제, 선언적 레시피 러너
> (`recipeToCdpTool`/`loadRecipesFromDir`), `cdpToolToMcp` + `McpServer` `tools/call`,
> MCP stdio 러너(`runMcpStdio` / `pnpm mcp`). 남음: allowlist 프리셋, 도메인 자동 매칭. 참고:
> [browser-use/browser-harness](https://github.com/browser-use/browser-harness)
> ("One websocket to Chrome, nothing between" — 얇은 CDP 하니스 위에 스킬을 얹는 모델).

## 1. 목적

지금은 새 브라우저 기능을 쓰려면 매번 **확장에 도구를 추가**(TOOL_NAMES → bridge dispatch →
handler/CDP)해야 한다. 목표는 **확장을 얇은 CDP 릴레이로** 만들어, 외부(어댑터/에이전트/스킬)에서
**raw CDP 명령을 보내 새 브라우저 도구를 정의**할 수 있게 하는 것이다. 확장 코드 수정 없이 도구가
늘어난다.

단, browser-harness와 달리 우리는 **MV3 확장이 밖으로 연결**하고 **세션/탭 그룹 단위 소유권·감사·
정책**을 갖는다. 그래서 "그냥 다 열기"가 아니라 **그 모델 안에서의 통제된 passthrough**로 설계한다.

이미 기반은 있다: `DebuggerManager`가 `chrome.debugger`로 임의 CDP를 보내는
`sendCommand(tabId, method, params)`와 이벤트 리스너를 갖고 있고, 온디맨드 attach도 된다.

## 2. 구성 요소

```text
외부 도구 정의 (어댑터/스킬)          확장 (얇은 릴레이)
─────────────────────────────       ──────────────────────────────
cdp.send(method, params) ──▶ browser.cdp_command ──▶ DebuggerManager.sendCommand ──▶ Chrome(CDP)
recipe/skill 레지스트리                정책 게이트 + 감사 + 소유권 검증
   │ (MCP 도구로 노출)
   ▼
named tool ("flights.search" 등)
```

### 2.1 확장: passthrough 도구 (Phase 1)

새 page-scope 도구 하나가 핵심이다.

- **`browser.cdp_command`** — payload `{ method: string, params?: object }`.
  1. `resolveOwnedPage`로 소유 페이지 검증(세션/리스/일시정지 게이트 재사용).
  2. `policy.allowsCdp(method)` 검사(§4).
  3. `debugger.ensureAttached(tab)` → `sendCommand(tab, method, params)`.
  4. 결과 `{ result: <raw CDP 결과> }` 반환. CDP 에러는 `BACKEND_UNAVAILABLE`/`UNSUPPORTED_ACTION`로 매핑.
  - 감사: `type=browser.cdp_command` + `details.method`(메서드명만; params는 민감할 수 있어 기본 미기록).

타깃 모델: 기본은 **탭(page) 타깃**. `Browser.*` / `Target.createTarget` 같은 **브라우저 레벨 CDP**는
탭 attach로는 불가 → 기본 **차단**(§4). 필요 시 Phase 2에서 브라우저 타깃 attach를 별도 설계.

### 2.2 확장: CDP 이벤트 구독 (Phase 2 ✅ 구현됨)

명령만으로는 부족한 도구(네트워크 가로채기, DOM 변경 관찰 등)를 위해:

- **`browser.cdp_events`** — payload `{ since?, methods?, limit? }` → `{ events, cursor }`.
  `DebuggerManager`가 모든 CDP 이벤트를 **탭별 링버퍼(최근 500)**에 적재(옵트인 캡처). 첫 호출이 캡처를
  시작하고, 이후 `since` 커서 이후 이벤트를 반환. `Network.enable` 등은 attach 시 이미 enable됨.
- 도메인 활성화가 더 필요하면 `cdp_command`로 외부가 직접 호출.

### 2.3 외부: 도구 정의 메커니즘 ("function pass")

확장은 그대로 두고, **도구는 어댑터/에이전트 쪽에서** 정의한다. 두 층:

> ✅ 구현됨: (a) 코드 레시피 + `cdpToolToMcp(server, tool)`로 **MCP 도구 자동 등록**
> (`McpServer`가 `tools/list`에 노출하고 `tools/call`로 실행; 프로토콜 도구는 `callTool`로 포워딩).

(a) **코드 레시피** — 어댑터에 `cdp` 클라이언트 헬퍼를 제공:
```ts
// agent-adapter
const cdp = (method, params) => bridge.call("browser.cdp_command", { method, params }, { sessionId, pageId });

// 외부 도구 정의: (cdp, args) => result
export const highlight = async (cdp, { selector }) => {
  const { root } = await cdp("DOM.getDocument", {});
  const { nodeId } = await cdp("DOM.querySelector", { nodeId: root.nodeId, selector });
  await cdp("Overlay.enable", {});
  return cdp("Overlay.highlightNode", { nodeId, highlightConfig: { contentColor: { r: 0, g: 200, b: 0, a: .3 } } });
};
```
이 함수들을 어댑터가 **MCP 도구로 등록**(name/description/schema + handler) → 에이전트엔 일반 도구로 보인다.

(b) **선언적 레시피**(코드 없이) — JSON로 CDP 시퀀스를 기술해 도구로 등록:
```json
{ "name": "page.metrics", "description": "레이아웃 메트릭",
  "steps": [{ "method": "Page.getLayoutMetrics" }],
  "result": "$.steps[0]" }
```
어댑터의 레시피 러너가 인자 템플릿팅(`{{args.x}}`) + 단계 실행 + 결과 추출을 처리.

(c) **스킬 디렉터리**(browser-harness 스타일, 선택) — `agent-workspace/domain-skills/*`에 사이트별
레시피를 두고 에이전트가 실행 중 추가/수정. 도메인 매칭으로 활성화.

## 3. 프로토콜

```json
// 요청
{ "id":"msg_1","version":"0.1.x","type":"browser.cdp_command",
  "sessionId":"sess_…","pageId":"page_…",
  "payload": { "method":"DOM.getDocument", "params": { "depth": 1 } } }

// 성공
{ "response": { "ok": true, "result": { /* raw CDP 결과 */ }, "auditId":"audit_…" } }

// 거부(정책)
{ "response": { "ok": false, "error": { "code":"POLICY_DENIED", "message":"CDP method blocked: Target.createTarget" } } }
```

`TOOL_NAMES`에 `browser.cdp_command`(+ Phase2 `browser.cdp_events`) 추가.
`get_capabilities`에 `rawCdp: { enabled, mode, allow/deny }` 노출.

## 4. 보안 · 정책 (핵심)

raw CDP는 쿠키 읽기·임의 이동·스크립트 주입·다운로드 등 **정책 우회 수단**이 된다. 따라서:

1. **옵트인 capability** — `start_session`에 `allowRawCdp?: boolean`(기본 **false**). 꺼진 세션에서
   `cdp_command` 호출 시 `POLICY_DENIED`.
2. **소유 탭 한정** — `resolveOwnedPage`만 통과. 타 세션/사용자 탭 불가. 브라우저 레벨 CDP 기본 차단.
3. **메서드 게이트** — 두 모드:
   - **denylist(기본)**: `Browser.*`, `Target.*`, `Storage.clearDataForOrigin`,
     `Page.setDownloadBehavior`, `Fetch.*`(요청 변조), `Input.dispatch*`는 신중 — 위험군 차단.
   - **allowlist(엄격)**: 명시한 도메인/메서드만 허용(`DOM.*`,`CSS.*`,`Runtime.evaluate`,`Page.getLayoutMetrics` 등).
   세션 생성 시 `cdpAllow`/`cdpDeny`로 조정.
4. **감사** — 모든 호출을 method까지 기록(`AuditLog`). 결과/리스크는 호출자 책임이며 **redaction 없음**을 명시.
5. **세션 게이트** — pause/finalize/동시성(Mutex)·명령 한도는 기존 도구와 동일 적용.
6. **킬 스위치** — 확장 옵션(또는 `BB_ALLOW_RAW_CDP`)으로 전역 비활성화 가능. 기본 비활성 권장.

## 5. 에러 · 한계

- CDP 도메인 미활성(예: `DOM.*` 전에 `DOM.enable` 필요) → 외부가 enable 호출 책임. 자동 enable은 옵션.
- `params`/`result` 크기 상한(예: 1MB) — 초과 시 `UNSUPPORTED_ACTION`.
- 명령 타임아웃은 브리지 요청 타임아웃(기본 60s) 사용.
- MV3 서비스워커 수명: 디버거 attach 유지 동안 워커가 살아있어야 함 — 장기 이벤트 스트림은 Phase 2에서
  alarm/keepalive 고려.
- 브라우저 타깃·다중 타깃(iframe/worker)·flat session: Phase 2에서 `sessionId`(CDP) 노출 설계.

## 6. 단계 계획

- **Phase 1 ✅** — `browser.cdp_command`(page-scope) + 옵트인 capability + denylist + 감사.
  어댑터에 `makeCdp`/`defineCdpTool`/`runCdpTool` + 예제 도구(`get_layout_metrics`,
  `get_full_text`, `highlight_selector`) 구현, demo에서 시연. (MCP 도구 등록 자동화는 Phase 2.)
- **Phase 2 ✅** — `browser.cdp_events`(탭 링버퍼 구독), MCP 자동 등록(`cdpToolToMcp` + `McpServer.tools/call`),
  선언적 레시피 러너(`recipeToCdpTool`), 이벤트 헬퍼(`makeCdpEvents`) + 예제(`recent_network_requests`).
- **Phase 3 ✅(기본)** — 스킬 디렉터리 로더(`loadRecipesFromDir`, `examples/skills/*.json`) + MCP stdio
  러너(`runMcpStdio` / `pnpm mcp`, `BB_SKILLS_DIR`). 남음: allowlist 프리셋, 도메인 자동 매칭, 에이전트 자가-기록.

## 7. 결정이 필요한 사항

1. **기본 정책**: denylist(유연, 권장) vs allowlist(엄격·안전). 기본 모드?
2. **capability 기본값**: `allowRawCdp` 기본 false 유지? (보안상 권장)
3. **도구 정의 위치**: 어댑터 코드 레시피 우선? 선언적 JSON 레시피까지? 스킬 디렉터리까지?
4. **이벤트 구독(Phase 2)** 지금 범위에 포함할지, 명령 passthrough만 먼저 할지.
5. **브라우저 레벨 CDP** 필요 여부(탭 한정으로 충분한지).

확정되면 Phase 1부터 구현한다(확장: ~1개 도구 + 정책/감사, 어댑터: cdp 헬퍼 + 등록 예제, 테스트, 문서).
