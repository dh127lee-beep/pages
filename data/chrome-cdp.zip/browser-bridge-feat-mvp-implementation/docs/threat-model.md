# 위협 모델

요약 문서다. 정식 정책·티어·redaction 규칙은
[spec/02-security-permissions.md](../spec/02-security-permissions.md)를 본다.

## 신뢰 경계 (요약)

| 경계 | 위험 | 통제 |
| --- | --- | --- |
| Agent → Bridge | 프롬프트 주입, 악성 tool 호출 | schema 검증, 세션 소유권 검사 |
| Adapter → Extension | 로컬 클라이언트 스푸핑 (수락된 리스크) | loopback 전용, schema 검증, client name 표시 |
| Extension → Native Host | 로컬 프로세스 남용 | allowlist, 명시적 설치, framed 프로토콜 |
| SW → Content Script | 과도한 탭 접근 | 세션/그룹 소유권, page lease |
| Content Script → Page | untrusted 콘텐츠 | 페이지 지시를 권위로 보지 않음 |
| Debugger → Browser | 광범위한 CDP | session-owned 탭만, attach/detach 수명 |
| Browser → Agent | 민감 콘텐츠 유출 | redaction, scope, audit |

## 핵심 수락 리스크: 자동 연결

연결은 **pairing 토큰/사용자 동의 없이 자동**으로 이뤄진다(제품 결정).

- **영향**: 어댑터 loopback 엔드포인트에 붙을 수 있는 임의의 로컬 프로세스가
  로그인된 브라우저를 무단 제어할 수 있다. 연결 시점 동의 게이트가 없다.
- **유지하는 안전선(마찰 0, pairing 아님)**:
  - 어댑터/WS는 `127.0.0.1` 루프백에만 바인딩.
  - 웹 페이지發(`window.postMessage`) 명령은 절대 수락하지 않음.
  - 확장은 로컬 HTTP 서버를 열지 않음.
  - 모든 envelope/command id를 schema 검증.
- **Native Messaging 경로**는 Chrome의 allowlist + 명시적 설치라는 추가 통제가 있어
  더 안전하다(프로덕션 우선 경로).

## 방어하는 것

- 프롬프트 주입: snapshot은 `source=untrusted_page`로 태깅, 페이지 텍스트는 지시 불가.
- 자격증명 유출: 쿠키/토큰 추출 API 없음, 민감 값/헤더/쿼리 redaction.
- 권한 남용: 모든 액션은 세션 소유권 + page lease + active 상태 게이트.
- 광범위 CDP: 디버거는 session-owned 탭만 attach, pause/release/end/close 시 detach.

## 방어하지 않는 것 (범위 밖)

- 연결 시점 사용자 동의(자동 연결 결정).
- 악성 로컬 환경(머신 자체가 침해된 경우).
- 에이전트의 판단 오류(위험 동작 최종 결정은 에이전트/사용자).
