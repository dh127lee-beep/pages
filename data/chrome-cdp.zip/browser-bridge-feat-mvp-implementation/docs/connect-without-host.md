# 매니페스트 없이 연결 (확장 + 내 프로그램만)

Native Messaging 매니페스트 설치(설치 가이드의 3번)를 **건너뛰는** 가장 단순한 방법.
요지: **당신의 프로그램이 곧 서버**가 되고, 확장이 거기에 자동 접속한다.

```text
당신의 프로그램(서버, 127.0.0.1:18470) ◀── Extension(client, 자동 접속)
```

- 매니페스트 불필요(3번 없음), 별도 babysit 어댑터 불필요.
- 확장은 native를 먼저 시도하다 실패하면 **자동으로 WS로 폴백**하므로 native 관련은
  아무것도 안 해도 된다.
- 단, 통신 상대는 한쪽에 있어야 한다 — 그 상대가 바로 당신이 어차피 실행할 프로그램이다.

## 절차

1. **확장 설치(1회)**: `pnpm build` → `chrome://extensions` → unpacked → `packages/extension/dist`.
2. **당신의 프로그램에 어댑터 임베드**: `@browser-bridge/agent-adapter`의 `DevWsServer`를
   `127.0.0.1:18470`에 띄우고 `server.request(...)`로 도구를 호출한다.
3. **프로그램 실행** → 확장이 자동 접속.

## 최소 예제

`examples/agent.mjs` 참고. 핵심만:

```js
import { DevWsServer } from "../packages/agent-adapter/dist/index.js"; // 빌드 후

const server = new DevWsServer({
  port: 18470,
  clientName: "my-program",
  onConnected: async () => {
    const s = await server.request("browser.start_session",
      { mode: "extension-tab", clientName: "my-program" });
    const sessionId = s.result.sessionId;
    await server.request("browser.new_page", { url: "https://example.com/" }, { sessionId });
  },
});
await server.start();
```

```bash
pnpm build
node examples/agent.mjs   # 확장만 설치돼 있으면 자동 접속
```

요청/응답 형식과 도구 목록은 [protocol.md](protocol.md), 사용 패턴은 [agent-usage.md](agent-usage.md).

## 이 방식 vs Native Messaging

| | 매니페스트 없이 (이 문서) | Native Messaging |
| --- | --- | --- |
| OS 매니페스트 설치(3번) | 불필요 | 필요(1회) |
| 누가 서버인가 | 당신의 프로그램 | Chrome이 띄운 호스트 |
| 외부 프로그램이 붙는 곳 | 당신의 프로그램 자체 | 호스트의 릴레이(127.0.0.1:18480) |
| "프로그램 0개"로 상시 대기 | 불가(프로그램이 곧 상대) | Chrome이 자동 실행(터미널 0) |

"확장만 설치하고 아무 프로그램도 안 띄운 채 외부에서 붙기"는 Native Messaging이 필요하고,
그건 매니페스트(3번)가 필수다. 매니페스트가 싫다면, 당신의 프로그램을 서버로 두는 이
방식이 가장 단순하다.
