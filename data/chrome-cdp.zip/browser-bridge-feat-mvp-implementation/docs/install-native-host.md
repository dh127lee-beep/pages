# Native Messaging 설치 (터미널 0 + 외부 프로그램 상시 접속)

이 경로의 핵심: **Chrome이 호스트 프로세스를 자동 실행**하므로 터미널을 띄울 필요가
없다. 그리고 호스트는 외부 에이전트용 **로컬 릴레이 포트(기본 `127.0.0.1:18480`)**를
함께 열기 때문에, 확장만 설치돼 있으면 외부 프로그램을 **아무 때나 실행해 접속**할 수
있다. (= "확장이 항상 켜진 서버"처럼 느껴짐)

```text
외부 에이전트/CLI ─ws→ 127.0.0.1:18480 (호스트의 릴레이)
                                  │
Chrome ─(connectNative, stdio)→ 호스트 ─(stdio)→ 확장 SW → 탭
        ↑ Chrome이 호스트를 자동 실행 (터미널 0)
```

## 1) 빌드

```bash
pnpm build   # 확장 + 전 패키지 (native-host 포함)
```

## 2) 확장 로드 후 ID 확인

[install-extension.md](install-extension.md)대로 `packages/extension/dist`를 로드하고,
`chrome://extensions`에서 확장의 **ID(32자, a–p)**를 복사한다. (unpacked ID는 dist 경로가
바뀌지 않는 한 고정)

## 3) 호스트 매니페스트 설치 (1회)

```bash
node packages/native-host/dist/install.js <확장-ID>
# Edge: ... <확장-ID> --edge   /  Chromium: ... --chromium
```

이 명령이 하는 일:
- 런처 스크립트 `packages/native-host/bb-native-host.sh` 생성(실행권한 부여) — `node dist/cli.js` 실행.
- OS의 NativeMessagingHosts 디렉터리에 `com.browser_bridge.native_host.json` 작성
  (`allowed_origins`에 해당 확장 ID만 등록).
  - macOS: `~/Library/Application Support/Google/Chrome/NativeMessagingHosts/`
  - Linux: `~/.config/google-chrome/NativeMessagingHosts/`

## 4) 연결

`chrome://extensions`에서 확장을 **새로고침**한다. 확장이 `connectNative`를 호출하면
Chrome이 호스트를 자동 실행하고, 호스트가 확장과 stdio로 연결된다.

확인:
- popup이 `connected`, `get_capabilities`의 `nativeHostAvailable`이 `true`.
- 호스트 로그(stderr)는 Chrome이 관리하므로, 디버깅 시 런처에 로그 리다이렉트를 추가.

## 5) 외부 프로그램에서 접속

확장이 연결돼 있는 동안 호스트의 릴레이가 `127.0.0.1:18480`에서 대기한다. 외부
프로그램은 WS로 붙어 tool 요청을 보낸다(JSON 한 줄):

```js
import WebSocket from "ws";
const ws = new WebSocket("ws://127.0.0.1:18480");
ws.on("open", () => {
  ws.send(JSON.stringify({ id: 1, type: "browser.start_session",
    payload: { mode: "extension-tab", clientName: "my-cli" } }));
});
ws.on("message", (d) => console.log(JSON.parse(d.toString()))); // { id, response }
```

요청 형식: `{ id, type, payload?, sessionId?, pageId? }` → 응답 `{ id, response }`.
도구·envelope는 [protocol.md](protocol.md), 사용 패턴은 [agent-usage.md](agent-usage.md).

## 보안

- `allowed_origins`에 등록된 확장 ID만 호스트에 연결 가능(Chrome 강제) + 호스트도 caller
  origin을 대조.
- 릴레이는 `127.0.0.1`에만 바인딩. 외부 네트워크 노출 없음. (자동 연결 정책의 수락된
  리스크는 [threat-model.md](threat-model.md).)

## 수명 주의 (caveat)

호스트는 확장의 native 포트가 열려 있는 동안만 산다. MV3 서비스 워커가 완전히 잠들면
포트가 닫혀 호스트(=릴레이)도 종료될 수 있다. 보통 활성 포트가 SW를 깨워 유지하지만,
오래 idle 후 첫 접속은 SW가 깨어 재연결될 때까지 짧게 지연될 수 있다. "절대적 상시
가동"이 필요하면 별도 브로커 데몬(launchd 상주) 방식을 고려한다([known-limitations.md](known-limitations.md)).

## 문제 해결

- 연결 실패 시 [troubleshooting.md](troubleshooting.md). 자주 보는 원인: 매니페스트 경로/권한,
  확장 ID 불일치, 런처 실행권한 누락, Node가 PATH에 없음.
