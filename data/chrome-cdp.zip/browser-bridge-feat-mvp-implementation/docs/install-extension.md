# 확장 설치 (개발)

## 빌드

```bash
pnpm install
pnpm build      # packages/extension/dist 생성
```

## Chrome/Edge에 로드

1. `chrome://extensions` (Edge는 `edge://extensions`) 열기
2. 우측 상단 **개발자 모드** ON
3. **압축해제된 확장 프로그램 로드** 클릭
4. `packages/extension/dist` 폴더 선택

## 확인

- 확장 아이콘 클릭 → popup에 연결 상태(disconnected/connected), 연결된 클라이언트,
  세션 수, debugger attached 수가 표시된다.
- 어댑터를 실행하지 않았다면 popup은 `disconnected`로 보인다 (정상).

## 권한

`manifest.json`은 의도적으로 고권한을 포함한다:
`activeTab`, `scripting`, `tabs`, `tabGroups`, `storage`, `debugger`, `alarms`,
`<all_urls>`, optional `nativeMessaging`. 근거는
[spec/02-security-permissions.md](../spec/02-security-permissions.md).

## 확장 ID 확인

`chrome://extensions`에서 확장의 ID(32자)를 확인해 둔다. Native Messaging 설치 시
allowlist에 필요하다 → [install-native-host.md](install-native-host.md).

## 코드 변경 반영

`pnpm build` 후 `chrome://extensions`에서 확장의 **새로고침** 버튼을 누른다.
