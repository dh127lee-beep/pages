# 알려진 한계

현재 MVP(Phase 0~10) 기준의 의도적 범위 제한과 미완 항목.

## 전송 / 연결

- 연결은 **자동(토큰/동의 없음)**이다. 임의의 로컬 프로세스가 어댑터/릴레이 엔드포인트에
  붙으면 로그인된 브라우저를 제어할 수 있다(수락된 리스크). 유지하는 안전선은
  loopback 전용 바인딩과 웹페이지 명령 거부뿐. → [threat-model.md](threat-model.md)
- 외부 프로그램은 native host의 릴레이(`127.0.0.1:18480`)로 raw JSON tool 요청을 보내 접속한다.
  단 호스트는 확장의 native 포트가 열려 있는 동안만 살아 있다(MV3 SW 수명 종속). **절대적
  상시 가동이 필요하면 별도 브로커 데몬(launchd 상주)이 후속 대안**.
- 멀티 에이전트는 **어댑터를 포트별로 띄우고 확장이 레인지 스캔으로 모두 연결**해 지원한다
  (세션은 agentId/탭그룹으로 격리, 에이전트마다 고유 clientName 필요). **한 어댑터는 확장 1개**만
  활성으로 받는다 — 여러 프로필 동시 사용은 프로필별 포트 분리가 필요. → [windows-and-ports](windows-and-ports.md)
- 세션은 첫 탭의 윈도우에 앵커링되어 새 탭이 그 윈도우에 열린다. **사용자가 수동으로 탭을
  다른 윈도우로 옮기는 경우의 reconcile은 후속**(탭 move/ungroup/window-move는 Phase 9 범위).
- MCP는 `initialize`/`tools/list`(정적 목록)까지 구현. **MCP stdio로 tool 실행까지 잇는
  브리지는 후속**(현재 외부 연동은 릴레이의 JSON 프로토콜 사용).
- 네이티브 프레이밍은 길이 접두사를 little-endian으로 가정(일반 플랫폼 기준).

## 탭 / 세션 수명

- 탭 close 이벤트는 처리하지만 **move/ungroup/window-move의 정밀 reconcile은 후속**
  (Phase 9 hardening 범위로 이관).
- page lease 만료는 세션 idle 타임아웃에 종속(개별 lease TTL은 미구현).

## snapshot / action

- DOM 추출은 대표 인터랙티브 요소 위주이며 cross-origin iframe 내부는 제한적.
- 액션 후 navigation 감지는 best-effort(같은 실행 컨텍스트 내 URL 비교).
- `evaluate_script`는 미구현(기본 read-only/predefined probe 설계만).

## 스크린샷

- `extension-tab` 모드는 보이는 탭만 캡처. 배경 탭은 `extension-debugger` 모드 필요.
- 아티팩트는 인메모리 레지스트리에 저장(어댑터 파일 저장은 후속).

## 테스트

- 단위/통합/E2E는 fake 포트와 실 loopback 소켓으로 커버. **실제 Chrome에서의
  수동 확인 항목**은 각 `task/0X-*.md`에 남아 있다.
