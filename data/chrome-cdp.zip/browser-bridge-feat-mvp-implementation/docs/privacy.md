# 프라이버시

Browser Bridge는 사용자의 실제 브라우저 세션에 접근하므로 데이터 취급을 명시한다.
정책의 근거는 [spec/02-security-permissions.md](../spec/02-security-permissions.md).

## 수집/노출하지 않는 것

- **쿠키·세션 토큰·auth 헤더 추출 API 없음** (Tier 4 금지).
- localStorage/sessionStorage 덤프 없음.
- 비밀번호 저장소 접근 없음.
- 페이지 본문/스크린샷/네트워크 페이로드를 audit 로그에 저장하지 않음.

## redaction (기본 적용)

- snapshot: password 필드 값은 `valueRedacted=true`, 값 미포함. hidden 입력 값 미노출.
  payment 유사 필드도 값 redaction.
- 네트워크: `Authorization`/`Cookie`/`Set-Cookie` 등 민감 헤더는 노출하지 않으며,
  URL의 `token`/`key`/`code`/`session`/`auth`/`secret`/`password`/`otp` 쿼리 파라미터는
  `[redacted]` 처리.

## 저장/수명

- 세션·페이지 메타데이터는 `chrome.storage.session`에 저장(브라우저 세션 동안 유지,
  종료 시 소거). 세션 종료/탭 닫힘 시 정리.
- 스크린샷 등 아티팩트는 인메모리 레지스트리에 보관되며 메타데이터만 에이전트에 반환.
- audit 이벤트는 id·동작·결과만(콤팩트), 페이로드 없이 bounded 버퍼로 보관.

## 신뢰 경계

- 페이지 콘텐츠는 항상 untrusted(`source=untrusted_page`). 페이지 텍스트는 사실을
  제공할 수 있으나 런타임에 지시를 내릴 수 없다(prompt injection 방어).
- 위험 동작(submit/upload/payment/password)은 risk hint로 표시되며 최종 판단은
  에이전트/사용자 몫이다.

## 사용자 가시성

- popup/side panel은 연결된 에이전트, 세션, 탭 그룹, lease, debugger 상태를 보여준다.

## 주의 (연결 정책)

현재 자동 연결(토큰/동의 없음) 정책상, 연결 시점의 명시적 동의 게이트가 없다.
민감 환경에서는 이 트레이드오프를 인지하고 사용한다 → [threat-model.md](threat-model.md).
