# 브라우저 도구 (Browser Tools)

이 문서는 현재 지원하는 `browser.*` 도구를 상세히 정리한다. 전송/응답 규약은
[protocol.md](protocol.md), 정식 정의는
[spec/03-protocol-and-mcp-tools.md](../spec/03-protocol-and-mcp-tools.md)를 참고한다.

도구 이름의 단일 출처는 [`packages/shared-protocol/src/tools.ts`](../packages/shared-protocol/src/tools.ts)의
`TOOL_NAMES`이고, 실제 디스패치는
[`packages/extension/src/background/bridge.ts`](../packages/extension/src/background/bridge.ts)의
`dispatch()`다. 페이지 액션의 실제 수행은
[`content/content-script.ts`](../packages/extension/src/content/content-script.ts),
탭/페이지 수명주기는 [`background/page-manager.ts`](../packages/extension/src/background/page-manager.ts)에 있다.

## 공통 규칙

- **envelope**: `{ id, version, type, sessionId?, pageId?, payload }` → `{ id, version, response }`.
  성공은 `response.ok=true`(+ `result`), 실패는 `response.ok=false`(+ `error.code`/`message`).
- **스코프**: 세션 도구는 `sessionId`, 페이지 도구는 `sessionId`+`pageId`가 **둘 다** 필요.
  소유권은 `agentId`(clientName 파생)로 검증 — 남의 세션/페이지는 건드릴 수 없다.
- **동시성**: 세션당 in-flight 명령 수 제한(`COMMAND_LIMIT_EXCEEDED`), 페이지 액션은
  페이지별 Mutex로 직렬화된다.
- **스냅샷 계약**: 액션의 `uid`는 **가장 최근 snapshot**의 것만 유효하다. 오래된 snapshot이면
  `SNAPSHOT_STALE`. snapshot은 `source=untrusted_page`로 태깅되고 password/payment 값은 redaction.

## 지원 도구

### 세션 (Session)

| 도구 | 스코프 | payload | 결과 | 비고 |
| --- | --- | --- | --- | --- |
| `browser.get_capabilities` | — | — | `{ protocolVersion, backends, permissions… }` | 버전·백엔드·권한 상태 |
| `browser.start_session` | — | `StartSessionInput` | `SessionDetail` | 논리적 탭 그룹 생성 |
| `browser.list_sessions` | agent | — | `SessionSummary[]` | 이 에이전트의 세션 목록 |
| `browser.get_session` | session | — | `SessionDetail` | 세션 상세 |
| `browser.pause_session` | session | — | `SessionDetail` | 명령 수락 중지 (`SESSION_PAUSED`) |
| `browser.resume_session` | session | — | `SessionDetail` | 명령 수락 재개 |
| `browser.end_session` | session | — | `SessionSummary` (status=finalized) | agent 생성 탭 닫고 claimed 탭은 해제 |

`StartSessionInput`: `mode`(`extension-tab` | `extension-debugger`), `clientName`,
`sessionLabel?`, `allowedDomains?`, `tabScope?`(`agent-created-only` | `active-tab` | `domain-grant`),
`tabGroup?`(`title`/`color`/`collapsed`).

### 페이지 / 탭 (Page & Tab)

| 도구 | 스코프 | payload | 결과 | 비고 |
| --- | --- | --- | --- | --- |
| `browser.new_page` | session | `NewPageInput` | `PageInfo` | 새 탭을 만들어 세션 그룹에 편입 |
| `browser.list_tabs` | agent | — | `TabSummary[]` | claim 선택용 사용자 탭 목록 |
| `browser.claim_tab` | session | `ClaimTabInput` | `PageInfo` | active 또는 `tabId`로 기존 탭 claim |
| `browser.release_tab` | page | — | `{ released: pageId }` | lease만 해제(탭은 유지) |
| `browser.list_pages` | session | — | `PageSummary[]` | 세션이 가진 페이지 목록 |
| `browser.get_tab_id` | page | — | `{ tabId }` | 페이지의 Chrome 탭 id |
| `browser.select_page` | page | — | `{ active: pageId }` | 해당 페이지 탭을 활성화(focus) |
| `browser.close_page` | page | — | `{ closed: pageId }` | 페이지 탭 닫고(에이전트 생성 시) lease 해제 |

`PageSummary`: `pageId`, `url`, `title`, `leaseStatus`.

- `NewPageInput`: `url`, `waitUntil?`(`load`|`domcontentloaded`|`networkidle`).
- `ClaimTabInput`: `strategy`(`active-tab`|`by-id`), `tabId?`(by-id 시 필수),
  `moveToSessionGroup?`, `preserveExistingGroup?`.
- 한 탭은 한 활성 세션만 lease 가능 — 중복 시 `TAB_ALREADY_LEASED`.

### 내비게이션 (Navigation)

| 도구 | 스코프 | payload | 결과 |
| --- | --- | --- | --- |
| `browser.navigate` | page | `NavigateInput` | `ActionResult` (`url`,`title`,`navigated`) |

- `NavigateInput`: `url`(http/https만, 아니면 `POLICY_DENIED`), `reload?`.
- 구현은 탭 이동 후 **URL 커밋(+짧은 grace) 또는 load 완료** 중 먼저 오는 시점까지 대기
  (전체 서브리소스 로드는 기다리지 않음, 타임아웃 8s). 이후 새 `url`/`title`을 반환.

### 관측 (Observation)

| 도구 | 스코프 | payload | 결과 | 비고 |
| --- | --- | --- | --- | --- |
| `browser.take_snapshot` | page | `TakeSnapshotInput` | `Snapshot` | a11y 우선 정규화 트리 + `uid` |
| `browser.take_screenshot` | page | — | `ArtifactMetadata` | 스크린샷 아티팩트(별도 저장) |

- `TakeSnapshotInput`: `includeBounds?`, `includeRiskHints?`, `includeHidden?`.
- `Snapshot.elements[]`: `uid`,`role`,`name`,`tag`,`visible`,`enabled`,
  `bounds?`,`value?`/`valueRedacted?`,`riskHints?`(`submit`|`upload`|`password`|`payment`).
- 디버거 모드(`extension-debugger`)는 비활성/백그라운드 탭도 캡처 가능.

### 페이지 액션 (Actions)

모두 page 스코프. 결과는 `ActionResult`(`url`,`title`,`navigated?`,`riskHints?`,`value?`,`matched?`).
액션 후 콘텐츠 스크립트는 DOM이 잠잠해질 때까지(quiet 150ms, 캡 800ms) 짧게 settle한다.

| 도구 | payload | 비고 |
| --- | --- | --- |
| `browser.click` | `{ snapshotId, uid }` | 클릭이 내비게이션을 유발하면(=콘텐츠 스크립트가 bfcache로 얼어 채널이 닫힘) 성공한 이동으로 처리하고 새 `url`/`title` 반환 |
| `browser.click_at` | `{ x, y }` | 좌표 기반 클릭(`elementFromPoint`). uid 불필요 |
| `browser.hover` | `{ snapshotId, uid }` | 마우스 호버(pointerover/mouseover/mousemove) |
| `browser.fill` | `{ snapshotId, uid, value }` | input/textarea/contenteditable 입력 |
| `browser.fill_form` | `{ snapshotId, fields: [{uid, value}] }` | 여러 필드 일괄 입력 |
| `browser.type_text` | `{ snapshotId, uid, text }` | 문자 단위 타이핑(keydown/input/keyup, 끝에 change) |
| `browser.press_key` | `{ key, uid? }` | 키 디스패치. `Enter`가 form 안이면 `submit` riskHint |
| `browser.scroll` | `{ direction: "up"\|"down", uid?, amount? }` | uid 지정 시 해당 요소로 scrollIntoView |
| `browser.drag` | `{ fromUid, toUid }` | HTML5 drag&drop 이벤트(dragstart→dragover→drop→dragend) |
| `browser.wait_for` | `{ text?, url?, timeoutMs? }` | 조건 충족까지 대기(기본 5s, 미충족 시 `ACTION_TIMEOUT`) |

### 디버깅 read (Debugger)

| 도구 | 스코프 | 결과 | 비고 |
| --- | --- | --- | --- |
| `browser.list_console_messages` | page | `ConsoleMessage[]` | 최근 콘솔 로그(레벨/텍스트/URL/타임스탬프) |
| `browser.list_network_requests` | page | `NetworkRequestSummary[]` | 최근 네트워크 요청(메서드/URL/상태/타입/소요) |

### CDP 기반 (디버거)

아래 도구는 `chrome.debugger`(CDP)를 통해 동작한다. 세션 모드와 무관하게 호출 시
**필요한 탭에 디버거를 온디맨드로 attach**한다(`DebuggerManager.ensureAttached`). 권한이 없거나
attach 실패 시 `BACKEND_UNAVAILABLE`. 권한은 `get_capabilities.debuggerPermission`으로 확인.

| 도구 | 스코프 | payload | 결과 | CDP |
| --- | --- | --- | --- | --- |
| `browser.evaluate_script` | page | `{ expression }` | `{ value }` (JSON 직렬화) | `Runtime.evaluate`(MAIN world, awaitPromise) |
| `browser.resize_page` | page | `{ width, height, deviceScaleFactor?, mobile?, reset? }` | `{ width, height, reset }` | `Emulation.setDeviceMetricsOverride` / `clear…` |
| `browser.emulate` | page | `EmulateInput` | `{ applied: true }` | `Emulation.setDeviceMetricsOverride` + `Network.emulateNetworkConditions` + `Emulation.setCPUThrottlingRate` |
| `browser.handle_dialog` | page | `{ accept, promptText? }` | `{ handled, dialog? }` | `Page.handleJavaScriptDialog` (열린 다이얼로그는 `Page.javascriptDialogOpening`로 추적) |
| `browser.upload_file` | page | `{ uid, files: string[], snapshotId? }` | `{ uploaded, uid }` | content-script가 uid 요소에 토큰 태깅 → `Runtime.evaluate`로 노드 해석 → `DOM.setFileInputFiles` |
| `browser.list_webmcp_tools` | page | — | `{ tools: WebmcpToolSummary[] }` | `Runtime.evaluate`로 페이지 WebMCP 제공자 조회 |
| `browser.execute_webmcp_tool` | page | `{ toolName, input? }` | `{ result }` | `Runtime.evaluate`로 페이지 WebMCP 도구 실행 |

| `browser.cdp_command` | page | `{ method, params? }` | `{ result }` (raw CDP) | 임의 CDP 명령 패스스루 (옵트인) |
| `browser.cdp_events` | page | `{ since?, methods?, limit? }` | `{ events: CdpEvent[], cursor }` | 버퍼된 CDP 이벤트 폴링 (옵트인) |

- `upload_file`의 `files`는 **브라우저 머신의 절대 경로**여야 한다(CDP 제약). 요소를 못 찾으면 `ELEMENT_NOT_FOUND`.
- **`cdp_command`(raw 패스스루)**: 외부에서 raw CDP로 새 도구를 정의하기 위한 통로. 세션이
  `start_session({ allowRawCdp: true })`로 **옵트인**해야 하며(미옵트인 시 `POLICY_DENIED`),
  소유 페이지에만 적용된다. `Browser.*`/`Target.*`/`Fetch.*`/`Storage.clearDataForOrigin` 등
  blast-radius가 큰 메서드는 denylist로 차단(`POLICY_DENIED`). 결과는 **redaction 없이** 그대로 반환된다.
  설계·정책 전문은 [design-raw-cdp-passthrough.md](design-raw-cdp-passthrough.md).
- **`cdp_events`(이벤트 폴링)**: 첫 호출이 캡처를 시작하고(idempotent), 이후 `since` 커서 이후의
  이벤트를 반환한다. 캡처 시작 후 발생한 이벤트만 잡히므로, "캡처 시작 → 액션(cdp_command) → 다시 폴링"
  순서로 쓴다. 탭당 최근 500개 링버퍼. `methods`로 필터(예: `["Network.responseReceived"]`).
- **WebMCP**는 페이지 JS API 계약(`navigator.modelContext` 또는 `window.agent`)을 대상으로 한다:
  목록은 `tools` 배열 / `listTools()` / `getTools()`, 실행은 `callTool(name, input)` 또는 도구의 `execute(input)`/`call(input)`.
  제공자가 없으면 목록은 `[]`, 실행은 에러. (chrome-devtools-mcp의 flag-gated DevTools WebMCP 도메인과는 다른, JS-API 기반 best-effort 구현.) `input`은 객체 또는 JSON 문자열.

- `EmulateInput`: `width?`,`height?`,`mobile?`, `network?`(`offline?`,`latencyMs?`,`downloadKbps?`,`uploadKbps?`),
  `cpuThrottlingRate?`(1=없음, 4=4배 느림), `reset?`(모든 오버라이드 해제).
- `evaluate_script`는 페이지(MAIN) 월드에서 실행되므로 페이지 전역에 접근한다. 예외는 `UNSUPPORTED_ACTION`.

## 에이전트에 노출되는 부분집합

LangGraph 에이전트([`agent/tools.py`](../agent/tools.py))는 위 프로토콜 도구 중 일부만 LLM 도구로 감싼다:
`take_snapshot`, `navigate`, `click`, `fill`, `scroll`, `read_console`(=`list_console_messages`).
세션/탭 수명주기(`start_session`/`new_page`/`end_session`)는 러너가 자동으로 처리한다.

여기에 더해 브라우저 도구가 아닌 **`final_response(text)`** 도구가 있다 — 에이전트가
최종 답변을 이 도구로 전달하면 루프가 종료되고, 콘솔 UI는 그 텍스트를 시스템 응답 말풍선으로
보여준다.

---

## chrome-devtools-mcp 대비 미반영 도구

아래는 참고 구현 [`reference/chrome-devtools-mcp`](../reference/chrome-devtools-mcp)에 정의돼 있으나
현재 이 프로젝트에 **반영되지 않은** 도구들이다. (이름은 chrome-devtools-mcp 기준)

> ✅ **이미 반영됨**(위 표 참고): `click_at` · `hover` · `type_text` · `drag` ·
> `evaluate_script` · `resize_page` · `emulate` · `handle_dialog` ·
> `list_pages` · `get_tab_id` · `select_page` · `close_page` ·
> `upload_file` · `list_webmcp_tools` · `execute_webmcp_tool`.

### 성능 / 진단
- `performance_start_trace` / `performance_stop_trace` / `performance_analyze_insight` — 성능 트레이싱
- `lighthouse_audit` — Lighthouse 감사

### 메모리 / 힙
- `take_heapsnapshot` / `close_heapsnapshot`
- `get_heapsnapshot_summary` / `get_heapsnapshot_details` / `get_heapsnapshot_class_nodes` / `get_heapsnapshot_retainers`

### 스크린캐스트
- `screencast_start` / `screencast_stop` — 화면 스트리밍 (우리는 단발 `take_screenshot`만)

### 확장 관리
- `install_extension` / `uninstall_extension` / `reload_extension` / `list_extensions` / `trigger_extension_action`

### 단건 조회 헬퍼
- `get_console_message` / `get_network_request` — 단일 항목 조회
  (우리는 목록형 `list_console_messages` / `list_network_requests`만)

> 참고: chrome-devtools-mcp는 단일 프로세스가 CDP로 직접 붙는 구조라 위 기능을 폭넓게 노출한다.
> 이 프로젝트는 MV3 확장이 **밖으로 연결**해 세션/탭 그룹 단위로 권한을 격리하는 모델이라,
> 미반영 도구를 더할 때는 스코프·소유권·redaction·정책 검증을 함께 설계해야 한다.
