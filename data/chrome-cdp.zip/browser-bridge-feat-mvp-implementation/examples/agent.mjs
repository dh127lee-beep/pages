/**
 * 최소 예제: "당신의 프로그램"이 곧 서버.
 *
 * 매니페스트 설치(Native Messaging) 없이, 확장만 설치돼 있으면 이 프로그램을
 * 실행하는 순간 확장이 자동 접속한다(확장은 native 실패 시 WS로 폴백).
 *
 * 준비:  pnpm build        (확장 + 어댑터 빌드)
 * 실행:  node examples/agent.mjs
 * 그리고 확장을 설치(packages/extension/dist)해 두기만 하면 된다.
 */

// 빌드 산출물에서 import (pnpm 워크스페이스 링크 없이 동작).
import { DevWsServer } from "../packages/agent-adapter/dist/index.js";

const server = new DevWsServer({
  port: 18470, // 확장 기본 접속 포트 (options에서 변경 가능)
  clientName: "my-program",
  onConnected: async () => {
    console.log("✅ 확장 연결됨 — 명령을 보냅니다.");

    console.log(await server.request("browser.get_capabilities"));

    const started = await server.request("browser.start_session", {
      mode: "extension-tab",
      clientName: "my-program",
      sessionLabel: "example",
    });
    if (!started.ok) return;
    const sessionId = started.result.sessionId;

    const page = await server.request("browser.new_page", { url: "https://example.com/" }, { sessionId });
    console.log("새 탭/탭그룹:", page.result);
    if (!page.ok) return;
    const pageId = page.result.pageId;

    console.log("snapshot:", await server.request("browser.take_snapshot", {}, { sessionId, pageId }));
    // 끝낼 때: await server.request("browser.end_session", {}, { sessionId });
  },
  onDisconnected: () => console.log("확장 연결 끊김 (재연결 대기)."),
});

await server.start();
console.log(
  "ws://127.0.0.1:18470 에서 대기 중. 확장(packages/extension/dist)만 설치돼 있으면 자동 접속합니다.\nCtrl+C 로 종료.",
);
