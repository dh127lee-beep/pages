import { fileURLToPath } from "node:url";
import { defineConfig } from "vitest/config";

const resolveSrc = (pkg: string) =>
  fileURLToPath(new URL(`./packages/${pkg}/src/index.ts`, import.meta.url));

export default defineConfig({
  resolve: {
    alias: {
      "@browser-bridge/shared-protocol": resolveSrc("shared-protocol"),
      "@browser-bridge/artifact-store": resolveSrc("artifact-store"),
      "@browser-bridge/agent-adapter": resolveSrc("agent-adapter"),
    },
  },
  test: {
    environment: "node",
    include: ["tests/**/*.test.ts", "packages/**/*.test.ts"],
  },
});
