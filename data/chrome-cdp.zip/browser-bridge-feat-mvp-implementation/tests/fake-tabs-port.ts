import type { CreateTabOptions, GroupTabsOptions, GroupUpdate, TabInfo, TabsPort } from "../packages/extension/src/background/tabs-port.js";

interface FakeGroup {
  title: string;
  color: string;
  collapsed: boolean;
  tabIds: number[];
}

/** In-memory TabsPort for unit tests. */
export class FakeTabsPort implements TabsPort {
  readonly tabs = new Map<number, TabInfo>();
  readonly groups = new Map<number, FakeGroup>();
  readonly closed: number[] = [];
  activeTab?: TabInfo;
  /** Window a new tab lands in when the caller doesn't specify one. */
  defaultWindowId = 1;

  private tabSeq = 100;
  private groupSeq = 900;

  async createTab(options: CreateTabOptions): Promise<TabInfo> {
    const tab: TabInfo = {
      tabId: ++this.tabSeq,
      windowId: options.windowId ?? this.defaultWindowId,
      url: options.url,
      title: `Tab ${this.tabSeq}`,
    };
    this.tabs.set(tab.tabId, tab);
    return tab;
  }

  async closeTab(tabId: number): Promise<void> {
    this.closed.push(tabId);
    this.tabs.delete(tabId);
  }

  async getTab(tabId: number): Promise<TabInfo | undefined> {
    return this.tabs.get(tabId);
  }

  async getActiveTab(): Promise<TabInfo | undefined> {
    return this.activeTab;
  }

  async listTabs(): Promise<TabInfo[]> {
    return [...this.tabs.values()];
  }

  async activate(tabId: number): Promise<void> {
    for (const tab of this.tabs.values()) tab.active = tab.tabId === tabId;
  }

  async navigate(tabId: number, url: string): Promise<void> {
    const tab = this.tabs.get(tabId);
    if (tab) tab.url = url;
  }

  async reload(tabId: number): Promise<void> {
    this.reloaded.push(tabId);
  }

  readonly reloaded: number[] = [];

  /** Seed an active user tab for claim tests. */
  setActiveTab(tab: Partial<TabInfo>): TabInfo {
    const full: TabInfo = {
      tabId: tab.tabId ?? ++this.tabSeq,
      windowId: tab.windowId ?? 1,
      url: tab.url ?? "https://example.com/",
      title: tab.title ?? "Example",
    };
    this.tabs.set(full.tabId, full);
    this.activeTab = full;
    return full;
  }

  async groupTabs({ tabIds, groupId }: GroupTabsOptions): Promise<number> {
    const gid = groupId ?? ++this.groupSeq;
    const group = this.groups.get(gid) ?? { title: "", color: "", collapsed: false, tabIds: [] };
    group.tabIds.push(...tabIds);
    this.groups.set(gid, group);
    return gid;
  }

  async updateGroup(groupId: number, update: GroupUpdate): Promise<void> {
    const group = this.groups.get(groupId) ?? { title: "", color: "", collapsed: false, tabIds: [] };
    if (update.title !== undefined) group.title = update.title;
    if (update.color !== undefined) group.color = update.color;
    if (update.collapsed !== undefined) group.collapsed = update.collapsed;
    this.groups.set(groupId, group);
  }

  async ungroupTabs(): Promise<void> {
    // no-op for tests
  }
}
