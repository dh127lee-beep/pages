import { describe, expect, it } from "vitest";
import { PROTOCOL_VERSION } from "@browser-bridge/shared-protocol";
import { makeBridge as build } from "./make-bridge.js";

const makeBridge = () => build().bridge;

const envelope = (type: string) => ({ id: "msg_1", version: PROTOCOL_VERSION, type, payload: {} });

describe("Bridge.handleMessage", () => {
  it("returns capabilities for browser.get_capabilities", async () => {
    const res = await makeBridge().handleMessage(envelope("browser.get_capabilities"));
    expect(res).toMatchObject({ ok: true, result: { protocolVersion: PROTOCOL_VERSION, backends: ["extension-tab", "extension-debugger"] } });
  });

  it("rejects an unknown tool", async () => {
    const res = await makeBridge().handleMessage(envelope("browser.nope"));
    expect(res).toMatchObject({ ok: false, error: { code: "UNSUPPORTED_ACTION" } });
  });

  it("requires a session context for a page tool", async () => {
    // evaluate_script is implemented now; without a handshake/context it is rejected.
    const res = await makeBridge().handleMessage(envelope("browser.evaluate_script"));
    expect(res).toMatchObject({ ok: false, error: { code: "SESSION_NOT_FOUND" } });
  });

  it("rejects a malformed envelope", async () => {
    const res = await makeBridge().handleMessage({ not: "valid" });
    expect(res).toMatchObject({ ok: false, error: { code: "UNSUPPORTED_ACTION" } });
  });
});
