import { describe, expect, it } from "vitest";
import { agentIdFromClientName, type StartSessionInput } from "@browser-bridge/shared-protocol";
import { PageManager } from "../packages/extension/src/background/page-manager.js";
import { SessionManager } from "../packages/extension/src/background/session-manager.js";
import { FakeTabsPort } from "./fake-tabs-port.js";

const input: StartSessionInput = { mode: "extension-tab", clientName: "codex" };
const owner = { agentId: agentIdFromClientName("codex"), clientName: "codex" };

describe("multi-window principle: session is window-anchored", () => {
  it("anchors to the window of the first tab and opens later tabs there", async () => {
    const sessions = new SessionManager();
    const tabs = new FakeTabsPort();
    const pages = new PageManager(tabs, sessions);
    const session = await sessions.create(owner, input);

    // First page lands in window 7 → the session anchors to window 7.
    tabs.defaultWindowId = 7;
    const first = await pages.newPage(session, "https://a.com/", "https://a.com");
    expect(first.windowId).toBe(7);
    expect(sessions.get(session.sessionId)!.tabGroup.windowId).toBe(7);

    // Even if the "current" window changes, the next page opens in the anchored window.
    tabs.defaultWindowId = 99;
    const second = await pages.newPage(session, "https://b.com/", "https://b.com");
    expect(second.windowId).toBe(7);
    // Same tab group, same window.
    expect(second.tabGroupId).toBe(first.tabGroupId);
  });

  it("keeps two sessions in their own windows", async () => {
    const sessions = new SessionManager();
    const tabs = new FakeTabsPort();
    const pages = new PageManager(tabs, sessions);

    const s1 = await sessions.create(owner, input);
    tabs.defaultWindowId = 1;
    const p1 = await pages.newPage(s1, "https://a.com/", "https://a.com");

    const s2 = await sessions.create({ agentId: agentIdFromClientName("cursor"), clientName: "cursor" }, input);
    tabs.defaultWindowId = 2;
    const p2 = await pages.newPage(s2, "https://b.com/", "https://b.com");

    expect(p1.windowId).toBe(1);
    expect(p2.windowId).toBe(2);
    expect(p1.tabGroupId).not.toBe(p2.tabGroupId);
  });
});
