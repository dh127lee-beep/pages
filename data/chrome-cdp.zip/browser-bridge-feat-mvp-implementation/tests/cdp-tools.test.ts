import { describe, expect, it } from "vitest";
import type { RpcRoute, ToolResponse } from "@browser-bridge/shared-protocol";
import {
  getLayoutMetrics,
  highlightSelector,
  makeCdp,
  runCdpTool,
  type CdpRequester,
} from "../packages/agent-adapter/src/cdp-tools.js";

class FakeRequester implements CdpRequester {
  readonly calls: Array<{ method: string; params: unknown; route: RpcRoute }> = [];
  constructor(private readonly responder: (method: string, params: unknown) => unknown = () => ({})) {}

  async request(type: string, payload?: unknown, route: RpcRoute = {}): Promise<ToolResponse> {
    if (type !== "browser.cdp_command") {
      return { ok: false, error: { code: "UNSUPPORTED_ACTION", message: `unexpected ${type}` } };
    }
    const { method, params } = (payload ?? {}) as { method: string; params?: unknown };
    this.calls.push({ method, params, route });
    return { ok: true, result: { result: this.responder(method, params) } } as ToolResponse;
  }
}

describe("cdp-tools", () => {
  it("makeCdp forwards method+params and unwraps the CDP result", async () => {
    const fake = new FakeRequester((method) => (method === "Page.getLayoutMetrics" ? { cssVisualViewport: { clientWidth: 800 } } : {}));
    const cdp = makeCdp(fake, { sessionId: "sess_1", pageId: "page_1" });
    const out = await cdp("Page.getLayoutMetrics");
    expect(out).toMatchObject({ cssVisualViewport: { clientWidth: 800 } });
    expect(fake.calls[0]).toMatchObject({ method: "Page.getLayoutMetrics", route: { sessionId: "sess_1", pageId: "page_1" } });
  });

  it("makeCdp throws when the passthrough is denied", async () => {
    const denying: CdpRequester = {
      async request() {
        return { ok: false, error: { code: "POLICY_DENIED", message: "off" } };
      },
    };
    const cdp = makeCdp(denying, {});
    await expect(cdp("DOM.getDocument")).rejects.toThrow(/POLICY_DENIED/);
  });

  it("runCdpTool(getLayoutMetrics) issues Page.getLayoutMetrics", async () => {
    const fake = new FakeRequester(() => ({ ok: true }));
    await runCdpTool(fake, { sessionId: "s", pageId: "p" }, getLayoutMetrics, {});
    expect(fake.calls.map((c) => c.method)).toEqual(["Page.getLayoutMetrics"]);
  });

  it("highlightSelector resolves the node then highlights it", async () => {
    const fake = new FakeRequester((method) => {
      if (method === "DOM.getDocument") return { root: { nodeId: 1 } };
      if (method === "DOM.querySelector") return { nodeId: 42 };
      return {};
    });
    const ok = await runCdpTool(fake, { sessionId: "s", pageId: "p" }, highlightSelector, { selector: "#go" });
    expect(ok).toBe(true);
    const methods = fake.calls.map((c) => c.method);
    expect(methods).toEqual(["DOM.getDocument", "DOM.querySelector", "Overlay.enable", "Overlay.highlightNode"]);
  });
});
