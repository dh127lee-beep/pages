import { describe, expect, it, vi } from "vitest";
import { ok, type RpcRoute } from "@browser-bridge/shared-protocol";
import { handleAgentMessage } from "../packages/native-host/src/agent-relay.js";

describe("handleAgentMessage", () => {
  it("forwards a tool request with its route and wraps the reply", async () => {
    const request = vi.fn(async (_type: string, _payload: unknown, _route: RpcRoute) => ok({ done: true }));
    const reply = (await handleAgentMessage(
      { id: 7, type: "browser.take_snapshot", sessionId: "sess_1", pageId: "page_1", payload: {} },
      request,
    )) as { id: number; response: unknown };

    expect(request).toHaveBeenCalledWith("browser.take_snapshot", {}, { sessionId: "sess_1", pageId: "page_1" });
    expect(reply).toMatchObject({ id: 7, response: { ok: true, result: { done: true } } });
  });

  it("ignores a malformed message", async () => {
    const request = vi.fn(async () => ok({}));
    expect(await handleAgentMessage({ nope: true }, request)).toBeUndefined();
    expect(request).not.toHaveBeenCalled();
  });
});
