import { describe, expect, it } from "vitest";
import { FrameDecoder, PROTOCOL_VERSION, encodeFrame, makeResponse, ok } from "@browser-bridge/shared-protocol";
import { NativeHost } from "../packages/native-host/src/native-host.js";

function decodeFrames(frames: Uint8Array[]): Array<Record<string, unknown>> {
  const decoder = new FrameDecoder();
  const out: Array<Record<string, unknown>> = [];
  for (const f of frames) out.push(...(decoder.push(f) as Array<Record<string, unknown>>));
  return out;
}

describe("NativeHost", () => {
  it("handshakes over framed stdio and round-trips a request", async () => {
    const writes: Uint8Array[] = [];
    const host = new NativeHost({ write: (f) => writes.push(f), clientName: "host" });

    host.onData(encodeFrame({ type: "bridge.hello", protocolVersion: PROTOCOL_VERSION, extensionVersion: "0.1.0" }));
    expect(decodeFrames(writes).at(-1)).toMatchObject({ type: "bridge.identify" });

    host.onData(encodeFrame({ type: "bridge.welcome", protocolVersion: PROTOCOL_VERSION, connectionId: "conn_1" }));
    expect(host.connected).toBe(true);

    const p = host.request("browser.get_capabilities");
    const sent = decodeFrames(writes);
    const req = sent.find((m) => m.type === "browser.get_capabilities") as { id: string };
    host.onData(encodeFrame(makeResponse(req.id, ok({ ok: 1 }))));
    await expect(p).resolves.toMatchObject({ ok: true, result: { ok: 1 } });
  });

  it("rejects a caller whose extension id is not allowlisted", () => {
    const writes: Uint8Array[] = [];
    let rejected = "";
    const host = new NativeHost({
      write: (f) => writes.push(f),
      clientName: "host",
      allowedExtensionIds: ["abcdefghijklmnopabcdefghijklmnop"],
      callerOrigin: "chrome-extension://ponmlkjihgfedcbaponmlkjihgfedcba/",
      onRejected: (r) => (rejected = r),
    });
    expect(host.allowed).toBe(false);
    host.onData(encodeFrame({ type: "bridge.hello", protocolVersion: PROTOCOL_VERSION, extensionVersion: "0.1.0" }));
    expect(writes).toHaveLength(0);
    expect(rejected).toContain("not allowed");
  });

  it("allows an allowlisted caller", () => {
    const id = "abcdefghijklmnopabcdefghijklmnop";
    const host = new NativeHost({
      write: () => {},
      clientName: "host",
      allowedExtensionIds: [id],
      callerOrigin: `chrome-extension://${id}/`,
    });
    expect(host.allowed).toBe(true);
  });
});
