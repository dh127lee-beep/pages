import { describe, expect, it } from "vitest";
import { PROTOCOL_VERSION, agentIdFromClientName, newConnectionId } from "@browser-bridge/shared-protocol";
import type { Bridge } from "../packages/extension/src/background/bridge.js";
import type { ToolContext } from "../packages/extension/src/background/context.js";
import { makeBridge as harness } from "./make-bridge.js";

function ctxFor(clientName: string): ToolContext {
  return { agentId: agentIdFromClientName(clientName), connectionId: newConnectionId(), clientName };
}

const msg = (type: string, payload: unknown = {}, sessionId?: string, pageId?: string) => ({
  id: "msg_1",
  version: PROTOCOL_VERSION,
  type,
  ...(sessionId ? { sessionId } : {}),
  ...(pageId ? { pageId } : {}),
  payload,
});

async function startSession(bridge: Bridge, ctx: ToolContext, tabScope = "active-tab") {
  const res = await bridge.handleMessage(
    msg("browser.start_session", { mode: "extension-tab", clientName: ctx.clientName, tabScope }),
    ctx,
  );
  return res.ok ? res.sessionId! : "";
}

describe("page tools", () => {
  it("new_page opens a tab in the session group", async () => {
    const { bridge } = harness();
    const ctx = ctxFor("codex");
    const sid = await startSession(bridge, ctx);
    const res = await bridge.handleMessage(
      msg("browser.new_page", { url: "https://example.com/" }, sid),
      ctx,
    );
    expect(res).toMatchObject({ ok: true, result: { createdByAgent: true, leaseStatus: "leased" } });
    if (res.ok) expect(res.pageId).toMatch(/^page_/);
  });

  it("new_page rejects non-http urls", async () => {
    const { bridge } = harness();
    const ctx = ctxFor("codex");
    const sid = await startSession(bridge, ctx);
    const res = await bridge.handleMessage(msg("browser.new_page", { url: "file:///etc/passwd" }, sid), ctx);
    expect(res).toMatchObject({ ok: false, error: { code: "POLICY_DENIED" } });
  });

  it("new_page enforces the domain allowlist", async () => {
    const { bridge } = harness();
    const ctx = ctxFor("codex");
    const res = await bridge.handleMessage(
      msg("browser.start_session", {
        mode: "extension-tab",
        clientName: "codex",
        allowedDomains: ["example.com"],
      }),
      ctx,
    );
    const sid = res.ok ? res.sessionId! : "";
    const denied = await bridge.handleMessage(msg("browser.new_page", { url: "https://evil.com/" }, sid), ctx);
    expect(denied).toMatchObject({ ok: false, error: { code: "POLICY_DENIED" } });
    const allowed = await bridge.handleMessage(
      msg("browser.new_page", { url: "https://example.com/ok" }, sid),
      ctx,
    );
    expect(allowed.ok).toBe(true);
  });

  it("new_page on a paused session is rejected", async () => {
    const { bridge } = harness();
    const ctx = ctxFor("codex");
    const sid = await startSession(bridge, ctx);
    await bridge.handleMessage(msg("browser.pause_session", {}, sid), ctx);
    const res = await bridge.handleMessage(msg("browser.new_page", { url: "https://example.com/" }, sid), ctx);
    expect(res).toMatchObject({ ok: false, error: { code: "SESSION_PAUSED" } });
  });

  it("claim_tab requires a scope that allows it", async () => {
    const { bridge, tabs } = harness();
    const ctx = ctxFor("codex");
    const sid = await startSession(bridge, ctx, "agent-created-only");
    tabs.setActiveTab({ tabId: 11, url: "https://x.com/", title: "X" });
    const res = await bridge.handleMessage(msg("browser.claim_tab", { strategy: "active-tab" }, sid), ctx);
    expect(res).toMatchObject({ ok: false, error: { code: "POLICY_DENIED" } });
  });

  it("claim_tab claims the active tab when scope allows", async () => {
    const { bridge, tabs } = harness();
    const ctx = ctxFor("codex");
    const sid = await startSession(bridge, ctx, "active-tab");
    tabs.setActiveTab({ tabId: 12, url: "https://x.com/", title: "X" });
    const res = await bridge.handleMessage(msg("browser.claim_tab", { strategy: "active-tab" }, sid), ctx);
    expect(res).toMatchObject({ ok: true, result: { claimedFromUser: true } });
  });

  it("release_tab drops the lease without closing the tab", async () => {
    const { bridge, tabs } = harness();
    const ctx = ctxFor("codex");
    const sid = await startSession(bridge, ctx);
    const created = await bridge.handleMessage(msg("browser.new_page", { url: "https://a.com/" }, sid), ctx);
    const pid = created.ok ? created.pageId! : "";
    const res = await bridge.handleMessage(msg("browser.release_tab", {}, sid, pid), ctx);
    expect(res.ok).toBe(true);
    expect(tabs.closed).toHaveLength(0);
  });

  it("end_session closes agent-created tabs", async () => {
    const { bridge, tabs } = harness();
    const ctx = ctxFor("codex");
    const sid = await startSession(bridge, ctx);
    const created = await bridge.handleMessage(msg("browser.new_page", { url: "https://a.com/" }, sid), ctx);
    const tabId = created.ok ? (created.result as { pageId: string }) && tabs.tabs.size : 0;
    expect(tabId).toBeGreaterThan(0);
    await bridge.handleMessage(msg("browser.end_session", {}, sid), ctx);
    expect(tabs.closed).toHaveLength(1);
  });
});
