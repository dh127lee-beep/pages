import { describe, expect, it } from "vitest";
import { PROTOCOL_VERSION, agentIdFromClientName, newConnectionId } from "@browser-bridge/shared-protocol";
import type { Bridge } from "../packages/extension/src/background/bridge.js";
import type { ToolContext } from "../packages/extension/src/background/context.js";
import { makeBridge, type BridgeHarness } from "./make-bridge.js";

function ctxFor(clientName: string): ToolContext {
  return { agentId: agentIdFromClientName(clientName), connectionId: newConnectionId(), clientName };
}

const msg = (type: string, payload: unknown = {}, sessionId?: string, pageId?: string) => ({
  id: "msg_1",
  version: PROTOCOL_VERSION,
  type,
  ...(sessionId ? { sessionId } : {}),
  ...(pageId ? { pageId } : {}),
  payload,
});

async function startWithPage(bridge: Bridge, ctx: ToolContext, mode = "extension-tab") {
  const s = await bridge.handleMessage(msg("browser.start_session", { mode, clientName: ctx.clientName }), ctx);
  const sid = s.ok ? s.sessionId! : "";
  const p = await bridge.handleMessage(msg("browser.new_page", { url: "https://example.com/" }, sid), ctx);
  const pid = p.ok ? p.pageId! : "";
  return { sid, pid };
}

function tabIdOf(h: BridgeHarness, pid: string): number {
  return h.pages.get(pid as never)!.chromeTabId;
}

describe("debugger tools", () => {
  it("list_console_messages attaches and returns buffered messages", async () => {
    const h = makeBridge();
    const ctx = ctxFor("codex");
    const { sid, pid } = await startWithPage(h.bridge, ctx);
    const tabId = tabIdOf(h, pid);

    await h.debuggerManager.ensureAttached(tabId);
    h.debuggerPort.emit(tabId, "Runtime.consoleAPICalled", { type: "warning", args: [{ value: "hi" }], timestamp: 1 });

    const res = await h.bridge.handleMessage(msg("browser.list_console_messages", {}, sid, pid), ctx);
    expect(res.ok).toBe(true);
    if (res.ok) expect((res.result as unknown[]).length).toBe(1);
    expect(h.debuggerPort.attached.has(tabId)).toBe(true);
  });

  it("list_network_requests returns redacted summaries", async () => {
    const h = makeBridge();
    const ctx = ctxFor("codex");
    const { sid, pid } = await startWithPage(h.bridge, ctx);
    const tabId = tabIdOf(h, pid);

    await h.debuggerManager.ensureAttached(tabId);
    h.debuggerPort.emit(tabId, "Network.requestWillBeSent", {
      requestId: "r1",
      request: { method: "GET", url: "https://x.com/?auth=secret" },
      type: "Document",
      timestamp: 1,
    });

    const res = await h.bridge.handleMessage(msg("browser.list_network_requests", {}, sid, pid), ctx);
    expect(res.ok).toBe(true);
    if (res.ok) {
      const reqs = res.result as Array<{ url: string }>;
      expect(reqs[0]!.url).toContain("auth=%5Bredacted%5D");
    }
  });

  it("take_screenshot uses the debugger in extension-debugger mode", async () => {
    const h = makeBridge();
    const ctx = ctxFor("codex");
    const { sid, pid } = await startWithPage(h.bridge, ctx, "extension-debugger");
    const res = await h.bridge.handleMessage(msg("browser.take_screenshot", {}, sid, pid), ctx);
    expect(res).toMatchObject({ ok: true, result: { kind: "screenshot" } });
    expect(h.debuggerPort.commands.map((c) => c.method)).toContain("Page.captureScreenshot");
    expect(h.screenshotPort.calls).toBe(0);
  });

  it("detaches the debugger when the session is paused", async () => {
    const h = makeBridge();
    const ctx = ctxFor("codex");
    const { sid, pid } = await startWithPage(h.bridge, ctx);
    const tabId = tabIdOf(h, pid);
    await h.debuggerManager.ensureAttached(tabId);
    expect(h.debuggerPort.attached.has(tabId)).toBe(true);

    await h.bridge.handleMessage(msg("browser.pause_session", {}, sid), ctx);
    expect(h.debuggerPort.attached.has(tabId)).toBe(false);
  });

  it("evaluate_script sends Runtime.evaluate via the debugger", async () => {
    const h = makeBridge();
    const ctx = ctxFor("codex");
    const { sid, pid } = await startWithPage(h.bridge, ctx);
    const res = await h.bridge.handleMessage(msg("browser.evaluate_script", { expression: "document.title" }, sid, pid), ctx);
    expect(res).toMatchObject({ ok: true, result: { value: expect.any(String) } });
    expect(h.debuggerPort.commands.map((c) => c.method)).toContain("Runtime.evaluate");
  });

  it("resize_page sends Emulation.setDeviceMetricsOverride", async () => {
    const h = makeBridge();
    const ctx = ctxFor("codex");
    const { sid, pid } = await startWithPage(h.bridge, ctx);
    const res = await h.bridge.handleMessage(msg("browser.resize_page", { width: 390, height: 844, mobile: true }, sid, pid), ctx);
    expect(res.ok).toBe(true);
    expect(h.debuggerPort.commands.map((c) => c.method)).toContain("Emulation.setDeviceMetricsOverride");
  });

  it("emulate sends network + cpu CDP commands", async () => {
    const h = makeBridge();
    const ctx = ctxFor("codex");
    const { sid, pid } = await startWithPage(h.bridge, ctx);
    const res = await h.bridge.handleMessage(
      msg("browser.emulate", { network: { downloadKbps: 1500, latencyMs: 40 }, cpuThrottlingRate: 4 }, sid, pid),
      ctx,
    );
    expect(res.ok).toBe(true);
    const methods = h.debuggerPort.commands.map((c) => c.method);
    expect(methods).toContain("Network.emulateNetworkConditions");
    expect(methods).toContain("Emulation.setCPUThrottlingRate");
  });

  it("handle_dialog reports the open dialog and sends Page.handleJavaScriptDialog", async () => {
    const h = makeBridge();
    const ctx = ctxFor("codex");
    const { sid, pid } = await startWithPage(h.bridge, ctx);
    const tabId = tabIdOf(h, pid);
    await h.debuggerManager.ensureAttached(tabId);
    h.debuggerPort.emit(tabId, "Page.javascriptDialogOpening", { type: "confirm", message: "Sure?" });

    const res = await h.bridge.handleMessage(msg("browser.handle_dialog", { accept: true }, sid, pid), ctx);
    expect(res).toMatchObject({ ok: true, result: { handled: true, dialog: { type: "confirm", message: "Sure?" } } });
    expect(h.debuggerPort.commands.map((c) => c.method)).toContain("Page.handleJavaScriptDialog");
  });

  it("get_tab_id / list_pages / select_page / close_page", async () => {
    const h = makeBridge();
    const ctx = ctxFor("codex");
    const { sid, pid } = await startWithPage(h.bridge, ctx);

    const tab = await h.bridge.handleMessage(msg("browser.get_tab_id", {}, sid, pid), ctx);
    expect(tab).toMatchObject({ ok: true, result: { tabId: expect.any(Number) } });

    const list = await h.bridge.handleMessage(msg("browser.list_pages", {}, sid), ctx);
    expect(list.ok).toBe(true);
    if (list.ok) expect((list.result as unknown[]).length).toBe(1);

    const sel = await h.bridge.handleMessage(msg("browser.select_page", {}, sid, pid), ctx);
    expect(sel).toMatchObject({ ok: true, result: { active: pid } });

    const close = await h.bridge.handleMessage(msg("browser.close_page", {}, sid, pid), ctx);
    expect(close).toMatchObject({ ok: true, result: { closed: pid } });
    const after = await h.bridge.handleMessage(msg("browser.list_pages", {}, sid), ctx);
    if (after.ok) expect((after.result as unknown[]).length).toBe(0);
  });

  it("upload_file tags the node and calls DOM.setFileInputFiles", async () => {
    const h = makeBridge();
    const ctx = ctxFor("codex");
    const { sid, pid } = await startWithPage(h.bridge, ctx);
    const res = await h.bridge.handleMessage(
      msg("browser.upload_file", { uid: "snap_x_0", files: ["/tmp/a.txt"] }, sid, pid),
      ctx,
    );
    expect(res).toMatchObject({ ok: true, result: { uploaded: 1 } });
    expect(h.debuggerPort.commands.map((c) => c.method)).toContain("DOM.setFileInputFiles");
  });

  it("upload_file requires files", async () => {
    const h = makeBridge();
    const ctx = ctxFor("codex");
    const { sid, pid } = await startWithPage(h.bridge, ctx);
    const res = await h.bridge.handleMessage(msg("browser.upload_file", { uid: "snap_x_0", files: [] }, sid, pid), ctx);
    expect(res).toMatchObject({ ok: false, error: { code: "UNSUPPORTED_ACTION" } });
  });

  it("list_webmcp_tools returns a tools array (empty when no provider)", async () => {
    const h = makeBridge();
    const ctx = ctxFor("codex");
    const { sid, pid } = await startWithPage(h.bridge, ctx);
    const res = await h.bridge.handleMessage(msg("browser.list_webmcp_tools", {}, sid, pid), ctx);
    expect(res.ok).toBe(true);
    if (res.ok) expect(Array.isArray((res.result as { tools: unknown[] }).tools)).toBe(true);
  });

  it("execute_webmcp_tool requires toolName and runs via the debugger", async () => {
    const h = makeBridge();
    const ctx = ctxFor("codex");
    const { sid, pid } = await startWithPage(h.bridge, ctx);
    const bad = await h.bridge.handleMessage(msg("browser.execute_webmcp_tool", {}, sid, pid), ctx);
    expect(bad).toMatchObject({ ok: false, error: { code: "UNSUPPORTED_ACTION" } });
    const ok = await h.bridge.handleMessage(
      msg("browser.execute_webmcp_tool", { toolName: "search", input: { q: "x" } }, sid, pid),
      ctx,
    );
    expect(ok.ok).toBe(true);
    expect(h.debuggerPort.commands.map((c) => c.method)).toContain("Runtime.evaluate");
  });

  it("cdp_command is denied unless the session opted in (allowRawCdp)", async () => {
    const h = makeBridge();
    const ctx = ctxFor("codex");
    const { sid, pid } = await startWithPage(h.bridge, ctx);
    const res = await h.bridge.handleMessage(msg("browser.cdp_command", { method: "DOM.getDocument" }, sid, pid), ctx);
    expect(res).toMatchObject({ ok: false, error: { code: "POLICY_DENIED" } });
  });

  it("cdp_command forwards an allowed method when opted in", async () => {
    const h = makeBridge();
    const ctx = ctxFor("codex");
    const s = await h.bridge.handleMessage(msg("browser.start_session", { mode: "extension-tab", clientName: ctx.clientName, allowRawCdp: true }), ctx);
    const sid = s.ok ? s.sessionId! : "";
    const p = await h.bridge.handleMessage(msg("browser.new_page", { url: "https://example.com/" }, sid), ctx);
    const pid = p.ok ? p.pageId! : "";

    const res = await h.bridge.handleMessage(msg("browser.cdp_command", { method: "DOM.getDocument", params: { depth: 1 } }, sid, pid), ctx);
    expect(res).toMatchObject({ ok: true, result: { result: expect.anything() } });
    const last = h.debuggerPort.commands.at(-1)!;
    expect(last.method).toBe("DOM.getDocument");
    expect(last.params).toMatchObject({ depth: 1 });
  });

  it("cdp_command blocks denylisted methods even when opted in", async () => {
    const h = makeBridge();
    const ctx = ctxFor("codex");
    const s = await h.bridge.handleMessage(msg("browser.start_session", { mode: "extension-tab", clientName: ctx.clientName, allowRawCdp: true }), ctx);
    const sid = s.ok ? s.sessionId! : "";
    const p = await h.bridge.handleMessage(msg("browser.new_page", { url: "https://example.com/" }, sid), ctx);
    const pid = p.ok ? p.pageId! : "";

    const res = await h.bridge.handleMessage(msg("browser.cdp_command", { method: "Target.createTarget", params: {} }, sid, pid), ctx);
    expect(res).toMatchObject({ ok: false, error: { code: "POLICY_DENIED" } });
  });

  it("cdp_events is gated by allowRawCdp and captures + filters events", async () => {
    const h = makeBridge();
    const ctx = ctxFor("codex");
    // Not opted in -> denied.
    const { sid: sid0, pid: pid0 } = await startWithPage(h.bridge, ctx);
    const denied = await h.bridge.handleMessage(msg("browser.cdp_events", {}, sid0, pid0), ctx);
    expect(denied).toMatchObject({ ok: false, error: { code: "POLICY_DENIED" } });

    // Opted in.
    const s = await h.bridge.handleMessage(msg("browser.start_session", { mode: "extension-tab", clientName: ctx.clientName, allowRawCdp: true }), ctx);
    const sid = s.ok ? s.sessionId! : "";
    const p = await h.bridge.handleMessage(msg("browser.new_page", { url: "https://example.com/" }, sid), ctx);
    const pid = p.ok ? p.pageId! : "";
    const tabId = tabIdOf(h, pid);

    // First poll starts capture; nothing buffered yet.
    const first = await h.bridge.handleMessage(msg("browser.cdp_events", {}, sid, pid), ctx);
    expect(first.ok).toBe(true);
    const cursor0 = first.ok ? (first.result as { cursor: number }).cursor : -1;

    // Now events arrive; poll again with a method filter.
    h.debuggerPort.emit(tabId, "Network.responseReceived", { requestId: "r1" });
    h.debuggerPort.emit(tabId, "Runtime.consoleAPICalled", { type: "log", args: [] });
    const second = await h.bridge.handleMessage(
      msg("browser.cdp_events", { since: cursor0, methods: ["Network.responseReceived"] }, sid, pid),
      ctx,
    );
    expect(second.ok).toBe(true);
    if (second.ok) {
      const res = second.result as { events: Array<{ method: string }>; cursor: number };
      expect(res.events.map((e) => e.method)).toEqual(["Network.responseReceived"]);
      expect(res.cursor).toBeGreaterThan(cursor0);
    }
  });

  it("rejects console read on a page not leased by the session", async () => {
    const h = makeBridge();
    const ctx = ctxFor("codex");
    const { sid } = await startWithPage(h.bridge, ctx);
    const res = await h.bridge.handleMessage(msg("browser.list_console_messages", {}, sid, "page_bogus"), ctx);
    expect(res).toMatchObject({ ok: false, error: { code: "TAB_NOT_LEASED" } });
  });
});
