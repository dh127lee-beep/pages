import { describe, expect, it } from "vitest";
import { ArtifactRegistry } from "../packages/extension/src/background/artifacts.js";
import { DebuggerManager } from "../packages/extension/src/background/debugger-manager.js";
import { FakeDebuggerPort } from "./make-bridge.js";

function setup() {
  const port = new FakeDebuggerPort();
  const artifacts = new ArtifactRegistry();
  const mgr = new DebuggerManager(port, artifacts);
  return { port, artifacts, mgr };
}

describe("DebuggerManager", () => {
  it("attaches and enables CDP domains", async () => {
    const { port, mgr } = setup();
    await mgr.ensureAttached(5);
    expect(port.attached.has(5)).toBe(true);
    const methods = port.commands.map((c) => c.method);
    expect(methods).toEqual(expect.arrayContaining(["Log.enable", "Runtime.enable", "Network.enable", "Page.enable"]));
    expect(mgr.attachedCount()).toBe(1);
  });

  it("buffers console messages", async () => {
    const { port, mgr } = setup();
    await mgr.ensureAttached(5);
    port.emit(5, "Runtime.consoleAPICalled", { type: "error", args: [{ value: "boom" }], timestamp: 1 });
    const msgs = mgr.listConsole(5);
    expect(msgs).toHaveLength(1);
    expect(msgs[0]).toMatchObject({ level: "error", text: "boom" });
  });

  it("buffers network requests and redacts the url", async () => {
    const { port, mgr } = setup();
    await mgr.ensureAttached(5);
    port.emit(5, "Network.requestWillBeSent", {
      requestId: "r1",
      request: { method: "GET", url: "https://x.com/api?token=secret" },
      type: "XHR",
      timestamp: 1,
    });
    port.emit(5, "Network.responseReceived", { requestId: "r1", response: { status: 200 }, type: "XHR" });
    port.emit(5, "Network.loadingFinished", { requestId: "r1", timestamp: 1.5 });

    const reqs = mgr.listNetwork(5);
    expect(reqs).toHaveLength(1);
    expect(reqs[0]).toMatchObject({ method: "GET", status: 200, resourceType: "XHR", durationMs: 500 });
    expect(reqs[0]!.url).toContain("token=%5Bredacted%5D");
  });

  it("captures a screenshot artifact via the debugger", async () => {
    const { port, artifacts, mgr } = setup();
    const meta = await mgr.captureScreenshot({ sessionId: "sess_1", pageId: "page_1", chromeTabId: 5, tabGroupId: 9 });
    expect(meta.kind).toBe("screenshot");
    expect(meta.byteLength).toBeGreaterThan(0);
    expect(port.commands.map((c) => c.method)).toContain("Page.captureScreenshot");
    expect(artifacts.size).toBe(1);
  });

  it("detaches and clears the buffer", async () => {
    const { port, mgr } = setup();
    await mgr.ensureAttached(5);
    port.emit(5, "Runtime.consoleAPICalled", { type: "log", args: [{ value: "x" }], timestamp: 1 });
    await mgr.detach(5);
    expect(port.attached.has(5)).toBe(false);
    expect(mgr.attachedCount()).toBe(0);
    expect(mgr.listConsole(5)).toEqual([]);
  });
});
