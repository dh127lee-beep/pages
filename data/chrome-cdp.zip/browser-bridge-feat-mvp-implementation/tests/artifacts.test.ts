import { describe, expect, it } from "vitest";
import { ArtifactRegistry, decodeDataUrl } from "../packages/extension/src/background/artifacts.js";

describe("decodeDataUrl", () => {
  it("decodes a base64 data URL", () => {
    const { contentType, bytes } = decodeDataUrl("data:image/png;base64,aGk=");
    expect(contentType).toBe("image/png");
    expect(new TextDecoder().decode(bytes)).toBe("hi");
  });

  it("throws on a non-data URL", () => {
    expect(() => decodeDataUrl("https://example.com")).toThrow();
  });
});

describe("ArtifactRegistry", () => {
  it("stores bytes and returns metadata without the binary", () => {
    const reg = new ArtifactRegistry();
    const bytes = new Uint8Array([1, 2, 3, 4]);
    const meta = reg.put(
      { sessionId: "sess_1", pageId: "page_1", tabGroupId: 7, kind: "screenshot", contentType: "image/png" },
      bytes,
    );
    expect(meta.artifactId).toMatch(/^artifact_/);
    expect(meta.byteLength).toBe(4);
    expect(meta).not.toHaveProperty("bytes");
    expect(reg.get(meta.artifactId)?.bytes).toBe(bytes);
    expect(reg.size).toBe(1);
  });
});
