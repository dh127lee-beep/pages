import { describe, expect, it, vi } from "vitest";
import { PROTOCOL_VERSION, makeResponse, ok, type TransportMessage } from "@browser-bridge/shared-protocol";
import { ConnectionSession } from "../packages/extension/src/bridge/connection-session.js";
import { ConnectionRegistry } from "../packages/extension/src/background/connection-registry.js";

const flush = () => new Promise((r) => setTimeout(r, 0));

function setup(handleTool = vi.fn(async () => ok({}))) {
  const sent: unknown[] = [];
  const registry = new ConnectionRegistry();
  const onConnected = vi.fn();
  const session = new ConnectionSession((m) => sent.push(m), {
    registry,
    handleTool,
    protocolVersion: PROTOCOL_VERSION,
    extensionVersion: "0.1.0",
    onConnected,
  });
  return { sent, registry, session, onConnected, handleTool };
}

describe("ConnectionSession handshake", () => {
  it("sends hello on start", () => {
    const { sent, session } = setup();
    session.start();
    expect(sent[0]).toMatchObject({ type: "bridge.hello", protocolVersion: PROTOCOL_VERSION });
  });

  it("registers client and replies welcome on identify", () => {
    const { sent, session, registry, onConnected } = setup();
    session.start();
    session.receive({
      type: "bridge.identify",
      protocolVersion: PROTOCOL_VERSION,
      clientName: "codex",
      clientVersion: "1.2.3",
    });
    expect(registry.list()).toHaveLength(1);
    expect(registry.list()[0]).toMatchObject({ clientName: "codex" });
    expect(sent.at(-1)).toMatchObject({ type: "bridge.welcome" });
    expect(onConnected).toHaveBeenCalledOnce();
  });

  it("rejects an incompatible adapter version", () => {
    const { sent, session, registry } = setup();
    session.receive({
      type: "bridge.identify",
      protocolVersion: "9.9.9",
      clientName: "codex",
      clientVersion: "1.0.0",
    });
    expect(registry.list()).toHaveLength(0);
    expect(sent.at(-1)).toMatchObject({ type: "bridge.reject", code: "VERSION_MISMATCH" });
  });

  it("replies pong to ping", () => {
    const { sent, session } = setup();
    session.receive({ type: "bridge.ping", nonce: "abc" });
    expect(sent.at(-1)).toMatchObject({ type: "bridge.pong", nonce: "abc" });
  });

  it("unregisters on close", () => {
    const { session, registry } = setup();
    session.receive({
      type: "bridge.identify",
      protocolVersion: PROTOCOL_VERSION,
      clientName: "codex",
      clientVersion: "1.0.0",
    });
    expect(registry.list()).toHaveLength(1);
    session.close();
    expect(registry.list()).toHaveLength(0);
  });
});

describe("ConnectionSession tool dispatch", () => {
  it("dispatches a tool message and responds with the same id", async () => {
    const handleTool = vi.fn(async (_m: TransportMessage) => ok({ done: true }));
    const { sent, session } = setup(handleTool);
    const msg: TransportMessage = {
      id: "msg_42",
      version: PROTOCOL_VERSION,
      type: "browser.get_capabilities",
      payload: {},
    };
    session.receive(msg);
    await flush();
    expect(handleTool).toHaveBeenCalledOnce();
    expect(sent.at(-1)).toMatchObject({ id: "msg_42", response: { ok: true } });
  });

  it("ignores a transport response (not expected on this side)", async () => {
    const { sent, session } = setup();
    session.receive(makeResponse("msg_1", ok({})));
    await flush();
    expect(sent).toHaveLength(0);
  });
});
