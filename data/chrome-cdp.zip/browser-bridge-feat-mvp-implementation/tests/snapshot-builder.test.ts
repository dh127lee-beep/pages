import { describe, expect, it } from "vitest";
import {
  buildSnapshot,
  computeRiskHints,
  type RawElement,
} from "../packages/extension/src/content/snapshot-builder.js";

const base = (over: Partial<RawElement>): RawElement => ({
  tag: "input",
  attributes: {},
  visible: true,
  enabled: true,
  ...over,
});

function build(raw: RawElement[], opts: { includeHidden?: boolean } = {}) {
  return buildSnapshot({
    rawElements: raw,
    snapshotId: "snap_1",
    pageId: "page_1",
    url: "https://example.com/",
    title: "Example",
    capturedAt: "2026-01-01T00:00:00.000Z",
    includeHidden: opts.includeHidden,
  });
}

describe("buildSnapshot", () => {
  it("assigns snapshot-local uids in order", () => {
    const { snapshot } = build([base({ name: "a" }), base({ name: "b" })]);
    expect(snapshot.elements.map((e) => e.uid)).toEqual(["snap_1_0", "snap_1_1"]);
    expect(snapshot.source).toBe("untrusted_page");
  });

  it("redacts password values", () => {
    const { snapshot } = build([base({ type: "password", isPassword: true, value: "hunter2" })]);
    expect(snapshot.elements[0]).toMatchObject({ valueRedacted: true });
    expect(snapshot.elements[0]!.value).toBeUndefined();
    expect(snapshot.elements[0]!.riskHints).toContain("password");
  });

  it("excludes hidden elements by default and never exposes their value", () => {
    const raw = [base({ name: "visible", value: "ok" }), base({ name: "secret", isHidden: true, value: "x" })];
    const def = build(raw);
    expect(def.snapshot.elements).toHaveLength(1);

    const withHidden = build(raw, { includeHidden: true });
    expect(withHidden.snapshot.elements).toHaveLength(2);
    const hidden = withHidden.snapshot.elements.find((e) => e.name === "secret");
    expect(hidden?.value).toBeUndefined();
  });

  it("keeps the includedIndices mapping aligned", () => {
    const { includedIndices } = build([base({ isHidden: true }), base({ name: "keep" })]);
    expect(includedIndices).toEqual([1]);
  });

  it("exposes non-sensitive input values", () => {
    const { snapshot } = build([base({ tag: "input", type: "text", value: "hello" })]);
    expect(snapshot.elements[0]!.value).toBe("hello");
  });

  it("truncates at maxElements", () => {
    const raw = Array.from({ length: 5 }, (_, i) => base({ name: `e${i}` }));
    const { snapshot } = buildSnapshot({
      rawElements: raw,
      snapshotId: "snap_1",
      pageId: "page_1",
      url: "u",
      title: "t",
      capturedAt: "c",
      maxElements: 2,
    });
    expect(snapshot.elements).toHaveLength(2);
    expect(snapshot.truncated).toBe(true);
  });
});

describe("computeRiskHints", () => {
  it("flags upload, submit, payment", () => {
    expect(computeRiskHints(base({ type: "file" }))).toContain("upload");
    expect(computeRiskHints(base({ tag: "button", type: "submit" }))).toContain("submit");
    expect(computeRiskHints(base({ tag: "input", attributes: { name: "card_number", autocomplete: "cc-number" } }))).toContain(
      "payment",
    );
  });
});
