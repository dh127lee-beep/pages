import { afterEach, describe, expect, it } from "vitest";
import WebSocket from "ws";
import { PROTOCOL_VERSION, type ToolResponse } from "@browser-bridge/shared-protocol";
import { DevWsServer } from "@browser-bridge/agent-adapter";
import { ConnectionRegistry } from "../packages/extension/src/background/connection-registry.js";
import { ConnectionSession } from "../packages/extension/src/bridge/connection-session.js";
import { makeBridge } from "./make-bridge.js";

/**
 * End-to-end: a real loopback WebSocket carries the protocol between the adapter
 * (DevWsServer, the RPC client) and a real Bridge wired through ConnectionSession
 * (the extension side, with fake browser ports).
 */
describe("E2E: adapter <-> bridge over a real socket", () => {
  let server: DevWsServer | undefined;
  let ws: WebSocket | undefined;

  afterEach(async () => {
    ws?.close();
    await server?.stop();
    server = undefined;
    ws = undefined;
  });

  async function connect() {
    const { bridge } = makeBridge();
    const registry = new ConnectionRegistry();

    let resolveConnected!: () => void;
    const connected = new Promise<void>((r) => (resolveConnected = r));

    // Resolve when the adapter (not just the extension) has processed welcome.
    server = new DevWsServer({ port: 0, clientName: "codex", onConnected: () => resolveConnected() });
    const { port } = await server.start();

    ws = new WebSocket(`ws://127.0.0.1:${port}`);
    let session: ConnectionSession | undefined;
    ws.on("open", () => {
      const socket = ws!;
      session = new ConnectionSession((m) => socket.send(JSON.stringify(m)), {
        registry,
        handleTool: (message, ctx) => bridge.handleMessage(message, ctx),
        protocolVersion: PROTOCOL_VERSION,
        extensionVersion: "0.1.0",
      });
      session.start();
    });
    ws.on("message", (data) => session?.receive(JSON.parse(data.toString())));

    await connected;
    return server;
  }

  const expectOk = (res: ToolResponse) => {
    expect(res.ok).toBe(true);
    return res as Extract<ToolResponse, { ok: true }>;
  };

  it("runs a full agent flow and a second session", async () => {
    const adapter = await connect();

    // capabilities
    expectOk(await adapter.request("browser.get_capabilities"));

    // start a session
    const started = expectOk(await adapter.request("browser.start_session", { mode: "extension-tab", clientName: "codex" }));
    const sid = (started.result as { sessionId: string }).sessionId;
    expect(sid).toMatch(/^sess_/);

    // open a page -> materializes the tab group
    const page = expectOk(await adapter.request("browser.new_page", { url: "https://example.com/" }, { sessionId: sid }));
    const pid = (page.result as { pageId: string }).pageId;

    const detail = expectOk(await adapter.request("browser.get_session", {}, { sessionId: sid }));
    expect((detail.result as { tabGroup: { state: string } }).tabGroup.state).toBe("materialized");

    // observe -> act -> capture -> read
    expectOk(await adapter.request("browser.take_snapshot", {}, { sessionId: sid, pageId: pid }));
    expectOk(await adapter.request("browser.click", { uid: "snap_x_0" }, { sessionId: sid, pageId: pid }));
    const shot = expectOk(await adapter.request("browser.take_screenshot", {}, { sessionId: sid, pageId: pid }));
    expect((shot.result as { kind: string }).kind).toBe("screenshot");
    expectOk(await adapter.request("browser.list_console_messages", {}, { sessionId: sid, pageId: pid }));

    // second session for the same agent (multi-session)
    const second = expectOk(await adapter.request("browser.start_session", { mode: "extension-tab", clientName: "codex" }));
    const sid2 = (second.result as { sessionId: string }).sessionId;
    const list = expectOk(await adapter.request("browser.list_sessions"));
    expect((list.result as Array<{ sessionId: string }>).map((s) => s.sessionId)).toEqual(
      expect.arrayContaining([sid, sid2]),
    );

    // end the first session -> finalized, group closed
    const ended = expectOk(await adapter.request("browser.end_session", {}, { sessionId: sid }));
    expect((ended.result as { status: string }).status).toBe("finalized");
  });
});
