import { describe, expect, it } from "vitest";
import { agentIdFromClientName, type StartSessionInput } from "@browser-bridge/shared-protocol";
import { ArtifactRegistry } from "../packages/extension/src/background/artifacts.js";
import { PageManager } from "../packages/extension/src/background/page-manager.js";
import { ScreenshotManager } from "../packages/extension/src/background/screenshot-manager.js";
import { SessionManager } from "../packages/extension/src/background/session-manager.js";
import { SnapshotManager } from "../packages/extension/src/background/snapshot-manager.js";
import { FakeTabsPort } from "./fake-tabs-port.js";
import { FakeContentMessenger, FakeScreenshotPort } from "./make-bridge.js";

const input: StartSessionInput = { mode: "extension-tab", clientName: "codex" };
const owner = { agentId: agentIdFromClientName("codex"), clientName: "codex" };

async function setup() {
  const sessions = new SessionManager();
  const tabs = new FakeTabsPort();
  const pages = new PageManager(tabs, sessions);
  const session = await sessions.create(owner, input);
  const page = await pages.newPage(session, "https://example.com/", "https://example.com");
  return { sessions, tabs, pages, session, page };
}

describe("SnapshotManager", () => {
  it("injects, snapshots, and records latestSnapshotId", async () => {
    const { pages, page } = await setup();
    const messenger = new FakeContentMessenger();
    const mgr = new SnapshotManager(messenger, pages);

    const snapshot = await mgr.snapshot(page, {});
    expect(snapshot.elements.length).toBeGreaterThan(0);
    expect(messenger.injected).toContain(page.chromeTabId);
    expect(pages.isSnapshotCurrent(page.pageId, snapshot.snapshotId)).toBe(true);
  });
});

describe("ScreenshotManager", () => {
  it("captures and stores an artifact, returning metadata only", async () => {
    const { page } = await setup();
    const port = new FakeScreenshotPort();
    const artifacts = new ArtifactRegistry();
    const mgr = new ScreenshotManager(port, artifacts);

    const meta = await mgr.capture({ tabGroupId: page.tabGroupId }, page);
    expect(meta.kind).toBe("screenshot");
    expect(meta.contentType).toBe("image/png");
    expect(meta.byteLength).toBeGreaterThan(0);
    expect(meta.sessionId).toBe(page.sessionId);
    expect(meta.pageId).toBe(page.pageId);
    expect(port.calls).toBe(1);
    expect(artifacts.size).toBe(1);
  });
});
