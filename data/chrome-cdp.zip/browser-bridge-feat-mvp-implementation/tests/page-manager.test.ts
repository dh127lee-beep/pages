import { describe, expect, it } from "vitest";
import { ToolError, agentIdFromClientName, type StartSessionInput } from "@browser-bridge/shared-protocol";
import { PageManager } from "../packages/extension/src/background/page-manager.js";
import { SessionManager } from "../packages/extension/src/background/session-manager.js";
import { FakeTabsPort } from "./fake-tabs-port.js";

const input: StartSessionInput = { mode: "extension-tab", clientName: "codex", tabScope: "active-tab" };
const owner = { agentId: agentIdFromClientName("codex"), clientName: "codex" };

async function setup() {
  const sessions = new SessionManager();
  const tabs = new FakeTabsPort();
  const pages = new PageManager(tabs, sessions);
  const session = await sessions.create(owner, input);
  return { sessions, tabs, pages, session };
}

describe("PageManager.newPage", () => {
  it("creates a tab and materializes the session tab group", async () => {
    const { tabs, pages, sessions, session } = await setup();
    const page = await pages.newPage(session, "https://example.com/", "https://example.com");

    expect(page.createdByAgent).toBe(true);
    expect(page.tabGroupId).toBeDefined();
    expect(tabs.tabs.has(page.chromeTabId)).toBe(true);

    const fresh = sessions.get(session.sessionId)!;
    expect(fresh.tabGroup.state).toBe("materialized");
    expect(fresh.tabGroup.tabGroupId).toBe(page.tabGroupId);
    expect(fresh.pageIds).toContain(page.pageId);
  });

  it("reuses the same group for subsequent pages", async () => {
    const { pages, session } = await setup();
    const a = await pages.newPage(session, "https://a.com/", "https://a.com");
    const b = await pages.newPage(session, "https://b.com/", "https://b.com");
    expect(a.tabGroupId).toBe(b.tabGroupId);
  });
});

describe("PageManager.claimTab", () => {
  it("claims the active tab into the session group", async () => {
    const { tabs, pages, session } = await setup();
    tabs.setActiveTab({ tabId: 5, url: "https://docs.example.com/x", title: "Docs" });
    const page = await pages.claimTab(session, { strategy: "active-tab" });
    expect(page.claimedFromUser).toBe(true);
    expect(page.chromeTabId).toBe(5);
    expect(page.tabGroupId).toBeDefined();
  });

  it("rejects a tab already leased by another session", async () => {
    const { tabs, pages, sessions, session } = await setup();
    tabs.setActiveTab({ tabId: 7, url: "https://x.com/", title: "X" });
    await pages.claimTab(session, { strategy: "active-tab" });

    const other = await sessions.create({ agentId: agentIdFromClientName("cursor"), clientName: "cursor" }, input);
    tabs.setActiveTab({ tabId: 7, url: "https://x.com/", title: "X" });
    await expect(pages.claimTab(other, { strategy: "active-tab" })).rejects.toMatchObject({
      code: "TAB_ALREADY_LEASED",
    });
  });

  it("preserves the existing group when asked", async () => {
    const { tabs, pages, session } = await setup();
    tabs.setActiveTab({ tabId: 9, url: "https://y.com/", title: "Y" });
    const page = await pages.claimTab(session, { strategy: "active-tab", preserveExistingGroup: true });
    expect(page.tabGroupId).toBeUndefined();
  });

  it("throws when there is no active tab", async () => {
    const { pages, session } = await setup();
    await expect(pages.claimTab(session, { strategy: "active-tab" })).rejects.toBeInstanceOf(ToolError);
  });
});

describe("PageManager.release / end / onTabRemoved", () => {
  it("release drops the lease without closing the tab", async () => {
    const { tabs, pages, session } = await setup();
    const page = await pages.newPage(session, "https://a.com/", "https://a.com");
    await pages.release(session, page.pageId);
    expect(pages.get(page.pageId)).toBeUndefined();
    expect(pages.isTabLeased(page.chromeTabId)).toBe(false);
    expect(tabs.closed).not.toContain(page.chromeTabId);
  });

  it("closeSessionPages closes agent tabs but leaves claimed tabs open", async () => {
    const { tabs, pages, session } = await setup();
    const created = await pages.newPage(session, "https://a.com/", "https://a.com");
    tabs.setActiveTab({ tabId: 42, url: "https://b.com/", title: "B" });
    const claimed = await pages.claimTab(session, { strategy: "active-tab" });

    await pages.closeSessionPages(session);
    expect(tabs.closed).toContain(created.chromeTabId);
    expect(tabs.closed).not.toContain(claimed.chromeTabId);
    expect(pages.list(session.sessionId)).toHaveLength(0);
  });

  it("onTabRemoved cleans up the lease", async () => {
    const { pages, sessions, session } = await setup();
    const page = await pages.newPage(session, "https://a.com/", "https://a.com");
    await pages.onTabRemoved(page.chromeTabId);
    expect(pages.get(page.pageId)).toBeUndefined();
    expect(sessions.get(session.sessionId)!.pageIds).not.toContain(page.pageId);
  });
});
