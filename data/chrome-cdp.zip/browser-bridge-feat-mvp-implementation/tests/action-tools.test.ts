import { describe, expect, it } from "vitest";
import { PROTOCOL_VERSION, agentIdFromClientName, newConnectionId } from "@browser-bridge/shared-protocol";
import type { Bridge } from "../packages/extension/src/background/bridge.js";
import type { ToolContext } from "../packages/extension/src/background/context.js";
import { makeBridge } from "./make-bridge.js";

function ctxFor(clientName: string): ToolContext {
  return { agentId: agentIdFromClientName(clientName), connectionId: newConnectionId(), clientName };
}

const msg = (type: string, payload: unknown = {}, sessionId?: string, pageId?: string) => ({
  id: "msg_1",
  version: PROTOCOL_VERSION,
  type,
  ...(sessionId ? { sessionId } : {}),
  ...(pageId ? { pageId } : {}),
  payload,
});

async function startWithSnapshot(bridge: Bridge, ctx: ToolContext) {
  const s = await bridge.handleMessage(msg("browser.start_session", { mode: "extension-tab", clientName: ctx.clientName }), ctx);
  const sid = s.ok ? s.sessionId! : "";
  const p = await bridge.handleMessage(msg("browser.new_page", { url: "https://example.com/" }, sid), ctx);
  const pid = p.ok ? p.pageId! : "";
  const snap = await bridge.handleMessage(msg("browser.take_snapshot", {}, sid, pid), ctx);
  const snapshotId = snap.ok ? (snap.result as { snapshotId: string }).snapshotId : "";
  return { sid, pid, snapshotId };
}

const KNOWN_UID = "snap_x_0";

describe("action tools", () => {
  it("click works against a current snapshot uid", async () => {
    const { bridge } = makeBridge();
    const ctx = ctxFor("codex");
    const { sid, pid, snapshotId } = await startWithSnapshot(bridge, ctx);
    const res = await bridge.handleMessage(msg("browser.click", { snapshotId, uid: KNOWN_UID }, sid, pid), ctx);
    expect(res).toMatchObject({ ok: true, result: { url: expect.any(String) } });
  });

  it("rejects a stale snapshot id", async () => {
    const { bridge } = makeBridge();
    const ctx = ctxFor("codex");
    const { sid, pid } = await startWithSnapshot(bridge, ctx);
    const res = await bridge.handleMessage(msg("browser.click", { snapshotId: "snap_old", uid: KNOWN_UID }, sid, pid), ctx);
    expect(res).toMatchObject({ ok: false, error: { code: "SNAPSHOT_STALE" } });
  });

  it("returns ELEMENT_NOT_FOUND for an unknown uid", async () => {
    const { bridge } = makeBridge();
    const ctx = ctxFor("codex");
    const { sid, pid, snapshotId } = await startWithSnapshot(bridge, ctx);
    const res = await bridge.handleMessage(msg("browser.click", { snapshotId, uid: "nope" }, sid, pid), ctx);
    expect(res).toMatchObject({ ok: false, error: { code: "ELEMENT_NOT_FOUND" } });
  });

  it("fill works against a uid", async () => {
    const { bridge } = makeBridge();
    const ctx = ctxFor("codex");
    const { sid, pid, snapshotId } = await startWithSnapshot(bridge, ctx);
    const res = await bridge.handleMessage(
      msg("browser.fill", { snapshotId, uid: KNOWN_UID, value: "hello" }, sid, pid),
      ctx,
    );
    expect(res.ok).toBe(true);
  });

  it("press_key works without a snapshot id", async () => {
    const { bridge } = makeBridge();
    const ctx = ctxFor("codex");
    const { sid, pid } = await startWithSnapshot(bridge, ctx);
    const res = await bridge.handleMessage(msg("browser.press_key", { key: "Enter" }, sid, pid), ctx);
    expect(res.ok).toBe(true);
  });

  it("dispatches the new input tools (hover / click_at / type_text / drag)", async () => {
    const { bridge } = makeBridge();
    const ctx = ctxFor("codex");
    const { sid, pid, snapshotId } = await startWithSnapshot(bridge, ctx);
    const hover = await bridge.handleMessage(msg("browser.hover", { snapshotId, uid: KNOWN_UID }, sid, pid), ctx);
    const clickAt = await bridge.handleMessage(msg("browser.click_at", { x: 10, y: 20 }, sid, pid), ctx);
    const type = await bridge.handleMessage(msg("browser.type_text", { snapshotId, uid: KNOWN_UID, text: "hi" }, sid, pid), ctx);
    const drag = await bridge.handleMessage(msg("browser.drag", { fromUid: KNOWN_UID, toUid: KNOWN_UID }, sid, pid), ctx);
    expect(hover.ok).toBe(true);
    expect(clickAt.ok).toBe(true);
    expect(type.ok).toBe(true);
    expect(drag.ok).toBe(true);
  });

  it("rejects actions on a paused session", async () => {
    const { bridge } = makeBridge();
    const ctx = ctxFor("codex");
    const { sid, pid, snapshotId } = await startWithSnapshot(bridge, ctx);
    await bridge.handleMessage(msg("browser.pause_session", {}, sid), ctx);
    const res = await bridge.handleMessage(msg("browser.click", { snapshotId, uid: KNOWN_UID }, sid, pid), ctx);
    expect(res).toMatchObject({ ok: false, error: { code: "SESSION_PAUSED" } });
  });

  it("rejects actions on a page not leased by the session", async () => {
    const { bridge } = makeBridge();
    const ctx = ctxFor("codex");
    const { sid } = await startWithSnapshot(bridge, ctx);
    const res = await bridge.handleMessage(msg("browser.click", { uid: KNOWN_UID }, sid, "page_bogus"), ctx);
    expect(res).toMatchObject({ ok: false, error: { code: "TAB_NOT_LEASED" } });
  });
});
