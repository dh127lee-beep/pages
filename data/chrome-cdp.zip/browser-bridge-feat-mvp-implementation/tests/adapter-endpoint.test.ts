import { describe, expect, it } from "vitest";
import { AdapterEndpoint, PROTOCOL_VERSION, makeResponse, ok } from "@browser-bridge/shared-protocol";

const hello = (version = PROTOCOL_VERSION) => ({
  type: "bridge.hello",
  protocolVersion: version,
  extensionVersion: "0.1.0",
});

describe("AdapterEndpoint", () => {
  it("replies identify to a compatible hello and becomes ready on welcome", () => {
    const sent: Array<Record<string, unknown>> = [];
    const ep = new AdapterEndpoint((m) => sent.push(m as Record<string, unknown>), { clientName: "codex" });

    ep.handleIncoming(hello());
    expect(sent.at(-1)).toMatchObject({ type: "bridge.identify", clientName: "codex" });

    ep.handleIncoming({ type: "bridge.welcome", protocolVersion: PROTOCOL_VERSION, connectionId: "conn_1" });
    expect(ep.connected).toBe(true);
  });

  it("rejects an incompatible hello", () => {
    const sent: Array<Record<string, unknown>> = [];
    const ep = new AdapterEndpoint((m) => sent.push(m as Record<string, unknown>), { clientName: "codex" });
    ep.handleIncoming(hello("9.9.9"));
    expect(sent.at(-1)).toMatchObject({ type: "bridge.reject", code: "VERSION_MISMATCH" });
    expect(ep.connected).toBe(false);
  });

  it("round-trips a tool request once ready", async () => {
    const sent: Array<Record<string, unknown>> = [];
    const ep = new AdapterEndpoint((m) => sent.push(m as Record<string, unknown>), { clientName: "codex" });
    ep.handleIncoming(hello());
    ep.handleIncoming({ type: "bridge.welcome", protocolVersion: PROTOCOL_VERSION, connectionId: "conn_1" });

    const p = ep.request("browser.get_capabilities");
    const req = sent.find((m) => m.type === "browser.get_capabilities") as { id: string };
    ep.handleIncoming(makeResponse(req.id, ok({ ready: true })));
    await expect(p).resolves.toMatchObject({ ok: true, result: { ready: true } });
  });

  it("returns EXTENSION_NOT_CONNECTED before ready and answers ping", () => {
    const sent: Array<Record<string, unknown>> = [];
    const ep = new AdapterEndpoint((m) => sent.push(m as Record<string, unknown>), { clientName: "codex" });
    ep.handleIncoming({ type: "bridge.ping", nonce: "n1" });
    expect(sent.at(-1)).toMatchObject({ type: "bridge.pong", nonce: "n1" });
    return expect(ep.request("browser.click")).resolves.toMatchObject({
      ok: false,
      error: { code: "EXTENSION_NOT_CONNECTED" },
    });
  });
});
