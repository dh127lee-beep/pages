import { describe, expect, it } from "vitest";
import { PROTOCOL_VERSION, agentIdFromClientName, newConnectionId } from "@browser-bridge/shared-protocol";
import type { ToolContext } from "../packages/extension/src/background/context.js";
import { makeBridge as build } from "./make-bridge.js";

const makeBridge = () => build().bridge;

function ctxFor(clientName: string): ToolContext {
  return { agentId: agentIdFromClientName(clientName), connectionId: newConnectionId(), clientName };
}

const msg = (type: string, payload: unknown = {}, sessionId?: string) => ({
  id: "msg_1",
  version: PROTOCOL_VERSION,
  type,
  ...(sessionId ? { sessionId } : {}),
  payload,
});

const startPayload = { mode: "extension-tab", clientName: "codex", sessionLabel: "qa" };

describe("session tools", () => {
  it("start_session creates a session for the agent", async () => {
    const bridge = makeBridge();
    const res = await bridge.handleMessage(msg("browser.start_session", startPayload), ctxFor("codex"));
    expect(res).toMatchObject({ ok: true, result: { status: "active", clientName: "codex" } });
    if (res.ok) expect(res.sessionId).toMatch(/^sess_/);
  });

  it("start_session without context is rejected", async () => {
    const bridge = makeBridge();
    const res = await bridge.handleMessage(msg("browser.start_session", startPayload), undefined);
    expect(res).toMatchObject({ ok: false, error: { code: "SESSION_NOT_FOUND" } });
  });

  it("start_session with invalid input is rejected", async () => {
    const bridge = makeBridge();
    const res = await bridge.handleMessage(msg("browser.start_session", { mode: "bogus" }), ctxFor("codex"));
    expect(res).toMatchObject({ ok: false, error: { code: "UNSUPPORTED_ACTION" } });
  });

  it("list_sessions returns only the agent's sessions", async () => {
    const bridge = makeBridge();
    await bridge.handleMessage(msg("browser.start_session", startPayload), ctxFor("codex"));
    await bridge.handleMessage(
      msg("browser.start_session", { ...startPayload, clientName: "cursor" }),
      ctxFor("cursor"),
    );
    const res = await bridge.handleMessage(msg("browser.list_sessions"), ctxFor("codex"));
    expect(res.ok && (res.result as unknown[]).length).toBe(1);
  });

  it("get_session rejects a session owned by another agent", async () => {
    const bridge = makeBridge();
    const created = await bridge.handleMessage(msg("browser.start_session", startPayload), ctxFor("codex"));
    const sid = created.ok ? created.sessionId! : "";
    const res = await bridge.handleMessage(msg("browser.get_session", {}, sid), ctxFor("cursor"));
    expect(res).toMatchObject({ ok: false, error: { code: "SESSION_NOT_FOUND" } });
  });

  it("pause then resume toggles status", async () => {
    const bridge = makeBridge();
    const created = await bridge.handleMessage(msg("browser.start_session", startPayload), ctxFor("codex"));
    const sid = created.ok ? created.sessionId! : "";

    const paused = await bridge.handleMessage(msg("browser.pause_session", {}, sid), ctxFor("codex"));
    expect(paused).toMatchObject({ ok: true, result: { status: "paused" } });

    const resumed = await bridge.handleMessage(msg("browser.resume_session", {}, sid), ctxFor("codex"));
    expect(resumed).toMatchObject({ ok: true, result: { status: "active" } });
  });

  it("end_session finalizes and then rejects pause", async () => {
    const bridge = makeBridge();
    const created = await bridge.handleMessage(msg("browser.start_session", startPayload), ctxFor("codex"));
    const sid = created.ok ? created.sessionId! : "";

    const ended = await bridge.handleMessage(msg("browser.end_session", {}, sid), ctxFor("codex"));
    expect(ended).toMatchObject({ ok: true, result: { status: "finalized" } });

    const paused = await bridge.handleMessage(msg("browser.pause_session", {}, sid), ctxFor("codex"));
    expect(paused).toMatchObject({ ok: false, error: { code: "SESSION_FINALIZED" } });
  });

  it("requireActive gates paused sessions for future page actions", async () => {
    const bridge = makeBridge();
    const rec = await bridge.sessions.create({ agentId: agentIdFromClientName("codex"), clientName: "codex" }, {
      mode: "extension-tab",
      clientName: "codex",
    });
    await bridge.sessions.setStatus(rec.sessionId, "paused");
    const gate = bridge.requireActive(bridge.sessions.get(rec.sessionId)!);
    expect(gate).toMatchObject({ ok: false, error: { code: "SESSION_PAUSED" } });
  });
});
