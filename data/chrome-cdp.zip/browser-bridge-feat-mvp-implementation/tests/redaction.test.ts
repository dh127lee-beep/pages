import { describe, expect, it } from "vitest";
import { redactHeaders, redactUrl } from "../packages/extension/src/background/redaction.js";

describe("redactHeaders", () => {
  it("redacts auth/cookie headers and keeps the rest", () => {
    const out = redactHeaders({ Authorization: "Bearer x", Cookie: "a=b", "Content-Type": "application/json" });
    expect(out.Authorization).toBe("[redacted]");
    expect(out.Cookie).toBe("[redacted]");
    expect(out["Content-Type"]).toBe("application/json");
  });
});

describe("redactUrl", () => {
  it("redacts sensitive query params", () => {
    const out = redactUrl("https://x.com/a?token=secret&q=hello&session=123");
    expect(out).toContain("token=%5Bredacted%5D");
    expect(out).toContain("session=%5Bredacted%5D");
    expect(out).toContain("q=hello");
  });

  it("returns the input unchanged when not a URL", () => {
    expect(redactUrl("not a url")).toBe("not a url");
  });
});
