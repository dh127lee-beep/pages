import { describe, expect, it } from "vitest";
import {
  ERROR_CODES,
  PROTOCOL_VERSION,
  TOOL_NAMES,
  isToolName,
  newSessionId,
  ok,
  err,
} from "@browser-bridge/shared-protocol";
import { LocalFsStore } from "@browser-bridge/artifact-store";

describe("shared-protocol skeleton", () => {
  it("exposes a protocol version", () => {
    expect(PROTOCOL_VERSION).toMatch(/^\d+\.\d+\.\d+$/);
  });

  it("lists browser tools", () => {
    expect(TOOL_NAMES).toContain("browser.start_session");
    expect(isToolName("browser.start_session")).toBe(true);
    expect(isToolName("browser.nope")).toBe(false);
  });

  it("declares the spec error codes", () => {
    expect(ERROR_CODES).toContain("TAB_ALREADY_LEASED");
    expect(ERROR_CODES).toContain("UNSUPPORTED_ACTION");
  });

  it("generates prefixed ids", () => {
    expect(newSessionId()).toMatch(/^sess_[0-9a-f]{12}$/);
  });

  it("builds success and error envelopes", () => {
    expect(ok({ value: 1 })).toMatchObject({ ok: true, result: { value: 1 }, warnings: [] });
    expect(err({ code: "POLICY_DENIED", message: "no" })).toMatchObject({ ok: false });
  });
});

describe("artifact-store skeleton", () => {
  it("constructs a local fs store", () => {
    const store = new LocalFsStore(".browser-bridge/artifacts");
    expect(store).toBeInstanceOf(LocalFsStore);
  });
});
