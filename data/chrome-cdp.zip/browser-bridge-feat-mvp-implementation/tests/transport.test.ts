import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { WebSocketTransport } from "../packages/extension/src/bridge/transport.js";
import type { ConnectionSessionDeps } from "../packages/extension/src/bridge/connection-session.js";

/** Minimal stand-in for the browser WebSocket so we can drive state transitions. */
class FakeWebSocket {
  static readonly CONNECTING = 0;
  static readonly OPEN = 1;
  static readonly CLOSING = 2;
  static readonly CLOSED = 3;
  static instances: FakeWebSocket[] = [];

  readyState = FakeWebSocket.CONNECTING;
  onopen: (() => void) | null = null;
  onclose: (() => void) | null = null;
  onerror: (() => void) | null = null;
  onmessage: ((event: unknown) => void) | null = null;

  constructor(public readonly url: string) {
    FakeWebSocket.instances.push(this);
  }
  send(): void {}
  close(): void {
    this.readyState = FakeWebSocket.CLOSED;
    this.onclose?.();
  }
  simulateOpen(): void {
    this.readyState = FakeWebSocket.OPEN;
    this.onopen?.();
  }
}

const makeDeps = (): ConnectionSessionDeps => ({
  registry: {} as ConnectionSessionDeps["registry"],
  handleTool: async () => ({ ok: false, error: { code: "UNSUPPORTED_ACTION", message: "x" } }),
  protocolVersion: "1",
  extensionVersion: "0.1.1",
});

describe("WebSocketTransport.kick", () => {
  beforeEach(() => {
    FakeWebSocket.instances = [];
    (globalThis as { WebSocket?: unknown }).WebSocket = FakeWebSocket;
  });
  afterEach(() => {
    delete (globalThis as { WebSocket?: unknown }).WebSocket;
  });

  it("is a no-op while connecting or open, and reconnects immediately when down", () => {
    const t = new WebSocketTransport({
      url: "ws://127.0.0.1:18470",
      makeSessionDeps: () => makeDeps(),
      minBackoffMs: 1_000,
      maxBackoffMs: 30_000,
    });
    t.start();
    expect(FakeWebSocket.instances.length).toBe(1);
    const first = FakeWebSocket.instances[0]!;

    t.kick(); // CONNECTING -> no new socket
    expect(FakeWebSocket.instances.length).toBe(1);

    first.simulateOpen();
    t.kick(); // OPEN -> no new socket
    expect(FakeWebSocket.instances.length).toBe(1);

    first.close(); // link down: internal backoff timer is scheduled (and lost if the SW sleeps)
    t.kick(); // recovery: reconnect now instead of waiting on the timer
    expect(FakeWebSocket.instances.length).toBe(2);
  });

  it("does nothing after stop()", () => {
    const t = new WebSocketTransport({ url: "ws://127.0.0.1:18470", makeSessionDeps: () => makeDeps() });
    t.start();
    t.stop();
    FakeWebSocket.instances = [];
    t.kick();
    expect(FakeWebSocket.instances.length).toBe(0);
  });
});
