import { describe, expect, it } from "vitest";
import { PROTOCOL_VERSION, agentIdFromClientName, newConnectionId } from "@browser-bridge/shared-protocol";
import type { Bridge } from "../packages/extension/src/background/bridge.js";
import type { ToolContext } from "../packages/extension/src/background/context.js";
import { makeBridge } from "./make-bridge.js";

function ctxFor(clientName: string): ToolContext {
  return { agentId: agentIdFromClientName(clientName), connectionId: newConnectionId(), clientName };
}

const msg = (type: string, payload: unknown = {}, sessionId?: string, pageId?: string) => ({
  id: "msg_1",
  version: PROTOCOL_VERSION,
  type,
  ...(sessionId ? { sessionId } : {}),
  ...(pageId ? { pageId } : {}),
  payload,
});

async function startWithPage(bridge: Bridge, ctx: ToolContext) {
  const s = await bridge.handleMessage(msg("browser.start_session", { mode: "extension-tab", clientName: ctx.clientName }), ctx);
  const sid = s.ok ? s.sessionId! : "";
  const p = await bridge.handleMessage(msg("browser.new_page", { url: "https://example.com/" }, sid), ctx);
  const pid = p.ok ? p.pageId! : "";
  return { sid, pid };
}

describe("snapshot/screenshot tools", () => {
  it("take_snapshot returns elements and records latest snapshot", async () => {
    const { bridge, pages } = makeBridge();
    const ctx = ctxFor("codex");
    const { sid, pid } = await startWithPage(bridge, ctx);

    const res = await bridge.handleMessage(msg("browser.take_snapshot", {}, sid, pid), ctx);
    expect(res.ok).toBe(true);
    if (res.ok) {
      const snap = res.result as { snapshotId: string; elements: unknown[] };
      expect(snap.elements.length).toBeGreaterThan(0);
      expect(res.pageId).toBe(pid);
      expect(pages.isSnapshotCurrent(pid as never, snap.snapshotId)).toBe(true);
    }
  });

  it("take_screenshot returns artifact metadata, not binary", async () => {
    const { bridge } = makeBridge();
    const ctx = ctxFor("codex");
    const { sid, pid } = await startWithPage(bridge, ctx);

    const res = await bridge.handleMessage(msg("browser.take_screenshot", {}, sid, pid), ctx);
    expect(res.ok).toBe(true);
    if (res.ok) {
      expect(res.result).toMatchObject({ kind: "screenshot", contentType: "image/png" });
      expect((res.result as { byteLength: number }).byteLength).toBeGreaterThan(0);
      expect(res.result).not.toHaveProperty("bytes");
    }
  });

  it("rejects a snapshot on a page not leased by the session", async () => {
    const { bridge } = makeBridge();
    const ctx = ctxFor("codex");
    const { sid } = await startWithPage(bridge, ctx);
    const res = await bridge.handleMessage(msg("browser.take_snapshot", {}, sid, "page_bogus"), ctx);
    expect(res).toMatchObject({ ok: false, error: { code: "TAB_NOT_LEASED" } });
  });

  it("rejects observation on a paused session", async () => {
    const { bridge } = makeBridge();
    const ctx = ctxFor("codex");
    const { sid, pid } = await startWithPage(bridge, ctx);
    await bridge.handleMessage(msg("browser.pause_session", {}, sid), ctx);
    const res = await bridge.handleMessage(msg("browser.take_snapshot", {}, sid, pid), ctx);
    expect(res).toMatchObject({ ok: false, error: { code: "SESSION_PAUSED" } });
  });
});
