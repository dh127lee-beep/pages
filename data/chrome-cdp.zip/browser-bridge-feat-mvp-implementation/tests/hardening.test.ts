import { describe, expect, it } from "vitest";
import { PROTOCOL_VERSION, agentIdFromClientName, newConnectionId } from "@browser-bridge/shared-protocol";
import { AuditLog } from "../packages/extension/src/background/audit-log.js";
import type { Bridge } from "../packages/extension/src/background/bridge.js";
import type { ToolContext } from "../packages/extension/src/background/context.js";
import { PageManager } from "../packages/extension/src/background/page-manager.js";
import { SessionManager, type SessionStore, type SessionRecord } from "../packages/extension/src/background/session-manager.js";
import { FakeTabsPort } from "./fake-tabs-port.js";
import { makeBridge } from "./make-bridge.js";

function ctxFor(clientName: string): ToolContext {
  return { agentId: agentIdFromClientName(clientName), connectionId: newConnectionId(), clientName };
}

const msg = (type: string, payload: unknown = {}, sessionId?: string, pageId?: string) => ({
  id: "msg_1",
  version: PROTOCOL_VERSION,
  type,
  ...(sessionId ? { sessionId } : {}),
  ...(pageId ? { pageId } : {}),
  payload,
});

async function start(bridge: Bridge, ctx: ToolContext) {
  const s = await bridge.handleMessage(msg("browser.start_session", { mode: "extension-tab", clientName: ctx.clientName }), ctx);
  return s.ok ? s.sessionId! : "";
}

async function startWithPage(bridge: Bridge, ctx: ToolContext) {
  const sid = await start(bridge, ctx);
  const p = await bridge.handleMessage(msg("browser.new_page", { url: "https://example.com/" }, sid), ctx);
  return { sid, pid: p.ok ? p.pageId! : "" };
}

describe("audit linkage", () => {
  it("records agent/session/page/tabGroup ids and attaches auditId", async () => {
    const h = makeBridge();
    const ctx = ctxFor("codex");
    const { sid, pid } = await startWithPage(h.bridge, ctx);
    const res = await h.bridge.handleMessage(msg("browser.take_snapshot", {}, sid, pid), ctx);
    expect(res.ok && typeof res.auditId).toBe("string");

    const events = h.audit.list();
    const last = events.at(-1)!;
    expect(last).toMatchObject({ type: "browser.take_snapshot", sessionId: sid, pageId: pid, ok: true });
    expect(last.agentId).toBe(agentIdFromClientName("codex"));
    expect(last.clientName).toBe("codex");
    expect(typeof last.tabGroupId).toBe("number");
  });

  it("notifies onRecord and returns recent events newest-first", () => {
    const seen: string[] = [];
    const log = new AuditLog(100, () => 0, (e) => seen.push(e.type));
    log.record({ type: "browser.navigate", ok: true });
    log.record({ type: "browser.click", ok: false, code: "ELEMENT_NOT_FOUND" });

    expect(seen).toEqual(["browser.navigate", "browser.click"]);
    const recent = log.recent(10);
    expect(recent.map((e) => e.type)).toEqual(["browser.click", "browser.navigate"]);
    expect(log.recent(1).map((e) => e.type)).toEqual(["browser.click"]);
  });
});

describe("command queue limit", () => {
  it("rejects commands beyond the per-session limit", async () => {
    const h = makeBridge({ maxPendingPerSession: 1 });
    const ctx = ctxFor("codex");
    const { sid, pid } = await startWithPage(h.bridge, ctx);

    // Fire two without awaiting: the first holds the only slot.
    const p1 = h.bridge.handleMessage(msg("browser.click", { uid: "snap_x_0" }, sid, pid), ctx);
    const p2 = h.bridge.handleMessage(msg("browser.click", { uid: "snap_x_0" }, sid, pid), ctx);
    const [r1, r2] = await Promise.all([p1, p2]);
    const codes = [r1, r2].map((r) => (r.ok ? "ok" : r.error.code));
    expect(codes).toContain("COMMAND_LIMIT_EXCEEDED");
  });
});

describe("idle reaper", () => {
  it("finalizes sessions idle past the threshold", async () => {
    const h = makeBridge();
    const ctx = ctxFor("codex");
    const sid = await start(h.bridge, ctx);
    const created = Date.parse(h.sessions.get(sid as never)!.createdAt);

    const reaped = await h.bridge.reapIdleSessions(1000, created + 5000);
    expect(reaped).toBe(1);
    expect(h.sessions.get(sid as never)!.status).toBe("finalized");
  });
});

describe("empty group cleanup", () => {
  it("finalizes a session when its last tab is closed", async () => {
    const h = makeBridge();
    const ctx = ctxFor("codex");
    const { sid, pid } = await startWithPage(h.bridge, ctx);
    const tabId = h.pages.get(pid as never)!.chromeTabId;

    await h.pages.onTabRemoved(tabId);
    const record = h.sessions.get(sid as never)!;
    expect(record.status).toBe("finalized");
    expect(record.tabGroup.state).toBe("closed");
  });
});

describe("resume after reconnect", () => {
  it("same clientName resolves to the same agent's sessions", async () => {
    const h = makeBridge();
    const ctx1 = ctxFor("codex");
    const sid = await start(h.bridge, ctx1);

    // New connection, same client name -> new connectionId, same agentId.
    const ctx2 = ctxFor("codex");
    expect(ctx2.connectionId).not.toBe(ctx1.connectionId);
    const list = await h.bridge.handleMessage(msg("browser.list_sessions"), ctx2);
    expect(list.ok && (list.result as Array<{ sessionId: string }>).some((s) => s.sessionId === sid)).toBe(true);
  });
});

describe("service worker rehydration", () => {
  it("restores sessions and pages from the stores", async () => {
    const sessionRecords: SessionRecord[] = [];
    const store: SessionStore = {
      async load() {
        return sessionRecords;
      },
      async save(records) {
        sessionRecords.splice(0, sessionRecords.length, ...records);
      },
    };
    const sessions = new SessionManager(store);
    const pages = new PageManager(new FakeTabsPort(), sessions);
    const session = await sessions.create({ agentId: agentIdFromClientName("codex"), clientName: "codex" }, {
      mode: "extension-tab",
      clientName: "codex",
    });
    await pages.newPage(session, "https://example.com/", "https://example.com");

    // Simulate a service worker restart: fresh manager from the same store.
    const restored = new SessionManager(store);
    await restored.hydrate();
    expect(restored.get(session.sessionId)?.pageIds.length).toBe(1);
  });
});
