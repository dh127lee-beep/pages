import { PROTOCOL_VERSION, type Capabilities } from "@browser-bridge/shared-protocol";
import { ActionManager } from "../packages/extension/src/background/action-manager.js";
import { AuditLog } from "../packages/extension/src/background/audit-log.js";
import { Bridge } from "../packages/extension/src/background/bridge.js";
import { ArtifactRegistry } from "../packages/extension/src/background/artifacts.js";
import { DebuggerManager } from "../packages/extension/src/background/debugger-manager.js";
import type { DebuggerEventListener, DebuggerPort } from "../packages/extension/src/background/debugger-port.js";
import { PageManager } from "../packages/extension/src/background/page-manager.js";
import { ScreenshotManager, type ScreenshotPort } from "../packages/extension/src/background/screenshot-manager.js";
import { SessionManager } from "../packages/extension/src/background/session-manager.js";
import { SnapshotManager, type ContentMessenger } from "../packages/extension/src/background/snapshot-manager.js";
import { buildSnapshot, type RawElement } from "../packages/extension/src/content/snapshot-builder.js";
import { FakeTabsPort } from "./fake-tabs-port.js";

export const DEFAULT_CAPS: Capabilities = {
  protocolVersion: PROTOCOL_VERSION,
  extensionVersion: "0.1.0",
  backends: ["extension-tab", "extension-debugger"],
  nativeHostAvailable: false,
  debuggerPermission: true,
  tabGroupsPermission: true,
};

/** Fake content messenger that builds a snapshot from canned raw elements. */
export class FakeContentMessenger implements ContentMessenger {
  raw: RawElement[] = [
    { tag: "button", name: "Submit", type: "submit", attributes: { type: "submit" }, visible: true, enabled: true },
  ];
  readonly injected: number[] = [];

  async ensureInjected(tabId: number): Promise<void> {
    this.injected.push(tabId);
  }

  async request(_tabId: number, message: unknown): Promise<unknown> {
    const m = message as { type: string; snapshotId?: string; pageId?: string; includeHidden?: boolean; uid?: string };
    if (m.type === "bb.snapshot") {
      const { snapshot } = buildSnapshot({
        rawElements: this.raw,
        snapshotId: String(m.snapshotId),
        pageId: String(m.pageId),
        url: "https://example.com/",
        title: "Example",
        capturedAt: "2026-01-01T00:00:00.000Z",
        includeHidden: m.includeHidden,
      });
      return { ok: true, snapshot };
    }
    // action message
    if (m.uid !== undefined && !this.knownUids.has(m.uid)) {
      return { ok: false, code: "ELEMENT_NOT_FOUND", error: `uid not found: ${m.uid}` };
    }
    return { ok: true, result: { url: "https://example.com/after", title: "After", navigated: true, riskHints: [] } };
  }

  /** uids the fake page "knows" for action resolution. */
  readonly knownUids = new Set<string>(["snap_x_0"]);
}

export class FakeScreenshotPort implements ScreenshotPort {
  calls = 0;
  async captureVisible(_windowId: number): Promise<string> {
    this.calls++;
    // 1x1 transparent PNG
    return "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+M8AAAMBAQDJ/pLvAAAAAElFTkSuQmCC";
  }
}

/** Fake chrome.debugger port: records commands, lets tests emit CDP events. */
export class FakeDebuggerPort implements DebuggerPort {
  readonly attached = new Set<number>();
  readonly commands: Array<{ tabId: number; method: string; params?: Record<string, unknown> }> = [];
  private listener?: DebuggerEventListener;

  async attach(tabId: number): Promise<void> {
    this.attached.add(tabId);
  }
  async detach(tabId: number): Promise<void> {
    this.attached.delete(tabId);
  }
  async sendCommand(tabId: number, method: string, params?: Record<string, unknown>): Promise<unknown> {
    this.commands.push({ tabId, method, params });
    if (method === "Page.captureScreenshot") {
      return { data: "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+M8AAAMBAQDJ/pLvAAAAAElFTkSuQmCC" };
    }
    if (method === "Runtime.evaluate") {
      return { result: { objectId: "fake-object-id" } };
    }
    return {};
  }
  setEventListener(listener: DebuggerEventListener): void {
    this.listener = listener;
  }
  emit(tabId: number, method: string, params: unknown): void {
    this.listener?.(tabId, method, params);
  }
}

export interface BridgeHarness {
  bridge: Bridge;
  sessions: SessionManager;
  pages: PageManager;
  tabs: FakeTabsPort;
  messenger: FakeContentMessenger;
  screenshotPort: FakeScreenshotPort;
  artifacts: ArtifactRegistry;
  actions: ActionManager;
  debuggerPort: FakeDebuggerPort;
  debuggerManager: DebuggerManager;
  audit: AuditLog;
}

export function makeBridge(opts?: {
  caps?: Capabilities;
  tabs?: FakeTabsPort;
  messenger?: FakeContentMessenger;
  screenshot?: FakeScreenshotPort;
  maxPendingPerSession?: number;
}): BridgeHarness {
  const sessions = new SessionManager();
  const tabs = opts?.tabs ?? new FakeTabsPort();
  const pages = new PageManager(tabs, sessions);
  const messenger = opts?.messenger ?? new FakeContentMessenger();
  const snapshots = new SnapshotManager(messenger, pages);
  const screenshotPort = opts?.screenshot ?? new FakeScreenshotPort();
  const artifacts = new ArtifactRegistry();
  const screenshots = new ScreenshotManager(screenshotPort, artifacts);
  const actions = new ActionManager(messenger, pages, snapshots);
  const debuggerPort = new FakeDebuggerPort();
  const debuggerManager = new DebuggerManager(debuggerPort, artifacts);
  const audit = new AuditLog();
  const caps = opts?.caps ?? DEFAULT_CAPS;
  const bridge = new Bridge({
    capabilities: { get: async () => caps },
    sessions,
    pages,
    snapshots,
    screenshots,
    actions,
    debugger: debuggerManager,
    audit,
    maxPendingPerSession: opts?.maxPendingPerSession,
  });
  return { bridge, sessions, pages, tabs, messenger, screenshotPort, artifacts, actions, debuggerPort, debuggerManager, audit };
}
