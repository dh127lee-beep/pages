import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import {
  RpcClient,
  isProtocolCompatible,
  makeResponse,
  ok,
  type TransportMessage,
} from "@browser-bridge/shared-protocol";

describe("RpcClient", () => {
  beforeEach(() => vi.useFakeTimers());
  afterEach(() => vi.useRealTimers());

  it("matches a response to its request by id", async () => {
    const sent: TransportMessage[] = [];
    const rpc = new RpcClient((m) => sent.push(m), 1000);

    const p = rpc.request("browser.get_capabilities");
    expect(sent).toHaveLength(1);
    const id = sent[0]!.id;

    rpc.handleResponse(makeResponse(id, ok({ ping: "pong" })));
    const res = await p;
    expect(res).toMatchObject({ ok: true, result: { ping: "pong" } });
    expect(rpc.inFlight).toBe(0);
  });

  it("times out with ACTION_TIMEOUT", async () => {
    const rpc = new RpcClient(() => {}, 5000);
    const p = rpc.request("browser.click");
    vi.advanceTimersByTime(5000);
    const res = await p;
    expect(res).toMatchObject({ ok: false, error: { code: "ACTION_TIMEOUT" } });
  });

  it("ignores an unmatched response", () => {
    const rpc = new RpcClient(() => {}, 1000);
    expect(rpc.handleResponse(makeResponse("msg_does_not_exist", ok({})))).toBe(false);
  });

  it("rejectAll settles in-flight requests with TRANSPORT_UNAVAILABLE", async () => {
    const rpc = new RpcClient(() => {}, 10_000);
    const p = rpc.request("browser.take_snapshot");
    rpc.rejectAll();
    const res = await p;
    expect(res).toMatchObject({ ok: false, error: { code: "TRANSPORT_UNAVAILABLE" } });
    expect(rpc.inFlight).toBe(0);
  });
});

describe("isProtocolCompatible", () => {
  it("accepts identical 0.x minor", () => {
    expect(isProtocolCompatible("0.1.0", "0.1.9")).toBe(true);
  });
  it("rejects different 0.x minor (breaking)", () => {
    expect(isProtocolCompatible("0.1.0", "0.2.0")).toBe(false);
  });
  it("rejects different major", () => {
    expect(isProtocolCompatible("1.0.0", "2.0.0")).toBe(false);
  });
  it("rejects malformed versions", () => {
    expect(isProtocolCompatible("nope", "0.1.0")).toBe(false);
  });
});
