import { describe, expect, it } from "vitest";
import { agentIdFromClientName, type StartSessionInput } from "@browser-bridge/shared-protocol";
import { ActionManager } from "../packages/extension/src/background/action-manager.js";
import { PageManager } from "../packages/extension/src/background/page-manager.js";
import { SessionManager } from "../packages/extension/src/background/session-manager.js";
import { SnapshotManager, type ContentMessenger } from "../packages/extension/src/background/snapshot-manager.js";
import { FakeTabsPort } from "./fake-tabs-port.js";
import { FakeContentMessenger } from "./make-bridge.js";

const input: StartSessionInput = { mode: "extension-tab", clientName: "codex" };
const owner = { agentId: agentIdFromClientName("codex"), clientName: "codex" };

async function setup(messenger: ContentMessenger = new FakeContentMessenger()) {
  const sessions = new SessionManager();
  const tabs = new FakeTabsPort();
  const pages = new PageManager(tabs, sessions);
  const snapshots = new SnapshotManager(messenger, pages);
  const actions = new ActionManager(messenger, pages, snapshots);
  const session = await sessions.create(owner, input);
  const page = await pages.newPage(session, "https://example.com/", "https://example.com");
  return { sessions, pages, snapshots, actions, page };
}

const delay = (ms: number) => new Promise((r) => setTimeout(r, ms));

describe("ActionManager", () => {
  it("rejects a stale snapshot", async () => {
    const { actions, pages, page } = await setup();
    await pages.setLatestSnapshot(page.pageId, "snap_current");
    await expect(
      actions.run(page, { type: "bb.click", payload: { uid: "snap_x_0" }, snapshotId: "snap_old" }),
    ).rejects.toMatchObject({ code: "SNAPSHOT_STALE" });
  });

  it("allows a current snapshot and returns the action result", async () => {
    const { actions, pages, page } = await setup();
    await pages.setLatestSnapshot(page.pageId, "snap_current");
    const out = await actions.run(page, { type: "bb.click", payload: { uid: "snap_x_0" }, snapshotId: "snap_current" });
    expect(out.result.url).toBeTruthy();
  });

  it("maps a content ELEMENT_NOT_FOUND into a ToolError", async () => {
    const { actions, page } = await setup();
    await expect(actions.run(page, { type: "bb.click", payload: { uid: "unknown" } })).rejects.toMatchObject({
      code: "ELEMENT_NOT_FOUND",
    });
  });

  it("returns a fresh snapshot when includeSnapshot is set", async () => {
    const { actions, page } = await setup();
    const out = await actions.run(page, { type: "bb.click", payload: { uid: "snap_x_0" }, includeSnapshot: true });
    expect(out.snapshot).toBeDefined();
  });

  it("treats a bfcache channel-closed error as a successful navigating action", async () => {
    class FrozenMessenger implements ContentMessenger {
      async ensureInjected(): Promise<void> {}
      async request(): Promise<unknown> {
        throw new Error(
          "The page keeping the extension port is moved into back/forward cache, so the message channel is closed.",
        );
      }
    }
    const { actions, page } = await setup(new FrozenMessenger());
    const out = await actions.run(page, { type: "bb.click", payload: { uid: "snap_x_0" } });
    expect(typeof out.result.url).toBe("string");
  });

  it("rethrows request errors that are not navigation/channel closures", async () => {
    class BoomMessenger implements ContentMessenger {
      async ensureInjected(): Promise<void> {}
      async request(): Promise<unknown> {
        throw new Error("boom");
      }
    }
    const { actions, page } = await setup(new BoomMessenger());
    await expect(actions.run(page, { type: "bb.click", payload: {} })).rejects.toThrow("boom");
  });

  it("serializes commands for the same page", async () => {
    class DelayMessenger implements ContentMessenger {
      active = 0;
      max = 0;
      async ensureInjected(): Promise<void> {}
      async request(): Promise<unknown> {
        this.active++;
        this.max = Math.max(this.max, this.active);
        await delay(5);
        this.active--;
        return { ok: true, result: { url: "u", title: "t" } };
      }
    }
    const messenger = new DelayMessenger();
    const { actions, page } = await setup(messenger);
    await Promise.all([
      actions.run(page, { type: "bb.click", payload: {} }),
      actions.run(page, { type: "bb.click", payload: {} }),
    ]);
    expect(messenger.max).toBe(1);
  });
});
