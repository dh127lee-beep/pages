import { describe, expect, it } from "vitest";
import {
  DEFAULT_HOST_NAME,
  extensionIdFromOrigin,
  generateHostManifest,
} from "../packages/native-host/src/host-manifest.js";

describe("generateHostManifest", () => {
  it("builds a stdio manifest with allowed origins", () => {
    const manifest = generateHostManifest({
      path: "/usr/local/bin/bb-host",
      allowedExtensionIds: ["abcdefghijklmnopabcdefghijklmnop"],
    });
    expect(manifest.name).toBe(DEFAULT_HOST_NAME);
    expect(manifest.type).toBe("stdio");
    expect(manifest.path).toBe("/usr/local/bin/bb-host");
    expect(manifest.allowed_origins).toEqual(["chrome-extension://abcdefghijklmnopabcdefghijklmnop/"]);
  });

  it("throws without any allowed extension id", () => {
    expect(() => generateHostManifest({ path: "/x", allowedExtensionIds: [] })).toThrow();
  });
});

describe("extensionIdFromOrigin", () => {
  it("extracts a valid extension id", () => {
    expect(extensionIdFromOrigin("chrome-extension://abcdefghijklmnopabcdefghijklmnop/")).toBe(
      "abcdefghijklmnopabcdefghijklmnop",
    );
  });
  it("returns undefined for a non-extension origin", () => {
    expect(extensionIdFromOrigin("https://example.com")).toBeUndefined();
  });
});
