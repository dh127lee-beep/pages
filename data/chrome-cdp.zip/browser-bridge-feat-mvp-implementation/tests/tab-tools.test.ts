import { describe, expect, it } from "vitest";
import { PROTOCOL_VERSION, agentIdFromClientName, newConnectionId } from "@browser-bridge/shared-protocol";
import type { Bridge } from "../packages/extension/src/background/bridge.js";
import type { ToolContext } from "../packages/extension/src/background/context.js";
import { makeBridge, type BridgeHarness } from "./make-bridge.js";

function ctxFor(clientName: string): ToolContext {
  return { agentId: agentIdFromClientName(clientName), connectionId: newConnectionId(), clientName };
}

const msg = (type: string, payload: unknown = {}, sessionId?: string, pageId?: string) => ({
  id: "msg_1",
  version: PROTOCOL_VERSION,
  type,
  ...(sessionId ? { sessionId } : {}),
  ...(pageId ? { pageId } : {}),
  payload,
});

async function start(bridge: Bridge, ctx: ToolContext, tabScope = "active-tab") {
  const s = await bridge.handleMessage(msg("browser.start_session", { mode: "extension-tab", clientName: ctx.clientName, tabScope }), ctx);
  return s.ok ? s.sessionId! : "";
}

describe("browser.list_tabs", () => {
  it("lists user tabs with leased flag", async () => {
    const h: BridgeHarness = makeBridge();
    const ctx = ctxFor("codex");
    h.tabs.setActiveTab({ tabId: 21, url: "https://a.com/", title: "A" });
    h.tabs.setActiveTab({ tabId: 22, url: "https://b.com/", title: "B" });

    const res = await h.bridge.handleMessage(msg("browser.list_tabs"), ctx);
    expect(res.ok).toBe(true);
    if (res.ok) {
      const tabs = res.result as Array<{ tabId: number; leased: boolean }>;
      expect(tabs.map((t) => t.tabId)).toEqual(expect.arrayContaining([21, 22]));
      expect(tabs.every((t) => t.leased === false)).toBe(true);
    }
  });
});

describe("browser.claim_tab by id", () => {
  it("claims a specific tab id from list_tabs", async () => {
    const h = makeBridge();
    const ctx = ctxFor("codex");
    const sid = await start(h.bridge, ctx);
    h.tabs.setActiveTab({ tabId: 31, url: "https://c.com/", title: "C" });

    const res = await h.bridge.handleMessage(
      msg("browser.claim_tab", { strategy: "by-id", tabId: 31 }, sid),
      ctx,
    );
    expect(res).toMatchObject({ ok: true, result: { claimedFromUser: true } });

    // now it shows as leased
    const list = await h.bridge.handleMessage(msg("browser.list_tabs"), ctx);
    if (list.ok) {
      const t = (list.result as Array<{ tabId: number; leased: boolean }>).find((x) => x.tabId === 31);
      expect(t?.leased).toBe(true);
    }
  });
});

describe("browser.navigate", () => {
  it("navigates a leased page and invalidates the snapshot", async () => {
    const h = makeBridge();
    const ctx = ctxFor("codex");
    const sid = await start(h.bridge, ctx);
    const p = await h.bridge.handleMessage(msg("browser.new_page", { url: "https://example.com/" }, sid), ctx);
    const pid = p.ok ? p.pageId! : "";
    await h.bridge.handleMessage(msg("browser.take_snapshot", {}, sid, pid), ctx);

    const res = await h.bridge.handleMessage(msg("browser.navigate", { url: "https://example.com/next" }, sid, pid), ctx);
    expect(res).toMatchObject({ ok: true, result: { navigated: true } });
    expect(h.pages.get(pid as never)!.url).toBe("https://example.com/next");
    expect(h.pages.get(pid as never)!.latestSnapshotId).toBeUndefined();
  });

  it("reload uses the reload path and skips domain policy", async () => {
    const h = makeBridge();
    const ctx = ctxFor("codex");
    const s = await h.bridge.handleMessage(
      msg("browser.start_session", { mode: "extension-tab", clientName: "codex", allowedDomains: ["example.com"] }),
      ctx,
    );
    const sid = s.ok ? s.sessionId! : "";
    const p = await h.bridge.handleMessage(msg("browser.new_page", { url: "https://example.com/" }, sid), ctx);
    const pid = p.ok ? p.pageId! : "";
    const tabId = h.pages.get(pid as never)!.chromeTabId;

    const res = await h.bridge.handleMessage(msg("browser.navigate", { url: "x", reload: true }, sid, pid), ctx);
    expect(res.ok).toBe(true);
    expect(h.tabs.reloaded).toContain(tabId);
  });

  it("rejects navigation to a disallowed domain", async () => {
    const h = makeBridge();
    const ctx = ctxFor("codex");
    const s = await h.bridge.handleMessage(
      msg("browser.start_session", { mode: "extension-tab", clientName: "codex", allowedDomains: ["example.com"] }),
      ctx,
    );
    const sid = s.ok ? s.sessionId! : "";
    const p = await h.bridge.handleMessage(msg("browser.new_page", { url: "https://example.com/" }, sid), ctx);
    const pid = p.ok ? p.pageId! : "";

    const res = await h.bridge.handleMessage(msg("browser.navigate", { url: "https://evil.com/" }, sid, pid), ctx);
    expect(res).toMatchObject({ ok: false, error: { code: "POLICY_DENIED" } });
  });
});
