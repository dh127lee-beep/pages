import { describe, expect, it } from "vitest";
import { McpServer, listMcpTools } from "@browser-bridge/agent-adapter";

function harness() {
  const lines: string[] = [];
  const server = new McpServer({ write: (l) => lines.push(l) });
  return { server, lines };
}

describe("McpServer", () => {
  it("responds to initialize", () => {
    const { server, lines } = harness();
    server.handleLine(JSON.stringify({ jsonrpc: "2.0", id: 1, method: "initialize" }));
    const res = JSON.parse(lines[0]!);
    expect(res).toMatchObject({ jsonrpc: "2.0", id: 1 });
    expect(res.result.serverInfo.name).toBe("browser-bridge");
  });

  it("lists the protocol tools", () => {
    const { server, lines } = harness();
    server.handleLine(JSON.stringify({ jsonrpc: "2.0", id: 2, method: "tools/list" }));
    const res = JSON.parse(lines[0]!);
    const names = (res.result.tools as Array<{ name: string }>).map((t) => t.name);
    expect(names).toEqual([...listMcpTools()]);
    expect(names).toContain("browser.start_session");
  });

  it("ignores notifications (no id)", () => {
    const { server, lines } = harness();
    void server.handleLine(JSON.stringify({ jsonrpc: "2.0", method: "initialized" }));
    expect(lines).toHaveLength(0);
  });

  it("lists extra tools and executes them via tools/call", async () => {
    const lines: string[] = [];
    const server = new McpServer({
      write: (l) => lines.push(l),
      tools: [
        {
          name: "echo",
          description: "echoes",
          inputSchema: { type: "object" },
          invoke: async (args) => ({ echoed: args.value }),
        },
      ],
    });

    await server.handleLine(JSON.stringify({ jsonrpc: "2.0", id: 1, method: "tools/list" }));
    const names = (JSON.parse(lines[0]!).result.tools as Array<{ name: string }>).map((t) => t.name);
    expect(names).toContain("echo");
    expect(names).toContain("browser.start_session");

    await server.handleLine(
      JSON.stringify({ jsonrpc: "2.0", id: 2, method: "tools/call", params: { name: "echo", arguments: { value: "hi" } } }),
    );
    const call = JSON.parse(lines[1]!);
    expect(call.result.content[0].text).toBe(JSON.stringify({ echoed: "hi" }));
    expect(call.result.isError).toBe(false);
  });

  it("forwards protocol tools to callTool", async () => {
    const lines: string[] = [];
    const calls: Array<{ name: string; args: unknown }> = [];
    const server = new McpServer({
      write: (l) => lines.push(l),
      callTool: async (name, args) => {
        calls.push({ name, args });
        return { ok: true };
      },
    });
    await server.handleLine(
      JSON.stringify({
        jsonrpc: "2.0",
        id: 3,
        method: "tools/call",
        params: { name: "browser.take_snapshot", arguments: { sessionId: "s", pageId: "p" } },
      }),
    );
    expect(calls).toEqual([{ name: "browser.take_snapshot", args: { sessionId: "s", pageId: "p" } }]);
    expect(JSON.parse(lines[0]!).result.isError).toBe(false);
  });

  it("returns isError for an unknown tool", async () => {
    const { server, lines } = harness();
    await server.handleLine(JSON.stringify({ jsonrpc: "2.0", id: 4, method: "tools/call", params: { name: "nope" } }));
    expect(JSON.parse(lines[0]!).result.isError).toBe(true);
  });
});
