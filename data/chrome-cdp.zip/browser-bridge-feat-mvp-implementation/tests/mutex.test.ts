import { describe, expect, it } from "vitest";
import { Mutex } from "@browser-bridge/shared-protocol";

describe("Mutex", () => {
  it("serializes acquirers in FIFO order", async () => {
    const mutex = new Mutex();
    const order: number[] = [];

    const release1 = await mutex.acquire();
    order.push(1);

    const second = (async () => {
      const release2 = await mutex.acquire();
      order.push(2);
      release2();
    })();

    // Second cannot proceed while the first holds the lock.
    await Promise.resolve();
    expect(order).toEqual([1]);

    release1();
    await second;
    expect(order).toEqual([1, 2]);
  });
});
