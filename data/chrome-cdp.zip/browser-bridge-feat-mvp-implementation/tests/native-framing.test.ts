import { describe, expect, it } from "vitest";
import { FrameDecoder, encodeFrame } from "@browser-bridge/shared-protocol";

describe("native messaging framing", () => {
  it("round-trips a single message", () => {
    const decoder = new FrameDecoder();
    const out = decoder.push(encodeFrame({ hello: "world" }));
    expect(out).toEqual([{ hello: "world" }]);
  });

  it("decodes multiple frames in one chunk", () => {
    const decoder = new FrameDecoder();
    const a = encodeFrame({ n: 1 });
    const b = encodeFrame({ n: 2 });
    const combined = new Uint8Array(a.length + b.length);
    combined.set(a, 0);
    combined.set(b, a.length);
    expect(decoder.push(combined)).toEqual([{ n: 1 }, { n: 2 }]);
  });

  it("waits for a frame split across chunks", () => {
    const decoder = new FrameDecoder();
    const frame = encodeFrame({ msg: "split" });
    expect(decoder.push(frame.subarray(0, 5))).toEqual([]);
    expect(decoder.push(frame.subarray(5))).toEqual([{ msg: "split" }]);
  });
});
