import { describe, expect, it } from "vitest";
import type { RpcRoute, ToolResponse } from "@browser-bridge/shared-protocol";
import type { Cdp, CdpRequester } from "../packages/agent-adapter/src/cdp-tools.js";
import { recipeToCdpTool } from "../packages/agent-adapter/src/recipes.js";
import { makeMcpCallTool } from "../packages/agent-adapter/src/mcp-stdio.js";

function fakeCdp(responder: (method: string, params: Record<string, unknown>) => unknown): {
  cdp: Cdp;
  calls: Array<{ method: string; params: Record<string, unknown> }>;
} {
  const calls: Array<{ method: string; params: Record<string, unknown> }> = [];
  const cdp: Cdp = async (method, params = {}) => {
    calls.push({ method, params });
    return responder(method, params);
  };
  return { cdp, calls };
}

describe("recipeToCdpTool", () => {
  it("templates args + prior step results and extracts the result", async () => {
    const tool = recipeToCdpTool({
      name: "find_node",
      description: "find a node id by selector",
      steps: [
        { method: "DOM.getDocument", params: { depth: 0 } },
        { method: "DOM.querySelector", params: { nodeId: "{{step0.root.nodeId}}", selector: "{{args.selector}}" } },
      ],
      result: "step1.nodeId",
    });
    const { cdp, calls } = fakeCdp((method) =>
      method === "DOM.getDocument" ? { root: { nodeId: 1 } } : { nodeId: 99 },
    );

    const result = await tool.run(cdp, { selector: "#go" });
    expect(result).toBe(99);
    expect(calls[1]).toEqual({ method: "DOM.querySelector", params: { nodeId: 1, selector: "#go" } });
  });

  it("defaults the result to the last step", async () => {
    const tool = recipeToCdpTool({
      name: "metrics",
      description: "layout metrics",
      steps: [{ method: "Page.getLayoutMetrics" }],
    });
    const { cdp } = fakeCdp(() => ({ cssVisualViewport: { clientWidth: 800 } }));
    expect(await tool.run(cdp, {})).toMatchObject({ cssVisualViewport: { clientWidth: 800 } });
  });
});

describe("makeMcpCallTool", () => {
  it("splits routing (sessionId/pageId) from the payload", async () => {
    const seen: Array<{ type: string; payload: unknown; route: RpcRoute }> = [];
    const server: CdpRequester = {
      async request(type, payload, route = {}) {
        seen.push({ type, payload, route });
        return { ok: true, result: { done: true } } as ToolResponse;
      },
    };
    const call = makeMcpCallTool(server);
    const out = await call("browser.take_snapshot", { sessionId: "s", pageId: "p", includeHidden: true });
    expect(out).toMatchObject({ done: true });
    expect(seen[0]).toEqual({
      type: "browser.take_snapshot",
      payload: { includeHidden: true },
      route: { sessionId: "s", pageId: "p" },
    });
  });

  it("throws on an error response", async () => {
    const server: CdpRequester = {
      async request() {
        return { ok: false, error: { code: "TAB_NOT_LEASED", message: "nope" } };
      },
    };
    await expect(makeMcpCallTool(server)("browser.click", { sessionId: "s", pageId: "p" })).rejects.toThrow(/TAB_NOT_LEASED/);
  });
});
