import { afterEach, describe, expect, it } from "vitest";
import WebSocket from "ws";
import { DevWsServer } from "@browser-bridge/agent-adapter";
import { PROTOCOL_VERSION, makeResponse, ok } from "@browser-bridge/shared-protocol";

describe("DevWsServer end-to-end (real loopback socket)", () => {
  let server: DevWsServer | undefined;

  afterEach(async () => {
    await server?.stop();
    server = undefined;
  });

  it("handshakes and round-trips a tool request", async () => {
    let resolveConnected!: () => void;
    const connected = new Promise<void>((r) => (resolveConnected = r));

    server = new DevWsServer({ port: 0, clientName: "test-agent", onConnected: () => resolveConnected() });
    const { port } = await server.start();
    expect(port).toBeGreaterThan(0);

    const ws = new WebSocket(`ws://127.0.0.1:${port}`);
    ws.on("open", () => {
      ws.send(
        JSON.stringify({ type: "bridge.hello", protocolVersion: PROTOCOL_VERSION, extensionVersion: "0.1.0" }),
      );
    });
    ws.on("message", (data) => {
      const msg = JSON.parse(data.toString());
      if (msg.type === "bridge.identify") {
        ws.send(
          JSON.stringify({ type: "bridge.welcome", protocolVersion: PROTOCOL_VERSION, connectionId: "conn_test" }),
        );
      } else if (msg.type === "browser.get_capabilities") {
        ws.send(JSON.stringify(makeResponse(msg.id, ok({ ext: true }))));
      }
    });

    await connected;
    const res = await server.request("browser.get_capabilities");
    expect(res).toMatchObject({ ok: true, result: { ext: true } });
    ws.close();
  });

  it("binds to loopback only", async () => {
    server = new DevWsServer({ port: 0, clientName: "test-agent" });
    await server.start();
    // address host is the bound interface; we requested 127.0.0.1.
    // (Connection from a non-loopback address is not reachable in this test env.)
    expect(server.connected).toBe(false);
  });

  it("returns EXTENSION_NOT_CONNECTED before handshake", async () => {
    server = new DevWsServer({ port: 0, clientName: "test-agent" });
    await server.start();
    const res = await server.request("browser.get_capabilities");
    expect(res).toMatchObject({ ok: false, error: { code: "EXTENSION_NOT_CONNECTED" } });
  });

  it("falls back to the next free port when the base is busy", async () => {
    const first = new DevWsServer({ port: 0, clientName: "a" });
    const { port } = await first.start(); // ephemeral port now occupied

    const second = new DevWsServer({ port, portCount: 4, clientName: "b" });
    const { port: chosen } = await second.start();
    try {
      expect(chosen).toBeGreaterThan(port);
      expect(chosen).toBeLessThanOrEqual(port + 3);
    } finally {
      await first.stop();
      await second.stop();
    }
  });
});
