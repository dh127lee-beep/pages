import { describe, expect, it } from "vitest";
import { agentIdFromClientName, type StartSessionInput } from "@browser-bridge/shared-protocol";
import {
  SessionManager,
  type SessionRecord,
  type SessionStore,
} from "../packages/extension/src/background/session-manager.js";

const input: StartSessionInput = { mode: "extension-tab", clientName: "codex", sessionLabel: "qa" };

function ownerOf(clientName: string) {
  return { agentId: agentIdFromClientName(clientName), clientName };
}

class MemoryStore implements SessionStore {
  records: SessionRecord[] = [];
  async load(): Promise<SessionRecord[]> {
    return this.records;
  }
  async save(records: SessionRecord[]): Promise<void> {
    this.records = records;
  }
}

describe("SessionManager", () => {
  it("creates an active session with a logical tab group", async () => {
    const mgr = new SessionManager();
    const rec = await mgr.create(ownerOf("codex"), input);
    expect(rec.status).toBe("active");
    expect(rec.tabGroup.state).toBe("logical");
    expect(rec.tabGroup.title).toContain("codex");
    expect(rec.sessionId).toMatch(/^sess_/);
  });

  it("isolates sessions by agent", async () => {
    const mgr = new SessionManager();
    await mgr.create(ownerOf("codex"), input);
    await mgr.create(ownerOf("codex"), input);
    await mgr.create(ownerOf("cursor"), { ...input, clientName: "cursor" });

    expect(mgr.list(agentIdFromClientName("codex"))).toHaveLength(2);
    expect(mgr.list(agentIdFromClientName("cursor"))).toHaveLength(1);
    expect(mgr.list()).toHaveLength(3);
  });

  it("assigns a deterministic color per session seed", async () => {
    const mgr = new SessionManager();
    const a = await mgr.create(ownerOf("codex"), input);
    // same seed -> same color via planTabGroup
    expect(a.tabGroup.color).toBeTypeOf("string");
  });

  it("persists through the store and rehydrates", async () => {
    const store = new MemoryStore();
    const mgr = new SessionManager(store);
    const rec = await mgr.create(ownerOf("codex"), input);
    expect(store.records).toHaveLength(1);

    const restored = new SessionManager(store);
    await restored.hydrate();
    expect(restored.get(rec.sessionId)?.sessionId).toBe(rec.sessionId);
  });

  it("updates status and removes", async () => {
    const mgr = new SessionManager();
    const rec = await mgr.create(ownerOf("codex"), input);
    await mgr.setStatus(rec.sessionId, "paused");
    expect(mgr.get(rec.sessionId)?.status).toBe("paused");
    await mgr.remove(rec.sessionId);
    expect(mgr.get(rec.sessionId)).toBeUndefined();
  });
});

describe("agentIdFromClientName", () => {
  it("is deterministic and slugified", () => {
    expect(agentIdFromClientName("Codex CLI")).toBe(agentIdFromClientName("codex cli"));
    expect(agentIdFromClientName("Codex CLI")).toBe("agent_codex-cli");
  });
});
