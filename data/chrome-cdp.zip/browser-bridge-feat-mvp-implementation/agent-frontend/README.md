# Agent Console (agent-frontend)

A web UI to run **multiple browser agents at once** against the Browser Bridge
extension, chat with each one, and watch every **tool call + result** stream live.
It reuses the Python agent in [`agent/`](../agent) (LangGraph deep agent + an
OpenAI-compatible local LLM) — the frontend just hosts, drives, and visualizes them.

```
┌── agent-frontend ──────────────────────────────────────────┐
│  Browser UI (chat + tool timeline + sessions panel)         │
│        │  WebSocket /ws/agents/{id}                          │
│  FastAPI backend ── AgentManager                            │
│        ├─ agent "A"  BridgeServer :18470  ◀── Extension ──▶ Chrome tab group A
│        ├─ agent "B"  BridgeServer :18471  ◀── Extension ──▶ Chrome tab group B
│        └─ …                                                  │
└─────────────────────────────────────────────────────────────┘
```

Each agent hosts its own bridge port (`18470…18479`) with a **unique clientName**,
so sessions stay isolated by agentId / tab group. The Chrome extension auto-connects
to every port in that range → N agents = N independent connections. See
[docs/windows-and-ports.md](../docs/windows-and-ports.md).

## Run

```bash
# 1) deps (the agent's deps + the console's web deps)
pip install -r agent/requirements.txt
pip install -r agent-frontend/backend/requirements.txt

# 2) a local OpenAI-compatible LLM must be serving (vLLM / Ollama / LM Studio / llama.cpp)
#    defaults: OPENAI_BASE_URL=http://localhost:1234/v1  OPENAI_MODEL=gemma-4-31b
export OPENAI_BASE_URL=http://localhost:1234/v1
export OPENAI_MODEL=your-model

# 3) start the console (from the repo root)
python agent-frontend/backend/server.py            # -> http://127.0.0.1:8500

# 4) load the extension (once): chrome://extensions -> Load unpacked -> packages/extension/dist
```

Then in the UI:

1. **Create agent** (give it a unique name, optional start URL / model override).
   A grey dot turns **green** when the extension connects to that agent's port.
2. **Chat**. On the first message the agent opens a Chrome **tab group** and starts
   the observe → act → verify loop. Assistant text streams in; each tool call shows
   as a collapsible card with its **args** and **result**.
3. **Browser sessions** panel (right) lists the tab groups that agent owns
   (`browser.list_sessions`) — create a second agent to see isolation in action.

## Multi-agent / multi-session testing

- **Multiple agents**: create several; each gets its own port + tab group and runs
  independently. Sockets stay open per agent, so they can stream **in parallel** —
  message A, switch to B, both keep going.
- **Sessions**: every agent owns at least one session (its tab group). The sessions
  panel reflects what `browser.list_sessions` returns for that agent's connection.
- Up to **10 agents** (the 18470–18479 port range). Names must be unique.

## Layout

```
agent-frontend/
  backend/
    server.py        FastAPI app: REST (/api/agents…) + WS (/ws/agents/{id}), serves the SPA
    manager.py       AgentManager + AgentInstance (BridgeServer + deep agent + event streaming)
    requirements.txt
  frontend/          vanilla SPA (no build step)
    index.html  app.js  styles.css
```

## Notes

- The agent code, prompts, and bridge tools live in [`agent/`](../agent) — this is a
  thin runner/visualizer on top. Tool cards include the deep agent's built-in tools
  (e.g. `write_todos`) as well as the browser tools.
- Conversation history is kept in-process per agent (captured from the graph's final
  state), so chats are multi-turn within a server run; restarting the server clears it.
- `BB_FRONTEND_PORT` overrides the UI port (default `8500`).
