"""
Agent runtime + manager for the test frontend.

Each *agent instance* hosts its own bridge endpoint (a ``BridgeServer`` bound to a
single dedicated port in 18470..18479). The Chrome extension auto-connects to every
port in that range, so N agents == N independent connections. Sessions stay isolated
because each agent uses a unique ``clientName`` (-> distinct agentId -> own tab group).

A turn is streamed via LangGraph ``astream_events`` so the UI can show the chat tokens
*and* every tool call / result as it happens. Conversation history is kept in-process
(captured from the graph's final state) so turns are multi-turn without a checkpointer.
"""

from __future__ import annotations

import asyncio
from typing import Any, Awaitable, Callable, Optional

from langchain_core.messages import AIMessage, HumanMessage
from langchain_openai import ChatOpenAI
from deepagents import create_deep_agent

from agent.agent import (
    DEFAULT_API_KEY,
    DEFAULT_BASE_URL,
    DEFAULT_MODEL,
    INSTRUCTIONS,
    llm_extra_body,
)
from agent.bridge_client import BridgeError, BridgeServer
from agent.tools import AgentContext, make_tools

# Keep in sync with the extension's scan range (discovery.ts DEFAULT_WS_PORT / COUNT).
BASE_PORT = 18470
PORT_COUNT = 10

Emit = Callable[[dict[str, Any]], Awaitable[None]]


def _content_text(content: Any) -> str:
    if isinstance(content, str):
        return content
    if isinstance(content, list):  # content blocks
        out = []
        for b in content:
            if isinstance(b, dict):
                out.append(b.get("text", "") or "")
            else:
                out.append(str(b))
        return "".join(out)
    return "" if content is None else str(content)


def _stringify(output: Any) -> str:
    if output is None:
        return ""
    if hasattr(output, "content"):
        return _content_text(output.content)
    return _content_text(output)


class AgentInstance:
    """One agent: a bridge endpoint + a deep agent driving a single browser session."""

    def __init__(
        self,
        agent_id: str,
        name: str,
        port: int,
        *,
        start_url: str = "https://example.com/",
        model: Optional[str] = None,
        base_url: Optional[str] = None,
        api_key: Optional[str] = None,
        recursion_limit: int = 80,
        connect_timeout: float = 60.0,
    ) -> None:
        self.id = agent_id
        self.name = name
        self.client_name = name  # unique per agent -> own agentId/tab group
        self.port = port
        self.start_url = start_url
        self.model = model or DEFAULT_MODEL
        self.base_url = base_url or DEFAULT_BASE_URL
        self.api_key = api_key or DEFAULT_API_KEY
        self.recursion_limit = recursion_limit
        self.connect_timeout = connect_timeout

        self.server = BridgeServer(port=port, port_count=1, client_name=self.client_name)
        self.lock = asyncio.Lock()  # serialize turns for this agent
        self.history: list[Any] = []
        self.graph: Any = None
        self.session_id: Optional[str] = None
        self.page_id: Optional[str] = None
        self.tab_group_title: Optional[str] = None

    async def start(self) -> None:
        await self.server.start()
        self.port = self.server.port

    async def stop(self) -> None:
        if self.session_id is not None:
            try:
                await self.server.request("browser.end_session", session_id=self.session_id)
            except Exception:  # noqa: BLE001 - best-effort cleanup
                pass
        await self.server.stop()

    @property
    def connected(self) -> bool:
        return self.server.connected

    async def ensure_ready(self) -> None:
        """Wait for the extension, open the session + first page, build the deep agent."""
        if self.graph is not None:
            return
        await self.server.wait_connected(self.connect_timeout)
        session = await self.server.request(
            "browser.start_session",
            {"mode": "extension-tab", "clientName": self.client_name, "sessionLabel": self.name},
        )
        self.session_id = session["sessionId"]
        self.tab_group_title = session.get("tabGroup", {}).get("title")
        page = await self.server.request("browser.new_page", {"url": self.start_url}, session_id=self.session_id)
        self.page_id = page["pageId"]

        ctx = AgentContext(server=self.server, session_id=self.session_id, page_id=self.page_id)
        llm = ChatOpenAI(model=self.model, base_url=self.base_url, api_key=self.api_key, temperature=0, extra_body=llm_extra_body())
        self.graph = create_deep_agent(model=llm, tools=make_tools(ctx), system_prompt=INSTRUCTIONS)

    async def stream_turn(self, task: str, emit: Emit) -> None:
        """Run one user turn, emitting token / tool_call / tool_result / final_response."""
        input_messages = self.history + [HumanMessage(content=task)]
        final_messages: Optional[list[Any]] = None
        final_answer: Optional[str] = None
        config = {"recursion_limit": self.recursion_limit}

        async for ev in self.graph.astream_events({"messages": input_messages}, version="v2", config=config):
            kind = ev.get("event")
            name = ev.get("name")
            data = ev.get("data") or {}
            run_id = ev.get("run_id")

            # The agent delivers its answer via the final_response tool. Surface its
            # text as a system-style bubble (not a tool card) and end the loop the
            # moment that tool finishes, so the agent stops cleanly.
            if name == "final_response":
                if kind == "on_tool_start":
                    final_answer = str((data.get("input") or {}).get("text", "") or "")
                    await emit({"type": "final_response", "content": final_answer})
                    continue
                if kind == "on_tool_end":
                    break

            if kind == "on_chat_model_stream":
                chunk = data.get("chunk")
                text = _content_text(getattr(chunk, "content", "")) if chunk is not None else ""
                if text:
                    await emit({"type": "token", "run_id": run_id, "content": text})
            elif kind == "on_chat_model_end":
                out = data.get("output")
                await emit({"type": "assistant_message", "run_id": run_id,
                            "content": _content_text(getattr(out, "content", "")) if out is not None else ""})
            elif kind == "on_tool_start":
                await emit({"type": "tool_call", "run_id": run_id, "name": name, "args": data.get("input")})
            elif kind == "on_tool_end":
                await emit({"type": "tool_result", "run_id": run_id, "name": name,
                            "output": _stringify(data.get("output"))})
            elif kind == "on_chain_end":
                out = data.get("output")
                if isinstance(out, dict) and isinstance(out.get("messages"), list) and out["messages"]:
                    final_messages = out["messages"]

        if final_answer is not None:
            # Keep a compact multi-turn memory: prior context + this answer, dropping
            # the intermediate browser tool churn.
            self.history = input_messages + [AIMessage(content=final_answer)]
        else:
            self.history = final_messages if final_messages is not None else input_messages

    async def list_sessions(self) -> list[dict[str, Any]]:
        if not self.server.connected:
            return []
        result = await self.server.request("browser.list_sessions")
        return result if isinstance(result, list) else []

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "clientName": self.client_name,
            "port": self.port,
            "connected": self.connected,
            "model": self.model,
            "baseUrl": self.base_url,
            "startUrl": self.start_url,
            "sessionId": self.session_id,
            "tabGroupTitle": self.tab_group_title,
        }


class AgentManager:
    def __init__(self) -> None:
        self._agents: dict[str, AgentInstance] = {}
        self._seq = 0

    def list(self) -> list[AgentInstance]:
        return list(self._agents.values())

    def get(self, agent_id: str) -> Optional[AgentInstance]:
        return self._agents.get(agent_id)

    def _next_free_port(self) -> int:
        used = {a.port for a in self._agents.values()}
        for port in range(BASE_PORT, BASE_PORT + PORT_COUNT):
            if port not in used:
                return port
        raise RuntimeError(f"no free port in {BASE_PORT}..{BASE_PORT + PORT_COUNT - 1} (max {PORT_COUNT} agents)")

    async def create(self, name: str, **kwargs: Any) -> AgentInstance:
        name = (name or "").strip()
        if not name:
            raise ValueError("agent name is required")
        if any(a.name == name for a in self._agents.values()):
            raise ValueError(f"agent name '{name}' is already in use (names must be unique for session isolation)")
        port = self._next_free_port()
        self._seq += 1
        agent_id = f"agent_{self._seq}"
        agent = AgentInstance(agent_id, name, port, **kwargs)
        await agent.start()
        self._agents[agent_id] = agent
        return agent

    async def remove(self, agent_id: str) -> bool:
        agent = self._agents.pop(agent_id, None)
        if agent is None:
            return False
        await agent.stop()
        return True

    async def shutdown(self) -> None:
        for agent in list(self._agents.values()):
            try:
                await agent.stop()
            except Exception:  # noqa: BLE001
                pass
        self._agents.clear()


__all__ = ["AgentManager", "AgentInstance", "BridgeError", "BASE_PORT", "PORT_COUNT"]
