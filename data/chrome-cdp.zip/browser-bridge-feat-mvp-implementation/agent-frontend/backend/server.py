"""
FastAPI backend for the Browser Bridge agent test frontend.

Run from the repo root:

    pip install -r agent-frontend/backend/requirements.txt   # + agent/requirements.txt
    python agent-frontend/backend/server.py                   # serves http://127.0.0.1:8500

Then open the URL, create one or more agents, and load the Chrome extension. Each
agent hosts a bridge port (18470..); the extension auto-connects to all of them.
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path

# Make the repo root importable so we can reuse the `agent` package, and this dir
# so `manager` imports as a top-level module when run as a script.
_BACKEND_DIR = Path(__file__).resolve().parent
_REPO_ROOT = _BACKEND_DIR.parents[1]
for p in (str(_REPO_ROOT), str(_BACKEND_DIR)):
    if p not in sys.path:
        sys.path.insert(0, p)

import uvicorn  # noqa: E402
from fastapi import FastAPI, WebSocket, WebSocketDisconnect  # noqa: E402
from fastapi.responses import JSONResponse  # noqa: E402
from fastapi.staticfiles import StaticFiles  # noqa: E402

from manager import AgentManager  # noqa: E402
from agent.agent import DEFAULT_BASE_URL, DEFAULT_MODEL  # noqa: E402

FRONTEND_DIR = _REPO_ROOT / "agent-frontend" / "frontend"

app = FastAPI(title="Browser Bridge — Agent Console")
manager = AgentManager()


@app.get("/api/config")
async def get_config() -> dict:
    return {"defaultModel": DEFAULT_MODEL, "defaultBaseUrl": DEFAULT_BASE_URL}


@app.get("/api/agents")
async def list_agents() -> list[dict]:
    return [a.to_dict() for a in manager.list()]


@app.post("/api/agents")
async def create_agent(body: dict) -> JSONResponse:
    try:
        agent = await manager.create(
            name=body.get("name", ""),
            start_url=body.get("startUrl") or "https://example.com/",
            model=body.get("model") or None,
            base_url=body.get("baseUrl") or None,
            api_key=body.get("apiKey") or None,
        )
    except (ValueError, RuntimeError) as exc:
        return JSONResponse({"error": str(exc)}, status_code=400)
    return JSONResponse(agent.to_dict(), status_code=201)


@app.delete("/api/agents/{agent_id}")
async def delete_agent(agent_id: str) -> JSONResponse:
    ok = await manager.remove(agent_id)
    return JSONResponse({"ok": ok}, status_code=200 if ok else 404)


@app.get("/api/agents/{agent_id}/sessions")
async def agent_sessions(agent_id: str) -> JSONResponse:
    agent = manager.get(agent_id)
    if agent is None:
        return JSONResponse({"error": "unknown agent"}, status_code=404)
    try:
        return JSONResponse({"connected": agent.connected, "sessions": await agent.list_sessions()})
    except Exception as exc:  # noqa: BLE001
        return JSONResponse({"connected": agent.connected, "sessions": [], "error": str(exc)})


@app.websocket("/ws/agents/{agent_id}")
async def agent_ws(ws: WebSocket, agent_id: str) -> None:
    await ws.accept()
    agent = manager.get(agent_id)
    if agent is None:
        await ws.send_text(json.dumps({"type": "error", "message": "unknown agent"}))
        await ws.close()
        return

    async def emit(ev: dict) -> None:
        await ws.send_text(json.dumps(ev, default=str))

    await emit({"type": "status", "connected": agent.connected})
    try:
        while True:
            raw = await ws.receive_text()
            try:
                msg = json.loads(raw)
            except json.JSONDecodeError:
                continue
            if msg.get("type") != "user_message":
                continue
            content = (msg.get("content") or "").strip()
            if not content:
                continue

            await emit({"type": "turn_start"})
            try:
                async with agent.lock:
                    await emit({"type": "info", "message": "waiting for the extension to connect…"}) if not agent.connected else None
                    await agent.ensure_ready()
                    await emit({"type": "status", "connected": agent.connected,
                                "sessionId": agent.session_id, "tabGroupTitle": agent.tab_group_title})
                    await agent.stream_turn(content, emit)
                # Loop ended normally: the agent stopped calling tools and produced a
                # final assistant message (already streamed above).
                await emit({"type": "turn_end", "reason": "completed"})
            except Exception as exc:  # noqa: BLE001
                name = type(exc).__name__
                reason = "limit" if "Recursion" in name or "GraphRecursion" in name else "error"
                await emit({"type": "error", "message": f"{name}: {exc}"})
                await emit({"type": "turn_end", "reason": reason})
    except WebSocketDisconnect:
        return


# Static frontend (must be mounted last so /api and /ws take precedence).
app.mount("/", StaticFiles(directory=str(FRONTEND_DIR), html=True), name="frontend")


@app.on_event("shutdown")
async def _shutdown() -> None:
    await manager.shutdown()


def main() -> None:
    port = int(os.environ.get("BB_FRONTEND_PORT", "8500"))
    print(f"Agent console: http://127.0.0.1:{port}", file=sys.stderr)
    uvicorn.run(app, host="127.0.0.1", port=port)


if __name__ == "__main__":
    main()
