"""
Async Browser Bridge client (Python side).

The Chrome MV3 extension cannot listen for connections, so it connects *out* to
an endpoint. This module hosts that endpoint: a loopback WebSocket server that
speaks the bridge protocol (handshake + request/response) to the extension.

Handshake (auto-connect, no token):
  extension -> bridge.hello       (we validate version)
  bridge    -> bridge.identify
  extension -> bridge.welcome     (we mark ready)
Then tool requests flow: we send a transport message, the extension replies with
a transport response matched by ``id``.
"""

from __future__ import annotations

import asyncio
import itertools
import json
from typing import Any, Optional

import websockets

PROTOCOL_VERSION = "0.1.0"


def _compatible(a: str, b: str) -> bool:
    """Major must match; during 0.x the minor is also a breaking boundary."""
    try:
        pa = [int(x) for x in a.split(".")[:2]]
        pb = [int(x) for x in b.split(".")[:2]]
    except ValueError:
        return False
    if pa[0] != pb[0]:
        return False
    if pa[0] == 0:
        return pa[1] == pb[1]
    return True


class BridgeError(Exception):
    def __init__(self, code: str, message: str) -> None:
        super().__init__(f"{code}: {message}")
        self.code = code


class BridgeServer:
    """Loopback endpoint the extension auto-connects to."""

    def __init__(self, port: int = 18470, port_count: int = 10, client_name: str = "langgraph-agent") -> None:
        self.base_port = port
        self.port_count = port_count
        self.port = port  # actual bound port, set in start()
        self.client_name = client_name
        self._ws: Optional[websockets.WebSocketServerProtocol] = None
        self._ready = asyncio.Event()
        self._pending: dict[str, asyncio.Future[dict[str, Any]]] = {}
        self._seq = itertools.count(1)
        self._server: Optional[websockets.WebSocketServer] = None

    async def start(self) -> None:
        """Bind the first free port in [base_port … base_port+port_count-1]."""
        last_error: Optional[OSError] = None
        for port in range(self.base_port, self.base_port + self.port_count):
            try:
                self._server = await websockets.serve(self._handle, "127.0.0.1", port)
                self.port = port
                return
            except OSError as exc:  # address already in use → try the next port
                last_error = exc
        raise last_error or OSError("no free port available")

    async def stop(self) -> None:
        if self._server is not None:
            self._server.close()
            await self._server.wait_closed()

    async def wait_connected(self, timeout: float = 60.0) -> None:
        await asyncio.wait_for(self._ready.wait(), timeout)

    @property
    def connected(self) -> bool:
        return self._ready.is_set()

    async def _handle(self, ws: "websockets.WebSocketServerProtocol") -> None:
        self._ws = ws
        try:
            async for raw in ws:
                await self._on_message(ws, json.loads(raw))
        except websockets.ConnectionClosed:
            pass
        finally:
            self._ws = None
            self._ready.clear()
            for fut in self._pending.values():
                if not fut.done():
                    fut.set_exception(BridgeError("TRANSPORT_UNAVAILABLE", "extension disconnected"))
            self._pending.clear()

    async def _on_message(self, ws: "websockets.WebSocketServerProtocol", msg: dict[str, Any]) -> None:
        kind = msg.get("type")
        if kind == "bridge.hello":
            if not _compatible(str(msg.get("protocolVersion", "")), PROTOCOL_VERSION):
                await ws.send(json.dumps({"type": "bridge.reject", "code": "VERSION_MISMATCH", "message": "incompatible protocol"}))
                return
            await ws.send(json.dumps({
                "type": "bridge.identify",
                "protocolVersion": PROTOCOL_VERSION,
                "clientName": self.client_name,
                "clientVersion": PROTOCOL_VERSION,
            }))
        elif kind == "bridge.welcome":
            self._ready.set()
        elif kind == "bridge.ping":
            await ws.send(json.dumps({"type": "bridge.pong", "nonce": msg.get("nonce")}))
        elif "id" in msg and "response" in msg:
            fut = self._pending.pop(msg["id"], None)
            if fut is not None and not fut.done():
                fut.set_result(msg["response"])

    async def request(
        self,
        tool_type: str,
        payload: Optional[dict[str, Any]] = None,
        *,
        session_id: Optional[str] = None,
        page_id: Optional[str] = None,
        timeout: float = 60.0,
    ) -> Any:
        if self._ws is None:
            raise BridgeError("EXTENSION_NOT_CONNECTED", "no extension is connected")
        msg_id = f"msg_{next(self._seq)}"
        message: dict[str, Any] = {"id": msg_id, "version": PROTOCOL_VERSION, "type": tool_type, "payload": payload or {}}
        if session_id is not None:
            message["sessionId"] = session_id
        if page_id is not None:
            message["pageId"] = page_id

        fut: asyncio.Future[dict[str, Any]] = asyncio.get_event_loop().create_future()
        self._pending[msg_id] = fut
        await self._ws.send(json.dumps(message))
        response = await asyncio.wait_for(fut, timeout)

        if not response.get("ok"):
            err = response.get("error", {})
            raise BridgeError(err.get("code", "UNSUPPORTED_ACTION"), err.get("message", "request failed"))
        return response.get("result")
