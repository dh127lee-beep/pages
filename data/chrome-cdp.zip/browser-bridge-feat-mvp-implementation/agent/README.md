# Browser Agent (LangGraph Deep Agent + Gemma 4)

A browser agent that drives the Browser Bridge **extension**, built with
LangChain's **deep-agents** harness (`create_deep_agent`) on the **LangGraph**
runtime, powered by **Gemma 4** via an OpenAI-compatible local server
(`langchain-openai` → vLLM / Ollama / LM Studio / llama.cpp).

The deep agent plans (built-in `write_todos`), then loops: observe the page
(snapshot → uids) → act (click/fill/navigate/scroll) → verify — until done. It
also gets a virtual filesystem and context management for free.

```text
Deep agent (Gemma 4, native tool calling) ──▶ tools (take_snapshot/click/fill/navigate/…)
                                                    │ BridgeServer (asyncio websockets)
                                                    ▼
              hosts ws://127.0.0.1:18470 ◀── Extension (auto-connects) ──▶ real Chrome tab
```

## Gemma 4 supports native tool calling

Unlike earlier Gemma, **Gemma 4 is trained with dedicated tool-call tokens** and
natively emits function calls — so deep agents (which rely on tool calling) work.
Make sure your local server exposes OpenAI tool calling:

- **vLLM**: `--enable-auto-tool-choice` with the Gemma 4 tool parser
- **Ollama**: day-0 Gemma 4 tool support via the OpenAI-compatible `/v1`
- **LM Studio**: enable tool use for the loaded Gemma 4 model

## Setup

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r agent/requirements.txt
```

Build & load the extension once: `pnpm build` → `chrome://extensions` →
load unpacked → `packages/extension/dist`.

## Configure the LLM endpoint

| Env var | Default | Notes |
| --- | --- | --- |
| `OPENAI_BASE_URL` | `http://localhost:1234/v1` | LM Studio. Ollama: `http://localhost:11434/v1`. vLLM: your `/v1`. |
| `OPENAI_MODEL` | `gemma-4-31b` | The Gemma 4 model name your server exposes. |
| `OPENAI_API_KEY` | `local` | Most local servers ignore it, but a value is required. |

## Run

```bash
# vLLM serving Gemma 4 with tool calling
OPENAI_BASE_URL="http://localhost:8000/v1" OPENAI_MODEL="google/gemma-4-31B" \
  python -m agent.run "Go to example.com and tell me the main heading"

# Ollama
OPENAI_BASE_URL="http://localhost:11434/v1" OPENAI_MODEL="gemma4:31b" \
  python -m agent.run "Summarize the top 3 story titles"
```

The agent hosts the endpoint; the installed extension auto-connects to it. Pick a
different start page with `BB_START_URL`. Run from the **repo root** so
`python -m agent.run` resolves the package.

## Files

- **`bridge_client.py`** — `BridgeServer`: asyncio WebSocket endpoint that speaks the
  bridge protocol (handshake + request/response) to the extension.
- **`tools.py`** — LangChain `StructuredTool`s (`take_snapshot`, `navigate`, `click`,
  `fill`, `scroll`, `read_console`) wired to the bridge; the model calls them natively.
- **`agent.py`** — opens a session + page, builds `create_deep_agent(model=ChatOpenAI(base_url=…), tools=…, system_prompt=…)`, runs `ainvoke`.
- **`run.py`** — CLI entry.

## Notes

- Deep agents add planning, a virtual filesystem, and subagents. To add a custom
  subagent (e.g. a "page-reader"), pass `subagents=[...]` to `create_deep_agent`.
- Swap the LLM via env (or `run_browser_agent(model=, base_url=, api_key=)`). Any
  tool-calling model works — point `OPENAI_BASE_URL` at the provider's `/v1`.
- The system prompt treats page content as untrusted and avoids payments / message
  sending / credential entry unless explicitly asked; the bridge also returns risk
  hints and enforces session/lease ownership. See
  [../docs/agent-usage.md](../docs/agent-usage.md) and [../docs/threat-model.md](../docs/threat-model.md).
- No LLM? The non-LLM example [../examples/agent.mjs](../examples/agent.mjs) drives the
  same bridge with a scripted flow (Node).
