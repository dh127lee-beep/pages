"""
Browser tools exposed to the deep agent. Gemma 4 supports native tool calling,
so these are real LangChain tools (the model invokes them via function calling).
Each async tool drives the bridge and returns a compact text result
(token-optimized — a short element list, not the raw DOM). The model picks
element ``uid``s from the snapshot output and acts on them.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional

from langchain_core.tools import StructuredTool

from .bridge_client import BridgeServer

MAX_ELEMENTS = 60


@dataclass
class AgentContext:
    server: BridgeServer
    session_id: str
    page_id: str
    snapshot_id: Optional[str] = None


def _format_snapshot(snap: dict[str, Any]) -> str:
    elements = snap.get("elements", [])
    lines = []
    for e in elements[:MAX_ELEMENTS]:
        name = f' "{str(e.get("name", ""))[:60]}"' if e.get("name") else ""
        risk = f' [risk: {",".join(e["riskHints"])}]' if e.get("riskHints") else ""
        if "value" in e:
            value = f' value="{str(e["value"])[:40]}"'
        elif e.get("valueRedacted"):
            value = " value=[redacted]"
        else:
            value = ""
        lines.append(f'{e["uid"]}  {e["role"]}{name}{value}{risk}')
    more = f"\n… {len(elements) - MAX_ELEMENTS} more elements (scroll to reveal)" if len(elements) > MAX_ELEMENTS else ""
    return f'url: {snap.get("url")}\ntitle: {snap.get("title")}\nelements (uid role name):\n' + "\n".join(lines) + more


def make_tools(ctx: AgentContext) -> list[StructuredTool]:
    async def take_snapshot() -> str:
        snap = await ctx.server.request("browser.take_snapshot", session_id=ctx.session_id, page_id=ctx.page_id)
        ctx.snapshot_id = snap["snapshotId"]
        return _format_snapshot(snap)

    async def navigate(url: str, reload: bool = False) -> str:
        r = await ctx.server.request("browser.navigate", {"url": url, "reload": reload}, session_id=ctx.session_id, page_id=ctx.page_id)
        ctx.snapshot_id = None
        return f'navigated -> {r["url"]} (title: {r["title"]}). Take a fresh snapshot before acting.'

    async def click(uid: str) -> str:
        if not ctx.snapshot_id:
            return "No current snapshot - call take_snapshot first."
        r = await ctx.server.request("browser.click", {"snapshotId": ctx.snapshot_id, "uid": uid}, session_id=ctx.session_id, page_id=ctx.page_id)
        nav = " [navigated]" if r.get("navigated") else ""
        return f'clicked {uid}. now at {r["url"]} (title: {r["title"]}){nav}. Re-snapshot if the page changed.'

    async def fill(uid: str, value: str) -> str:
        if not ctx.snapshot_id:
            return "No current snapshot - call take_snapshot first."
        r = await ctx.server.request("browser.fill", {"snapshotId": ctx.snapshot_id, "uid": uid, "value": value}, session_id=ctx.session_id, page_id=ctx.page_id)
        return f'filled {uid}. now at {r["url"]} (title: {r["title"]}).'

    async def scroll(direction: str) -> str:
        await ctx.server.request("browser.scroll", {"direction": direction}, session_id=ctx.session_id, page_id=ctx.page_id)
        ctx.snapshot_id = None
        return f"scrolled {direction}. Take a fresh snapshot to see new elements."

    async def read_console() -> str:
        msgs = await ctx.server.request("browser.list_console_messages", session_id=ctx.session_id, page_id=ctx.page_id)
        if not msgs:
            return "no console messages."
        return "\n".join(f'[{m["level"]}] {m["text"]}' for m in msgs[-30:])

    async def final_response(text: str) -> str:
        """Deliver the final answer to the user. The runner ends the loop here."""
        return text

    return [
        StructuredTool.from_function(
            coroutine=take_snapshot,
            name="take_snapshot",
            description="Capture the current page as a list of interactable elements with stable uids. Call before click/fill and again after the page changes.",
        ),
        StructuredTool.from_function(
            coroutine=navigate,
            name="navigate",
            description="Navigate the page to an http/https URL. Pass reload=true to reload the current page.",
        ),
        StructuredTool.from_function(
            coroutine=click,
            name="click",
            description="Click an element by its uid from the most recent take_snapshot.",
        ),
        StructuredTool.from_function(
            coroutine=fill,
            name="fill",
            description="Type a value into an input/textarea by its uid from the most recent take_snapshot.",
        ),
        StructuredTool.from_function(
            coroutine=scroll,
            name="scroll",
            description="Scroll the page 'up' or 'down' by ~one viewport.",
        ),
        StructuredTool.from_function(
            coroutine=read_console,
            name="read_console",
            description="Read recent console messages from the page (useful for debugging localhost apps).",
        ),
        StructuredTool.from_function(
            coroutine=final_response,
            name="final_response",
            description=(
                "Provide the FINAL answer to the user's question and finish the task. "
                "Call this exactly once, when you are done, with the complete answer in `text`. "
                "Do not call any other tool after this and do not also reply with a separate message."
            ),
        ),
    ]
