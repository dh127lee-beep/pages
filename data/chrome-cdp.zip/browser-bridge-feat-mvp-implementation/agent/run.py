"""
CLI entry for the LangGraph browser agent (OpenAI-compatible local LLM).

    OPENAI_BASE_URL=http://localhost:1234/v1 OPENAI_MODEL=your-model \
      python -m agent.run "your task here"

Then load the extension (it auto-connects to ws://127.0.0.1:18470).
"""

from __future__ import annotations

import asyncio
import os
import sys

from .agent import DEFAULT_BASE_URL, DEFAULT_MODEL, run_browser_agent


def main() -> None:
    task = " ".join(sys.argv[1:]).strip() or "Open the page and tell me its main heading."
    start_url = os.environ.get("BB_START_URL", "https://example.com/")
    port = int(os.environ.get("BB_WS_PORT", "18470"))

    print(f"LLM: {DEFAULT_MODEL} @ {DEFAULT_BASE_URL}", file=sys.stderr)
    print("(set OPENAI_BASE_URL / OPENAI_MODEL / OPENAI_API_KEY / BB_WS_PORT as needed)", file=sys.stderr)

    answer = asyncio.run(run_browser_agent(task, start_url=start_url, port=port))
    print(f"\n=== ANSWER ===\n{answer}")


if __name__ == "__main__":
    main()
