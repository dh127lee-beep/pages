"""Claude + LangGraph browser agent that drives the Browser Bridge extension."""
