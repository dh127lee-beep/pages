"""`did you mean "…"?` for commands, options, op names, element ids and sheet names."""

from __future__ import annotations

from typing import Iterable

MAX_SUGGEST_INPUT_CHARS = 64
MAX_SUGGEST_CANDIDATES = 500
MAX_SUGGEST_CANDIDATE_CHARS = 128


def _distance(a: str, b: str) -> int:
    """Optimal-string-alignment distance: one transposition counts as one edit ("blod" ~ "bold")."""
    rows, cols = len(a) + 1, len(b) + 1
    d = [[0] * cols for _ in range(rows)]
    for i in range(rows):
        d[i][0] = i
    for j in range(cols):
        d[0][j] = j
    for i in range(1, rows):
        for j in range(1, cols):
            cost = 0 if a[i - 1] == b[j - 1] else 1
            v = min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + cost)
            if i > 1 and j > 1 and a[i - 1] == b[j - 2] and a[i - 2] == b[j - 1]:
                v = min(v, d[i - 2][j - 2] + 1)
            d[i][j] = v
    return d[-1][-1]


def did_you_mean(value: str, candidates: Iterable[str]) -> str | None:
    """The closest candidate when the typo is small enough to be a typo; None when nothing is near."""
    needle = value.lower()[:MAX_SUGGEST_INPUT_CHARS]
    if not needle:
        return None
    budget = max(2, len(needle) // 3)
    best: tuple[str, int] | None = None
    for scanned, name in enumerate(candidates):
        if scanned >= MAX_SUGGEST_CANDIDATES:
            break
        if len(name) > MAX_SUGGEST_CANDIDATE_CHARS:
            continue
        d = _distance(needle, name.lower())
        if d <= budget and (best is None or d < best[1]):
            best = (name, d)
    return best[0] if best and best[1] > 0 else None


def did_you_mean_hint(value: str, candidates: Iterable[str]) -> str | None:
    guess = did_you_mean(value, candidates)
    return f'did you mean "{guess}"?' if guess else None
