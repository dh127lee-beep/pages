"""Tool specs: the `genoffice mcp` tool list, framework-free.

Each spec names a GenOffice method, carries the original tool description and a JSON Schema for its
parameters. Adapters (deepagents/LangChain, OpenAI function calling, an MCP server) are built from
this list, so every host sees the same names, parameters and envelopes.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any

from .api import GenOffice
from .result import EXIT, GenOfficeError, to_json_error
from .suggest import did_you_mean

READ_THEN_APPLY = "Read the file with the matching *_read tool first: ops target the ids and indexes it lists. "
NO_OVERWRITE = "Refuses to overwrite another existing file unless force=true (only when the user asked to replace it)."

S = {"type": "string"}
B = {"type": "boolean"}
I = {"type": "integer", "minimum": 0}
N = {"type": "number"}
OBJ = {"type": "object"}
ARR = {"type": "array", "items": {"type": "object"}}
JSON_ANY = {"anyOf": [{"type": "array"}, {"type": "object"}]}


def p(schema: dict[str, Any], description: str) -> dict[str, Any]:
    return {**schema, "description": description}


@dataclass
class ToolSpec:
    name: str
    method: str
    description: str
    properties: dict[str, dict[str, Any]] = field(default_factory=dict)
    required: list[str] = field(default_factory=list)
    read_only: bool = False
    # the call reaches the configured cloud provider (search, image, media)
    open_world: bool = False

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": self.properties,
            "required": self.required,
            "additionalProperties": False,
        }


FILE = lambda what="path of the document": p(S, what)  # noqa: E731
OUT_REQ = p(S, "output path (required)")
FORCE = p(B, "overwrite an existing output (only when the user asked to replace it)")
DRY = p(B, "validate the batch without writing")
BEST = p(B, 'apply every op that can apply and write; rejected ops come back in detail.failures with status "partial"')
STOP = p(B, 'apply ops in order up to the first rejection and write what applied (status "partial")')
OUT_APPLY = p(S, "write the result here instead of editing in place")

TOOLS: list[ToolSpec] = [
    ToolSpec(
        "info",
        "info",
        "Metadata and a structure summary of a document (docx, xlsx, pptx, pdf, md, html, csv): page or slide count, sheets, block count, headings, size. Runs locally.",
        {"file": FILE(), "password": p(S, "password of an encrypted PDF")},
        ["file"],
        read_only=True,
    ),
    ToolSpec(
        "convert",
        "convert",
        "Convert a document to another format: pdf→docx (text layer), csv→xlsx, xls/xlsb/ods→xlsx, md→docx/html, docx→html/md, html→docx, xlsx→csv (sheet), and docx/xlsx/pptx/md/html→pdf (needs LibreOffice). Output defaults to the input name with the new extension. "
        + NO_OVERWRITE,
        {
            "file": FILE("path of the source document"),
            "to": p(S, "target format: pdf | docx | xlsx | md | html | csv"),
            "out": p(S, "output path (default: the input's folder and name with the new extension)"),
            "force": FORCE,
            "password": p(S, "password of an encrypted PDF"),
            "sheet": p(S, "xlsx→csv: the sheet to export (default: the active sheet)"),
        },
        ["file", "to"],
    ),
    ToolSpec(
        "create_docx",
        "create_docx",
        "Create a new Word document from Markdown (GFM; headings, lists, tables, images by relative path) or from a restricted-HTML fragment (tags per guide docs). Give exactly one of markdown, html or from. Edits to an existing .docx go through docs_apply instead.",
        {
            "markdown": p(S, "the document as Markdown text"),
            "html": p(S, "the document as a restricted-HTML fragment"),
            "from": p(S, "path of an existing .md or .html file to build from"),
            "out": p(S, "output .docx path (required)"),
            "force": FORCE,
        },
        ["out"],
    ),
    ToolSpec(
        "create_xlsx",
        "create_xlsx",
        'Create a new workbook from data: a 2-D array of cell values, { "sheets": [{ "name", "rows" }] } for several sheets, or a .csv/.json file. Strings starting with "=" are formulas. Give exactly one of data or from. Formatting, charts and more sheets afterwards: sheet_apply.',
        {
            "data": p(JSON_ANY, 'rows as a 2-D array, or { "sheets": [{ "name", "rows" }] }'),
            "from": p(S, "path of a .csv or .json file to build from"),
            "header": p(B, "first row is a header: bold, frozen, with a filter over the range"),
            "decimal": p(S, 'CSV decimal separator, e.g. "," to read 1.234,5 as 1234.5'),
            "out": p(S, "output .xlsx path (required)"),
            "force": FORCE,
        },
        ["out"],
    ),
    ToolSpec(
        "create_pdf",
        "create_pdf",
        "Print a document (md, html, docx, xlsx, pptx) to a new PDF with LibreOffice headless.",
        {"from": p(S, "path of the document to print"), "out": p(S, "output .pdf path (required)"), "force": FORCE},
        ["from", "out"],
    ),
    ToolSpec(
        "create_pptx",
        "create_pptx",
        "Create a .pptx in one call from ops on a blank one-slide deck, or from a deck spec (pages of px-positioned text, shapes and images on a 1280x720 canvas; guide slides spec). This is the path for a short deck (up to about 5 slides) and whenever the user gives concrete content and no design brief: write the ops or the spec directly, then slides_render to look. Set render=true to get the slide PNGs in the same call and audit=true for the geometry findings. The staged deck_start / deck_page / deck_build flow is for longer or design-sensitive presentations a person will present. Give exactly one of ops, spec or spec_dir.",
        {
            "ops": p(ARR, "JSON array of slides ops, the same objects slides_apply takes (guide slides)"),
            "spec": p(JSON_ANY, 'a deck spec object { "pages": [...] } (guide slides spec)'),
            "spec_dir": p(S, "path of a directory of one-page spec files taken in name order (the deck_* tools write one)"),
            "outline": p(S, "path of outline.json to check the pages against"),
            "out": p(S, "output .pptx path (required)"),
            "force": FORCE,
            "render": p(B, "render one PNG per slide after writing (detail.previews); needs LibreOffice"),
            "audit": p(B, "include the geometry audit of the built deck under detail.audit"),
        },
        ["out"],
    ),
    ToolSpec(
        "docs_read",
        "docs_read",
        "Structure and text of a .docx as 0-based blocks (paragraphs, headings, list items, tables, images, charts) with a 200-character preview each; the block indexes are what docs_apply ops target. Flags add comments, styles, sections, fields or header/footer text. Use full for whole block text, range to narrow.",
        {
            "file": FILE("path of the .docx"),
            "range": p(S, 'block range "a-b" (0-based, inclusive)'),
            "html": p(B, "include each block as restricted HTML"),
            "full": p(B, "whole block text, no 200-character clip"),
            "max_chars": p(I, "move the preview clip"),
            "comments": p(B, "comment threads"),
            "revisions": p(B, "tracked changes"),
            "styles": p(B, "paragraph, character and table style ids"),
            "header_footer": p(B, "header/footer text per section"),
            "sections": p(B, "page setup per section with block ranges"),
            "fields": p(B, "fields with their cached results"),
            "notes": p(B, "footnotes / endnotes"),
            "properties": p(B, "core document properties"),
        },
        ["file"],
        read_only=True,
    ),
    ToolSpec(
        "docs_apply",
        "docs_apply",
        "Edit a .docx with a batch of ops (the op reference: guide docs). "
        + READ_THEN_APPLY
        + "Block indexes inside one batch are live: after an insert adds two blocks, later indexes shift by two. Atomic by default: one rejected op leaves the file untouched and comes back with its index and reason; fix that op and resend the whole batch. dry_run validates without writing.",
        {
            "file": FILE("path of the .docx"),
            "ops": p(
                ARR,
                'JSON array of ops, every entry with "op"; target is { "blockIndexes": [n] } or { "nodeType": "docHeading"|"docParagraph"|"docListItem"|"image"|"table", "headingLevel"? }',
            ),
            "track": p(B, "record the batch's edits as tracked changes"),
            "author": p(S, "author name for tracked changes / comments"),
            "dry_run": DRY,
            "best_effort": BEST,
            "stop_on_error": STOP,
            "out": OUT_APPLY,
            "force": FORCE,
        },
        ["file", "ops"],
    ),
    ToolSpec(
        "docs_check",
        "docs_check",
        "Consistency checks on a .docx: fields not evaluated, broken references, missing images, empty headings, heading level skips, placeholder text, open comments; one finding per issue in detail.issues (exit 0 is not 'clean').",
        {"file": FILE("path of the .docx")},
        ["file"],
        read_only=True,
    ),
    ToolSpec(
        "merge",
        "merge",
        "Fill {{key}} placeholders in a .docx, .pptx or .xlsx template with values from a JSON object and write the result to out (nested objects flatten to dotted keys; whitespace inside the braces is tolerated; a whole-cell placeholder in xlsx takes the value type). The result lists used_keys, unused_keys and unresolved_placeholders with their location and reason (no_key; split_placeholder; unreachable_nested); strict makes an unresolved placeholder an error.",
        {
            "file": FILE("path of the template (.docx, .pptx or .xlsx)"),
            "data": p(OBJ, 'the values as a JSON object, e.g. { "name": "Ada", "amount": 12 }'),
            "out": p(S, "output path (required)"),
            "force": FORCE,
            "strict": p(B, "an unresolved placeholder is an error and nothing is written"),
        },
        ["file", "data", "out"],
    ),
    ToolSpec(
        "pdf_read",
        "pdf_read",
        "Text layer of a PDF page by page (1-based page, width_pt/height_pt, text clipped to 4000 characters with truncated: true) plus page count, encrypted flag and title/author/producer metadata. Reads pages 1-20 by default and says how to get the rest: page or range narrows, full reads every page uncapped. Scanned pages come back with empty text.",
        {
            "file": FILE("path of the .pdf"),
            "page": p(I, "one 1-based page"),
            "range": p(S, 'pages "a-b", 1-based'),
            "password": p(S, "password of an encrypted PDF"),
            "full": p(B, "every page, no clip"),
            "max_chars": p(I, "move the per-page clip"),
        },
        ["file"],
        read_only=True,
    ),
    ToolSpec(
        "sheet_read",
        "sheet_read",
        "Cells of one worksheet as raw values with formulas keyed by A1 address, plus sheet features (panes, filter, charts, tables). Defaults to the active sheet and up to 500x100 cells; the result says when it truncated. stats for counts and the sheet list, formats for styling, column widths and row heights, where to list only cells of one kind.",
        {
            "file": FILE("path of the .xlsx"),
            "sheet": p(S, "sheet name (default: the active sheet)"),
            "range": p(S, "A1:D20"),
            "cols": p(S, 'only these columns, e.g. "A,C:E"'),
            "max_rows": p(I, "cap the rows returned"),
            "where": p({"type": "string", "enum": ["formula", "error", "empty", "number", "text"]}, "only cells of one kind, as {ref, value, formula}"),
            "stats": p(B, "counts, used range and the sheet list; no cells"),
            "formats": p(B, "cell formats, column widths (px) and row heights (pt)"),
        },
        ["file"],
        read_only=True,
    ),
    ToolSpec(
        "sheet_apply",
        "sheet_apply",
        "Edit an .xlsx: cells sets values, formulas and styles by address; ops runs the workbook DSL (formatting, charts, images, tables, freeze panes, filters, conditional formats, validation, hyperlinks, notes, page setup, protection, defined names, sheet order; guide sheets). Give exactly one of cells or ops. "
        + READ_THEN_APPLY
        + "Ops run in order, each seeing the previous result; structural ops (rows, columns, sheets) shift the addresses of later ops.",
        {
            "file": FILE("path of the .xlsx"),
            "sheet": p(S, "default sheet for cells / ops without one"),
            "cells": p(ARR, 'JSON array of { "cell": "B2", "sheet"?, "value"? | "formula"?, "style"? }; style takes the format fields of the format_range op'),
            "ops": p(ARR, "JSON array of workbook DSL ops"),
            "dry_run": DRY,
            "best_effort": BEST,
            "stop_on_error": STOP,
            "out": OUT_APPLY,
            "force": FORCE,
        },
        ["file"],
    ),
    ToolSpec(
        "sheet_check",
        "sheet_check",
        "Consistency checks on an .xlsx: formula errors, formulas not evaluated, missing sheet references, broken defined names, too-narrow columns (with a set_col_width suggest), placeholder text; one finding per issue.",
        {"file": FILE("path of the .xlsx")},
        ["file"],
        read_only=True,
    ),
    ToolSpec(
        "slides_read",
        "slides_read",
        "Structure of a .pptx: slides s_<n> with their elements e_* (kind, text preview, EMU geometry, effective font), tables and with full the whole text and speaker notes. The ids are what slides_apply ops target; ids of created elements are new, so read again before a second batch. layouts lists the master layouts for addSlideWithLayout.",
        {
            "file": FILE("path of the .pptx"),
            "slide": p(I, "one 0-based slide"),
            "full": p(B, "whole text, every table row, speaker notes"),
            "layouts": p(B, "list the master layouts"),
            "max_chars": p(I, "move the 300-character preview clip"),
            "units": p({"type": "string", "enum": ["in", "cm", "pt", "px"]}, "convert geometry from EMU"),
        },
        ["file"],
        read_only=True,
    ),
    ToolSpec(
        "slides_apply",
        "slides_apply",
        "Edit a .pptx with a batch of ops (setText, addElement, addPicture, deleteElement, setTransform, addBlankSlide ...; guide slides). "
        + READ_THEN_APPLY
        + "setText runs inherit the element's first run style unless a field is set. Ops run in order; a later op may target a slide an earlier op added. Atomic by default. After the edit, slides_audit for overflow and slides_render to look.",
        {
            "file": FILE("path of the .pptx"),
            "ops": p(ARR, 'JSON array of ops; target is { "slide": <index|"s_n">, "el"?: "e_*" }'),
            "dry_run": DRY,
            "best_effort": BEST,
            "stop_on_error": STOP,
            "out": OUT_APPLY,
            "force": FORCE,
        },
        ["file", "ops"],
    ),
    ToolSpec(
        "slides_audit",
        "slides_audit",
        "Layout audit of a .pptx: text overflow, out-of-bounds or fully off-slide elements, overlaps and stretched pictures per slide, with the element ids and a suggested setTransform op for slides_apply. Heuristic glyph widths; confirm with slides_render.",
        {"file": FILE("path of the .pptx"), "slide": p(I, "one 0-based slide")},
        ["file"],
        read_only=True,
    ),
    ToolSpec(
        "slides_render",
        "slides_render",
        "One PNG per slide (960x540 at scale 1 for 16:9), written to a directory (detail.files) so you can look at the pages. Needs LibreOffice and pypdfium2. Use after building or editing a deck; slide renders one page (0-based).",
        {"file": FILE("path of the .pptx"), "out": p(S, "directory for the PNGs (required)"), "slide": p(I, "one 0-based slide"), "scale": p(N, "pixel scale, default 1")},
        ["file", "out"],
        read_only=True,
    ),
    ToolSpec(
        "slides_check",
        "slides_check",
        "Check a deck-flow file on disk: an outline.json (core hook and page plan) or one page spec, which is checked against outline.json and style.md beside it or one folder up. The deck_* tools call this for you; use it directly when the files were written by other means.",
        {
            "file": FILE("path of outline.json or a page .json"),
            "outline": p(S, "path of outline.json (default: beside the file or one folder up)"),
            "page": p(I, "0-based outline entry the page is checked against (default: from the NN.json name)"),
        },
        ["file"],
        read_only=True,
    ),
    ToolSpec(
        "slides_replace",
        "slides_replace",
        "Rebuild one slide of a .pptx from a one-page spec file on disk (a deck the staged flow built); the other slides keep their ids and content. deck_replace does the same from an inline page.",
        {
            "file": FILE("path of the .pptx"),
            "slide": p(I, "0-based slide to rebuild"),
            "spec": p(S, "path of the one-page spec file"),
            "outline": p(S, "path of outline.json"),
            "out": OUT_APPLY,
            "force": FORCE,
        },
        ["file", "slide", "spec"],
    ),
    ToolSpec(
        "render",
        "render",
        "One PNG per page of a document (docx, xlsx, pptx, pdf, md, html) as LibreOffice lays it out, written to a directory (detail.files). page renders one page (1-based); grid adds a contact sheet of every page; el crops a pptx element. Look before reporting a document as done.",
        {
            "file": FILE(),
            "out": p(S, "directory for the PNGs (required)"),
            "page": p(I, "one 1-based page"),
            "scale": p(N, "pixel scale, default 1"),
            "el": p(S, "pptx: also crop the page to this element id (e_*)"),
            "pad": p(I, "padding around the cropped element, px"),
            "grid": p(B, "also write every page onto one contact sheet"),
            "cols": p(I, "contact sheet columns (default 4)"),
            "tile": p(I, "contact sheet tile width px (default 320)"),
        },
        ["file", "out"],
        read_only=True,
    ),
    ToolSpec(
        "guide",
        "guide",
        'The op reference to read before writing ops: guide("docs"), guide("sheets") or guide("slides") list the groups; topic narrows to one group or one op. guide("slides", "design") is the staged deck workflow and guide("slides", "spec") the outline and page spec format (deck_start returns both). Generated from the same definitions apply validates against.',
        {
            "domain": p({"type": "string", "enum": ["slides", "docs", "sheets"]}, "slides | docs | sheets"),
            "topic": p(S, "a group, an op name, or for slides: design | spec"),
            "index": p(B, "only the group and op names"),
        },
        ["domain"],
        read_only=True,
    ),
    ToolSpec(
        "capabilities",
        "capabilities",
        "Which cloud features are configured (web search, image search, image generation, media understanding) and whether LibreOffice rendering is available. Check once before planning photos or live facts; everything else runs locally.",
        read_only=True,
    ),
    ToolSpec(
        "search",
        "search",
        "Web search, or image search with images=true, through the configured provider (the query leaves the machine). Image results carry imageUrl, sourceUrl, width and height for addPicture / insert_image / spec image elements.",
        {"query": p(S, "the search query"), "images": p(B, "image search"), "max": p(I, "maximum results")},
        ["query"],
        read_only=True,
        open_world=True,
    ),
    ToolSpec(
        "image",
        "image",
        "Generate an image from a prompt with the configured provider and save it; the result names the real format (a .png request may come back .jpg, see warnings). ref images steer edits.",
        {
            "prompt": p(S, "what to draw"),
            "out": p(S, "output path"),
            "aspect": p(S, "aspect ratio, e.g. 16:9"),
            "size": p(S, "pixel size, e.g. 1024x1024"),
            "ref": p(S, "comma-separated reference image paths"),
            "model": p(S, "provider model name"),
            "force": FORCE,
        },
        ["prompt"],
        open_world=True,
    ),
    ToolSpec(
        "media",
        "media",
        "Describe or extract from an image, audio or video file (or URL) with the configured provider; the file leaves the machine.",
        {"source": p(S, "path or URL of the media"), "ask": p(S, "the question to answer about it")},
        ["source"],
        read_only=True,
        open_world=True,
    ),
    ToolSpec(
        "deck_start",
        "deck_start",
        "Stage 1 of a staged deck, for a longer or design-sensitive presentation a person will present (a short deck of up to about 5 slides with concrete content is one create_pptx call instead): write the style sheet and the outline, check the outline, and get the design and spec guides plus the configured cloud capabilities back in one call. Call once per deck, before any deck_page. Fix every outline error it reports (call again with the corrected outline) before writing pages. The result lists the pages to write, one deck_page call each.",
        {
            "dir": p(S, "the deck folder (created if missing); style.md, outline.json, pages/ and deck.pptx live here"),
            "style": p(S, "style.md: the deck style sheet in Markdown, naming the palette as #RRGGBB colors, the fonts, the layout variants and one sentence of style; pages are checked against these colors"),
            "outline": p(OBJ, 'the outline object: { "core_hook", "pages": [{ "title", "type": cover|content|data|closing, "layout", "brief" with the real figures, "image_queries": [] }] } (format: guide slides spec)'),
        },
        ["dir", "style", "outline"],
    ),
    ToolSpec(
        "deck_page",
        "deck_page",
        "Stage 2: one page spec for outline entry `index`, checked against that entry and the style sheet before it is kept; a page that fails the check is not written. Exactly one page per call, in outline order (the next missing page first).",
        {
            "dir": p(S, "the deck folder"),
            "index": p(I, "0-based outline page index"),
            "page": p(OBJ, 'the one-page spec object { "title", "type", "layout", "elements": [...] } echoing the outline entry\'s title, type and layout (format: guide slides spec)'),
        },
        ["dir", "index", "page"],
    ),
    ToolSpec(
        "deck_build",
        "deck_build",
        "Stage 3: build the .pptx from the checked pages. Refuses while an outline page has no file or a page disagrees with its entry. Then look at the result with slides_render and slides_audit; fix a page with deck_replace.",
        {
            "dir": p(S, "the deck folder"),
            "out": p(S, "output .pptx path (default: <dir>/deck.pptx, overwritten on rebuild)"),
            "render": p(B, "render the slides after building (needs LibreOffice)"),
        },
        ["dir"],
    ),
    ToolSpec(
        "deck_replace",
        "deck_replace",
        "Fix round: rewrite one page spec, check it against its outline entry and the style sheet, and rebuild only that slide of the built deck; the other slides keep their ids and content. When the check fails, the previous page file and the deck stay as they were.",
        {
            "dir": p(S, "the deck folder"),
            "index": p(I, "0-based page (slide) to rebuild"),
            "page": p(OBJ, "the corrected one-page spec object"),
            "pptx": p(S, "the built deck (default: <dir>/deck.pptx)"),
        },
        ["dir", "index", "page"],
    ),
]

BY_NAME = {t.name: t for t in TOOLS}

# python keyword parameters: the schema says "from", the method takes from_
_RENAMES = {"from": "from_"}


def call(go: GenOffice, name: str, args: dict[str, Any] | str | None = None) -> dict[str, Any]:
    """Run one tool by name with JSON arguments; returns the envelope."""
    spec = BY_NAME.get(name)
    if spec is None:
        return _usage_error(name, f"unknown tool {name!r}", "unknown_command", {"commands": list(BY_NAME)}, name, BY_NAME)
    if isinstance(args, str):
        try:
            args = json.loads(args or "{}")
        except json.JSONDecodeError as e:
            return _usage_error(name, f"arguments are not valid JSON: {e}", "invalid_json", None)
    args = args or {}
    unknown = [k for k in args if k not in spec.properties]
    if unknown:
        return _usage_error(
            name, f"unknown option {unknown[0]!r} for {name}", "unknown_option", {"options": list(spec.properties)}, unknown[0], spec.properties
        )
    missing = [k for k in spec.required if args.get(k) is None]
    if missing:
        return _usage_error(name, f"missing {', '.join(missing)}", "missing_argument", {"required": spec.required})
    kwargs = {_RENAMES.get(k, k): v for k, v in args.items() if v is not None}
    return getattr(go, spec.method)(**kwargs)


def _usage_error(
    command: str, message: str, reason: str, detail: dict[str, Any] | None, typo: str | None = None, names: Any = ()
) -> dict[str, Any]:
    guess = did_you_mean(typo, names) if typo else None
    err = GenOfficeError(EXIT.usage, message, detail, reason=reason, suggestion=f'did you mean "{guess}"?' if guess else None)
    return to_json_error(command, err)


def openai_tools(names: list[str] | None = None) -> list[dict[str, Any]]:
    """The specs as OpenAI / Anthropic-style function definitions."""
    return [
        {"type": "function", "function": {"name": t.name, "description": t.description, "parameters": t.parameters}}
        for t in TOOLS
        if names is None or t.name in names
    ]


def anthropic_tools(names: list[str] | None = None) -> list[dict[str, Any]]:
    return [
        {"name": t.name, "description": t.description, "input_schema": t.parameters}
        for t in TOOLS
        if names is None or t.name in names
    ]
