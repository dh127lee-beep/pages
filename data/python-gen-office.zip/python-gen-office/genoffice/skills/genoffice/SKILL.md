---
name: genoffice
description: Create, convert, read and edit Office documents locally with the genoffice tools. Build a new presentation (pptx) from a brief through a checked outline, per-page spec and build pipeline, a new spreadsheet (xlsx) from rows or CSV with formulas, a new Word document (docx) from Markdown or HTML, or a PDF; convert between pdf, docx, xlsx, pptx, md, html and csv; read the structure and text of an existing file (including the user's own docx / xlsx / pptx as source material) and apply structured edits to it. Use whenever the user asks for a slide deck, presentation, spreadsheet, workbook, report, Word document or any real Office file, a format conversion, or a rewrite of part of an existing document. Documents are processed locally; only search, image and media send the query or the referenced file to the configured provider.
license: Apache-2.0
metadata:
  version: 0.1.0
  source: adapted from genspark-ai/genoffice skills/genoffice/SKILL.md (Apache-2.0)
---

# genoffice — GenOffice as built-in tools

The genoffice tools are the `genoffice` CLI as functions: one tool per command, the same parameters (`--max-chars` → `max_chars`), the same op vocabulary and the same result. Every tool runs in-process on python-docx / openpyxl / python-pptx / pypdf; only `search`, `image` and `media` leave the machine, and only `→pdf` / `render` / `slides_render` need LibreOffice (they answer `app_unavailable` without it — check `capabilities` once).

Every tool returns one JSON object: `{ "status": "ok" | "partial", "command", "summary", "output_path"?, "warnings"?, "detail"? }` (`partial`: an apply with `best_effort` / `stop_on_error` wrote the file but lost ops) or `{ "status": "error", "code", "error", "message", "suggestion"?, "detail"? }`. `code`: `1` usage or rejected ops, `2` file not found / output exists / outside allowed roots, `3` conversion failed, `4` app (LibreOffice / provider) not available. `error` is the machine-readable reason (table under "When a tool fails"), `suggestion` the next step in one sentence, including `did you mean "…"?` when a tool, option, op name, element id or sheet name is one typo away. `detail` carries facts as fields (`failures[]` with `index`, `op`, `error`, `reason`, `valid_range`, `available`, `supported`, `usage`; `sheets`, `options`, `commands`); never parse `message`.

## Tools

| Tool | What it does |
| --- | --- |
| `info(file)` | Metadata and structure summary (docx blocks and headings, pptx slides, xlsx sheets, pdf pages) |
| `convert(file, to, out?, force?, sheet?)` | `pdf→docx` (text layer), `csv→xlsx`, `xls/xlsb/ods→xlsx` (LibreOffice), `md→docx/html`, `docx→html/md`, `html→docx`, `xlsx→csv` (`sheet`), and `docx/xlsx/pptx/md/html→pdf` (LibreOffice) |
| `create_pptx(ops \| spec \| spec_dir, outline?, out, render?, audit?)` | New deck from a list of slide ops, or from page specs (px-positioned text, shapes and images; the designed-deck path, below) |
| `create_xlsx(data \| from, header?, decimal?, out)` | New workbook from a 2-D array / `{sheets:[{name,rows}]}` or a CSV/JSON file; `"=..."` cells are formulas; `header` bolds and freezes row 1 and filters the range |
| `create_docx(markdown \| html \| from, out)` | New Word document from Markdown or a restricted-HTML fragment |
| `create_pdf(from, out)` | PDF printed by LibreOffice from any md/html/docx/xlsx/pptx file |
| `slides_read(file, slide?, full?, max_chars?, layouts?, units?)` / `slides_apply(file, ops, dry_run?)` | Inspect ids (`s_<n>`, `e_*`), geometry (`box` in EMU, or converted with `units`), text previews (300 characters, `…(+n chars)` with `truncated: true`; `full`: whole text, every table row, speaker notes) and `effective` font; then edit with ops |
| `slides_audit(file, slide?)` / `slides_render(file, out, slide?)` | Geometry audit (`out_of_bounds`, `off_slide`, `text_overflow`, `text_overflow_width`, `overlap`, `picture_distorted`): `issues[]` with a `code`, `level`, `path` (`s_n/e_*`) and, except for overlap, a `suggest` `setTransform` op you pass to `slides_apply` as is; one PNG per slide to look at |
| `render(file, out, page?, el?, grid?)` | One PNG per page of a docx, xlsx, pptx, md, html or pdf file; `el` (pptx) also crops one element; `grid` writes a contact sheet. Look at it before reporting a document as done |
| `slides_check(file)` / `slides_replace(file, slide, spec)` | Validate a deck outline, or build-and-audit one page file against its outline entry and style.md; rebuild one slide from its page file, other slides untouched |
| `sheet_read(file, sheet?, range?, cols?, max_rows?, where?, stats?, formats?)` / `sheet_apply(file, ops \| cells)` / `sheet_check(file)` | Read a range plus `features` (panes, filter, charts, tables, rule counts); keep output small with `cols`, `max_rows`, `where` (`formula\|error\|empty\|number\|text`) or `stats`; edit with the workbook DSL or by cell address; `check` lists formula errors, references to missing sheets, broken defined names, `###` columns (with a `set_col_width` suggest), placeholder text |
| `docs_read(file, range?, full?, html?, comments?, styles?, header_footer?, sections?, fields?, properties?)` / `docs_apply(file, ops, dry_run?)` / `docs_check(file)` | Read blocks by index (200-character previews; `full` lifts the cap), then edit with ops (`insert_content` restricted HTML, `replace_blocks`, `setFont`, `findReplace`, `insert_image`, `set_header_footer`, `set_page_setup`, `define_style` / `applyStyle`, `add_comment`, `set_properties` …); `check` lists fields without results, broken refs, empty headings, level skips, placeholder text, open comments |
| `merge(file, data, out, strict?)` | Fill `{{key}}` placeholders in a docx / pptx / xlsx template; `detail.used_keys`, `unused_keys`, `unresolved_placeholders[]` (`{placeholder, key, reason: no_key \| split_placeholder \| unreachable_nested, location}`) |
| `pdf_read(file, page? \| range?, full?, password?)` | Text layer page by page (`page`, `width_pt`, `height_pt`, `text` clipped to 4000 characters), page count, `encrypted`, metadata; first 20 pages unless `range` / `full` |
| `guide(domain, topic?)` | The op reference for `slides`, `docs`, `sheets`, generated from the same registry `apply` validates against — read it before writing ops; `guide("slides", "design")` / `guide("slides", "spec")` for building a deck |
| `search(query, images?, max?)` / `image(prompt, out?, aspect?)` / `media(source, ask?)` | Web / image search, image generation, media questions through the configured provider |
| `capabilities()` | Which providers are configured and whether LibreOffice rendering is available; no network call |
| `deck_start` / `deck_page` / `deck_build` / `deck_replace` | The staged deck flow below with the deck folder as state |

`ops`, `cells`, `data` and `spec` take the JSON value inline (or the path of a JSON file). An apply edits in place unless `out` is given.

## Which tool

| Task | Tool path | Not for |
| --- | --- | --- |
| A presentation from a brief, however short | `guide("slides","design")` → `deck_start` (style + outline) → `deck_page` per page → `deck_build` → `slides_render` → `slides_audit` | editing a deck that exists (`slides_apply`) |
| A short deck with concrete content (≤ ~5 slides) | `create_pptx(spec=…, render=true, audit=true)` | a long, design-sensitive deck (staged flow) |
| Change text, a picture or one slide of an existing deck | `slides_read` → `slides_apply` → `slides_audit` → `render(page=…)` | restyling the whole deck |
| A workbook from data | `create_xlsx` → `sheet_apply(ops)` for formats/charts → `sheet_check` | one cell fix in an existing file (`sheet_apply(cells)`) |
| Edit cells, formats, charts, rules of an existing workbook | `sheet_read` → `guide("sheets", op)` → `sheet_apply(ops)` → `sheet_check` | |
| A Word document from text | `create_docx(markdown=…)` → `docs_check` → `render` | |
| Edit an existing Word document | `docs_read` → `docs_apply` → `docs_check` | reading its text (`convert(to="md")` or `docs_read(full=true)`) |
| Read the user's file as source material | `convert(to="md"/"csv")` or `<domain>_read(full=true)` | opening the zip yourself |
| Change the file format | `convert(file, to)` | any content change (edit first, convert after) |
| Fill a template | `merge(file, data, out)` | |
| Look up op fields | `guide(domain, op)` | guessing from this file |

## Behaviour to know

- **Word (`docs`)**: block indexes inside one batch are live — after `insert_content` adds two blocks, later indexes shift by two. A target that matches no block fails the whole batch. `findReplace` does not reach table cells (use `replace_blocks` on the table). Tags outside the restricted set are stripped silently. `convert docx→md` writes GFM and drops images (counted in `detail.skipped`). `create_docx(markdown=…)` embeds local images referenced by relative path. `insert_image` takes a local path, a data: URL or an http(s) URL and appends unless `afterBlockIndex` is given. `set_header_footer` writes plain text with `{PAGE}` / `{NUMPAGES}` tokens. Ops the port does not implement come back as `unsupported` with the reason; `guide("docs")` marks them.
- **Excel (`sheet`)**: ops run in order, each seeing the previous result: after `insert_rows` / `delete_cols` the following ops address the shifted grid; a sheet added or renamed earlier in the batch is addressed by its new name. `set_cell` with a string starting with `=` writes a formula; `type: "text"` keeps it literal. `sheet_read` returns raw values and formulas separately. **The port has no formula engine**: formulas it writes carry no cached value until Excel (or LibreOffice) opens the file; the `formulas_not_cached` warning names those cells — not an error, but say so when you hand the file over.
- **PowerPoint (`slides`)**: picture ops (`addPicture`, `replacePicture`) take a local path, data URL or http(s) URL in `bytes`. `setText` runs inherit the element's first run style unless a field is set explicitly. Ops in one batch run in order, so a later op may target a slide an earlier op added. Created elements get new `e_*` ids: `slides_read` again before targeting them. Every EMU length field (`box`, `offset`, `wEmu`, `colWidthsEmu`, `insets`) also takes `"2.54cm"`, `"1in"`, `"10mm"`, `"12pt"`, `"96px"`.
- **Layout routes** (`→pdf`, `render`, `slides_render`, `create_pdf`): LibreOffice headless, a fresh profile per call, up to 180 s.

## Workflow

1. `info` or `<domain>_read` to learn the structure: block indexes (docx), `s_<n>` / `e_*` ids and EMU geometry (pptx), sheet names and cell values (xlsx).
2. `guide(domain)` for the op fields (`guide(domain, op)` for one op), then write the ops yourself.
3. `dry_run=true` when the batch is large; a rejected op comes back as `op_rejected` with the usage line — fix that op and resend the whole batch. Atomic by default: on rejection the file is untouched and `detail.batch` is `{total, applied: 0, failed, skipped}`. `best_effort` applies every op that can apply, `stop_on_error` applies in order up to the first rejection; both write the file and answer `status: "partial"` with the lost ops in `detail.failures` — check `status`, not only whether an error came back.
4. The QA gate below, then report the output path.

## Pitfalls

| Pitfall | Rule |
| --- | --- |
| `slides_read/audit/render/replace` `slide` and op targets `{ "slide": n }` are **0-based**; `render(page=n)` is **1-based**; docx block indexes are 0-based | `s_0` is page 1 of the PNGs |
| Structural edits renumber: new `e_*` ids after `addElement`, `s_*` after adding slides, docx block indexes after `insert_content` / `deleteBlocks` | Inside one batch indexes are live; before the next batch read again |
| EMU fields take integers or unit strings | Do not multiply by 914400 yourself; `slides_read` returns EMU integers |
| CSV import: a `sep=;` first line is honoured and removed, ISO dates become real dates, `decimal=","` for `1.234,5` | `header=true` freezes row 1 and adds a filter; without it the first row is data |
| `sheet_apply` addresses sheets by the **current tab name** | `sheet_not_found` carries `detail.failures[].available` and a `did you mean` |
| `create_*` / `convert` / `image` never overwrite (`output_exists`); `apply(out=…)` onto another existing file also refuses | Pick another name, or `force=true` when the user asked for replacement |
| `check` / `audit` succeed whether or not they found something | Read `detail.issues`; success is not "clean" |
| Deck specs are px on a 1280×720 canvas; ops are EMU | Never mix the two |
| `docs findReplace` skips table cells; unknown HTML tags in `insert_content` are stripped silently | `replace_blocks` on the table block; stay inside the restricted HTML set (`guide("docs")`) |

## When a tool fails

Branch on `error`, do what `suggestion` says, then resend the **whole** batch (atomic apply wrote nothing).

| `error` | Next step |
| --- | --- |
| `unknown_command`, `unknown_option` | `suggestion`'s `did you mean`; `detail.commands` / `detail.options` list the valid ones |
| `missing_argument`, `invalid_argument` | Fix the parameter named in `message` |
| `invalid_json` | Re-serialize the ops |
| `unknown_op` | `detail.failures[].supported` and `did_you_mean`; `guide(domain)` for the list |
| `op_rejected` | `detail.failures[].usage` is the op's usage line; `guide(domain, op)`; fix that one op |
| `unresolved_placeholder` | `merge(strict=true)`: add the keys named in `detail.unresolved_placeholders[]` to `data` (or retype a `split_placeholder` in one run) and rerun |
| `target_not_found` | `detail.failures[].available` lists the ids on that slide / matching blocks; otherwise read again and retarget |
| `out_of_range` | `detail.failures[].valid_range` (or `detail.valid_range`) |
| `sheet_not_found` | `detail.failures[].available` has the tab names; use one verbatim |
| `file_not_found` | Check the path (relative to the tool root) |
| `output_exists` | Another `out`, or `force=true` if the user asked to replace |
| `outside_allowed_roots` | Stay inside the allowed roots; do not try another location |
| `unsupported` | `detail.supported` lists what this tool accepts; pick another route |
| `conversion_failed`, `app_unavailable`, `app_crashed` | Retry once; if `capabilities` says LibreOffice or the provider is missing, tell the user and continue without that step |

A successful result may still carry `warnings[]` (`{code, message, suggestion?}`): `formulas_not_cached`, `images_dropped`, `output_renamed`, `unresolved_placeholder`, `no_text_layer`. Read them, report what matters, do not retry.

## Before you say "done"

| Artifact | 1. Check | 2. Look (when `capabilities` says rendering is available) | 3. Report |
| --- | --- | --- | --- |
| Deck | `slides_audit` → `detail.issues` empty (apply the `suggest` ops otherwise) | `render(file, out, grid=true)`, look at the contact sheet | The `.pptx` path and anything you left as is |
| Workbook | `sheet_check` → no `formula_error`, `missing_sheet_ref` (apply the `set_col_width` suggests) | `render(file, out)` | The `.xlsx` path; name uncached formulas |
| Document | `docs_check` → no `broken_ref`, `placeholder_left`, `field_not_evaluated` you can fix | `render(file, out)`, look at page 1 and the last | The `.docx` path |

## Reading the user's files

Office files are zipped XML, so go through the tools:

- docx: `convert(file, to="md")` for the whole text (images dropped), or `docs_read(file, full=true)` for blocks with indexes.
- xlsx: `convert(file, to="csv", sheet=…)` for a whole sheet as displayed text, or `sheet_read(file, range="A1:H200")` for raw values (`stats=true` first to size a workbook, `cols` / `max_rows` to page, `where="formula"` for the formulas alone).
- pptx: `slides_read(file, full=true)` for every slide's text, tables and speaker notes.
- pdf: `pdf_read(file, range="1-20")`.

Take figures and wording from that material.

## Designing a deck

Whenever the user wants a presentation of more than a few slides, do not hand-place ops: follow the staged pipeline. You are the model, genoffice is the engine, and each stage is a file the tools check before the next one starts.

1. `guide("slides", "design")` once per session, then `guide("slides", "spec")`. `capabilities()` once: use search / image search / image generation for facts and photos only when they are configured, and plan photo-free pages otherwise.
2. `deck_start(dir, style, outline)`: the style sheet (colors as `#RRGGBB`, fonts, layout variants, one sentence of style) and the outline (core hook + one entry per page: title, type, layout, brief with real figures, image_queries). Fix every error it reports before going on.
3. One page per call: re-read the style sheet and the page's outline entry, resolve its photos, `deck_page(dir, index, page)`. The page is kept only when it passes; fix until `detail.audit`, `detail.outline.findings` and `detail.style.offPalette` are empty, then the next page. Never write several pages in one call.
4. `deck_build(dir)`, then `slides_render` and look; `slides_audit` for geometry. Fix a page with `deck_replace(dir, index, page)`. At most two fix rounds.
5. Report the path. Photos come from `search(images=true)` results, `image`, or local files the user gave you; never draw a grey box in place of a photo. Figures come from the user's material or `search`; say so when a number is illustrative.

## Editing an existing deck

1. `slides_read(file, slide=n, full=true)` for the element ids and current text.
2. `setText` on the existing element (unstyled runs inherit the original font, size and color), `addElement` / `addPicture` for new content, `deleteElement` for what goes. Write with `out` when the user wants the original kept.
3. `slides_audit(file, slide=n)` after the edit; apply the `suggest` ops it returns, then render once more.
4. Ids of created elements are new: `slides_read` again before a second round of ops.

## Examples

Deck from ops — `create_pptx(out="q3.pptx", ops=…)`:

```json
[
  { "op": "addElement", "target": { "slide": 0 }, "kind": "textbox",
    "offset": { "x": 914400, "y": 685800, "cx": 7315200, "cy": 914400 },
    "paragraphs": [{ "runs": [{ "text": "Q3 Review", "bold": true, "fontSize": 36 }] }] },
  { "op": "addBlankSlide", "target": { "slide": 0 } },
  { "op": "addTable", "target": { "slide": 1 }, "rows": 3, "cols": 3,
    "offset": { "x": 914400, "y": 1828800, "cx": 7315200, "cy": 2286000 } }
]
```

Workbook with formulas, then a formatted header:

```json
create_xlsx(out="sales.xlsx", data=[["item","qty","price"],["Apple",2,1.5],["Total","=SUM(B2:B2)",""]])
sheet_apply(file="sales.xlsx", ops=[{"op":"format_range","range":"A1:C1","format":{"bold":true,"fillColor":"#FFFF00"}}])
```

Word from Markdown, then a paragraph after block 0:

```json
create_docx(out="report.docx", markdown="# Report\n\nBody text.")
docs_apply(file="report.docx", ops=[{"op":"insert_content","afterBlockIndex":0,"html":"<p>Executive summary.</p>"}])
```

## Path rules

- Relative paths resolve against the tool root the host configured; genoffice never writes outside `out` or the file being edited.
- `create_*` and `convert` refuse to overwrite an existing output without `force`. Apply edits in place unless `out` is given; `out` onto another existing file also needs `force`.
- When allowed roots are configured, genoffice only reads and writes inside them (`outside_allowed_roots` otherwise).

## Limits of the Python port

- Not ported (they need the GenOffice desktop editor): `open`, `selection`, tracked-change recording, pivot refresh. Also not implemented: OCR, a formula engine, and some ops (`guide` lists each one with its reason).
- `→pdf`, `render`, `slides_render`, `xls/ods→xlsx` need LibreOffice; rendering also needs pypdfium2.
