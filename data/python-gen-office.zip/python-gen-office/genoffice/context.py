"""Where genoffice reads and writes, and which outside services it may call.

The CLI took these from the environment and the GenOffice app's settings; a Python host passes them
in. `Context` is the only state the commands share, so two agents with two contexts never see each
other's roots or providers.
"""

from __future__ import annotations

import json
import os
import shutil
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Optional

from .result import EXIT, GenOfficeError

# provider hooks: plain callables, so any SDK (or a test stub) plugs in
SearchFn = Callable[..., list]  # (query, *, images: bool, max: int) -> [{title,url,snippet}] | [{title,imageUrl,sourceUrl,...}]
ImageFn = Callable[..., Any]  # (prompt, *, aspect, size, refs, model) -> bytes | (bytes, mime)
MediaFn = Callable[..., str]  # (source, *, ask) -> answer text


@dataclass
class Context:
    """root: relative paths resolve here (default: the process cwd).
    allowed_roots: when set, every read and write must stay inside one of them
        (GENOFFICE_ALLOWED_ROOTS, os.pathsep-separated, is the default).
    search / image / media: the cloud features; None = not configured.
    soffice: LibreOffice binary for →pdf and render (GENOFFICE_SOFFICE, else found on PATH).
    audit_log: JSONL file every executed command is appended to (GENOFFICE_AUDIT_LOG; "" disables).
    """

    root: Optional[str] = None
    allowed_roots: Optional[list[str]] = None
    search: Optional[SearchFn] = None
    image: Optional[ImageFn] = None
    media: Optional[MediaFn] = None
    soffice: Optional[str] = None
    audit_log: Optional[str] = None
    extra: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.allowed_roots is None:
            raw = os.environ.get("GENOFFICE_ALLOWED_ROOTS")
            if raw:
                self.allowed_roots = [p for p in raw.split(os.pathsep) if p]
        if self.audit_log is None:
            self.audit_log = os.environ.get("GENOFFICE_AUDIT_LOG")
        if self.soffice is None:
            self.soffice = os.environ.get("GENOFFICE_SOFFICE") or _find_soffice()

    # ---- paths ----

    @property
    def base(self) -> Path:
        return Path(self.root or os.getcwd()).expanduser().resolve()

    def resolve(self, path: str | os.PathLike[str], *, base: Path | None = None) -> Path:
        p = Path(path).expanduser()
        if not p.is_absolute():
            p = (base or self.base) / p
        p = p.resolve()
        self._assert_allowed(p)
        return p

    def input_file(self, path: str | None, *, what: str = "file", base: Path | None = None) -> Path:
        if not path:
            raise GenOfficeError(EXIT.usage, f"missing {what}", reason="missing_argument")
        p = self.resolve(path, base=base)
        if not p.is_file():
            raise GenOfficeError(
                EXIT.file,
                f"file not found: {path}",
                {"path": str(p)},
                reason="file_not_found",
                suggestion="check the path (relative to the working directory)",
            )
        return p

    def output_file(self, path: str | os.PathLike[str], *, force: bool = False, editing: Path | None = None) -> Path:
        """An output path that may be written: refuses to overwrite another existing file without force."""
        p = self.resolve(path)
        if p.exists() and not force and p != editing:
            raise GenOfficeError(
                EXIT.file,
                f"output exists: {p}",
                {"path": str(p)},
                reason="output_exists",
                suggestion="pick another out path, or pass force=True when the user asked to replace it",
            )
        p.parent.mkdir(parents=True, exist_ok=True)
        return p

    def _assert_allowed(self, p: Path) -> None:
        if not self.allowed_roots:
            return
        for root in self.allowed_roots:
            r = Path(root).expanduser().resolve()
            if p == r or r in p.parents:
                return
        raise GenOfficeError(
            EXIT.file,
            f"outside the allowed roots: {p}",
            {"path": str(p), "allowed_roots": self.allowed_roots},
            reason="outside_allowed_roots",
            suggestion="stay inside the allowed roots; do not try another location",
        )

    # ---- capabilities ----

    def require_soffice(self, what: str) -> str:
        if not self.soffice:
            raise GenOfficeError(
                EXIT.app,
                f"{what} needs LibreOffice (soffice), which was not found",
                {"supported_without_app": ["docx", "xlsx", "pptx", "md", "html", "csv"]},
                reason="app_unavailable",
                suggestion="install LibreOffice or set GENOFFICE_SOFFICE to its soffice binary, or tell the user",
            )
        return self.soffice

    def audit(self, command: str, args: dict[str, Any], status: str) -> None:
        if not self.audit_log:
            return
        try:
            line = {"ts": time.time(), "command": command, "status": status, "args": _short(args)}
            path = Path(self.audit_log).expanduser()
            path.parent.mkdir(parents=True, exist_ok=True)
            with path.open("a", encoding="utf-8") as f:
                f.write(json.dumps(line, ensure_ascii=False, default=str) + "\n")
        except OSError:
            pass


def _short(args: dict[str, Any]) -> dict[str, Any]:
    out = {}
    for k, v in args.items():
        text = v if isinstance(v, (str, int, float, bool)) or v is None else json.dumps(v, default=str)
        if isinstance(text, str) and len(text) > 200:
            text = text[:200] + "…"
        out[k] = text
    return out


def _find_soffice() -> str | None:
    for name in ("soffice", "libreoffice"):
        found = shutil.which(name)
        if found:
            return found
    for cand in (
        "/Applications/LibreOffice.app/Contents/MacOS/soffice",
        "/usr/lib/libreoffice/program/soffice",
        "/opt/libreoffice/program/soffice",
        r"C:\Program Files\LibreOffice\program\soffice.exe",
    ):
        if os.path.exists(cand):
            return cand
    return None
