"""Op registries and the batch runner shared by `docs apply`, `sheet apply` and `slides apply`.

One registry per domain holds every op's name, group, signature, note and handler. `guide` prints
the catalog from the same objects `apply` validates against, so the reference cannot drift from what
is accepted (the CLI's rule, kept here).

Batch modes:
    atomic         any rejected op leaves the file untouched (error, exit 1)
    best_effort    every op that can apply does; the rest are reported (status "partial")
    stop_on_error  ops apply in order up to the first rejection (status "partial")
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from typing import Any, Callable, Literal

from .result import EXIT, CommandResult, GenOfficeError
from .suggest import did_you_mean

BatchMode = Literal["atomic", "best_effort", "stop_on_error"]
Domain = Literal["slides", "docs", "sheets"]


class OpError(Exception):
    """Raised by an op handler: the op is rejected, with the facts a caller needs to fix it.

    reason: op_rejected | target_not_found | out_of_range | sheet_not_found
    available: ids/names that do exist; valid_range: [lo, hi] of valid indexes.
    """

    def __init__(
        self,
        message: str,
        *,
        reason: str = "op_rejected",
        available: list[str] | None = None,
        valid_range: tuple[int, int] | list[int] | None = None,
        wanted: str | None = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.reason = reason
        self.available = available
        self.valid_range = list(valid_range) if valid_range is not None else None
        self.wanted = wanted


@dataclass
class OpDef:
    name: str
    group: str
    signature: str
    handler: Callable[..., Any] | None = None
    note: str | None = None
    required: tuple[str, ...] = ()
    # False: part of the original GenOffice op set but not implemented by this port
    available: bool = True
    reason: str | None = None
    examples: list[Any] = field(default_factory=list)

    @property
    def usage(self) -> str:
        return f"Usage: {{op: \"{self.name}\", {self.signature.strip('{} ')}}}"

    def entry(self) -> dict[str, Any]:
        out: dict[str, Any] = {"op": self.name, "group": self.group, "signature": self.signature}
        if self.note:
            out["note"] = self.note
        if self.required:
            out["required"] = list(self.required)
        if not self.available:
            out["available"] = False
            out["reason"] = self.reason
        if self.examples:
            out["examples"] = self.examples
        return out


class OpRegistry:
    def __init__(self, domain: Domain, header: list[str], footer: list[str] | None = None) -> None:
        self.domain = domain
        self.header = header
        self.footer = footer or []
        self.groups: dict[str, str] = {}
        self.ops: dict[str, OpDef] = {}

    def group(self, name: str, summary: str) -> None:
        self.groups[name] = summary

    def op(
        self,
        name: str,
        group: str,
        signature: str,
        *,
        note: str | None = None,
        required: tuple[str, ...] | list[str] = (),
        examples: list[Any] | None = None,
    ) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        def register(fn: Callable[..., Any]) -> Callable[..., Any]:
            self.ops[name] = OpDef(
                name, group, signature, fn, note, tuple(required), examples=examples or []
            )
            return fn

        return register

    def unavailable(self, name: str, group: str, signature: str, reason: str) -> None:
        self.ops[name] = OpDef(name, group, signature, None, available=False, reason=reason)

    # ---- catalog / guide ----

    def catalog(self) -> dict[str, Any]:
        groups = [
            {"name": g, "summary": s, "ops": [o.name for o in self.ops.values() if o.group == g]}
            for g, s in self.groups.items()
        ]
        ops = [o.entry() for o in self.ops.values()]
        body = {"domain": self.domain, "groups": groups, "ops": ops}
        return {"domain": self.domain, "fingerprint": fingerprint(body), "groups": groups, "ops": ops}

    def guide_text(self, group: str | None = None) -> str:
        lines = list(self.header) + [""]
        for g, summary in self.groups.items():
            if group and g != group:
                continue
            lines.append(f"{g[0].upper()}{g[1:]}{f' ({summary})' if summary else ''}:")
            for o in self.ops.values():
                if o.group != g:
                    continue
                if not o.available:
                    lines.append(f"  {o.name} — not available in the Python port: {o.reason}")
                    continue
                lines.append(f"  {o.name} {o.signature}")
                if o.note:
                    lines.append(f"    — {o.note}")
        if not group and self.footer:
            lines += [""] + self.footer
        return "\n".join(lines)

    def names(self) -> list[str]:
        return [o.name for o in self.ops.values() if o.available]

    # ---- batch ----

    def run_batch(self, ops: Any, ctx: Any, mode: BatchMode = "atomic") -> "BatchOutcome":
        """Run ops in order against ctx (the open document). Never writes; the caller saves.

        atomic: raises GenOfficeError on the first rejection (the caller then writes nothing).
        """
        if not isinstance(ops, list):
            raise GenOfficeError(
                EXIT.usage,
                "ops must be a JSON array of op objects",
                reason="invalid_argument",
                suggestion=f'send a list like [{{"op": "..."}}]; `guide("{self.domain}")` lists the ops',
            )
        outcome = BatchOutcome(total=len(ops))
        for index, raw in enumerate(ops):
            failure = self._run_one(index, raw, ctx, outcome)
            if failure is None:
                outcome.applied += 1
                continue
            outcome.failures.append(failure)
            if mode == "atomic":
                raise self.failed_batch(failure, outcome)
            if mode == "stop_on_error":
                break
        return outcome

    def _run_one(self, index: int, raw: Any, ctx: Any, outcome: "BatchOutcome") -> dict[str, Any] | None:
        if not isinstance(raw, dict) or not isinstance(raw.get("op"), str):
            return {
                "index": index,
                "op": str(raw.get("op")) if isinstance(raw, dict) else "?",
                "error": 'every op is an object with an "op" field',
                "reason": "op_rejected",
            }
        name = raw["op"]
        d = self.ops.get(name)
        if d is None or not d.available:
            supported = self.names()
            f: dict[str, Any] = {
                "index": index,
                "op": name,
                "reason": "unknown_op" if d is None else "unsupported",
                "error": f'unknown op "{name}"'
                if d is None
                else f'op "{name}" is not available in the Python port: {d.reason}',
                "supported": supported,
            }
            guess = did_you_mean(name, supported)
            if guess:
                f["did_you_mean"] = guess
            return f
        missing = [k for k in d.required if raw.get(k) is None]
        if missing:
            return {
                "index": index,
                "op": name,
                "reason": "op_rejected",
                "error": f"{name}: missing {', '.join(missing)}",
                "usage": d.usage,
            }
        try:
            result = d.handler(ctx, raw)  # type: ignore[misc]
        except OpError as e:
            f = {"index": index, "op": name, "error": e.message, "reason": e.reason}
            if e.available is not None:
                f["available"] = e.available
                if e.wanted:
                    guess = did_you_mean(e.wanted, e.available)
                    if guess:
                        f["did_you_mean"] = guess
            if e.valid_range is not None:
                f["valid_range"] = e.valid_range
            if e.reason == "op_rejected":
                f["usage"] = d.usage
            return f
        except (ValueError, TypeError, KeyError, IndexError) as e:
            return {
                "index": index,
                "op": name,
                "error": f"{name}: {e}",
                "reason": "op_rejected",
                "usage": d.usage,
            }
        if isinstance(result, dict):
            outcome.notes.append({"index": index, "op": name, **result})
        return None

    def failed_batch(self, f: dict[str, Any], outcome: "BatchOutcome") -> GenOfficeError:
        return GenOfficeError(
            EXIT.usage,
            f"op {f['index']} ({f['op']}) rejected: {f['error']}; nothing was written",
            {"failures": [f], "batch": batch_counts(outcome.total, 0, 1)},
            reason=f["reason"] if f["reason"] != "unsupported" else "unknown_op",
            suggestion=op_suggestion(f, self.domain),
        )


@dataclass
class BatchOutcome:
    total: int
    applied: int = 0
    failures: list[dict[str, Any]] = field(default_factory=list)
    notes: list[dict[str, Any]] = field(default_factory=list)

    @property
    def counts(self) -> dict[str, int]:
        return batch_counts(self.total, self.applied, len(self.failures))


def batch_mode(best_effort: bool = False, stop_on_error: bool = False, isolation: str | None = None) -> BatchMode:
    if isolation is not None and isolation not in ("atomic", "per_op"):
        raise GenOfficeError(EXIT.usage, "isolation must be atomic or per_op", reason="invalid_argument")
    if stop_on_error and (best_effort or isolation == "per_op"):
        raise GenOfficeError(
            EXIT.usage,
            "stop_on_error cannot be combined with best_effort",
            reason="invalid_argument",
            suggestion="pick one batch mode",
        )
    if best_effort or isolation == "per_op":
        return "best_effort"
    if stop_on_error:
        return "stop_on_error"
    return "atomic"


def batch_counts(total: int, applied: int, failed: int) -> dict[str, int]:
    return {"total": total, "applied": applied, "failed": failed, "skipped": max(0, total - applied - failed)}


def batch_result(r: CommandResult, outcome: BatchOutcome) -> CommandResult:
    """A result that ran as a batch: counts always, `partial` once any op was lost."""
    detail = dict(r.detail or {})
    detail["batch"] = outcome.counts
    if outcome.notes:
        detail["notes"] = outcome.notes
    if not outcome.failures:
        r.detail = detail
        return r
    detail["failures"] = outcome.failures
    c = outcome.counts
    skipped = f", {c['skipped']} skipped" if c["skipped"] else ""
    r.detail = detail
    r.status = "partial"
    r.summary = f"{r.summary}; {c['failed']} failed{skipped}"
    return r


def op_suggestion(f: dict[str, Any], domain: str) -> str:
    reason = f["reason"]
    if reason in ("unknown_op", "unsupported"):
        if f.get("did_you_mean"):
            return f'did you mean "{f["did_you_mean"]}"? (guide("{domain}") lists every op), then resend the whole batch'
        return f'run guide("{domain}") for the op list, then resend the whole batch'
    if reason == "out_of_range" and f.get("valid_range"):
        lo, hi = f["valid_range"]
        return f"use an index between {lo} and {hi} ({domain}_read lists the current ones), then resend the whole batch"
    if reason in ("target_not_found", "sheet_not_found"):
        if f.get("did_you_mean"):
            return f'did you mean "{f["did_you_mean"]}"? (detail.failures[].available lists the valid ones), then resend the whole batch'
        return f"run {domain}_read for the current ids (see detail.failures[].available), then resend the whole batch"
    if f.get("usage"):
        return f"fix op {f['index']} to match its usage line (detail.failures[].usage), then resend the whole batch"
    return f"fix op {f['index']}, then resend the whole batch"


def fingerprint(value: Any) -> str:
    text = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str)
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:12]


def clip(text: str, limit: int | None) -> tuple[str, bool]:
    """Previews end in `…(+n chars)` with truncated: true, as the CLI prints them."""
    if limit is None or len(text) <= limit:
        return text, False
    return f"{text[:limit]}…(+{len(text) - limit} chars)", True
