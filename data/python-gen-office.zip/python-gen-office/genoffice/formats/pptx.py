"""PowerPoint: `slides read/apply/audit/check/replace`, `create --type pptx` and `merge` on .pptx.

Ids follow the CLI: slides are `s_<0-based index>`, elements `e_<shape id>` (the cNvPr id, stable
while other shapes change). Op targets are {"slide": <index | "s_n">, "el"?: "e_*"}. EMU fields take
integers or unit strings ("2.54cm", "1in", "96px").
"""

from __future__ import annotations

import copy
import io
import re
from pathlib import Path
from typing import Any, Iterator

from lxml import etree
from pptx import Presentation
from pptx.chart.data import CategoryChartData, XyChartData
from pptx.dml.color import RGBColor
from pptx.enum.chart import XL_CHART_TYPE
from pptx.enum.shapes import MSO_CONNECTOR, MSO_SHAPE, MSO_SHAPE_TYPE, PP_PLACEHOLDER
from pptx.enum.text import MSO_ANCHOR, MSO_AUTO_SIZE
from pptx.opc.constants import RELATIONSHIP_TYPE as RT
from pptx.oxml.ns import qn
from pptx.util import Pt

from ..context import Context
from ..ops import BatchMode, OpError, OpRegistry, batch_result, clip
from ..result import EXIT, CommandResult, GenOfficeError, Warning
from ..units import EMU_PER_PT, SLIDE_H_EMU, SLIDE_W_EMU, emu_to, to_emu
from . import slide_spec as ss
from .slide_spec import ALIGN, load_image_bytes, set_bullet, set_solid

A_NS = "http://schemas.openxmlformats.org/drawingml/2006/main"
NS = {"a": A_NS, "p": "http://schemas.openxmlformats.org/presentationml/2006/main"}
PREVIEW_CHARS = 300

# ================================================================ registry

REGISTRY = OpRegistry(
    "slides",
    header=[
        "PowerPoint ops (slides_apply ops / create_pptx ops): a JSON array; every entry has \"op\" and a target",
        '{"slide": <0-based index | "s_n">, "el"?: "e_*"} (slides_read lists the ids). EMU fields (offset, box,',
        'widthEmu, wEmu/hEmu, colWidthsEmu, insets) take integers or "2.54cm" / "1in" / "10mm" / "12pt" / "96px".',
        "Field notation: ? = optional, a|b = one of.",
    ],
    footer=[
        "Ops run in order; a later op may target a slide an earlier op added. Created elements get new e_* ids",
        "(detail.notes[].created): run slides_read again before a second batch. Atomic by default.",
    ],
)
for _g, _s in (
    ("text", "text, fonts, paragraph format"),
    ("element", "fill, outline, geometry, order, links, alignment of existing elements"),
    ("insert", "new text boxes, shapes, connectors, pictures, tables, charts"),
    ("table", "cells, merges, sizes of an existing table"),
    ("slide", "add, delete, duplicate, move slides; background, notes, transitions"),
    ("deck", "slide size, find/replace, theme"),
):
    REGISTRY.group(_g, _s)


class Deck:
    """The open presentation an op batch runs against."""

    def __init__(self, prs: Any, bases: list[Path]) -> None:
        self.prs = prs
        self.bases = bases

    @property
    def slides(self) -> list[Any]:
        return list(self.prs.slides)

    def slide_index(self, target: Any) -> int:
        n = len(self.prs.slides)
        raw = target.get("slide") if isinstance(target, dict) else target
        if isinstance(raw, str) and re.fullmatch(r"s_\d+", raw):
            raw = int(raw[2:])
        if not isinstance(raw, int) or isinstance(raw, bool):
            raise OpError('target.slide must be a 0-based index or "s_n"')
        if not 0 <= raw < n:
            raise OpError(f"slide {raw} out of range (0-{n - 1})", reason="out_of_range", valid_range=(0, n - 1))
        return raw

    def slide(self, op: dict[str, Any]) -> Any:
        return self.prs.slides[self.slide_index(op.get("target"))]

    def shape(self, op: dict[str, Any]) -> tuple[Any, Any]:
        target = op.get("target") or {}
        slide = self.slide(op)
        el = target.get("el")
        if not isinstance(el, str):
            raise OpError('target.el is required: an element id "e_*" from slides_read')
        found = find_shape(slide, el)
        if found is None:
            raise OpError(
                f'no element "{el}" on slide {self.slide_index(target)}. Available: [{", ".join(element_ids(slide))}]',
                reason="target_not_found",
                available=element_ids(slide),
                wanted=el,
            )
        return slide, found

    def shapes_by_ids(self, slide: Any, ids: Any) -> list[Any]:
        if not isinstance(ids, list) or not ids:
            raise OpError("els must be a non-empty array of element ids")
        out = []
        for el in ids:
            s = find_shape(slide, str(el))
            if s is None:
                raise OpError(f'no element "{el}"', reason="target_not_found", available=element_ids(slide), wanted=str(el))
            out.append(s)
        return out


def iter_shapes(shapes: Any) -> Iterator[Any]:
    for s in shapes:
        yield s
        if s.shape_type == MSO_SHAPE_TYPE.GROUP:
            yield from iter_shapes(s.shapes)


def element_id(shape: Any) -> str:
    return f"e_{shape.shape_id}"


def element_ids(slide: Any) -> list[str]:
    return [element_id(s) for s in iter_shapes(slide.shapes)]


def find_shape(slide: Any, el: str) -> Any:
    for s in iter_shapes(slide.shapes):
        if element_id(s) == el:
            return s
    return None


def _box(op: dict[str, Any], key: str) -> dict[str, int]:
    b = op.get(key)
    if not isinstance(b, dict):
        raise OpError(f"{key} must be {{x, y, cx, cy}}")
    try:
        return {k: to_emu(b[k]) for k in ("x", "y", "cx", "cy") if k in b}
    except ValueError as e:
        raise OpError(f"{key}: {e}") from e


def _rgb(value: Any) -> RGBColor:
    rgb, _ = ss.parse_color(value)
    return RGBColor.from_string(rgb)


def _text_frame(shape: Any) -> Any:
    if not getattr(shape, "has_text_frame", False):
        raise OpError(f"element {element_id(shape)} has no text (kind {kind_of(shape)})")
    return shape.text_frame


# ---------------------------------------------------------------- text ops


def write_rich(tf: Any, paragraphs: Any) -> None:
    """Op paragraphs into a text frame; unset run fields inherit the frame's first run style."""
    if not isinstance(paragraphs, list):
        raise OpError("paragraphs must be [{runs:[{text,...}], align?}]")
    first_rpr = None
    for p in tf.paragraphs:
        if p.runs:
            first_rpr = p.runs[0]._r.find(qn("a:rPr"))
            break
    first_ppr = tf.paragraphs[0]._p.find(qn("a:pPr")) if tf.paragraphs else None
    first_rpr = copy.deepcopy(first_rpr) if first_rpr is not None else None
    first_ppr = copy.deepcopy(first_ppr) if first_ppr is not None else None
    tf.clear()
    for i, para in enumerate(paragraphs):
        if not isinstance(para, dict):
            raise OpError("every paragraph is an object with runs")
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        if first_ppr is not None and p._p.find(qn("a:pPr")) is None:
            p._p.insert(0, copy.deepcopy(first_ppr))
        _paragraph_format(p, para)
        if isinstance(para.get("level"), int):
            p.level = para["level"]
        for r in para.get("runs", []):
            if not isinstance(r, dict):
                raise OpError("every run is an object with text")
            run = p.add_run()
            if first_rpr is not None:
                old = run._r.find(qn("a:rPr"))
                if old is not None:
                    run._r.remove(old)
                run._r.insert(0, copy.deepcopy(first_rpr))
            run.text = str(r.get("text", ""))
            _font(run.font, r, size_key="fontSize")
            link = r.get("link")
            if isinstance(link, str):
                run.hyperlink.address = link
            elif isinstance(link, dict) and link.get("url"):
                run.hyperlink.address = link["url"]


def _font(font: Any, f: dict[str, Any], *, size_key: str) -> None:
    if f.get("fontFamily"):
        font.name = str(f["fontFamily"])
    if f.get(size_key) is not None:
        font.size = Pt(float(f[size_key]))
    for key in ("bold", "italic"):
        if key in f and f[key] is not None:
            setattr(font, key, bool(f[key]))
    if "underline" in f and f["underline"] is not None:
        font.underline = bool(f["underline"])
    if f.get("strike") is not None:
        rpr = font._rPr
        rpr.set("strike", "sngStrike" if f["strike"] else "noStrike")
    if f.get("color"):
        set_solid(font.fill, f["color"])


def _paragraph_format(p: Any, fmt: dict[str, Any]) -> None:
    if fmt.get("align") in ALIGN:
        p.alignment = ALIGN[fmt["align"]]
    elif fmt.get("align") is not None:
        raise OpError("align is left|center|right|justify")
    if fmt.get("bullet") is not None:
        set_bullet(p, bool(fmt["bullet"]))
    if fmt.get("lineSpacingPct") is not None:
        p.line_spacing = float(fmt["lineSpacingPct"]) / 100
    if fmt.get("spaceBeforePt") is not None:
        p.space_before = Pt(float(fmt["spaceBeforePt"]))
    if fmt.get("spaceAfterPt") is not None:
        p.space_after = Pt(float(fmt["spaceAfterPt"]))


@REGISTRY.op(
    "setText",
    "text",
    '{paragraphs:[{runs:[{text,bold?,italic?,underline?,fontSize?,color?,fontFamily?,link?}],align?,bullet?,level?}]}',
    note="runs inherit the element's first run style unless a field is set (bold: false)",
    required=("paragraphs",),
)
def _set_text(deck: Deck, op: dict[str, Any]) -> None:
    _, shape = deck.shape(op)
    write_rich(_text_frame(shape), op["paragraphs"])


@REGISTRY.op(
    "setFont",
    "text",
    "{font:{fontFamily?,fontSizePt?,fontSizeStep?,bold?,italic?,underline?,strike?,color?}}",
    note="merges onto every run of the element",
    required=("font",),
)
def _set_font(deck: Deck, op: dict[str, Any]) -> None:
    _, shape = deck.shape(op)
    f = op["font"]
    if not isinstance(f, dict):
        raise OpError("font must be an object")
    for p in _text_frame(shape).paragraphs:
        for r in p.runs:
            _font(r.font, f, size_key="fontSizePt")
            if f.get("fontSizeStep"):
                current = r.font.size.pt if r.font.size else 18.0
                r.font.size = Pt(max(1.0, current + float(f["fontSizeStep"])))


@REGISTRY.op(
    "setParagraphFormat",
    "text",
    "{format:{align?,bullet?,lineSpacingPct?,spaceBeforePt?,spaceAfterPt?}}",
    required=("format",),
)
def _set_paragraph_format(deck: Deck, op: dict[str, Any]) -> None:
    _, shape = deck.shape(op)
    for p in _text_frame(shape).paragraphs:
        _paragraph_format(p, op["format"])


REGISTRY.unavailable(
    "insertEquation", "text", "{latex,position?}", "OMML typesetting from LaTeX is not ported"
)

# ---------------------------------------------------------------- element ops


@REGISTRY.op("deleteElement", "element", "{} — no fields besides target")
def _delete_element(deck: Deck, op: dict[str, Any]) -> None:
    _, shape = deck.shape(op)
    el = shape._element
    el.getparent().remove(el)


def _apply_fill(fill: Any, value: Any) -> None:
    if value == "none":
        fill.background()
    elif isinstance(value, str):
        set_solid(fill, value)
    elif isinstance(value, dict) and isinstance(value.get("stops"), list) and len(value["stops"]) >= 2:
        fill.gradient()
        fill.gradient_angle = float(value.get("angle", 0))
        gs_lst = fill._xPr.find(qn("a:gradFill")).find(qn("a:gsLst"))
        for gs in list(gs_lst):
            gs_lst.remove(gs)
        for stop in value["stops"]:
            gs = etree.SubElement(gs_lst, qn("a:gs"))
            pos = float(stop.get("pos", 0))
            gs.set("pos", str(int(round((pos if pos > 1 else pos * 100) * 1000))))
            clr = etree.SubElement(gs, qn("a:srgbClr"))
            clr.set("val", ss.parse_color(stop.get("color"))[0])
    else:
        raise OpError('fill is "#RRGGBB", "none" or {stops:[{pos,color}], angle?}')


@REGISTRY.op("setFill", "element", '{fill:"#RRGGBB"|"none"|{stops:[{pos,color}],angle?}}', required=("fill",))
def _set_fill(deck: Deck, op: dict[str, Any]) -> None:
    _, shape = deck.shape(op)
    if not hasattr(shape, "fill"):
        raise OpError(f"element {element_id(shape)} ({kind_of(shape)}) has no fill")
    _apply_fill(shape.fill, op["fill"])


@REGISTRY.op("setStroke", "element", '{stroke:{color:"#RRGGBB",widthEmu}|null} — null removes the outline')
def _set_stroke(deck: Deck, op: dict[str, Any]) -> None:
    _, shape = deck.shape(op)
    if "stroke" not in op:
        raise OpError("stroke is required ({color, widthEmu} or null)")
    stroke = op["stroke"]
    if stroke is None:
        shape.line.fill.background()
        return
    if not isinstance(stroke, dict):
        raise OpError("stroke is {color, widthEmu} or null")
    if stroke.get("color"):
        set_solid(shape.line.fill, stroke["color"])
    if stroke.get("widthEmu") is not None:
        shape.line.width = to_emu(stroke["widthEmu"])


@REGISTRY.op(
    "setTransform",
    "element",
    "{box:{x,y,cx,cy},rotDeg?} (group children: absBox instead of box, plus group)",
)
def _set_transform(deck: Deck, op: dict[str, Any]) -> None:
    _, shape = deck.shape(op)
    key = "box" if "box" in op else "absBox" if "absBox" in op else None
    if key is None and op.get("rotDeg") is None:
        raise OpError("give box {x,y,cx,cy} and/or rotDeg")
    if key:
        b = _box(op, key)
        if "x" in b:
            shape.left = b["x"]
        if "y" in b:
            shape.top = b["y"]
        if "cx" in b:
            shape.width = b["cx"]
        if "cy" in b:
            shape.height = b["cy"]
    if op.get("rotDeg") is not None:
        shape.rotation = float(op["rotDeg"])


@REGISTRY.op("reorderElement", "element", '{dir:"front"|"back"|"forward"|"backward"}', required=("dir",))
def _reorder(deck: Deck, op: dict[str, Any]) -> None:
    _, shape = deck.shape(op)
    el = shape._element
    parent = el.getparent()
    # the first two children of spTree / grpSp are nvGrpSpPr and grpSpPr
    siblings = [c for c in parent if c.tag not in (qn("p:nvGrpSpPr"), qn("p:grpSpPr"))]
    i = siblings.index(el)
    direction = op["dir"]
    if direction == "front":
        parent.remove(el)
        parent.append(el)
    elif direction == "back":
        parent.remove(el)
        parent.insert(2, el)
    elif direction == "forward" and i + 1 < len(siblings):
        siblings[i + 1].addnext(el)
    elif direction == "backward" and i > 0:
        siblings[i - 1].addprevious(el)
    elif direction not in ("forward", "backward"):
        raise OpError("dir is front|back|forward|backward")


PRESETS = {m.xml_value for m in MSO_SHAPE if getattr(m, "xml_value", None)}


def _prst_geom(shape: Any) -> Any:
    geom = shape._element.find(qn("p:spPr")) if hasattr(shape._element, "find") else None
    geom = geom.find(qn("a:prstGeom")) if geom is not None else None
    if geom is None:
        raise OpError(f"element {element_id(shape)} ({kind_of(shape)}) has no preset geometry")
    return geom


@REGISTRY.op("setShapeGeometry", "element", '{prst:"<OOXML preset geometry name>"}', required=("prst",))
def _set_geometry(deck: Deck, op: dict[str, Any]) -> None:
    _, shape = deck.shape(op)
    if op["prst"] not in PRESETS:
        raise OpError(f'unknown preset geometry "{op["prst"]}"', available=sorted(PRESETS), wanted=str(op["prst"]))
    geom = _prst_geom(shape)
    geom.set("prst", op["prst"])
    av = geom.find(qn("a:avLst"))
    if av is not None:
        for gd in list(av):
            av.remove(gd)


@REGISTRY.op("setShapeAdjust", "element", "{adjust:{<gdName>:number,…}} — preset-geometry avLst values", required=("adjust",))
def _set_adjust(deck: Deck, op: dict[str, Any]) -> None:
    _, shape = deck.shape(op)
    geom = _prst_geom(shape)
    av = geom.find(qn("a:avLst"))
    if av is None:
        av = etree.SubElement(geom, qn("a:avLst"))
    for name, value in dict(op["adjust"]).items():
        gd = next((g for g in av if g.get("name") == name), None)
        if gd is None:
            gd = etree.SubElement(av, qn("a:gd"))
            gd.set("name", name)
        gd.set("fmla", f"val {int(value)}")


@REGISTRY.op("setTextAnchor", "element", '{anchor:"top"|"middle"|"bottom"}', required=("anchor",))
def _set_anchor(deck: Deck, op: dict[str, Any]) -> None:
    _, shape = deck.shape(op)
    if op["anchor"] not in ss.VALIGN:
        raise OpError("anchor is top|middle|bottom")
    _text_frame(shape).vertical_anchor = ss.VALIGN[op["anchor"]]


@REGISTRY.op(
    "setTextBodyProps",
    "element",
    '{props:{vert?:"horz"|"eaVert"|"vert"|"vert270"|"wordArtVert",autofit?:"none"|"shrink"|"resize",insets?:{l?,t?,r?,b?} (EMU),wrap?:boolean}}',
    required=("props",),
)
def _set_body_props(deck: Deck, op: dict[str, Any]) -> None:
    _, shape = deck.shape(op)
    tf = _text_frame(shape)
    props = op["props"]
    if props.get("vert"):
        tf._txBody.bodyPr.set("vert", props["vert"])
    if props.get("autofit"):
        tf.auto_size = {
            "none": MSO_AUTO_SIZE.NONE,
            "shrink": MSO_AUTO_SIZE.TEXT_TO_FIT_SHAPE,
            "resize": MSO_AUTO_SIZE.SHAPE_TO_FIT_TEXT,
        }[props["autofit"]]
    insets = props.get("insets") or {}
    for key, attr in (("l", "margin_left"), ("t", "margin_top"), ("r", "margin_right"), ("b", "margin_bottom")):
        if insets.get(key) is not None:
            setattr(tf, attr, to_emu(insets[key]))
    if props.get("wrap") is not None:
        tf.word_wrap = bool(props["wrap"])


ACTIONS = {
    "nextslide": "ppaction://hlinkshowjump?jump=nextslide",
    "previousslide": "ppaction://hlinkshowjump?jump=previousslide",
    "firstslide": "ppaction://hlinkshowjump?jump=firstslide",
    "lastslide": "ppaction://hlinkshowjump?jump=lastslide",
    "lastslideviewed": "ppaction://hlinkshowjump?jump=lastslideviewed",
    "endshow": "ppaction://hlinkshowjump?jump=endshow",
}


@REGISTRY.op("setLink", "element", '{link:{kind:"url",url}|{kind:"slide",slideIndex}|{kind:"action",action}|null}')
def _set_link(deck: Deck, op: dict[str, Any]) -> None:
    _, shape = deck.shape(op)
    if "link" not in op:
        raise OpError("link is required (or null to remove)")
    action = shape.click_action
    link = op["link"]
    if link is None:
        action.hyperlink.address = None
        cnv = shape._element.xpath("./*[1]/p:cNvPr")[0]
        for h in cnv.findall(qn("a:hlinkClick")):
            cnv.remove(h)
    elif link.get("kind") == "url":
        action.hyperlink.address = link["url"]
    elif link.get("kind") == "slide":
        action.target_slide = deck.prs.slides[deck.slide_index(link.get("slideIndex"))]
    elif link.get("kind") == "action":
        if link.get("action") not in ACTIONS:
            raise OpError("action is " + "|".join(ACTIONS), available=list(ACTIONS), wanted=str(link.get("action")))
        cnv = shape._element.xpath("./*[1]/p:cNvPr")[0]
        for h in cnv.findall(qn("a:hlinkClick")):
            cnv.remove(h)
        h = etree.SubElement(cnv, qn("a:hlinkClick"))
        h.set(qn("r:id"), "")
        h.set("action", ACTIONS[link["action"]])
    else:
        raise OpError('link.kind is "url", "slide" or "action"')


@REGISTRY.op("flipElements", "element", '{els:[id,…],axis:"h"|"v"} — target.el unused', required=("els", "axis"))
def _flip(deck: Deck, op: dict[str, Any]) -> None:
    slide = deck.slide(op)
    attr = {"h": "flipH", "v": "flipV"}.get(op["axis"])
    if attr is None:
        raise OpError('axis is "h" or "v"')
    for s in deck.shapes_by_ids(slide, op["els"]):
        xfrm = s._element.xpath("./*[2]/a:xfrm | ./p:xfrm")
        if not xfrm:
            raise OpError(f"element {element_id(s)} cannot be flipped")
        xfrm[0].set(attr, "0" if xfrm[0].get(attr) in ("1", "true") else "1")


def _bounds(shapes: list[Any]) -> tuple[int, int, int, int]:
    return (
        min(s.left for s in shapes),
        min(s.top for s in shapes),
        max(s.left + s.width for s in shapes),
        max(s.top + s.height for s in shapes),
    )


@REGISTRY.op(
    "alignElements",
    "element",
    '{els:[ids],mode:"left"|"centerH"|"right"|"top"|"centerV"|"bottom",to?:"selection"|"slide"}',
    required=("els", "mode"),
)
def _align(deck: Deck, op: dict[str, Any]) -> None:
    slide = deck.slide(op)
    shapes = deck.shapes_by_ids(slide, op["els"])
    if op.get("to") == "slide":
        x0, y0, x1, y1 = 0, 0, deck.prs.slide_width, deck.prs.slide_height
    else:
        x0, y0, x1, y1 = _bounds(shapes)
    mode = op["mode"]
    for s in shapes:
        if mode == "left":
            s.left = x0
        elif mode == "right":
            s.left = x1 - s.width
        elif mode == "centerH":
            s.left = (x0 + x1 - s.width) // 2
        elif mode == "top":
            s.top = y0
        elif mode == "bottom":
            s.top = y1 - s.height
        elif mode == "centerV":
            s.top = (y0 + y1 - s.height) // 2
        else:
            raise OpError("mode is left|centerH|right|top|centerV|bottom")


@REGISTRY.op(
    "distributeElements",
    "element",
    '{els:[ids],axis:"horizontal"|"vertical",to?:"selection"|"slide"}',
    required=("els", "axis"),
)
def _distribute(deck: Deck, op: dict[str, Any]) -> None:
    slide = deck.slide(op)
    shapes = deck.shapes_by_ids(slide, op["els"])
    horizontal = op["axis"] == "horizontal"
    if op["axis"] not in ("horizontal", "vertical"):
        raise OpError("axis is horizontal|vertical")
    pos, size = ("left", "width") if horizontal else ("top", "height")
    shapes.sort(key=lambda s: getattr(s, pos))
    if op.get("to") == "slide":
        start, end = 0, deck.prs.slide_width if horizontal else deck.prs.slide_height
    else:
        start = getattr(shapes[0], pos)
        end = getattr(shapes[-1], pos) + getattr(shapes[-1], size)
    total = sum(getattr(s, size) for s in shapes)
    gap = (end - start - total) / max(1, len(shapes) - 1) if len(shapes) > 1 else 0
    cur = float(start)
    for s in shapes:
        setattr(s, pos, int(round(cur)))
        cur += getattr(s, size) + gap


@REGISTRY.op("setPictureSrcRect", "element", "{srcRect:{l,t,r,b}|null} — crop fractions 0..1, null removes the crop")
def _src_rect(deck: Deck, op: dict[str, Any]) -> None:
    _, shape = deck.shape(op)
    if shape.shape_type != MSO_SHAPE_TYPE.PICTURE:
        raise OpError(f"element {element_id(shape)} is not a picture")
    r = op.get("srcRect") or {}
    shape.crop_left, shape.crop_top = float(r.get("l", 0)), float(r.get("t", 0))
    shape.crop_right, shape.crop_bottom = float(r.get("r", 0)), float(r.get("b", 0))


@REGISTRY.op("setPictureOpacity", "element", "{opacity:0..1}", required=("opacity",))
def _opacity(deck: Deck, op: dict[str, Any]) -> None:
    _, shape = deck.shape(op)
    blip = shape._element.find(".//" + qn("a:blip"))
    if blip is None:
        raise OpError(f"element {element_id(shape)} is not a picture")
    for a in blip.findall(qn("a:alphaModFix")):
        blip.remove(a)
    value = float(op["opacity"])
    if value < 1:
        a = etree.SubElement(blip, qn("a:alphaModFix"))
        a.set("amt", str(int(round(max(0.0, value) * 100000))))


for _name, _sig, _why in (
    ("setConnectorEndpoints", "{p1:{x,y},p2:{x,y},start?:{targetId,idx}|null,end?:{targetId,idx}|null}", "connector re-routing is not ported; delete and addConnector"),
    ("setRedaction", "{label: string|null}", "redaction marks are an app feature"),
    ("groupElements", "{els:[id,id,…]}", "grouping existing shapes is not ported"),
    ("ungroupElement", "{}", "ungrouping is not ported"),
    ("setShapeCustomGeometry", "{path:{w,h,cmds:[…]}}", "freeform geometry is not ported"),
    ("setEffects", "{effects:{shadow?,glow?,reflection?,softEdge?}}", "shape effects are not ported"),
    ("setImageFill", "{source:{mediaPath}|{bytes,ext},tile?}", "picture fills of shapes are not ported"),
):
    REGISTRY.unavailable(_name, "element", _sig, _why)

# ---------------------------------------------------------------- insert ops


def _created(shape: Any) -> dict[str, Any]:
    return {"created": element_id(shape)}


@REGISTRY.op(
    "addElement",
    "insert",
    '{kind:"textbox"|<preset geometry>,offset:{x,y,cx,cy},paragraphs?,fill?,stroke?,adjustments?:{<gd name>:val},bodyPr?:{autoFit?:"shrink"|"resize"}}',
    required=("kind", "offset"),
)
def _add_element(deck: Deck, op: dict[str, Any]) -> dict[str, Any]:
    slide = deck.slide(op)
    b = _box(op, "offset")
    if len(b) < 4:
        raise OpError("offset needs x, y, cx and cy")
    kind = op["kind"]
    if kind == "textbox":
        shape = slide.shapes.add_textbox(b["x"], b["y"], b["cx"], b["cy"])
        shape.text_frame.word_wrap = True
        shape.text_frame.auto_size = MSO_AUTO_SIZE.NONE
    else:
        if kind not in PRESETS:
            raise OpError(f'unknown kind "{kind}" (textbox or a preset geometry)', available=["textbox", *sorted(PRESETS)], wanted=str(kind))
        shape = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, b["x"], b["y"], b["cx"], b["cy"])
        _prst_geom(shape).set("prst", kind)
    if op.get("paragraphs"):
        write_rich(shape.text_frame, op["paragraphs"])
    if op.get("fill") is not None:
        _apply_fill(shape.fill, op["fill"])
    if op.get("stroke"):
        set_solid(shape.line.fill, op["stroke"]["color"])
        if op["stroke"].get("widthEmu") is not None:
            shape.line.width = to_emu(op["stroke"]["widthEmu"])
    if op.get("adjustments"):
        _set_adjust(deck, {"target": {"slide": deck.slide_index(op["target"]), "el": element_id(shape)}, "adjust": op["adjustments"]})
    auto = (op.get("bodyPr") or {}).get("autoFit")
    if auto:
        shape.text_frame.auto_size = MSO_AUTO_SIZE.TEXT_TO_FIT_SHAPE if auto == "shrink" else MSO_AUTO_SIZE.SHAPE_TO_FIT_TEXT
    return _created(shape)


SIDES = {"top": 0, "left": 1, "bottom": 2, "right": 3}


def _endpoint(deck: Deck, slide: Any, value: Any) -> tuple[Any, int, int]:
    if isinstance(value, dict):
        return None, to_emu(value["x"]), to_emu(value["y"])
    s = find_shape(slide, str(value))
    if s is None:
        raise OpError(f'no element "{value}"', reason="target_not_found", available=element_ids(slide), wanted=str(value))
    return s, s.left + s.width // 2, s.top + s.height // 2


@REGISTRY.op(
    "addConnector",
    "insert",
    '{from,to,kind?:"straight"|"elbow"|"curved",fromSide?,toSide?,arrow?:"none"|"end"|"both",line?:{color?,widthPt?,dash?}}',
    note="from/to are element ids or points {x,y}",
    required=("from", "to"),
)
def _add_connector(deck: Deck, op: dict[str, Any]) -> dict[str, Any]:
    slide = deck.slide(op)
    kind = {"straight": MSO_CONNECTOR.STRAIGHT, "elbow": MSO_CONNECTOR.ELBOW, "curved": MSO_CONNECTOR.CURVE}.get(op.get("kind", "straight"))
    if kind is None:
        raise OpError("kind is straight|elbow|curved")
    a, ax, ay = _endpoint(deck, slide, op["from"])
    b, bx, by = _endpoint(deck, slide, op["to"])
    conn = slide.shapes.add_connector(kind, ax, ay, bx, by)
    if a is not None and b is not None:
        horizontal = abs(bx - ax) >= abs(by - ay)
        auto_from = ("right" if bx >= ax else "left") if horizontal else ("bottom" if by >= ay else "top")
        auto_to = {"right": "left", "left": "right", "top": "bottom", "bottom": "top"}[auto_from]
        conn.begin_connect(a, SIDES.get(op.get("fromSide", auto_from), 3))
        conn.end_connect(b, SIDES.get(op.get("toSide", auto_to), 1))
    elif a is not None:
        conn.begin_connect(a, SIDES.get(op.get("fromSide", "right"), 3))
    elif b is not None:
        conn.end_connect(b, SIDES.get(op.get("toSide", "left"), 1))
    line = op.get("line") or {}
    if line.get("color"):
        set_solid(conn.line.fill, line["color"])
    if line.get("widthPt") is not None:
        conn.line.width = Pt(float(line["widthPt"]))
    ln = conn.line._get_or_add_ln()
    if line.get("dash"):
        dash = etree.SubElement(ln, qn("a:prstDash"))
        dash.set("val", str(line["dash"]))
    arrow = op.get("arrow", "end")
    # schema order inside a:ln: headEnd before tailEnd
    if arrow == "both":
        etree.SubElement(ln, qn("a:headEnd")).set("type", "triangle")
    if arrow in ("end", "both"):
        etree.SubElement(ln, qn("a:tailEnd")).set("type", "triangle")
    return _created(conn)


@REGISTRY.op(
    "addPicture",
    "insert",
    "{bytes:local path|dataURL|http(s) URL|base64,ext?,offset:{x,y,cx?,cy?}}",
    note="cx/cy omitted keep the picture's own size (or aspect when one is given)",
    required=("bytes", "offset"),
)
def _add_picture(deck: Deck, op: dict[str, Any]) -> dict[str, Any]:
    slide = deck.slide(op)
    b = _box(op, "offset")
    try:
        blob = load_image_bytes(op["bytes"], deck.bases)
    except Exception as e:  # noqa: BLE001
        raise OpError(f"addPicture: {e}") from e
    pic = slide.shapes.add_picture(io.BytesIO(blob), b.get("x", 0), b.get("y", 0), b.get("cx"), b.get("cy"))
    return _created(pic)


@REGISTRY.op("replacePicture", "insert", "{bytes:local path|dataURL|http(s) URL|base64,ext?}", required=("bytes",))
def _replace_picture(deck: Deck, op: dict[str, Any]) -> None:
    slide, shape = deck.shape(op)
    blip = shape._element.find(".//" + qn("a:blip"))
    if blip is None:
        raise OpError(f"element {element_id(shape)} is not a picture")
    try:
        blob = load_image_bytes(op["bytes"], deck.bases)
    except Exception as e:  # noqa: BLE001
        raise OpError(f"replacePicture: {e}") from e
    _, rid = slide.part.get_or_add_image_part(io.BytesIO(blob))
    blip.set(qn("r:embed"), rid)


@REGISTRY.op(
    "addTable",
    "insert",
    "{rows,cols,offset:{x,y,cx,cy},colWidthsEmu?,rowHeightsEmu?}",
    required=("rows", "cols", "offset"),
)
def _add_table(deck: Deck, op: dict[str, Any]) -> dict[str, Any]:
    slide = deck.slide(op)
    b = _box(op, "offset")
    rows, cols = int(op["rows"]), int(op["cols"])
    if not (1 <= rows <= 100 and 1 <= cols <= 30):
        raise OpError("rows 1-100, cols 1-30")
    frame = slide.shapes.add_table(rows, cols, b["x"], b["y"], b.get("cx", 6000000), b.get("cy", 300000 * rows))
    table = frame.table
    for i, w in enumerate(op.get("colWidthsEmu") or []):
        if i < cols:
            table.columns[i].width = to_emu(w)
    for i, h in enumerate(op.get("rowHeightsEmu") or []):
        if i < rows:
            table.rows[i].height = to_emu(h)
    return _created(frame)


CHARTS = {
    "bar": XL_CHART_TYPE.COLUMN_CLUSTERED,
    "barStacked": XL_CHART_TYPE.COLUMN_STACKED,
    "line": XL_CHART_TYPE.LINE_MARKERS,
    "area": XL_CHART_TYPE.AREA,
    "pie": XL_CHART_TYPE.PIE,
    "doughnut": XL_CHART_TYPE.DOUGHNUT,
    "scatter": XL_CHART_TYPE.XY_SCATTER,
    "radar": XL_CHART_TYPE.RADAR,
}


@REGISTRY.op(
    "addChart",
    "insert",
    '{kind:"bar"|"barStacked"|"line"|"area"|"pie"|"doughnut"|"scatter"|"radar",categories:[…],series:[{name,values:[…]}],offset,title?,colorScheme?:["#RRGGBB"]}',
    note="scatter: categories are the x values",
    required=("kind", "series", "offset"),
)
def _add_chart(deck: Deck, op: dict[str, Any]) -> dict[str, Any]:
    slide = deck.slide(op)
    kind = op["kind"]
    if kind not in CHARTS:
        raise OpError(f'unknown chart kind "{kind}"', available=list(CHARTS), wanted=str(kind))
    b = _box(op, "offset")
    cats = list(op.get("categories") or [])
    if kind == "scatter":
        data: Any = XyChartData()
        for s in op["series"]:
            ser = data.add_series(str(s.get("name", "")))
            for x, y in zip(cats, s.get("values", [])):
                ser.add_data_point(float(x), float(y))
    else:
        data = CategoryChartData()
        data.categories = cats
        for s in op["series"]:
            values = list(s.get("values", []))
            if len(values) != len(cats):
                raise OpError(f'series "{s.get("name")}" has {len(values)} values for {len(cats)} categories')
            data.add_series(str(s.get("name", "")), values)
    frame = slide.shapes.add_chart(CHARTS[kind], b["x"], b["y"], b.get("cx", 5486400), b.get("cy", 3200400), data)
    chart = frame.chart
    if op.get("title"):
        chart.has_title = True
        chart.chart_title.text_frame.text = str(op["title"])
    colors = op.get("colorScheme") or []
    if colors:
        plot = chart.plots[0]
        if kind in ("pie", "doughnut"):
            for i, point in enumerate(plot.series[0].points):
                point.format.fill.solid()
                point.format.fill.fore_color.rgb = _rgb(colors[i % len(colors)])
        else:
            for i, ser in enumerate(plot.series):
                ser.format.fill.solid()
                ser.format.fill.fore_color.rgb = _rgb(colors[i % len(colors)])
    return _created(frame)


for _name, _sig in (
    ("addSmartArt", "{layout,items:[…],offset}"),
    ("addMedia", '{kind:"video"|"audio",bytes,ext,offset}'),
    ("addNarration", "{bytes,ext,durationMs}"),
    ("clearNarration", "{}"),
    ("addModel3d", "{bytes,ext,offset}"),
    ("setModel3dView", "{ax,ay,az,poster?,posterExt?}"),
    ("pasteElements", "{items,dx,dy}"),
):
    REGISTRY.unavailable(_name, "insert", _sig, "needs the GenOffice editor (media, SmartArt or clipboard payloads)")

# ---------------------------------------------------------------- table ops


def _table(shape: Any) -> Any:
    if not getattr(shape, "has_table", False):
        raise OpError(f"element {element_id(shape)} ({kind_of(shape)}) is not a table")
    return shape.table


def _cell(table: Any, row: Any, col: Any) -> Any:
    nr, nc = len(table.rows), len(table.columns)
    if not isinstance(row, int) or not 0 <= row < nr:
        raise OpError(f"row {row} out of range (0-{nr - 1})", reason="out_of_range", valid_range=(0, nr - 1))
    if not isinstance(col, int) or not 0 <= col < nc:
        raise OpError(f"col {col} out of range (0-{nc - 1})", reason="out_of_range", valid_range=(0, nc - 1))
    return table.cell(row, col)


@REGISTRY.op("setTableCell", "table", "{row,col,paragraphs}", required=("row", "col", "paragraphs"))
def _set_table_cell(deck: Deck, op: dict[str, Any]) -> None:
    _, shape = deck.shape(op)
    write_rich(_cell(_table(shape), op["row"], op["col"]).text_frame, op["paragraphs"])


@REGISTRY.op("tableMerge", "table", '{kind:"merge-right"|"merge-down"|"split",row,col}', required=("kind", "row", "col"))
def _table_merge(deck: Deck, op: dict[str, Any]) -> None:
    _, shape = deck.shape(op)
    table = _table(shape)
    cell = _cell(table, op["row"], op["col"])
    if op["kind"] == "split":
        if not cell.is_merge_origin:
            raise OpError("the cell is not the origin of a merged range")
        cell.split()
        return
    h = cell.span_height if cell.is_merge_origin else 1
    w = cell.span_width if cell.is_merge_origin else 1
    if op["kind"] == "merge-right":
        other = _cell(table, op["row"] + h - 1, op["col"] + w)
    elif op["kind"] == "merge-down":
        other = _cell(table, op["row"] + h, op["col"] + w - 1)
    else:
        raise OpError("kind is merge-right|merge-down|split")
    if cell.is_merge_origin:
        cell.split()
    cell.merge(other)


@REGISTRY.op("setTableRowHeight", "table", "{row,hEmu}", required=("row", "hEmu"))
def _row_height(deck: Deck, op: dict[str, Any]) -> None:
    _, shape = deck.shape(op)
    table = _table(shape)
    _cell(table, op["row"], 0)
    table.rows[op["row"]].height = to_emu(op["hEmu"])


@REGISTRY.op("setTableColWidth", "table", "{col,wEmu}", required=("col", "wEmu"))
def _col_width(deck: Deck, op: dict[str, Any]) -> None:
    _, shape = deck.shape(op)
    table = _table(shape)
    _cell(table, 0, op["col"])
    table.columns[op["col"]].width = to_emu(op["wEmu"])


@REGISTRY.op("setTableCellAnchor", "table", '{row,col,anchor:"top"|"middle"|"bottom"}', required=("row", "col", "anchor"))
def _cell_anchor(deck: Deck, op: dict[str, Any]) -> None:
    _, shape = deck.shape(op)
    if op["anchor"] not in ss.VALIGN:
        raise OpError("anchor is top|middle|bottom")
    _cell(_table(shape), op["row"], op["col"]).vertical_anchor = ss.VALIGN[op["anchor"]]


@REGISTRY.op(
    "setTableStyle",
    "table",
    "{firstRow?,lastRow?,firstCol?,lastCol?,bandRow?,bandCol?}",
    note="look flags only; built-in style ids (styleName/styleId) are not ported",
)
def _table_style(deck: Deck, op: dict[str, Any]) -> None:
    _, shape = deck.shape(op)
    table = _table(shape)
    if op.get("styleName") or op.get("styleId"):
        raise OpError("styleName/styleId are not available in the Python port; set the look flags")
    for key, attr in (
        ("firstRow", "first_row"),
        ("lastRow", "last_row"),
        ("firstCol", "first_col"),
        ("lastCol", "last_col"),
        ("bandRow", "horz_banding"),
        ("bandCol", "vert_banding"),
    ):
        if op.get(key) is not None:
            setattr(table, attr, bool(op[key]))


REGISTRY.unavailable("tableStructure", "table", "{action,index,count?}", "inserting/deleting table rows and columns is not ported")
REGISTRY.unavailable("setChart", "table", "{patch:ChartEdit}", "chart edits need the GenOffice editor")

# ---------------------------------------------------------------- slide ops


def _blank_layout(prs: Any) -> Any:
    for layout in prs.slide_layouts:
        if layout.name.lower() == "blank":
            return layout
    return min(prs.slide_layouts, key=lambda l: len(l.placeholders))


def move_slide(prs: Any, old: int, new: int) -> None:
    lst = prs.slides._sldIdLst
    el = list(lst)[old]
    lst.remove(el)
    lst.insert(new, el)


def delete_slide(prs: Any, index: int) -> None:
    lst = prs.slides._sldIdLst
    sid = list(lst)[index]
    lst.remove(sid)
    prs.part.rels.pop(sid.rId)


def _insert_after(deck: Deck, op: dict[str, Any], layout: Any) -> dict[str, Any]:
    target = op.get("target")
    after = deck.slide_index(target) if isinstance(target, dict) and "slide" in target else len(deck.prs.slides) - 1
    deck.prs.slides.add_slide(layout)
    move_slide(deck.prs, len(deck.prs.slides) - 1, after + 1)
    return {"slide": f"s_{after + 1}"}


@REGISTRY.op("deleteSlide", "slide", "{}")
def _delete_slide(deck: Deck, op: dict[str, Any]) -> None:
    index = deck.slide_index(op.get("target"))
    if len(deck.prs.slides) == 1:
        raise OpError("cannot delete the only slide")
    delete_slide(deck.prs, index)


def duplicate_slide(prs: Any, index: int) -> int:
    src = prs.slides[index]
    new = prs.slides.add_slide(src.slide_layout)
    tree = new.shapes._spTree
    for el in list(tree)[2:]:
        tree.remove(el)
    rid_map: dict[str, str] = {}
    for rid, rel in src.part.rels.items():
        if rel.reltype in (RT.SLIDE_LAYOUT, RT.NOTES_SLIDE):
            continue
        if rel.is_external:
            rid_map[rid] = new.part.rels.get_or_add_ext_rel(rel.reltype, rel.target_ref)
        else:
            rid_map[rid] = new.part.relate_to(rel.target_part, rel.reltype)
    for el in list(src.shapes._spTree)[2:]:
        tree.append(copy.deepcopy(el))
    bg = src._element.cSld.find(qn("p:bg"))
    if bg is not None:
        new._element.cSld.insert(0, copy.deepcopy(bg))
    r_attrs = (qn("r:embed"), qn("r:id"), qn("r:link"))
    for node in new._element.iter():
        for attr in r_attrs:
            if node.get(attr) in rid_map:
                node.set(attr, rid_map[node.get(attr)])
    if src.has_notes_slide:
        new.notes_slide.notes_text_frame.text = src.notes_slide.notes_text_frame.text
    move_slide(prs, len(prs.slides) - 1, index + 1)
    return index + 1


@REGISTRY.op("duplicateSlide", "slide", "{} — the copy lands after target.slide")
def _duplicate_slide(deck: Deck, op: dict[str, Any]) -> dict[str, Any]:
    return {"slide": f"s_{duplicate_slide(deck.prs, deck.slide_index(op.get('target')))}"}


@REGISTRY.op("addBlankSlide", "slide", "{} — inserts after target.slide")
def _add_blank(deck: Deck, op: dict[str, Any]) -> dict[str, Any]:
    return _insert_after(deck, op, _blank_layout(deck.prs))


@REGISTRY.op(
    "addSlideWithLayout",
    "slide",
    "{layout:<name>|<index>} — inserts after target.slide (default: after the last slide)",
    required=("layout",),
)
def _add_with_layout(deck: Deck, op: dict[str, Any]) -> dict[str, Any]:
    layouts = list(deck.prs.slide_layouts)
    want = op["layout"]
    if isinstance(want, int) and 0 <= want < len(layouts):
        layout = layouts[want]
    else:
        layout = next((l for l in layouts if l.name == want), None)
        if layout is None:
            raise OpError(f'no layout "{want}"', reason="target_not_found", available=[l.name for l in layouts], wanted=str(want))
    return _insert_after(deck, op, layout)


@REGISTRY.op("moveSlide", "slide", "{to} — 0-based destination index", required=("to",))
def _move_slide(deck: Deck, op: dict[str, Any]) -> None:
    index = deck.slide_index(op.get("target"))
    to = deck.slide_index(op["to"])
    move_slide(deck.prs, index, to)


@REGISTRY.op(
    "setBackground",
    "slide",
    '{kind:"solid"|"gradient"|"reset",color?,from?,to?,angleDeg?}',
    required=("kind",),
)
def _set_background(deck: Deck, op: dict[str, Any]) -> None:
    slide = deck.slide(op)
    kind = op["kind"]
    if kind == "reset":
        bg = slide._element.cSld.find(qn("p:bg"))
        if bg is not None:
            slide._element.cSld.remove(bg)
    elif kind == "solid":
        set_solid(slide.background.fill, op.get("color") or "#FFFFFF")
    elif kind == "gradient":
        _apply_fill(
            slide.background.fill,
            {"stops": [{"pos": 0, "color": op.get("from", "#FFFFFF")}, {"pos": 1, "color": op.get("to", "#000000")}], "angle": op.get("angleDeg", 90)},
        )
    else:
        raise OpError("kind is solid|gradient|reset (image backgrounds are not ported)")


@REGISTRY.op("setHidden", "slide", "{hidden:boolean}", required=("hidden",))
def _set_hidden(deck: Deck, op: dict[str, Any]) -> None:
    slide = deck.slide(op)
    if op["hidden"]:
        slide._element.set("show", "0")
    elif "show" in slide._element.attrib:
        del slide._element.attrib["show"]


TRANSITIONS = ("none", "fade", "push", "wipe", "cut", "split", "cover", "pull", "zoom")


def _transition(slide: Any) -> Any:
    sld = slide._element
    tr = sld.find(qn("p:transition"))
    if tr is None:
        tr = etree.Element(qn("p:transition"))
        anchor = sld.find(qn("p:clrMapOvr"))
        (anchor if anchor is not None else sld.cSld).addnext(tr)
    return tr


@REGISTRY.op("setTransition", "slide", '{kind:"none"|"fade"|"push"|"wipe"|"cut"|"split"|"cover"|"pull"|"zoom"}', required=("kind",))
def _set_transition(deck: Deck, op: dict[str, Any]) -> None:
    slide = deck.slide(op)
    if op["kind"] not in TRANSITIONS:
        raise OpError("unknown transition", available=list(TRANSITIONS), wanted=str(op["kind"]))
    tr = _transition(slide)
    for child in list(tr):
        tr.remove(child)
    if op["kind"] != "none":
        etree.SubElement(tr, qn(f"p:{op['kind']}"))


@REGISTRY.op("setAdvanceTime", "slide", "{ms:number|null} — auto-advance; null clears")
def _advance(deck: Deck, op: dict[str, Any]) -> None:
    tr = _transition(deck.slide(op))
    if op.get("ms") is None:
        tr.attrib.pop("advTm", None)
    else:
        tr.set("advTm", str(int(op["ms"])))


@REGISTRY.op("setNotes", "slide", "{text} — speaker notes", required=("text",))
def _set_notes(deck: Deck, op: dict[str, Any]) -> None:
    deck.slide(op).notes_slide.notes_text_frame.text = str(op["text"])


for _name, _sig, _why in (
    ("pasteSlide", "{afterIndex,bundle|png,mode?}", "clipboard payload"),
    ("insertSlidePptx", "{source,at?,replace?}", "use slides_replace with a page spec"),
    ("setSlideLayout", "{layout?}", "re-binding placeholders to another layout is not ported"),
    ("setAnimations", "{items:[…]}", "animation timelines are not ported"),
    ("addAnimation", "{effect,kind?,trigger?,…}", "animation timelines are not ported"),
    ("removeAnimation", "{seq}", "animation timelines are not ported"),
    ("reorderAnimation", "{seq,to}", "animation timelines are not ported"),
    ("addComment", "{text,author}", "slide comments are not ported"),
    ("deleteComment", "{authorId,idx}", "slide comments are not ported"),
):
    REGISTRY.unavailable(_name, "slide", _sig, _why)

# ---------------------------------------------------------------- deck ops


@REGISTRY.op("setSlideSize", "deck", "{cx,cy} — EMU page size, whole deck", required=("cx", "cy"))
def _slide_size(deck: Deck, op: dict[str, Any]) -> None:
    deck.prs.slide_width = to_emu(op["cx"])
    deck.prs.slide_height = to_emu(op["cy"])


def replace_in_paragraph(p: Any, pattern: re.Pattern[str], repl: Any) -> int:
    """Replace across the runs of one paragraph; a match spanning runs keeps the first run's format."""
    runs = p.runs
    text = "".join(r.text for r in runs)
    matches = list(pattern.finditer(text))
    if not matches:
        return 0
    # single-run matches keep their run; anything else collapses into the first run
    spans, pos = [], 0
    for r in runs:
        spans.append((pos, pos + len(r.text)))
        pos += len(r.text)
    inside = all(any(s <= m.start() and m.end() <= e for s, e in spans) for m in matches)
    if inside:
        for r in runs:
            r.text = pattern.sub(repl, r.text)
    else:
        runs[0].text = pattern.sub(repl, text)
        for r in runs[1:]:
            r._r.getparent().remove(r._r)
    return len(matches)


def text_frames(slide: Any) -> Iterator[tuple[Any, Any]]:
    """(shape, text frame) of every text box, shape and table cell on a slide, groups included."""
    for s in iter_shapes(slide.shapes):
        if getattr(s, "has_text_frame", False):
            yield s, s.text_frame
        if getattr(s, "has_table", False):
            for row in s.table.rows:
                for cell in row.cells:
                    yield s, cell.text_frame


@REGISTRY.op(
    "findReplace",
    "deck",
    "{find,replace,matchCase?,slideIndex?} — whole deck unless slideIndex",
    required=("find", "replace"),
)
def _find_replace(deck: Deck, op: dict[str, Any]) -> dict[str, Any]:
    flags = 0 if op.get("matchCase") else re.I
    pattern = re.compile(re.escape(str(op["find"])), flags)
    replacement = str(op["replace"])
    slides = deck.slides if op.get("slideIndex") is None else [deck.prs.slides[deck.slide_index(op["slideIndex"])]]
    count = 0
    for slide in slides:
        for _, tf in text_frames(slide):
            for p in tf.paragraphs:
                count += replace_in_paragraph(p, pattern, lambda _m: replacement)
    return {"replaced": count}


def _theme_part(prs: Any) -> Any:
    return prs.slide_master.part.part_related_by(RT.THEME)


THEME_SLOTS = ("dk1", "lt1", "dk2", "lt2", "accent1", "accent2", "accent3", "accent4", "accent5", "accent6", "hlink", "folHlink")


@REGISTRY.op(
    "applyTheme",
    "deck",
    '{name?,colors:{dk1?,lt1?,dk2?,lt2?,accent1?..accent6?,hlink?,folHlink?},majorFont?,minorFont?} — "#RRGGBB" slots, whole deck',
)
def _apply_theme(deck: Deck, op: dict[str, Any]) -> None:
    part = _theme_part(deck.prs)
    root = etree.fromstring(part.blob)
    scheme = root.find(".//a:clrScheme", NS)
    for slot, value in (op.get("colors") or {}).items():
        if slot not in THEME_SLOTS:
            raise OpError(f'unknown theme slot "{slot}"', available=list(THEME_SLOTS), wanted=slot)
        el = scheme.find(f"a:{slot}", NS)
        for child in list(el):
            el.remove(child)
        etree.SubElement(el, f"{{{A_NS}}}srgbClr").set("val", ss.parse_color(value)[0])
    for key, tag in (("majorFont", "a:majorFont"), ("minorFont", "a:minorFont")):
        if op.get(key):
            latin = root.find(f".//{tag}/a:latin", NS)
            latin.set("typeface", str(op[key]))
    if op.get("name"):
        root.set("name", str(op["name"]))
        if scheme is not None:
            scheme.set("name", str(op["name"]))
    part.blob = etree.tostring(root, xml_declaration=True, encoding="UTF-8", standalone=True)


for _name, _sig in (
    ("applyHeaderFooter", "{settings:{footer?,slideNum?,date?,dateAuto?}}"),
    ("setSections", "{sections:[{id,name,slideIndices},…]}"),
    ("addSection", "{atSlideIndex,name}"),
    ("renameSection", "{id,name}"),
    ("removeSection", "{id}"),
    ("moveSection", '{id,dir:"up"|"down"}'),
):
    REGISTRY.unavailable(_name, "deck", _sig, "headers/footers and sections are not ported")

# ================================================================ reading


def kind_of(shape: Any) -> str:
    st = shape.shape_type
    if st == MSO_SHAPE_TYPE.GROUP:
        return "group"
    if st == MSO_SHAPE_TYPE.PICTURE or shape._element.tag == qn("p:pic"):
        return "picture"
    if getattr(shape, "has_table", False):
        return "table"
    if getattr(shape, "has_chart", False):
        return "chart"
    if shape._element.tag == qn("p:cxnSp"):
        return "connector"
    if shape.is_placeholder:
        return "placeholder"
    if st == MSO_SHAPE_TYPE.TEXT_BOX:
        return "textbox"
    return "shape"


def shape_text(shape: Any) -> str:
    if getattr(shape, "has_text_frame", False):
        return "\n".join(p.text for p in shape.text_frame.paragraphs)
    if getattr(shape, "has_table", False):
        return "\n".join(" | ".join(c.text for c in row.cells) for row in shape.table.rows)
    return ""


def _rpr_values(rpr: Any) -> dict[str, Any]:
    if rpr is None:
        return {}
    out: dict[str, Any] = {}
    if rpr.get("sz"):
        out["fontSize"] = int(rpr.get("sz")) / 100
    for attr, key in (("b", "bold"), ("i", "italic")):
        if rpr.get(attr) is not None:
            out[key] = rpr.get(attr) in ("1", "true")
    latin = rpr.find(qn("a:latin"))
    if latin is not None and latin.get("typeface"):
        out["fontFamily"] = latin.get("typeface")
    fill = rpr.find(qn("a:solidFill"))
    if fill is not None and len(fill):
        clr = fill[0]
        val = clr.get("val")
        out["color"] = f"#{val}" if clr.tag == qn("a:srgbClr") else f"scheme:{val}"
    return out


def _lvl1(container: Any) -> tuple[Any, Any]:
    """(lvl1pPr, its defRPr) of a lstStyle / txStyles child, or (None, None)."""
    if container is None:
        return None, None
    lvl = container.find(qn("a:lvl1pPr"))
    return lvl, (lvl.find(qn("a:defRPr")) if lvl is not None else None)


def effective(shape: Any, prs: Any) -> dict[str, Any] | None:
    """First run's font size / family / color / bold / italic and paragraph align, with where each comes from."""
    if not getattr(shape, "has_text_frame", False):
        return None
    tf = shape.text_frame
    para = next((p for p in tf.paragraphs if p.runs), tf.paragraphs[0] if tf.paragraphs else None)
    if para is None:
        return None
    candidates: list[tuple[str, Any, Any]] = []  # (src, rPr-like, pPr-like)
    run = para.runs[0] if para.runs else None
    ppr = para._p.find(qn("a:pPr"))
    candidates.append(("run", run._r.find(qn("a:rPr")) if run is not None else None, None))
    candidates.append(("paragraph defRPr", ppr.find(qn("a:defRPr")) if ppr is not None else None, ppr))
    lvl, defrpr = _lvl1(tf._txBody.find(qn("a:lstStyle")))
    candidates.append(("shape lstStyle", defrpr, lvl))
    is_title = False
    if shape.is_placeholder:
        try:
            is_title = shape.placeholder_format.type in (PP_PLACEHOLDER.TITLE, PP_PLACEHOLDER.CENTER_TITLE)
        except ValueError:
            is_title = False
        base = getattr(shape, "_base_placeholder", None)
        for src in ("layout placeholder", "master placeholder"):
            if base is None:
                break
            body = base._element.find(qn("p:txBody"))
            if body is not None:
                lvl, defrpr = _lvl1(body.find(qn("a:lstStyle")))
                candidates.append((src, defrpr, lvl))
                first_r = body.find(".//" + qn("a:rPr"))
                candidates.append((src, first_r, None))
            base = getattr(base, "_base_placeholder", None)
        styles = prs.slide_master._element.find(qn("p:txStyles"))
        name = "titleStyle" if is_title else "bodyStyle"
        if styles is not None:
            lvl, defrpr = _lvl1(styles.find(qn(f"p:{name}")))
            candidates.append((f"master {name}", defrpr, lvl))
    dts = prs.part._element.find(qn("p:defaultTextStyle"))
    lvl, defrpr = _lvl1(dts)
    candidates.append(("presentation defaultTextStyle", defrpr, lvl))

    out: dict[str, Any] = {}
    src: dict[str, str] = {}
    for where, rpr, pprl in candidates:
        for k, v in _rpr_values(rpr).items():
            if k not in out:
                out[k], src[k] = v, where
        if pprl is not None and pprl.get("algn") and "align" not in out:
            out["align"], src["align"] = pprl.get("algn"), where
    family = out.get("fontFamily")
    if family is None or family.startswith("+"):
        major = is_title or (family or "").startswith("+mj")
        theme = _theme_fonts(prs)
        out["fontFamily"] = theme.get("major" if major else "minor")
        src["fontFamily"] = "theme major" if major else "theme minor"
    out["src"] = src
    return out


def _theme_fonts(prs: Any) -> dict[str, str]:
    try:
        root = etree.fromstring(_theme_part(prs).blob)
    except Exception:  # noqa: BLE001 - a deck without a readable theme just reports no family
        return {}
    out = {}
    for key, tag in (("major", "a:majorFont"), ("minor", "a:minorFont")):
        latin = root.find(f".//{tag}/a:latin", NS)
        if latin is not None:
            out[key] = latin.get("typeface")
    return out


def _link(shape: Any, prs: Any) -> dict[str, Any] | None:
    try:
        action = shape.click_action
    except Exception:  # noqa: BLE001 - group / graphic frames have no click action
        return None
    h = shape._element.xpath("./*[1]/p:cNvPr/a:hlinkClick")
    if h and h[0].get("action", "").startswith("ppaction://hlinkshowjump"):
        return {"action": h[0].get("action").split("jump=")[-1]}
    if action.target_slide is not None:
        return {"slide": list(prs.slides).index(action.target_slide)}
    if action.hyperlink.address:
        return {"url": action.hyperlink.address}
    return None


def _box_out(shape: Any, unit: str | None) -> dict[str, Any]:
    b = {"x": shape.left or 0, "y": shape.top or 0, "cx": shape.width or 0, "cy": shape.height or 0}
    if unit:
        return {k: emu_to(v, unit) for k, v in b.items()}
    return b


def describe(shape: Any, prs: Any, *, full: bool, limit: int | None, unit: str | None) -> dict[str, Any]:
    d: dict[str, Any] = {"id": element_id(shape), "name": shape.name, "kind": kind_of(shape), "box": _box_out(shape, unit)}
    if unit:
        d["unit"] = unit
    text = shape_text(shape)
    if text:
        d["text"], truncated = clip(text, None if full else limit)
        if truncated:
            d["truncated"] = True
    eff = effective(shape, prs)
    if eff and text:
        d["effective"] = eff
    link = _link(shape, prs)
    if link:
        d["link"] = link
    if getattr(shape, "has_table", False):
        t: dict[str, Any] = {"rows": len(shape.table.rows), "cols": len(shape.table.columns)}
        if full:
            t["cells"] = [[c.text for c in row.cells] for row in shape.table.rows]
        d["table"] = t
    if d["kind"] == "group":
        d["children"] = [describe(c, prs, full=full, limit=limit, unit=unit) for c in shape.shapes]
    return d


READ_UNITS = ("in", "cm", "pt", "px")


def open_pptx(path: Path) -> Any:
    try:
        return Presentation(str(path))
    except Exception as e:  # noqa: BLE001 - python-pptx raises several types on a broken package
        raise GenOfficeError(
            EXIT.conversion, f"cannot open {path.name} as a .pptx: {e}", reason="conversion_failed"
        ) from e


def read(
    ctx: Context,
    file: str,
    *,
    slide: int | None = None,
    full: bool = False,
    layouts: bool = False,
    max_chars: int | None = None,
    units: str | None = None,
) -> CommandResult:
    path = ctx.input_file(file)
    if units is not None and units not in READ_UNITS:
        raise GenOfficeError(EXIT.usage, f"units must be one of {', '.join(READ_UNITS)}", reason="invalid_argument")
    prs = open_pptx(path)
    n = len(prs.slides)
    if slide is not None and not 0 <= slide < n:
        raise GenOfficeError(
            EXIT.usage, f"slide {slide} out of range (0-{n - 1})", {"valid_range": [0, n - 1]}, reason="out_of_range",
            suggestion=f"use a 0-based slide between 0 and {n - 1}",
        )
    limit = max_chars if max_chars is not None else PREVIEW_CHARS
    slides = []
    for i, s in enumerate(prs.slides):
        if slide is not None and i != slide:
            continue
        entry: dict[str, Any] = {"id": f"s_{i}", "index": i, "layout": s.slide_layout.name}
        if s._element.get("show") == "0":
            entry["hidden"] = True
        entry["elements"] = [describe(sh, prs, full=full, limit=limit, unit=units) for sh in s.shapes]
        if full and s.has_notes_slide:
            entry["notes"] = s.notes_slide.notes_text_frame.text
        slides.append(entry)
    detail: dict[str, Any] = {"slide_size": {"cx": prs.slide_width, "cy": prs.slide_height}, "slide_count": n, "slides": slides}
    if layouts:
        detail["layouts"] = [{"index": i, "name": l.name} for i, l in enumerate(prs.slide_layouts)]
    return CommandResult(summary=f"{path.name}: {n} slide{'s' if n != 1 else ''}", detail=detail)


def info(path: Path) -> dict[str, Any]:
    prs = open_pptx(path)
    titles = []
    for s in prs.slides:
        t = s.shapes.title
        titles.append(t.text_frame.text if t is not None and t.has_text_frame else None)
    return {
        "format": "pptx",
        "slides": len(prs.slides),
        "slide_size": {"cx": prs.slide_width, "cy": prs.slide_height},
        "titles": titles,
        "layouts": len(prs.slide_layouts),
        "size_bytes": path.stat().st_size,
    }


def to_text(path: Path) -> str:
    prs = open_pptx(path)
    parts = []
    for i, s in enumerate(prs.slides):
        parts.append(f"## Slide {i + 1}")
        for sh in iter_shapes(s.shapes):
            text = shape_text(sh).strip()
            if text:
                parts.append(text)
        if s.has_notes_slide and s.notes_slide.notes_text_frame.text.strip():
            parts.append(f"> Notes: {s.notes_slide.notes_text_frame.text.strip()}")
        parts.append("")
    return "\n\n".join(parts).strip() + "\n"


# ================================================================ apply / create


def _save(ctx: Context, prs: Any, path: Path, out: str | None, force: bool) -> Path:
    target = ctx.output_file(out, force=force, editing=path) if out else path
    prs.save(str(target))
    return target


def apply(
    ctx: Context,
    file: str,
    ops: Any,
    *,
    dry_run: bool = False,
    mode: BatchMode = "atomic",
    out: str | None = None,
    force: bool = False,
    ops_base: str | None = None,
) -> CommandResult:
    path = ctx.input_file(file)
    prs = open_pptx(path)
    bases = [ctx.base] + ([Path(ops_base)] if ops_base else [])
    outcome = REGISTRY.run_batch(ops, Deck(prs, bases), mode)
    if dry_run:
        return batch_result(CommandResult(summary=f"dry run: {outcome.applied} of {outcome.total} ops valid, nothing written"), outcome)
    target = _save(ctx, prs, path, out, force)
    return batch_result(
        CommandResult(summary=f"applied {outcome.applied} op{'s' if outcome.applied != 1 else ''} to {target.name}", output_path=str(target)),
        outcome,
    )


def new_deck() -> Any:
    """A blank 16:9 deck; the default template's 4:3 layouts are stretched to the wider page."""
    prs = Presentation()
    factor = SLIDE_W_EMU / prs.slide_width
    prs.slide_width, prs.slide_height = SLIDE_W_EMU, SLIDE_H_EMU
    for owner in [prs.slide_master, *prs.slide_layouts]:
        for sh in owner.shapes:
            if sh.left is not None and sh.width is not None:
                sh.left, sh.width = int(sh.left * factor), int(sh.width * factor)
    return prs


def create_from_ops(ctx: Context, ops: Any, out: str, *, force: bool = False, ops_base: str | None = None) -> CommandResult:
    target = ctx.output_file(out, force=force)
    prs = new_deck()
    prs.slides.add_slide(_blank_layout(prs))
    bases = [ctx.base] + ([Path(ops_base)] if ops_base else [])
    outcome = REGISTRY.run_batch(ops, Deck(prs, bases), "atomic")
    prs.save(str(target))
    n = len(prs.slides)
    return batch_result(
        CommandResult(summary=f"created {target.name}: {n} slide{'s' if n != 1 else ''}", output_path=str(target), detail={"slides": n}),
        outcome,
    )


# ---------------------------------------------------------------- spec path


def _load_spec_input(ctx: Context, spec_obj: Any, spec_path: str | None) -> tuple[list[tuple[str, dict]], list[Path], Path | None]:
    """(label, page) pairs, base dirs for images, and the anchor path for outline/style lookup."""
    try:
        if spec_path:
            p = ctx.resolve(spec_path)
            if p.is_dir():
                files = ss.page_files(p)
                if not files:
                    raise ValueError(f"no *.json page files in {p}")
                pages = []
                for f in files:
                    page = ss.read_json(f)
                    if not isinstance(page, dict):
                        raise ValueError(f"{f.name}: a page file holds one page object")
                    pages.append((f.name, page))
                return pages, [ctx.base, p], p
            if not p.is_file():
                raise GenOfficeError(EXIT.file, f"file not found: {spec_path}", reason="file_not_found")
            spec_obj = ss.read_json(p)
            pages_list = ss.pages_of(spec_obj)
            labels = [p.name] if len(pages_list) == 1 else [f"{p.name}#{i + 1}" for i in range(len(pages_list))]
            return list(zip(labels, pages_list)), [ctx.base, p.parent], p
        pages_list = ss.pages_of(spec_obj)
        return [(f"page {i + 1}", pg) for i, pg in enumerate(pages_list)], [ctx.base], None
    except ValueError as e:
        raise GenOfficeError(EXIT.usage, str(e), reason="invalid_json" if "JSON" in str(e) else "invalid_argument",
                             suggestion="fix the spec (guide slides spec)") from e


def _outline_and_style(ctx: Context, anchor: Path | None, outline: str | None) -> tuple[dict | None, set[str] | None, list[str]]:
    notes: list[str] = []
    outline_path = ctx.resolve(outline) if outline else (ss.find_beside(anchor, "outline.json") if anchor else None)
    data = None
    if outline_path is not None:
        if not outline_path.is_file():
            raise GenOfficeError(EXIT.file, f"file not found: {outline}", reason="file_not_found")
        data = ss.read_json(outline_path)
    elif anchor is not None:
        notes.append("no outline.json beside the spec or one folder up: pages not checked against an outline")
    style_path = ss.find_beside(outline_path or anchor, "style.md") if (outline_path or anchor) else None
    style = ss.palette(style_path.read_text(encoding="utf-8")) if style_path else None
    if style_path is None and anchor is not None:
        notes.append("no style.md beside the spec or one folder up: colors not checked")
    return data, style, notes


def _check_against(pages: list[tuple[str, dict]], outline: dict | None, style: set[str] | None, start: int = 0) -> tuple[dict, list[dict]]:
    """Per-page outline findings and off-palette colors; returns (summary, errors)."""
    findings, off, errors = [], {}, []
    entries = outline.get("pages", []) if isinstance(outline, dict) else None
    for i, (label, page) in enumerate(pages):
        entry = entries[start + i] if entries is not None and start + i < len(entries) else None
        res = ss.check_page(page, entry, style)
        for f in res["findings"]:
            item = {"page": label, **f}
            findings.append(item)
            if f["level"] == "error":
                errors.append(item)
        if res["offPalette"]:
            off[label] = res["offPalette"]
    return {"outline": {"findings": findings}, "style": {"offPalette": off}}, errors


def create_from_spec(
    ctx: Context,
    *,
    spec: Any = None,
    spec_path: str | None = None,
    outline: str | None = None,
    out: str,
    force: bool = False,
) -> CommandResult:
    pages, bases, anchor = _load_spec_input(ctx, spec, spec_path)
    target = ctx.output_file(out, force=force)
    outline_data, style, notes = _outline_and_style(ctx, anchor, outline)
    if outline_data is not None:
        errors, warnings = ss.check_outline(outline_data)
        if errors:
            raise GenOfficeError(EXIT.usage, f"outline has {len(errors)} error(s); nothing was built", {"errors": errors, "warnings": warnings},
                                 reason="invalid_argument", suggestion="fix the outline (slides_check) and build again")
        expected = len(outline_data.get("pages", []))
        if expected != len(pages):
            raise GenOfficeError(EXIT.usage, f"the outline plans {expected} pages but the spec has {len(pages)}",
                                 {"outline_pages": expected, "spec_pages": len(pages)}, reason="invalid_argument",
                                 suggestion="write one page file per outline entry before building")
    checks, errors = _check_against(pages, outline_data, style)
    if errors:
        raise GenOfficeError(EXIT.usage, f"{len(errors)} page(s) disagree with the outline; nothing was built", {**checks, "errors": errors},
                             reason="invalid_argument", suggestion="fix the named page files and build again")
    prs = new_deck()
    layout = _blank_layout(prs)
    issues, failures, built = [], [], 0
    for label, page in pages:
        slide = prs.slides.add_slide(layout)
        page_issues, page_failures, kept = ss.build_page(slide, page, bases, label)
        issues += page_issues
        failures += page_failures
        if kept == 0:
            delete_slide(prs, len(prs.slides) - 1)
            continue
        built += 1
        if page.get("title"):
            slide.name = str(page["title"])[:255]
    if built == 0:
        raise GenOfficeError(EXIT.conversion, "no page survived validation; nothing was built", {"issues": issues, "imageFailures": failures},
                             reason="conversion_failed", suggestion="fix the pages listed in detail.issues")
    prs.save(str(target))
    detail: dict[str, Any] = {"slides": built, "issues": issues, "imageFailures": failures}
    if outline_data is not None or style is not None:
        detail.update(checks)
    if notes:
        detail["notes"] = notes
    warns = [Warning("page_dropped", f"{len(pages) - built} page(s) had no surviving element")] if built < len(pages) else []
    return CommandResult(summary=f"created {target.name}: {built} slide{'s' if built != 1 else ''}", output_path=str(target), detail=detail, warnings=warns)


def check(ctx: Context, file: str, *, outline: str | None = None, page: int | None = None) -> CommandResult:
    """slides check: an outline.json, or one page spec against its outline entry and style.md."""
    path = ctx.input_file(file)
    try:
        data = ss.read_json(path)
    except ValueError as e:
        raise GenOfficeError(EXIT.usage, str(e), reason="invalid_json") from e
    if isinstance(data, dict) and isinstance(data.get("pages"), list) and ("core_hook" in data or "topic" in data):
        errors, warnings = ss.check_outline(data)
        detail = {"pages": len(data["pages"]), "errors": errors, "warnings": warnings}
        if errors:
            raise GenOfficeError(EXIT.usage, f"outline has {len(errors)} error(s)", detail, reason="invalid_argument",
                                 suggestion="fix every error in the outline file, then check again")
        return CommandResult(summary=f"outline ok: {len(data['pages'])} pages, {len(warnings)} warning(s)", detail=detail)
    if not isinstance(data, dict) or "elements" not in data:
        raise GenOfficeError(EXIT.usage, "not an outline ({core_hook, pages}) nor a page spec ({elements})", reason="invalid_argument")
    outline_data, style, notes = _outline_and_style(ctx, path, outline)
    number = page + 1 if page is not None else ss.page_number(path)  # page: 0-based outline entry
    entry = None
    if outline_data is not None:
        entries = outline_data.get("pages", [])
        if number is None or not 1 <= number <= len(entries):
            notes.append(f"page number {number} has no outline entry (name the file NN.json or pass page)")
        else:
            entry = entries[number - 1]
    res = ss.check_page(data, entry, style)
    prs = new_deck()
    slide = prs.slides.add_slide(_blank_layout(prs))
    issues, failures, kept = ss.build_page(slide, data, [ctx.base, path.parent], path.name)
    audit_issues = _audit_slide(prs, 0, slide) if kept else []
    detail = {
        "audit": audit_issues,
        "issues": issues,
        "imageFailures": failures,
        "outline": {"findings": res["findings"], **({"entry": number} if entry is not None else {})},
        "style": {"offPalette": res["offPalette"]},
    }
    if notes:
        detail["notes"] = notes
    errors = [f for f in res["findings"] if f["level"] == "error"] + [i for i in issues if i["level"] == "error"]
    if errors:
        raise GenOfficeError(EXIT.usage, f"{path.name}: {len(errors)} error(s)", detail, reason="invalid_argument",
                             suggestion="fix the page file until detail.outline.findings has no errors, then check again")
    open_items = len(audit_issues) + len(res["findings"]) + len(res["offPalette"])
    return CommandResult(summary=f"{path.name}: {'clean' if not open_items else f'{open_items} item(s) to fix'}", detail=detail)


def replace(
    ctx: Context,
    file: str,
    slide: int,
    spec_path: str,
    *,
    outline: str | None = None,
    out: str | None = None,
    force: bool = False,
) -> CommandResult:
    path = ctx.input_file(file)
    prs = open_pptx(path)
    n = len(prs.slides)
    if not isinstance(slide, int) or not 0 <= slide < n:
        raise GenOfficeError(EXIT.usage, f"slide {slide} out of range (0-{n - 1})", {"valid_range": [0, n - 1]}, reason="out_of_range")
    pages, bases, anchor = _load_spec_input(ctx, None, spec_path)
    if len(pages) != 1:
        raise GenOfficeError(EXIT.usage, "replace takes a one-page spec file", reason="invalid_argument")
    outline_data, style, notes = _outline_and_style(ctx, anchor, outline)
    checks, errors = _check_against(pages, outline_data, style, start=slide)
    if errors:
        raise GenOfficeError(EXIT.usage, "the page disagrees with its outline entry; nothing was written", {**checks, "errors": errors},
                             reason="invalid_argument", suggestion="fix the page file, then replace again")
    new = prs.slides.add_slide(_blank_layout(prs))
    issues, failures, kept = ss.build_page(new, pages[0][1], bases, pages[0][0])
    if kept == 0:
        raise GenOfficeError(EXIT.conversion, "no element of the page survived validation", {"issues": issues, "imageFailures": failures},
                             reason="conversion_failed")
    move_slide(prs, len(prs.slides) - 1, slide)
    delete_slide(prs, slide + 1)
    target = _save(ctx, prs, path, out, force)
    detail = {"slide": f"s_{slide}", "issues": issues, "imageFailures": failures, **checks}
    if notes:
        detail["notes"] = notes
    return CommandResult(summary=f"replaced slide {slide} of {target.name}", output_path=str(target), detail=detail)


# ================================================================ audit


def _text_metrics(shape: Any, prs: Any) -> tuple[list[dict[str, Any]], float]:
    eff = effective(shape, prs) or {}
    default = float(eff.get("fontSize") or 18.0)
    paragraphs = []
    for p in shape.text_frame.paragraphs:
        runs = [(r.text, r.font.size.pt if r.font.size else default) for r in p.runs]
        if not runs:
            runs = [("", default)]
        paragraphs.append(
            {
                "runs": runs,
                "lineSpacingPct": p.line_spacing * 100 if isinstance(p.line_spacing, float) else None,
                "spaceBeforePt": p.space_before.pt if p.space_before is not None else None,
                "spaceAfterPt": p.space_after.pt if p.space_after is not None else None,
            }
        )
    return paragraphs, default


def _insets(tf: Any) -> tuple[int, int, int, int]:
    return (
        tf.margin_left if tf.margin_left is not None else 91440,
        tf.margin_top if tf.margin_top is not None else 45720,
        tf.margin_right if tf.margin_right is not None else 91440,
        tf.margin_bottom if tf.margin_bottom is not None else 45720,
    )


def _audit_slide(prs: Any, index: int, slide: Any) -> list[dict[str, Any]]:
    W, H = prs.slide_width, prs.slide_height
    issues: list[dict[str, Any]] = []
    texts, pictures = [], []
    for sh in slide.shapes:
        if sh.left is None or sh.width is None:
            continue
        eid = element_id(sh)
        path = f"s_{index}/{eid}"
        x, y, cx, cy = sh.left, sh.top, sh.width, sh.height

        def suggest(box: dict[str, int]) -> dict[str, Any]:
            return {"op": "setTransform", "target": {"slide": index, "el": eid}, "box": box}

        if x >= W or y >= H or x + cx <= 0 or y + cy <= 0:
            nx, ny = min(max(0, x), max(0, W - cx)), min(max(0, y), max(0, H - cy))
            issues.append({"code": "off_slide", "level": "error", "path": path, "message": f"{eid} lies entirely off the slide",
                           "suggest": suggest({"x": nx, "y": ny, "cx": min(cx, W), "cy": min(cy, H)})})
            continue
        if x < 0 or y < 0 or x + cx > W or y + cy > H:
            nx, ny = max(0, x), max(0, y)
            issues.append({"code": "out_of_bounds", "level": "warning", "path": path, "message": f"{eid} sticks out of the slide",
                           "suggest": suggest({"x": nx, "y": ny, "cx": min(cx, W - nx), "cy": min(cy, H - ny)})})
        kind = kind_of(sh)
        if getattr(sh, "has_text_frame", False) and sh.text_frame.text.strip():
            texts.append(sh)
            tf = sh.text_frame
            body = tf._txBody.bodyPr
            if body.find(qn("a:normAutofit")) is None:  # shrink-on-overflow text never overflows
                l, t, r, b = _insets(tf)
                width_pt = (cx - l - r) / EMU_PER_PT
                paragraphs, _ = _text_metrics(sh, prs)
                wrap = tf.word_wrap is not False
                height_pt, widest = ss.measure(paragraphs, width_pt if wrap else 1e9)
                need = int(height_pt * EMU_PER_PT) + t + b
                if widest > width_pt + 1 and wrap:
                    grow = int(widest * EMU_PER_PT) + l + r
                    issues.append({"code": "text_overflow_width", "level": "warning", "path": path,
                                   "message": f"{eid}: a word is wider than the box", "suggest": suggest({"x": x, "y": y, "cx": min(grow, W - x), "cy": cy})})
                if need > cy * 1.05:
                    ncy = need
                    ny = y if y + ncy <= H else max(0, H - ncy)
                    issues.append({"code": "text_overflow", "level": "warning", "path": path,
                                   "message": f"{eid}: text needs about {round(need / EMU_PER_PT)}pt, the box is {round(cy / EMU_PER_PT)}pt tall",
                                   "suggest": suggest({"x": x, "y": ny, "cx": cx, "cy": min(ncy, H)})})
        if kind == "picture":
            pictures.append(sh)
            try:
                iw, ih = sh.image.size
                cw = iw * (1 - sh.crop_left - sh.crop_right)
                ch = ih * (1 - sh.crop_top - sh.crop_bottom)
                if cw > 0 and ch > 0 and cy > 0:
                    src_ar, box_ar = cw / ch, cx / cy
                    if abs(box_ar / src_ar - 1) > 0.05:
                        fixed_cy = int(cx / src_ar)
                        issues.append({"code": "picture_distorted", "level": "warning", "path": path,
                                       "message": f"{eid}: box aspect {box_ar:.2f} vs picture {src_ar:.2f}",
                                       "suggest": suggest({"x": x, "y": y, "cx": cx, "cy": fixed_cy})})
            except Exception:  # noqa: BLE001 - linked or unreadable pictures are skipped
                pass
    for group in (texts, pictures):
        for i in range(len(group)):
            for j in range(i + 1, len(group)):
                a, b = group[i], group[j]
                ix = min(a.left + a.width, b.left + b.width) - max(a.left, b.left)
                iy = min(a.top + a.height, b.top + b.height) - max(a.top, b.top)
                if ix > 0 and iy > 0:
                    small = min(a.width * a.height, b.width * b.height) or 1
                    if ix * iy / small > 0.1:
                        issues.append({"code": "overlap", "level": "warning", "path": f"s_{index}/{element_id(a)}",
                                       "message": f"{element_id(a)} overlaps {element_id(b)}", "with": element_id(b)})
    return issues


def audit(ctx: Context, file: str, *, slide: int | None = None) -> CommandResult:
    path = ctx.input_file(file)
    prs = open_pptx(path)
    n = len(prs.slides)
    if slide is not None and not 0 <= slide < n:
        raise GenOfficeError(EXIT.usage, f"slide {slide} out of range (0-{n - 1})", {"valid_range": [0, n - 1]}, reason="out_of_range")
    issues = []
    for i, s in enumerate(prs.slides):
        if slide is None or i == slide:
            issues += _audit_slide(prs, i, s)
    counts: dict[str, int] = {}
    for it in issues:
        counts[it["code"]] = counts.get(it["code"], 0) + 1
    summary = f"{path.name}: " + (", ".join(f"{v} {k}" for k, v in counts.items()) if issues else "no geometry issues")
    return CommandResult(summary=summary, detail={"issues": issues, "counts": counts})


# ================================================================ merge


PLACEHOLDER_RE = re.compile(r"\{\{\s*([^{}]+?)\s*\}\}")


def flatten(data: Any, prefix: str = "") -> dict[str, Any]:
    out: dict[str, Any] = {}
    if isinstance(data, dict):
        for k, v in data.items():
            key = f"{prefix}.{k}" if prefix else str(k)
            if isinstance(v, dict):
                out.update(flatten(v, key))
            else:
                out[key] = v
    return out


def _value_text(v: Any) -> str:
    if v is None:
        return ""
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    return str(v)


def merge(ctx: Context, file: str, data: Any, out: str, *, force: bool = False, strict: bool = False) -> CommandResult:
    path = ctx.input_file(file)
    if not isinstance(data, dict):
        raise GenOfficeError(EXIT.usage, "data must be a JSON object", reason="invalid_argument")
    values = flatten(data)
    target = ctx.output_file(out, force=force)
    prs = open_pptx(path)
    used: set[str] = set()
    unresolved: list[dict[str, Any]] = []

    def fill(tf: Any, location: dict[str, Any]) -> None:
        for p in tf.paragraphs:
            text = "".join(r.text for r in p.runs)
            for m in PLACEHOLDER_RE.finditer(text):
                if m.group(1) not in values:
                    unresolved.append({"placeholder": m.group(0), "key": m.group(1), "reason": "no_key", "location": location})

            def sub(m: re.Match[str]) -> str:
                key = m.group(1)
                if key in values:
                    used.add(key)
                    return _value_text(values[key])
                return m.group(0)

            replace_in_paragraph(p, PLACEHOLDER_RE, sub)

    def visit(shapes: Any, slide_index: int, depth: int) -> None:
        for sh in shapes:
            loc = {"slide": slide_index, "el": element_id(sh)}
            if sh.shape_type == MSO_SHAPE_TYPE.GROUP:
                if depth >= 1:
                    for inner in iter_shapes(sh.shapes):
                        for m in PLACEHOLDER_RE.finditer(shape_text(inner)):
                            unresolved.append({"placeholder": m.group(0), "key": m.group(1), "reason": "unreachable_nested",
                                               "location": {"slide": slide_index, "el": element_id(inner)}})
                else:
                    visit(sh.shapes, slide_index, depth + 1)
                continue
            if getattr(sh, "has_text_frame", False):
                fill(sh.text_frame, loc)
            if getattr(sh, "has_table", False):
                for row in sh.table.rows:
                    for cell in row.cells:
                        fill(cell.text_frame, loc)

    for i, s in enumerate(prs.slides):
        visit(s.shapes, i, 0)
        if s.has_notes_slide:
            fill(s.notes_slide.notes_text_frame, {"slide": i, "el": "notes"})

    detail = {
        "used_keys": sorted(used),
        "unused_keys": sorted(set(values) - used),
        "unresolved_placeholders": unresolved,
    }
    if unresolved and strict:
        raise GenOfficeError(EXIT.usage, f"{len(unresolved)} placeholder(s) without a value; nothing was written", detail,
                             reason="unresolved_placeholder", suggestion="add the keys to data (or ungroup nested groups) and merge again")
    prs.save(str(target))
    warnings = [
        Warning("unresolved_placeholder", f"{len(unresolved)} placeholder(s) left in place", "see detail.unresolved_placeholders")
    ] if unresolved else []
    return CommandResult(summary=f"merged {len(used)} key(s) into {target.name}", output_path=str(target), detail=detail, warnings=warnings)
