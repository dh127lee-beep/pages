"""Word documents: read blocks, apply ops, check, create from Markdown / restricted HTML, export, merge.

Blocks are the body's top-level paragraphs, tables and content controls in document order, 0-based;
the op names and fields are GenOffice's `docs apply` set. Built on python-docx.
"""

from __future__ import annotations

import base64
import copy
import io
import json
import re
import urllib.request
from html import escape as html_escape
from html.parser import HTMLParser
from pathlib import Path
from typing import Any, Iterable

from docx import Document
from docx.enum.section import WD_ORIENT, WD_SECTION_START
from docx.enum.style import WD_STYLE_TYPE
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_COLOR_INDEX, WD_TAB_ALIGNMENT, WD_TAB_LEADER
from docx.image.image import Image as DocxImage
from docx.opc.constants import RELATIONSHIP_TYPE as RT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.section import Section
from docx.shared import Emu, Inches, Pt, RGBColor, Twips
from docx.table import Table, _Cell
from docx.text.paragraph import Paragraph
from docx.text.run import Run

from ..context import Context
from ..ops import OpError, OpRegistry, batch_result, clip
from ..result import EXIT, CommandResult, GenOfficeError, Warning
from ..units import EMU_PER_PX, to_emu

W_P, W_TBL, W_SDT, W_SECTPR = qn("w:p"), qn("w:tbl"), qn("w:sdt"), qn("w:sectPr")
PREVIEW_CHARS = 200
EMU_PER_TWIP = 635

HTML_RULES = """Restricted HTML (insert_content, replace_blocks, create from .html):
  blocks: p, h1-h6, ul/ol/li (nested lists), table/thead/tbody/tr/th/td (colspan), blockquote, pre, hr, img, div
  inline: b/strong, i/em, u, s/del/strike, sup, sub, code, mark, a href, br, img src, span style
  style: color, background-color, font-size (pt|px), font-weight, font-style, text-decoration, font-family; text-align on blocks
  img src: local path (relative to the working directory, then to the ops / source file), data: URL or http(s) URL
  any other tag is stripped silently (its text is kept)"""

REGISTRY = OpRegistry(
    "docs",
    header=[
        "Word ops (docs_apply ops): a JSON array; every entry has \"op\". Blocks are 0-based (docs_read lists them).",
        'target is {"blockIndexes": [n, ...]}, {"blockRange": [a, b]} or {"nodeType": "docHeading"|"docParagraph"|"docListItem"|"image"|"table", "headingLevel"?}.',
        "Lengths: numbers are twips for paragraph/page fields and points for pictures; strings take \"2.54cm\", \"1in\", \"72pt\", \"96px\".",
        "Field notation: ? = optional, a|b = one of.",
    ],
    footer=[
        "Block indexes inside one batch are live: after insert_content adds two blocks, later indexes shift by two.",
        "Atomic by default: one rejected op leaves the file untouched; fix it and resend the whole batch.",
        "",
        HTML_RULES,
    ],
)
REGISTRY.group("block", "edits of existing blocks, addressed by target")
REGISTRY.group(
    "content",
    "new content, pictures, header/footer, page setup, styles, comments, properties",
)


# ---------------------------------------------------------------- document context


class _DocCtx:
    def __init__(self, ctx: Context, doc: Any, bases: Iterable[Path | None]) -> None:
        self.ctx = ctx
        self.doc = doc
        self.bases = [b for b in bases if b is not None]
        self.warnings: list[Warning] = []

    def blocks(self) -> list[Any]:
        return _block_elements(self.doc)

    def load_image(self, src: str) -> bytes:
        return _load_image(self.ctx, src, self.bases)


def _block_elements(doc: Any) -> list[Any]:
    return [el for el in doc.element.body.iterchildren() if el.tag in (W_P, W_TBL, W_SDT)]


def _wrap(doc: Any, el: Any) -> Any:
    if el.tag == W_P:
        return Paragraph(el, doc._body)
    if el.tag == W_TBL:
        return Table(el, doc._body)
    return None


def _load_image(ctx: Context, src: str, bases: list[Path]) -> bytes:
    if src.startswith("data:"):
        head, _, data = src.partition(",")
        return base64.b64decode(data) if ";base64" in head else data.encode("latin-1")
    if src.startswith(("http://", "https://")):
        req = urllib.request.Request(src, headers={"User-Agent": "genoffice-python"})
        with urllib.request.urlopen(req, timeout=20) as r:
            return r.read()
    p = Path(src).expanduser()
    candidates = [p] if p.is_absolute() else [b / p for b in bases]
    for c in candidates:
        resolved = ctx.resolve(c)
        if resolved.is_file():
            return resolved.read_bytes()
    raise ValueError(f"image not found: {src}")


def _image_width_px(blob: bytes) -> int:
    img = DocxImage.from_blob(blob)
    dpi = img.horz_dpi or 96
    return max(1, int(round(img.px_width * 96 / dpi)))


# ---------------------------------------------------------------- block description


def _style_name(p: Paragraph) -> str:
    try:
        return p.style.name if p.style is not None else "Normal"
    except (KeyError, AttributeError):
        return "Normal"


def _heading_level(p: Paragraph) -> int | None:
    name = _style_name(p)
    m = re.match(r"^Heading (\d)$", name, re.I)
    if m:
        return int(m.group(1))
    if name.lower() == "title":
        return 1
    return None


def _list_info(doc: Any, p: Paragraph) -> dict[str, Any] | None:
    name = _style_name(p)
    m = re.match(r"^List (Bullet|Number)(?: (\d))?$", name)
    pPr = p._p.pPr
    numPr = pPr.numPr if pPr is not None else None
    if numPr is not None and numPr.numId is not None and numPr.numId.val != 0:
        level = numPr.ilvl.val if numPr.ilvl is not None else 0
        return {"kind": _num_kind(doc, numPr.numId.val, level), "level": level}
    if m:
        return {"kind": "bullet" if m.group(1) == "Bullet" else "number", "level": int(m.group(2) or 1) - 1}
    return None


def _num_kind(doc: Any, num_id: int, level: int) -> str:
    try:
        numbering = doc.part.numbering_part.element
    except (KeyError, NotImplementedError, AttributeError):
        return "bullet"
    abs_ids = numbering.xpath(f'./w:num[@w:numId="{num_id}"]/w:abstractNumId/@w:val')
    if not abs_ids:
        return "bullet"
    fmts = numbering.xpath(
        f'./w:abstractNum[@w:abstractNumId="{abs_ids[0]}"]/w:lvl[@w:ilvl="{level}"]/w:numFmt/@w:val'
    )
    return "bullet" if not fmts or fmts[0] in ("bullet", "none") else "number"


def _instr_text(el: Any) -> str:
    parts = [t.text or "" for t in el.iter(qn("w:instrText"))]
    parts += [f.get(qn("w:instr")) or "" for f in el.iter(qn("w:fldSimple"))]
    return " ".join(parts)


def _block_kind(doc: Any, el: Any) -> tuple[str, dict[str, Any]]:
    if el.tag == W_TBL:
        t = Table(el, doc._body)
        return "table", {"rows": len(t.rows), "cols": len(t.columns)}
    if el.tag == W_SDT:
        return ("toc" if "TOC" in _instr_text(el) else "content_control"), {}
    p = Paragraph(el, doc._body)
    instr = _instr_text(el)
    if re.search(r"\bTOC\b", instr):
        return "toc", {}
    level = _heading_level(p)
    if level is not None:
        return "heading", {"level": level}
    info = _list_info(doc, p)
    if info:
        return "list_item", {"list": info}
    if not p.text.strip():
        if el.xpath('.//*[local-name()="chart"]'):
            return "chart", {}
        if el.xpath('.//*[local-name()="pic"]'):
            return "image", {}
        if el.xpath('.//w:br[@w:type="page"]'):
            return "page_break", {}
        return "empty", {}
    return "paragraph", {}


def _block_text(doc: Any, el: Any) -> str:
    if el.tag == W_P:
        return Paragraph(el, doc._body).text
    if el.tag == W_TBL:
        t = Table(el, doc._body)
        return "\n".join(" | ".join(c.text for c in _unique_cells(r)) for r in t.rows)
    return "".join(t.text or "" for t in el.iter(qn("w:t")))


def _unique_cells(row: Any) -> list[_Cell]:
    out, seen = [], set()
    for c in row.cells:
        if id(c._tc) in seen:
            continue
        seen.add(id(c._tc))
        out.append(c)
    return out


def _describe(doc: Any, index: int, el: Any, limit: int | None, with_html: bool) -> dict[str, Any]:
    kind, extra = _block_kind(doc, el)
    text, truncated = clip(_block_text(doc, el), limit)
    b: dict[str, Any] = {"index": index, "kind": kind, "text": text}
    if truncated:
        b["truncated"] = True
    b.update(extra)
    if el.tag == W_P:
        b["style"] = _style_name(Paragraph(el, doc._body))
    elif el.tag == W_TBL:
        st = Table(el, doc._body).style
        if st is not None:
            b["style"] = st.name
    if with_html:
        b["html"] = _block_html(doc, el)
    return b


# ---------------------------------------------------------------- targets


def _check_index(i: Any, n: int, *, allow_minus_one: bool = False) -> int:
    lo = -1 if allow_minus_one else 0
    if isinstance(i, bool) or not isinstance(i, int) or i < lo or i >= n:
        raise OpError(
            f"block index invalid or out of range (the document has {n} blocks): {i}",
            reason="out_of_range",
            valid_range=[lo, n - 1],
        )
    return i


def _target_indexes(dc: _DocCtx, op: dict[str, Any], *, required: bool = True) -> list[int]:
    blocks = dc.blocks()
    n = len(blocks)
    t = op.get("target")
    if t is None:
        if required:
            raise OpError(f"{op['op']}: target is required")
        return list(range(n))
    if not isinstance(t, dict):
        raise OpError("target must be an object")
    if "blockIndexes" in t:
        idx = t["blockIndexes"]
        if not isinstance(idx, list) or not idx:
            raise OpError("target.blockIndexes must be a non-empty array")
        return sorted({_check_index(i, n) for i in idx})
    if "blockRange" in t:
        a, b = t["blockRange"]
        _check_index(a, n)
        _check_index(b, n)
        return list(range(min(a, b), max(a, b) + 1))
    if "nodeType" in t:
        kinds = {
            "docHeading": "heading",
            "docParagraph": "paragraph",
            "docListItem": "list_item",
            "image": "image",
            "table": "table",
        }
        kind = kinds.get(t["nodeType"])
        if kind is None:
            raise OpError(f"unknown nodeType {t['nodeType']!r}", available=list(kinds), wanted=str(t["nodeType"]))
        level = t.get("headingLevel")
        out = []
        for i, el in enumerate(blocks):
            k, extra = _block_kind(dc.doc, el)
            if k == kind and (level is None or extra.get("level") == level):
                out.append(i)
        if not out:
            raise OpError(f"no matching blocks for nodeType {t['nodeType']}", reason="target_not_found")
        return out
    raise OpError('target needs blockIndexes, blockRange or nodeType')


def _paragraphs_of(doc: Any, el: Any) -> list[Paragraph]:
    if el.tag == W_P:
        return [Paragraph(el, doc._body)]
    return [Paragraph(p, doc._body) for p in el.iter(W_P)]


def _target_paragraphs(dc: _DocCtx, op: dict[str, Any]) -> list[Paragraph]:
    blocks = dc.blocks()
    out: list[Paragraph] = []
    for i in _target_indexes(dc, op):
        out.extend(_paragraphs_of(dc.doc, blocks[i]))
    return out


def _runs(p: Paragraph) -> list[Run]:
    return [Run(r, p) for r in p._p.xpath("./w:r | ./w:hyperlink/w:r | ./w:ins/w:r | ./w:smartTag/w:r")]


# ---------------------------------------------------------------- formatting helpers

_ALIGN = {
    "left": WD_ALIGN_PARAGRAPH.LEFT,
    "center": WD_ALIGN_PARAGRAPH.CENTER,
    "right": WD_ALIGN_PARAGRAPH.RIGHT,
    "justify": WD_ALIGN_PARAGRAPH.JUSTIFY,
}
_CJK = re.compile(r"[\u3040-\u30ff\u3400-\u9fff\uac00-\ud7af\uf900-\ufaff]")
_NAMED_COLORS = {
    "black": "000000", "white": "FFFFFF", "red": "FF0000", "green": "008000", "blue": "0000FF",
    "yellow": "FFFF00", "gray": "808080", "grey": "808080", "orange": "FFA500", "purple": "800080",
}


def _hex(color: Any) -> str:
    if not isinstance(color, str):
        raise ValueError(f"color must be #RRGGBB, got {color!r}")
    c = color.strip().lower()
    if c in _NAMED_COLORS:
        return _NAMED_COLORS[c]
    m = re.match(r"^rgb\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)", c)
    if m:
        return "".join(f"{min(255, int(v)):02X}" for v in m.groups())
    c = c.lstrip("#")
    if re.fullmatch(r"[0-9a-f]{3}", c):
        c = "".join(ch * 2 for ch in c)
    if not re.fullmatch(r"[0-9a-f]{6}", c):
        raise ValueError(f"color must be #RRGGBB, got {color!r}")
    return c.upper()


def _twips(v: Any) -> int:
    """Paragraph and page lengths: a number is twips, a string takes a unit."""
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        return int(round(v))
    return int(round(to_emu(v, default_unit="pt") / EMU_PER_TWIP))


def _set_shading(el_pr: Any, fill: str | None) -> None:
    for old in el_pr.findall(qn("w:shd")):
        el_pr.remove(old)
    if fill:
        shd = OxmlElement("w:shd")
        shd.set(qn("w:val"), "clear")
        shd.set(qn("w:color"), "auto")
        shd.set(qn("w:fill"), _hex(fill))
        el_pr.append(shd)


def _set_font_family(run: Run, family: str | None) -> None:
    rPr = run._r.get_or_add_rPr()
    if family is None:
        for f in rPr.findall(qn("w:rFonts")):
            rPr.remove(f)
        return
    if _CJK.search(family):
        rFonts = rPr.get_or_add_rFonts()
        rFonts.set(qn("w:eastAsia"), family)
    else:
        run.font.name = family


def _apply_font(run: Run, f: dict[str, Any]) -> None:
    font = run.font
    for key, attr in (("bold", "bold"), ("italic", "italic"), ("strike", "strike")):
        if key in f:
            setattr(font, attr, f[key])
    if "underline" in f:
        font.underline = f["underline"]
    if "color" in f:
        font.color.rgb = RGBColor.from_string(_hex(f["color"])) if f["color"] else None
    if "fontSize" in f:
        font.size = Pt(f["fontSize"]) if f["fontSize"] else None
    if "fontFamily" in f:
        _set_font_family(run, f["fontFamily"])
    if "highlight" in f:
        h = f["highlight"]
        if h is None or h == "none":
            font.highlight_color = None
        elif isinstance(h, str) and h.startswith("#"):
            _set_shading(run._r.get_or_add_rPr(), h)
        else:
            name = re.sub(r"(?<!^)(?=[A-Z])", "_", str(h)).upper()
            try:
                font.highlight_color = WD_COLOR_INDEX[name]
            except KeyError:
                raise ValueError(f"unknown highlight {h!r} (yellow, brightGreen, turquoise, pink, … or #RRGGBB)")
    if "baseline" in f:
        b = f["baseline"]
        font.superscript = True if b == "superscript" else None
        font.subscript = True if b == "subscript" else None


def _hyperlink_wrap(p: Paragraph, url: str | None) -> None:
    for h in p._p.findall(qn("w:hyperlink")):
        for r in list(h):
            h.addprevious(r)
        p._p.remove(h)
    if not url:
        return
    runs = p._p.findall(qn("w:r"))
    if not runs:
        return
    h = OxmlElement("w:hyperlink")
    h.set(qn("r:id"), p.part.relate_to(url, RT.HYPERLINK, is_external=True))
    runs[0].addprevious(h)
    for r in runs:
        h.append(r)
        run = Run(r, p)
        run.font.underline = True
        if run.font.color.rgb is None:
            run.font.color.rgb = RGBColor(0x05, 0x63, 0xC1)


def _ensure_style(doc: Any, name: str) -> Any:
    try:
        return doc.styles[name]
    except KeyError:
        pass
    m = re.match(r"^Heading (\d)$", name)
    if not m:
        raise OpError(f'the document has no "{name}" style')
    level = int(m.group(1))
    s = doc.styles.add_style(name, WD_STYLE_TYPE.PARAGRAPH)
    try:
        s.base_style = doc.styles["Normal"]
    except KeyError:
        pass
    s.font.bold = True
    s.font.size = Pt({1: 20, 2: 16, 3: 14, 4: 12}.get(level, 11))
    pPr = s.element.get_or_add_pPr()
    lvl = OxmlElement("w:outlineLvl")
    lvl.set(qn("w:val"), str(level - 1))
    pPr.append(lvl)
    return s


def _find_style(doc: Any, style_id: str) -> Any:
    for s in doc.styles:
        if s.style_id == style_id or s.name == style_id:
            return s
    return None


# ---------------------------------------------------------------- restricted HTML builder

_VOID = {"br", "img", "hr", "meta", "link", "input", "col", "wbr"}
_BLOCK = {
    "p", "div", "h1", "h2", "h3", "h4", "h5", "h6", "ul", "ol", "li", "table", "blockquote", "pre", "hr",
    "section", "article", "header", "footer", "main", "figure", "figcaption", "body", "html", "nav", "aside",
}


class _Node:
    def __init__(self, tag: str, attrs: dict[str, str]) -> None:
        self.tag = tag
        self.attrs = attrs
        self.children: list[Any] = []


class _TreeParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.root = _Node("root", {})
        self.stack = [self.root]
        self.skip = 0

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag in ("script", "style", "head", "title"):
            self.skip += 1
            return
        node = _Node(tag, {k: v or "" for k, v in attrs})
        self.stack[-1].children.append(node)
        if tag not in _VOID:
            self.stack.append(node)

    def handle_startendtag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        self.stack[-1].children.append(_Node(tag, {k: v or "" for k, v in attrs}))

    def handle_endtag(self, tag: str) -> None:
        if tag in ("script", "style", "head", "title"):
            self.skip = max(0, self.skip - 1)
            return
        for i in range(len(self.stack) - 1, 0, -1):
            if self.stack[i].tag == tag:
                del self.stack[i:]
                return

    def handle_data(self, data: str) -> None:
        if not self.skip:
            self.stack[-1].children.append(data)


def _css(style: str) -> dict[str, str]:
    out = {}
    for part in style.split(";"):
        k, _, v = part.partition(":")
        if k.strip():
            out[k.strip().lower()] = v.strip()
    return out


def _css_size_pt(v: str) -> float | None:
    m = re.match(r"^([\d.]+)\s*(pt|px)?$", v.strip())
    if not m:
        return None
    n = float(m.group(1))
    return n * 0.75 if m.group(2) == "px" else n


class _HtmlBuilder:
    """Turns a restricted-HTML fragment into paragraphs and tables of a container (document or cell)."""

    def __init__(self, doc: Any, load_image: Any, warnings: list[Warning], max_width_px: int = 624) -> None:
        self.doc = doc
        self.load_image = load_image
        self.warnings = warnings
        self.max_width_px = max_width_px

    def build(self, html: str, container: Any) -> None:
        parser = _TreeParser()
        parser.feed(html)
        parser.close()
        self._blocks(parser.root.children, container, {})

    # blocks

    def _blocks(self, nodes: list[Any], cont: Any, bctx: dict[str, Any], base: dict[str, Any] | None = None) -> None:
        inline: list[Any] = []
        for n in nodes:
            if isinstance(n, str) or n.tag not in _BLOCK:
                inline.append(n)
                continue
            self._flush(inline, cont, bctx, base)
            inline = []
            self._block(n, cont, bctx, base or {})
        self._flush(inline, cont, bctx, base)

    def _flush(self, inline: list[Any], cont: Any, bctx: dict[str, Any], base: dict[str, Any] | None) -> None:
        if not inline:
            return
        if all(isinstance(n, str) and not n.strip() for n in inline):
            return
        self._para(cont, inline, bctx, base or {})

    def _block(self, n: _Node, cont: Any, bctx: dict[str, Any], base: dict[str, Any]) -> None:
        tag = n.tag
        align = _css(n.attrs.get("style", "")).get("text-align") or n.attrs.get("align")
        if tag == "p" or tag == "figcaption":
            style = "Caption" if tag == "figcaption" else None
            self._para(cont, n.children, bctx, base, style=style, align=align, node=n)
        elif re.fullmatch(r"h[1-6]", tag):
            _ensure_style(self.doc, f"Heading {tag[1]}")
            self._para(cont, n.children, bctx, base, style=f"Heading {tag[1]}", align=align, node=n)
        elif tag in ("ul", "ol"):
            self._list(n, cont, bctx, base, level=bctx.get("list_level", -1) + 1)
        elif tag == "li":
            self._list(_Node("ul", {}), cont, bctx, base, level=0, items=[n])
        elif tag == "table":
            self._table(n, cont, bctx)
        elif tag == "blockquote":
            self._blocks(n.children, cont, {**bctx, "quote": True}, base)
        elif tag == "pre":
            self._para(cont, n.children, {**bctx, "pre": True}, {**base, "code": True}, node=n)
        elif tag == "hr":
            p = cont.add_paragraph()
            pPr = p._p.get_or_add_pPr()
            bdr = OxmlElement("w:pBdr")
            bottom = OxmlElement("w:bottom")
            for k, v in (("val", "single"), ("sz", "6"), ("space", "1"), ("color", "auto")):
                bottom.set(qn(f"w:{k}"), v)
            bdr.append(bottom)
            pPr.append(bdr)
        else:
            self._blocks(n.children, cont, bctx, {**base, **self._fmt_of(n)})

    def _para(
        self,
        cont: Any,
        nodes: list[Any],
        bctx: dict[str, Any],
        base: dict[str, Any],
        *,
        style: str | None = None,
        align: str | None = None,
        node: _Node | None = None,
    ) -> Paragraph:
        p = cont.add_paragraph()
        if style:
            try:
                p.style = self.doc.styles[style]
            except KeyError:
                pass
        elif bctx.get("quote"):
            try:
                p.style = self.doc.styles["Quote"]
            except KeyError:
                p.paragraph_format.left_indent = Inches(0.5)
        if align in _ALIGN:
            p.alignment = _ALIGN[align]
        fmt = dict(base)
        if node is not None:
            fmt.update(self._fmt_of(node))
        self._inline(p, nodes, fmt, pre=bool(bctx.get("pre")))
        return p

    def _list(
        self, n: _Node, cont: Any, bctx: dict[str, Any], base: dict[str, Any], *, level: int, items: list[_Node] | None = None
    ) -> None:
        kind = "Number" if n.tag == "ol" else "Bullet"
        style = f"List {kind}" if level == 0 else f"List {kind} {min(level + 1, 3)}"
        for li in items if items is not None else [c for c in n.children if isinstance(c, _Node) and c.tag == "li"]:
            inline = [c for c in li.children if isinstance(c, str) or c.tag not in _BLOCK]
            blocks = [c for c in li.children if isinstance(c, _Node) and c.tag in _BLOCK]
            first_p = next((b for b in blocks if b.tag == "p"), None)
            if not inline and first_p is not None:
                inline = first_p.children
                blocks = [b for b in blocks if b is not first_p]
            p = cont.add_paragraph()
            for name in (style, f"List {kind}", "List Paragraph"):
                try:
                    p.style = self.doc.styles[name]
                    break
                except KeyError:
                    continue
            self._inline(p, inline, dict(base))
            for b in blocks:
                if b.tag in ("ul", "ol"):
                    self._list(b, cont, {**bctx, "list_level": level}, base, level=level + 1)
                else:
                    self._block(b, cont, {**bctx, "list_level": level}, base)

    def _table(self, n: _Node, cont: Any, bctx: dict[str, Any]) -> None:
        rows: list[_Node] = []

        def collect(node: _Node) -> None:
            for c in node.children:
                if isinstance(c, _Node):
                    if c.tag == "tr":
                        rows.append(c)
                    elif c.tag in ("thead", "tbody", "tfoot"):
                        collect(c)

        collect(n)
        if not rows:
            return
        grid = []
        for r in rows:
            cells = [c for c in r.children if isinstance(c, _Node) and c.tag in ("td", "th")]
            grid.append([(c, max(1, int(c.attrs.get("colspan", "1") or 1))) for c in cells])
        ncols = max(1, max(sum(span for _, span in row) for row in grid))
        table = cont.add_table(rows=len(grid), cols=ncols)
        try:
            table.style = self.doc.styles["Table Grid"]
        except KeyError:
            pass
        for ri, row in enumerate(grid):
            col = 0
            for cell_node, span in row:
                if col >= ncols:
                    break
                cell = table.cell(ri, col)
                end = min(ncols - 1, col + span - 1)
                if end > col:
                    cell = cell.merge(table.cell(ri, end))
                base = {"bold": True} if cell_node.tag == "th" else {}
                first = cell.paragraphs[0]
                self._blocks(cell_node.children, cell, {}, base)
                if len(cell.paragraphs) > 1 and not first.text and not first._p.xpath(".//w:drawing"):
                    first._p.getparent().remove(first._p)
                col = end + 1

    # inline

    def _fmt_of(self, n: _Node) -> dict[str, Any]:
        f: dict[str, Any] = {}
        tag = n.tag
        if tag in ("b", "strong"):
            f["bold"] = True
        elif tag in ("i", "em", "cite"):
            f["italic"] = True
        elif tag in ("u", "ins"):
            f["underline"] = True
        elif tag in ("s", "del", "strike"):
            f["strike"] = True
        elif tag == "sup":
            f["baseline"] = "superscript"
        elif tag == "sub":
            f["baseline"] = "subscript"
        elif tag in ("code", "kbd", "samp", "tt"):
            f["code"] = True
        elif tag == "mark":
            f["highlight"] = "yellow"
        elif tag == "a" and n.attrs.get("href"):
            f["link"] = n.attrs["href"]
        css = _css(n.attrs.get("style", ""))
        if "color" in css:
            f["color"] = css["color"]
        if "background-color" in css:
            f["shade"] = css["background-color"]
        if "font-size" in css:
            size = _css_size_pt(css["font-size"])
            if size:
                f["fontSize"] = size
        if css.get("font-weight") in ("bold", "700", "800", "900"):
            f["bold"] = True
        if css.get("font-style") == "italic":
            f["italic"] = True
        deco = css.get("text-decoration", "")
        if "underline" in deco:
            f["underline"] = True
        if "line-through" in deco:
            f["strike"] = True
        if "font-family" in css:
            f["fontFamily"] = css["font-family"].split(",")[0].strip().strip("'\"")
        if tag == "font" and n.attrs.get("color"):
            f["color"] = n.attrs["color"]
        return f

    def _segments(self, nodes: list[Any], fmt: dict[str, Any], out: list[Any]) -> None:
        for n in nodes:
            if isinstance(n, str):
                out.append(("text", n, fmt))
            elif n.tag == "br":
                out.append(("br", "\n", fmt))
            elif n.tag == "img":
                out.append(("img", n.attrs.get("src", ""), fmt))
            else:
                self._segments(n.children, {**fmt, **self._fmt_of(n)}, out)

    def _inline(self, p: Paragraph, nodes: list[Any], fmt: dict[str, Any], *, pre: bool = False) -> None:
        segs: list[Any] = []
        self._segments(nodes, fmt, segs)
        if not pre:
            norm = []
            for kind, text, f in segs:
                if kind == "text":
                    text = re.sub(r"\s+", " ", text)
                norm.append([kind, text, f])
            # trim leading / trailing space of the paragraph and around line breaks
            prev_space = True
            for s in norm:
                if s[0] == "text":
                    if prev_space:
                        s[1] = s[1].lstrip(" ")
                    if s[1]:
                        prev_space = s[1].endswith(" ")
                else:
                    prev_space = True
            for s in reversed(norm):
                if s[0] != "text":
                    break
                s[1] = s[1].rstrip(" ")
                if s[1]:
                    break
            segs = [tuple(s) for s in norm if s[0] != "text" or s[1]]
        for kind, text, f in segs:
            if kind == "br":
                p.add_run().add_break()
            elif kind == "img":
                self._picture(p, text)
            elif pre:
                lines = text.split("\n")
                for i, line in enumerate(lines):
                    if i:
                        p.add_run().add_break()
                    if line:
                        self._run(p, line, f)
            else:
                self._run(p, text, f)

    def _run(self, p: Paragraph, text: str, f: dict[str, Any]) -> Run:
        link = f.get("link")
        if link and not link.startswith("#"):
            h = OxmlElement("w:hyperlink")
            h.set(qn("r:id"), p.part.relate_to(link, RT.HYPERLINK, is_external=True))
            r = OxmlElement("w:r")
            h.append(r)
            p._p.append(h)
            run = Run(r, p)
            run.text = text
            run.font.underline = True
            run.font.color.rgb = RGBColor(0x05, 0x63, 0xC1)
        else:
            run = p.add_run(text)
        spec = {k: v for k, v in f.items() if k in ("bold", "italic", "underline", "strike", "color", "fontSize", "fontFamily", "highlight", "baseline")}
        if f.get("code"):
            spec.setdefault("fontFamily", "Courier New")
        try:
            _apply_font(run, spec)
        except ValueError:
            pass
        if f.get("shade"):
            try:
                _set_shading(run._r.get_or_add_rPr(), f["shade"])
            except ValueError:
                pass
        return run

    def _picture(self, p: Paragraph, src: str, width_px: int | None = None) -> None:
        try:
            blob = self.load_image(src)
            natural = _image_width_px(blob)
        except Exception as e:  # unreadable or missing images are dropped, not fatal
            self.warnings.append(Warning("image_failed", f"image {src[:80]} skipped: {e}"))
            return
        w = min(width_px or natural, self.max_width_px)
        p.add_run().add_picture(io.BytesIO(blob), width=Emu(w * EMU_PER_PX))


def _insert_html(dc: _DocCtx, html: str, after: int | None, max_width_px: int = 624) -> list[Any]:
    """Build html at the end of the body, then move the new blocks after block `after` (-1 = start)."""
    body = dc.doc.element.body
    before = set(body)  # holding the proxies keeps lxml element identity stable
    _HtmlBuilder(dc.doc, dc.load_image, dc.warnings, max_width_px).build(html, dc.doc)
    new = [e for e in body if e not in before and e.tag != W_SECTPR]
    if not new:
        raise OpError("the html produced no blocks")
    fresh = set(new)
    blocks = [b for b in dc.blocks() if b not in fresh]
    if after is None:
        return new
    if after == -1:
        if blocks:
            for e in new:
                blocks[0].addprevious(e)
        return new
    anchor = blocks[after]
    for e in new:
        anchor.addnext(e)
        anchor = e
    return new


# ---------------------------------------------------------------- block ops


@REGISTRY.op(
    "setFont",
    "block",
    '{target, bold?, italic?, underline?, strike?, color?: "#RRGGBB"|null, highlight?, fontSize?: pt|null, '
    'fontFamily?: string|null, baseline?: "superscript"|"subscript"|"none"|null, link?: {url}|null}',
    note="run-level style of every run in the targeted blocks; a present field is set, null clears it, absent fields stay",
    required=("target",),
)
def _set_font(dc: _DocCtx, op: dict[str, Any]) -> None:
    paras = _target_paragraphs(dc, op)
    spec = {k: op[k] for k in ("bold", "italic", "underline", "strike", "color", "highlight", "fontSize", "fontFamily", "baseline") if k in op}
    if not spec and "link" not in op:
        raise OpError("setFont: give at least one font field")
    for p in paras:
        for run in _runs(p):
            _apply_font(run, spec)
        if "link" in op:
            link = op["link"]
            _hyperlink_wrap(p, link.get("url") if isinstance(link, dict) else None)


@REGISTRY.op(
    "setParagraphFormat",
    "block",
    '{target, align?: "left"|"center"|"right"|"justify"|null, lineSpacing?, indentLeft?, indentRight?, indentFirstLine?, '
    'spaceBefore?, spaceAfter?, pageBreakBefore?: bool, shadingFill?: "#RRGGBB"|null, borders?: subset of "tblr"|null, '
    'tabs?: [{pos, align?, leader?}]|null}',
    note="lengths in twips or unit strings; lineSpacing as a multiple; indentFirstLine negative = hanging",
    required=("target",),
)
def _set_paragraph_format(dc: _DocCtx, op: dict[str, Any]) -> None:
    for p in _target_paragraphs(dc, op):
        pf = p.paragraph_format
        if "align" in op:
            if op["align"] is not None and op["align"] not in _ALIGN:
                raise OpError(f"align must be one of {list(_ALIGN)}")
            pf.alignment = _ALIGN.get(op["align"]) if op["align"] else None
        if "lineSpacing" in op:
            pf.line_spacing = float(op["lineSpacing"]) if op["lineSpacing"] is not None else None
        for key, attr in (
            ("indentLeft", "left_indent"),
            ("indentRight", "right_indent"),
            ("indentFirstLine", "first_line_indent"),
            ("spaceBefore", "space_before"),
            ("spaceAfter", "space_after"),
        ):
            if key in op:
                setattr(pf, attr, Twips(_twips(op[key])) if op[key] is not None else None)
        if "pageBreakBefore" in op:
            pf.page_break_before = op["pageBreakBefore"]
        if "shadingFill" in op:
            _set_shading(p._p.get_or_add_pPr(), op["shadingFill"])
        if "borders" in op:
            pPr = p._p.get_or_add_pPr()
            for old in pPr.findall(qn("w:pBdr")):
                pPr.remove(old)
            if op["borders"]:
                bdr = OxmlElement("w:pBdr")
                for ch, side in (("t", "top"), ("l", "left"), ("b", "bottom"), ("r", "right")):
                    if ch in op["borders"]:
                        e = OxmlElement(f"w:{side}")
                        for k, v in (("val", "single"), ("sz", "4"), ("space", "1"), ("color", "auto")):
                            e.set(qn(f"w:{k}"), v)
                        bdr.append(e)
                pPr.append(bdr)
        if "tabs" in op:
            pf.tab_stops.clear_all()
            for t in op["tabs"] or []:
                align = WD_TAB_ALIGNMENT[str(t.get("align", "left")).upper()]
                leader = WD_TAB_LEADER[{"none": "SPACES", "dot": "DOTS", "hyphen": "DASHES", "underscore": "LINES", "middleDot": "MIDDLE_DOT"}[t.get("leader", "none")]]
                pf.tab_stops.add_tab_stop(Twips(_twips(t["pos"])), align, leader)


@REGISTRY.op("setHeadingLevel", "block", "{target, level: 0-6}", note="0 = demote to body paragraph", required=("target", "level"))
def _set_heading_level(dc: _DocCtx, op: dict[str, Any]) -> None:
    level = op["level"]
    if not isinstance(level, int) or not 0 <= level <= 6:
        raise OpError("level must be 0-6")
    blocks = dc.blocks()
    for i in _target_indexes(dc, op):
        if blocks[i].tag != W_P:
            raise OpError(f"block {i} is not a paragraph")
        p = Paragraph(blocks[i], dc.doc._body)
        p.style = _ensure_style(dc.doc, f"Heading {level}") if level else dc.doc.styles["Normal"]


def _run_at(starts: list[int], texts: list[str], offset: int, *, end: bool) -> tuple[int, int]:
    """The run holding a character offset (end=True: the run holding the char just before it)."""
    for i in range(len(texts)):
        lo, hi = starts[i], starts[i] + len(texts[i])
        if (lo < offset <= hi) if end else (lo <= offset < hi):
            return i, offset - lo
    return 0, 0


def _replace_in_runs(runs: list[Run], find: str, repl: str, match_case: bool) -> int:
    texts = [r.text for r in runs]
    full = "".join(texts)
    flags = 0 if match_case else re.I
    matches = list(re.finditer(re.escape(find), full, flags))
    starts = []
    pos = 0
    for t in texts:
        starts.append(pos)
        pos += len(t)

    done = 0
    for m in reversed(matches):
        i, a = _run_at(starts, texts, m.start(), end=False)
        j, b = _run_at(starts, texts, m.end(), end=True)
        if i == j:
            texts[i] = texts[i][:a] + repl + texts[i][b:]
            runs[i].text = texts[i]
        else:
            texts[i] = texts[i][:a] + repl
            runs[i].text = texts[i]
            for k in range(i + 1, j):
                texts[k] = ""
                runs[k].text = ""
            texts[j] = texts[j][b:]
            runs[j].text = texts[j]
        done += 1
    return done


@REGISTRY.op(
    "findReplace",
    "block",
    "{find, replace, matchCase?, target?}",
    note="plain text inside runs of paragraphs (not table cells: replace_blocks the table); target narrows the blocks, omitted = whole document",
    required=("find",),
)
def _find_replace(dc: _DocCtx, op: dict[str, Any]) -> dict[str, Any]:
    if not op["find"]:
        raise OpError("find must not be empty")
    blocks = dc.blocks()
    total = 0
    for i in _target_indexes(dc, op, required=False):
        if blocks[i].tag != W_P:
            continue
        p = Paragraph(blocks[i], dc.doc._body)
        total += _replace_in_runs(_runs(p), op["find"], str(op.get("replace", "")), bool(op.get("matchCase")))
    return {"replacements": total}


@REGISTRY.op("deleteBlocks", "block", "{target}", required=("target",))
def _delete_blocks(dc: _DocCtx, op: dict[str, Any]) -> None:
    blocks = dc.blocks()
    for i in sorted(_target_indexes(dc, op), reverse=True):
        el = blocks[i]
        pPr = el.find(qn("w:pPr")) if el.tag == W_P else None
        if pPr is not None and pPr.find(W_SECTPR) is not None:
            for child in list(el):
                if child is not pPr:
                    el.remove(child)
            continue
        el.getparent().remove(el)
    if not dc.blocks():
        dc.doc.add_paragraph()


@REGISTRY.op(
    "moveBlocks",
    "block",
    "{blockIndexes: [n], afterBlockIndex}",
    note="moves the blocks (relative order kept) after afterBlockIndex; -1 = start of document",
    required=("blockIndexes", "afterBlockIndex"),
)
def _move_blocks(dc: _DocCtx, op: dict[str, Any]) -> None:
    blocks = dc.blocks()
    n = len(blocks)
    moving = sorted({_check_index(i, n) for i in op["blockIndexes"]})
    after = _check_index(op["afterBlockIndex"], n, allow_minus_one=True)
    if after in moving:
        raise OpError("afterBlockIndex must not be one of the moved blocks")
    els = [blocks[i] for i in moving]
    anchor = blocks[after] if after >= 0 else None
    first = next((b for k, b in enumerate(blocks) if k not in moving), None)
    for e in els:
        e.getparent().remove(e)
    if anchor is None:
        if first is None:
            return
        for e in els:
            first.addprevious(e)
        return
    for e in els:
        anchor.addnext(e)
        anchor = e


@REGISTRY.op("setList", "block", '{target, kind?: "bullet"|"number"}', note="paragraphs to list items (default bullet); headings are not converted", required=("target",))
def _set_list(dc: _DocCtx, op: dict[str, Any]) -> None:
    kind = op.get("kind", "bullet")
    if kind not in ("bullet", "number"):
        raise OpError('kind must be "bullet" or "number"')
    name = "List Bullet" if kind == "bullet" else "List Number"
    try:
        style = dc.doc.styles[name]
    except KeyError:
        raise OpError(f'the document has no "{name}" style, so the Python port cannot number it')
    blocks = dc.blocks()
    for i in _target_indexes(dc, op):
        if blocks[i].tag != W_P:
            continue
        p = Paragraph(blocks[i], dc.doc._body)
        if _heading_level(p) is not None:
            continue
        p.style = style


@REGISTRY.op("clearList", "block", "{target}", note="list items back to body paragraphs", required=("target",))
def _clear_list(dc: _DocCtx, op: dict[str, Any]) -> None:
    blocks = dc.blocks()
    for i in _target_indexes(dc, op):
        if blocks[i].tag != W_P:
            continue
        p = Paragraph(blocks[i], dc.doc._body)
        pPr = p._p.pPr
        if pPr is not None and pPr.numPr is not None:
            pPr.remove(pPr.numPr)
        if _style_name(p).startswith("List"):
            p.style = dc.doc.styles["Normal"]


@REGISTRY.op(
    "applyStyle",
    "block",
    "{target, styleId}",
    note="paragraph (or table) style by id or name; a heading style turns the block into a heading; docs_read styles=true lists ids",
    required=("target", "styleId"),
)
def _apply_style(dc: _DocCtx, op: dict[str, Any]) -> None:
    style = _find_style(dc.doc, op["styleId"])
    if style is None:
        ids = [s.style_id for s in dc.doc.styles if s.type in (WD_STYLE_TYPE.PARAGRAPH, WD_STYLE_TYPE.TABLE)]
        raise OpError(f'no style "{op["styleId"]}"', reason="target_not_found", available=ids, wanted=op["styleId"])
    blocks = dc.blocks()
    for i in _target_indexes(dc, op):
        el = blocks[i]
        if el.tag == W_TBL:
            if style.type != WD_STYLE_TYPE.TABLE:
                raise OpError(f"block {i} is a table; {op['styleId']} is not a table style")
            Table(el, dc.doc._body).style = style
        elif el.tag == W_P:
            if style.type != WD_STYLE_TYPE.PARAGRAPH:
                raise OpError(f"{op['styleId']} is not a paragraph style")
            Paragraph(el, dc.doc._body).style = style


def _add_field_runs(p: Paragraph, instr: str, result: str) -> None:
    def fld(kind: str) -> Any:
        r = OxmlElement("w:r")
        c = OxmlElement("w:fldChar")
        c.set(qn("w:fldCharType"), kind)
        if kind == "begin":
            c.set(qn("w:dirty"), "true")
        r.append(c)
        return r

    p._p.append(fld("begin"))
    r = OxmlElement("w:r")
    t = OxmlElement("w:instrText")
    t.set(qn("xml:space"), "preserve")
    t.text = f" {instr} "
    r.append(t)
    p._p.append(r)
    p._p.append(fld("separate"))
    if result:
        p.add_run(result)
    p._p.append(fld("end"))


def _set_update_fields(doc: Any) -> None:
    settings = doc.settings.element
    if settings.find(qn("w:updateFields")) is None:
        e = OxmlElement("w:updateFields")
        e.set(qn("w:val"), "true")
        settings.append(e)


@REGISTRY.op(
    "insertToc",
    "block",
    "{afterBlockIndex}",
    note="a TOC field after that block (-1 = start); Word computes the entries and page numbers on open; fails without headings",
    required=("afterBlockIndex",),
)
def _insert_toc(dc: _DocCtx, op: dict[str, Any]) -> None:
    blocks = dc.blocks()
    after = _check_index(op["afterBlockIndex"], len(blocks), allow_minus_one=True)
    if not any(_block_kind(dc.doc, b)[0] == "heading" for b in blocks):
        raise OpError("the document has no headings for a table of contents")
    p = dc.doc.add_paragraph()
    _add_field_runs(p, 'TOC \\o "1-3" \\h \\z \\u', "")
    el = p._p
    el.getparent().remove(el)
    if after == -1:
        blocks[0].addprevious(el)
    else:
        blocks[after].addnext(el)
    _set_update_fields(dc.doc)


@REGISTRY.op(
    "setImageProperties",
    "block",
    '{target, widthPx?, heightPx?, align?: "left"|"center"|"right"|null}',
    note="image blocks only; one dimension scales the other proportionally",
    required=("target",),
)
def _set_image_properties(dc: _DocCtx, op: dict[str, Any]) -> None:
    blocks = dc.blocks()
    for i in _target_indexes(dc, op):
        el = blocks[i]
        if _block_kind(dc.doc, el)[0] != "image":
            raise OpError(f"block {i} is not an image block")
        for ext in el.xpath(".//wp:extent"):
            cx, cy = int(ext.get("cx")), int(ext.get("cy"))
            w, h = op.get("widthPx"), op.get("heightPx")
            if w and h:
                ncx, ncy = w * EMU_PER_PX, h * EMU_PER_PX
            elif w:
                ncx, ncy = w * EMU_PER_PX, int(cy * w * EMU_PER_PX / cx)
            elif h:
                ncx, ncy = int(cx * h * EMU_PER_PX / cy), h * EMU_PER_PX
            else:
                continue
            ext.set("cx", str(int(ncx)))
            ext.set("cy", str(int(ncy)))
            for a in ext.getparent().xpath(".//a:ext"):
                a.set("cx", str(int(ncx)))
                a.set("cy", str(int(ncy)))
        if "align" in op:
            Paragraph(el, dc.doc._body).alignment = _ALIGN.get(op["align"]) if op["align"] else None


@REGISTRY.op("setOutlineLevel", "block", "{target, level: 0-9}", note="0 removes the outline level; 1-9 = outline level 1-9", required=("target", "level"))
def _set_outline_level(dc: _DocCtx, op: dict[str, Any]) -> None:
    level = op["level"]
    if not isinstance(level, int) or not 0 <= level <= 9:
        raise OpError("level must be 0-9")
    for p in _target_paragraphs(dc, op):
        pPr = p._p.get_or_add_pPr()
        for old in pPr.findall(qn("w:outlineLvl")):
            pPr.remove(old)
        if level:
            e = OxmlElement("w:outlineLvl")
            e.set(qn("w:val"), str(level - 1))
            pPr.append(e)


@REGISTRY.op("stepIndent", "block", "{target, delta: 1|-1}", note="left indent by 0.5in steps", required=("target", "delta"))
def _step_indent(dc: _DocCtx, op: dict[str, Any]) -> None:
    for p in _target_paragraphs(dc, op):
        pf = p.paragraph_format
        cur = pf.left_indent or 0
        pf.left_indent = Emu(max(0, cur + int(op["delta"]) * Inches(0.5)))


@REGISTRY.op("stepHangingIndent", "block", "{target, delta: 1|-1}", note="hanging indent by 0.5in steps", required=("target", "delta"))
def _step_hanging(dc: _DocCtx, op: dict[str, Any]) -> None:
    for p in _target_paragraphs(dc, op):
        pf = p.paragraph_format
        hang = max(0, -(pf.first_line_indent or 0) + int(op["delta"]) * Inches(0.5))
        pf.first_line_indent = Emu(-hang) if hang else None
        if (pf.left_indent or 0) < hang:
            pf.left_indent = Emu(hang)


@REGISTRY.op(
    "insertField",
    "block",
    '{target, type: "SEQ"|"REF"|"PAGEREF"|"DATE"|"PAGE"|"NUMPAGES"|"AUTHOR"|..., args?, result?}',
    note="appended at the end of exactly one paragraph; marked dirty so Word computes the result on open",
    required=("target", "type"),
)
def _insert_field(dc: _DocCtx, op: dict[str, Any]) -> None:
    paras = _target_paragraphs(dc, op)
    if len(paras) != 1:
        raise OpError("insertField targets exactly one paragraph")
    instr = f"{op['type']} {op.get('args', '')}".strip()
    _add_field_runs(paras[0], instr, str(op.get("result", "")))
    _set_update_fields(dc.doc)


@REGISTRY.op("insertBookmark", "block", "{target, name}", note="bookmarks exactly one paragraph for REF / PAGEREF fields", required=("target", "name"))
def _insert_bookmark(dc: _DocCtx, op: dict[str, Any]) -> None:
    name = op["name"]
    if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]{0,39}", str(name)):
        raise OpError("name: letters, digits, underscore, up to 40 characters")
    body = dc.doc.element.body
    if name in body.xpath(".//w:bookmarkStart/@w:name"):
        raise OpError(f'bookmark "{name}" exists')
    paras = _target_paragraphs(dc, op)
    if len(paras) != 1:
        raise OpError("insertBookmark targets exactly one paragraph")
    ids = [int(x) for x in body.xpath(".//w:bookmarkStart/@w:id") if str(x).isdigit()]
    bid = str(max(ids, default=0) + 1)
    start, end = OxmlElement("w:bookmarkStart"), OxmlElement("w:bookmarkEnd")
    start.set(qn("w:id"), bid)
    start.set(qn("w:name"), name)
    end.set(qn("w:id"), bid)
    p = paras[0]._p
    pPr = p.find(qn("w:pPr"))
    if pPr is not None:
        pPr.addnext(start)
    else:
        p.insert(0, start)
    p.append(end)


@REGISTRY.op("updateFields", "block", '{scope?: "all"|"SEQ"|"REF"|"DATE"}', note="marks the fields dirty so Word recomputes every result on open")
def _update_fields(dc: _DocCtx, op: dict[str, Any]) -> None:
    for c in dc.doc.element.body.iter(qn("w:fldChar")):
        if c.get(qn("w:fldCharType")) == "begin":
            c.set(qn("w:dirty"), "true")
    _set_update_fields(dc.doc)


def _one_table(dc: _DocCtx, op: dict[str, Any]) -> Table:
    blocks = dc.blocks()
    idx = [i for i in _target_indexes(dc, op) if blocks[i].tag == W_TBL]
    if len(idx) != 1:
        raise OpError("target must match exactly one table")
    return Table(blocks[idx[0]], dc.doc._body)


def _grid_check(t: Table, row: Any = None, col: Any = None) -> None:
    if row is not None and not (isinstance(row, int) and 0 <= row < len(t.rows)):
        raise OpError(f"row out of range (0-{len(t.rows) - 1})", reason="out_of_range", valid_range=[0, len(t.rows) - 1])
    if col is not None and not (isinstance(col, int) and 0 <= col < len(t.columns)):
        raise OpError(f"col out of range (0-{len(t.columns) - 1})", reason="out_of_range", valid_range=[0, len(t.columns) - 1])


@REGISTRY.op("insertTableRow", "block", '{target, row, position?: "before"|"after", count?}', note="the new rows copy the row's cell formatting, empty text", required=("target", "row"))
def _insert_table_row(dc: _DocCtx, op: dict[str, Any]) -> None:
    t = _one_table(dc, op)
    _grid_check(t, row=op["row"])
    src = t.rows[op["row"]]._tr
    anchor = src
    for _ in range(int(op.get("count", 1))):
        tr = copy.deepcopy(src)
        for tc in tr.iter(qn("w:tc")):
            ps = tc.findall(W_P)
            for p in ps[1:]:
                tc.remove(p)
            for p in ps[:1]:
                for child in list(p):
                    if child.tag != qn("w:pPr"):
                        p.remove(child)
        if op.get("position", "after") == "before":
            src.addprevious(tr)
        else:
            anchor.addnext(tr)
            anchor = tr


@REGISTRY.op("deleteTableRow", "block", "{target, row, count?}", required=("target", "row"))
def _delete_table_row(dc: _DocCtx, op: dict[str, Any]) -> None:
    t = _one_table(dc, op)
    _grid_check(t, row=op["row"])
    rows = [r._tr for r in t.rows][op["row"] : op["row"] + int(op.get("count", 1))]
    if len(rows) >= len(t.rows):
        raise OpError("cannot delete every row; deleteBlocks removes the table")
    for tr in rows:
        tr.getparent().remove(tr)


@REGISTRY.op("insertTableColumn", "block", '{target, col, position?: "before"|"after", count?}', required=("target", "col"))
def _insert_table_column(dc: _DocCtx, op: dict[str, Any]) -> None:
    t = _one_table(dc, op)
    _grid_check(t, col=op["col"])
    before = op.get("position", "after") == "before"
    for _ in range(int(op.get("count", 1))):
        grid = t._tbl.tblGrid
        cols = grid.findall(qn("w:gridCol"))
        newcol = copy.deepcopy(cols[op["col"]])
        (cols[op["col"]].addprevious if before else cols[op["col"]].addnext)(newcol)
        for r in t.rows:
            tcs = r._tr.findall(qn("w:tc"))
            if op["col"] >= len(tcs):
                raise OpError("merged cells cover that column; the Python port cannot insert there")
            tc = copy.deepcopy(tcs[op["col"]])
            for p in tc.findall(W_P)[1:]:
                tc.remove(p)
            for p in tc.findall(W_P):
                for child in list(p):
                    if child.tag != qn("w:pPr"):
                        p.remove(child)
            (tcs[op["col"]].addprevious if before else tcs[op["col"]].addnext)(tc)


@REGISTRY.op("deleteTableColumn", "block", "{target, col, count?}", required=("target", "col"))
def _delete_table_column(dc: _DocCtx, op: dict[str, Any]) -> None:
    t = _one_table(dc, op)
    _grid_check(t, col=op["col"])
    count = int(op.get("count", 1))
    if count >= len(t.columns):
        raise OpError("cannot delete every column; deleteBlocks removes the table")
    for _ in range(count):
        cols = t._tbl.tblGrid.findall(qn("w:gridCol"))
        t._tbl.tblGrid.remove(cols[op["col"]])
        for r in t.rows:
            tcs = r._tr.findall(qn("w:tc"))
            if op["col"] < len(tcs):
                r._tr.remove(tcs[op["col"]])


@REGISTRY.op("mergeTableCells", "block", "{target, range: {row, col, rowEnd?, colEnd?}}", note="0-based grid, ends inclusive; texts kept as separate paragraphs", required=("target", "range"))
def _merge_cells(dc: _DocCtx, op: dict[str, Any]) -> None:
    t = _one_table(dc, op)
    r = op["range"]
    _grid_check(t, row=r["row"], col=r["col"])
    _grid_check(t, row=r.get("rowEnd", r["row"]), col=r.get("colEnd", r["col"]))
    try:
        t.cell(r["row"], r["col"]).merge(t.cell(r.get("rowEnd", r["row"]), r.get("colEnd", r["col"])))
    except Exception as e:
        raise OpError(f"merge refused: {e}")


@REGISTRY.op(
    "setTableCellFormat",
    "block",
    '{target, range?: {row, col, rowEnd?, colEnd?}, fill?: "#RRGGBB"|null, vAlign?: "top"|"center"|"bottom"|null, width?: twips|"2.5cm"}',
    note="cells in the range (omitted = whole table)",
    required=("target",),
)
def _set_cell_format(dc: _DocCtx, op: dict[str, Any]) -> None:
    t = _one_table(dc, op)
    r = op.get("range") or {"row": 0, "col": 0, "rowEnd": len(t.rows) - 1, "colEnd": len(t.columns) - 1}
    _grid_check(t, row=r["row"], col=r["col"])
    _grid_check(t, row=r.get("rowEnd", r["row"]), col=r.get("colEnd", r["col"]))
    valign = {"top": WD_CELL_VERTICAL_ALIGNMENT.TOP, "center": WD_CELL_VERTICAL_ALIGNMENT.CENTER, "bottom": WD_CELL_VERTICAL_ALIGNMENT.BOTTOM}
    for ri in range(r["row"], r.get("rowEnd", r["row"]) + 1):
        for ci in range(r["col"], r.get("colEnd", r["col"]) + 1):
            cell = t.cell(ri, ci)
            if "fill" in op:
                _set_shading(cell._tc.get_or_add_tcPr(), op["fill"])
            if "vAlign" in op:
                cell.vertical_alignment = valign.get(op["vAlign"]) if op["vAlign"] else None
            if op.get("width") is not None:
                cell.width = Twips(_twips(op["width"]))


@REGISTRY.op("setTableStyle", "block", "{target, styleId?: string|null, look?: {firstRow?, lastRow?, firstColumn?, lastColumn?, bandedRows?, bandedColumns?}}", required=("target",))
def _set_table_style(dc: _DocCtx, op: dict[str, Any]) -> None:
    t = _one_table(dc, op)
    if "styleId" in op:
        if op["styleId"] is None:
            t.style = None
        else:
            s = _find_style(dc.doc, op["styleId"])
            if s is None or s.type != WD_STYLE_TYPE.TABLE:
                ids = [x.style_id for x in dc.doc.styles if x.type == WD_STYLE_TYPE.TABLE]
                raise OpError(f'no table style "{op["styleId"]}"', reason="target_not_found", available=ids, wanted=op["styleId"])
            t.style = s
    if op.get("look"):
        tblPr = t._tbl.tblPr
        look = tblPr.find(qn("w:tblLook"))
        if look is None:
            look = OxmlElement("w:tblLook")
            tblPr.append(look)
        keys = {"firstRow": "firstRow", "lastRow": "lastRow", "firstColumn": "firstColumn", "lastColumn": "lastColumn"}
        for k, attr in keys.items():
            if k in op["look"]:
                look.set(qn(f"w:{attr}"), "1" if op["look"][k] else "0")
        if "bandedRows" in op["look"]:
            look.set(qn("w:noHBand"), "0" if op["look"]["bandedRows"] else "1")
        if "bandedColumns" in op["look"]:
            look.set(qn("w:noVBand"), "0" if op["look"]["bandedColumns"] else "1")


REGISTRY.unavailable("setMatchedFont", "block", "{text?, matchCase?, matchColor?, matchFontSize?, target?, <font fields>}", "character-level run matching is not ported; use findReplace + setFont on whole blocks")
REGISTRY.unavailable("setParagraphAttrs", "block", "{target, attrs}", "editor node attributes have no file equivalent outside the app")
REGISTRY.unavailable("splitTableCell", "block", "{target, cell: {row, col}}", "unmerging is not ported; rebuild the table with replace_blocks")


# ---------------------------------------------------------------- content ops


@REGISTRY.op(
    "insert_content",
    "content",
    "{html, afterBlockIndex?}",
    note="new blocks after an index (-1 = start of document; omitted = end of document); restricted HTML",
    required=("html",),
)
def _insert_content(dc: _DocCtx, op: dict[str, Any]) -> dict[str, Any]:
    after = op.get("afterBlockIndex")
    if after is not None:
        _check_index(after, len(dc.blocks()), allow_minus_one=True)
    new = _insert_html(dc, str(op["html"]), after)
    blocks = dc.blocks()
    first = blocks.index(new[0])
    return {"blockRange": [first, first + len(new) - 1]}


@REGISTRY.op(
    "replace_blocks",
    "content",
    "{startBlockIndex, endBlockIndex, html}",
    note="rewrite a block range (inclusive); the new paragraphs inherit the replaced paragraphs' formatting",
    required=("startBlockIndex", "endBlockIndex", "html"),
)
def _replace_blocks(dc: _DocCtx, op: dict[str, Any]) -> dict[str, Any]:
    blocks = dc.blocks()
    n = len(blocks)
    a = _check_index(op["startBlockIndex"], n)
    b = _check_index(op["endBlockIndex"], n)
    if b < a:
        raise OpError("endBlockIndex must be >= startBlockIndex")
    old = blocks[a : b + 1]
    old_paras = [Paragraph(e, dc.doc._body) for e in old if e.tag == W_P]
    inherit = []
    for p in old_paras:
        runs = _runs(p)
        f = runs[0].font if runs else None
        inherit.append(
            {
                "pPr": copy.deepcopy(p._p.pPr) if p._p.pPr is not None else None,
                "font": {k: getattr(f, k) for k in ("bold", "italic", "size", "name")} if f else {},
                "rgb": f.color.rgb if f is not None and f.color.type is not None else None,
            }
        )
    sect = [e.find(qn("w:pPr")).find(W_SECTPR) for e in old if e.tag == W_P and e.find(qn("w:pPr")) is not None and e.find(qn("w:pPr")).find(W_SECTPR) is not None]
    new = _insert_html(dc, str(op["html"]), b)
    for e in old:
        e.getparent().remove(e)
    k = 0
    for e in new:
        if e.tag != W_P or not inherit:
            continue
        src = inherit[min(k, len(inherit) - 1)]
        k += 1
        p = Paragraph(e, dc.doc._body)
        if _style_name(p) == "Normal" and p._p.pPr is None and src["pPr"] is not None:
            pPr = copy.deepcopy(src["pPr"])
            for s in pPr.findall(W_SECTPR):
                pPr.remove(s)
            p._p.insert(0, pPr)
        for run in _runs(p):
            for key, value in src["font"].items():
                if value is not None and getattr(run.font, key) is None:
                    setattr(run.font, key, value)
            if src["rgb"] is not None and run.font.color.type is None:
                run.font.color.rgb = src["rgb"]
    for s in sect:
        last = new[-1] if new[-1].tag == W_P else None
        if last is None:
            p = dc.doc.add_paragraph()
            p._p.getparent().remove(p._p)
            new[-1].addnext(p._p)
            last = p._p
        last.get_or_add_pPr().append(s)
    first = dc.blocks().index(new[0])
    return {"blockRange": [first, first + len(new) - 1]}


def _picture_paragraph(dc: _DocCtx, op: dict[str, Any], width_emu: int | None, height_emu: int | None, max_width_px: int) -> Any:
    after = op.get("afterBlockIndex")
    if after is not None:
        _check_index(after, len(dc.blocks()), allow_minus_one=True)
    try:
        blob = dc.load_image(str(op["url"]))
        natural = _image_width_px(blob)
    except Exception as e:
        raise OpError(f"image could not be read: {e}")
    p = dc.doc.add_paragraph()
    if width_emu is None and height_emu is None:
        width_emu = min(natural, max_width_px) * EMU_PER_PX
    shape = p.add_run().add_picture(io.BytesIO(blob), width=Emu(width_emu) if width_emu else None, height=Emu(height_emu) if height_emu else None)
    if op.get("alt"):
        for docpr in p._p.xpath(".//wp:docPr"):
            docpr.set("descr", str(op["alt"]))
    if op.get("align") in _ALIGN:
        p.alignment = _ALIGN[op["align"]]
    el = p._p
    if after is not None:
        el.getparent().remove(el)
        blocks = dc.blocks()
        if after == -1:
            blocks[0].addprevious(el) if blocks else dc.doc.element.body.insert(0, el)
        else:
            blocks[after].addnext(el)
    return shape


@REGISTRY.op(
    "insert_image",
    "content",
    '{url, afterBlockIndex?, maxWidthPx?, alt?, align?: "left"|"center"|"right"}',
    note="url is a local path (relative to the working directory, then to the ops file), a data: URL or an http(s) URL; scaled down to maxWidthPx (default 480); appended when afterBlockIndex is omitted",
    required=("url",),
)
def _insert_image(dc: _DocCtx, op: dict[str, Any]) -> None:
    _picture_paragraph(dc, op, None, None, int(op.get("maxWidthPx", 480)))


@REGISTRY.op(
    "insert_picture",
    "content",
    '{url, afterBlockIndex?, width?, height?, alt?, align?, float?}',
    note='sized variant of insert_image; width/height take "2.54cm", "1in", "72pt", "96px" or points; float placement is not ported (inserted inline, reported in notes)',
    required=("url",),
)
def _insert_picture(dc: _DocCtx, op: dict[str, Any]) -> dict[str, Any] | None:
    w = to_emu(op["width"], default_unit="pt") if op.get("width") is not None else None
    h = to_emu(op["height"], default_unit="pt") if op.get("height") is not None else None
    _picture_paragraph(dc, op, w, h, 10_000)
    return {"note": "float placement is not supported by the Python port; the picture was inserted inline"} if op.get("float") else None


def _sections_for(dc: _DocCtx, op: dict[str, Any]) -> list[Section]:
    sections = list(dc.doc.sections)
    if op.get("section") is not None:
        s = op["section"]
        if not isinstance(s, int) or not 0 <= s < len(sections):
            raise OpError(f"section out of range (0-{len(sections) - 1})", reason="out_of_range", valid_range=[0, len(sections) - 1])
        return [sections[s]]
    if op.get("blockIndex") is not None:
        n = len(dc.blocks())
        i = _check_index(op["blockIndex"], n)
        for k, (a, b) in enumerate(_section_ranges(dc.doc)):
            if a <= i <= b:
                return [sections[k]]
    return sections


def _write_hf_text(part_obj: Any, text: str) -> None:
    el = part_obj._element
    for child in list(el):
        el.remove(child)
    lines = text.split("\n") if text else [""]
    for line in lines:
        p = part_obj.add_paragraph()
        for piece in re.split(r"(\{PAGE\}|\{NUMPAGES\})", line):
            if piece in ("{PAGE}", "{NUMPAGES}"):
                f = OxmlElement("w:fldSimple")
                f.set(qn("w:instr"), piece.strip("{}"))
                r = OxmlElement("w:r")
                t = OxmlElement("w:t")
                t.text = "1"
                r.append(t)
                f.append(r)
                p._p.append(f)
            elif piece:
                p.add_run(piece)


@REGISTRY.op(
    "set_header_footer",
    "content",
    '{kind: "header"|"footer", text, view?: "default"|"first"|"even", section?}',
    note='plain text, \\n between lines, {PAGE} / {NUMPAGES} become page-number fields, "" clears; view first/even switches the different-first-page / odd-even setting on',
    required=("kind", "text"),
)
def _set_header_footer(dc: _DocCtx, op: dict[str, Any]) -> None:
    kind, view = op["kind"], op.get("view", "default")
    if kind not in ("header", "footer") or view not in ("default", "first", "even"):
        raise OpError('kind header|footer, view default|first|even')
    if view == "even":
        dc.doc.settings.odd_and_even_pages_header_footer = True
    for s in _sections_for(dc, op):
        if view == "first":
            s.different_first_page_header_footer = True
        attr = {"default": kind, "first": f"first_page_{kind}", "even": f"even_page_{kind}"}[view]
        hf = getattr(s, attr)
        hf.is_linked_to_previous = False
        _write_hf_text(hf, str(op["text"]))


_PAPER = {
    "A3": (16838, 23811), "A4": (11906, 16838), "A5": (8391, 11906), "B5": (10319, 14572),
    "Letter": (12240, 15840), "Legal": (12240, 20160), "Tabloid": (15840, 24480),
}


def _sectpr_child(sectPr: Any, tag: str, after: tuple[str, ...]) -> Any:
    el = sectPr.find(qn(tag))
    if el is not None:
        return el
    el = OxmlElement(tag)
    prev = None
    for t in after:
        found = sectPr.find(qn(t))
        if found is not None:
            prev = found
    if prev is not None:
        prev.addnext(el)
    else:
        sectPr.insert(0, el)
    return el


@REGISTRY.op(
    "set_page_setup",
    "content",
    '{section?, blockIndex?, paper?: "A3"|"A4"|"A5"|"B5"|"Letter"|"Legal"|"Tabloid", width?, height?, orientation?: "portrait"|"landscape", '
    "margins?: {top, right, bottom, left, header, footer, gutter}, columns?: {count, spacing}, titlePg?: bool, pageNumberStart?, pageNumberFormat?}",
    note='lengths as "2.54cm" / "1in" / "72pt" or twips; section or blockIndex picks one section, neither = all; docs_read sections=true lists them',
)
def _set_page_setup(dc: _DocCtx, op: dict[str, Any]) -> None:
    if op.get("paper") is not None and op["paper"] not in _PAPER:
        raise OpError(f"paper must be one of {list(_PAPER)}", available=list(_PAPER), wanted=str(op["paper"]))
    for s in _sections_for(dc, op):
        if op.get("paper"):
            w, h = _PAPER[op["paper"]]
            s.page_width, s.page_height = Twips(w), Twips(h)
        if op.get("width") is not None:
            s.page_width = Twips(_twips(op["width"]))
        if op.get("height") is not None:
            s.page_height = Twips(_twips(op["height"]))
        orient = op.get("orientation")
        if orient in ("portrait", "landscape"):
            w, h = s.page_width, s.page_height
            if (orient == "landscape") != (w > h):
                s.page_width, s.page_height = h, w
            s.orientation = WD_ORIENT.LANDSCAPE if orient == "landscape" else WD_ORIENT.PORTRAIT
        for key, attr in (
            ("top", "top_margin"), ("right", "right_margin"), ("bottom", "bottom_margin"), ("left", "left_margin"),
            ("header", "header_distance"), ("footer", "footer_distance"), ("gutter", "gutter"),
        ):
            if (op.get("margins") or {}).get(key) is not None:
                setattr(s, attr, Twips(_twips(op["margins"][key])))
        if op.get("titlePg") is not None:
            s.different_first_page_header_footer = bool(op["titlePg"])
        sectPr = s._sectPr
        if op.get("columns"):
            cols = _sectpr_child(sectPr, "w:cols", ("w:pgSz", "w:pgMar", "w:paperSrc", "w:pgBorders", "w:lnNumType", "w:pgNumType"))
            cols.set(qn("w:num"), str(int(op["columns"].get("count", 1))))
            if op["columns"].get("spacing") is not None:
                cols.set(qn("w:space"), str(_twips(op["columns"]["spacing"])))
        if op.get("pageNumberStart") is not None or op.get("pageNumberFormat"):
            pg = _sectpr_child(sectPr, "w:pgNumType", ("w:pgSz", "w:pgMar", "w:paperSrc", "w:pgBorders", "w:lnNumType"))
            if op.get("pageNumberStart") is not None:
                pg.set(qn("w:start"), str(int(op["pageNumberStart"])))
            if op.get("pageNumberFormat"):
                pg.set(qn("w:fmt"), str(op["pageNumberFormat"]))


@REGISTRY.op(
    "insert_section_break",
    "content",
    '{afterBlockIndex, type?: "nextPage"|"continuous"|"evenPage"|"oddPage"}',
    note="the blocks after afterBlockIndex become a new section (a copy of the current setup; change it with set_page_setup section: N)",
    required=("afterBlockIndex",),
)
def _insert_section_break(dc: _DocCtx, op: dict[str, Any]) -> dict[str, Any]:
    kinds = {"nextPage": WD_SECTION_START.NEW_PAGE, "continuous": WD_SECTION_START.CONTINUOUS, "evenPage": WD_SECTION_START.EVEN_PAGE, "oddPage": WD_SECTION_START.ODD_PAGE}
    kind = op.get("type", "nextPage")
    if kind not in kinds:
        raise OpError(f"type must be one of {list(kinds)}")
    blocks = dc.blocks()
    i = _check_index(op["afterBlockIndex"], len(blocks))
    ranges = _section_ranges(dc.doc)
    k = next(n for n, (a, b) in enumerate(ranges) if a <= i <= b)
    if ranges[k][1] == i:
        raise OpError(f"block {i} already ends section {k}")
    current = list(dc.doc.sections)[k]._sectPr
    host = blocks[i]
    if host.tag != W_P:
        p = dc.doc.add_paragraph()
        p._p.getparent().remove(p._p)
        host.addnext(p._p)
        host = p._p
    host.get_or_add_pPr().append(copy.deepcopy(current))
    Section(current, dc.doc.part).start_type = kinds[kind]
    return {"section": k + 1}


@REGISTRY.op(
    "define_style",
    "content",
    '{styleId, name?, type?: "paragraph"|"character"|"table", basedOn?, next?, quickFormat?, '
    "paragraph?: {align, spaceBefore, spaceAfter, lineSpacing, indentLeft, indentRight, firstLineIndent, keepNext, keepLines, pageBreakBefore, outlineLevel}, "
    "run?: {bold, italic, underline, strike, caps, smallCaps, color, highlight, fontSize, fontFamily, eastAsiaFontFamily}}",
    note='creates or patches a style; only the given fields change; put it on paragraphs with {op: "applyStyle", target, styleId}',
    required=("styleId",),
)
def _define_style(dc: _DocCtx, op: dict[str, Any]) -> dict[str, Any]:
    types = {"paragraph": WD_STYLE_TYPE.PARAGRAPH, "character": WD_STYLE_TYPE.CHARACTER, "table": WD_STYLE_TYPE.TABLE}
    kind = op.get("type", "paragraph")
    if kind not in types:
        raise OpError("type must be paragraph, character or table")
    style = _find_style(dc.doc, op["styleId"])
    created = style is None
    if created:
        style = dc.doc.styles.add_style(op.get("name") or op["styleId"], types[kind])
        style.element.styleId = op["styleId"]
    elif op.get("name"):
        style.name = op["name"]
    if "basedOn" in op:
        base = _find_style(dc.doc, op["basedOn"]) if op["basedOn"] else None
        if op["basedOn"] and base is None:
            raise OpError(f'basedOn: no style "{op["basedOn"]}"', reason="target_not_found")
        style.base_style = base
    if op.get("next") and kind == "paragraph":
        nxt = _find_style(dc.doc, op["next"])
        if nxt is not None:
            style.next_paragraph_style = nxt
    if "quickFormat" in op:
        style.quick_style = bool(op["quickFormat"])
    run = op.get("run") or {}
    font = style.font
    for key in ("bold", "italic", "underline", "strike"):
        if key in run:
            setattr(font, key, run[key])
    if "caps" in run:
        font.all_caps = run["caps"]
    if "smallCaps" in run:
        font.small_caps = run["smallCaps"]
    if "color" in run:
        font.color.rgb = RGBColor.from_string(_hex(run["color"])) if run["color"] else None
    if "fontSize" in run:
        font.size = Pt(run["fontSize"]) if run["fontSize"] else None
    if "fontFamily" in run:
        font.name = run["fontFamily"]
    if run.get("eastAsiaFontFamily"):
        style.element.get_or_add_rPr().get_or_add_rFonts().set(qn("w:eastAsia"), run["eastAsiaFontFamily"])
    para = op.get("paragraph") or {}
    if para and kind != "paragraph":
        raise OpError("paragraph fields need type paragraph")
    if para:
        pf = style.paragraph_format
        if "align" in para:
            pf.alignment = _ALIGN.get(para["align"]) if para["align"] else None
        for key, attr in (("spaceBefore", "space_before"), ("spaceAfter", "space_after"), ("indentLeft", "left_indent"), ("indentRight", "right_indent"), ("firstLineIndent", "first_line_indent")):
            if key in para:
                setattr(pf, attr, Twips(_twips(para[key])) if para[key] is not None else None)
        if "lineSpacing" in para:
            pf.line_spacing = float(para["lineSpacing"]) if para["lineSpacing"] is not None else None
        for key, attr in (("keepNext", "keep_with_next"), ("keepLines", "keep_together"), ("pageBreakBefore", "page_break_before")):
            if key in para:
                setattr(pf, attr, para[key])
        if para.get("outlineLevel") is not None:
            pPr = style.element.get_or_add_pPr()
            e = OxmlElement("w:outlineLvl")
            e.set(qn("w:val"), str(int(para["outlineLevel"])))
            pPr.append(e)
    return {"styleId": style.style_id, "created": created}


def _isolate_span(p: Paragraph, text: str, occurrence: int) -> list[Run]:
    runs = _runs(p)
    full = "".join(r.text for r in runs)
    starts = [m.start() for m in re.finditer(re.escape(text), full)]
    if len(starts) < occurrence:
        raise OpError(f'text "{text}" not found {occurrence} time(s) in the block', reason="target_not_found")
    s = starts[occurrence - 1]
    e = s + len(text)

    def split_at(offset: int) -> None:
        pos = 0
        for r in _runs(p):
            t = r.text
            if pos < offset < pos + len(t):
                right = copy.deepcopy(r._r)
                r._r.addnext(right)
                r.text = t[: offset - pos]
                Run(right, p).text = t[offset - pos :]
                return
            pos += len(t)

    split_at(e)
    split_at(s)
    out, pos = [], 0
    for r in _runs(p):
        t = r.text
        if pos >= s and pos + len(t) <= e and t:
            out.append(r)
        pos += len(t)
    return out


@REGISTRY.op(
    "add_comment",
    "content",
    "{blockIndex, comment, text?, occurrence?, author?, initials?}",
    note="anchors a new thread to a block, or to an exact text span inside it (occurrence picks one of several, 1-based); \\n in comment starts a paragraph",
    required=("blockIndex", "comment"),
)
def _add_comment(dc: _DocCtx, op: dict[str, Any]) -> dict[str, Any]:
    blocks = dc.blocks()
    i = _check_index(op["blockIndex"], len(blocks))
    paras = _paragraphs_of(dc.doc, blocks[i])
    if not paras:
        raise OpError(f"block {i} has no paragraph to anchor a comment")
    if op.get("text"):
        runs = []
        for p in paras:
            try:
                runs = _isolate_span(p, str(op["text"]), int(op.get("occurrence", 1)))
                break
            except OpError:
                continue
        if not runs:
            raise OpError(f'text "{op["text"]}" not found in block {i}', reason="target_not_found")
    else:
        runs = [r for p in paras for r in _runs(p)] or [paras[0].add_run("")]
    lines = str(op["comment"]).split("\n")
    c = dc.doc.add_comment(runs if len(runs) > 1 else runs[0], text=lines[0], author=op.get("author", "GenOffice"), initials=op.get("initials", "GO"))
    for line in lines[1:]:
        c.add_paragraph(line)
    return {"id": str(c.comment_id)}


_CORE_KEYS = {
    "title": "title", "subject": "subject", "creator": "author", "author": "author", "keywords": "keywords",
    "description": "comments", "comments": "comments", "category": "category", "lastModifiedBy": "last_modified_by",
    "contentStatus": "content_status", "identifier": "identifier", "language": "language", "version": "version",
}


@REGISTRY.op(
    "set_properties",
    "content",
    '{core?: {title, subject, creator, keywords, description, lastModifiedBy, category, …}, app?, custom?, clear?: "all"}',
    note="a string sets the value, null clears it; app and custom properties are not ported",
)
def _set_properties(dc: _DocCtx, op: dict[str, Any]) -> None:
    if op.get("app") or op.get("custom"):
        raise OpError("only core properties are supported by the Python port (app / custom are not)")
    cp = dc.doc.core_properties
    if op.get("clear") == "all":
        for attr in set(_CORE_KEYS.values()):
            setattr(cp, attr, "")
    for key, value in (op.get("core") or {}).items():
        attr = _CORE_KEYS.get(key)
        if attr is None:
            raise OpError(f"unknown core property {key!r}", available=list(_CORE_KEYS), wanted=key)
        setattr(cp, attr, "" if value is None else str(value))


for _name, _sig, _why in (
    ("insert_text_box", "{afterBlockIndex?, text|html, x, y, width, height, anchor?, wrap?}", "floating text boxes (DrawingML anchors) are not ported"),
    ("insert_chart", "{kind, title?, categories, series, afterBlockIndex?}", "native Word charts need a chart part writer the port does not have"),
    ("edit_chart", "{blockIndex, categories?, series?}", "chart parts are not ported"),
    ("set_watermark", "{text?|image?, color?, opacity?, diagonal?, scale?, washout?}", "VML watermarks are not ported"),
    ("reply_comment", "{id, comment, author?}", "comment threads (commentsExtended) are not ported"),
    ("resolve_comment", "{id, resolved?}", "comment threads (commentsExtended) are not ported"),
    ("delete_comment", "{id, withReplies?}", "comment deletion is not ported"),
    ("accept_changes", "{all?|ids?|author?|type?|blockIndex?|blockRange?|before?}", "tracked changes are not ported"),
    ("reject_changes", "{all?|ids?|author?|type?|blockIndex?|blockRange?|before?}", "tracked changes are not ported"),
    ("insert_footnote", "{blockIndex, text, afterText?}", "footnotes are not ported"),
    ("insert_endnote", "{blockIndex, text, afterText?}", "endnotes are not ported"),
    ("edit_note", "{id, find, replace, matchCase?, kind?}", "footnotes/endnotes are not ported"),
    ("delete_note", "{id, kind?}", "footnotes/endnotes are not ported"),
):
    REGISTRY.unavailable(_name, "content", _sig, _why)


# ---------------------------------------------------------------- sections / fields / comments


def _section_ranges(doc: Any) -> list[tuple[int, int]]:
    out, start = [], 0
    blocks = _block_elements(doc)
    for i, el in enumerate(blocks):
        if el.tag == W_P:
            pPr = el.find(qn("w:pPr"))
            if pPr is not None and pPr.find(W_SECTPR) is not None:
                out.append((start, i))
                start = i + 1
    out.append((start, len(blocks) - 1))
    return out


def _sections_detail(doc: Any) -> list[dict[str, Any]]:
    out = []
    for k, (s, (a, b)) in enumerate(zip(doc.sections, _section_ranges(doc))):
        def cm(v: Any) -> float | None:
            return round(v / 360000, 2) if v is not None else None

        out.append(
            {
                "index": k,
                "blockRange": [a, b],
                "width_cm": cm(s.page_width),
                "height_cm": cm(s.page_height),
                "orientation": "landscape" if s.orientation == WD_ORIENT.LANDSCAPE else "portrait",
                "margins_cm": {
                    "top": cm(s.top_margin), "right": cm(s.right_margin), "bottom": cm(s.bottom_margin), "left": cm(s.left_margin),
                },
                "start": str(s.start_type).split(".")[-1].split(" ")[0].lower(),
            }
        )
    return out


def _block_index_of(doc: Any) -> dict[Any, int]:
    return {el: i for i, el in enumerate(_block_elements(doc))}


def _top_block(el: Any, index: dict[Any, int]) -> int | None:
    while el is not None:
        if el in index:
            return index[el]
        el = el.getparent()
    return None


def _fields(doc: Any) -> list[dict[str, Any]]:
    index = _block_index_of(doc)
    out: list[dict[str, Any]] = []
    stack: list[dict[str, Any]] = []
    body = doc.element.body
    for el in body.iter(qn("w:fldChar"), qn("w:instrText"), qn("w:t"), qn("w:fldSimple")):
        tag = el.tag
        if tag == qn("w:fldSimple"):
            instr = (el.get(qn("w:instr")) or "").strip()
            out.append({"block": _top_block(el, index), "type": instr.split(" ")[0] if instr else "", "instr": instr, "result": "".join(t.text or "" for t in el.iter(qn("w:t")))})
        elif tag == qn("w:fldChar"):
            kind = el.get(qn("w:fldCharType"))
            if kind == "begin":
                stack.append({"block": _top_block(el, index), "instr": "", "result": "", "separated": False})
            elif kind == "separate" and stack:
                stack[-1]["separated"] = True
            elif kind == "end" and stack:
                f = stack.pop()
                instr = f["instr"].strip()
                out.append({"block": f["block"], "type": instr.split(" ")[0] if instr else "", "instr": instr, "result": f["result"]})
        elif tag == qn("w:instrText") and stack:
            stack[-1]["instr"] += el.text or ""
        elif tag == qn("w:t") and stack and stack[-1]["separated"]:
            stack[-1]["result"] += el.text or ""
    return out


def _comments(doc: Any) -> list[dict[str, Any]]:
    try:
        comments = list(doc.comments)
    except Exception:
        return []
    index = _block_index_of(doc)
    anchors = {}
    for el in doc.element.body.iter(qn("w:commentRangeStart"), qn("w:commentReference")):
        cid = el.get(qn("w:id"))
        anchors.setdefault(cid, _top_block(el, index))
    return [
        {"id": str(c.comment_id), "author": c.author, "initials": c.initials, "text": c.text, "block": anchors.get(str(c.comment_id))}
        for c in comments
    ]


def _properties(doc: Any) -> dict[str, Any]:
    cp = doc.core_properties
    out = {}
    for key in ("title", "subject", "author", "keywords", "comments", "category", "last_modified_by", "revision", "created", "modified"):
        v = getattr(cp, key, None)
        if v not in (None, ""):
            out[key] = v.isoformat() if hasattr(v, "isoformat") else v
    return out


# ---------------------------------------------------------------- read / apply / check


def _open(ctx: Context, file: str) -> tuple[Path, Any]:
    path = ctx.input_file(file)
    try:
        return path, Document(str(path))
    except Exception as e:
        raise GenOfficeError(EXIT.conversion, f"not a readable .docx: {path.name} ({e})", reason="conversion_failed")


def read(
    ctx: Context,
    file: str,
    *,
    range: str | None = None,
    html: bool = False,
    full: bool = False,
    max_chars: int | None = None,
    comments: bool = False,
    revisions: bool = False,
    styles: bool = False,
    header_footer: bool = False,
    sections: bool = False,
    fields: bool = False,
    notes: bool = False,
    properties: bool = False,
) -> CommandResult:
    path, doc = _open(ctx, file)
    blocks = _block_elements(doc)
    n = len(blocks)
    lo, hi = 0, n - 1
    if range:
        m = re.fullmatch(r"\s*(\d+)\s*(?:-\s*(\d+))?\s*", str(range))
        if not m:
            raise GenOfficeError(EXIT.usage, f"range must be a-b, got {range!r}", reason="invalid_argument")
        lo = int(m.group(1))
        hi = int(m.group(2)) if m.group(2) else lo
        if lo >= n:
            raise GenOfficeError(EXIT.usage, f"range starts past the last block ({n} blocks)", {"valid_range": [0, n - 1]}, reason="out_of_range")
        hi = min(hi, n - 1)
    limit = None if full else (max_chars if max_chars is not None else PREVIEW_CHARS)
    out = [_describe(doc, i, blocks[i], limit, html) for i in builtins_range(lo, hi + 1)]
    detail: dict[str, Any] = {"blocks": out, "total_blocks": n}
    if comments:
        detail["comments"] = _comments(doc)
    if revisions:
        detail["revisions"] = []
        detail["revisions_note"] = "tracked changes are not read by the Python port"
    if styles:
        detail["styles"] = {
            "paragraph": [s.style_id for s in doc.styles if s.type == WD_STYLE_TYPE.PARAGRAPH],
            "character": [s.style_id for s in doc.styles if s.type == WD_STYLE_TYPE.CHARACTER],
            "tableStyles": [s.style_id for s in doc.styles if s.type == WD_STYLE_TYPE.TABLE],
        }
    if header_footer:
        hf = []
        for k, s in enumerate(doc.sections):
            for kind in ("header", "footer"):
                for view, attr in (("default", kind), ("first", f"first_page_{kind}"), ("even", f"even_page_{kind}")):
                    part = getattr(s, attr)
                    if part.is_linked_to_previous and (k > 0 or view != "default"):
                        continue
                    text = "\n".join("".join(t.text or "" for t in p._p.iter(qn("w:t"))) for p in part.paragraphs)
                    if text or view == "default":
                        hf.append({"section": k, "kind": kind, "view": view, "text": text})
        detail["header_footer"] = hf
    if sections:
        detail["sections"] = _sections_detail(doc)
    if fields:
        detail["fields"] = _fields(doc)
    if notes:
        detail["notes"] = []
        detail["notes_note"] = "footnotes/endnotes are not read by the Python port"
    if properties:
        detail["properties"] = _properties(doc)
    shown = len(out)
    return CommandResult(summary=f"read {shown} of {n} blocks of {path.name}", detail=detail)


builtins_range = range  # `range` is a keyword argument of read()


def _parse_ops(ops: Any) -> Any:
    if isinstance(ops, (str, bytes)):
        try:
            return json.loads(ops)
        except json.JSONDecodeError as e:
            raise GenOfficeError(EXIT.usage, f"ops is not valid JSON: {e}", reason="invalid_json", suggestion="re-serialize the ops array")
    return ops


def apply(
    ctx: Context,
    file: str,
    ops: Any,
    *,
    track: bool = False,
    author: str | None = None,
    dry_run: bool = False,
    mode: str = "atomic",
    out: str | None = None,
    force: bool = False,
    ops_base: str | Path | None = None,
) -> CommandResult:
    path, doc = _open(ctx, file)
    target = ctx.output_file(out, force=force, editing=path) if out and not dry_run else path
    dc = _DocCtx(ctx, doc, [ctx.base, Path(ops_base) if ops_base else None, path.parent])
    outcome = REGISTRY.run_batch(_parse_ops(ops), dc, mode)  # type: ignore[arg-type]
    warnings = list(dc.warnings)
    if track:
        warnings.append(Warning("track_unsupported", "tracked changes are not recorded by the Python port; the edits were applied directly"))
    written = not dry_run and outcome.applied > 0
    if written:
        doc.save(str(target))
    blocks = len(_block_elements(doc))
    if dry_run:
        summary = f"dry run: {outcome.applied} of {outcome.total} ops would apply to {path.name}"
    else:
        summary = f"applied {outcome.applied} ops to {target.name}"
    r = CommandResult(summary=summary, output_path=str(target) if written else None, detail={"blocks": blocks}, warnings=warnings)
    return batch_result(r, outcome)


_PLACEHOLDER = re.compile(r"\bTODO\b|\bTBD\b|\bXX+%?|lorem ipsum|\{\{[^{}]+\}\}|\[(?:insert|placeholder)[^\]]*\]", re.I)


def check(ctx: Context, file: str) -> CommandResult:
    path, doc = _open(ctx, file)
    blocks = _block_elements(doc)
    issues: list[dict[str, Any]] = []

    def add(code: str, level: str, i: int | None, message: str, suggest: dict[str, Any] | None = None) -> None:
        issue: dict[str, Any] = {"code": code, "level": level, "path": f"b_{i}" if i is not None else "document", "message": message}
        if suggest:
            issue["suggest"] = suggest
        issues.append(issue)

    prev_level = 0
    for i, el in enumerate(blocks):
        kind, extra = _block_kind(doc, el)
        text = _block_text(doc, el)
        m = _PLACEHOLDER.search(text)
        if m:
            add("placeholder_left", "warning", i, f'placeholder text "{m.group(0)}" in block {i}')
        if kind == "heading":
            level = extra["level"]
            if not text.strip():
                add("empty_heading", "warning", i, f"heading at block {i} has no text", {"op": "deleteBlocks", "target": {"blockIndexes": [i]}})
            if prev_level and level > prev_level + 1:
                add("heading_level_skip", "warning", i, f"heading level jumps from {prev_level} to {level} at block {i}", {"op": "setHeadingLevel", "target": {"blockIndexes": [i]}, "level": prev_level + 1})
            prev_level = level
        for blip in el.xpath('.//*[local-name()="blip"]'):
            rid = blip.get(qn("r:embed"))
            if rid and rid not in doc.part.rels:
                add("missing_image", "error", i, f"picture in block {i} points at a missing part ({rid})")
    bookmarks = set(doc.element.body.xpath(".//w:bookmarkStart/@w:name"))
    for f in _fields(doc):
        t = f["type"].upper()
        if t == "TOC" and not f["result"].strip():
            add("field_not_evaluated", "warning", f["block"], "table of contents has no entries yet; Word fills it on open (update fields)")
        elif t in ("PAGE", "NUMPAGES", "SECTIONPAGES", "AUTHOR", "FILENAME"):
            add("field_not_evaluated", "info", f["block"], f"{t} field is computed by Word on open")
        elif t in ("REF", "PAGEREF"):
            parts = f["instr"].split()
            name = parts[1] if len(parts) > 1 else ""
            if name not in bookmarks:
                add("broken_ref", "error", f["block"], f'{t} field points at missing bookmark "{name}"')
    for c in _comments(doc):
        add("open_comment", "info", c["block"], f'open comment {c["id"]} by {c["author"]}: {c["text"][:80]}')
    counts = {lvl: sum(1 for x in issues if x["level"] == lvl) for lvl in ("error", "warning", "info")}
    summary = (
        f"{len(issues)} issues in {path.name} ({counts['error']} errors, {counts['warning']} warnings, {counts['info']} info)"
        if issues
        else f"no issues in {path.name}"
    )
    return CommandResult(summary=summary, detail={"issues": issues, "counts": counts, "blocks": len(blocks)})


# ---------------------------------------------------------------- create / export


def _new_document() -> Any:
    return Document()


def create_from_html(ctx: Context, html: str, out: str, *, force: bool = False, base_dir: str | Path | None = None) -> CommandResult:
    target = ctx.output_file(out, force=force)
    doc = _new_document()
    warnings: list[Warning] = []
    bases = [Path(base_dir) if base_dir else None, ctx.base]
    _HtmlBuilder(doc, lambda src: _load_image(ctx, src, [b for b in bases if b]), warnings).build(html, doc)
    if not _block_elements(doc):
        doc.add_paragraph()
    doc.save(str(target))
    n = len(_block_elements(doc))
    return CommandResult(summary=f"created {target.name} ({n} blocks)", output_path=str(target), detail={"blocks": n}, warnings=warnings)


def markdown_to_html(text: str) -> str:
    from markdown_it import MarkdownIt

    md = MarkdownIt("commonmark", {"html": True}).enable("table").enable("strikethrough")
    return md.render(text)


def create_from_markdown(ctx: Context, text: str, out: str, *, force: bool = False, base_dir: str | Path | None = None) -> CommandResult:
    return create_from_html(ctx, markdown_to_html(text), out, force=force, base_dir=base_dir)


def from_text_pages(ctx: Context, pages: list[str], out: str, *, force: bool = False) -> CommandResult:
    target = ctx.output_file(out, force=force)
    doc = _new_document()
    for k, page in enumerate(pages):
        if k:
            doc.add_page_break()
        for chunk in re.split(r"\n\s*\n", page or ""):
            lines = [ln.strip() for ln in chunk.splitlines() if ln.strip()]
            if lines:
                doc.add_paragraph(" ".join(lines))
    if not _block_elements(doc):
        doc.add_paragraph()
    doc.save(str(target))
    n = len(_block_elements(doc))
    return CommandResult(summary=f"created {target.name} from {len(pages)} pages ({n} blocks)", output_path=str(target), detail={"blocks": n, "pages": len(pages)})


def _md_escape(text: str) -> str:
    text = text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    return re.sub(r"([\\*_`\[\]])", r"\\\1", text)


def _wrap_marks(text: str, marks: str) -> str:
    if not marks or not text.strip():
        return text
    lead = text[: len(text) - len(text.lstrip())]
    trail = text[len(text.rstrip()) :]
    return f"{lead}{marks}{text.strip()}{marks[::-1] if marks != '~~' else marks}{trail}"


def _inline_md(p: Paragraph, counter: dict[str, int]) -> str:
    out = []
    for item in p.iter_inner_content():
        if isinstance(item, Run):
            if item._r.xpath(".//w:drawing | .//w:pict"):
                counter["images"] += 1
            t = _md_escape(item.text)
            marks = ""
            if item.bold and item.italic:
                marks = "***"
            elif item.bold:
                marks = "**"
            elif item.italic:
                marks = "*"
            t = _wrap_marks(t, marks)
            if item.font.strike:
                t = _wrap_marks(t, "~~")
            out.append(t)
        else:
            url = getattr(item, "url", "") or ""
            text = _md_escape(item.text)
            out.append(f"[{text}]({url})" if url else text)
    return "".join(out)


def to_markdown(path: str | Path) -> tuple[str, dict[str, int]]:
    doc = Document(str(path))
    counter = {"images": 0}
    parts: list[tuple[str, str]] = []
    for el in _block_elements(doc):
        kind, extra = _block_kind(doc, el)
        if kind == "table":
            t = Table(el, doc._body)
            rows = [[_md_escape(c.text).replace("|", "\\|").replace("\n", "<br>") for c in _unique_cells(r)] for r in t.rows]
            width = max(len(r) for r in rows)
            rows = [r + [""] * (width - len(r)) for r in rows]
            lines = ["| " + " | ".join(rows[0]) + " |", "| " + " | ".join(["---"] * width) + " |"]
            lines += ["| " + " | ".join(r) + " |" for r in rows[1:]]
            parts.append(("table", "\n".join(lines)))
            counter["images"] += len(el.xpath(".//w:drawing"))
            continue
        if el.tag != W_P:
            continue
        p = Paragraph(el, doc._body)
        text = _inline_md(p, counter)
        if kind == "heading":
            parts.append(("heading", "#" * min(6, extra["level"]) + " " + text.strip()))
        elif kind == "list_item":
            info = extra["list"]
            bullet = "1." if info["kind"] == "number" else "-"
            parts.append(("list", "  " * info["level"] * (2 if bullet == "1." else 1) + f"{bullet} {text.strip()}"))
        elif kind in ("paragraph",) and text.strip():
            parts.append(("paragraph", text.strip()))
    lines: list[str] = []
    prev = None
    for kind, text in parts:
        if lines:
            lines.append("\n" if kind == "list" and prev == "list" else "\n\n")
        lines.append(text)
        prev = kind
    md = "".join(lines)
    return (md + "\n" if md else md), counter


def _inline_html(doc: Any, p: Paragraph) -> str:
    out = []
    for item in p.iter_inner_content():
        if isinstance(item, Run):
            for blip in item._r.xpath('.//*[local-name()="blip"]'):
                rid = blip.get(qn("r:embed"))
                part = doc.part.related_parts.get(rid) if rid else None
                if part is not None:
                    data = base64.b64encode(part.blob).decode("ascii")
                    out.append(f'<img src="data:{part.content_type};base64,{data}">')
            t = html_escape(item.text).replace("\n", "<br>")
            if item.bold:
                t = f"<strong>{t}</strong>"
            if item.italic:
                t = f"<em>{t}</em>"
            if item.underline:
                t = f"<u>{t}</u>"
            if item.font.strike:
                t = f"<s>{t}</s>"
            if item.font.superscript:
                t = f"<sup>{t}</sup>"
            if item.font.subscript:
                t = f"<sub>{t}</sub>"
            out.append(t)
        else:
            url = html_escape(getattr(item, "url", "") or "")
            out.append(f'<a href="{url}">{html_escape(item.text)}</a>')
    return "".join(out)


def _block_html(doc: Any, el: Any) -> str:
    if el.tag == W_TBL:
        t = Table(el, doc._body)
        rows = []
        for r in t.rows:
            cells = "".join(f"<td>{'<br>'.join(_inline_html(doc, p) for p in c.paragraphs)}</td>" for c in _unique_cells(r))
            rows.append(f"<tr>{cells}</tr>")
        return f"<table>{''.join(rows)}</table>"
    if el.tag != W_P:
        return f"<p>{html_escape(_block_text(doc, el))}</p>"
    p = Paragraph(el, doc._body)
    kind, extra = _block_kind(doc, el)
    inner = _inline_html(doc, p)
    align = {WD_ALIGN_PARAGRAPH.CENTER: "center", WD_ALIGN_PARAGRAPH.RIGHT: "right", WD_ALIGN_PARAGRAPH.JUSTIFY: "justify"}.get(p.alignment)
    style = f' style="text-align:{align}"' if align else ""
    if kind == "heading":
        n = min(6, extra["level"])
        return f"<h{n}{style}>{inner}</h{n}>"
    if kind == "list_item":
        tag = "ol" if extra["list"]["kind"] == "number" else "ul"
        return f"<{tag}><li>{inner}</li></{tag}>"
    return f"<p{style}>{inner}</p>"


def to_html(path: str | Path) -> str:
    doc = Document(str(path))
    body: list[str] = []
    open_lists: list[str] = []

    def close_to(level: int) -> None:
        while len(open_lists) > level:
            body.append(f"</{open_lists.pop()}>")

    for el in _block_elements(doc):
        kind, extra = _block_kind(doc, el)
        if kind == "list_item":
            tag = "ol" if extra["list"]["kind"] == "number" else "ul"
            level = extra["list"]["level"]
            close_to(level + 1)
            while len(open_lists) < level + 1:
                body.append(f"<{tag}>")
                open_lists.append(tag)
            body.append(f"<li>{_inline_html(doc, Paragraph(el, doc._body))}</li>")
            continue
        close_to(0)
        if kind in ("empty", "page_break"):
            continue
        body.append(_block_html(doc, el))
    close_to(0)
    title = html_escape(doc.core_properties.title or Path(path).stem)
    return (
        '<!DOCTYPE html>\n<html><head><meta charset="utf-8">'
        f"<title>{title}</title></head>\n<body>\n" + "\n".join(body) + "\n</body></html>\n"
    )


def info(path: str | Path) -> dict[str, Any]:
    p = Path(path)
    doc = Document(str(p))
    blocks = _block_elements(doc)
    headings = []
    tables = 0
    for i, el in enumerate(blocks):
        kind, extra = _block_kind(doc, el)
        if kind == "heading":
            headings.append({"index": i, "level": extra["level"], "text": clip(_block_text(doc, el), 120)[0]})
        elif kind == "table":
            tables += 1
    return {
        "format": "docx",
        "blocks": len(blocks),
        "headings": headings,
        "tables": tables,
        "images": len(doc.element.body.xpath('.//*[local-name()="pic"]')),
        "sections": len(doc.sections),
        "properties": _properties(doc),
        "size_bytes": p.stat().st_size,
    }


# ---------------------------------------------------------------- merge

_MERGE = re.compile(r"\{\{\s*([^{}]+?)\s*\}\}")


def _flatten(data: dict[str, Any], prefix: str = "") -> dict[str, str]:
    out: dict[str, str] = {}
    for k, v in data.items():
        key = f"{prefix}{k}"
        if isinstance(v, dict):
            out.update(_flatten(v, f"{key}."))
        elif v is None:
            out[key] = ""
        elif isinstance(v, bool):
            out[key] = "true" if v else "false"
        elif isinstance(v, (list, tuple)):
            out[key] = ", ".join(str(x) for x in v)
        else:
            out[key] = str(v)
    return out


def _rpr_key(run: Run) -> bytes:
    from lxml import etree

    rPr = run._r.rPr
    return etree.tostring(rPr) if rPr is not None else b""


def _merge_paragraph(p: Paragraph, values: dict[str, str], used: set[str], unresolved: list[dict[str, Any]], location: dict[str, Any]) -> int:
    runs = _runs(p)
    texts = [r.text for r in runs]
    full = "".join(texts)
    starts, pos = [], 0
    for t in texts:
        starts.append(pos)
        pos += len(t)

    filled = 0
    for m in reversed(list(_MERGE.finditer(full))):
        key = m.group(1).strip()
        if key not in values:
            unresolved.append({"placeholder": m.group(0), "key": key, "reason": "no_key", "location": location})
            continue
        i, a = _run_at(starts, texts, m.start(), end=False)
        j, b = _run_at(starts, texts, m.end(), end=True)
        if i != j and len({_rpr_key(runs[k]) for k in range(i, j + 1) if texts[k]}) > 1:
            unresolved.append({"placeholder": m.group(0), "key": key, "reason": "split_placeholder", "location": location})
            continue
        if i == j:
            texts[i] = texts[i][:a] + values[key] + texts[i][b:]
            runs[i].text = texts[i]
        else:
            texts[i] = texts[i][:a] + values[key]
            runs[i].text = texts[i]
            for k in range(i + 1, j):
                texts[k] = ""
                runs[k].text = ""
            texts[j] = texts[j][b:]
            runs[j].text = texts[j]
        used.add(key)
        filled += 1
    return filled


def merge(ctx: Context, file: str, data: dict[str, Any], out: str, *, force: bool = False, strict: bool = False) -> CommandResult:
    path, doc = _open(ctx, file)
    if not isinstance(data, dict):
        raise GenOfficeError(EXIT.usage, "data must be a JSON object", reason="invalid_argument")
    target = ctx.output_file(out, force=force)
    values = _flatten(data)
    used: set[str] = set()
    unresolved: list[dict[str, Any]] = []
    filled = 0
    for i, el in enumerate(_block_elements(doc)):
        loc: dict[str, Any] = {"block": i}
        if el.tag == W_TBL:
            loc["table"] = True
        for p in _paragraphs_of(doc, el):
            filled += _merge_paragraph(p, values, used, unresolved, loc)
    seen_parts: set[Any] = set()
    for k, s in enumerate(doc.sections):
        for kind in ("header", "footer", "first_page_header", "first_page_footer", "even_page_header", "even_page_footer"):
            part = getattr(s, kind)
            if part.is_linked_to_previous and k > 0:
                continue
            el = part._element
            if el in seen_parts:
                continue
            seen_parts.add(el)
            for p_el in el.iter(W_P):
                filled += _merge_paragraph(Paragraph(p_el, part), values, used, unresolved, {"section": k, kind.split("_")[-1]: True, "part": kind})
    detail = {
        "used_keys": sorted(used),
        "unused_keys": sorted(k for k in values if k not in used),
        "unresolved_placeholders": unresolved,
        "filled": filled,
    }
    if unresolved and strict:
        raise GenOfficeError(
            EXIT.usage,
            f"{len(unresolved)} placeholders left unresolved in {path.name}; nothing was written",
            detail,
            reason="unresolved_placeholder",
            suggestion="add the missing keys to data (or retype a split_placeholder in one run in the template) and rerun",
        )
    warnings = []
    if unresolved:
        warnings.append(Warning("unresolved_placeholder", f"{len(unresolved)} placeholders left in place without a value", "see detail.unresolved_placeholders"))
    doc.save(str(target))
    return CommandResult(summary=f"filled {filled} placeholders of {path.name} into {target.name}", output_path=str(target), detail=detail, warnings=warnings)
