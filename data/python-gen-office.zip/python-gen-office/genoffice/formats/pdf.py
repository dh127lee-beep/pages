"""PDF text layer, page by page (pypdf). Scanned pages come back with empty text."""

from __future__ import annotations

import builtins
from pathlib import Path
from typing import Any

from ..context import Context
from ..ops import clip
from ..result import EXIT, CommandResult, GenOfficeError

DEFAULT_PAGES = 20
PAGE_CHARS = 4000


def _open(path: Path, password: str | None):
    from pypdf import PdfReader
    from pypdf.errors import PdfReadError

    try:
        reader = PdfReader(str(path))
    except PdfReadError as e:
        raise GenOfficeError(EXIT.conversion, f"not a readable PDF: {e}", reason="conversion_failed") from e
    if reader.is_encrypted:
        if not password or not reader.decrypt(password):
            raise GenOfficeError(
                EXIT.usage,
                "the PDF is encrypted" + (" and the password is wrong" if password else ""),
                {"encrypted": True},
                reason="invalid_argument",
                suggestion="pass the password",
            )
    return reader


def _metadata(reader: Any) -> dict[str, Any]:
    meta = reader.metadata or {}
    return {
        k: str(meta.get(f"/{k.capitalize()}"))
        for k in ("title", "author", "producer")
        if meta.get(f"/{k.capitalize()}")
    }


def parse_range(text: str, count: int) -> tuple[int, int]:
    """'3-7' (1-based, inclusive) or '4'."""
    try:
        if "-" in text:
            a, b = text.split("-", 1)
            lo, hi = int(a), int(b)
        else:
            lo = hi = int(text)
    except ValueError as e:
        raise GenOfficeError(EXIT.usage, f"range must look like 1-20: {text}", reason="invalid_argument") from e
    if lo < 1 or hi < lo or lo > count:
        raise GenOfficeError(
            EXIT.usage,
            f"range {text} is outside 1-{count}",
            {"valid_range": [1, count]},
            reason="out_of_range",
        )
    return lo, min(hi, count)


def read(
    ctx: Context,
    file: str,
    *,
    page: int | None = None,
    range: str | None = None,
    password: str | None = None,
    full: bool = False,
    max_chars: int | None = None,
) -> CommandResult:
    path = ctx.input_file(file)
    reader = _open(path, password)
    count = len(reader.pages)
    if page is not None:
        lo, hi = parse_range(str(page), count)
    elif range:
        lo, hi = parse_range(range, count)
    elif full:
        lo, hi = 1, count
    else:
        lo, hi = 1, min(count, DEFAULT_PAGES)
    limit = None if full else (max_chars or PAGE_CHARS)
    pages = []
    for n in builtins.range(lo, hi + 1):
        p = reader.pages[n - 1]
        text, truncated = clip((p.extract_text() or "").strip(), limit)
        entry: dict[str, Any] = {
            "page": n,
            "width_pt": round(float(p.mediabox.width), 2),
            "height_pt": round(float(p.mediabox.height), 2),
            "text": text,
        }
        if truncated:
            entry["truncated"] = True
        pages.append(entry)
    detail: dict[str, Any] = {
        "page_count": count,
        "encrypted": bool(reader.is_encrypted),
        "metadata": _metadata(reader),
        "pages": pages,
    }
    if hi < count and page is None and not range:
        detail["truncated"] = f"pages {hi + 1}-{count} not read; pass range='{hi + 1}-{min(count, hi + DEFAULT_PAGES)}' or full=True"
    return CommandResult(f"read pages {lo}-{hi} of {count} from {path.name}", detail=detail)



def page_texts(path: Path, password: str | None = None) -> list[str]:
    reader = _open(path, password)
    return [(p.extract_text() or "").strip() for p in reader.pages]


def info(path: Path, password: str | None = None) -> dict[str, Any]:
    reader = _open(path, password)
    first = reader.pages[0] if reader.pages else None
    return {
        "format": "pdf",
        "pages": len(reader.pages),
        "encrypted": bool(reader.is_encrypted),
        "page_size_pt": [round(float(first.mediabox.width), 2), round(float(first.mediabox.height), 2)]
        if first
        else None,
        "metadata": _metadata(reader),
        "size_bytes": path.stat().st_size,
    }
