"""Layout-dependent routes: →pdf, render to PNG.

The CLI ran these in a hidden GenOffice process. The port runs LibreOffice headless (a fresh
profile per call, so calls may run concurrently) and rasterises the PDF with pypdfium2. Both are
optional: without them these routes answer `app_unavailable` (exit 4) and everything else works.
"""

from __future__ import annotations

import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Any

from ..context import Context
from ..result import EXIT, GenOfficeError

TIMEOUT_S = 180


def soffice_convert(ctx: Context, src: Path, fmt: str, *, filter: str | None = None) -> Path:
    """Convert src with LibreOffice into a temp dir; returns the produced file (caller moves it)."""
    soffice = ctx.require_soffice(f"converting {src.suffix} to {fmt}")
    work = Path(tempfile.mkdtemp(prefix="genoffice-"))
    profile = work / "profile"
    target = f"{fmt}:{filter}" if filter else fmt
    cmd = [
        soffice,
        f"-env:UserInstallation={profile.as_uri()}",
        "--headless",
        "--norestore",
        "--convert-to",
        target,
        "--outdir",
        str(work),
        str(src),
    ]
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=TIMEOUT_S)
    except subprocess.TimeoutExpired as e:
        raise GenOfficeError(
            EXIT.conversion, f"LibreOffice timed out after {TIMEOUT_S}s", reason="conversion_failed"
        ) from e
    produced = work / f"{src.stem}.{fmt}"
    if proc.returncode != 0 or not produced.exists():
        if proc.returncode and proc.returncode < 0:
            raise GenOfficeError(
                EXIT.conversion,
                f"LibreOffice crashed converting {src.name}",
                {"signal": -proc.returncode, "stderr": proc.stderr[-500:]},
                reason="app_crashed",
                suggestion="retry once; if it repeats, tell the user and name the document",
            )
        raise GenOfficeError(
            EXIT.conversion,
            f"LibreOffice could not convert {src.name} to {fmt}",
            {"stderr": (proc.stderr or proc.stdout)[-500:]},
            reason="conversion_failed",
            suggestion="retry once; check the file opens in an office app",
        )
    return produced


def to_pdf(ctx: Context, src: Path, out: Path) -> Path:
    if src.suffix.lower() == ".pdf":
        shutil.copyfile(src, out)
        return out
    if src.suffix.lower() in (".md", ".markdown"):
        # markdown has no layout of its own: through docx, as the app prints it
        from . import docx as docx_engine

        tmp = Path(tempfile.mkdtemp(prefix="genoffice-")) / f"{src.stem}.docx"
        docx_engine.create_from_markdown(
            Context(root=str(src.parent), soffice=ctx.soffice),
            src.read_text(encoding="utf-8"),
            str(tmp),
            base_dir=src.parent,
        )
        src = tmp
    produced = soffice_convert(ctx, src, "pdf")
    shutil.move(str(produced), out)
    return out


def _pdfium():
    try:
        import pypdfium2 as pdfium  # type: ignore[import-not-found]
    except ImportError as e:
        raise GenOfficeError(
            EXIT.app,
            "rendering needs pypdfium2",
            reason="app_unavailable",
            suggestion="pip install 'genoffice-py[render]' (pypdfium2), or tell the user",
        ) from e
    return pdfium


def render(
    ctx: Context,
    src: Path,
    out_dir: Path,
    *,
    page: int | None = None,
    scale: float = 1.0,
    el: str | None = None,
    pad: int = 16,
    grid: bool = False,
    cols: int = 4,
    tile: int = 320,
    zero_based_slide: bool = False,
) -> dict[str, Any]:
    """One PNG per page (`<stem>-NN.png`, 1-based); el crops a pptx element; grid adds a contact sheet."""
    pdfium = _pdfium()
    out_dir.mkdir(parents=True, exist_ok=True)
    work = Path(tempfile.mkdtemp(prefix="genoffice-"))
    pdf_path = src if src.suffix.lower() == ".pdf" else to_pdf(ctx, src, work / f"{src.stem}.pdf")
    doc = pdfium.PdfDocument(str(pdf_path))
    count = len(doc)
    if page is not None:
        n = page + 1 if zero_based_slide else page
        if n < 1 or n > count:
            lo, hi = (0, count - 1) if zero_based_slide else (1, count)
            raise GenOfficeError(
                EXIT.usage,
                f"page {page} is outside {lo}-{hi}",
                {"valid_range": [lo, hi]},
                reason="out_of_range",
            )
        numbers = [n]
    else:
        numbers = list(range(1, count + 1))
    # 960 px wide for a 16:9 slide at scale 1, as the app renders
    files, sizes = [], []
    for n in numbers:
        p = doc[n - 1]
        w_pt = p.get_width()
        bitmap = p.render(scale=scale * 960 / w_pt if src.suffix.lower() == ".pptx" else scale * 96 / 72)
        img = bitmap.to_pil()
        name = out_dir / f"{src.stem}-{n:02d}.png"
        img.save(name)
        files.append(str(name))
        sizes.append(img.size)
        if el and src.suffix.lower() == ".pptx":
            files.append(str(_crop_element(src, n - 1, el, img, name, pad)))
    detail: dict[str, Any] = {"files": files, "pages": count, "rendered": numbers}
    if grid and files:
        detail["grid"] = _contact_sheet(
            [f for f in files if "-e_" not in f], out_dir / f"{src.stem}-grid.png", cols, tile
        )
    return detail


def _crop_element(src: Path, slide_index: int, el: str, img: Any, name: Path, pad: int) -> Path:
    from pptx import Presentation

    prs = Presentation(str(src))
    slide = prs.slides[slide_index]
    shape = next((s for s in slide.shapes if f"e_{s.shape_id}" == el), None)
    if shape is None:
        raise GenOfficeError(
            EXIT.usage,
            f'no element "{el}" on slide {slide_index}',
            {"available": [f"e_{s.shape_id}" for s in slide.shapes]},
            reason="target_not_found",
        )
    fx = img.size[0] / prs.slide_width
    fy = img.size[1] / prs.slide_height
    box = (
        max(0, int(shape.left * fx) - pad),
        max(0, int(shape.top * fy) - pad),
        min(img.size[0], int((shape.left + shape.width) * fx) + pad),
        min(img.size[1], int((shape.top + shape.height) * fy) + pad),
    )
    out = name.with_name(f"{name.stem}-{el}.png")
    img.crop(box).save(out)
    return out


def _contact_sheet(files: list[str], out: Path, cols: int, tile: int) -> dict[str, Any]:
    from PIL import Image

    images = [Image.open(f) for f in files]
    cols = max(1, min(cols, len(images)))
    th = max(int(tile * im.size[1] / im.size[0]) for im in images)
    rows = (len(images) + cols - 1) // cols
    gap = 8
    sheet = Image.new("RGB", (cols * tile + (cols + 1) * gap, rows * th + (rows + 1) * gap), "#DDDDDD")
    tiles = []
    for i, im in enumerate(images):
        r, c = divmod(i, cols)
        x, y = gap + c * (tile + gap), gap + r * (th + gap)
        thumb = im.copy()
        thumb.thumbnail((tile, th))
        sheet.paste(thumb, (x, y))
        tiles.append({"page": i + 1, "x": x, "y": y, "w": thumb.size[0], "h": thumb.size[1]})
    sheet.save(out)
    return {"path": str(out), "cols": cols, "tiles": tiles}
