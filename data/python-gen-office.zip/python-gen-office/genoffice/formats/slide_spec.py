"""The designed-deck path: outline.json, style.md and one page spec per slide (guides/slides_spec.md).

Pure spec logic lives here — loading, validation, building one page onto a slide, the outline and
page checks — plus the helpers pptx.py shares with it: colors, image loading, text measurement.
Specs are px on a 1280x720 canvas; everything written to the slide is EMU.
"""

from __future__ import annotations

import base64
import io
import json
import re
import urllib.request
from pathlib import Path
from typing import Any

from lxml import etree
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_CONNECTOR, MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, MSO_AUTO_SIZE, PP_ALIGN
from pptx.oxml.ns import qn
from pptx.util import Pt

from ..units import EMU_PER_PX, SLIDE_H_PX, SLIDE_W_PX

MAX_PAGES = 60
MAX_ELEMENTS = 48
MAX_IMAGES = 8

PAGE_TYPES = ("cover", "content", "data", "closing")
LAYOUTS: dict[str, tuple[str, ...]] = {
    "cover": (
        "cover_typography_hero",
        "cover_dark_minimal",
        "cover_split_color",
        "cover_full_image_overlay",
        "cover_magazine",
        "cover_split_image",
    ),
    "content": (
        "left_text_right_image",
        "three_column_cards",
        "hero_big_number",
        "two_column_comparison",
        "timeline_horizontal",
        "full_image_text_overlay",
    ),
    "data": ("kpi_cards_row", "chart_with_insight", "two_by_two_grid"),
    "closing": ("closing_cta", "closing_thank_you"),
}

# spec shape name -> OOXML preset geometry
SHAPES = {
    "rect": "rect",
    "roundRect": "roundRect",
    "ellipse": "ellipse",
    "triangle": "triangle",
    "rightArrow": "rightArrow",
    "leftArrow": "leftArrow",
    "upArrow": "upArrow",
    "downArrow": "downArrow",
    "chevron": "chevron",
    "diamond": "diamond",
    "parallelogram": "parallelogram",
    "trapezoid": "trapezoid",
    "hexagon": "hexagon",
    "pentagon": "pentagon",
    "pie": "pie",
    "donut": "donut",
    "star5": "star5",
    "heart": "heart",
    "cloud": "cloud",
    "line": None,
    "lineArrow": None,
}

PLACEHOLDER = re.compile(r"\bXX+\s*%|\blorem\b|\bipsum\b|\bTBD\b|\bTODO\b|\[placeholder\]", re.I)
HEX = re.compile(r"#([0-9A-Fa-f]{6})([0-9A-Fa-f]{2})?\b")
ALIGN = {"left": PP_ALIGN.LEFT, "center": PP_ALIGN.CENTER, "right": PP_ALIGN.RIGHT, "justify": PP_ALIGN.JUSTIFY}
VALIGN = {"top": MSO_ANCHOR.TOP, "middle": MSO_ANCHOR.MIDDLE, "bottom": MSO_ANCHOR.BOTTOM}


# ---------------------------------------------------------------- colors


def parse_color(value: Any) -> tuple[str, int | None]:
    """"#RRGGBB" or "#RRGGBBAA" -> ("RRGGBB", alpha 0..100000 or None)."""
    if not isinstance(value, str):
        raise ValueError(f"color must be a #RRGGBB string, got {value!r}")
    m = re.fullmatch(r"#?([0-9A-Fa-f]{6})([0-9A-Fa-f]{2})?", value.strip())
    if not m:
        raise ValueError(f'color must be "#RRGGBB" or "#RRGGBBAA", got {value!r}')
    alpha = None if m.group(2) is None else round(int(m.group(2), 16) / 255 * 100000)
    return m.group(1).upper(), alpha


def set_solid(fill: Any, value: str) -> None:
    """Solid fill on a python-pptx FillFormat, with alpha when the color carries one."""
    rgb, alpha = parse_color(value)
    fill.solid()
    fill.fore_color.rgb = RGBColor.from_string(rgb)
    if alpha is not None and alpha < 100000:
        clr = fill._xPr.find(qn("a:solidFill")).find(qn("a:srgbClr"))
        a = etree.SubElement(clr, qn("a:alpha"))
        a.set("val", str(alpha))


# ---------------------------------------------------------------- images


def load_image_bytes(src: str, bases: list[Path]) -> bytes:
    """A local path (tried against each base), a data: URL, an http(s) URL or bare base64."""
    if not isinstance(src, str) or not src:
        raise ValueError("image source must be a non-empty string")
    if src.startswith("data:"):
        _, _, payload = src.partition(",")
        return base64.b64decode(payload)
    if src.startswith(("http://", "https://")):
        req = urllib.request.Request(src, headers={"User-Agent": "genoffice-python/0.1"})
        with urllib.request.urlopen(req, timeout=20) as resp:  # noqa: S310 - the caller chose the URL
            return resp.read()
    p = Path(src).expanduser()
    candidates = [p] if p.is_absolute() else [b / p for b in bases]
    for c in candidates:
        if c.is_file():
            return c.read_bytes()
    if len(src) > 64 and re.fullmatch(r"[A-Za-z0-9+/=\s]+", src):
        return base64.b64decode(src)
    raise ValueError(f"cannot read image {src!r} (not a file, data: URL or http(s) URL)")


def image_size(blob: bytes) -> tuple[int, int]:
    from PIL import Image

    with Image.open(io.BytesIO(blob)) as im:
        return im.size


def cover_crop(img_w: int, img_h: int, box_w: float, box_h: float) -> tuple[dict[str, float], float]:
    """Center crop (object-fit: cover): crop fractions l/t/r/b and the share of the picture kept."""
    img_ar, box_ar = img_w / img_h, box_w / box_h
    if img_ar > box_ar:  # too wide: trim left and right
        keep = box_ar / img_ar
        side = (1 - keep) / 2
        return {"l": side, "t": 0.0, "r": side, "b": 0.0}, keep
    keep = img_ar / box_ar
    side = (1 - keep) / 2
    return {"l": 0.0, "t": side, "r": 0.0, "b": side}, keep


# ---------------------------------------------------------------- text measurement


def _is_wide(ch: str) -> bool:
    o = ord(ch)
    return o >= 0x2E80 and not (0xFF61 <= o <= 0xFFDC)


def char_width(ch: str, size_pt: float) -> float:
    if ch == " ":
        return 0.28 * size_pt
    return size_pt * (1.0 if _is_wide(ch) else 0.55)


def _tokens(text: str) -> list[str]:
    out: list[str] = []
    for word in re.findall(r"\s+|[^\s]+", text):
        if any(_is_wide(c) for c in word):
            out.extend(word)  # CJK breaks anywhere
        else:
            out.append(word)
    return out


def wrap_lines(runs: list[tuple[str, float]], width_pt: float) -> tuple[int, float]:
    """Greedy wrap of one paragraph: (line count, widest unbreakable token in pt)."""
    lines, x, widest = 1, 0.0, 0.0
    for text, size in runs:
        for tok in _tokens(text):
            w = sum(char_width(c, size) for c in tok)
            if tok.strip():
                widest = max(widest, w)
            if x + w > width_pt and x > 0 and tok.strip():
                lines += 1
                x = w
            else:
                x += w
    return lines, widest


def measure(paragraphs: list[dict[str, Any]], width_pt: float) -> tuple[float, float]:
    """Height in pt of measured paragraphs and the widest unbreakable token.

    paragraphs: [{runs: [(text, sizePt)], lineSpacingPct?, spaceBeforePt?, spaceAfterPt?}]
    """
    height, widest = 0.0, 0.0
    for p in paragraphs:
        runs = p["runs"] or [("", p.get("size", 18.0))]
        size = max((s for _, s in runs), default=18.0)
        lines, w = wrap_lines(runs, max(width_pt, 1.0))
        widest = max(widest, w)
        spacing = (p.get("lineSpacingPct") or 100) / 100
        height += lines * size * 1.2 * spacing + (p.get("spaceBeforePt") or 0) + (p.get("spaceAfterPt") or 0)
    return height, widest


# ---------------------------------------------------------------- loading


def read_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        raise ValueError(f"{path.name}: invalid JSON ({e.msg} at line {e.lineno})") from e


def pages_of(spec: Any) -> list[dict[str, Any]]:
    """{pages:[...]}, a bare array of pages, or a single page object."""
    if isinstance(spec, dict) and isinstance(spec.get("pages"), list):
        pages = spec["pages"]
    elif isinstance(spec, list):
        pages = spec
    elif isinstance(spec, dict):
        pages = [spec]
    else:
        raise ValueError("a spec is {pages:[...]}, an array of pages or one page object")
    if not pages:
        raise ValueError("the spec has no pages")
    if len(pages) > MAX_PAGES:
        raise ValueError(f"at most {MAX_PAGES} pages per deck (got {len(pages)})")
    return pages


def page_files(directory: Path) -> list[Path]:
    """Every *.json in name order, numbers compared as numbers (2 before 10)."""
    files = [p for p in directory.iterdir() if p.suffix.lower() == ".json" and p.is_file()]
    return sorted(files, key=lambda p: [int(t) if t.isdigit() else t for t in re.split(r"(\d+)", p.stem)])


def find_beside(start: Path, name: str) -> Path | None:
    """name in the folder of start (or start itself when it is a folder) and one folder up."""
    folder = start if start.is_dir() else start.parent
    for d in (folder, folder.parent):
        if (d / name).is_file():
            return d / name
    return None


def page_number(path: Path) -> int | None:
    m = re.match(r"^(\d+)", path.stem)
    return int(m.group(1)) if m else None


# ---------------------------------------------------------------- building


def _num(v: Any) -> bool:
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def _runs_text(paragraphs: Any) -> str:
    if not isinstance(paragraphs, list):
        return ""
    return "\n".join(
        "".join(str(r.get("text", "")) for r in p.get("runs", []) if isinstance(r, dict))
        for p in paragraphs
        if isinstance(p, dict)
    )


def write_paragraphs(tf: Any, paragraphs: list[dict[str, Any]]) -> None:
    """Spec paragraphs into a text frame (run fields text/sizePt/bold/italic/color/font)."""
    tf.clear()
    for i, para in enumerate(paragraphs):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        if para.get("align") in ALIGN:
            p.alignment = ALIGN[para["align"]]
        if _num(para.get("lineSpacingPct")):
            p.line_spacing = float(para["lineSpacingPct"]) / 100
        if _num(para.get("spaceBeforePt")):
            p.space_before = Pt(para["spaceBeforePt"])
        if _num(para.get("spaceAfterPt")):
            p.space_after = Pt(para["spaceAfterPt"])
        if "bullet" in para:
            set_bullet(p, bool(para["bullet"]))
        for r in para.get("runs", []):
            run = p.add_run()
            run.text = str(r.get("text", ""))
            f = run.font
            if _num(r.get("sizePt")):
                f.size = Pt(max(6, min(160, r["sizePt"])))
            if "bold" in r:
                f.bold = bool(r["bold"])
            if "italic" in r:
                f.italic = bool(r["italic"])
            if r.get("font"):
                f.name = str(r["font"])
            if r.get("color"):
                set_solid(f.fill, r["color"])


def set_bullet(p: Any, on: bool) -> None:
    pPr = p._p.get_or_add_pPr()
    for tag in ("a:buNone", "a:buChar", "a:buAutoNum", "a:buFont"):
        for el in pPr.findall(qn(tag)):
            pPr.remove(el)
    if on:
        pPr.set("marL", "285750")
        pPr.set("indent", "-285750")
        bu = etree.SubElement(pPr, qn("a:buChar"))
        bu.set("char", "•")
    else:
        etree.SubElement(pPr, qn("a:buNone"))


def _paragraph_metrics(paragraphs: list[dict[str, Any]]) -> list[dict[str, Any]]:
    out = []
    for para in paragraphs:
        runs = [
            (str(r.get("text", "")), float(r["sizePt"]) if _num(r.get("sizePt")) else 18.0)
            for r in para.get("runs", [])
            if isinstance(r, dict)
        ]
        out.append(
            {
                "runs": runs,
                "lineSpacingPct": para.get("lineSpacingPct"),
                "spaceBeforePt": para.get("spaceBeforePt"),
                "spaceAfterPt": para.get("spaceAfterPt"),
            }
        )
    return out


def build_page(slide: Any, page: dict[str, Any], bases: list[Path], label: str) -> tuple[list[dict], list[dict], int]:
    """Paint one page spec onto an empty slide: (issues, imageFailures, elements kept)."""
    issues: list[dict[str, Any]] = []
    failures: list[dict[str, Any]] = []

    def issue(level: str, code: str, message: str, element: int | None = None) -> None:
        item: dict[str, Any] = {"page": label, "level": level, "code": code, "message": message}
        if element is not None:
            item["element"] = element
        issues.append(item)

    if page.get("background"):
        try:
            set_solid(slide.background.fill, page["background"])
        except ValueError as e:
            issue("warning", "bad_background", str(e))

    elements = page.get("elements")
    if not isinstance(elements, list):
        issue("error", "no_elements", "page has no elements array")
        return issues, failures, 0
    if len(elements) > MAX_ELEMENTS:
        issue("warning", "too_many_elements", f"only the first {MAX_ELEMENTS} of {len(elements)} elements are kept")
        elements = elements[:MAX_ELEMENTS]

    kept, images, texts = 0, 0, []
    for i, el in enumerate(elements):
        if not isinstance(el, dict):
            issue("warning", "dropped", "element is not an object", i)
            continue
        kind = el.get("type")
        if kind not in ("shape", "text", "image"):
            issue("warning", "dropped", f"unknown element type {kind!r}", i)
            continue
        if not all(_num(el.get(k)) for k in ("x", "y", "w", "h")):
            issue("warning", "dropped", "missing numeric x/y/w/h", i)
            continue
        x, y, w, h = (int(round(el[k])) for k in ("x", "y", "w", "h"))
        if x >= SLIDE_W_PX or y >= SLIDE_H_PX or x + w <= 0 or y + h <= 0 or w < 0 or h < 0:
            issue("warning", "dropped", "element lies fully outside the 1280x720 canvas", i)
            continue
        cx0, cy0 = max(0, x), max(0, y)
        cx1, cy1 = min(SLIDE_W_PX, x + w), min(SLIDE_H_PX, y + h)
        if (cx0, cy0, cx1, cy1) != (x, y, x + w, y + h):
            issue("warning", "clamped", "box stuck out of the canvas and was clamped", i)
        x, y, w, h = cx0, cy0, cx1 - cx0, cy1 - cy0
        try:
            if kind == "text":
                text = _runs_text(el.get("paragraphs"))
                if not text.strip():
                    issue("warning", "dropped", "text element without text", i)
                    continue
                h = _grow_to_fit(el, x, y, w, h, issue, i)
                box = slide.shapes.add_textbox(*(v * EMU_PER_PX for v in (x, y, w, h)))
                tf = box.text_frame
                tf.word_wrap = True
                tf.auto_size = MSO_AUTO_SIZE.NONE
                tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0
                tf.vertical_anchor = VALIGN.get(el.get("valign", "top"), MSO_ANCHOR.TOP)
                write_paragraphs(tf, el["paragraphs"])
                texts.append((i, re.sub(r"\s+", " ", text.strip().lower())))
            elif kind == "shape":
                _add_shape(slide, el, x, y, w, h)
                text = _runs_text(el.get("paragraphs"))
                if text.strip():
                    texts.append((i, re.sub(r"\s+", " ", text.strip().lower())))
            else:
                if images >= MAX_IMAGES:
                    issue("warning", "dropped", f"more than {MAX_IMAGES} images on the page", i)
                    continue
                try:
                    blob = load_image_bytes(str(el.get("url", "")), bases)
                    iw, ih = image_size(blob)
                except Exception as e:  # noqa: BLE001 - any unreadable picture is reported, not fatal
                    failures.append({"page": label, "element": i, "url": el.get("url"), "error": str(e)})
                    continue
                pic = slide.shapes.add_picture(io.BytesIO(blob), *(v * EMU_PER_PX for v in (x, y, w, h)))
                crop, keep = cover_crop(iw, ih, max(w, 1), max(h, 1))
                pic.crop_left, pic.crop_top, pic.crop_right, pic.crop_bottom = crop["l"], crop["t"], crop["r"], crop["b"]
                if keep < 0.5:
                    issue("warning", "image_cropped", f"the box keeps only {round(keep * 100)}% of the picture; give it the picture's aspect", i)
                images += 1
        except ValueError as e:
            issue("warning", "dropped", str(e), i)
            continue
        kept += 1

    for a in range(len(texts)):
        for b in range(a + 1, len(texts)):
            ta, tb = texts[a][1], texts[b][1]
            if ta and (ta == tb or (len(ta) > 12 and (ta in tb or tb in ta))):
                issue("warning", "duplicate_text", f"elements {texts[a][0]} and {texts[b][0]} say the same thing", texts[b][0])
    if kept == 0:
        issue("error", "empty_page", "no element survived validation")
    return issues, failures, kept


def _grow_to_fit(el: dict[str, Any], x: int, y: int, w: int, h: int, issue: Any, i: int) -> int:
    """The builder measures every plain text box and grows it downwards (never shrinks)."""
    height_pt, _ = measure(_paragraph_metrics(el["paragraphs"]), w * 0.75)
    need = int(height_pt / 0.75 + 0.999)
    if need <= h:
        return h
    grown = min(need, SLIDE_H_PX - y)
    issue("warning", "text_grown", f"text box grown from {h}px to {grown}px to fit its text", i)
    return grown


def _add_shape(slide: Any, el: dict[str, Any], x: int, y: int, w: int, h: int) -> None:
    name = el.get("shape", "rect")
    if name not in SHAPES:
        raise ValueError(f"unknown shape {name!r} (one of {', '.join(SHAPES)})")
    fill, stroke = el.get("fill"), el.get("stroke")
    if not fill and not stroke:
        raise ValueError("shape without fill or stroke")
    emu = [v * EMU_PER_PX for v in (x, y, w, h)]
    if SHAPES[name] is None:  # line / lineArrow: the diagonal of the box
        if not stroke:
            raise ValueError(f"{name} needs a stroke")
        x0, y0, x1, y1 = emu[0], emu[1], emu[0] + emu[2], emu[1] + emu[3]
        if el.get("flipV"):
            y0, y1 = y1, y0
        if el.get("flipH"):
            x0, x1 = x1, x0
        line = slide.shapes.add_connector(MSO_CONNECTOR.STRAIGHT, x0, y0, x1, y1)
        _stroke(line.line, stroke)
        if name == "lineArrow":
            ln = line.line._get_or_add_ln()
            tail = etree.SubElement(ln, qn("a:tailEnd"))
            tail.set("type", "triangle")
        return
    shape = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, *emu)
    shape._element.spPr.find(qn("a:prstGeom")).set("prst", SHAPES[name])
    if el.get("flipH"):
        shape._element.spPr.find(qn("a:xfrm")).set("flipH", "1")
    if el.get("flipV"):
        shape._element.spPr.find(qn("a:xfrm")).set("flipV", "1")
    if fill:
        set_solid(shape.fill, fill)
    else:
        shape.fill.background()
    if stroke:
        _stroke(shape.line, stroke)
    else:
        shape.line.fill.background()
    # drop the theme's shadow / style text color so the spec controls the look
    style = shape._element.find(qn("p:style"))
    if style is not None:
        shape._element.remove(style)
    tf = shape.text_frame
    tf.word_wrap = True
    tf.vertical_anchor = VALIGN.get(el.get("valign", "middle"), MSO_ANCHOR.MIDDLE)
    if el.get("paragraphs"):
        write_paragraphs(tf, el["paragraphs"])


def _stroke(line: Any, stroke: Any) -> None:
    if not isinstance(stroke, dict) or not stroke.get("color"):
        raise ValueError("stroke is {color, widthPt}")
    set_solid(line.fill, stroke["color"])
    line.width = Pt(float(stroke.get("widthPt", 1)))


# ---------------------------------------------------------------- checks


def check_outline(outline: Any) -> tuple[list[dict], list[dict]]:
    errors: list[dict[str, Any]] = []
    warnings: list[dict[str, Any]] = []

    def err(code: str, message: str, page: int | None = None) -> None:
        errors.append({"code": code, "message": message, **({"page": page} if page is not None else {})})

    def warn(code: str, message: str, page: int | None = None) -> None:
        warnings.append({"code": code, "message": message, **({"page": page} if page is not None else {})})

    if not isinstance(outline, dict) or not isinstance(outline.get("pages"), list):
        err("invalid_outline", 'outline is {"core_hook", "pages": [...]}')
        return errors, warnings
    if not str(outline.get("core_hook", "")).strip():
        err("missing_core_hook", "core_hook is missing: one sentence with tension, a number or a contrast")
    pages = outline["pages"]
    if not pages:
        err("no_pages", "outline has no pages")
    body_layouts: set[str] = set()
    prev: tuple[str, str] | None = None
    for n, p in enumerate(pages, start=1):
        if not isinstance(p, dict):
            err("invalid_page", "page entry is not an object", n)
            prev = None
            continue
        ptype, layout = p.get("type"), p.get("layout")
        if ptype not in PAGE_TYPES:
            err("unknown_type", f"type {ptype!r} is not one of {', '.join(PAGE_TYPES)}", n)
        elif layout not in LAYOUTS[ptype]:
            err("unknown_layout", f"layout {layout!r} is not a {ptype} layout ({', '.join(LAYOUTS[ptype])})", n)
        for key in ("title", "brief"):
            if not str(p.get(key, "")).strip():
                err(f"missing_{key}", f"{key} is missing", n)
        if not isinstance(p.get("image_queries"), list):
            err("missing_image_queries", "image_queries is missing ([] for a page without photos)", n)
        else:
            for q in p["image_queries"]:
                if isinstance(q, str) and not q.startswith("http") and any(ord(c) > 127 for c in q):
                    warn("non_english_query", f"image query {q!r} is not English", n)
        text = f"{p.get('title', '')} {p.get('brief', '')}"
        if PLACEHOLDER.search(text):
            err("placeholder_copy", f"placeholder copy in the entry: {PLACEHOLDER.search(text).group(0)!r}", n)
        brief = str(p.get("brief", "")).strip()
        if brief and len(brief) < 40:
            warn("thin_brief", "brief is thin: name what goes in each region with the real figures", n)
        if ptype in ("content", "data"):
            body_layouts.add(str(layout))
            if prev == (ptype, layout):
                err("repeated_layout", f"layout {layout!r} repeats the previous page", n)
            prev = (ptype, str(layout))
        else:
            prev = None
    if pages:
        if len(body_layouts) < 3 and sum(1 for p in pages if isinstance(p, dict) and p.get("type") in ("content", "data")) >= 3:
            warn("few_layouts", "fewer than three layout variants across the body pages")
        if isinstance(pages[0], dict) and pages[0].get("type") != "cover":
            warn("first_not_cover", "the first page is not a cover")
        if isinstance(pages[-1], dict) and pages[-1].get("type") != "closing" and len(pages) > 1:
            warn("last_not_closing", "the last page is not a closing page")
    return errors, warnings


def palette(style_text: str) -> set[str]:
    return {m.group(1).upper() for m in HEX.finditer(style_text)} | {"FFFFFF", "000000"}


def page_colors(page: dict[str, Any]) -> set[str]:
    """Every #RRGGBB the page uses (alpha ignored)."""
    found: set[str] = set()

    def walk(v: Any, key: str = "") -> None:
        if isinstance(v, dict):
            for k, x in v.items():
                walk(x, k)
        elif isinstance(v, list):
            for x in v:
                walk(x, key)
        elif isinstance(v, str) and key in ("fill", "color", "background"):
            m = re.fullmatch(r"#([0-9A-Fa-f]{6})([0-9A-Fa-f]{2})?", v.strip())
            if m:
                found.add(m.group(1).upper())

    walk(page)
    return found


def page_text(page: dict[str, Any]) -> str:
    return "\n".join(_runs_text(el.get("paragraphs")) for el in page.get("elements", []) if isinstance(el, dict))


def check_page(page: dict[str, Any], entry: dict[str, Any] | None, style: set[str] | None) -> dict[str, Any]:
    """Findings of a page against its outline entry and the style palette."""
    findings: list[dict[str, Any]] = []
    if entry is not None:
        for key in ("title", "type", "layout"):
            if key in page and entry.get(key) is not None and page[key] != entry[key]:
                findings.append(
                    {"level": "error", "code": "disagrees_with_outline", "field": key,
                     "message": f"{key} {page[key]!r} disagrees with the outline entry ({entry[key]!r})"}
                )
        title = str(entry.get("title", "")).strip().lower()
        text = page_text(page).lower()
        if title and title not in re.sub(r"\s+", " ", text):
            findings.append({"level": "warning", "code": "title_missing", "message": "the entry's title is not in the page text"})
        if entry.get("image_queries") and not any(
            isinstance(el, dict) and el.get("type") == "image" for el in page.get("elements", [])
        ):
            findings.append({"level": "warning", "code": "photo_missing", "message": "the entry plans photos but the page has no image"})
    m = PLACEHOLDER.search(page_text(page))
    if m:
        findings.append({"level": "error", "code": "placeholder_copy", "message": f"placeholder copy {m.group(0)!r}"})
    off = sorted(f"#{c}" for c in page_colors(page) - style) if style is not None else []
    return {"findings": findings, "offPalette": off}
