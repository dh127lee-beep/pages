"""Excel (`sheet`) engine: read, the workbook DSL, check, create, csv, merge — on openpyxl.

The op names and fields are the GenOffice workbook DSL as `genoffice sheet apply --ops` takes it:
worksheets are addressed by name (`sheet`, omitted = the active sheet), cells by A1 address, rows
1-based, columns by letter. Ops run in order and each sees the previous result.

What the port cannot do: openpyxl has no formula engine, so formulas written here carry no cached
value (warning `formulas_not_cached`; Excel computes them on open) and ops that need one
(`convert_to_values`, `add_pivot`) are listed as unavailable.
"""

from __future__ import annotations

import copy
import csv
import io
import json
import re
import urllib.request
from datetime import date, datetime, time
from pathlib import Path
from typing import Any

import openpyxl
from openpyxl.cell.cell import Cell
from openpyxl.comments import Comment
from openpyxl.formatting.rule import CellIsRule, ColorScaleRule, DataBarRule, FormulaRule
from openpyxl.formula.tokenizer import Token, Tokenizer
from openpyxl.formula.translate import Translator
from openpyxl.styles import Alignment, Border, Font, GradientFill, PatternFill, Side
from openpyxl.styles.colors import Color
from openpyxl.styles.fills import Stop
from openpyxl.utils import column_index_from_string, get_column_letter
from openpyxl.utils.cell import range_boundaries
from openpyxl.utils.datetime import to_excel
from openpyxl.workbook.defined_name import DefinedName
from openpyxl.workbook.workbook import Workbook
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.worksheet.table import Table, TableStyleInfo
from openpyxl.worksheet.worksheet import Worksheet

from ..context import Context
from ..ops import BatchMode, OpError, OpRegistry, batch_result
from ..result import EXIT, CommandResult, GenOfficeError, Warning
from ..suggest import did_you_mean

HEADER = [
    'Excel ops (sheet_apply ops=[...]): a JSON array; every entry has "op". Address a worksheet with',
    '"sheet": "<name>" (omitted = the active sheet; sheet_read lists names). Ranges are A1:D9,',
    'rows are 1-based, columns are letters. Strings starting with "=" are formulas.',
    "Field notation: bare = string, n = number, bool = boolean, ? = optional, a|b = one of.",
]

FOOTER = [
    "Ops run in order: after insert/delete rows or columns, the ops that follow address the shifted grid, and a",
    "sheet added or renamed earlier in the batch is addressed by its new name; existing formulas and merges are",
    "shifted with the grid. Rules, links, notes, filters and visuals must come after any row/column op of their sheet.",
    "This port has no formula engine: formulas are stored without a cached value and Excel computes them on open",
    "(warning formulas_not_cached).",
]

REGISTRY = OpRegistry("sheets", HEADER, FOOTER)
for _name, _summary in (
    ("content", "cell values, formulas, fills, find/replace, sorting"),
    ("format", "cell formats, conditional formats, data validation"),
    ("layout", "merges, sizes, hidden rows/columns, panes, filters, page setup, protection"),
    ("data", "hyperlinks, notes, defined names, Excel tables, pivot tables"),
    ("visuals", "charts, images, shapes, sparklines"),
    ("structure", "rows, columns and sheets; later ops in the batch use the shifted addresses"),
    ("editor-only", "accepted by the app, refused headless"),
):
    REGISTRY.group(_name, _summary)

# `cells` mode: one pseudo-op per entry, so failures point at the entry the caller wrote
CELLS = OpRegistry("sheets", [])
CELLS.group("cells", "")

_ADDR = re.compile(r"^\$?([A-Za-z]{1,3})\$?(\d+)$")
_RANGE = re.compile(r"^\$?[A-Za-z]{1,3}\$?\d+(?::\$?[A-Za-z]{1,3}\$?\d+)?$")
_COL = re.compile(r"^[A-Za-z]{1,3}$")
_ERRORS = ("#REF!", "#DIV/0!", "#NAME?", "#VALUE!", "#N/A", "#NUM!", "#NULL!")
_THEME_SLOTS = {
    "lt1": 0, "bg1": 0, "dk1": 1, "tx1": 1, "lt2": 2, "bg2": 2, "dk2": 3, "tx2": 3,
    "accent1": 4, "accent2": 5, "accent3": 6, "accent4": 7, "accent5": 8, "accent6": 9,
    "hlink": 10, "folHlink": 11,
}
_THEME_RE = re.compile(r"^(lt1|lt2|dk1|dk2|bg1|bg2|tx1|tx2|accent[1-6]|hlink|folHlink)(?:([+-])(\d{1,3})%)?$")
_PLACEHOLDER = re.compile(r"\{\{\s*([^{}]+?)\s*\}\}")
_MARGINS = {
    "normal": (0.7, 0.7, 0.75, 0.75, 0.3, 0.3),
    "wide": (1.0, 1.0, 1.0, 1.0, 0.5, 0.5),
    "narrow": (0.25, 0.25, 0.75, 0.75, 0.3, 0.3),
}
MAX_READ_ROWS = 500
MAX_READ_COLS = 100
_irange = range  # read() takes a `range` argument, as the CLI flag is named


class Book:
    """The open workbook an op batch runs against."""

    def __init__(self, wb: Workbook, ctx: Context, *, default_sheet: str | None = None, base: Path | None = None) -> None:
        self.wb = wb
        self.ctx = ctx
        self.default_sheet = default_sheet
        self.base = base
        self.formula_cells: list[str] = []

    def ws(self, op: dict[str, Any], key: str = "sheet") -> Worksheet:
        name = op.get(key) or (self.default_sheet if key == "sheet" else None) or op.get("sheet") or self.default_sheet
        if not name:
            return self.wb.active
        if name not in self.wb.sheetnames:
            raise OpError(
                f'no sheet "{name}". Available: [{", ".join(self.wb.sheetnames)}]',
                reason="sheet_not_found",
                available=list(self.wb.sheetnames),
                wanted=name,
            )
        return self.wb[name]


# ---- addressing ----


def _addr(value: Any, field: str = "address") -> tuple[int, int]:
    if not isinstance(value, str) or not _ADDR.match(value.strip()):
        raise OpError(f'{field} must be an A1 address like "B2", got {value!r}')
    m = _ADDR.match(value.strip())
    return int(m.group(2)), column_index_from_string(m.group(1).upper())  # type: ignore[union-attr]


def _range(value: Any, field: str = "range") -> tuple[int, int, int, int]:
    """(min_row, min_col, max_row, max_col) of "A1:D9" or "A1"."""
    if not isinstance(value, str) or not _RANGE.match(value.strip()):
        raise OpError(f'{field} must be an A1 range like "A1:D9", got {value!r}')
    c1, r1, c2, r2 = range_boundaries(value.strip().upper())
    return r1, c1, r2, c2


def _col(value: Any, field: str = "column") -> int:
    if not isinstance(value, str) or not _COL.match(value):
        raise OpError(f'{field} must be a column letter like "C", got {value!r}')
    return column_index_from_string(value.upper())


def _ref(r1: int, c1: int, r2: int | None = None, c2: int | None = None) -> str:
    a = f"{get_column_letter(c1)}{r1}"
    if r2 is None or (r2 == r1 and c2 == c1):
        return a
    return f"{a}:{get_column_letter(c2)}{r2}"  # type: ignore[arg-type]


def _count(op: dict[str, Any], hi: int) -> int:
    n = op.get("count", 1)
    if not isinstance(n, int) or n < 1 or n > hi:
        raise OpError(f"count must be an integer 1-{hi}")
    return n


# ---- colors ----


def _color(value: Any) -> Color:
    """#RRGGBB, a theme slot ("accent1", "accent1+40%", "dk2-25%") or {theme, tint}."""
    if isinstance(value, dict) and "theme" in value:
        slot = value["theme"]
        idx = _THEME_SLOTS.get(slot, slot) if isinstance(slot, str) else slot
        if not isinstance(idx, int):
            raise OpError(f"unknown theme slot {slot!r}")
        return Color(theme=idx, tint=float(value.get("tint", 0)))
    if isinstance(value, str):
        v = value.strip()
        if re.fullmatch(r"#?[0-9A-Fa-f]{6}", v):
            return Color(rgb="FF" + v.lstrip("#").upper())
        m = _THEME_RE.match(v)
        if m:
            tint = 0.0
            if m.group(2):
                tint = int(m.group(3)) / 100 * (1 if m.group(2) == "+" else -1)
            return Color(theme=_THEME_SLOTS[m.group(1)], tint=tint)
    raise OpError(f'color must be "#RRGGBB", a theme slot like "accent1+40%" or {{theme, tint}}, got {value!r}')


def _color_out(c: Any) -> Any:
    if c is None:
        return None
    if getattr(c, "type", None) == "theme":
        slot = next((k for k, v in _THEME_SLOTS.items() if v == c.theme and k[:2] in ("lt", "dk", "ac", "hl", "fo")), c.theme)
        return {"theme": slot, "tint": round(c.tint or 0, 3)}
    rgb = getattr(c, "rgb", None)
    if isinstance(rgb, str) and len(rgb) == 8:
        return "#" + rgb[2:]
    return None


# ---- formula shifting for row/column ops ----


def _shift_ref(ref: str, own_sheet: str, target: str, axis: str, at: int, count: int, delete: bool) -> str:
    sheet_part = ""
    body = ref
    if "!" in ref:
        sheet_part, body = ref.rsplit("!", 1)
        sheet_name = sheet_part.strip("'").replace("''", "'")
        sheet_part += "!"
    else:
        sheet_name = own_sheet
    if sheet_name != target:
        return ref
    pieces = body.split(":")
    out = []
    for piece in pieces:
        m = re.fullmatch(r"(\$?)([A-Za-z]{1,3})?(\$?)(\d+)?", piece)
        if not m or (m.group(2) is None and m.group(4) is None):
            return ref
        dc, col, dr, row = m.groups()
        if axis == "row" and row is not None:
            r = int(row)
            if delete:
                if at <= r < at + count:
                    if len(pieces) == 1:
                        return sheet_part + "#REF!"
                    r = at if piece is pieces[0] else at - 1
                elif r >= at + count:
                    r -= count
            elif r >= at:
                r += count
            row = str(max(r, 1))
        if axis == "col" and col is not None:
            c = column_index_from_string(col.upper())
            if delete:
                if at <= c < at + count:
                    if len(pieces) == 1:
                        return sheet_part + "#REF!"
                    c = at if piece is pieces[0] else at - 1
                elif c >= at + count:
                    c -= count
            elif c >= at:
                c += count
            col = get_column_letter(max(c, 1))
        out.append(f"{dc}{col or ''}{dr}{row or ''}")
    return sheet_part + ":".join(out)


def _shift_formula(formula: str, own_sheet: str, target: str, axis: str, at: int, count: int, delete: bool) -> str:
    try:
        tok = Tokenizer(formula)
    except Exception:
        return formula
    for t in tok.items:
        if t.type == Token.OPERAND and t.subtype == Token.RANGE:
            t.value = _shift_ref(t.value, own_sheet, target, axis, at, count, delete)
    return "=" + "".join(t.value for t in tok.items)


def _shift_workbook(book: Book, ws: Worksheet, axis: str, at: int, count: int, delete: bool) -> None:
    for sheet in book.wb.worksheets:
        for row in sheet.iter_rows():
            for cell in row:
                if isinstance(cell.value, str) and cell.value.startswith("="):
                    cell.value = _shift_formula(cell.value, sheet.title, ws.title, axis, at, count, delete)
    for mr in list(ws.merged_cells.ranges):
        lo, hi = (mr.min_row, mr.max_row) if axis == "row" else (mr.min_col, mr.max_col)
        if delete and lo >= at and hi < at + count:
            ws.merged_cells.remove(mr)
        elif lo >= at:
            n = -count if delete else count
            mr.shift(row_shift=n) if axis == "row" else mr.shift(col_shift=n)


# ---- content ops ----


def _write(book: Book, ws: Worksheet, r: int, c: int, value: Any, *, as_text: bool = False) -> None:
    cell = ws.cell(row=r, column=c)
    if isinstance(value, str) and value.startswith("=") and not as_text:
        cell.value = value
        book.formula_cells.append(f"{ws.title}!{cell.coordinate}")
        return
    if value is not None and not isinstance(value, (str, int, float, bool)):
        raise OpError(f"cell values are strings, numbers, booleans or null, got {type(value).__name__}")
    cell.value = value
    if as_text and isinstance(value, str):
        cell.data_type = "s"
        cell.number_format = "@"


@REGISTRY.op(
    "set_cell", "content", "{sheet?, address, value: string|n|bool|null, type?: text}", required=("address",),
    note='a string value starting with "=" is written as a formula; type: "text" keeps such a string as literal cell text',
)
def _set_cell(book: Book, op: dict[str, Any]) -> None:
    ws = book.ws(op)
    r, c = _addr(op["address"])
    if "value" not in op:
        raise OpError("set_cell: missing value")
    _write(book, ws, r, c, op["value"], as_text=op.get("type") == "text")


@REGISTRY.op("set_formula", "content", '{sheet?, address, formula: "=..."}', required=("address", "formula"))
def _set_formula(book: Book, op: dict[str, Any]) -> None:
    ws = book.ws(op)
    r, c = _addr(op["address"])
    f = op["formula"]
    if not isinstance(f, str) or not f.startswith("="):
        raise OpError('formula must start with "="')
    _write(book, ws, r, c, f)


@REGISTRY.op("set_range", "content", "{sheet?, start?, range?, values: [[string|n|bool|null]]}", required=("values",),
             note="start is the top-left cell; range, when given instead, must match the values grid")
def _set_range(book: Book, op: dict[str, Any]) -> None:
    ws = book.ws(op)
    values = op["values"]
    if not isinstance(values, list) or not values or not all(isinstance(r, list) for r in values):
        raise OpError("values must be a non-empty 2-D array")
    if op.get("range"):
        r1, c1, r2, c2 = _range(op["range"])
        if r2 - r1 + 1 != len(values) or any(len(row) != c2 - c1 + 1 for row in values):
            raise OpError(f"range {op['range']} is {r2 - r1 + 1}x{c2 - c1 + 1} but values are {len(values)}x{max(len(r) for r in values)}")
    else:
        r1, c1 = _addr(op.get("start", "A1"), "start")
    for i, row in enumerate(values):
        for j, v in enumerate(row):
            _write(book, ws, r1 + i, c1 + j, v)


@REGISTRY.op("clear_cell", "content", "{sheet?, address}", required=("address",))
def _clear_cell(book: Book, op: dict[str, Any]) -> None:
    ws = book.ws(op)
    r, c = _addr(op["address"])
    ws.cell(row=r, column=c).value = None


@REGISTRY.op("clear_range", "content", "{sheet?, range}", required=("range",))
def _clear_range(book: Book, op: dict[str, Any]) -> None:
    ws = book.ws(op)
    r1, c1, r2, c2 = _range(op["range"])
    for row in ws.iter_rows(min_row=r1, max_row=r2, min_col=c1, max_col=c2):
        for cell in row:
            if not isinstance(cell, Cell):
                continue
            cell.value = None


def _block(ws: Worksheet, r1: int, c1: int, r2: int, c2: int) -> list[list[Cell]]:
    return [[ws.cell(row=r, column=c) for c in range(c1, c2 + 1)] for r in range(r1, r2 + 1)]


def _paste(book: Book, src: list[list[tuple[Any, str, Any]]], ws: Worksheet, r0: int, c0: int) -> None:
    """src: rows of (value, origin coordinate, style); formulas shift by the paste offset."""
    for i, row in enumerate(src):
        for j, (value, origin, style) in enumerate(row):
            cell = ws.cell(row=r0 + i, column=c0 + j)
            if isinstance(value, str) and value.startswith("="):
                value = Translator(value, origin=origin).translate_formula(cell.coordinate)
                book.formula_cells.append(f"{ws.title}!{cell.coordinate}")
            cell.value = value
            if style is not None:
                cell._style = copy.copy(style)


def _snapshot(ws: Worksheet, r1: int, c1: int, r2: int, c2: int) -> list[list[tuple[Any, str, Any]]]:
    return [[(c.value, c.coordinate, copy.copy(c._style)) for c in row] for row in _block(ws, r1, c1, r2, c2)]


@REGISTRY.op("fill_range", "content", "{sheet?, source, sourceSheet?, target}", required=("source", "target"),
             note="tiles the source block's values and formulas across target; relative references shift, $-anchored ones stay")
def _fill_range(book: Book, op: dict[str, Any]) -> None:
    ws = book.ws(op)
    src_ws = book.ws(op, "sourceSheet")
    sr1, sc1, sr2, sc2 = _range(op["source"], "source")
    tr1, tc1, tr2, tc2 = _range(op["target"], "target")
    h, w = sr2 - sr1 + 1, sc2 - sc1 + 1
    th, tw = tr2 - tr1 + 1, tc2 - tc1 + 1
    if th % h or tw % w:
        raise OpError(f"target {op['target']} must be a whole multiple of the source's {h}x{w}")
    src = _snapshot(src_ws, sr1, sc1, sr2, sc2)
    for i in range(0, th, h):
        for j in range(0, tw, w):
            _paste(book, src, ws, tr1 + i, tc1 + j)


def _copy_source(book: Book, op: dict[str, Any]) -> tuple[Worksheet, tuple[int, int, int, int], list]:
    src_ws = book.ws(op, "sourceSheet")
    box = _range(op["source"], "source")
    src = _snapshot(src_ws, *box)
    col, values = op.get("filterColumn"), op.get("filterValues")
    if col and values:
        k = _col(col, "filterColumn") - box[1]
        if not 0 <= k < len(src[0]):
            raise OpError("filterColumn must lie inside the source range")
        wanted = {str(v) for v in values}
        src = [row for row in src if row[k][0] is not None and str(row[k][0]) in wanted]
    return src_ws, box, src


def _target_origin(op: dict[str, Any], h: int, w: int) -> tuple[int, int]:
    tr1, tc1, tr2, tc2 = _range(op["target"], "target")
    if (tr1, tc1) != (tr2, tc2) and (tr2 - tr1 + 1, tc2 - tc1 + 1) != (h, w):
        raise OpError("target must be the top-left cell or a range exactly the source's size")
    return tr1, tc1


@REGISTRY.op("copy_range", "content", "{sheet?, source, sourceSheet?, target, filterColumn?, filterValues?: [string]}",
             required=("source", "target"))
def _copy_range(book: Book, op: dict[str, Any]) -> None:
    ws = book.ws(op)
    _, box, src = _copy_source(book, op)
    if not src:
        return
    r0, c0 = _target_origin(op, box[2] - box[0] + 1, box[3] - box[1] + 1)
    _paste(book, src, ws, r0, c0)


@REGISTRY.op("move_range", "content", "{sheet?, source, sourceSheet?, target}", required=("source", "target"),
             note="cut → paste as one op: copies source (values and formulas) to target, then clears the source cells; sourceSheet for another sheet; source and target must not overlap")
def _move_range(book: Book, op: dict[str, Any]) -> None:
    ws = book.ws(op)
    src_ws, (r1, c1, r2, c2), src = _copy_source(book, op)
    r0, c0 = _target_origin(op, r2 - r1 + 1, c2 - c1 + 1)
    if src_ws is ws and not (r0 > r2 or r0 + r2 - r1 < r1 or c0 > c2 or c0 + c2 - c1 < c1):
        raise OpError("source and target must not overlap")
    _paste(book, src, ws, r0, c0)
    for row in _block(src_ws, r1, c1, r2, c2):
        for cell in row:
            cell.value = None


@REGISTRY.op("find_replace", "content", "{sheet?, find, replace, matchCase?: bool, wholeCell?: bool}", required=("find", "replace"))
def _find_replace(book: Book, op: dict[str, Any]) -> dict[str, Any]:
    ws = book.ws(op)
    find, repl = str(op["find"]), str(op["replace"])
    flags = 0 if op.get("matchCase") else re.I
    pattern = re.compile(("^" + re.escape(find) + "$") if op.get("wholeCell") else re.escape(find), flags)
    n = 0
    for row in ws.iter_rows():
        for cell in row:
            v = cell.value
            if isinstance(v, str) and not v.startswith("=") and pattern.search(v):
                cell.value = pattern.sub(lambda _: repl, v)
                n += 1
    return {"replaced": n}


def _sort_key(v: Any) -> tuple[int, Any]:
    if v is None:
        return (2, 0)
    if isinstance(v, bool):
        return (1, str(v))
    if isinstance(v, (int, float)):
        return (0, v)
    if isinstance(v, (datetime, date)):
        return (0, to_excel(v))
    return (1, str(v).lower())


@REGISTRY.op("sort_range", "content", "{sheet?, range, byColumn, order: asc|desc, hasHeader?: bool}",
             required=("range", "byColumn", "order"), note="hasHeader keeps the first row in place")
def _sort_range(book: Book, op: dict[str, Any]) -> None:
    ws = book.ws(op)
    r1, c1, r2, c2 = _range(op["range"])
    k = _col(op["byColumn"], "byColumn") - c1
    if not 0 <= k <= c2 - c1:
        raise OpError("byColumn must lie inside the range")
    if op["order"] not in ("asc", "desc"):
        raise OpError("order must be asc or desc")
    if op.get("hasHeader"):
        r1 += 1
    rows = _snapshot(ws, r1, c1, r2, c2)
    filled = [r for r in rows if r[k][0] is not None]
    empty = [r for r in rows if r[k][0] is None]
    filled.sort(key=lambda r: _sort_key(r[k][0]), reverse=op["order"] == "desc")
    for i, row in enumerate(filled + empty):
        for j, (value, origin, style) in enumerate(row):
            cell = ws.cell(row=r1 + i, column=c1 + j)
            if isinstance(value, str) and value.startswith("="):
                value = Translator(value, origin=origin).translate_formula(cell.coordinate)
            cell.value = value
            cell._style = style


REGISTRY.unavailable("convert_to_values", "content", "{sheet?, range}",
                     "replacing formulas with values needs a formula engine, which the Python port does not have")


# ---- format ops ----


def _fill(fmt: dict[str, Any]) -> Any:
    spec = fmt["fill"]
    if spec is None:
        return PatternFill(fill_type=None)
    if not isinstance(spec, dict):
        raise OpError("fill must be {pattern, fg, bg?} or {gradient: {angle?, stops}}")
    if "gradient" in spec:
        g = spec["gradient"]
        stops = [Stop(_color(s["color"]), float(s.get("position", 0))) for s in g.get("stops", [])]
        if len(stops) < 2:
            raise OpError("gradient needs at least two stops")
        return GradientFill(type="linear", degree=float(g.get("angle", 0)), stop=stops)
    pattern = spec.get("pattern", "solid")
    fg = _color(spec["fg"]) if spec.get("fg") else None
    bg = _color(spec["bg"]) if spec.get("bg") else None
    return PatternFill(patternType=pattern, fgColor=fg, bgColor=bg)


def _apply_format(cell: Cell, fmt: dict[str, Any], edges: dict[str, bool]) -> None:
    font_keys = {"bold": "b", "italic": "i", "underline": "u", "strikethrough": "strike",
                 "fontFamily": "name", "fontSize": "sz", "fontColor": "color"}
    if any(k in fmt for k in font_keys):
        font = copy.copy(cell.font)
        for key, attr in font_keys.items():
            if key not in fmt:
                continue
            v = fmt[key]
            if key == "underline":
                v = "single" if v else None
            elif key == "fontColor":
                v = _color(v) if v is not None else None
            elif key == "fontFamily" and v is None:
                v = "Calibri"
            elif key == "fontSize" and v is None:
                v = 11
            elif key in ("bold", "italic", "strikethrough"):
                v = bool(v)
            setattr(font, attr, v)
        cell.font = font
    if "fillColor" in fmt:
        c = fmt["fillColor"]
        cell.fill = PatternFill(fill_type=None) if c is None else PatternFill("solid", fgColor=_color(c))
    if "fill" in fmt:
        cell.fill = _fill(fmt)
    if "numberFormat" in fmt:
        cell.number_format = fmt["numberFormat"] or "General"
    align_keys = {"horizontalAlign": "horizontal", "verticalAlign": "vertical", "wrapText": "wrap_text",
                  "textRotation": "text_rotation", "indent": "indent"}
    if any(k in fmt for k in align_keys):
        al = copy.copy(cell.alignment)
        for key, attr in align_keys.items():
            if key not in fmt:
                continue
            v = fmt[key]
            if key == "textRotation":
                v = 255 if v == "vertical" else (v or 0)
            elif key == "indent":
                v = v or 0
            elif key == "wrapText":
                v = bool(v)
            setattr(al, attr, v)
        cell.alignment = al
    if "border" in fmt and fmt["border"] is not None:
        b = fmt["border"]
        kind = b.get("type", "all")
        if kind == "none":
            cell.border = Border()
            return
        side = Side(style=b.get("style", "thin"), color=_color(b.get("color", "#000000")))
        border = copy.copy(cell.border)
        for name in ("top", "bottom", "left", "right"):
            if kind == "all" or (kind == name and edges[name]):
                setattr(border, name, side)
        cell.border = border


@REGISTRY.op(
    "format_range", "format",
    "{sheet?, range, format: {bold?, italic?, underline?, strikethrough?, fontFamily?, fontSize?: n, fontColor?, fillColor?, "
    "fill?: {pattern, fg, bg?}|{gradient: {angle?, stops: [{position, color}]}}, numberFormat?, horizontalAlign?: left|center|right, "
    "verticalAlign?: top|center|bottom, wrapText?: bool, textRotation?: n|vertical, indent?: n, border?: {type: all|top|bottom|left|right|none, style?, color?}}}",
    required=("range", "format"),
    note='null clears a property; colors are #RRGGBB or theme slots ("accent1", "accent1+40%", "dk2-25%", {theme, tint}) that follow the workbook theme; fill = {pattern, fg, bg?} or {gradient: {angle, stops}}; border type none removes all borders',
)
def _format_range(book: Book, op: dict[str, Any]) -> None:
    ws = book.ws(op)
    r1, c1, r2, c2 = _range(op["range"])
    fmt = op["format"]
    if not isinstance(fmt, dict) or not fmt:
        raise OpError("format must set at least one property")
    unknown = set(fmt) - {"bold", "italic", "underline", "strikethrough", "fontFamily", "fontSize", "fontColor", "fillColor",
                          "fill", "numberFormat", "horizontalAlign", "verticalAlign", "wrapText", "textRotation", "indent", "border"}
    if unknown:
        raise OpError(f"unknown format fields: {', '.join(sorted(unknown))}")
    for r in range(r1, r2 + 1):
        for c in range(c1, c2 + 1):
            edges = {"top": r == r1, "bottom": r == r2, "left": c == c1, "right": c == c2}
            _apply_format(ws.cell(row=r, column=c), fmt, edges)


def _dxf(fmt: dict[str, Any] | None) -> dict[str, Any]:
    fmt = fmt or {}
    out: dict[str, Any] = {}
    if fmt.get("fillColor"):
        c = _color(fmt["fillColor"])
        out["fill"] = PatternFill(start_color=c, end_color=c, fill_type="solid")
    if any(k in fmt for k in ("fontColor", "bold", "italic")):
        out["font"] = Font(color=_color(fmt["fontColor"]) if fmt.get("fontColor") else None,
                           b=fmt.get("bold"), i=fmt.get("italic"))
    if not out:
        raise OpError("rule format needs fillColor, fontColor, bold or italic")
    return out


@REGISTRY.op(
    "add_conditional_format", "format",
    "{sheet?, range, rule: {kind: number, operator, value: n, value2?: n}|{kind: text, operator: contains|notContains|beginsWith|endsWith, text}"
    "|{kind: blank, blank: bool}|{kind: colorScale, minColor, maxColor, midColor?}|{kind: dataBar, color}, format?: {fillColor?, fontColor?, bold?, italic?}}",
    required=("range", "rule"),
    note="adds to the rules the sheet already has (clear_conditional_formats first to start over); format = {fillColor?, fontColor?, bold?, italic?}",
)
def _add_cf(book: Book, op: dict[str, Any]) -> None:
    ws = book.ws(op)
    r1, c1, r2, c2 = _range(op["range"])
    rng = _ref(r1, c1, r2, c2)
    tl = _ref(r1, c1)
    rule = op["rule"]
    kind = rule.get("kind") if isinstance(rule, dict) else None
    if kind == "number":
        operator = rule.get("operator")
        valid = ("between", "notBetween", "equal", "notEqual", "greaterThan", "lessThan", "greaterThanOrEqual", "lessThanOrEqual")
        if operator not in valid:
            raise OpError(f"number operator must be one of {', '.join(valid)}")
        formula = [str(rule["value"])] + ([str(rule["value2"])] if operator in ("between", "notBetween") else [])
        if operator in ("between", "notBetween") and "value2" not in rule:
            raise OpError(f"{operator} needs value2")
        cf = CellIsRule(operator=operator, formula=formula, **_dxf(op.get("format")))
    elif kind == "text":
        t = str(rule.get("text", "")).replace('"', '""')
        if not t:
            raise OpError("text rule needs text")
        exprs = {
            "contains": f'NOT(ISERROR(SEARCH("{t}",{tl})))',
            "notContains": f'ISERROR(SEARCH("{t}",{tl}))',
            "beginsWith": f'LEFT({tl},{len(rule["text"])})="{t}"',
            "endsWith": f'RIGHT({tl},{len(rule["text"])})="{t}"',
        }
        if rule.get("operator") not in exprs:
            raise OpError("text operator must be contains, notContains, beginsWith or endsWith")
        cf = FormulaRule(formula=[exprs[rule["operator"]]], **_dxf(op.get("format")))
    elif kind == "blank":
        expr = f"LEN(TRIM({tl}))=0" if rule.get("blank", True) else f"LEN(TRIM({tl}))>0"
        cf = FormulaRule(formula=[expr], **_dxf(op.get("format")))
    elif kind == "colorScale":
        lo, hi = _color(rule.get("minColor", "#F8696B")), _color(rule.get("maxColor", "#63BE7B"))
        if rule.get("midColor"):
            cf = ColorScaleRule(start_type="min", start_color=lo, mid_type="percentile", mid_value=50,
                                mid_color=_color(rule["midColor"]), end_type="max", end_color=hi)
        else:
            cf = ColorScaleRule(start_type="min", start_color=lo, end_type="max", end_color=hi)
    elif kind == "dataBar":
        cf = DataBarRule(start_type="min", end_type="max", color=_color(rule.get("color", "#638EC6")))
    else:
        raise OpError("rule.kind must be number, text, blank, colorScale or dataBar")
    ws.conditional_formatting.add(rng, cf)


@REGISTRY.op("clear_conditional_formats", "format", "{sheet?}",
             note="removes every rule of the sheet; later add_conditional_format ops in the batch rebuild from scratch")
def _clear_cf(book: Book, op: dict[str, Any]) -> None:
    from openpyxl.formatting.formatting import ConditionalFormattingList

    book.ws(op).conditional_formatting = ConditionalFormattingList()


def _drop_validation(ws: Worksheet, rng: str) -> None:
    for dv in list(ws.data_validations.dataValidation):
        kept = [str(r) for r in dv.sqref.ranges if str(r) != rng]
        if len(kept) == len(dv.sqref.ranges):
            continue
        if kept:
            dv.sqref = " ".join(kept)  # type: ignore[assignment]
        else:
            ws.data_validations.dataValidation.remove(dv)


@REGISTRY.op(
    "set_data_validation", "format",
    "{sheet?, range, validation: {kind: list, values: [string]}|{kind: whole|decimal|date|textLength, operator?, min?, max?}|{kind: custom, formula}|null}",
    required=("range",),
    note="adds to the rules the sheet already has; on a range that has one it replaces it, null removes it",
)
def _set_dv(book: Book, op: dict[str, Any]) -> None:
    ws = book.ws(op)
    r1, c1, r2, c2 = _range(op["range"])
    rng = _ref(r1, c1, r2, c2)
    _drop_validation(ws, rng)
    v = op.get("validation")
    if v is None:
        return
    kind = v.get("kind") if isinstance(v, dict) else None
    if kind == "list":
        values = v.get("values") or []
        if not values:
            raise OpError("list validation needs values")
        dv = DataValidation(type="list", formula1='"' + ",".join(str(x).replace('"', '""') for x in values) + '"', allow_blank=True)
    elif kind in ("whole", "decimal", "date", "textLength"):
        operator = v.get("operator", "between")
        lo = v.get("min", v.get("value"))
        hi = v.get("max")
        if lo is None:
            raise OpError(f"{kind} validation needs min (or value)")
        dv = DataValidation(type=kind, operator=operator, formula1=str(lo), formula2=str(hi) if hi is not None else None, allow_blank=True)
    elif kind == "custom":
        dv = DataValidation(type="custom", formula1=str(v.get("formula", "")).lstrip("="), allow_blank=True)
    else:
        raise OpError("validation.kind must be list, whole, decimal, date, textLength or custom")
    dv.add(rng)
    ws.add_data_validation(dv)


# ---- layout ops ----


@REGISTRY.op("merge_cells", "layout", "{sheet?, range}", required=("range",))
def _merge(book: Book, op: dict[str, Any]) -> None:
    ws = book.ws(op)
    ws.merge_cells(_ref(*_range(op["range"])))


@REGISTRY.op("unmerge_cells", "layout", "{sheet?, range}", required=("range",))
def _unmerge(book: Book, op: dict[str, Any]) -> None:
    ws = book.ws(op)
    rng = _ref(*_range(op["range"]))
    if rng not in {str(m) for m in ws.merged_cells.ranges}:
        raise OpError(f"no merged range {rng}", reason="target_not_found", available=[str(m) for m in ws.merged_cells.ranges], wanted=rng)
    ws.unmerge_cells(rng)


@REGISTRY.op("set_row_height", "layout", "{sheet?, row: n, count?: n, heightPoints: n}", required=("row", "heightPoints"), note="pt")
def _row_height(book: Book, op: dict[str, Any]) -> None:
    ws = book.ws(op)
    h = op["heightPoints"]
    if not isinstance(h, (int, float)) or not 2 <= h <= 409:
        raise OpError("heightPoints must be 2-409")
    for r in range(int(op["row"]), int(op["row"]) + _count(op, 500)):
        ws.row_dimensions[r].height = h


@REGISTRY.op("set_col_width", "layout", "{sheet?, column, count?: n, widthPx: n}", required=("column", "widthPx"), note="px")
def _col_width(book: Book, op: dict[str, Any]) -> None:
    ws = book.ws(op)
    w = op["widthPx"]
    if not isinstance(w, (int, float)) or not 10 <= w <= 2000:
        raise OpError("widthPx must be 10-2000")
    c0 = _col(op["column"])
    for c in range(c0, c0 + _count(op, 100)):
        ws.column_dimensions[get_column_letter(c)].width = round(max(w - 5, 0) / 7, 2)


@REGISTRY.op("set_rows_hidden", "layout", "{sheet?, row: n, count?: n, hidden: bool}", required=("row", "hidden"))
def _rows_hidden(book: Book, op: dict[str, Any]) -> None:
    ws = book.ws(op)
    for r in range(int(op["row"]), int(op["row"]) + _count(op, 10000)):
        ws.row_dimensions[r].hidden = bool(op["hidden"])


@REGISTRY.op("set_cols_hidden", "layout", "{sheet?, column, count?: n, hidden: bool}", required=("column", "hidden"))
def _cols_hidden(book: Book, op: dict[str, Any]) -> None:
    ws = book.ws(op)
    c0 = _col(op["column"])
    for c in range(c0, c0 + _count(op, 1000)):
        ws.column_dimensions[get_column_letter(c)].hidden = bool(op["hidden"])


@REGISTRY.op("set_freeze", "layout", "{sheet?, rows: n, columns: n}", required=("rows", "columns"), note="0/0 unfreezes")
def _freeze(book: Book, op: dict[str, Any]) -> None:
    ws = book.ws(op)
    rows, cols = int(op["rows"]), int(op["columns"])
    if not (0 <= rows <= 100 and 0 <= cols <= 100):
        raise OpError("rows and columns must be 0-100")
    ws.freeze_panes = None if rows == 0 and cols == 0 else _ref(rows + 1, cols + 1)


@REGISTRY.op("set_filter", "layout", "{sheet?, range}", required=("range",))
def _set_filter(book: Book, op: dict[str, Any]) -> None:
    ws = book.ws(op)
    ws.auto_filter.ref = _ref(*_range(op["range"]))


@REGISTRY.op("set_filter_criteria", "layout", "{sheet?, column, values: [string]|null}", required=("column",),
             note="needs a filter without criteria; null clears the column")
def _filter_criteria(book: Book, op: dict[str, Any]) -> None:
    ws = book.ws(op)
    if not ws.auto_filter.ref:
        raise OpError("the sheet has no filter; set_filter first")
    _, c1, _, c2 = _range(ws.auto_filter.ref)
    c = _col(op["column"])
    if not c1 <= c <= c2:
        raise OpError(f"column {op['column']} is outside the filter {ws.auto_filter.ref}")
    col_id = c - c1
    ws.auto_filter.filterColumn = [f for f in ws.auto_filter.filterColumn if f.colId != col_id]
    if op.get("values"):
        ws.auto_filter.add_filter_column(col_id, [str(v) for v in op["values"]])


@REGISTRY.op("clear_filter", "layout", "{sheet?}")
def _clear_filter(book: Book, op: dict[str, Any]) -> None:
    ws = book.ws(op)
    ws.auto_filter.ref = None
    ws.auto_filter.filterColumn = []


@REGISTRY.op(
    "set_page_setup", "layout",
    "{sheet?, orientation?: portrait|landscape, paperSize?: n, scale?: n, fitToWidth?: n, fitToHeight?: n, margins?: normal|wide|narrow, "
    "printArea?: string|null, printTitles?: string|null, header?: {left?, center?, right?}|null, footer?: {left?, center?, right?}|null}",
    note="paperSize 9 = A4, 1 = Letter; scale and fitToWidth/fitToHeight are exclusive; margins normal|wide|narrow; printArea/printTitles/header/footer null clears",
)
def _page_setup(book: Book, op: dict[str, Any]) -> None:
    ws = book.ws(op)
    keys = {"orientation", "paperSize", "scale", "fitToWidth", "fitToHeight", "margins", "printArea", "printTitles", "header", "footer"}
    if not keys & set(op):
        raise OpError("set_page_setup needs at least one setting")
    if "scale" in op and ("fitToWidth" in op or "fitToHeight" in op):
        raise OpError("scale and fitToWidth/fitToHeight are exclusive")
    if op.get("orientation"):
        if op["orientation"] not in ("portrait", "landscape"):
            raise OpError("orientation must be portrait or landscape")
        ws.page_setup.orientation = op["orientation"]
    if op.get("paperSize") is not None:
        ws.page_setup.paperSize = int(op["paperSize"])
    if op.get("scale") is not None:
        ws.page_setup.scale = int(op["scale"])
        ws.sheet_properties.pageSetUpPr.fitToPage = False
    if "fitToWidth" in op or "fitToHeight" in op:
        ws.sheet_properties.pageSetUpPr.fitToPage = True
        ws.page_setup.fitToWidth = int(op.get("fitToWidth", 1) or 0)
        ws.page_setup.fitToHeight = int(op.get("fitToHeight", 0) or 0)
    if op.get("margins"):
        if op["margins"] not in _MARGINS:
            raise OpError("margins must be normal, wide or narrow")
        m = ws.page_margins
        m.left, m.right, m.top, m.bottom, m.header, m.footer = _MARGINS[op["margins"]]
    if "printArea" in op:
        ws.print_area = op["printArea"] if op["printArea"] else None  # type: ignore[assignment]
    if "printTitles" in op:
        ws.print_title_rows = None
        ws.print_title_cols = None
        for part in (op["printTitles"] or "").split(","):
            part = part.strip()
            if re.fullmatch(r"\d+:\d+", part):
                ws.print_title_rows = part
            elif re.fullmatch(r"[A-Za-z]+:[A-Za-z]+", part):
                ws.print_title_cols = part.upper()
            elif part:
                raise OpError('printTitles is "1:3", "A:B" or "A:B,1:3"')
    for key, hf in (("header", ws.oddHeader), ("footer", ws.oddFooter)):
        if key not in op:
            continue
        parts = op[key] or {}
        hf.left.text = parts.get("left")
        hf.center.text = parts.get("center")
        hf.right.text = parts.get("right")


@REGISTRY.op("protect_sheet", "layout", "{sheet?, protected: bool, password?}", required=("protected",))
def _protect(book: Book, op: dict[str, Any]) -> None:
    ws = book.ws(op)
    ws.protection.sheet = bool(op["protected"])
    if op["protected"] and op.get("password"):
        ws.protection.password = op["password"]
    if not op["protected"]:
        ws.protection.password = None


# ---- data ops ----


@REGISTRY.op("set_hyperlink", "data", "{sheet?, address, target: string|null}", required=("address",))
def _hyperlink(book: Book, op: dict[str, Any]) -> None:
    ws = book.ws(op)
    r, c = _addr(op["address"])
    cell = ws.cell(row=r, column=c)
    target = op.get("target")
    if not target:
        cell.hyperlink = None
        return
    if target.startswith("#"):
        cell.hyperlink = None
        from openpyxl.worksheet.hyperlink import Hyperlink

        cell.hyperlink = Hyperlink(ref=cell.coordinate, location=target[1:])
    else:
        cell.hyperlink = target
    cell.style = "Hyperlink"


@REGISTRY.op("set_note", "data", "{sheet?, address, text: string|null}", required=("address",))
def _note(book: Book, op: dict[str, Any]) -> None:
    ws = book.ws(op)
    r, c = _addr(op["address"])
    text = op.get("text")
    ws.cell(row=r, column=c).comment = Comment(text, "genoffice") if text else None


@REGISTRY.op("add_defined_name", "data", "{name, ref}", required=("name", "ref"), note='ref like "Sheet1!$A$2:$A$9"')
def _add_name(book: Book, op: dict[str, Any]) -> None:
    name = op["name"]
    if not re.fullmatch(r"[^\W\d][\w.]{0,254}", name) or _ADDR.match(name):
        raise OpError(f"invalid defined name {name!r}")
    ref = str(op["ref"]).lstrip("=")
    if name in book.wb.defined_names:
        del book.wb.defined_names[name]
    book.wb.defined_names[name] = DefinedName(name, attr_text=ref)


@REGISTRY.op("delete_defined_name", "data", "{name}", required=("name",))
def _del_name(book: Book, op: dict[str, Any]) -> None:
    names = list(book.wb.defined_names.keys())
    if op["name"] not in names:
        raise OpError(f'no defined name "{op["name"]}"', reason="target_not_found", available=names, wanted=op["name"])
    del book.wb.defined_names[op["name"]]


@REGISTRY.op("add_table", "data", "{sheet?, range, name?, style?, bandedRows?: bool}", required=("range",),
             note="first row = unique, non-empty column names")
def _add_table(book: Book, op: dict[str, Any]) -> None:
    ws = book.ws(op)
    r1, c1, r2, c2 = _range(op["range"])
    if r2 <= r1:
        raise OpError("a table needs a header row and at least one data row")
    heads = [ws.cell(row=r1, column=c).value for c in range(c1, c2 + 1)]
    if any(h in (None, "") for h in heads) or len({str(h).lower() for h in heads}) != len(heads):
        raise OpError("the first row must hold unique, non-empty column names")
    for c, h in zip(range(c1, c2 + 1), heads):
        if not isinstance(h, str):
            ws.cell(row=r1, column=c).value = str(h)
    existing = {t for s in book.wb.worksheets for t in s.tables}
    name = op.get("name") or next(f"Table{i}" for i in range(1, 10000) if f"Table{i}" not in existing)
    if name in existing:
        raise OpError(f"a table named {name} already exists")
    style = op.get("style", "TableStyleMedium2")
    if not re.fullmatch(r"TableStyle(?:Light|Medium|Dark)[1-9][0-9]?", style):
        raise OpError('style is a built-in table style like "TableStyleMedium2"')
    table = Table(displayName=name, ref=_ref(r1, c1, r2, c2))
    table.tableStyleInfo = TableStyleInfo(name=style, showRowStripes=op.get("bandedRows", True))
    ws.add_table(table)


REGISTRY.unavailable("add_pivot", "data", "{sheet?, sourceRange, targetSheet?, targetCell, rows, values, ...}",
                     "a pivot needs the source formulas evaluated and a pivot cache, which the Python port does not build")


# ---- visuals ----


@REGISTRY.op(
    "add_chart", "visuals",
    "{sheet?, chartType: column|bar|line|area|pie|doughnut|scatter, dataRange, title?, anchorCell?}",
    required=("chartType", "dataRange"),
    note="header row and a leading category column are detected; the chart lands two columns right of the data unless anchorCell",
)
def _add_chart(book: Book, op: dict[str, Any]) -> None:
    from openpyxl.chart import AreaChart, BarChart, DoughnutChart, LineChart, PieChart, Reference, ScatterChart, Series

    ws = book.ws(op)
    r1, c1, r2, c2 = _range(op["dataRange"], "dataRange")
    kind = op["chartType"]
    makers = {"column": BarChart, "bar": BarChart, "line": LineChart, "area": AreaChart,
              "pie": PieChart, "doughnut": DoughnutChart, "scatter": ScatterChart}
    if kind not in makers:
        raise OpError(f"chartType must be one of {', '.join(makers)}")
    header = any(isinstance(ws.cell(row=r1, column=c).value, str) for c in range(c1 + 1 if c2 > c1 else c1, c2 + 1))
    first = r1 + 1 if header else r1
    body = [ws.cell(row=r, column=c1).value for r in range(first, r2 + 1)]
    has_cats = c2 > c1 and any(isinstance(v, str) for v in body)
    chart = makers[kind]()
    if kind in ("column", "bar"):
        chart.type = "col" if kind == "column" else "bar"
    if kind == "scatter":
        xs = Reference(ws, min_col=c1, min_row=first, max_row=r2)
        for c in range(c1 + 1, c2 + 1):
            ys = Reference(ws, min_col=c, min_row=r1 if header else first, max_row=r2)
            chart.series.append(Series(ys, xs, title_from_data=header))
    else:
        dc = c1 + 1 if has_cats else c1
        chart.add_data(Reference(ws, min_col=dc, min_row=r1, max_col=c2, max_row=r2), titles_from_data=header)
        if has_cats:
            chart.set_categories(Reference(ws, min_col=c1, min_row=first, max_row=r2))
    if op.get("title"):
        chart.title = op["title"]
    anchor = op.get("anchorCell")
    if anchor:
        _addr(anchor, "anchorCell")
    else:
        anchor = _ref(r1, c2 + 2)
    ws.add_chart(chart, anchor)


def _image_bytes(book: Book, path: str) -> io.BytesIO:
    if re.match(r"^https?://", path):
        try:
            with urllib.request.urlopen(path, timeout=30) as resp:  # noqa: S310 - the op asks for this URL
                return io.BytesIO(resp.read())
        except Exception as e:  # pragma: no cover - network
            raise OpError(f"could not download {path}: {e}")
    candidates = [Path(path)] if Path(path).is_absolute() else [book.ctx.base / path] + ([book.base / path] if book.base else [])
    for cand in candidates:
        p = book.ctx.resolve(cand)
        if p.is_file():
            return io.BytesIO(p.read_bytes())
    raise OpError(f"image not found: {path}", reason="op_rejected")


@REGISTRY.op("add_image", "visuals", "{sheet?, path, anchorCell?, widthPx?: n, heightPx?: n}", required=("path",),
             note="path is a local file (absolute or relative) or an https URL")
def _add_image(book: Book, op: dict[str, Any]) -> None:
    from openpyxl.drawing.image import Image

    ws = book.ws(op)
    img = Image(_image_bytes(book, op["path"]))
    if op.get("widthPx") and op.get("heightPx"):
        img.width, img.height = op["widthPx"], op["heightPx"]
    elif op.get("widthPx"):
        img.height, img.width = img.height * op["widthPx"] / img.width, op["widthPx"]
    anchor = op.get("anchorCell", "A1")
    _addr(anchor, "anchorCell")
    ws.add_image(img, anchor)


REGISTRY.unavailable("edit_chart", "visuals", "{sheet?, chart, title?, chartType?, seriesColors?, legend?, dataLabels?, grouping?, axisTitles?}",
                     "openpyxl cannot re-open a chart part for editing; delete and add_chart again")
REGISTRY.unavailable("add_shape", "visuals", "{sheet?, shapeType, anchorCell, text?, ...}", "openpyxl does not write drawing shapes")
REGISTRY.unavailable("add_sparkline", "visuals", "{sheet?, dataRange, targetCell?, type: line|column|stacked}",
                     "openpyxl does not write sparkline extensions")


# ---- structure ----


@REGISTRY.op("insert_rows", "structure", "{sheet?, row: n, count: n}", required=("row", "count"))
def _insert_rows(book: Book, op: dict[str, Any]) -> None:
    ws = book.ws(op)
    n = _count(op, 500)
    _shift_workbook(book, ws, "row", int(op["row"]), n, False)
    ws.insert_rows(int(op["row"]), n)


@REGISTRY.op("delete_rows", "structure", "{sheet?, row: n, count: n}", required=("row", "count"))
def _delete_rows(book: Book, op: dict[str, Any]) -> None:
    ws = book.ws(op)
    n = _count(op, 500)
    _shift_workbook(book, ws, "row", int(op["row"]), n, True)
    ws.delete_rows(int(op["row"]), n)


@REGISTRY.op("insert_cols", "structure", "{sheet?, column, count: n}", required=("column", "count"))
def _insert_cols(book: Book, op: dict[str, Any]) -> None:
    ws = book.ws(op)
    c, n = _col(op["column"]), _count(op, 100)
    _shift_workbook(book, ws, "col", c, n, False)
    ws.insert_cols(c, n)


@REGISTRY.op("delete_cols", "structure", "{sheet?, column, count: n}", required=("column", "count"))
def _delete_cols(book: Book, op: dict[str, Any]) -> None:
    ws = book.ws(op)
    c, n = _col(op["column"]), _count(op, 100)
    _shift_workbook(book, ws, "col", c, n, True)
    ws.delete_cols(c, n)


def _sheet_name(book: Book, name: Any) -> str:
    if not isinstance(name, str) or not name.strip() or len(name) > 31 or re.search(r"[\[\]:*?/\\]", name):
        raise OpError("sheet names are 1-31 characters without [ ] : * ? / \\")
    if name.lower() in (s.lower() for s in book.wb.sheetnames):
        raise OpError(f'a sheet named "{name}" already exists')
    return name


@REGISTRY.op("add_sheet", "structure", "{name, rows?: n, columns?: n}", required=("name",))
def _add_sheet(book: Book, op: dict[str, Any]) -> None:
    book.wb.create_sheet(_sheet_name(book, op["name"]))


@REGISTRY.op("delete_sheet", "structure", "{sheet}", required=("sheet",))
def _delete_sheet(book: Book, op: dict[str, Any]) -> None:
    ws = book.ws(op)
    if len(book.wb.worksheets) == 1:
        raise OpError("cannot delete the only sheet")
    book.wb.remove(ws)


@REGISTRY.op("rename_sheet", "structure", "{sheet, name}", required=("sheet", "name"))
def _rename_sheet(book: Book, op: dict[str, Any]) -> None:
    ws = book.ws(op)
    old, new = ws.title, _sheet_name(book, op["name"])
    ws.title = new
    quoted_old = "'" + old.replace("'", "''") + "'!"
    plain_old = old + "!"
    ref_new = ("'" + new.replace("'", "''") + "'!") if re.search(r"\W", new) else new + "!"
    for sheet in book.wb.worksheets:
        for row in sheet.iter_rows():
            for cell in row:
                if isinstance(cell.value, str) and cell.value.startswith("="):
                    v = cell.value.replace(quoted_old, ref_new)
                    if not re.search(r"\W", old):
                        v = re.sub(rf"(?<![\w'.]){re.escape(plain_old)}", ref_new, v)
                    cell.value = v
    if book.default_sheet == old:
        book.default_sheet = new


@REGISTRY.op("duplicate_sheet", "structure", "{sheet, name?}", required=("sheet",),
             note="the copy is cloned from the workbook as it stands at this op")
def _dup_sheet(book: Book, op: dict[str, Any]) -> None:
    ws = book.ws(op)
    name = op.get("name") or next(f"{ws.title} ({i})" for i in range(2, 1000) if f"{ws.title} ({i})" not in book.wb.sheetnames)
    copy_ws = book.wb.copy_worksheet(ws)
    copy_ws.title = _sheet_name(book, name)


@REGISTRY.op("move_sheet", "structure", "{sheet, position: n}", required=("sheet", "position"), note="position is 1-based")
def _move_sheet(book: Book, op: dict[str, Any]) -> None:
    ws = book.ws(op)
    n = len(book.wb.worksheets)
    pos = op["position"]
    if not isinstance(pos, int) or not 1 <= pos <= n:
        raise OpError(f"position out of range (1-{n})", reason="out_of_range", valid_range=(1, n))
    book.wb.move_sheet(ws, offset=pos - 1 - book.wb.worksheets.index(ws))


@REGISTRY.op("set_sheet_hidden", "structure", "{sheet, hidden: bool}", required=("sheet", "hidden"))
def _sheet_hidden(book: Book, op: dict[str, Any]) -> None:
    ws = book.ws(op)
    if op["hidden"]:
        visible = [s for s in book.wb.worksheets if s.sheet_state == "visible"]
        if visible == [ws]:
            raise OpError("cannot hide the last visible sheet")
        ws.sheet_state = "hidden"
        if book.wb.active is ws:
            book.wb.active = book.wb.worksheets.index(next(s for s in visible if s is not ws))
    else:
        ws.sheet_state = "visible"


REGISTRY.unavailable("refresh_pivot", "editor-only", "{sheet?, pivot}", "needs the live editor")


# ---- cells mode ----


@CELLS.op("cell", "cells", '{cell, sheet?, value? | formula?, style?}', required=("cell",))
def _cells_entry(book: Book, op: dict[str, Any]) -> None:
    if "value" in op and "formula" in op:
        raise OpError("give value or formula, not both")
    base = {"sheet": op.get("sheet")}
    if "formula" in op:
        _set_formula(book, {**base, "address": op["cell"], "formula": op["formula"]})
    elif "value" in op:
        _set_cell(book, {**base, "address": op["cell"], "value": op["value"]})
    if op.get("style"):
        _format_range(book, {**base, "range": op["cell"], "format": op["style"]})
    if not any(k in op for k in ("value", "formula", "style")):
        raise OpError("each entry needs value, formula or style")


# ---- loading ----


def _load(path: Path, *, data_only: bool = False) -> Workbook:
    try:
        return openpyxl.load_workbook(path, data_only=data_only)
    except Exception as e:
        raise GenOfficeError(EXIT.conversion, f"could not open {path.name} as a workbook: {e}", reason="conversion_failed")


def _pick_sheet(wb: Workbook, name: str | None) -> Worksheet:
    if name is None:
        return wb.active
    if name not in wb.sheetnames:
        guess = did_you_mean(name, wb.sheetnames)
        raise GenOfficeError(
            EXIT.usage,
            f'no sheet "{name}"',
            {"sheets": list(wb.sheetnames)},
            reason="sheet_not_found",
            suggestion=f'did you mean "{guess}"? (detail.sheets has the tab names)' if guess else "use a name from detail.sheets verbatim",
        )
    return wb[name]


def _raw(v: Any) -> Any:
    """Values as the workbook stores them: dates become Excel serials."""
    if isinstance(v, (datetime, date)):
        return round(to_excel(v), 8)
    if isinstance(v, time):
        return round(to_excel(v), 8)
    return v


def _cols_filter(spec: str) -> list[int]:
    out: list[int] = []
    for part in spec.split(","):
        part = part.strip().upper()
        if not part:
            continue
        if ":" in part:
            a, b = part.split(":", 1)
            out.extend(range(column_index_from_string(a), column_index_from_string(b) + 1))
        elif _COL.match(part):
            out.append(column_index_from_string(part))
        else:
            raise GenOfficeError(EXIT.usage, f'cols must look like "A,C:E", got {spec!r}', reason="invalid_argument")
    return sorted(set(out))


def _features(ws: Worksheet, box: tuple[int, int, int, int]) -> dict[str, Any]:
    r1, c1, r2, c2 = box
    charts = []
    for i, ch in enumerate(getattr(ws, "_charts", [])):
        title = None
        try:
            t = ch.title
            title = t if isinstance(t, str) else "".join(r.t for p in t.tx.rich.p for r in (p.r or [])) if t else None
        except Exception:
            title = None
        charts.append({"index": i, "type": getattr(ch, "tagname", type(ch).__name__), "title": title})
    merges = [str(m) for m in ws.merged_cells.ranges if not (m.max_row < r1 or m.min_row > r2 or m.max_col < c1 or m.min_col > c2)]
    links = []
    for row in ws.iter_rows(min_row=r1, max_row=r2, min_col=c1, max_col=c2):
        for cell in row:
            if getattr(cell, "hyperlink", None):
                links.append({"ref": cell.coordinate, "target": cell.hyperlink.target or f"#{cell.hyperlink.location}"})
    return {
        "panes": {"frozen": ws.freeze_panes} if ws.freeze_panes else None,
        "filter": ws.auto_filter.ref or None,
        "charts": charts,
        "images": len(getattr(ws, "_images", [])),
        "tables": [{"name": n, "ref": t.ref if hasattr(t, "ref") else t} for n, t in ws.tables.items()],
        "conditional_formats": sum(len(cf.rules) for cf in ws.conditional_formatting),
        "data_validations": len(ws.data_validations.dataValidation),
        "merges": merges,
        "links": links,
    }


def _cell_format(cell: Cell) -> dict[str, Any]:
    out: dict[str, Any] = {}
    f = cell.font
    if f.b:
        out["bold"] = True
    if f.i:
        out["italic"] = True
    if f.u:
        out["underline"] = True
    if f.strike:
        out["strikethrough"] = True
    if f.name and f.name != "Calibri":
        out["fontFamily"] = f.name
    if f.sz and float(f.sz) != 11:
        out["fontSize"] = float(f.sz)
    color = _color_out(f.color)
    if color and color not in ("#000000", {"theme": "dk1", "tint": 0}):
        out["fontColor"] = color
    if isinstance(cell.fill, PatternFill) and cell.fill.fill_type:
        out["fillColor" if cell.fill.fill_type == "solid" else "fill"] = (
            _color_out(cell.fill.fgColor) if cell.fill.fill_type == "solid"
            else {"pattern": cell.fill.fill_type, "fg": _color_out(cell.fill.fgColor), "bg": _color_out(cell.fill.bgColor)}
        )
    elif isinstance(cell.fill, GradientFill):
        out["fill"] = {"gradient": {"angle": cell.fill.degree, "stops": [{"position": s.position, "color": _color_out(s.color)} for s in cell.fill.stop]}}
    if cell.number_format and cell.number_format != "General":
        out["numberFormat"] = cell.number_format
    a = cell.alignment
    if a.horizontal:
        out["horizontalAlign"] = a.horizontal
    if a.vertical:
        out["verticalAlign"] = a.vertical
    if a.wrap_text:
        out["wrapText"] = True
    if a.text_rotation:
        out["textRotation"] = "vertical" if a.text_rotation == 255 else a.text_rotation
    if a.indent:
        out["indent"] = a.indent
    sides = [s for s in ("top", "bottom", "left", "right") if getattr(cell.border, s) is not None and getattr(cell.border, s).style]
    if sides:
        out["border"] = sides
    return out


def _kind(value: Any, formula: str | None) -> str:
    if formula:
        return "formula"
    if value is None or value == "":
        return "empty"
    if isinstance(value, str) and value in _ERRORS:
        return "error"
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return "number"
    return "text"


# ---- read ----


def read(
    ctx: Context,
    file: str,
    *,
    sheet: str | None = None,
    range: str | None = None,  # noqa: A002 - the CLI flag is --range
    cols: str | None = None,
    max_rows: int | None = None,
    where: str | None = None,
    stats: bool = False,
    formats: bool = False,
) -> CommandResult:
    path = ctx.input_file(file)
    wb = _load(path)
    ws = _pick_sheet(wb, sheet)
    cached_ws = _load(path, data_only=True)[ws.title]
    if where is not None and where not in ("formula", "error", "empty", "number", "text"):
        raise GenOfficeError(EXIT.usage, "where must be formula, error, empty, number or text", reason="invalid_argument")

    used = ws.calculate_dimension() if ws.max_row and ws.max_column else "A1:A1"
    if range:
        try:
            c1, r1, c2, r2 = range_boundaries(range.upper())
        except Exception:
            raise GenOfficeError(EXIT.usage, f'range must look like "A1:D20", got {range!r}', reason="invalid_argument")
        r1, r2 = r1 or 1, r2 or ws.max_row
    else:
        c1, r1, c2, r2 = range_boundaries(used)
    box = (r1, c1, r2, c2)
    sheets = list(wb.sheetnames)

    if stats:
        counts = {"formula": 0, "error": 0, "number": 0, "text": 0}
        for row in ws.iter_rows():
            for cell in row:
                k = _kind(cached_ws[cell.coordinate].value, cell.value if isinstance(cell.value, str) and cell.value.startswith("=") else None)
                if k in counts:
                    counts[k] += 1
        detail = {
            "sheet": ws.title,
            "sheets": [{"name": s.title, "used": s.calculate_dimension(), "rows": s.max_row, "cols": s.max_column, "state": s.sheet_state} for s in wb.worksheets],
            "used": used,
            "counts": counts,
            "features": _features(ws, box),
        }
        return CommandResult(summary=f"stats of {ws.title} ({used}) in {path.name}", detail=detail)

    columns = _cols_filter(cols) if cols else list(_irange(c1, min(c2, c1 + MAX_READ_COLS - 1) + 1))
    cols_truncated = not cols and c2 - c1 + 1 > MAX_READ_COLS
    cap = max_rows or MAX_READ_ROWS
    rows_total = r2 - r1 + 1
    last = min(r2, r1 + cap - 1)
    detail: dict[str, Any] = {"sheet": ws.title, "sheets": sheets, "range": _ref(r1, c1, r2, c2)}

    if where:
        cells = []
        for r in _irange(r1, r2 + 1):
            for c in columns:
                cell = ws.cell(row=r, column=c)
                f = cell.value if isinstance(cell.value, str) and cell.value.startswith("=") else None
                value = _raw(cached_ws.cell(row=r, column=c).value) if f else _raw(cell.value)
                if _kind(value, f) == where:
                    cells.append({"ref": cell.coordinate, "value": value, "formula": f})
                    if len(cells) >= cap * 10:
                        break
        detail["cells"] = cells
        detail["features"] = _features(ws, box)
        return CommandResult(summary=f"{len(cells)} {where} cells in {ws.title}!{detail['range']} of {path.name}", detail=detail)

    values: list[list[Any]] = []
    formulas: dict[str, str] = {}
    fmts: dict[str, Any] = {}
    for r in _irange(r1, last + 1):
        row_vals = []
        for c in columns:
            cell = ws.cell(row=r, column=c)
            v = cell.value
            if isinstance(v, str) and v.startswith("="):
                formulas[cell.coordinate] = v
                v = cached_ws.cell(row=r, column=c).value
            row_vals.append(_raw(v))
            if formats and cell.has_style:
                f = _cell_format(cell)
                if f:
                    fmts[cell.coordinate] = f
        values.append(row_vals)
    detail["values"] = values
    if cols:
        detail["columns"] = [get_column_letter(c) for c in columns]
    detail["formulas"] = formulas
    detail["dates"] = "Excel serial numbers (days since 1899-12-30)"
    detail["rowsShown"] = len(values)
    detail["rowsTotal"] = rows_total
    if last < r2 or cols_truncated:
        detail["truncated"] = True
        if last < r2:
            detail["note"] = f"rows {r1}-{last} of {r1}-{r2}; pass range={_ref(last + 1, c1, r2, c2)!r} to continue"
        if cols_truncated:
            detail["note_cols"] = f"columns capped at {MAX_READ_COLS}; pass cols to choose others"
    if formulas and any(v is None for v in (_raw(cached_ws[a].value) for a in formulas)):
        detail["uncached_formulas"] = "formulas without a cached value read as null; Excel computes them on open"
    if formats:
        detail["formats"] = fmts
        detail["colWidths"] = {
            get_column_letter(c): round((ws.column_dimensions[get_column_letter(c)].width or 8.43) * 7 + 5)
            for c in columns
        }
        detail["rowHeights"] = {
            str(r): ws.row_dimensions[r].height for r in _irange(r1, last + 1) if ws.row_dimensions[r].height
        }
    detail["features"] = _features(ws, box)
    return CommandResult(summary=f"read {ws.title}!{_ref(r1, c1, last, columns[-1] if columns else c1)} of {path.name}", detail=detail)


# ---- batch order (formats/xlsx-batch-order.ts) ----

_ANCHORED_OPS = {
    "add_conditional_format", "clear_conditional_formats", "set_data_validation", "set_hyperlink", "set_note",
    "set_filter", "set_filter_criteria", "clear_filter", "add_chart", "add_image", "add_table",
}
_GRID_OPS = {"insert_rows", "delete_rows", "insert_cols", "delete_cols"}
_SHEET_OPS = {"add_sheet", "delete_sheet", "rename_sheet", "duplicate_sheet", "move_sheet", "set_sheet_hidden"}
_NAME_OPS = {"add_defined_name", "delete_defined_name"}


def _check_batch_order(ops: Any, book: Book) -> None:
    """Rules, links, notes, filters and visuals do not move with the grid, so a row/column op after one of them
    on the same sheet would leave it on the wrong cells; defined names do not follow sheet or grid ops either.
    Refused up front, whatever the batch mode."""
    if not isinstance(ops, list):
        return
    default = book.default_sheet or book.wb.active.title
    anchored: dict[str, int] = {}
    names_at = next((i for i, o in enumerate(ops) if isinstance(o, dict) and o.get("op") in _NAME_OPS), None)
    for i, o in enumerate(ops):
        if not isinstance(o, dict):
            continue
        name = o.get("op")
        sheet = o.get("sheet") or default
        if name in _ANCHORED_OPS:
            anchored.setdefault(sheet, i)
        elif name in _GRID_OPS and sheet in anchored:
            _reject_order(ops, i, name, f"{name} on {sheet} comes after op {anchored[sheet]} ({ops[anchored[sheet]]['op']}), "
                          "whose rule, link, note, filter or visual would not move with the rows/columns",
                          "move the row/column op before the rules, links, notes, filters and visuals of its sheet, or into its own batch")
        if names_at is not None and (name in _GRID_OPS or name in _SHEET_OPS):
            _reject_order(ops, i, name, f"{name} cannot share a batch with defined-name ops (op {names_at})",
                          "send the defined-name ops in their own batch, before or after the sheet and row/column ops")


def _reject_order(ops: list[Any], index: int, name: str, error: str, suggestion: str) -> None:
    from ..ops import batch_counts

    raise GenOfficeError(
        EXIT.usage,
        f"op {index} ({name}) rejected: {error}; nothing was written",
        {"failures": [{"index": index, "op": name, "reason": "op_rejected", "error": error, "usage": REGISTRY.ops[name].usage}],
         "batch": batch_counts(len(ops), 0, 1)},
        reason="op_rejected",
        suggestion=suggestion,
    )


# ---- apply ----


def apply(
    ctx: Context,
    file: str,
    *,
    ops: list[dict[str, Any]] | None = None,
    cells: list[dict[str, Any]] | None = None,
    sheet: str | None = None,
    dry_run: bool = False,
    mode: BatchMode = "atomic",
    out: str | None = None,
    force: bool = False,
    ops_base: str | None = None,
) -> CommandResult:
    if (ops is None) == (cells is None):
        raise GenOfficeError(EXIT.usage, "give exactly one of ops or cells", reason="invalid_argument",
                             suggestion="ops for the workbook DSL, cells for values/formulas/styles by address")
    path = ctx.input_file(file)
    wb = _load(path)
    if sheet is not None:
        _pick_sheet(wb, sheet)
    book = Book(wb, ctx, default_sheet=sheet, base=Path(ops_base) if ops_base else None)
    if cells is not None:
        if not isinstance(cells, list):
            raise GenOfficeError(EXIT.usage, "cells must be a JSON array", reason="invalid_argument")
        batch = [{**c, "op": "cell"} if isinstance(c, dict) else c for c in cells]
        outcome = CELLS.run_batch(batch, book, mode)
    else:
        _check_batch_order(ops, book)
        outcome = REGISTRY.run_batch(ops, book, mode)
    if dry_run:
        r = CommandResult(summary=f"dry run: {outcome.applied} of {outcome.total} ops valid for {path.name}; nothing written")
        r.detail = {"dry_run": True}
        return batch_result(r, outcome)
    target = ctx.output_file(out, force=force, editing=path) if out else path
    try:
        wb.save(target)
    except Exception as e:
        raise GenOfficeError(EXIT.conversion, f"could not write {target.name}: {e}", reason="conversion_failed")
    r = CommandResult(summary=f"applied {outcome.applied} ops to {target.name}", output_path=str(target))
    if book.formula_cells:
        listed = sorted(set(book.formula_cells))
        r.warnings.append(Warning(
            "formulas_not_cached",
            f"{len(listed)} formula cells have no cached value: {', '.join(listed[:20])}{' …' if len(listed) > 20 else ''}",
            "Excel computes them on open; sheet_read shows the formula and a null value until then",
        ))
    return batch_result(r, outcome)


# ---- check ----

_SHEET_REF = re.compile(r"(?:'((?:[^']|'')+)'|(?<![#\w.])([A-Za-z_\u00c0-\uffff][\w.\u00c0-\uffff]*))!")
_STRINGS = re.compile(r'"(?:[^"]|"")*"')
_PLACEHOLDER_TEXT = re.compile(r"(?i)\b(?:TODO|TBD|lorem ipsum|lorem)\b|\bXX+\b|\{\{[^{}]+\}\}")


def _sheet_refs(formula: str) -> set[str]:
    body = _STRINGS.sub('""', formula)
    return {(m.group(1) or m.group(2)).replace("''", "'") for m in _SHEET_REF.finditer(body)}


def check(ctx: Context, file: str) -> CommandResult:
    path = ctx.input_file(file)
    wb = _load(path)
    cached = _load(path, data_only=True)
    names = set(wb.sheetnames)
    issues: list[dict[str, Any]] = []
    uncached: list[str] = []

    def issue(code: str, level: str, where: str, message: str, suggest: dict[str, Any] | None = None) -> None:
        item = {"code": code, "level": level, "path": where, "message": message}
        if suggest:
            item["suggest"] = suggest
        issues.append(item)

    for ws in wb.worksheets:
        cws = cached[ws.title]
        widest: dict[str, int] = {}
        for row in ws.iter_rows():
            for cell in row:
                v = cell.value
                where = f"{ws.title}!{cell.coordinate}"
                cv = cws[cell.coordinate].value
                if isinstance(v, str) and v.startswith("="):
                    if "#REF!" in v:
                        issue("formula_error", "error", where, f"formula holds a broken reference: {v}")
                    for ref in _sheet_refs(v):
                        if ref not in names:
                            hint = did_you_mean(ref, names)
                            issue("missing_sheet_ref", "error", where,
                                  f'formula references sheet "{ref}", which is not in the workbook' + (f' (did you mean "{hint}"?)' if hint else ""))
                    if cv is None:
                        uncached.append(where)
                    elif isinstance(cv, str) and cv in _ERRORS:
                        issue("formula_error", "error", where, f"formula evaluates to {cv}: {v}")
                    continue
                if isinstance(v, str):
                    if v in _ERRORS:
                        issue("formula_error", "error", where, f"cell holds the error value {v}")
                    elif _PLACEHOLDER_TEXT.search(v):
                        issue("placeholder_text", "warning", where, f"placeholder text left in the cell: {v[:80]!r}")
                num = cv if not (isinstance(v, str) and v.startswith("=")) else None
                num = v if isinstance(v, (int, float)) and not isinstance(v, bool) else num
                if isinstance(num, (int, float)) and not isinstance(num, bool):
                    text = f"{num:,.2f}" if "," in (cell.number_format or "") else str(num)
                    if "%" in (cell.number_format or ""):
                        text = f"{num * 100:.2f}%"
                    col = cell.column_letter
                    widest[col] = max(widest.get(col, 0), len(text))
        for col, chars in widest.items():
            if col in {c for m in ws.merged_cells.ranges for c in (get_column_letter(i) for i in range(m.min_col, m.max_col + 1))}:
                continue
            width = ws.column_dimensions[col].width or 8.43
            if chars > width + 0.5:
                px = int(chars * 7 + 14)
                issue("column_too_narrow", "warning", f"{ws.title}!{col}:{col}",
                      f"numbers up to {chars} characters show as ### in a {width:.1f}-character column",
                      {"op": "set_col_width", "sheet": ws.title, "column": col, "widthPx": min(px, 2000)})
        for i, ch in enumerate(getattr(ws, "_charts", [])):
            for s in getattr(ch, "series", []):
                ref = getattr(getattr(getattr(s, "val", None), "numRef", None), "f", None)
                if not ref:
                    continue
                for sref in _sheet_refs(ref + ""):
                    if sref not in names:
                        issue("chart_range_off_data", "error", f"{ws.title}!chart{i}", f"chart series points at missing sheet {sref}: {ref}")
                m = re.search(r"\$?[A-Z]+\$?(\d+)(?::\$?[A-Z]+\$?(\d+))?$", ref)
                tgt_name = next(iter(_sheet_refs(ref)), ws.title)
                if m and tgt_name in names and int(m.group(1)) > wb[tgt_name].max_row:
                    issue("chart_range_off_data", "warning", f"{ws.title}!chart{i}", f"chart series range lies below the data: {ref}")
        n_cf = sum(len(cf.rules) for cf in ws.conditional_formatting)
        n_dv = len(ws.data_validations.dataValidation)
        if n_cf or n_dv:
            issue("existing_rules", "info", ws.title, f"{n_cf} conditional format rules, {n_dv} data validations")

    for name, dn in wb.defined_names.items():
        text = dn.attr_text or ""
        missing = [s for s in _sheet_refs(text) if s not in names]
        if "#REF!" in text or missing:
            issue("broken_defined_name", "error", name, f"defined name {name} points at {text}")
    for ws in wb.worksheets:
        for name, dn in ws.defined_names.items():
            if "#REF!" in (dn.attr_text or ""):
                issue("broken_defined_name", "error", f"{ws.title}!{name}", f"defined name {name} points at {dn.attr_text}")
    if uncached:
        issue("formulas_not_cached", "info", uncached[0],
              f"{len(uncached)} formulas have no cached value (Excel computes them on open): {', '.join(uncached[:50])}")

    errors = sum(1 for i in issues if i["level"] == "error")
    warnings = sum(1 for i in issues if i["level"] == "warning")
    return CommandResult(
        summary=f"checked {path.name}: {errors} errors, {warnings} warnings",
        detail={"issues": issues, "counts": {"error": errors, "warning": warnings, "info": len(issues) - errors - warnings}},
    )


# ---- create ----


def _rows_to_sheet(ws: Worksheet, rows: list[list[Any]], header: bool) -> int:
    formulas = 0
    for row in rows:
        if not isinstance(row, list):
            raise GenOfficeError(EXIT.usage, "every row must be an array of cell values", reason="invalid_argument")
        ws.append(row)
        formulas += sum(1 for v in row if isinstance(v, str) and v.startswith("="))
    if header and rows:
        width = max(len(r) for r in rows)
        for c in _irange(1, width + 1):
            ws.cell(row=1, column=c).font = Font(b=True)
        ws.freeze_panes = "A2"
        ws.auto_filter.ref = _ref(1, 1, len(rows), width)
    return formulas


def create_from_rows(ctx: Context, data: Any, out: str, *, header: bool = False, force: bool = False) -> CommandResult:
    if isinstance(data, dict) and isinstance(data.get("sheets"), list):
        sheets = data["sheets"]
    elif isinstance(data, list):
        sheets = [{"name": "Sheet1", "rows": data}]
    else:
        raise GenOfficeError(EXIT.usage, 'data must be a 2-D array or {"sheets": [{"name", "rows"}]}', reason="invalid_argument")
    if not sheets:
        raise GenOfficeError(EXIT.usage, "data has no sheets", reason="invalid_argument")
    target = ctx.output_file(out, force=force)
    wb = Workbook()
    wb.remove(wb.active)
    formulas = 0
    for i, s in enumerate(sheets):
        name = str(s.get("name") or f"Sheet{i + 1}")
        if len(name) > 31 or re.search(r"[\[\]:*?/\\]", name) or name in wb.sheetnames:
            raise GenOfficeError(EXIT.usage, f"invalid or duplicate sheet name {name!r}", reason="invalid_argument")
        formulas += _rows_to_sheet(wb.create_sheet(name), s.get("rows") or [], header)
    wb.save(target)
    r = CommandResult(
        summary=f"created {target.name} ({len(sheets)} sheet{'s' if len(sheets) != 1 else ''})",
        output_path=str(target),
        detail={"sheets": [{"name": s.get("name") or f"Sheet{i + 1}", "rows": len(s.get("rows") or [])} for i, s in enumerate(sheets)]},
    )
    if formulas:
        r.warnings.append(Warning("formulas_not_cached", f"{formulas} formulas have no cached value",
                                  "Excel computes them on open"))
    return r


_ISO_DATE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
_ISO_DT = re.compile(r"^\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}(?::\d{2})?$")


def _csv_value(text: str, decimal: str | None) -> tuple[Any, str | None]:
    s = text.strip()
    if s == "":
        return None, None
    if s.startswith("="):
        return s, None
    if _ISO_DATE.match(s):
        try:
            return datetime.strptime(s, "%Y-%m-%d"), "yyyy-mm-dd"
        except ValueError:
            return text, None
    if _ISO_DT.match(s):
        try:
            return datetime.fromisoformat(s.replace("T", " ")), "yyyy-mm-dd hh:mm"
        except ValueError:
            return text, None
    num = s
    if decimal == ",":
        if re.fullmatch(r"-?\d{1,3}(\.\d{3})*(,\d+)?|-?\d+(,\d+)?", num):
            num = num.replace(".", "").replace(",", ".")
        else:
            return text, None
    elif not re.fullmatch(r"-?\d+(\.\d+)?([eE][-+]?\d+)?", num):
        return text, None
    try:
        f = float(num)
    except ValueError:
        return text, None
    if re.fullmatch(r"-?\d+", num) and not (len(num.lstrip("-")) > 1 and num.lstrip("-").startswith("0")):
        return int(num), None
    if re.fullmatch(r"-?0\d+", num):
        return text, None  # leading zeros are identifiers (zip codes), keep the text
    return f, None


def create_from_csv(ctx: Context, csv_path: str, out: str, *, header: bool = False, decimal: str | None = None, force: bool = False) -> CommandResult:
    src = ctx.input_file(csv_path)
    raw = src.read_bytes()
    text = raw.decode("utf-8-sig") if raw[:3] == b"\xef\xbb\xbf" else _decode(raw)
    lines = text.splitlines()
    delimiter = None
    if lines and re.fullmatch(r"sep=.", lines[0].strip()):
        delimiter = lines[0].strip()[4]
        text = "\n".join(lines[1:])
    if delimiter is None:
        try:
            delimiter = csv.Sniffer().sniff(text[:4096], delimiters=",;\t|").delimiter
        except csv.Error:
            delimiter = ";" if decimal == "," else ","
    rows = list(csv.reader(io.StringIO(text), delimiter=delimiter))
    target = ctx.output_file(out, force=force)
    wb = Workbook()
    ws = wb.active
    ws.title = re.sub(r"[\[\]:*?/\\]", "_", src.stem)[:31] or "Sheet1"
    width = 0
    for r, row in enumerate(rows, start=1):
        width = max(width, len(row))
        for c, cell_text in enumerate(row, start=1):
            if header and r == 1:
                ws.cell(row=r, column=c, value=cell_text)
                continue
            value, fmt = _csv_value(cell_text, decimal)
            cell = ws.cell(row=r, column=c, value=value)
            if fmt:
                cell.number_format = fmt
    if header and rows:
        for c in _irange(1, width + 1):
            ws.cell(row=1, column=c).font = Font(b=True)
        ws.freeze_panes = "A2"
        ws.auto_filter.ref = _ref(1, 1, len(rows), max(width, 1))
    wb.save(target)
    return CommandResult(
        summary=f"created {target.name} from {src.name} ({len(rows)} rows)",
        output_path=str(target),
        detail={"sheet": ws.title, "rows": len(rows), "cols": width, "delimiter": delimiter},
    )


def _decode(raw: bytes) -> str:
    for enc in ("utf-8", "cp949", "cp1252"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("latin-1")


def create_from_json_file(ctx: Context, json_path: str, out: str, *, header: bool = False, force: bool = False) -> CommandResult:
    src = ctx.input_file(json_path)
    try:
        data = json.loads(src.read_text(encoding="utf-8-sig"))
    except json.JSONDecodeError as e:
        raise GenOfficeError(EXIT.usage, f"{src.name} is not valid JSON: {e}", reason="invalid_json")
    return create_from_rows(ctx, data, out, header=header, force=force)


# ---- csv / info ----


def _display(value: Any, fmt: str) -> str:
    if value is None:
        return ""
    if isinstance(value, bool):
        return "TRUE" if value else "FALSE"
    if isinstance(value, datetime):
        if value.time() == time(0) or not re.search(r"h", fmt, re.I):
            return value.date().isoformat()
        return value.strftime("%Y-%m-%d %H:%M")
    if isinstance(value, date):
        return value.isoformat()
    if isinstance(value, (int, float)):
        if "%" in fmt:
            m = re.search(r"0\.(0+)%", fmt)
            return f"{value * 100:.{len(m.group(1)) if m else 0}f}%"
        m = re.search(r"0\.(0+)", fmt)
        if "#,##0" in fmt:
            return f"{value:,.{len(m.group(1)) if m else 0}f}"
        if m:
            return f"{value:.{len(m.group(1))}f}"
        if isinstance(value, float) and value.is_integer():
            return str(int(value))
        return str(value)
    return str(value)


def to_csv(path: Path | str, sheet: str | None = None) -> str:
    wb = _load(Path(path), data_only=True)
    ws = _pick_sheet(wb, sheet)
    buf = io.StringIO()
    writer = csv.writer(buf, lineterminator="\r\n")
    for row in ws.iter_rows():
        writer.writerow([_display(c.value, c.number_format or "") for c in row])
    return buf.getvalue()


def info(path: Path | str) -> dict[str, Any]:
    p = Path(path)
    wb = _load(p)
    return {
        "format": "xlsx",
        "sheets": [
            {"name": ws.title, "dimensions": ws.calculate_dimension(), "rows": ws.max_row, "cols": ws.max_column, "state": ws.sheet_state}
            for ws in wb.worksheets
        ],
        "active": wb.active.title if wb.active else None,
        "defined_names": {n: d.attr_text for n, d in wb.defined_names.items()},
        "size_bytes": p.stat().st_size,
    }


# ---- merge ----


def _flatten(data: dict[str, Any], prefix: str = "") -> dict[str, Any]:
    out: dict[str, Any] = {}
    for k, v in data.items():
        key = f"{prefix}{k}"
        if isinstance(v, dict):
            out.update(_flatten(v, key + "."))
        else:
            out[key] = v
    return out


def merge(ctx: Context, file: str, data: dict[str, Any], out: str, *, force: bool = False, strict: bool = False) -> CommandResult:
    if not isinstance(data, dict):
        raise GenOfficeError(EXIT.usage, "data must be a JSON object", reason="invalid_argument")
    path = ctx.input_file(file)
    values = _flatten(data)
    wb = _load(path)
    used: set[str] = set()
    unresolved: list[dict[str, Any]] = []
    for ws in wb.worksheets:
        for row in ws.iter_rows():
            for cell in row:
                v = cell.value
                if not isinstance(v, str) or "{{" not in v:
                    continue
                whole = _PLACEHOLDER.fullmatch(v.strip())
                if whole and whole.group(1) in values:
                    val = values[whole.group(1)]
                    used.add(whole.group(1))
                    if isinstance(val, (int, float, bool)) or val is None:
                        cell.value = val
                    else:
                        cell.value = str(val)
                        cell.data_type = "s"
                    continue

                def sub(m: re.Match[str]) -> str:
                    key = m.group(1)
                    if key in values:
                        used.add(key)
                        return "" if values[key] is None else str(values[key])
                    unresolved.append({"placeholder": m.group(0), "key": key, "reason": "no_key",
                                       "location": {"sheet": ws.title, "cell": cell.coordinate}})
                    return m.group(0)

                new = _PLACEHOLDER.sub(sub, v)
                if new != v:
                    cell.value = new
                    cell.data_type = "s"  # substituted text stays text, even when it starts with "="
    if unresolved and strict:
        raise GenOfficeError(
            EXIT.usage,
            f"{len(unresolved)} placeholders have no value; nothing was written",
            {"unresolved_placeholders": unresolved, "used_keys": sorted(used)},
            reason="unresolved_placeholder",
            suggestion="add the keys to data and rerun",
        )
    target = ctx.output_file(out, force=force)
    wb.save(target)
    r = CommandResult(
        summary=f"merged {len(used)} keys into {target.name}",
        output_path=str(target),
        detail={"used_keys": sorted(used), "unused_keys": sorted(set(values) - used), "unresolved_placeholders": unresolved},
    )
    if unresolved:
        r.warnings.append(Warning("unresolved_placeholder", f"{len(unresolved)} placeholders left in place without a value",
                                  "see detail.unresolved_placeholders"))
    return r
