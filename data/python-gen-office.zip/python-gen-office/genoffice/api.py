"""The GenOffice command set as Python functions.

Each method is one `genoffice` command (or one tool of `genoffice mcp`, which mirrors the commands
one-to-one): same name, same parameters, same JSON envelope back. Nothing raises; a failure is an
envelope with `status: "error"`, an exit `code`, a stable `error` reason and a `suggestion`.

    go = GenOffice(root="/work")
    go.create_docx(markdown="# Q3\\n\\nRevenue grew 12%.", out="q3.docx")
    go.docs_read("q3.docx")
    go.docs_apply("q3.docx", ops=[{"op": "insert_content", "afterBlockIndex": 0, "html": "<p>Summary.</p>"}])
"""

from __future__ import annotations

import base64
import functools
import json
import os
import re
import shutil
import time
from pathlib import Path
from typing import Any, Callable

from .context import Context
from .ops import batch_mode
from .result import EXIT, CommandResult, GenOfficeError, Warning, to_json_error, to_json_ok
from .suggest import did_you_mean

GUIDES = Path(__file__).parent / "guides"
SKILL = Path(__file__).parent / "skills" / "genoffice" / "SKILL.md"

CONVERT_ROUTES = {
    ".pdf": ["docx"],
    ".csv": ["xlsx"],
    ".xls": ["xlsx"],
    ".xlsb": ["xlsx"],
    ".ods": ["xlsx"],
    ".md": ["docx", "html", "pdf"],
    ".markdown": ["docx", "html", "pdf"],
    ".docx": ["html", "md", "pdf"],
    ".html": ["docx", "pdf"],
    ".htm": ["docx", "pdf"],
    ".xlsx": ["csv", "pdf"],
    ".pptx": ["pdf"],
}

Envelope = dict[str, Any]


def command(name: str) -> Callable[[Callable[..., CommandResult]], Callable[..., Envelope]]:
    """Wrap a method so it returns the JSON envelope and logs to the audit file."""

    def wrap(fn: Callable[..., CommandResult]) -> Callable[..., Envelope]:
        @functools.wraps(fn)
        def run(self: "GenOffice", *args: Any, **kwargs: Any) -> Envelope:
            try:
                env = to_json_ok(name, fn(self, *args, **kwargs))
            except GenOfficeError as e:
                env = to_json_error(name, e)
            except Exception as e:  # an engine bug or a corrupt file: same shape as a conversion failure
                env = to_json_error(
                    name,
                    GenOfficeError(
                        EXIT.conversion,
                        f"{type(e).__name__}: {e}",
                        reason="conversion_failed",
                        suggestion="check the input file; retry once, then tell the user",
                    ),
                )
            self.ctx.audit(name, {**dict(enumerate(args)), **kwargs}, env["status"])
            return env

        run.command = name  # type: ignore[attr-defined]
        return run

    return wrap


def _engine(ext: str):
    if ext == ".docx":
        from .formats import docx

        return docx
    if ext == ".xlsx":
        from .formats import xlsx

        return xlsx
    if ext == ".pptx":
        from .formats import pptx

        return pptx
    return None


def _ext_error(path: Path, supported: list[str], what: str) -> GenOfficeError:
    return GenOfficeError(
        EXIT.usage,
        f"{what} does not take {path.suffix or 'a file without extension'}",
        {"supported": supported},
        reason="unsupported",
        suggestion=f"pass one of {', '.join(supported)}",
    )


class GenOffice:
    """All commands bound to one Context (root, allowed roots, providers, LibreOffice)."""

    def __init__(self, ctx: Context | None = None, **context_kwargs: Any) -> None:
        self.ctx = ctx or Context(**context_kwargs)

    # ---- helpers ----

    def _json_arg(self, value: Any, what: str) -> tuple[Any, Path | None]:
        """Inline JSON (list/dict or a JSON string) or the path of a JSON file; returns (value, file dir)."""
        if isinstance(value, (list, dict)):
            return value, None
        if isinstance(value, str):
            text = value.strip()
            if text[:1] in ("[", "{"):
                try:
                    return json.loads(text), None
                except json.JSONDecodeError as e:
                    raise GenOfficeError(
                        EXIT.usage,
                        f"{what} is not valid JSON: {e}",
                        reason="invalid_json",
                        suggestion=f"re-serialize {what}",
                    ) from e
            path = self.ctx.input_file(value, what=what)
            try:
                return json.loads(path.read_text(encoding="utf-8")), path.parent
            except json.JSONDecodeError as e:
                raise GenOfficeError(
                    EXIT.usage, f"{path.name} is not valid JSON: {e}", reason="invalid_json"
                ) from e
        raise GenOfficeError(EXIT.usage, f"missing {what}", reason="missing_argument")

    def _one_of(self, **given: Any) -> str:
        names = [k for k, v in given.items() if v is not None]
        if len(names) != 1:
            raise GenOfficeError(
                EXIT.usage,
                f"give exactly one of {', '.join(given)}",
                {"given": names},
                reason="invalid_argument" if names else "missing_argument",
            )
        return names[0]

    def _default_out(self, src: Path, ext: str) -> str:
        return str(src.with_suffix(f".{ext}"))

    # ---- inspect / convert ----

    @command("info")
    def info(self, file: str, password: str | None = None) -> CommandResult:
        path = self.ctx.input_file(file)
        ext = path.suffix.lower()
        if ext == ".pdf":
            from .formats import pdf

            detail = pdf.info(path, password)
            return CommandResult(f"{path.name}: pdf, {detail['pages']} pages", detail=detail)
        engine = _engine(ext)
        if engine is not None:
            detail = engine.info(path)
            return CommandResult(f"{path.name}: {ext[1:]}", detail=detail)
        if ext in (".md", ".markdown", ".html", ".htm", ".csv", ".txt"):
            text = path.read_text(encoding="utf-8", errors="replace")
            detail = {
                "format": ext[1:],
                "lines": text.count("\n") + 1,
                "chars": len(text),
                "size_bytes": path.stat().st_size,
            }
            if ext in (".md", ".markdown"):
                detail["headings"] = [
                    {"level": len(m.group(1)), "text": m.group(2).strip()}
                    for m in re.finditer(r"^(#{1,6})\s+(.+)$", text, re.M)
                ]
            return CommandResult(f"{path.name}: {ext[1:]}", detail=detail)
        raise _ext_error(path, [".docx", ".xlsx", ".pptx", ".pdf", ".md", ".html", ".csv"], "info")

    @command("convert")
    def convert(
        self,
        file: str,
        to: str,
        out: str | None = None,
        force: bool = False,
        password: str | None = None,
        sheet: str | None = None,
    ) -> CommandResult:
        src = self.ctx.input_file(file)
        ext = src.suffix.lower()
        fmt = to.lower().lstrip(".")
        routes = CONVERT_ROUTES.get(ext)
        if routes is None or fmt not in routes:
            supported = [f"{e[1:]}→{t}" for e, ts in CONVERT_ROUTES.items() for t in ts]
            guess = did_you_mean(fmt, routes or [])
            raise GenOfficeError(
                EXIT.usage,
                f"no route {ext[1:] or '?'}→{fmt}",
                {"supported": supported},
                reason="unsupported",
                suggestion=f'did you mean "{guess}"?' if guess else "pick a route from detail.supported",
            )
        dest = self.ctx.output_file(out or self._default_out(src, fmt), force=force)
        warnings: list[Warning] = []
        detail: dict[str, Any] = {"from": ext[1:], "to": fmt}
        if fmt == "pdf":
            from .formats import office

            office.to_pdf(self.ctx, src, dest)
        elif ext == ".pdf":
            from .formats import docx, pdf

            pages = pdf.page_texts(src, password)
            docx.from_text_pages(self.ctx, pages, str(dest), force=True)
            detail["pages"] = len(pages)
            if any(not p for p in pages):
                warnings.append(
                    Warning(
                        "no_text_layer",
                        f"{sum(1 for p in pages if not p)} page(s) have no text layer (scans); the port does not run OCR",
                    )
                )
        elif ext == ".csv":
            from .formats import xlsx

            xlsx.create_from_csv(self.ctx, str(src), str(dest), force=True)
        elif ext in (".xls", ".xlsb", ".ods"):
            from .formats import office

            produced = office.soffice_convert(self.ctx, src, "xlsx")
            shutil.move(str(produced), dest)
        elif ext in (".md", ".markdown"):
            text = src.read_text(encoding="utf-8")
            if fmt == "docx":
                from .formats import docx

                docx.create_from_markdown(self.ctx, text, str(dest), force=True, base_dir=src.parent)
            else:
                dest.write_text(markdown_to_html(text, title=src.stem), encoding="utf-8")
        elif ext == ".docx":
            from .formats import docx

            if fmt == "md":
                md, skipped = docx.to_markdown(src)
                dest.write_text(md, encoding="utf-8")
                if skipped.get("images"):
                    detail["skipped"] = skipped
                    warnings.append(
                        Warning("images_dropped", f"{skipped['images']} image(s) dropped (Markdown keeps text only)")
                    )
            else:
                dest.write_text(docx.to_html(src), encoding="utf-8")
        elif ext in (".html", ".htm"):
            from .formats import docx

            docx.create_from_html(
                self.ctx, src.read_text(encoding="utf-8"), str(dest), force=True, base_dir=src.parent
            )
        elif ext == ".xlsx":
            from .formats import xlsx

            text = xlsx.to_csv(src, sheet)
            text = text.replace("\r\n", "\n").replace("\n", "\r\n")
            dest.write_bytes(b"\xef\xbb\xbf" + text.encode("utf-8"))
            if sheet:
                detail["sheet"] = sheet
        return CommandResult(f"converted {src.name} to {dest.name}", str(dest), detail, warnings)

    # ---- create ----

    @command("create")
    def create_docx(
        self,
        markdown: str | None = None,
        html: str | None = None,
        from_: str | None = None,
        out: str | None = None,
        force: bool = False,
    ) -> CommandResult:
        from .formats import docx

        if not out:
            raise GenOfficeError(EXIT.usage, "out is required", reason="missing_argument")
        given = self._one_of(markdown=markdown, html=html, **{"from": from_})
        if given == "markdown":
            return docx.create_from_markdown(self.ctx, markdown, out, force=force, base_dir=self.ctx.base)
        if given == "html":
            return docx.create_from_html(self.ctx, html, out, force=force, base_dir=self.ctx.base)
        src = self.ctx.input_file(from_)
        text = src.read_text(encoding="utf-8")
        if src.suffix.lower() in (".md", ".markdown", ".txt"):
            return docx.create_from_markdown(self.ctx, text, out, force=force, base_dir=src.parent)
        if src.suffix.lower() in (".html", ".htm"):
            return docx.create_from_html(self.ctx, text, out, force=force, base_dir=src.parent)
        raise _ext_error(src, [".md", ".html"], "create_docx")

    @command("create")
    def create_xlsx(
        self,
        data: Any = None,
        from_: str | None = None,
        header: bool = False,
        decimal: str | None = None,
        out: str | None = None,
        force: bool = False,
    ) -> CommandResult:
        from .formats import xlsx

        if not out:
            raise GenOfficeError(EXIT.usage, "out is required", reason="missing_argument")
        given = self._one_of(data=data, **{"from": from_})
        if given == "data":
            rows, _ = self._json_arg(data, "data")
            return xlsx.create_from_rows(self.ctx, rows, out, header=header, force=force)
        src = self.ctx.input_file(from_)
        if src.suffix.lower() == ".csv":
            return xlsx.create_from_csv(self.ctx, str(src), out, header=header, decimal=decimal, force=force)
        if src.suffix.lower() == ".json":
            return xlsx.create_from_json_file(self.ctx, str(src), out, header=header, force=force)
        raise _ext_error(src, [".csv", ".json"], "create_xlsx")

    @command("create")
    def create_pdf(self, from_: str | None = None, out: str | None = None, force: bool = False) -> CommandResult:
        from .formats import office

        if not out:
            raise GenOfficeError(EXIT.usage, "out is required", reason="missing_argument")
        src = self.ctx.input_file(from_, what="from")
        dest = self.ctx.output_file(out, force=force)
        office.to_pdf(self.ctx, src, dest)
        return CommandResult(f"printed {src.name} to {dest.name}", str(dest))

    @command("create")
    def create_pptx(
        self,
        ops: Any = None,
        spec: Any = None,
        spec_dir: str | None = None,
        outline: str | None = None,
        out: str | None = None,
        force: bool = False,
        render: bool = False,
        audit: bool = False,
    ) -> CommandResult:
        from .formats import pptx

        if not out:
            raise GenOfficeError(EXIT.usage, "out is required", reason="missing_argument")
        given = self._one_of(ops=ops, spec=spec, spec_dir=spec_dir)
        if given == "ops":
            parsed, base = self._json_arg(ops, "ops")
            r = pptx.create_from_ops(self.ctx, parsed, out, force=force, ops_base=str(base) if base else None)
        elif given == "spec":
            if isinstance(spec, str) and spec.strip()[:1] not in ("[", "{"):
                r = pptx.create_from_spec(self.ctx, spec_path=spec, outline=outline, out=out, force=force)
            else:
                parsed, _ = self._json_arg(spec, "spec")
                r = pptx.create_from_spec(self.ctx, spec=parsed, outline=outline, out=out, force=force)
        else:
            r = pptx.create_from_spec(self.ctx, spec_path=spec_dir, outline=outline, out=out, force=force)
        return self._after_deck(r, render=render, audit=audit)

    def _after_deck(self, r: CommandResult, *, render: bool, audit: bool) -> CommandResult:
        from .formats import pptx

        detail = dict(r.detail or {})
        if audit and r.output_path:
            detail["audit"] = (pptx.audit(self.ctx, r.output_path).detail or {}).get("issues", [])
        if render and r.output_path:
            from .formats import office

            path = Path(r.output_path)
            try:
                previews = office.render(self.ctx, path, path.parent / f"{path.stem}-shots")
                detail["previews"] = previews["files"]
                detail["files"] = previews["files"]
            except GenOfficeError as e:
                r.warnings.append(Warning("render_unavailable", e.message, e.suggestion))
        r.detail = detail
        return r

    # ---- docs ----

    @command("docs read")
    def docs_read(
        self,
        file: str,
        range: str | None = None,
        html: bool = False,
        full: bool = False,
        max_chars: int | None = None,
        comments: bool = False,
        revisions: bool = False,
        styles: bool = False,
        header_footer: bool = False,
        sections: bool = False,
        fields: bool = False,
        notes: bool = False,
        properties: bool = False,
    ) -> CommandResult:
        from .formats import docx

        return docx.read(
            self.ctx,
            file,
            range=range,
            html=html,
            full=full,
            max_chars=max_chars,
            comments=comments,
            revisions=revisions,
            styles=styles,
            header_footer=header_footer,
            sections=sections,
            fields=fields,
            notes=notes,
            properties=properties,
        )

    @command("docs apply")
    def docs_apply(
        self,
        file: str,
        ops: Any,
        track: bool = False,
        author: str | None = None,
        dry_run: bool = False,
        best_effort: bool = False,
        stop_on_error: bool = False,
        out: str | None = None,
        force: bool = False,
    ) -> CommandResult:
        from .formats import docx

        parsed, base = self._json_arg(ops, "ops")
        return docx.apply(
            self.ctx,
            file,
            parsed,
            track=track,
            author=author,
            dry_run=dry_run,
            mode=batch_mode(best_effort, stop_on_error),
            out=out,
            force=force,
            ops_base=base,
        )

    @command("docs check")
    def docs_check(self, file: str) -> CommandResult:
        from .formats import docx

        return docx.check(self.ctx, file)

    # ---- sheets ----

    @command("sheet read")
    def sheet_read(
        self,
        file: str,
        sheet: str | None = None,
        range: str | None = None,
        cols: str | None = None,
        max_rows: int | None = None,
        where: str | None = None,
        stats: bool = False,
        formats: bool = False,
    ) -> CommandResult:
        from .formats import xlsx

        return xlsx.read(
            self.ctx, file, sheet=sheet, range=range, cols=cols, max_rows=max_rows, where=where, stats=stats, formats=formats
        )

    @command("sheet apply")
    def sheet_apply(
        self,
        file: str,
        sheet: str | None = None,
        cells: Any = None,
        ops: Any = None,
        dry_run: bool = False,
        best_effort: bool = False,
        stop_on_error: bool = False,
        out: str | None = None,
        force: bool = False,
    ) -> CommandResult:
        from .formats import xlsx

        given = self._one_of(cells=cells, ops=ops)
        parsed, base = self._json_arg(cells if given == "cells" else ops, given)
        return xlsx.apply(
            self.ctx,
            file,
            ops=parsed if given == "ops" else None,
            cells=parsed if given == "cells" else None,
            sheet=sheet,
            dry_run=dry_run,
            mode=batch_mode(best_effort, stop_on_error),
            out=out,
            force=force,
            ops_base=base,
        )

    @command("sheet check")
    def sheet_check(self, file: str) -> CommandResult:
        from .formats import xlsx

        return xlsx.check(self.ctx, file)

    # ---- slides ----

    @command("slides read")
    def slides_read(
        self,
        file: str,
        slide: int | None = None,
        full: bool = False,
        layouts: bool = False,
        max_chars: int | None = None,
        units: str | None = None,
    ) -> CommandResult:
        from .formats import pptx

        return pptx.read(self.ctx, file, slide=slide, full=full, layouts=layouts, max_chars=max_chars, units=units)

    @command("slides apply")
    def slides_apply(
        self,
        file: str,
        ops: Any,
        dry_run: bool = False,
        best_effort: bool = False,
        stop_on_error: bool = False,
        isolation: str | None = None,
        out: str | None = None,
        force: bool = False,
    ) -> CommandResult:
        from .formats import pptx

        parsed, base = self._json_arg(ops, "ops")
        return pptx.apply(
            self.ctx,
            file,
            parsed,
            dry_run=dry_run,
            mode=batch_mode(best_effort, stop_on_error, isolation),
            out=out,
            force=force,
            ops_base=base,
        )

    @command("slides audit")
    def slides_audit(self, file: str, slide: int | None = None) -> CommandResult:
        from .formats import pptx

        return pptx.audit(self.ctx, file, slide=slide)

    @command("slides render")
    def slides_render(self, file: str, out: str, slide: int | None = None, scale: float | None = None) -> CommandResult:
        from .formats import office

        src = self.ctx.input_file(file)
        if src.suffix.lower() != ".pptx":
            raise _ext_error(src, [".pptx"], "slides_render")
        detail = office.render(
            self.ctx, src, self.ctx.resolve(out), page=slide, scale=scale or 1.0, zero_based_slide=True
        )
        return CommandResult(f"rendered {len(detail['rendered'])} slide(s) of {src.name}", detail=detail)

    @command("slides check")
    def slides_check(self, file: str, outline: str | None = None, page: int | None = None) -> CommandResult:
        from .formats import pptx

        return pptx.check(self.ctx, file, outline=outline, page=page)

    @command("slides replace")
    def slides_replace(
        self,
        file: str,
        slide: int,
        spec: str,
        outline: str | None = None,
        out: str | None = None,
        force: bool = False,
    ) -> CommandResult:
        from .formats import pptx

        return pptx.replace(self.ctx, file, slide, spec, outline=outline, out=out, force=force)

    # ---- render / merge / pdf ----

    @command("render")
    def render(
        self,
        file: str,
        out: str,
        page: int | None = None,
        scale: float | None = None,
        el: str | None = None,
        pad: int | None = None,
        grid: bool = False,
        cols: int | None = None,
        tile: int | None = None,
    ) -> CommandResult:
        from .formats import office

        src = self.ctx.input_file(file)
        detail = office.render(
            self.ctx,
            src,
            self.ctx.resolve(out),
            page=page,
            scale=scale or 1.0,
            el=el,
            pad=16 if pad is None else pad,
            grid=grid,
            cols=cols or 4,
            tile=tile or 320,
        )
        return CommandResult(f"rendered {len(detail['rendered'])} page(s) of {src.name}", detail=detail)

    @command("merge")
    def merge(self, file: str, data: Any, out: str | None = None, force: bool = False, strict: bool = False) -> CommandResult:
        if not out:
            raise GenOfficeError(EXIT.usage, "out is required", reason="missing_argument")
        src = self.ctx.input_file(file)
        engine = _engine(src.suffix.lower())
        if engine is None:
            raise _ext_error(src, [".docx", ".pptx", ".xlsx"], "merge")
        values, _ = self._json_arg(data, "data")
        if not isinstance(values, dict):
            raise GenOfficeError(EXIT.usage, "data must be a JSON object", reason="invalid_argument")
        return engine.merge(self.ctx, str(src), values, out, force=force, strict=strict)

    @command("pdf read")
    def pdf_read(
        self,
        file: str,
        page: int | None = None,
        range: str | None = None,
        password: str | None = None,
        full: bool = False,
        max_chars: int | None = None,
    ) -> CommandResult:
        from .formats import pdf

        return pdf.read(self.ctx, file, page=page, range=range, password=password, full=full, max_chars=max_chars)

    # ---- guide / capabilities ----

    @command("guide")
    def guide(self, domain: str, topic: str | None = None, index: bool = False) -> CommandResult:
        registry = _registry(domain)
        if domain == "slides" and topic in ("design", "spec"):
            text = (GUIDES / f"slides_{topic}.md").read_text(encoding="utf-8")
            return CommandResult(text, detail={"domain": domain, "topic": topic})
        catalog = registry.catalog()
        if index:
            names = {g["name"]: g["ops"] for g in catalog["groups"]}
            lines = [f"{g}: {', '.join(ops)}" for g, ops in names.items()]
            return CommandResult("\n".join(lines), detail={"domain": domain, "fingerprint": catalog["fingerprint"], "groups": names})
        if not topic:
            return CommandResult(registry.guide_text(), detail=catalog)
        if topic in registry.groups:
            ops = [o for o in catalog["ops"] if o["group"] == topic]
            return CommandResult(
                registry.guide_text(topic),
                detail={"domain": domain, "fingerprint": catalog["fingerprint"], "group": topic, "ops": ops},
            )
        entry = next((o for o in catalog["ops"] if o["op"] == topic), None)
        if entry is None:
            names = list(registry.groups) + [o["op"] for o in catalog["ops"]]
            guess = did_you_mean(topic, names)
            raise GenOfficeError(
                EXIT.usage,
                f'no group or op "{topic}" in the {domain} guide',
                {"groups": list(registry.groups)},
                reason="invalid_argument",
                suggestion=f'did you mean "{guess}"?' if guess else f'guide("{domain}") lists them',
            )
        d = registry.ops[topic]
        lines = [f"{d.name} {d.signature}"] + ([f"  — {d.note}"] if d.note else [])
        if not d.available:
            lines = [f"{d.name} — not available in the Python port: {d.reason}"]
        return CommandResult("\n".join(lines), detail={"domain": domain, "op": entry})

    @command("capabilities")
    def capabilities(self) -> CommandResult:
        try:
            import pypdfium2  # noqa: F401  # type: ignore[import-not-found]

            rasterizer = True
        except ImportError:
            rasterizer = False
        detail = {
            "search": self.ctx.search is not None,
            "image_search": self.ctx.search is not None and self.ctx.extra.get("image_search", True),
            "image_generation": self.ctx.image is not None,
            "media": self.ctx.media is not None,
            "app": {
                "soffice": self.ctx.soffice,
                "pdf_and_render": bool(self.ctx.soffice) and rasterizer,
                "rasterizer": rasterizer,
            },
            "local": ["info", "convert (no →pdf)", "create docx/xlsx/pptx", "docs/sheet/slides read/apply/check", "merge", "pdf read", "guide"],
        }
        on = [k for k in ("search", "image_search", "image_generation", "media") if detail[k]]
        return CommandResult(f"configured: {', '.join(on) if on else 'no cloud features'}", detail=detail)

    # ---- cloud (providers the host plugs into the Context) ----

    @command("search")
    def search(self, query: str, images: bool = False, max: int | None = None) -> CommandResult:
        if self.ctx.search is None:
            raise _not_configured("search")
        limit = max or (6 if images else 8)
        results = list(self.ctx.search(query, images=images, max=limit))[:limit]
        key = "images" if images else "results"
        return CommandResult(f"{len(results)} {key} for {query!r}", detail={key: results})

    @command("image")
    def image(
        self,
        prompt: str,
        out: str | None = None,
        aspect: str | None = None,
        size: str | None = None,
        ref: str | None = None,
        model: str | None = None,
        force: bool = False,
    ) -> CommandResult:
        if self.ctx.image is None:
            raise _not_configured("image")
        if aspect and not re.fullmatch(r"\d{1,2}:\d{1,2}", aspect):
            raise GenOfficeError(EXIT.usage, f"aspect must look like 16:9: {aspect}", reason="invalid_argument")
        if size and not re.fullmatch(r"\d{2,5}x\d{2,5}", size):
            raise GenOfficeError(EXIT.usage, f"size must look like 1024x1024: {size}", reason="invalid_argument")
        refs = [str(self.ctx.input_file(r.strip(), what="ref")) for r in ref.split(",")] if ref else []
        produced = self.ctx.image(prompt, aspect=aspect, size=size, refs=refs, model=model)
        data, mime = produced if isinstance(produced, tuple) else (produced, None)
        if isinstance(data, str):
            data = base64.b64decode(data.split(",", 1)[-1])
        mime = mime or _sniff_mime(data)
        real_ext = {"image/png": ".png", "image/jpeg": ".jpg", "image/webp": ".webp", "image/gif": ".gif"}.get(mime, ".png")
        wanted = Path(out or f"image-{int(time.time())}{real_ext}")
        warnings = []
        if wanted.suffix.lower() not in (real_ext, ".jpeg" if real_ext == ".jpg" else real_ext):
            warnings.append(
                Warning("output_renamed", f"the provider returned {mime}; saved as {wanted.with_suffix(real_ext).name}")
            )
            wanted = wanted.with_suffix(real_ext)
        dest = self.ctx.output_file(wanted, force=force)
        dest.write_bytes(data)
        detail = {"mime": mime}
        if warnings:
            detail["note"] = warnings[0].message
        return CommandResult(f"saved {dest.name}", str(dest), detail, warnings)

    @command("media")
    def media(self, source: str, ask: str | None = None) -> CommandResult:
        if self.ctx.media is None:
            raise _not_configured("media")
        target = source if re.match(r"^https?://", source) else str(self.ctx.input_file(source, what="source"))
        text = str(self.ctx.media(target, ask=ask))
        return CommandResult(text, detail={"text": text, "source": target})

    # ---- staged deck flow (the deck folder is the state) ----

    @command("deck")
    def deck_start(self, dir: str, style: str, outline: Any) -> CommandResult:
        deck = self.ctx.resolve(dir)
        (deck / "pages").mkdir(parents=True, exist_ok=True)
        plan, _ = self._json_arg(outline, "outline")
        (deck / "style.md").write_text(str(style), encoding="utf-8")
        (deck / "outline.json").write_text(json.dumps(plan, ensure_ascii=False, indent=2), encoding="utf-8")
        check = self.slides_check(str(deck / "outline.json"))
        if check["status"] == "error":
            raise _from_envelope(check)
        design, spec, caps = self.guide("slides", "design"), self.guide("slides", "spec"), self.capabilities()
        titles = _outline_titles(deck)
        detail = {
            **(check.get("detail") or {}),
            "deck": str(deck),
            "pages": [{"index": i, "title": t, "file": str(_page_file(deck, i))} for i, t in enumerate(titles)],
            "guides": {"design": design.get("summary"), "spec": spec.get("summary")},
            "capabilities": caps.get("detail"),
            "next": f'write page 0 ("{titles[0] if titles else ""}") with deck_page; one page per call, in order, '
            "re-reading style.md's palette and the page's outline entry each time",
        }
        return CommandResult(check["summary"], detail=detail, warnings=_warnings(check))

    @command("deck")
    def deck_page(self, dir: str, index: int, page: Any) -> CommandResult:
        deck = self._deck(dir)
        titles = _outline_titles(deck)
        _page_in_range(index, len(titles))
        missing = _missing_pages(deck, len(titles))
        if missing and index > missing[0]:
            raise GenOfficeError(
                EXIT.usage,
                f"page {index} comes after missing page {missing[0]}; pages are written in outline order",
                {"missing_pages": missing},
                reason="invalid_argument",
                suggestion=f'write page {missing[0]} ("{titles[missing[0]]}") first',
            )
        spec, _ = self._json_arg(page, "page")
        check = self._check_pending(deck, index, spec)
        missing = _missing_pages(deck, len(titles))
        progress = {"deck": str(deck), "page": index, "file": str(_page_file(deck, index)), "missing_pages": missing}
        if check["status"] == "error":
            err = _from_envelope(check)
            err.detail = {**(err.detail or {}), **progress, "kept": False}
            err.suggestion = err.suggestion or "fix the page and call deck_page again with the same index"
            raise err
        then = (
            f'write page {missing[0]} ("{titles[missing[0]]}") with deck_page'
            if missing
            else "every page has a file: build with deck_build"
        )
        return CommandResult(check["summary"], detail={**(check.get("detail") or {}), **progress, "next": then}, warnings=_warnings(check))

    @command("deck")
    def deck_build(self, dir: str, out: str | None = None, render: bool = False) -> CommandResult:
        from .formats import pptx

        deck = self._deck(dir)
        missing = _missing_pages(deck, len(_outline_titles(deck)))
        if missing:
            raise GenOfficeError(
                EXIT.usage,
                f"pages {', '.join(map(str, missing))} have no file yet",
                {"missing_pages": missing},
                reason="missing_argument",
                suggestion="write them with deck_page before building",
            )
        target = out or str(deck / "deck.pptx")
        r = pptx.create_from_spec(
            self.ctx, spec_path=str(deck / "pages"), outline=str(deck / "outline.json"), out=target, force=out is None
        )
        r = self._after_deck(r, render=render, audit=False)
        r.detail = {
            **(r.detail or {}),
            "deck": str(deck),
            "next": f"slides_render {r.output_path} to look at every page, slides_audit for geometry; "
            "deck_replace rebuilds one page from a corrected spec",
        }
        return r

    @command("deck")
    def deck_replace(self, dir: str, index: int, page: Any, pptx: str | None = None) -> CommandResult:
        from .formats import pptx as engine

        deck = self._deck(dir)
        _page_in_range(index, len(_outline_titles(deck)))
        built = self.ctx.resolve(pptx) if pptx else deck / "deck.pptx"
        if not built.exists():
            raise GenOfficeError(EXIT.file, f"no built deck at {built}", reason="file_not_found", suggestion="run deck_build first")
        spec, _ = self._json_arg(page, "page")
        check = self._check_pending(deck, index, spec)
        if check["status"] == "error":
            err = _from_envelope(check)
            err.detail = {**(err.detail or {}), "kept": False}
            raise err
        r = engine.replace(self.ctx, str(built), index, str(_page_file(deck, index)), outline=str(deck / "outline.json"))
        r.detail = {**(r.detail or {}), "check": check.get("detail"), "next": f"slides_render {built} with slide {index} to confirm"}
        return r

    def _deck(self, dir: str) -> Path:
        deck = self.ctx.resolve(dir)
        if not (deck / "outline.json").exists():
            raise GenOfficeError(
                EXIT.usage,
                f"{deck} has no outline.json",
                reason="missing_argument",
                suggestion="call deck_start with the style sheet and the outline first",
            )
        return deck

    def _check_pending(self, deck: Path, index: int, spec: Any) -> Envelope:
        """Check the page from a `.pending` file beside the real one; keep it only when it passes."""
        final = _page_file(deck, index)
        pending = final.with_name(final.name + ".pending")
        pending.write_text(json.dumps(spec, ensure_ascii=False, indent=2), encoding="utf-8")
        try:
            check = self.slides_check(str(pending), page=index)
            if check["status"] != "error":
                os.replace(pending, final)
            return check
        finally:
            pending.unlink(missing_ok=True)

    # ---- not ported ----

    @command("open")
    def open(self, file: str, **_: Any) -> CommandResult:
        raise GenOfficeError(
            EXIT.app,
            "open needs the GenOffice desktop editor, which the Python port does not have",
            reason="app_unavailable",
            suggestion="give the user the output path instead",
        )

    @command("selection")
    def selection(self, file: str) -> CommandResult:
        raise GenOfficeError(
            EXIT.app,
            "selection needs the GenOffice desktop editor, which the Python port does not have",
            reason="file_not_open_in_gui",
            suggestion="ask the user to name the slide / block / range instead",
        )

    @command("skill")
    def skill_path(self) -> CommandResult:
        return CommandResult(str(SKILL), str(SKILL), detail={"path": str(SKILL)})


# ---- module helpers ----


def _registry(domain: str):
    if domain == "docs":
        from .formats import docx

        return docx.REGISTRY
    if domain == "sheets":
        from .formats import xlsx

        return xlsx.REGISTRY
    if domain == "slides":
        from .formats import pptx

        return pptx.REGISTRY
    guess = did_you_mean(domain, ["slides", "docs", "sheets"])
    raise GenOfficeError(
        EXIT.usage,
        f"unknown guide domain {domain!r}",
        {"domains": ["slides", "docs", "sheets"]},
        reason="invalid_argument",
        suggestion=f'did you mean "{guess}"?' if guess else "use slides, docs or sheets",
    )


def _not_configured(feature: str) -> GenOfficeError:
    return GenOfficeError(
        EXIT.app,
        f"{feature} is not configured",
        {"configured": False},
        reason="app_unavailable",
        suggestion=f"pass a {feature} provider to Context(...); plan without it otherwise",
    )


def _from_envelope(env: Envelope) -> GenOfficeError:
    return GenOfficeError(
        int(env.get("code", EXIT.usage)),
        env.get("message", "failed"),
        env.get("detail"),
        reason=env.get("error"),
        suggestion=env.get("suggestion"),
    )


def _warnings(env: Envelope) -> list[Warning]:
    return [Warning(w["code"], w["message"], w.get("suggestion")) for w in env.get("warnings", [])]


def _page_file(deck: Path, index: int) -> Path:
    return deck / "pages" / f"{index + 1:02d}.json"


def _outline_titles(deck: Path) -> list[str]:
    try:
        raw = json.loads((deck / "outline.json").read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return []
    return [p.get("title", "") if isinstance(p, dict) else "" for p in raw.get("pages", [])]


def _missing_pages(deck: Path, count: int) -> list[int]:
    return [i for i in range(count) if not _page_file(deck, i).exists()]


def _page_in_range(index: int, count: int) -> None:
    if 0 <= index < count:
        return
    raise GenOfficeError(
        EXIT.usage,
        f"the outline has {count} pages; index {index} has no entry",
        {"valid_range": [0, count - 1]},
        reason="out_of_range",
    )


def _sniff_mime(data: bytes) -> str:
    if data[:8] == b"\x89PNG\r\n\x1a\n":
        return "image/png"
    if data[:3] == b"\xff\xd8\xff":
        return "image/jpeg"
    if data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        return "image/webp"
    if data[:4] == b"GIF8":
        return "image/gif"
    return "application/octet-stream"


def markdown_to_html(text: str, *, title: str = "") -> str:
    from markdown_it import MarkdownIt

    body = MarkdownIt("gfm-like" if _has_linkify() else "commonmark").enable("table").render(text)
    return (
        f'<!doctype html>\n<html><head><meta charset="utf-8"><title>{title}</title></head>\n'
        f"<body>\n{body}</body></html>\n"
    )


def _has_linkify() -> bool:
    try:
        import linkify_it  # noqa: F401  # type: ignore[import-not-found]

        return True
    except ImportError:
        return False


_default: GenOffice | None = None


def default() -> GenOffice:
    """A process-wide instance on the cwd and the environment (what the CLI uses)."""
    global _default
    if _default is None:
        _default = GenOffice()
    return _default
