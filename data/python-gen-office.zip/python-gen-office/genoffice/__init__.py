"""GenOffice in native Python: create, convert, read and edit docx / xlsx / pptx / pdf.

A port of the `genoffice` CLI (genspark-ai/genoffice, Apache-2.0) as plain functions with the same
command names, parameters, op vocabulary and JSON envelope, for agents that call tools in-process.

    from genoffice import GenOffice
    go = GenOffice(root="/work")
    go.sheet_read("sales.xlsx", range="A1:D20")

Agent hosts: `genoffice.tools` (framework-free specs), `genoffice.integrations.deepagents`.
"""

from __future__ import annotations

__version__ = "0.1.0"

from .api import GenOffice, default  # noqa: E402
from .context import Context  # noqa: E402
from .result import EXIT, CommandResult, GenOfficeError  # noqa: E402
from .tools import TOOLS, call  # noqa: E402

__all__ = ["GenOffice", "Context", "TOOLS", "call", "default", "EXIT", "CommandResult", "GenOfficeError", "__version__"]
