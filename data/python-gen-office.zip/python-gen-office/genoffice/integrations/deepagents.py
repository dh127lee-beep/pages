"""genoffice as built-in tools of a deepagents agent.

Three ways in, from smallest to largest:

    tools = genoffice_tools(root="/work")                 # LangChain tools, add them anywhere
    agent = create_deep_agent(model, middleware=[GenOfficeMiddleware(root="/work")])
    agent = create_genoffice_agent(model, root="/work")   # the two above, plus the skill

The middleware adds the tools and a short system prompt (the skill's workflow, pitfalls and QA
gate); the full SKILL.md is in `SKILLS_DIR` for deepagents' own `skills=` loader, which discloses it
on demand instead.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Awaitable, Callable, Iterable

from langchain.agents.middleware import AgentMiddleware
from langchain_core.tools import BaseTool, StructuredTool

from ..api import GenOffice
from ..tools import TOOLS, ToolSpec, call

SKILLS_DIR = str(Path(__file__).resolve().parent.parent / "skills")

GENOFFICE_SYSTEM_PROMPT = """## genoffice tools (Office documents)

You have the genoffice tools: create, convert, read and edit docx / xlsx / pptx / pdf on disk. Each tool returns one JSON envelope: `status` ok | partial | error; on error branch on `error` and do what `suggestion` says (`detail` has the facts: `failures[]` with `index`, `op`, `reason`, `available`, `valid_range`, `usage`). A batch apply is atomic: fix the one rejected op and resend the WHOLE batch.

Workflow: read first (`docs_read` / `sheet_read` / `slides_read` / `info`) → `guide(domain, op?)` for exact op fields (never guess them) → `*_apply` → check (`docs_check` / `sheet_check` / `slides_audit`, findings are in `detail.issues`, success is not "clean") → `render` when `capabilities` says it is available → report the output path and anything left as is.

Rules:
- Indexes: slide targets and `slides_*` `slide` are 0-based; `render(page)` is 1-based; docx block indexes are 0-based and live inside a batch (later ops see earlier inserts). Re-read before a second batch: created elements get new `e_*` ids.
- pptx ops are EMU (ints or "2.54cm"/"1in"/"12pt"/"96px"); deck specs are px on 1280x720. Never mix.
- `create_*` / `convert` never overwrite: `force=true` only when the user asked to replace. Apply edits in place unless `out`.
- Formulas written by the tools have no cached value until Excel opens the file (`formulas_not_cached`): mention it.
- A presentation of more than ~5 slides goes through the staged flow: `guide("slides","design")`, `guide("slides","spec")`, `deck_start` → `deck_page` (one page per call, in order) → `deck_build` → `slides_audit` / `slides_render` → `deck_replace`. Short decks with concrete content: one `create_pptx(spec=…, audit=true)`.
- The user's Office files are source material: read them with `convert(to="md"/"csv")` or `*_read(full=true)`, never as raw zip.
- Photos only from `search(images=true)`, `image`, or the user's files, and only when `capabilities` says they are configured; never a grey box in place of a photo. Say when a figure is illustrative."""


def genoffice_tools(
    go: GenOffice | None = None,
    *,
    include: Iterable[str] | None = None,
    exclude: Iterable[str] | None = None,
    **context: Any,
) -> list[BaseTool]:
    """One LangChain tool per genoffice tool. context kwargs build the Context (root, allowed_roots,
    search, image, media, soffice) when no GenOffice instance is given."""
    go = go or GenOffice(**context)
    wanted = set(include) if include is not None else None
    skipped = set(exclude or ())
    return [_tool(go, spec) for spec in TOOLS if (wanted is None or spec.name in wanted) and spec.name not in skipped]


def _tool(go: GenOffice, spec: ToolSpec) -> BaseTool:
    def run(**kwargs: Any) -> str:
        return json.dumps(call(go, spec.name, kwargs), ensure_ascii=False, default=str)

    return StructuredTool.from_function(
        func=run,
        name=spec.name,
        description=spec.description,
        args_schema=spec.parameters,
        metadata={"genoffice": True, "read_only": spec.read_only, "open_world": spec.open_world},
    )


class GenOfficeMiddleware(AgentMiddleware):
    """Registers the genoffice tools and appends the genoffice system prompt to every model call."""

    def __init__(
        self,
        go: GenOffice | None = None,
        *,
        include: Iterable[str] | None = None,
        exclude: Iterable[str] | None = None,
        system_prompt: str | None = GENOFFICE_SYSTEM_PROMPT,
        **context: Any,
    ) -> None:
        super().__init__()
        self.go = go or GenOffice(**context)
        self.tools = genoffice_tools(self.go, include=include, exclude=exclude)
        self.system_prompt = system_prompt

    def _with_prompt(self, request: Any) -> Any:
        if not self.system_prompt:
            return request
        from deepagents.middleware._utils import append_to_system_message

        return request.override(system_message=append_to_system_message(request.system_message, self.system_prompt))

    def wrap_model_call(self, request: Any, handler: Callable[[Any], Any]) -> Any:
        return handler(self._with_prompt(request))

    async def awrap_model_call(self, request: Any, handler: Callable[[Any], Awaitable[Any]]) -> Any:
        return await handler(self._with_prompt(request))


def create_genoffice_agent(
    model: Any = None,
    *,
    root: str | None = None,
    tools: Iterable[Any] = (),
    middleware: Iterable[Any] = (),
    skills: list[str] | None = None,
    with_skill: bool = False,
    genoffice: GenOffice | None = None,
    context: dict[str, Any] | None = None,
    **kwargs: Any,
):
    """create_deep_agent with genoffice built in.

    with_skill=True also loads SKILL.md through deepagents' skills loader; it reads skill files
    through the agent's backend, so pass a FilesystemBackend that can see SKILLS_DIR.
    """
    from deepagents import create_deep_agent

    go = genoffice or GenOffice(root=root, **(context or {}))
    sources = list(skills or [])
    if with_skill:
        sources.append(SKILLS_DIR)
    return create_deep_agent(
        model,
        tools=list(tools),
        middleware=[GenOfficeMiddleware(go), *middleware],
        skills=sources or None,
        **kwargs,
    )
