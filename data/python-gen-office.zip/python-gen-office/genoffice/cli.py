"""`genoffice` on the command line, with the original command shape:

    genoffice docs read report.docx --full --json
    echo '[{"op":"format_range","range":"A1:C1","format":{"bold":true}}]' | genoffice sheet apply sales.xlsx --ops - --json
    genoffice create --type pptx --spec deck/pages --outline deck/outline.json --out deck/deck.pptx --json

Every command is a thin layer over the same GenOffice method the tools call; `--json` prints the
envelope, exit codes are 0 ok, 1 usage / rejected ops, 2 file, 3 conversion, 4 app not available.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

from . import __version__
from .api import GenOffice
from .result import EXIT, GenOfficeError, exit_code, format_human, to_json_error
from .suggest import did_you_mean
from .tools import BY_NAME, call

# command path -> (tool, positionals)
ROUTES: dict[tuple[str, ...], tuple[str, list[str]]] = {
    ("info",): ("info", ["file"]),
    ("convert",): ("convert", ["file"]),
    ("merge",): ("merge", ["file"]),
    ("render",): ("render", ["file"]),
    ("guide",): ("guide", ["domain", "topic"]),
    ("capabilities",): ("capabilities", []),
    ("search",): ("search", ["query"]),
    ("image",): ("image", ["prompt"]),
    ("media",): ("media", ["source"]),
    ("docs", "read"): ("docs_read", ["file"]),
    ("docs", "apply"): ("docs_apply", ["file"]),
    ("docs", "check"): ("docs_check", ["file"]),
    ("sheet", "read"): ("sheet_read", ["file"]),
    ("sheet", "apply"): ("sheet_apply", ["file"]),
    ("sheet", "check"): ("sheet_check", ["file"]),
    ("slides", "read"): ("slides_read", ["file"]),
    ("slides", "apply"): ("slides_apply", ["file"]),
    ("slides", "audit"): ("slides_audit", ["file"]),
    ("slides", "render"): ("slides_render", ["file"]),
    ("slides", "check"): ("slides_check", ["file"]),
    ("slides", "replace"): ("slides_replace", ["file"]),
    ("pdf", "read"): ("pdf_read", ["file"]),
}
JSON_OPTIONS = {"ops", "cells", "data", "spec"}
CREATE_TYPES = ("docx", "xlsx", "pptx", "pdf")


def main(argv: list[str] | None = None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    as_json = "--json" in argv
    argv = [a for a in argv if a != "--json"]
    if not argv or argv[0] in ("-h", "--help", "help"):
        print(_usage())
        return EXIT.ok
    if argv[0] in ("-v", "--version"):
        print(__version__)
        return EXIT.ok
    try:
        tool, args = _parse(argv)
        if tool == "skill_path":
            env = GenOffice().skill_path()
        else:
            env = call(GenOffice(), tool, args)
    except GenOfficeError as e:
        env = to_json_error(" ".join(argv[:2]), e)
    if as_json:
        print(json.dumps(env, ensure_ascii=False, indent=2, default=str))
    else:
        print(format_human(env), file=sys.stderr if env["status"] == "error" else sys.stdout)
    return exit_code(env)


def _parse(argv: list[str]) -> tuple[str, dict[str, Any]]:
    if argv[0] == "create":
        return _parse_create(argv[1:])
    if argv[:2] == ["skill", "path"]:
        return "skill_path", {}
    route = ROUTES.get(tuple(argv[:2])) or ROUTES.get(tuple(argv[:1]))
    if route is None:
        names = sorted({" ".join(k) for k in ROUTES} | {"create", "skill path"})
        guess = did_you_mean(" ".join(argv[:2]), names) or did_you_mean(argv[0], names)
        raise GenOfficeError(
            EXIT.usage,
            f"unknown command: {' '.join(argv[:2])}",
            {"commands": names},
            reason="unknown_command",
            suggestion=f'did you mean "{guess}"?' if guess else "genoffice --help lists the commands",
        )
    tool, positionals = route
    rest = argv[len(next(k for k in ROUTES if ROUTES[k] == route)) :]
    return tool, _options(tool, positionals, rest)


def _parse_create(rest: list[str]) -> tuple[str, dict[str, Any]]:
    kind = None
    if "--type" in rest:
        i = rest.index("--type")
        kind = rest[i + 1] if i + 1 < len(rest) else None
        rest = rest[:i] + rest[i + 2 :]
    if kind not in CREATE_TYPES:
        raise GenOfficeError(
            EXIT.usage,
            "create needs --type docx|xlsx|pptx|pdf",
            {"supported": list(CREATE_TYPES)},
            reason="missing_argument" if kind is None else "invalid_argument",
        )
    tool = f"create_{kind}"
    args = _options(tool, [], rest, extra={"spec": "spec"} if kind == "pptx" else None)
    if kind == "pptx" and isinstance(args.get("spec"), str) and Path(args["spec"]).is_dir():
        args["spec_dir"] = args.pop("spec")
    return tool, args


def _options(tool: str, positionals: list[str], rest: list[str], extra: dict[str, str] | None = None) -> dict[str, Any]:
    spec = BY_NAME[tool]
    parser = argparse.ArgumentParser(prog=f"genoffice {tool}", add_help=False, allow_abbrev=False)
    for name in positionals:
        parser.add_argument(name, nargs="?" if name not in spec.required else None)
    for name, schema in spec.properties.items():
        if name in positionals:
            continue
        flag = "--" + name.replace("_", "-")
        kind = schema.get("type")
        if kind == "boolean":
            parser.add_argument(flag, dest=name, action="store_true", default=None)
        elif kind == "integer":
            parser.add_argument(flag, dest=name, type=int)
        elif kind == "number":
            parser.add_argument(flag, dest=name, type=float)
        else:
            parser.add_argument(flag, dest=name)
    if tool in ("docs_apply", "sheet_apply", "slides_apply"):
        parser.add_argument("--isolation", dest="isolation")
    try:
        ns, unknown = parser.parse_known_args(rest)
    except SystemExit as e:
        raise GenOfficeError(EXIT.usage, f"bad arguments for {tool}", reason="invalid_argument") from e
    if unknown:
        options = ["--" + k.replace("_", "-") for k in spec.properties]
        guess = did_you_mean(unknown[0], options)
        raise GenOfficeError(
            EXIT.usage,
            f"unknown option {unknown[0]}",
            {"options": options},
            reason="unknown_option",
            suggestion=f'did you mean "{guess}"?' if guess else None,
        )
    args = {k: v for k, v in vars(ns).items() if v is not None}
    isolation = args.pop("isolation", None)
    if isolation == "per_op":
        args["best_effort"] = True
    for key in JSON_OPTIONS & args.keys():
        if args[key] == "-":
            args[key] = sys.stdin.read()
    if tool == "merge" and "data" in args:
        args["data"] = _json_or_path(args["data"])
    return args


def _json_or_path(value: str) -> Any:
    """--data takes inline JSON or a file; the tool schema wants the object."""
    text = value.strip()
    if text[:1] in ("{", "["):
        return text
    return Path(value).read_text(encoding="utf-8")


def _usage() -> str:
    lines = [f"genoffice {__version__} (Python port) — create, convert, read and edit Office documents", "", "Commands:"]
    for path, (tool, pos) in ROUTES.items():
        lines.append(f"  genoffice {' '.join(path)} {' '.join(f'<{p}>' for p in pos)}".rstrip())
    lines += [
        "  genoffice create --type docx|xlsx|pptx|pdf ...",
        "  genoffice skill path",
        "",
        "Add --json for the machine-readable envelope. Options mirror the tool parameters (snake_case → --kebab-case).",
    ]
    return "\n".join(lines)


if __name__ == "__main__":
    raise SystemExit(main())
