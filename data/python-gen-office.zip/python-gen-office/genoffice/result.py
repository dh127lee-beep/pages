"""Result envelope, exit codes and errors — the same contract as the GenOffice CLI's `--json`.

Every public function returns one dict:

    {"status": "ok" | "partial", "command", "summary", "output_path"?, "warnings"?, "detail"?}
    {"status": "error", "command", "code", "error", "message", "suggestion"?, "detail"?}

A program branches on `error` (the machine-readable reason) and reads facts from `detail`;
`message` is for people.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal


class EXIT:
    ok = 0
    usage = 1
    file = 2
    conversion = 3
    app = 4


ErrorReason = Literal[
    "unknown_command",
    "unknown_option",
    "missing_argument",
    "invalid_argument",
    "invalid_json",
    "unsupported",
    "unknown_op",
    "op_rejected",
    "unresolved_placeholder",
    "target_not_found",
    "out_of_range",
    "sheet_not_found",
    "file_not_found",
    "resource_limit",
    "output_exists",
    "file_open_in_gui",
    "file_not_open_in_gui",
    "outside_allowed_roots",
    "conversion_failed",
    "app_unavailable",
    "app_crashed",
    "invalid_usage",
]

_DEFAULT_REASON = {
    EXIT.ok: "invalid_usage",
    EXIT.usage: "invalid_usage",
    EXIT.file: "file_not_found",
    EXIT.conversion: "conversion_failed",
    EXIT.app: "app_unavailable",
}


class GenOfficeError(Exception):
    """A failure with an exit code, a stable reason and a one-sentence next step."""

    def __init__(
        self,
        code: int,
        message: str,
        detail: dict[str, Any] | None = None,
        *,
        reason: str | None = None,
        suggestion: str | None = None,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.detail = detail
        self.reason = reason or _DEFAULT_REASON.get(code, "invalid_usage")
        self.suggestion = suggestion


@dataclass
class Warning:
    code: str
    message: str
    suggestion: str | None = None

    def to_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {"code": self.code, "message": self.message}
        if self.suggestion:
            out["suggestion"] = self.suggestion
        return out


@dataclass
class CommandResult:
    summary: str
    output_path: str | None = None
    detail: dict[str, Any] | None = None
    warnings: list[Warning] = field(default_factory=list)
    # `partial`: the file was written but a batch lost ops (see detail.batch / detail.failures)
    status: Literal["ok", "partial"] = "ok"


def to_json_ok(command: str, r: CommandResult) -> dict[str, Any]:
    out: dict[str, Any] = {"status": r.status, "command": command, "summary": r.summary}
    if r.output_path:
        out["output_path"] = r.output_path
    if r.warnings:
        out["warnings"] = [w.to_dict() for w in r.warnings]
    if r.detail is not None:
        out["detail"] = r.detail
    return out


def to_json_error(command: str | None, err: GenOfficeError) -> dict[str, Any]:
    out: dict[str, Any] = {
        "status": "error",
        "command": command,
        "code": err.code,
        "error": err.reason,
        "message": err.message,
    }
    if err.suggestion:
        out["suggestion"] = err.suggestion
    if err.detail is not None:
        out["detail"] = err.detail
    return out


def exit_code(envelope: dict[str, Any]) -> int:
    return int(envelope.get("code", EXIT.ok)) if envelope.get("status") == "error" else EXIT.ok


def format_human(envelope: dict[str, Any]) -> str:
    """The non-`--json` rendering of an envelope, as the CLI prints it."""
    if envelope.get("status") == "error":
        lines = [f"genoffice: {envelope['message']}"]
        if envelope.get("suggestion"):
            lines.append(f"  hint: {envelope['suggestion']}")
        detail = dict(envelope.get("detail") or {})
        batch = detail.pop("batch", None)
        if batch:
            lines.append(_batch_line(batch))
        if detail:
            import json

            lines.append(f"  {json.dumps(detail, ensure_ascii=False)}")
        return "\n".join(lines)
    lines = [envelope["summary"]]
    if envelope.get("output_path"):
        lines.append(f"  output: {envelope['output_path']}")
    for w in envelope.get("warnings", []):
        hint = f" ({w['suggestion']})" if w.get("suggestion") else ""
        lines.append(f"  warning: {w['message']}{hint}")
    for key, value in (envelope.get("detail") or {}).items():
        if key == "batch":
            lines.append(_batch_line(value))
            continue
        if isinstance(value, (dict, list)):
            import json

            text = json.dumps(value, ensure_ascii=False)
        else:
            text = str(value)
        lines.append(f"  {key}: {text}")
    return "\n".join(lines)


def _batch_line(b: dict[str, int]) -> str:
    return (
        f"  batch: {b['applied']} of {b['total']} ops applied, "
        f"{b['failed']} failed, {b['skipped']} skipped"
    )
