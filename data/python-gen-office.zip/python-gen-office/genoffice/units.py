"""Length units: EMU fields take integers or strings with a unit suffix ("2.54cm", "1in", "10mm", "12pt", "96px")."""

from __future__ import annotations

import re
from typing import Any

EMU_PER_INCH = 914400
EMU_PER_PT = 12700
EMU_PER_PX = 9525  # 96 dpi
EMU_PER_CM = 360000
EMU_PER_MM = 36000
TWIPS_PER_PT = 20

# deck specs are px on a 1280x720 canvas; the slide is 13.333in x 7.5in
SLIDE_W_PX = 1280
SLIDE_H_PX = 720
SLIDE_W_EMU = SLIDE_W_PX * EMU_PER_PX
SLIDE_H_EMU = SLIDE_H_PX * EMU_PER_PX

_UNIT = re.compile(r"^\s*(-?\d+(?:\.\d+)?)\s*(cm|mm|in|pt|px|emu)?\s*$", re.I)
_PER_EMU = {
    "emu": 1,
    "in": EMU_PER_INCH,
    "pt": EMU_PER_PT,
    "px": EMU_PER_PX,
    "cm": EMU_PER_CM,
    "mm": EMU_PER_MM,
}


def to_emu(value: Any, *, default_unit: str = "emu") -> int:
    """An EMU integer from a number (in default_unit) or a "<n><unit>" string."""
    if isinstance(value, bool):
        raise ValueError(f"not a length: {value!r}")
    if isinstance(value, (int, float)):
        return int(round(value * _PER_EMU[default_unit]))
    if isinstance(value, str):
        m = _UNIT.match(value)
        if m:
            unit = (m.group(2) or default_unit).lower()
            return int(round(float(m.group(1)) * _PER_EMU[unit]))
    raise ValueError(f'not a length: {value!r} (use an integer or "2.54cm" / "1in" / "10mm" / "12pt" / "96px")')


def to_pt(value: Any) -> float:
    """Points from a number (already points) or a unit string; docx lengths default to points."""
    return to_emu(value, default_unit="pt") / EMU_PER_PT


def emu_to(value: int, unit: str) -> float:
    return round(value / _PER_EMU[unit], 3)


def px(value: float) -> int:
    return int(round(value * EMU_PER_PX))
