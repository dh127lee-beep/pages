from __future__ import annotations

import pytest

from genoffice.context import Context
from genoffice.formats import docx as D
from genoffice.result import GenOfficeError

MD = """# Report

Intro with **bold** and a [link](https://example.com).

- one
- two

| a | b |
|---|---|
| 1 | 2 |

## Next

Body TODO here.
"""


@pytest.fixture
def ctx(tmp_path):
    return Context(root=str(tmp_path), audit_log="")


@pytest.fixture
def report(ctx, tmp_path):
    D.create_from_markdown(ctx, MD, "report.docx")
    return tmp_path / "report.docx"


def kinds(ctx, file="report.docx"):
    return [b["kind"] for b in D.read(ctx, file).detail["blocks"]]


def test_markdown_roundtrip(ctx, report):
    md, counts = D.to_markdown(report)
    assert md.startswith("# Report")
    assert "**bold**" in md
    assert "[link](https://example.com)" in md
    assert "- one\n- two" in md
    assert "| a | b |" in md
    assert "## Next" in md
    assert counts["images"] == 0


def test_read_blocks(ctx, report):
    r = D.read(ctx, "report.docx", styles=True, sections=True, fields=True, properties=True)
    blocks = r.detail["blocks"]
    assert [b["kind"] for b in blocks] == ["heading", "paragraph", "list_item", "list_item", "table", "heading", "paragraph"]
    assert blocks[0]["level"] == 1 and blocks[5]["level"] == 2
    assert blocks[2]["list"] == {"kind": "bullet", "level": 0}
    assert blocks[4]["rows"] == 2 and blocks[4]["cols"] == 2
    assert "Heading1" in r.detail["styles"]["paragraph"]
    assert r.detail["sections"][0]["blockRange"] == [0, 6]
    r = D.read(ctx, "report.docx", range="1-2", max_chars=5)
    assert [b["index"] for b in r.detail["blocks"]] == [1, 2]
    assert r.detail["blocks"][0]["truncated"] is True


def test_apply_live_indexes(ctx, report):
    ops = [
        {"op": "insert_content", "afterBlockIndex": 0, "html": "<p>Summary one.</p><p>Summary two.</p>"},
        # block 3 is the old block 1 (Intro) after two inserted blocks
        {"op": "setFont", "target": {"blockIndexes": [3]}, "bold": True, "color": "#FF0000"},
        {"op": "findReplace", "find": "Summary", "replace": "Overview"},
        {"op": "deleteBlocks", "target": {"blockIndexes": [2]}},
    ]
    r = D.apply(ctx, "report.docx", ops)
    assert r.status == "ok" and r.detail["batch"]["applied"] == 4
    blocks = D.read(ctx, "report.docx").detail["blocks"]
    assert blocks[1]["text"] == "Overview one."
    assert blocks[2]["text"].startswith("Intro")
    from docx import Document

    doc = Document(str(report))
    assert all(run.bold for run in doc.paragraphs[2].runs if run.text.strip())


def test_atomic_rejection_leaves_file(ctx, report):
    before = report.read_bytes()
    with pytest.raises(GenOfficeError) as e:
        D.apply(ctx, "report.docx", [
            {"op": "setHeadingLevel", "target": {"blockIndexes": [1]}, "level": 2},
            {"op": "deleteBlocks", "target": {"blockIndexes": [99]}},
        ])
    f = e.value.detail["failures"][0]
    assert f["reason"] == "out_of_range" and f["index"] == 1 and f["valid_range"] == [0, 6]
    assert e.value.detail["batch"]["applied"] == 0
    assert report.read_bytes() == before


def test_best_effort_partial(ctx, report):
    r = D.apply(ctx, "report.docx", [
        {"op": "deleteBlocks", "target": {"blockIndexes": [99]}},
        {"op": "setHeadingLevel", "target": {"blockIndexes": [1]}, "level": 2},
    ], mode="best_effort")
    assert r.status == "partial"
    assert r.detail["batch"] == {"total": 2, "applied": 1, "failed": 1, "skipped": 0}
    assert kinds(ctx)[1] == "heading"


def test_unknown_op_did_you_mean(ctx, report):
    with pytest.raises(GenOfficeError) as e:
        D.apply(ctx, "report.docx", [{"op": "setFnot", "target": {"blockIndexes": [0]}}])
    assert e.value.reason == "unknown_op"
    assert e.value.detail["failures"][0]["did_you_mean"] == "setFont"


def test_dry_run_and_out(ctx, report, tmp_path):
    before = report.read_bytes()
    r = D.apply(ctx, "report.docx", [{"op": "insertToc", "afterBlockIndex": -1}], dry_run=True)
    assert r.output_path is None and report.read_bytes() == before
    r = D.apply(ctx, "report.docx", [{"op": "insertToc", "afterBlockIndex": -1}], out="copy.docx")
    assert (tmp_path / "copy.docx").exists() and kinds(ctx, "copy.docx")[0] == "toc"
    with pytest.raises(GenOfficeError) as e:
        D.apply(ctx, "report.docx", [{"op": "insertToc", "afterBlockIndex": -1}], out="copy.docx")
    assert e.value.reason == "output_exists"


def test_content_ops(ctx, report):
    r = D.apply(ctx, "report.docx", [
        {"op": "replace_blocks", "startBlockIndex": 1, "endBlockIndex": 1, "html": "<p>New intro</p>"},
        {"op": "set_header_footer", "kind": "footer", "text": "Page {PAGE} of {NUMPAGES}"},
        {"op": "set_page_setup", "paper": "A4", "orientation": "landscape", "margins": {"top": "2cm"}},
        {"op": "define_style", "styleId": "Callout", "run": {"bold": True, "color": "#1F3A5F"}},
        {"op": "applyStyle", "target": {"blockIndexes": [1]}, "styleId": "Callout"},
        {"op": "add_comment", "blockIndex": 1, "comment": "check this", "text": "intro"},
        {"op": "set_properties", "core": {"title": "Q3"}},
        {"op": "insert_section_break", "afterBlockIndex": 4},
    ])
    assert r.status == "ok"
    rd = D.read(ctx, "report.docx", header_footer=True, comments=True, sections=True, properties=True)
    assert rd.detail["blocks"][1]["text"] == "New intro" and rd.detail["blocks"][1]["style"] == "Callout"
    assert any("Page 1 of 1" in h["text"] for h in rd.detail["header_footer"] if h["kind"] == "footer")
    assert rd.detail["comments"][0]["text"] == "check this" and rd.detail["comments"][0]["block"] == 1
    assert rd.detail["properties"]["title"] == "Q3"
    assert len(rd.detail["sections"]) == 2 and rd.detail["sections"][0]["orientation"] == "landscape"


def test_unavailable_op(ctx, report):
    with pytest.raises(GenOfficeError) as e:
        D.apply(ctx, "report.docx", [{"op": "insert_footnote", "blockIndex": 0, "text": "x"}])
    assert e.value.detail["failures"][0]["reason"] == "unsupported"


def test_check_finds_placeholder(ctx, report):
    r = D.check(ctx, "report.docx")
    codes = [i["code"] for i in r.detail["issues"]]
    assert "placeholder_left" in codes
    assert r.detail["issues"][codes.index("placeholder_left")]["path"] == "b_6"


def test_merge(ctx, tmp_path):
    D.create_from_html(ctx, "<p>Dear {{ name }}, you owe {{amount}}.</p><p>Ref {{order.id}} {{missing}}</p>"
                       "<p>{{split</p>", "tpl.docx")
    r = D.merge(ctx, "tpl.docx", {"name": "Ada", "amount": 12, "order": {"id": "A-1"}, "extra": 1}, "out.docx")
    assert r.detail["used_keys"] == ["amount", "name", "order.id"]
    assert r.detail["unused_keys"] == ["extra"]
    assert [u["key"] for u in r.detail["unresolved_placeholders"]] == ["missing"]
    assert r.warnings[0].code == "unresolved_placeholder"
    md, _ = D.to_markdown(tmp_path / "out.docx")
    assert "Dear Ada, you owe 12." in md and "Ref A-1 {{missing}}" in md
    with pytest.raises(GenOfficeError) as e:
        D.merge(ctx, "tpl.docx", {"name": "Ada"}, "strict.docx", strict=True)
    assert e.value.reason == "unresolved_placeholder"
    assert not (tmp_path / "strict.docx").exists()


def test_merge_split_placeholder(ctx, tmp_path):
    D.create_from_html(ctx, "<p>Hi {{na<b>me</b>}}</p>", "split.docx")
    r = D.merge(ctx, "split.docx", {"name": "Ada"}, "o.docx")
    assert r.detail["unresolved_placeholders"][0]["reason"] == "split_placeholder"


def test_html_and_info(ctx, report, tmp_path):
    html = D.to_html(report)
    assert "<h1>Report</h1>" in html and "<ul>" in html and "<table>" in html
    info = D.info(report)
    assert info["blocks"] == 7 and info["tables"] == 1 and info["headings"][0]["text"] == "Report"
    r = D.from_text_pages(ctx, ["line a\nline b\n\npara 2", "page two"], "pdf.docx")
    assert r.detail["blocks"] == 4
