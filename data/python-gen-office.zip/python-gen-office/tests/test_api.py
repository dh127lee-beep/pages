"""The layers above the engines: envelope, tool dispatch, CLI, guide, deck flow, deepagents."""

from __future__ import annotations

import json

import pytest

from genoffice import GenOffice, TOOLS, call
from genoffice.cli import main as cli_main


@pytest.fixture
def go(tmp_path):
    return GenOffice(root=str(tmp_path))


def test_envelope_ok_and_error(go, tmp_path):
    ok = go.create_xlsx(data=[["a", "b"], [1, "=A2*2"]], out="t.xlsx")
    assert ok["status"] == "ok" and ok["command"] == "create"
    assert ok["output_path"] == str(tmp_path / "t.xlsx")
    again = go.create_xlsx(data=[[1]], out="t.xlsx")
    assert again["status"] == "error" and again["code"] == 2 and again["error"] == "output_exists"
    missing = go.info("nope.docx")
    assert missing["error"] == "file_not_found" and missing["code"] == 2


def test_tool_specs_mirror_methods(go):
    names = {t.name for t in TOOLS}
    for expected in ("docs_apply", "sheet_read", "slides_audit", "create_pptx", "deck_page", "guide", "merge"):
        assert expected in names
    for t in TOOLS:
        assert callable(getattr(go, t.method)), t.name
        assert set(t.required) <= set(t.properties), t.name


def test_call_validates_names_and_options(go):
    env = call(go, "sheet_reed", {"file": "x.xlsx"})
    assert env["error"] == "unknown_command" and "sheet_read" in env["suggestion"]
    env = call(go, "sheet_read", {"file": "x.xlsx", "rnage": "A1"})
    assert env["error"] == "unknown_option" and '"range"' in env["suggestion"]
    env = call(go, "docs_apply", {"file": "x.docx"})
    assert env["error"] == "missing_argument"


def test_from_keyword_maps(go, tmp_path):
    (tmp_path / "r.md").write_text("# Title\n\nBody.", encoding="utf-8")
    env = call(go, "create_docx", {"from": "r.md", "out": "r.docx"})
    assert env["status"] == "ok", env
    assert go.info("r.docx")["detail"]["headings"][0]["text"] == "Title"


def test_ops_inline_string_and_file(go, tmp_path):
    go.create_docx(markdown="# A\n\nB", out="d.docx")
    ops = [{"op": "insert_content", "afterBlockIndex": 0, "html": "<p>Inserted.</p>"}]
    (tmp_path / "ops.json").write_text(json.dumps(ops), encoding="utf-8")
    assert go.docs_apply("d.docx", ops="ops.json")["status"] == "ok"
    assert go.docs_apply("d.docx", ops=json.dumps(ops))["status"] == "ok"
    bad = go.docs_apply("d.docx", ops="[{oops")
    assert bad["error"] == "invalid_json"


def test_guide_domains_topics(go):
    for domain in ("docs", "sheets", "slides"):
        env = go.guide(domain)
        assert env["status"] == "ok" and env["detail"]["fingerprint"]
    assert "set_col_width" in go.guide("sheets", "layout")["summary"]
    assert go.guide("slides", "setText")["detail"]["op"]["op"] == "setText"
    assert "1280" in go.guide("slides", "spec")["summary"]
    typo = go.guide("sheets", "format_rnage")
    assert typo["status"] == "error" and "format_range" in typo["suggestion"]


def test_convert_routes(go, tmp_path):
    (tmp_path / "a.md").write_text("# Hi\n\n| a | b |\n|---|---|\n| 1 | 2 |\n", encoding="utf-8")
    assert go.convert("a.md", to="docx")["status"] == "ok"
    md = go.convert("a.docx", to="md", out="back.md")
    assert md["status"] == "ok" and "Hi" in (tmp_path / "back.md").read_text(encoding="utf-8")
    html = go.convert("a.md", to="html")
    assert "<table>" in (tmp_path / "a.html").read_text(encoding="utf-8"), html
    (tmp_path / "d.csv").write_text("sep=;\nname;amount\nx;1,5\n", encoding="utf-8")
    assert go.convert("d.csv", to="xlsx")["status"] == "ok"
    csv = go.convert("d.xlsx", to="csv", out="d2.csv")
    assert csv["status"] == "ok" and (tmp_path / "d2.csv").read_bytes().startswith(b"\xef\xbb\xbf")
    nope = go.convert("a.md", to="pptx")
    assert nope["error"] == "unsupported" and nope["detail"]["supported"]


def test_capabilities_and_providers(tmp_path):
    seen = {}

    def search(query, *, images=False, max=8):
        seen["q"] = (query, images, max)
        return [{"title": "t", "url": "https://example.com", "snippet": "s"}]

    go = GenOffice(root=str(tmp_path), search=search)
    caps = go.capabilities()["detail"]
    assert caps["search"] is True and caps["image_generation"] is False
    env = go.search("harbor cranes", max=3)
    assert env["detail"]["results"][0]["url"] == "https://example.com" and seen["q"] == ("harbor cranes", False, 3)
    assert go.image("a cat")["error"] == "app_unavailable"


def test_image_provider_renames_to_real_format(tmp_path):
    jpeg = b"\xff\xd8\xff\xe0" + b"0" * 32
    go = GenOffice(root=str(tmp_path), image=lambda prompt, **kw: jpeg)
    env = go.image("a cat", out="cat.png")
    assert env["status"] == "ok" and env["output_path"].endswith("cat.jpg")
    assert env["warnings"][0]["code"] == "output_renamed"


def test_allowed_roots(tmp_path):
    inside = tmp_path / "in"
    inside.mkdir()
    go = GenOffice(root=str(inside), allowed_roots=[str(inside)])
    env = go.create_xlsx(data=[[1]], out=str(tmp_path / "escape.xlsx"))
    assert env["error"] == "outside_allowed_roots"


def test_deck_flow(go, tmp_path):
    outline = {
        "topic": "Logistics review",
        "core_hook": "Margins fell 40% while volume grew 12%",
        "pages": [
            {"title": "The 40% squeeze", "type": "cover", "layout": "cover_typography_hero",
             "brief": "Main title, subtitle with the 2024 period, presenter line on a dark background.", "image_queries": []},
            {"title": "Thank you", "type": "closing", "layout": "closing_thank_you",
             "brief": "Closing line with the contact address of the logistics team and sources.", "image_queries": []},
        ],
    }
    style = "# Style\n\nBackground #0E1A2B, text #FFFFFF, accent #F2A541. Fonts default."
    start = go.deck_start("deck", style, outline)
    assert start["status"] == "ok", start
    assert [p["index"] for p in start["detail"]["pages"]] == [0, 1]

    def page(title, type_, layout):
        return {"title": title, "type": type_, "layout": layout, "background": "#0E1A2B",
                "elements": [{"type": "text", "x": 80, "y": 280, "w": 1100, "h": 120,
                              "paragraphs": [{"runs": [{"text": title, "sizePt": 44, "bold": True, "color": "#FFFFFF"}]}]}]}

    early = go.deck_page("deck", 1, page("Thank you", "closing", "closing_thank_you"))
    assert early["error"] == "invalid_argument" and early["detail"]["missing_pages"] == [0, 1]
    wrong = go.deck_page("deck", 0, page("Another title", "content", "three_column_cards"))
    assert wrong["status"] == "error" and wrong["detail"]["kept"] is False
    assert not (tmp_path / "deck" / "pages" / "01.json").exists()
    assert go.deck_page("deck", 0, page("The 40% squeeze", "cover", "cover_typography_hero"))["status"] == "ok"
    assert go.deck_build("deck")["error"] == "missing_argument"
    assert go.deck_page("deck", 1, page("Thank you", "closing", "closing_thank_you"))["status"] == "ok"
    built = go.deck_build("deck")
    assert built["status"] == "ok", built
    assert go.slides_read(built["output_path"])["detail"]["slides"][1]["id"] == "s_1"
    fixed = go.deck_replace("deck", 1, page("Thank you", "closing", "closing_thank_you"))
    assert fixed["status"] == "ok", fixed


def test_cli_json_and_exit_codes(tmp_path, capsys, monkeypatch):
    monkeypatch.chdir(tmp_path)
    (tmp_path / "t.json").write_text('[["item","qty"],["Apple",2]]', encoding="utf-8")
    assert cli_main(["create", "--type", "xlsx", "--from", "t.json", "--out", "s.xlsx", "--json"]) == 0
    capsys.readouterr()
    assert cli_main(["sheet", "read", "s.xlsx", "--range", "A1:B2", "--json"]) == 0
    env = json.loads(capsys.readouterr().out)
    assert env["detail"]["values"][1][0] == "Apple"
    monkeypatch.setattr("sys.stdin", __import__("io").StringIO('[{"op":"set_cell","address":"C1","value":"note"}]'))
    assert cli_main(["sheet", "apply", "s.xlsx", "--ops", "-", "--json"]) == 0
    capsys.readouterr()
    assert cli_main(["sheet", "raed", "s.xlsx", "--json"]) == 1
    env = json.loads(capsys.readouterr().out)
    assert env["error"] == "unknown_command" and "sheet read" in env["suggestion"]
    assert cli_main(["info", "missing.docx", "--json"]) == 2


def test_deepagents_tools_and_middleware(tmp_path):
    pytest.importorskip("deepagents")
    from genoffice.integrations.deepagents import GenOfficeMiddleware, genoffice_tools

    tools = {t.name: t for t in genoffice_tools(root=str(tmp_path))}
    assert len(tools) == len(TOOLS)
    out = json.loads(tools["create_xlsx"].invoke({"data": [["a"], [1]], "out": "x.xlsx"}))
    assert out["status"] == "ok"
    out = json.loads(tools["sheet_read"].invoke({"file": "x.xlsx"}))
    assert out["detail"]["values"][1][0] == 1
    mw = GenOfficeMiddleware(root=str(tmp_path), include=["guide", "info"])
    assert [t.name for t in mw.tools] == ["info", "guide"]


def test_deep_agent_end_to_end(tmp_path):
    """A scripted model drives a real deepagents graph through two genoffice tools."""
    pytest.importorskip("deepagents")
    from langchain_core.language_models.fake_chat_models import GenericFakeChatModel
    from langchain_core.messages import AIMessage

    from genoffice.integrations.deepagents import create_genoffice_agent

    class ScriptedModel(GenericFakeChatModel):
        def bind_tools(self, tools, **kwargs):
            return self

    script = iter(
        [
            AIMessage(content="", tool_calls=[{"id": "1", "name": "create_docx",
                                               "args": {"markdown": "# Plan\n\nShip it.", "out": "plan.docx"}}]),
            AIMessage(content="", tool_calls=[{"id": "2", "name": "docs_read", "args": {"file": "plan.docx"}}]),
            AIMessage(content="Created plan.docx with 2 blocks."),
        ]
    )
    agent = create_genoffice_agent(ScriptedModel(messages=script), root=str(tmp_path))
    result = agent.invoke({"messages": [{"role": "user", "content": "make a plan doc"}]})
    tool_outputs = [json.loads(m.content) for m in result["messages"] if m.type == "tool"]
    assert [o["command"] for o in tool_outputs] == ["create", "docs read"]
    assert tool_outputs[1]["detail"]["blocks"][0]["text"] == "Plan"
    assert (tmp_path / "plan.docx").exists()
    system = [m for m in result["messages"] if m.type == "system"]
    assert not system  # the prompt is added per model call, not stored in state
