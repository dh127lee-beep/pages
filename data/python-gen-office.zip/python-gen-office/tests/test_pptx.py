import json

import pytest
from PIL import Image
from pptx import Presentation

from genoffice.context import Context
from genoffice.formats import pptx as P
from genoffice.result import GenOfficeError

BOX = {"x": 914400, "y": 685800, "cx": 7315200, "cy": 914400}


@pytest.fixture
def ctx(tmp_path):
    return Context(root=str(tmp_path), audit_log="")


def make_deck(ctx, name="q3.pptx"):
    ops = [
        {
            "op": "addElement",
            "target": {"slide": 0},
            "kind": "textbox",
            "offset": BOX,
            "paragraphs": [{"runs": [{"text": "Q3 Review", "bold": True, "fontSize": 36}]}],
        },
        {"op": "addBlankSlide", "target": {"slide": 0}},
        {"op": "addTable", "target": {"slide": 1}, "rows": 3, "cols": 3, "offset": {"x": "1in", "y": "2in", "cx": "8in", "cy": "2.5in"}},
    ]
    return P.create_from_ops(ctx, ops, name)


def test_create_and_read_ids(ctx):
    r = make_deck(ctx)
    assert r.detail["slides"] == 2
    assert [n["created"] for n in r.detail["notes"] if "created" in n]
    d = P.read(ctx, "q3.pptx").detail
    assert [s["id"] for s in d["slides"]] == ["s_0", "s_1"]
    tb = d["slides"][0]["elements"][0]
    assert tb["id"].startswith("e_") and tb["kind"] == "textbox" and tb["text"] == "Q3 Review"
    assert tb["effective"]["fontSize"] == 36 and tb["effective"]["src"]["fontSize"] == "run"
    table = d["slides"][1]["elements"][0]
    assert table["kind"] == "table" and table["table"] == {"rows": 3, "cols": 3}
    inches = P.read(ctx, "q3.pptx", units="in").detail["slides"][0]["elements"][0]
    assert inches["unit"] == "in" and inches["box"]["x"] == 1.0


def test_set_text_inherits_font(ctx, tmp_path):
    make_deck(ctx)
    el = P.read(ctx, "q3.pptx").detail["slides"][0]["elements"][0]["id"]
    r = P.apply(ctx, "q3.pptx", [{"op": "setText", "target": {"slide": 0, "el": el}, "paragraphs": [{"runs": [{"text": "Q4 Plan"}]}]}])
    assert r.detail["batch"]["applied"] == 1
    run = Presentation(str(tmp_path / "q3.pptx")).slides[0].shapes[0].text_frame.paragraphs[0].runs[0]
    assert run.text == "Q4 Plan" and run.font.size.pt == 36 and run.font.bold


def test_target_not_found_and_out_of_range(ctx):
    make_deck(ctx)
    el = P.read(ctx, "q3.pptx").detail["slides"][0]["elements"][0]["id"]
    typo = el[:-1] + str((int(el[-1]) + 1) % 10)
    with pytest.raises(GenOfficeError) as e:
        P.apply(ctx, "q3.pptx", [{"op": "deleteElement", "target": {"slide": 0, "el": typo}}])
    f = e.value.detail["failures"][0]
    assert e.value.reason == "target_not_found" and f["available"] == [el] and f["did_you_mean"] == el
    with pytest.raises(GenOfficeError) as e:
        P.apply(ctx, "q3.pptx", [{"op": "deleteSlide", "target": {"slide": 7}}])
    assert e.value.reason == "out_of_range" and e.value.detail["failures"][0]["valid_range"] == [0, 1]
    with pytest.raises(GenOfficeError) as e:
        P.apply(ctx, "q3.pptx", [{"op": "setTxt", "target": {"slide": 0}}])
    assert e.value.detail["failures"][0]["did_you_mean"] == "setText"


def test_best_effort_partial(ctx):
    make_deck(ctx)
    r = P.apply(
        ctx,
        "q3.pptx",
        [{"op": "setNotes", "target": {"slide": 0}, "text": "hello"}, {"op": "deleteSlide", "target": {"slide": 9}}],
        mode="best_effort",
    )
    assert r.status == "partial" and r.detail["batch"] == {"total": 2, "applied": 1, "failed": 1, "skipped": 0}
    assert P.read(ctx, "q3.pptx", full=True).detail["slides"][0]["notes"] == "hello"


def test_slide_ops_and_chart(ctx):
    make_deck(ctx)
    r = P.apply(
        ctx,
        "q3.pptx",
        [
            {"op": "duplicateSlide", "target": {"slide": 0}},
            {"op": "moveSlide", "target": {"slide": 2}, "to": 0},
            {"op": "setBackground", "target": {"slide": 0}, "kind": "solid", "color": "#112233"},
            {"op": "addChart", "target": {"slide": 1}, "kind": "bar", "categories": ["a", "b"],
             "series": [{"name": "s", "values": [1, 2]}], "offset": {"x": 0, "y": 0, "cx": "4in", "cy": "3in"}, "title": "T"},
            {"op": "findReplace", "find": "q3", "replace": "Q9"},
            {"op": "applyTheme", "colors": {"accent1": "#FF0000"}, "majorFont": "Arial"},
        ],
    )
    assert r.detail["batch"]["applied"] == 6
    d = P.read(ctx, "q3.pptx").detail
    assert len(d["slides"]) == 3
    texts = [e.get("text") for s in d["slides"] for e in s["elements"]]
    assert texts.count("Q9 Review") == 2
    assert any(e["kind"] == "chart" for e in d["slides"][1]["elements"])


def png(path, w, h):
    Image.new("RGB", (w, h), (200, 30, 30)).save(path)
    return str(path)


def write_deck_files(tmp_path):
    deck = tmp_path / "deck"
    (deck / "pages").mkdir(parents=True)
    (deck / "style.md").write_text("bg #0E1A2B, text #FFFFFF, accent #E4572E, card #1F3A5F\n")
    outline = {
        "core_hook": "Margins fell 40% while volume grew",
        "pages": [
            {"title": "The squeeze", "type": "cover", "layout": "cover_typography_hero", "brief": "Main title over a dark background, subtitle with the period 2022-2024.", "image_queries": []},
            {"title": "Where it went", "type": "content", "layout": "left_text_right_image", "brief": "Fuel +31%, wages +18% on the left; harbor photo on the right side.", "image_queries": ["harbor cranes"]},
        ],
    }
    (deck / "outline.json").write_text(json.dumps(outline))
    img = png(tmp_path / "hero.png", 400, 600)
    pages = [
        {"title": "The squeeze", "type": "cover", "layout": "cover_typography_hero", "background": "#0E1A2B",
         "elements": [{"type": "text", "x": 80, "y": 200, "w": 1000, "h": 100,
                       "paragraphs": [{"runs": [{"text": "The squeeze", "sizePt": 48, "bold": True, "color": "#FFFFFF"}]}]}]},
        {"title": "Where it went", "type": "content", "layout": "left_text_right_image", "background": "#0E1A2B",
         "elements": [
             {"type": "shape", "shape": "roundRect", "x": 60, "y": 100, "w": 500, "h": 400, "fill": "#1F3A5F80"},
             {"type": "shape", "shape": "lineArrow", "x": 60, "y": 520, "w": 500, "h": 1, "stroke": {"color": "#E4572E", "widthPt": 2}},
             {"type": "text", "x": 80, "y": 120, "w": 460, "h": 60, "paragraphs": [{"runs": [{"text": "Where it went", "sizePt": 32, "color": "#FFFFFF"}]}]},
             {"type": "image", "url": img, "x": 660, "y": 80, "w": 540, "h": 560},
         ]},
    ]
    for i, p in enumerate(pages, start=1):
        (deck / "pages" / f"{i:02d}.json").write_text(json.dumps(p))
    return deck


def test_spec_build_and_checks(ctx, tmp_path):
    deck = write_deck_files(tmp_path)
    assert P.check(ctx, "deck/outline.json").detail["errors"] == []
    page = P.check(ctx, "deck/pages/02.json").detail
    assert page["style"]["offPalette"] == [] and page["imageFailures"] == []
    r = P.create_from_spec(ctx, spec_path="deck/pages", out="deck/deck.pptx")
    assert r.detail["slides"] == 2 and r.detail["imageFailures"] == []
    prs = Presentation(str(deck / "deck.pptx"))
    assert len(prs.slides) == 2 and prs.slide_width == 12192000
    pic = [s for s in prs.slides[1].shapes if s.shape_type == 13][0]
    assert pic.crop_top > 0 or pic.crop_left > 0 or pic.crop_bottom > 0
    # off-palette color and a disagreeing title
    bad = json.loads((deck / "pages" / "01.json").read_text())
    bad["elements"][0]["paragraphs"][0]["runs"][0]["color"] = "#00FF00"
    (deck / "pages" / "01.json").write_text(json.dumps(bad))
    assert P.check(ctx, "deck/pages/01.json").detail["style"]["offPalette"] == ["#00FF00"]
    bad["title"] = "Other"
    (deck / "pages" / "01.json").write_text(json.dumps(bad))
    with pytest.raises(GenOfficeError) as e:
        P.check(ctx, "deck/pages/01.json")
    assert e.value.detail["outline"]["findings"][0]["code"] == "disagrees_with_outline"
    with pytest.raises(GenOfficeError):
        P.create_from_spec(ctx, spec_path="deck/pages", out="deck/deck2.pptx")


def test_outline_errors(ctx, tmp_path):
    outline = {
        "core_hook": "x",
        "pages": [
            {"title": "A", "type": "content", "layout": "three_column_cards", "brief": "Revenue grew XX% this year", "image_queries": []},
            {"title": "B", "type": "content", "layout": "three_column_cards", "brief": "b", "image_queries": []},
            {"title": "C", "type": "content", "layout": "nope", "brief": "c"},
        ],
    }
    (tmp_path / "outline.json").write_text(json.dumps(outline))
    with pytest.raises(GenOfficeError) as e:
        P.check(ctx, "outline.json")
    codes = {x["code"] for x in e.value.detail["errors"]}
    assert {"placeholder_copy", "repeated_layout", "unknown_layout", "missing_image_queries"} <= codes
    assert any(w["code"] == "first_not_cover" for w in e.value.detail["warnings"])


def test_audit_overflow_and_replace(ctx, tmp_path):
    long = "word " * 200
    P.create_from_ops(ctx, [{"op": "addElement", "target": {"slide": 0}, "kind": "textbox",
                             "offset": {"x": "1in", "y": "1in", "cx": "3in", "cy": "0.5in"},
                             "paragraphs": [{"runs": [{"text": long, "fontSize": 18}]}]}], "a.pptx")
    issues = P.audit(ctx, "a.pptx").detail["issues"]
    over = [i for i in issues if i["code"] == "text_overflow"]
    assert over and over[0]["suggest"]["op"] == "setTransform"
    fixed = P.apply(ctx, "a.pptx", [over[0]["suggest"]])
    assert fixed.detail["batch"]["applied"] == 1
    deck = write_deck_files(tmp_path)
    P.create_from_spec(ctx, spec_path="deck/pages", out="deck/deck.pptx")
    r = P.replace(ctx, "deck/deck.pptx", 0, "deck/pages/01.json")
    assert r.detail["slide"] == "s_0" and len(Presentation(str(deck / "deck.pptx")).slides) == 2


def test_merge(ctx, tmp_path):
    P.create_from_ops(ctx, [
        {"op": "addElement", "target": {"slide": 0}, "kind": "textbox", "offset": BOX,
         "paragraphs": [{"runs": [{"text": "Hello {{ name"}, {"text": " }}, you owe {{amount}} {{missing}}", "bold": True}]}]},
        {"op": "setNotes", "target": {"slide": 0}, "text": "for {{client.city}}"},
    ], "tpl.pptx")
    r = P.merge(ctx, "tpl.pptx", {"name": "Ada", "amount": 12, "client": {"city": "Seoul"}, "extra": 1}, "out.pptx")
    assert r.detail["used_keys"] == ["amount", "client.city", "name"]
    assert r.detail["unused_keys"] == ["extra"]
    assert r.detail["unresolved_placeholders"][0]["key"] == "missing"
    assert r.warnings and r.warnings[0].code == "unresolved_placeholder"
    text = P.to_text(tmp_path / "out.pptx")
    assert "Hello Ada, you owe 12 {{missing}}" in text and "Seoul" in text
    with pytest.raises(GenOfficeError) as e:
        P.merge(ctx, "tpl.pptx", {"name": "Ada"}, "out2.pptx", strict=True)
    assert e.value.reason == "unresolved_placeholder" and not (tmp_path / "out2.pptx").exists()


def test_output_exists_and_info(ctx, tmp_path):
    make_deck(ctx)
    with pytest.raises(GenOfficeError) as e:
        make_deck(ctx)
    assert e.value.reason == "output_exists"
    info = P.info(tmp_path / "q3.pptx")
    assert info["slides"] == 2 and info["format"] == "pptx"


def test_catalog_has_original_names():
    names = set(P.REGISTRY.ops)
    for op in ("setText", "addElement", "addPicture", "tableMerge", "addSlideWithLayout", "applyTheme", "addAnimation"):
        assert op in names
    assert not P.REGISTRY.ops["addAnimation"].available
    assert "setText" in P.REGISTRY.guide_text("text")
