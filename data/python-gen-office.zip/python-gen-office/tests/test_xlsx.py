import openpyxl
import pytest

from genoffice.context import Context
from genoffice.formats import xlsx
from genoffice.result import GenOfficeError


@pytest.fixture
def ctx(tmp_path):
    return Context(root=str(tmp_path))


@pytest.fixture
def book(ctx, tmp_path):
    rows = [["item", "qty", "price"], ["Apple", 2, 1.5], ["Pear", 3, 2.0], ["Total", "=SUM(B2:B3)", ""]]
    xlsx.create_from_rows(ctx, rows, "sales.xlsx", header=True)
    return tmp_path / "sales.xlsx"


def test_create_with_header_and_formula(ctx, book):
    ws = openpyxl.load_workbook(book).active
    assert ws["B4"].value == "=SUM(B2:B3)"
    assert ws["A1"].font.b and ws.freeze_panes == "A2" and ws.auto_filter.ref == "A1:C4"


def test_read_values_and_formulas(ctx, book):
    r = xlsx.read(ctx, "sales.xlsx")
    assert r.detail["values"][1] == ["Apple", 2, 1.5]
    assert r.detail["formulas"] == {"B4": "=SUM(B2:B3)"}
    assert r.detail["values"][3][1] is None  # no cached value
    assert r.detail["features"]["filter"] == "A1:C4"
    r = xlsx.read(ctx, "sales.xlsx", where="formula")
    assert r.detail["cells"] == [{"ref": "B4", "value": None, "formula": "=SUM(B2:B3)"}]
    r = xlsx.read(ctx, "sales.xlsx", max_rows=2, cols="A,C")
    assert r.detail["values"] == [["item", "price"], ["Apple", 1.5]] and r.detail["truncated"]


def test_apply_runs_in_order_and_shifts_formulas(ctx, book):
    ops = [
        {"op": "format_range", "range": "A1:C1", "format": {"bold": True, "fillColor": "accent1+40%"}},
        {"op": "insert_rows", "row": 2, "count": 1},
        {"op": "set_cell", "address": "A2", "value": "Kiwi"},
        {"op": "set_cell", "address": "B2", "value": 5},
    ]
    r = xlsx.apply(ctx, "sales.xlsx", ops=ops)
    assert r.status == "ok" and r.detail["batch"]["applied"] == 4
    ws = openpyxl.load_workbook(book).active
    assert ws["A2"].value == "Kiwi" and ws["A3"].value == "Apple"
    assert ws["B5"].value == "=SUM(B3:B4)"
    assert ws["A1"].fill.fgColor.theme == 4


def test_sheet_not_found_did_you_mean(ctx, book):
    with pytest.raises(GenOfficeError) as e:
        xlsx.apply(ctx, "sales.xlsx", ops=[{"op": "set_cell", "sheet": "Shet1", "address": "A1", "value": 1}])
    f = e.value.detail["failures"][0]
    assert e.value.reason == "sheet_not_found" and f["did_you_mean"] == "Sheet1"
    assert e.value.detail["batch"]["applied"] == 0


def test_atomic_vs_best_effort(ctx, book):
    ops = [{"op": "set_cell", "address": "D1", "value": "x"}, {"op": "set_cel", "address": "A1", "value": 1}]
    with pytest.raises(GenOfficeError) as e:
        xlsx.apply(ctx, "sales.xlsx", ops=ops)
    assert e.value.reason == "unknown_op" and e.value.detail["failures"][0]["did_you_mean"] == "set_cell"
    assert openpyxl.load_workbook(book).active["D1"].value is None
    r = xlsx.apply(ctx, "sales.xlsx", ops=ops, mode="best_effort")
    assert r.status == "partial" and r.detail["batch"] == {"total": 2, "applied": 1, "failed": 1, "skipped": 0}
    assert openpyxl.load_workbook(book).active["D1"].value == "x"


def test_cells_mode(ctx, book):
    r = xlsx.apply(ctx, "sales.xlsx", cells=[
        {"cell": "D1", "value": "total"},
        {"cell": "D2", "formula": "=B2*C2", "style": {"numberFormat": "0.00"}},
    ])
    assert [w.code for w in r.warnings] == ["formulas_not_cached"]
    ws = openpyxl.load_workbook(book).active
    assert ws["D2"].value == "=B2*C2" and ws["D2"].number_format == "0.00"


def test_csv_import(ctx, tmp_path):
    (tmp_path / "data.csv").write_text("sep=;\nname;amount;day\nA;1.234,5;2024-01-02\nB;7;2024-01-03 09:30\n", encoding="utf-8")
    r = xlsx.create_from_csv(ctx, "data.csv", "data.xlsx", header=True, decimal=",")
    ws = openpyxl.load_workbook(r.output_path).active
    assert ws["B2"].value == 1234.5 and ws["B3"].value == 7
    assert ws["C2"].is_date and ws["C3"].value.hour == 9
    assert ws["A1"].value == "name" and ws.freeze_panes == "A2"


def test_check_finds_errors(ctx, book):
    xlsx.apply(ctx, "sales.xlsx", ops=[
        {"op": "set_cell", "address": "E1", "value": "=Missing!A1+1"},
        {"op": "set_cell", "address": "E2", "value": "=#REF!+1"},
        {"op": "set_cell", "address": "E3", "value": "TODO"},
    ])
    codes = {i["code"] for i in xlsx.check(ctx, "sales.xlsx").detail["issues"]}
    assert {"missing_sheet_ref", "formula_error", "placeholder_text", "formulas_not_cached"} <= codes


def test_merge_typed(ctx, tmp_path):
    xlsx.create_from_rows(ctx, [["{{name}}", "{{amount}}", "Hi {{name}} {{missing}}"]], "t.xlsx")
    r = xlsx.merge(ctx, "t.xlsx", {"name": "=Ada", "amount": 12}, "o.xlsx")
    ws = openpyxl.load_workbook(r.output_path).active
    assert ws["B1"].value == 12 and ws["A1"].value == "=Ada" and ws["A1"].data_type == "s"
    assert r.detail["unresolved_placeholders"][0]["key"] == "missing"
    with pytest.raises(GenOfficeError) as e:
        xlsx.merge(ctx, "t.xlsx", {"name": "x"}, "o2.xlsx", strict=True)
    assert e.value.reason == "unresolved_placeholder" and not (tmp_path / "o2.xlsx").exists()


def test_chart_table_and_csv_out(ctx, book):
    r = xlsx.apply(ctx, "sales.xlsx", ops=[
        {"op": "add_chart", "chartType": "column", "dataRange": "A1:B3", "title": "Qty"},
        {"op": "add_table", "range": "A1:C3", "name": "Fruit"},
        {"op": "add_sheet", "name": "Notes"},
        {"op": "rename_sheet", "sheet": "Notes", "name": "Memo"},
    ])
    assert r.status == "ok"
    feats = xlsx.read(ctx, "sales.xlsx").detail["features"]
    assert feats["tables"][0]["name"] == "Fruit" and len(feats["charts"]) == 1
    assert xlsx.to_csv(book).startswith("item,qty,price\r\nApple,2,1.5")
    assert [s["name"] for s in xlsx.info(book)["sheets"]] == ["Sheet1", "Memo"]


def test_link_before_grid_op_is_refused(ctx, book):
    ops = [{"op": "set_hyperlink", "address": "B1", "target": "https://x.com"}, {"op": "delete_cols", "column": "A", "count": 1}]
    with pytest.raises(GenOfficeError) as e:
        xlsx.apply(ctx, "sales.xlsx", ops=ops, mode="best_effort")
    f = e.value.detail["failures"][0]
    assert e.value.reason == "op_rejected" and f["index"] == 1 and f["op"] == "delete_cols" and f["usage"]
    assert openpyxl.load_workbook(book).active["A1"].value == "item"
    # the other way round, or on another sheet, is fine
    assert xlsx.apply(ctx, "sales.xlsx", ops=list(reversed(ops))).status == "ok"


def test_defined_names_do_not_mix_with_sheet_ops(ctx, book):
    ops = [{"op": "add_defined_name", "name": "Qty", "ref": "Sheet1!$B$2:$B$3"}, {"op": "add_sheet", "name": "X"}]
    with pytest.raises(GenOfficeError) as e:
        xlsx.apply(ctx, "sales.xlsx", ops=ops)
    assert e.value.detail["failures"][0]["op"] == "add_sheet" and e.value.detail["batch"]["applied"] == 0
    assert xlsx.apply(ctx, "sales.xlsx", ops=ops[:1]).status == "ok"
