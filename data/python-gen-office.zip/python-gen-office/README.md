# genoffice-py — GenOffice, native Python port

[genspark-ai/genoffice](https://github.com/genspark-ai/genoffice)의 `genoffice` CLI와 [`skills/genoffice/SKILL.md`](https://github.com/genspark-ai/genoffice/blob/main/skills/genoffice/SKILL.md)를 **순수 파이썬 함수**로 옮긴 패키지입니다.
CLI 커맨드 하나 = 함수 하나 = 에이전트 툴 하나이고, 이름·파라미터·op 어휘·JSON 결과(envelope)를 원본과 동일하게 맞췄습니다.
그래서 원본 스킬 문서의 워크플로가 그대로 통하고, deepagents 같은 다른 에이전트에 **빌트인 툴**로 바로 꽂을 수 있습니다.

```
원본 (TypeScript)                         이 패키지 (Python)
genoffice docs read r.docx --full --json   go.docs_read("r.docx", full=True)       → tool "docs_read"
genoffice sheet apply s.xlsx --ops -       go.sheet_apply("s.xlsx", ops=[...])     → tool "sheet_apply"
genoffice create --type pptx --spec dir    go.create_pptx(spec_dir="dir", out=...) → tool "create_pptx"
genoffice mcp  (deck_start/page/build)     go.deck_start(...) ...                   → tool "deck_start" ...
```

의존성은 python-docx / openpyxl / python-pptx / pypdf / markdown-it-py / Pillow 뿐이고(전부 순수 파이썬 혹은 휠 제공), Node·Electron·GenOffice 앱이 필요 없습니다.

## 설치

```bash
pip install -e .                    # 코어
pip install -e ".[deepagents]"      # deepagents 어댑터
pip install -e ".[render]"          # render / slides_render (pypdfium2) — LibreOffice 도 필요
```

## 구조

```
genoffice/
  result.py        envelope · exit code · error reason        (원본 result.ts)
  ops.py           op 레지스트리 · batch 모드 · 실패 분류        (op-catalog.ts, batch.ts, op-errors.ts)
  context.py       root · allowed roots · provider · soffice    (fs.ts + 앱 설정)
  api.py           GenOffice 클래스: 커맨드 = 메서드             (commands/*.ts)
  tools.py         툴 스펙(JSON Schema) + call()                (mcp/tools.ts, mcp/deck.ts)
  cli.py           `genoffice ...` 동일한 커맨드라인             (cli.ts)
  formats/
    docx.py        docs read/apply/check, md/html→docx, merge
    xlsx.py        sheet read/apply/check, csv/json→xlsx, merge
    pptx.py        slides read/apply/audit/check/replace, merge
    slide_spec.py  1280×720 px 덱 스펙 빌더 + outline/page 체크
    pdf.py         pdf read
    office.py      →pdf, render (LibreOffice + pypdfium2, 선택)
  guides/          slides design / spec 가이드
  skills/genoffice/SKILL.md   툴 이름으로 옮긴 스킬
  integrations/deepagents.py  LangChain 툴 · 미들웨어 · create_genoffice_agent
```

## 파이썬에서 직접

```python
from genoffice import GenOffice

go = GenOffice(root="/work")                       # 상대 경로 기준
go.create_xlsx(data=[["item", "qty", "price"], ["Apple", 2, 1.5], ["Total", "=SUM(B2:B2)", ""]],
               header=True, out="sales.xlsx")
go.sheet_apply("sales.xlsx", ops=[{"op": "format_range", "range": "A1:C1",
                                   "format": {"bold": True, "fillColor": "#FFFF00"}}])
env = go.sheet_check("sales.xlsx")
env["status"], env["detail"]["issues"]
```

모든 함수는 예외를 던지지 않고 원본 `--json`과 같은 dict를 돌려줍니다.

```json
{"status": "ok", "command": "sheet apply", "summary": "...", "output_path": "...", "warnings": [...], "detail": {...}}
{"status": "error", "command": "slides apply", "code": 1, "error": "target_not_found",
 "message": "...", "suggestion": "did you mean \"e_4\"? ...", "detail": {"failures": [{"index": 0, "available": ["e_2", "e_4"]}]}}
```

## deepagents에 빌트인 툴로

```python
from deepagents import create_deep_agent
from genoffice.integrations.deepagents import GenOfficeMiddleware, create_genoffice_agent, genoffice_tools

# 1) 가장 간단: 미들웨어가 툴 30개 + 스킬 요약 시스템 프롬프트를 넣어줌
agent = create_deep_agent("anthropic:claude-sonnet-5-5", middleware=[GenOfficeMiddleware(root="/work")])

# 2) 툴만 필요할 때
agent = create_deep_agent(model, tools=genoffice_tools(root="/work", exclude=["image", "media"]))

# 3) 한 번에 (+ SKILL.md 를 deepagents skills 로더로 점진 공개)
from deepagents.backends import FilesystemBackend
from genoffice.integrations.deepagents import SKILLS_DIR
agent = create_genoffice_agent(model, root="/work", with_skill=True,
                               backend=FilesystemBackend(root_dir="/"))
```

검색·이미지·미디어는 원본에서 "GenOffice에 설정된 provider"였던 것을 콜백으로 받습니다.

```python
go = GenOffice(
    root="/work",
    allowed_roots=["/work"],                                    # GENOFFICE_ALLOWED_ROOTS 와 동일
    search=lambda q, *, images=False, max=8: my_search(q, images, max),
    image=lambda prompt, **kw: my_image_bytes(prompt, **kw),   # bytes 또는 (bytes, mime)
    media=lambda source, *, ask=None: my_vision(source, ask),
)
agent = create_deep_agent(model, middleware=[GenOfficeMiddleware(go)])
```

다른 프레임워크에서는 `genoffice.tools.openai_tools()` / `anthropic_tools()`로 스키마를 받고 `genoffice.tools.call(go, name, args)`로 실행하면 됩니다.

## CLI

```bash
genoffice guide sheets layout
genoffice create --type docx --from report.md --out report.docx --json
echo '[{"op":"insert_content","afterBlockIndex":0,"html":"<p>Executive summary.</p>"}]' | genoffice docs apply report.docx --ops - --json
```

## 원본 대비 범위

| 영역 | 포팅됨 | 미포팅 (호출 시 이유와 함께 `unsupported` / `app_unavailable`) |
| --- | --- | --- |
| 커맨드/툴 | info, convert, create_*, docs/sheet/slides read·apply·check, slides audit·check·replace, render, merge, pdf read, guide, capabilities, search/image/media, deck_* | open, selection (데스크톱 에디터 필요), mcp 서버 자체, skill install |
| docs ops | `guide("docs")` 참고 | 변경 추적 기록·수락/거절, 각주/미주, 차트 등 (`guide`에 사유 표기) |
| sheets ops | 43개 | convert_to_values, add_pivot, edit_chart, add_shape, add_sparkline, refresh_pivot |
| slides ops | `guide("slides")` 참고 | 애니메이션, 섹션, SmartArt, 미디어 등 |
| 엔진 | — | 수식 계산 엔진(쓴 수식은 캐시값 없음 → `formulas_not_cached` 경고), OCR |
| 레이아웃 | →pdf / render 는 LibreOffice + pypdfium2 가 있을 때 | |

`guide(domain)`은 각 레지스트리에서 생성되므로, 무엇이 되고 안 되는지는 항상 `guide` 출력이 정답입니다.

## 테스트

```bash
python -m pytest -q
```

`tests/test_api.py::test_deep_agent_end_to_end`는 스크립트된 가짜 모델로 실제 deepagents 그래프를 돌려 `create_docx → docs_read`를 실행합니다.

## License

Apache-2.0. GenOffice(genspark-ai/genoffice, Apache-2.0)의 SKILL.md, 덱 design/spec 가이드, op 이름·시그니처를 옮겨 왔습니다.
