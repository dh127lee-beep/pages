# dsh-deepagents-server

DeepSeek Harness(`deepseek-ai/deepseek-harness`)의 에이전트 런타임 기능을
LangChain **deepagents 0.7.32** 위에서 Python 서버로 재구성한 구현입니다.
차이점 분석과 설계 고민은 `../docs/deepagents-vs-deepseek-harness.html`에 정리돼 있습니다.

## 실행

```sh
uv venv --python 3.12 .venv
uv pip install --python .venv/bin/python -e '.[test]'
cp .env.example .env   # DEEPSEEK_API_KEY, DSH_WORKSPACE, DSH_SERVER_TOKEN 설정
set -a; . ./.env; set +a
.venv/bin/python -m dsh_server          # http://127.0.0.1:3080
.venv/bin/python -m pytest              # 네트워크 없이 가짜 모델로 E2E 12개
```

### 웹 콘솔

서버를 띄우고 `http://127.0.0.1:3080/?token=$DSH_SERVER_TOKEN` 을 열면 됩니다(토큰은 브라우저 localStorage에 저장).
빌드 없는 단일 파일(`dsh_server/static/index.html`)이며 다음을 보여줍니다.

* 세션 트리(루트 / 서브에이전트 / 포크 / 웹훅) + 실시간 상태 점
* 타임라인: 스트리밍 응답, 생각(reasoning) 접기, 툴 카드(명령·diff·결과), 턴 경계, 시스템 입력(서브에이전트 결과·예약·goal 라운드)
* interrupt 응답 UI: 도구 승인(승인/인자 편집/거절+사유), `ask_user_question` 선택지, plan 리뷰(승인 / 계속 계획+피드백)
* 우측 패널: 세션·토큰·캐시 적중, todos, goal 진행률, 워크스페이스 변경(git status), 서브에이전트, job(kill), 예약(삭제), 원시 이벤트
* 헤더: 프리셋 변경, Plan 토글, Compact, Fork, 중단 · 다크 모드 · 모바일 레이아웃

### 오피스 프로필: 코드 실행 없는 VFS 샌드박스 (비개발자용)

세션마다 `profile`을 `dev` 또는 `office`로 고릅니다(`DSH_PROFILE`이 기본값). `office`에서는:

* **셸·job·승격·MCP 없음.** 백엔드가 명령 실행을 지원하지 않아 deepagents가 `execute`를 아예 노출하지 않습니다.
* **파일은 가상 파일시스템(VFS)에만 존재.** LangGraph store(SQLite)에 워크스페이스별 네임스페이스로 저장되고(바이너리는 base64),
  호스트 디렉터리는 건드리지 않습니다. 사용자는 콘솔의 **파일** 탭에서 올리고 내려받습니다.
* **고정된 오피스 툴 세트**(genoffice-py): 읽기·만들기·수정·점검·양식 채우기(`merge`)·변환. LibreOffice·클라우드가 필요한
  `render`/`create_pdf`/`search`/`image`/`media`는 제외됩니다.
* **`/templates/`**: `DSH_OFFICE_TEMPLATES` 폴더가 읽기 전용 공용 양식으로 보입니다(`{{ 이름 }}` 자리표시자 → `merge`).
* 각 툴 호출은 워크스페이스를 비공개 임시 폴더에 복사 → genoffice를 그 폴더에 가둬 실행(`allowed_roots`) →
  바뀐 파일만 VFS에 되돌려 쓰고 임시 경로는 결과에서 지웁니다.
* 비개발자용 프롬프트(쉬운 말, 원본 보존, 모호하면 질문 1개, 결과물 `present`), 파일 삭제 전 확인, 쉬운 툴 이름 표시.

```sh
uv pip install --python .venv/bin/python -e /path/to/python-gen-office
DSH_PROFILE=office DSH_OFFICE_TEMPLATES=/srv/forms DSH_OFFICE_QUOTA_MB=200 DSH_OFFICE_MAX_FILE_MB=25 \
  .venv/bin/python -m dsh_server
```

| 엔드포인트 (office 세션) | 설명 |
|---|---|
| `GET /v1/sessions/{id}/files` | 파일·공용 양식 목록, 사용량/한도 |
| `PUT /v1/sessions/{id}/files?path=/a.xlsx` | 업로드(본문 = 파일 바이트). 에이전트에게 알림이 갑니다 |
| `GET /v1/sessions/{id}/files/raw?path=…` | 다운로드 (`?token=` 지원, 링크용) |
| `DELETE /v1/sessions/{id}/files?path=…` | 삭제 |

서브에이전트는 부모의 파일을 함께 쓰고, 포크는 파일을 스냅샷 복사합니다.

### OpenAI 호환 게이트웨이로 실행 (예: 로컬 Claude CLI API)

```sh
DSH_PROTOCOL=openai-compat DEEPSEEK_BASE_URL=http://127.0.0.1:8899/v1 DEEPSEEK_API_KEY=dummy \
DSH_MODEL=sonnet DSH_MAX_TOKENS=8192 DSH_CONTEXT_WINDOW=200000 \
DSH_WORKSPACE=/path/to/ws DSH_SERVER_TOKEN=tok .venv/bin/python -m dsh_server
```

`openai-compat`은 DeepSeek 전용 필드(`thinking`, `reasoning_content`) 없이 표준 chat completions만 씁니다.
게이트웨이가 스트리밍 응답에 usage를 보내지 않으면 콘솔은 요청 수만 집계합니다.

## 기능 대응표

| Harness | 이 서버 |
|---|---|
| llm-deepseek (Anthropic Messages, `thinking` + `output_config.effort`, thinking 재전송) | `ChatAnthropic(base_url=https://api.deepseek.com/anthropic)` — `llm.py` |
| OpenAI 호환 경로의 `reasoning_content` 재전송 | `ReasoningReplayChatDeepSeek` (`DSH_PROTOCOL=openai`) |
| read / write / edit / glob / grep | deepagents `FilesystemMiddleware` (`read_file`, `write_file`, `edit_file`, `delete`, `ls`, `glob`, `grep`) |
| bash + bwrap/Seatbelt 샌드박스, fail-closed | `SandboxedShellBackend.execute` — `sandbox.py` |
| `sandbox_permissions` + `justification` 승격 | `request_escalated_execute` (항상 HITL 승인) |
| 권한 프리셋 read-only / workspace-write / danger-full-access | `permissions.py` (`FilesystemPermission` + `interrupt_on` + `DenyToolsMiddleware`) |
| spill-policy (12,500 토큰) | `FilesystemMiddleware(tool_token_limit_before_evict=12500)` → `/large_tool_results/` |
| compaction-basic (트리거 공식, 8개 섹션 요약, 툴결과 pruner, `/compact`) | `SummarizationMiddleware` + `ToolResultPrunerMiddleware` + `compact_conversation` |
| `todo_write` | `TodoListMiddleware` (`write_todos`) |
| plan mode + `exit_plan_mode` 리뷰 | `PlanModeMiddleware` (변경 툴 실제 차단까지) |
| goal (`create_goal`/`get_goal`/`update_goal`, `<goal_round>` 드라이버) | `GoalMiddleware` + `Hub._after_turn` |
| `ask_user_question` / `present` | `InteractionMiddleware` (LangGraph `interrupt`) |
| `subagent` / `subagent_fork` / `send_message` / `interrupt_agent` / `list_agents` | `runner.subagent_tools` (자식 = 별도 세션, 비동기, 깊이 1, 동시 8개) |
| (동기 위임) | deepagents `task` + general-purpose 서브에이전트 |
| jobs (`job_list`/`job_output`/`job_kill`) | `jobs.py` (+ `job_start`) |
| schedule (`after_seconds`/`at`/`every_seconds`/`daily`/`weekly`/`cron`) | `schedule.py` |
| skills / AGENTS.md | `SkillsMiddleware` / `MemoryMiddleware` (`/_user/skills/`, `/.agents/skills/`, `/.dsh/skills/`) |
| MCP (`mcp__<server>__<tool>`) | `langchain-mcp-adapters` — `web.load_mcp_tools` |
| web_search / web_fetch | Tavily / httpx (+SSRF 차단) |
| webhook → 새 세션 | `POST /v1/webhooks/{github,generic}` (HMAC 검증) |
| guards (repeat reminder 3/5/8, read-before-write) | `RepeatToolReminderMiddleware`, `ReadBeforeWriteMiddleware` |
| session log + follow stream | `EventLog` (JSONL, seq) + `GET /v1/sessions/{id}/follow` (SSE) |
| fork | 시드 세션 (`POST /v1/sessions/{id}/fork`) |

## HTTP API (모두 `Authorization: Bearer $DSH_SERVER_TOKEN`)

| Method | Path | 설명 |
|---|---|---|
| POST | `/v1/sessions` | `{preset, model, effort, title, prompt?}` 세션 생성 |
| GET | `/v1/sessions[?parent_id=]` | 목록 |
| GET / PATCH | `/v1/sessions/{id}` | 상태(status, todos, goal, plan_mode, interrupts, usage) / 프리셋·모델·effort 변경 |
| POST | `/v1/sessions/{id}/prompt` | `{text}` — 실행 중이면 큐에 쌓임. `/plan [msg]`, `/plan off`, `/compact` 명령 지원 |
| POST | `/v1/sessions/{id}/cancel` | 현재 턴 중단 |
| GET | `/v1/sessions/{id}/interrupts` | 대기 중 승인/질문/플랜 리뷰 |
| POST | `/v1/sessions/{id}/resume` | `{responses: {interrupt_id: value}}` |
| POST | `/v1/sessions/{id}/plan-mode` | `{active}` — 다음 턴에 적용 |
| POST | `/v1/sessions/{id}/fork` | 유휴 상태에서 포크 |
| GET | `/v1/sessions/{id}/events?after_seq=` | 이벤트 로그 |
| GET | `/v1/sessions/{id}/follow?after_seq=` | SSE: 재생 후 실시간 (`assistant/delta` 포함) |
| GET | `/v1/sessions/{id}/messages` | 모델 히스토리 |
| GET | `/v1/sessions/{id}/jobs`, `/schedules`, `/subagents` | 부가 상태 |
| POST | `/v1/jobs/{id}/kill`, DELETE `/v1/schedules/{id}` | 제어 |

### interrupt 응답 형식

```jsonc
// HITL 승인 (request_escalated_execute, /_user/ 쓰기, DSH_ALWAYS_ASK_TOOLS)
{"responses": {"<id>": {"decisions": [{"type": "approve"}]}}}
{"responses": {"<id>": {"decisions": [{"type": "reject", "message": "no"}]}}}
// ask_user_question
{"responses": {"<id>": {"answers": [{"id": "q1", "selected": ["postgres"], "custom": null}]}}}
// plan_review (exit_plan_mode)
{"responses": {"<id>": {"approved": false, "feedback": "split step 2"}}}
```

### 예시

```sh
T=change-me; H="Authorization: Bearer $T"
SID=$(curl -s -H "$H" -H 'content-type: application/json' localhost:3080/v1/sessions \
  -d '{"prompt":"이 저장소 구조를 요약해줘"}' | jq -r .id)
curl -N -H "$H" "localhost:3080/v1/sessions/$SID/follow"
```

## 보안 주의

* 기본 바인딩은 `127.0.0.1`. 외부 공개 시 TLS 프록시 뒤에 두고 토큰을 비밀로 유지하세요.
* 셸에 넘기는 환경변수는 `PATH/HOME/LANG…`만 — API 키는 모델이 실행하는 프로세스로 새지 않습니다.
* 샌드박스는 **파일 쓰기만** 제한합니다(harness와 동일). 네트워크·프로세스는 막지 않으므로
  신뢰할 수 없는 작업은 컨테이너/VM에서 실행하세요.
* `danger-full-access`는 승인 없이 호스트 전체에 쓸 수 있습니다.
