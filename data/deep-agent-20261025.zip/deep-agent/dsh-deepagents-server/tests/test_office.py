"""Office / VFS profile: no shell, files only in the store, fixed genoffice tool set."""

from __future__ import annotations

import io
import json
from pathlib import Path
from typing import Any

import pytest
from fastapi.testclient import TestClient

from dsh_server.app import create_app
from dsh_server.config import Settings
from dsh_server.office import translate_paths
from dsh_server.vfs import VFSError, normalize

from .test_server import FakeModel, call, make_client, say, turn_tools, wait_for

docx = pytest.importorskip("docx")
openpyxl = pytest.importorskip("openpyxl")


def office_client(tmp_path: Path, responder, *, templates: Path | None = None, **kw: Any) -> TestClient:
    return make_client(tmp_path, responder, default_profile="office", office_templates_dir=templates, **kw)


def tool_results(c: TestClient, sid: str) -> list[dict]:
    return [e["data"] for e in c.get(f"/v1/sessions/{sid}/events").json() if e["type"] == "tool/result"]


def docx_bytes(*paragraphs: str) -> bytes:
    d = docx.Document()
    for p in paragraphs:
        d.add_paragraph(p)
    buf = io.BytesIO()
    d.save(buf)
    return buf.getvalue()


def test_path_rules() -> None:
    assert normalize("report.docx") == "/report.docx"
    assert normalize("/a/./b.docx") == "/a/b.docx"
    for bad in ("../x", "/a/../../x", "/templates/x.docx", "/_skills/x", "", "a\\b"):
        with pytest.raises(VFSError):
            normalize(bad)
    assert translate_paths({"file": "/a.docx", "out": "b/c.xlsx", "ops": "[{}]"}) == {"file": "a.docx", "out": "b/c.xlsx", "ops": "[{}]"}
    with pytest.raises(VFSError):
        translate_paths({"out": "../../evil.docx"})


def test_catalog_has_no_code_execution(tmp_path: Path) -> None:
    seen: dict[str, Any] = {}

    class Spy(FakeModel):
        def bind_tools(self, tools, **kwargs):
            seen["tools"] = sorted(t.name if hasattr(t, "name") else t.get("name") for t in tools)
            return self

    settings = Settings(workspace=tmp_path, home=tmp_path / "home", auth_token="t", default_profile="office")
    app = create_app(settings, model_builder=lambda s, **kw: Spy(responder=lambda m: say("ok")))
    with TestClient(app) as c:
        c.headers["authorization"] = "Bearer t"
        sid = c.post("/v1/sessions", json={"prompt": "hi"}).json()["id"]
        wait_for(c, sid)
    tools = set(seen["tools"])
    for name in ("execute", "job_start", "request_escalated_execute", "web_fetch", "render", "create_pdf", "image"):
        assert name not in tools, name
    for name in ("create_docx", "docs_read", "sheet_apply", "merge", "slides_read", "read_file", "write_todos",
                 "ask_user_question", "present", "subagent"):
        assert name in tools, name


def test_create_xlsx_lands_in_vfs_and_downloads(tmp_path: Path) -> None:
    def responder(messages):
        if not turn_tools(messages):
            return call("create_xlsx", data=[["item", "qty"], ["apple", 3], ["pear", 5]], header=True, out="/sales.xlsx")
        return say("done")

    with office_client(tmp_path, responder) as c:
        sid = c.post("/v1/sessions", json={"prompt": "make a sheet"}).json()["id"]
        wait_for(c, sid)
        env = json.loads(tool_results(c, sid)[0]["content"])
        assert env["status"] == "ok" and env["saved_files"] == ["/sales.xlsx"]
        assert "dsh-office-" not in json.dumps(env)  # temp paths are scrubbed
        files = c.get(f"/v1/sessions/{sid}/files").json()["files"]
        assert [f["path"] for f in files] == ["/sales.xlsx"]
        raw = c.get(f"/v1/sessions/{sid}/files/raw", params={"path": "/sales.xlsx"})
        ws = openpyxl.load_workbook(io.BytesIO(raw.content)).active
        assert ws["A2"].value == "apple" and ws["B3"].value == 5
        assert not list((tmp_path / "ws").iterdir())  # nothing touched the host workspace


def test_uploaded_docx_is_readable_and_text_tools_are_guarded(tmp_path: Path) -> None:
    def responder(messages):
        tools = turn_tools(messages)
        if not tools:
            return call("docs_read", file="/memo.docx", full=True)
        if len(tools) == 1:
            return call("read_file", file_path="/memo.docx")
        return say("ok")

    with office_client(tmp_path, responder) as c:
        sid = c.post("/v1/sessions", json={}).json()["id"]
        r = c.put(f"/v1/sessions/{sid}/files", params={"path": "/memo.docx"}, content=docx_bytes("분기 매출 12억", "다음 회의 5월 3일"))
        assert r.status_code == 201
        c.post(f"/v1/sessions/{sid}/prompt", json={"text": "read my memo"})
        wait_for(c, sid)
        read, guarded = tool_results(c, sid)[:2]
        assert "분기 매출 12억" in read["content"]
        assert "binary office file" in guarded["content"]
        msgs = c.get(f"/v1/sessions/{sid}/messages").json()
        assert any("file_uploaded" in str(m["data"].get("content")) for m in msgs)  # the agent was told


def test_escape_attempts_stay_inside(tmp_path: Path) -> None:
    def responder(messages):
        tools = turn_tools(messages)
        if not tools:
            return call("create_docx", markdown="# x", out="../../escaped.docx")
        if len(tools) == 1:
            return call("info", file="/etc/passwd")
        return say("ok")

    with office_client(tmp_path, responder) as c:
        sid = c.post("/v1/sessions", json={"prompt": "try"}).json()["id"]
        wait_for(c, sid)
        first, second = (json.loads(r["content"]) for r in tool_results(c, sid)[:2])
        assert first["error"] == "invalid_path"
        assert second["status"] == "error" and second["error"] == "file_not_found"
        assert "/private/" not in json.dumps(second) and "/tmp/" not in json.dumps(second)
        assert c.get(f"/v1/sessions/{sid}/files").json()["files"] == []


def test_templates_are_read_only_but_mergeable(tmp_path: Path) -> None:
    templates = tmp_path / "templates"
    templates.mkdir()
    (templates / "offer.docx").write_bytes(docx_bytes("Dear {{ name }},", "Salary: {{ salary }}"))

    def responder(messages):
        tools = turn_tools(messages)
        if not tools:
            return call("merge", file="/templates/offer.docx", data={"name": "Ada", "salary": "100"}, out="/offer_ada.docx")
        if len(tools) == 1:
            return call("docs_apply", file="/templates/offer.docx", ops=[{"op": "insert_content", "afterBlockIndex": 0, "html": "<p>x</p>"}])
        if len(tools) == 2:
            return call("write_file", file_path="/templates/new.md", content="x")
        return say("ok")

    with office_client(tmp_path, responder, templates=templates) as c:
        sid = c.post("/v1/sessions", json={"prompt": "fill"}).json()["id"]
        wait_for(c, sid)
        merged, edit, write = (r["content"] for r in tool_results(c, sid)[:3])
        assert json.loads(merged)["saved_files"] == ["/offer_ada.docx"]
        assert json.loads(edit)["status"] == "error"
        assert "read-only" in write or "denied" in write.lower()
        listing = c.get(f"/v1/sessions/{sid}/files").json()
        assert [t["path"] for t in listing["templates"]] == ["/templates/offer.docx"]
        assert [f["path"] for f in listing["files"]] == ["/offer_ada.docx"]
        out = docx.Document(io.BytesIO(c.get(f"/v1/sessions/{sid}/files/raw", params={"path": "/offer_ada.docx"}).content))
        assert "Dear Ada," in [p.text for p in out.paragraphs]
        assert docx.Document(str(templates / "offer.docx")).paragraphs[0].text == "Dear {{ name }},"


def test_read_only_preset_and_delete_confirmation(tmp_path: Path) -> None:
    def responder(messages):
        tools = turn_tools(messages)
        if not tools:
            return call("create_docx", markdown="# x", out="/x.docx")
        return say(tools[-1].content)

    with office_client(tmp_path, responder) as c:
        sid = c.post("/v1/sessions", json={"prompt": "make", "preset": "read-only"}).json()["id"]
        wait_for(c, sid)
        assert "read-only" in tool_results(c, sid)[0]["content"]

    def deleter(messages):
        tools = turn_tools(messages)
        if not tools:
            return call("delete", file_path="/old.md")
        return say("deleted")

    (tmp_path / "b").mkdir()
    with office_client(tmp_path / "b", deleter) as c:
        sid = c.post("/v1/sessions", json={}).json()["id"]
        c.put(f"/v1/sessions/{sid}/files", params={"path": "/old.md"}, content=b"old notes")
        c.post(f"/v1/sessions/{sid}/prompt", json={"text": "delete old.md"})
        [intr] = wait_for(c, sid, ("waiting",))["interrupts"]
        assert intr["value"]["action_requests"][0]["name"] == "delete"
        c.post(f"/v1/sessions/{sid}/resume", json={"responses": {intr["id"]: {"decisions": [{"type": "approve"}]}}})
        wait_for(c, sid)
        assert c.get(f"/v1/sessions/{sid}/files").json()["files"] == []


def test_upload_limits_and_dev_sessions_have_no_files(tmp_path: Path) -> None:
    with office_client(tmp_path, lambda m: say("ok"), office_max_file_mb=1) as c:
        sid = c.post("/v1/sessions", json={}).json()["id"]
        assert c.put(f"/v1/sessions/{sid}/files", params={"path": "/big.bin"}, content=b"x" * (1024 * 1024 + 1)).status_code == 413
        assert c.put(f"/v1/sessions/{sid}/files", params={"path": "/../x"}, content=b"x").status_code == 400
        assert c.put(f"/v1/sessions/{sid}/files", params={"path": "/templates/x"}, content=b"x").status_code == 400
        dev = c.post("/v1/sessions", json={"profile": "dev"}).json()["id"]
        assert c.get(f"/v1/sessions/{dev}/files").status_code == 409


def test_subagent_and_fork_workspaces(tmp_path: Path) -> None:
    def responder(messages):
        from .test_server import last_human

        human = last_human(messages)
        tools = turn_tools(messages)
        if human == "child task":
            return call("create_docx", markdown="# child", out="/from_child.docx") if not tools else say("child done")
        if "<subagent_settled" in human:
            return say("parent got it")
        if not tools:
            return call("subagent", description="writer", prompt="child task")
        return say("spawned")

    import time

    with office_client(tmp_path, responder) as c:
        sid = c.post("/v1/sessions", json={"prompt": "delegate"}).json()["id"]
        deadline = time.time() + 30
        while time.time() < deadline:
            evs = [e["type"] for e in c.get(f"/v1/sessions/{sid}/events").json()]
            if evs.count("turn/end") >= 2 and c.get(f"/v1/sessions/{sid}").json()["status"] == "idle":
                break
            time.sleep(0.2)
        # the child wrote into the parent's workspace
        assert [f["path"] for f in c.get(f"/v1/sessions/{sid}/files").json()["files"]] == ["/from_child.docx"]
        assert "vfs/changed" in [e["type"] for e in c.get(f"/v1/sessions/{sid}/events").json()]
        fork = c.post(f"/v1/sessions/{sid}/fork").json()["id"]
        c.delete(f"/v1/sessions/{sid}/files", params={"path": "/from_child.docx"})
        # the fork kept its own snapshot
        assert [f["path"] for f in c.get(f"/v1/sessions/{fork}/files").json()["files"]] == ["/from_child.docx"]


def test_cjk_bold_is_rewritten_outside_code() -> None:
    from dsh_server.office import fix_cjk_emphasis

    md = "달은 **5월(1,000원)**입니다. `**code**`\n```\n**fence**\n```\n**a** and **b**"
    out = fix_cjk_emphasis(md)
    assert "달은 <strong>5월(1,000원)</strong>입니다." in out
    assert "`**code**`" in out and "\n**fence**\n" in out
    assert out.endswith("<strong>a</strong> and <strong>b</strong>")
