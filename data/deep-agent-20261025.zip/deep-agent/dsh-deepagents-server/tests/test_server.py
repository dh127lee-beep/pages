"""End-to-end tests through the HTTP API with a rule-based fake model (no network)."""

from __future__ import annotations

import time
import uuid
from collections.abc import Callable
from pathlib import Path
from typing import Any

import pytest
from fastapi.testclient import TestClient
from langchain_core.language_models import BaseChatModel
from langchain_core.messages import AIMessage, BaseMessage, HumanMessage, ToolMessage
from langchain_core.outputs import ChatGeneration, ChatResult

from dsh_server.app import create_app
from dsh_server.config import Settings
from dsh_server.prompts import TITLE_PROMPT

Responder = Callable[[list[BaseMessage]], AIMessage]


class FakeModel(BaseChatModel):
    responder: Any

    @property
    def _llm_type(self) -> str:
        return "fake"

    def _generate(self, messages, stop=None, run_manager=None, **kwargs) -> ChatResult:
        return ChatResult(generations=[ChatGeneration(message=self.responder(messages))])

    def bind_tools(self, tools, **kwargs):
        return self


def call(name: str, **args: Any) -> AIMessage:
    return AIMessage(content="", tool_calls=[{"id": f"call_{uuid.uuid4().hex[:8]}", "name": name, "args": args}])


def say(text: str) -> AIMessage:
    return AIMessage(content=text, usage_metadata={"input_tokens": 10, "output_tokens": 2, "total_tokens": 12})


def last_human(messages: list[BaseMessage]) -> str:
    for m in reversed(messages):
        if isinstance(m, HumanMessage) and "<runtime_context>" not in str(m.content) and "<plan_mode>" not in str(m.content):
            return str(m.content)
    return ""


def turn_tools(messages: list[BaseMessage]) -> list[ToolMessage]:
    """Tool results since the last real human message."""
    out: list[ToolMessage] = []
    for m in reversed(messages):
        if isinstance(m, HumanMessage) and "<runtime_context>" not in str(m.content) and "<plan_mode>" not in str(m.content):
            break
        if isinstance(m, ToolMessage):
            out.append(m)
    return list(reversed(out))


def make_client(tmp_path: Path, responder: Responder, **overrides: Any) -> TestClient:
    def wrapped(messages: list[BaseMessage]) -> AIMessage:
        if any(TITLE_PROMPT[:30] in str(m.content) for m in messages):
            return AIMessage(content="Test session title")
        return responder(messages)

    workspace = tmp_path / "ws"
    workspace.mkdir()
    settings = Settings(workspace=workspace, home=tmp_path / "home", auth_token="t", **overrides)
    app = create_app(settings, model_builder=lambda s, **kw: FakeModel(responder=wrapped))
    client = TestClient(app)
    client.headers["authorization"] = "Bearer t"
    return client


def wait_for(client: TestClient, sid: str, statuses: tuple[str, ...] = ("idle",), timeout: float = 30) -> dict:
    deadline = time.time() + timeout
    while time.time() < deadline:
        s = client.get(f"/v1/sessions/{sid}").json()
        ended = any(e["type"] in ("turn/end", "interrupt/asked") for e in client.get(f"/v1/sessions/{sid}/events").json())
        if ended and s["status"] in statuses and not s["queued"]:
            return s
        time.sleep(0.1)
    raise AssertionError(f"session {sid} did not reach {statuses}: {client.get(f'/v1/sessions/{sid}').json()}")


def types(client: TestClient, sid: str) -> list[str]:
    return [e["type"] for e in client.get(f"/v1/sessions/{sid}/events").json()]


def test_auth_required(tmp_path: Path) -> None:
    with make_client(tmp_path, lambda m: say("hi")) as c:
        assert c.get("/health").status_code == 200
        assert c.get("/v1/sessions", headers={"authorization": "Bearer nope"}).status_code == 401


def test_todos_files_shell_and_events(tmp_path: Path) -> None:
    def responder(messages):
        done = [t.name for t in turn_tools(messages)]
        if not done:
            return AIMessage(content="", tool_calls=[
                {"id": "c1", "name": "write_todos", "args": {"todos": [{"content": "write file", "status": "in_progress"}]}},
                {"id": "c2", "name": "write_file", "args": {"file_path": "/hello.txt", "content": "hello\n"}},
            ])
        if "execute" not in done:
            return call("execute", command="cat hello.txt && echo extra > extra.txt")
        return say("done")

    with make_client(tmp_path, responder) as c:
        sid = c.post("/v1/sessions", json={"prompt": "make a file"}).json()["id"]
        state = wait_for(c, sid)
        ev = types(c, sid)
        assert "todo/write" in ev and "turn/end" in ev and "usage" in ev
        assert state["todos"][0]["content"] == "write file"
        assert (tmp_path / "ws" / "hello.txt").read_text() == "hello\n"
        results = [e for e in c.get(f"/v1/sessions/{sid}/events").json() if e["type"] == "tool/result"]
        shell = next(r for r in results if r["data"]["name"] == "execute")
        assert "hello" in shell["data"]["content"]
        assert (tmp_path / "ws" / "extra.txt").exists()  # workspace-write sandbox allows workspace writes


def test_read_only_preset_denies_writes(tmp_path: Path) -> None:
    def responder(messages):
        if not turn_tools(messages):
            return call("write_file", file_path="/x.txt", content="x")
        return say("ok")

    with make_client(tmp_path, responder) as c:
        sid = c.post("/v1/sessions", json={"prompt": "write", "preset": "read-only"}).json()["id"]
        wait_for(c, sid)
        assert not (tmp_path / "ws" / "x.txt").exists()


def test_read_before_write_guard(tmp_path: Path) -> None:
    def responder(messages):
        tools = turn_tools(messages)
        if not tools:
            return call("edit_file", file_path="/a.txt", old_string="a", new_string="b")
        return say(tools[-1].content)

    with make_client(tmp_path, responder) as c:
        (tmp_path / "ws" / "a.txt").write_text("a")
        sid = c.post("/v1/sessions", json={"prompt": "edit"}).json()["id"]
        wait_for(c, sid)
        assert (tmp_path / "ws" / "a.txt").read_text() == "a"
        msgs = [e for e in c.get(f"/v1/sessions/{sid}/events").json() if e["type"] == "tool/result"]
        assert "read /a.txt with read_file" in msgs[0]["data"]["content"]


def test_escalation_requires_approval(tmp_path: Path) -> None:
    def responder(messages):
        tools = turn_tools(messages)
        if not tools:
            return call("request_escalated_execute", command="echo escalated", sandbox_permissions="danger-full-access",
                        justification="test")
        return say(f"result: {tools[-1].content}")

    with make_client(tmp_path, responder) as c:
        sid = c.post("/v1/sessions", json={"prompt": "go"}).json()["id"]
        state = wait_for(c, sid, ("waiting",))
        [intr] = state["interrupts"]
        assert intr["value"]["action_requests"][0]["name"] == "request_escalated_execute"
        r = c.post(f"/v1/sessions/{sid}/resume", json={"responses": {intr["id"]: {"decisions": [{"type": "approve"}]}}})
        assert r.status_code == 202
        wait_for(c, sid)
        results = [e for e in c.get(f"/v1/sessions/{sid}/events").json() if e["type"] == "tool/result"]
        assert "escalated" in results[-1]["data"]["content"]


def test_ask_user_question(tmp_path: Path) -> None:
    def responder(messages):
        tools = turn_tools(messages)
        if not tools:
            return call("ask_user_question", questions=[{"id": "q1", "question": "Which DB?",
                                                         "options": [{"label": "sqlite"}, {"label": "postgres"}]}])
        return say(f"answer was {tools[-1].content}")

    with make_client(tmp_path, responder) as c:
        sid = c.post("/v1/sessions", json={"prompt": "ask me"}).json()["id"]
        [intr] = wait_for(c, sid, ("waiting",))["interrupts"]
        assert intr["value"]["type"] == "user_question"
        c.post(f"/v1/sessions/{sid}/resume", json={"responses": {intr["id"]: {"answers": [{"id": "q1", "selected": ["postgres"]}]}}})
        wait_for(c, sid)
        final = [e for e in c.get(f"/v1/sessions/{sid}/events").json() if e["type"] == "assistant/message"][-1]
        assert "postgres" in final["data"]["text"]


def test_plan_mode_blocks_mutation_and_review(tmp_path: Path) -> None:
    def responder(messages):
        tools = turn_tools(messages)
        if not tools:
            return call("write_file", file_path="/p.txt", content="x")
        if len(tools) == 1:
            return call("exit_plan_mode", plan="# Plan\n1. write p.txt")
        return say("planned")

    with make_client(tmp_path, responder) as c:
        sid = c.post("/v1/sessions", json={}).json()["id"]
        assert c.post(f"/v1/sessions/{sid}/prompt", json={"text": "/plan write p.txt"}).json()["plan_mode"] is True
        [intr] = wait_for(c, sid, ("waiting",))["interrupts"]
        assert intr["value"]["type"] == "plan_review"
        assert not (tmp_path / "ws" / "p.txt").exists()
        c.post(f"/v1/sessions/{sid}/resume", json={"responses": {intr["id"]: {"approved": True}}})
        state = wait_for(c, sid)
        assert state["plan_mode"] is False
        assert "plan/mode" in types(c, sid)


def test_async_subagent_settles_into_parent(tmp_path: Path) -> None:
    def responder(messages):
        human = last_human(messages)
        if "<subagent_settled" in human:
            return say("parent saw: " + human)
        if human == "child task":
            return say("child result 42")
        if not turn_tools(messages):
            return call("subagent", description="helper", prompt="child task")
        return say("spawned")

    with make_client(tmp_path, responder) as c:
        sid = c.post("/v1/sessions", json={"prompt": "delegate"}).json()["id"]
        deadline = time.time() + 30
        while time.time() < deadline:
            finals = [e for e in c.get(f"/v1/sessions/{sid}/events").json() if e["type"] == "assistant/message"]
            if any("child result 42" in e["data"]["text"] for e in finals):
                break
            time.sleep(0.2)
        else:
            raise AssertionError(types(c, sid))
        [child] = c.get(f"/v1/sessions/{sid}/subagents").json()
        assert child["kind"] == "subagent" and child["parent_id"] == sid


def test_goal_driver_continues_until_complete(tmp_path: Path) -> None:
    def responder(messages):
        human = last_human(messages)
        tools = turn_tools(messages)
        if human == "keep going":
            return call("create_goal", objective="count to 2", max_goal_rounds=5) if not tools else say("goal set")
        if "<goal_round" in human and 'round="2"' in human:
            if not tools:
                return call("get_goal")
            if len(tools) == 1:
                import json
                g = json.loads(tools[0].content)
                return call("update_goal", goal_id=g["id"], revision=g["revision"], action="complete")
            return say("finished")
        return say("working")

    with make_client(tmp_path, responder) as c:
        sid = c.post("/v1/sessions", json={"prompt": "keep going"}).json()["id"]
        deadline = time.time() + 30
        while time.time() < deadline:
            s = c.get(f"/v1/sessions/{sid}").json()
            if s["goal"] and s["goal"]["phase"] == "complete" and s["status"] == "idle":
                break
            time.sleep(0.2)
        else:
            raise AssertionError(s)
        assert s["goal"]["rounds"] == 2


def test_schedule_and_fork(tmp_path: Path) -> None:
    def responder(messages):
        human = last_human(messages)
        if "<scheduled_task" in human:
            return say("reminder handled")
        if human == "remind me" and not turn_tools(messages):
            return call("schedule_create", prompt="check build", title="build", after_seconds=1)
        return say("ok")

    with make_client(tmp_path, responder) as c:
        sid = c.post("/v1/sessions", json={"prompt": "remind me"}).json()["id"]
        deadline = time.time() + 30
        while time.time() < deadline:
            if "schedule/fired" in types(c, sid) and c.get(f"/v1/sessions/{sid}").json()["status"] == "idle":
                break
            time.sleep(0.3)
        else:
            raise AssertionError(types(c, sid))
        wait_for(c, sid)
        fork = c.post(f"/v1/sessions/{sid}/fork").json()
        c.post(f"/v1/sessions/{fork['id']}/prompt", json={"text": "hello fork"})
        wait_for(c, fork["id"])
        msgs = c.get(f"/v1/sessions/{fork['id']}/messages").json()
        assert any("remind me" in str(m["data"].get("content")) for m in msgs)


def test_large_tool_output_is_spilled(tmp_path: Path) -> None:
    def responder(messages):
        tools = turn_tools(messages)
        if not tools:
            return call("execute", command="python3 -c \"print('x'*200000)\"")
        return say(tools[-1].content[:300])

    with make_client(tmp_path, responder, spill_max_inline_tokens=1000, shell_max_output_bytes=400_000) as c:
        sid = c.post("/v1/sessions", json={"prompt": "big"}).json()["id"]
        wait_for(c, sid)
        result = [e for e in c.get(f"/v1/sessions/{sid}/events").json() if e["type"] == "tool/result"][0]
        assert "/large_tool_results/" in result["data"]["content"]
        assert any((tmp_path / "home" / "data" / "spill").rglob("*"))


def test_skills_memory_and_tool_catalog_reach_the_model(tmp_path: Path) -> None:
    seen: dict[str, Any] = {}

    class SpyModel(FakeModel):
        def bind_tools(self, tools, **kwargs):
            seen["tools"] = sorted(t.name if hasattr(t, "name") else t.get("name") for t in tools)
            return self

    def responder(messages):
        system = "\n".join(str(m.content) for m in messages if m.type == "system")
        if system:
            seen["system"] = system
        return say("ok")

    workspace = tmp_path / "ws"
    workspace.mkdir()
    (workspace / "AGENTS.md").write_text("Project rule: always use tabs.\n")
    skill = tmp_path / "home" / "user" / "skills" / "release-notes"
    skill.mkdir(parents=True)
    (skill / "SKILL.md").write_text("---\nname: release-notes\ndescription: Write release notes from git log.\n---\nSteps...\n")
    settings = Settings(workspace=workspace, home=tmp_path / "home", auth_token="t")
    app = create_app(settings, model_builder=lambda s, **kw: SpyModel(responder=responder))
    with TestClient(app) as c:
        c.headers["authorization"] = "Bearer t"
        sid = c.post("/v1/sessions", json={"prompt": "hi"}).json()["id"]
        wait_for(c, sid)
    assert "always use tabs" in seen["system"]
    assert "release-notes" in seen["system"]
    for name in ("write_todos", "execute", "read_file", "task", "subagent", "job_start", "schedule_create",
                 "ask_user_question", "exit_plan_mode", "create_goal", "present", "web_fetch",
                 "request_escalated_execute", "compact_conversation"):
        assert name in seen["tools"], name
