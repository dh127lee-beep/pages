"""Background jobs (harness: packages/jobs, docs/subsystems/jobs.md).

`job_start` runs a shell command in the background under the session's sandbox; `job_list`,
`job_output` and `job_kill` control it. Ids look like `shell-<16hex>`. On settlement the owner
session receives a non-waking notice that lands in its next request (harness `agent.inject()`).
"""

from __future__ import annotations

import asyncio
import os
import signal
import time
import uuid
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Literal

from langchain.tools import ToolRuntime
from langchain_core.tools import BaseTool, StructuredTool
from pydantic import BaseModel, Field

from .middleware import thread_id_of
from .sandbox import safe_env, wrap_command

JobStatus = Literal["running", "stopping", "completed", "killed", "failed"]


@dataclass
class Job:
    id: str
    owner: str
    command: str
    description: str
    log_path: Path
    status: JobStatus = "running"
    exit_code: int | None = None
    started_at: float = field(default_factory=time.time)
    ended_at: float | None = None
    proc: asyncio.subprocess.Process | None = None
    done: asyncio.Event = field(default_factory=asyncio.Event)

    def summary(self) -> dict:
        return {"job_id": self.id, "status": self.status, "exit_code": self.exit_code,
                "description": self.description, "command": self.command,
                "started_at": self.started_at, "ended_at": self.ended_at}


class JobManager:
    def __init__(self, root: Path, *, max_per_owner: int,
                 on_settled: Callable[[Job], None], on_event: Callable[[str, str, dict], None]) -> None:
        self.root = root
        root.mkdir(parents=True, exist_ok=True)
        self.max_per_owner = max_per_owner
        self.on_settled = on_settled
        self.on_event = on_event
        self.jobs: dict[str, Job] = {}

    def owned(self, owner: str) -> list[Job]:
        return [j for j in self.jobs.values() if j.owner == owner]

    async def start(self, owner: str, command: str, description: str, *, mode: str, workspace: Path) -> Job:
        running = [j for j in self.owned(owner) if j.status in ("running", "stopping")]
        if len(running) >= self.max_per_owner:
            raise RuntimeError(f"job limit reached ({self.max_per_owner} running); kill one first")
        wrapped = wrap_command(command, mode, [workspace], workspace)  # type: ignore[arg-type]
        if wrapped is None:
            raise RuntimeError(f"[sandbox: SANDBOX_UNAVAILABLE] cannot confine a job under '{mode}' mode")
        job_id = f"shell-{uuid.uuid4().hex[:16]}"
        job = Job(id=job_id, owner=owner, command=command, description=description,
                  log_path=self.root / f"{job_id}.log")
        log = job.log_path.open("wb")
        job.proc = await asyncio.create_subprocess_shell(
            wrapped, cwd=workspace, env=safe_env(), stdout=log, stderr=asyncio.subprocess.STDOUT,
            stdin=asyncio.subprocess.DEVNULL, start_new_session=True)
        log.close()
        self.jobs[job_id] = job
        self.on_event(owner, "job/registered", job.summary())
        asyncio.create_task(self._watch(job))
        return job

    async def _watch(self, job: Job) -> None:
        assert job.proc is not None
        code = await job.proc.wait()
        job.exit_code = code
        job.ended_at = time.time()
        if job.status == "stopping":
            job.status = "killed"
        else:
            job.status = "completed" if code == 0 else "failed"
        job.done.set()
        self.on_event(job.owner, "job/settled", job.summary())
        self.on_settled(job)

    def tail(self, job: Job, max_bytes: int = 16_000) -> str:
        data = job.log_path.read_bytes() if job.log_path.exists() else b""
        text = data[-max_bytes:].decode("utf-8", errors="replace")
        prefix = f"…[{len(data) - max_bytes} earlier bytes in {job.log_path}]…\n" if len(data) > max_bytes else ""
        return prefix + text

    async def kill(self, job: Job) -> None:
        if job.proc and job.status == "running":
            job.status = "stopping"
            try:
                os.killpg(job.proc.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            try:
                await asyncio.wait_for(job.done.wait(), 5)
            except TimeoutError:
                os.killpg(job.proc.pid, signal.SIGKILL)

    async def shutdown(self) -> None:
        for job in list(self.jobs.values()):
            await self.kill(job)


class JobStartInput(BaseModel):
    command: str = Field(description="Shell command to run in the background (sandboxed).")
    description: str = Field(description="Short description of what the job does.")


class JobOutputInput(BaseModel):
    job_id: str
    wait: bool = Field(default=False, description="Wait for the job to finish (up to timeout_ms).")
    timeout_ms: int = Field(default=30_000, ge=0, le=600_000)


class JobKillInput(BaseModel):
    job_id: str
    reason: str | None = None


def job_tools(manager: JobManager, *, mode_of: Callable[[str], str], workspace: Path) -> list[BaseTool]:
    def _get(owner: str, job_id: str) -> Job:
        job = manager.jobs.get(job_id)
        if job is None or job.owner != owner:
            raise KeyError(job_id)
        return job

    async def job_start(runtime: ToolRuntime, command: str, description: str) -> str:
        owner = thread_id_of(runtime)
        try:
            job = await manager.start(owner, command, description, mode=mode_of(owner), workspace=workspace)
        except RuntimeError as e:
            return f"Error: {e}"
        return f"Started {job.id}. Use job_output to read its output; you will be notified when it settles."

    async def job_list(runtime: ToolRuntime) -> list[dict]:
        return [j.summary() for j in manager.owned(thread_id_of(runtime))]

    async def job_output(runtime: ToolRuntime, job_id: str, wait: bool = False, timeout_ms: int = 30_000) -> str:
        try:
            job = _get(thread_id_of(runtime), job_id)
        except KeyError:
            return f"Error: unknown job {job_id}"
        if wait and job.status == "running":
            try:
                await asyncio.wait_for(job.done.wait(), timeout_ms / 1000)
            except TimeoutError:
                pass
        return f"[status: {job.status}, exit code: {job.exit_code}]\n{manager.tail(job)}"

    async def job_kill(runtime: ToolRuntime, job_id: str, reason: str | None = None) -> str:
        try:
            job = _get(thread_id_of(runtime), job_id)
        except KeyError:
            return f"Error: unknown job {job_id}"
        await manager.kill(job)
        return f"{job_id}: {job.status}"

    return [
        StructuredTool.from_function(name="job_start", coroutine=job_start, args_schema=JobStartInput, infer_schema=False,
                                     description="Run a long-running shell command in the background."),
        StructuredTool.from_function(name="job_list", coroutine=job_list,
                                     description="List this session's background jobs."),
        StructuredTool.from_function(name="job_output", coroutine=job_output, args_schema=JobOutputInput, infer_schema=False,
                                     description="Read a background job's output tail, optionally waiting for it to finish."),
        StructuredTool.from_function(name="job_kill", coroutine=job_kill, args_schema=JobKillInput, infer_schema=False,
                                     description="Stop a background job."),
    ]
