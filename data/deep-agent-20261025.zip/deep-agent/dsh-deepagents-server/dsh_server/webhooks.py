"""Webhook-started sessions (harness: docs/subsystems/webhook.md).

Fire-and-forget like the harness: a verified delivery is matched against rules; the first
matching rule creates a new root session with the rendered prompt. No queue, retry or dedupe.

Rules file (YAML):

    rules:
      - name: triage-issues
        source: github            # github: X-Hub-Signature-256 | generic: X-DSH-Signature
        secret_env: GITHUB_WEBHOOK_SECRET
        events: [issues]          # github only (X-GitHub-Event)
        actions: [opened]         # optional, payload["action"]
        preset: read-only
        prompt: "Triage issue #{issue[number]}: {issue[title]}\\n\\n{issue[body]}"
"""

from __future__ import annotations

import hashlib
import hmac
import os
import string
from pathlib import Path
from typing import Any

import yaml


class _Payload(dict):
    def __missing__(self, key: str) -> str:
        return ""


def load_rules(path: Path | None) -> list[dict[str, Any]]:
    if path is None or not path.exists():
        return []
    return yaml.safe_load(path.read_text()).get("rules", [])


def verify(rule: dict[str, Any], body: bytes, headers: dict[str, str]) -> bool:
    secret = os.environ.get(rule.get("secret_env", ""), "")
    if not secret:
        return False  # fail closed: a rule without a secret never fires
    header = "x-hub-signature-256" if rule.get("source") == "github" else "x-dsh-signature"
    expected = "sha256=" + hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, headers.get(header, ""))


def match(rule: dict[str, Any], source: str, payload: dict[str, Any], headers: dict[str, str]) -> bool:
    if rule.get("source", "generic") != source:
        return False
    if source == "github" and rule.get("events") and headers.get("x-github-event") not in rule["events"]:
        return False
    if rule.get("actions") and payload.get("action") not in rule["actions"]:
        return False
    return True


def render(rule: dict[str, Any], payload: dict[str, Any]) -> str:
    # Formatter with item access only; attribute access ("{x.__class__}") is rejected.
    template = rule["prompt"]
    for _, field_name, _, _ in string.Formatter().parse(template):
        if field_name and "." in field_name:
            raise ValueError("attribute access is not allowed in webhook prompts")
    return template.format_map(_Payload(payload))
