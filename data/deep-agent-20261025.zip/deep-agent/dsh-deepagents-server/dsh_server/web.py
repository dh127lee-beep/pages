"""`web_fetch` / `web_search` (harness: packages/web) and MCP servers (harness: packages/mcp).

On a server, `web_fetch` is an SSRF vector: by default it refuses loopback, private,
link-local and metadata addresses, re-checking every redirect hop.
"""

from __future__ import annotations

import asyncio
import ipaddress
import json
import logging
import re
import socket
from html import unescape
from pathlib import Path
from urllib.parse import urljoin, urlparse

import httpx
from langchain_core.tools import BaseTool, StructuredTool
from pydantic import BaseModel, Field

log = logging.getLogger(__name__)
MAX_FETCH_BYTES = 2_000_000
_MCP_NAME = re.compile(r"^[A-Za-z0-9_-]{1,32}$")


class WebFetchInput(BaseModel):
    url: str = Field(description="http(s) URL to fetch")


class WebSearchInput(BaseModel):
    queries: list[str] = Field(min_length=1, max_length=5)


async def _assert_public(url: str) -> None:
    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https") or not parsed.hostname:
        raise ValueError("only http(s) URLs are allowed")
    infos = await asyncio.get_running_loop().getaddrinfo(parsed.hostname, parsed.port or 443, type=socket.SOCK_STREAM)
    for info in infos:
        ip = ipaddress.ip_address(info[4][0])
        if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved or ip.is_multicast or ip.is_unspecified:
            raise ValueError(f"refusing to fetch non-public address {ip}")


def _html_to_text(html: str) -> str:
    html = re.sub(r"(?is)<(script|style|noscript).*?</\1>", " ", html)
    html = re.sub(r"(?i)<br\s*/?>|</(p|div|h\d|li|tr)>", "\n", html)
    text = unescape(re.sub(r"<[^>]+>", " ", html))
    return re.sub(r"\n\s*\n+", "\n\n", re.sub(r"[ \t]+", " ", text)).strip()


def web_tools(*, allow_private: bool, tavily_api_key: str) -> list[BaseTool]:
    async def web_fetch(url: str) -> str:
        async with httpx.AsyncClient(timeout=30, follow_redirects=False,
                                     headers={"user-agent": "dsh-deepagents-server/0.1"}) as client:
            for _ in range(5):
                if not allow_private:
                    try:
                        await _assert_public(url)
                    except ValueError as e:
                        return f"Error: {e}"
                resp = await client.get(url)
                if resp.is_redirect and "location" in resp.headers:
                    url = urljoin(url, resp.headers["location"])
                    continue
                body = resp.content[:MAX_FETCH_BYTES].decode(resp.encoding or "utf-8", errors="replace")
                if "html" in resp.headers.get("content-type", ""):
                    body = _html_to_text(body)
                return f"[{resp.status_code} {url}]\n{body}"
        return "Error: too many redirects"

    tools: list[BaseTool] = [StructuredTool.from_function(
        name="web_fetch", coroutine=web_fetch, args_schema=WebFetchInput, infer_schema=False,
        description="Fetch a public web page and return it as text.")]

    if tavily_api_key:
        async def web_search(queries: list[str]) -> str:
            async with httpx.AsyncClient(timeout=60) as client:
                results = []
                for q in queries:
                    r = await client.post("https://api.tavily.com/search",
                                          json={"api_key": tavily_api_key, "query": q, "max_results": 5})
                    r.raise_for_status()
                    results.append({"query": q, "results": [
                        {"title": x.get("title"), "url": x.get("url"), "snippet": x.get("content")}
                        for x in r.json().get("results", [])]})
            return json.dumps(results, ensure_ascii=False)

        tools.append(StructuredTool.from_function(
            name="web_search", coroutine=web_search, args_schema=WebSearchInput, infer_schema=False,
            description="Search the web. Returns titles, URLs and snippets per query."))
    return tools


async def load_mcp_tools(config_path: Path | None) -> list[BaseTool]:
    """Load tools from `{"servers": {name: connection}}` and name them `mcp__<server>__<tool>`.

    Connection entries use langchain-mcp-adapters' format, e.g.
    `{"transport": "stdio", "command": "npx", "args": [...]}` or
    `{"transport": "streamable_http", "url": "https://..."}`.
    """
    if config_path is None or not config_path.exists():
        return []
    from langchain_mcp_adapters.client import MultiServerMCPClient

    servers: dict = json.loads(config_path.read_text()).get("servers", {})
    bad = [n for n in servers if not _MCP_NAME.match(n)]
    if bad:
        raise ValueError(f"MCP server names must match [A-Za-z0-9_-]{{1,32}}: {bad}")
    client = MultiServerMCPClient(servers)
    tools: list[BaseTool] = []
    for name in servers:
        try:
            for tool in await client.get_tools(server_name=name):
                tool.name = f"mcp__{name}__{tool.name}"
                tools.append(tool)
        except Exception:  # noqa: BLE001 - one broken server must not take the agent down
            log.exception("MCP server %s failed to load", name)
    return tools
