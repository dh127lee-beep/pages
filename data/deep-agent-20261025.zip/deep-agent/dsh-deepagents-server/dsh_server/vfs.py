"""Virtual file system for sessions that may not touch the host or run code.

Files live in the LangGraph store (SQLite), one namespace per *workspace*:
`("vfs", <workspace id>)`, key = virtual path such as `/report.docx`. The value format is the
one deepagents' `StoreBackend` uses (`content` + `encoding` utf-8|base64 + timestamps), so the
model's ordinary file tools (`ls`, `read_file`, `write_file`, `glob`, `grep`, `delete`) and the
office tools see the same files.

Server-side code that needs real paths (genoffice) gets a private temporary copy through
`materialize()` and writes results back with `sync_back()`; nothing outside the temp directory
is reachable, and the directory is deleted after the call.
"""

from __future__ import annotations

import asyncio
import base64
import hashlib
import os
import posixpath
import shutil
import stat
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

#: Virtual prefixes served by other backends; user files may not be written there.
RESERVED_PREFIXES = ("/templates/", "/_skills/", "/large_tool_results/", "/conversation_history/", "/memories/")
TEMPLATES_PREFIX = "/templates/"
MAX_PATH = 400


class VFSError(ValueError):
    """A user-facing problem with a virtual path or quota (message is safe to show)."""


def normalize(path: str, *, allow_reserved: bool = False) -> str:
    if not isinstance(path, str) or not path.strip():
        raise VFSError("empty path")
    if "\x00" in path or "\\" in path or len(path) > MAX_PATH:
        raise VFSError(f"invalid path: {path!r}")
    raw = path if path.startswith("/") else "/" + path
    if ".." in raw.split("/"):
        raise VFSError(f"'..' is not allowed in paths: {path!r}")
    norm = posixpath.normpath(raw)
    if norm in ("/", "."):
        raise VFSError("a file path is required, not the root folder")
    if not allow_reserved and any((norm + "/").startswith(p) for p in RESERVED_PREFIXES):
        raise VFSError(f"{norm} is in a read-only system folder")
    return norm


def _decode(value: dict[str, Any]) -> bytes:
    content = value.get("content", "")
    if isinstance(content, list):  # legacy deepagents format
        content = "\n".join(content)
    if value.get("encoding") == "base64":
        return base64.standard_b64decode(content)
    return content.encode("utf-8")


def _encode(data: bytes, created_at: str | None = None) -> dict[str, Any]:
    now = datetime.now(timezone.utc).isoformat()
    try:
        content, encoding = data.decode("utf-8"), "utf-8"
    except UnicodeDecodeError:
        content, encoding = base64.standard_b64encode(data).decode("ascii"), "base64"
    return {"content": content, "encoding": encoding, "created_at": created_at or now, "modified_at": now}


def _size(value: dict[str, Any]) -> int:
    content = value.get("content", "")
    if isinstance(content, list):
        content = "\n".join(content)
    if value.get("encoding") == "base64":
        return len(content) * 3 // 4
    return len(content.encode("utf-8"))


class VFS:
    def __init__(self, store: Any, *, quota_bytes: int, max_file_bytes: int, templates_dir: Path | None) -> None:
        self.store = store
        self.quota_bytes = quota_bytes
        self.max_file_bytes = max_file_bytes
        self.templates_dir = templates_dir if templates_dir and templates_dir.is_dir() else None
        self._locks: dict[str, asyncio.Lock] = defaultdict(asyncio.Lock)

    @staticmethod
    def namespace(workspace: str) -> tuple[str, ...]:
        return ("vfs", workspace)

    def lock(self, workspace: str) -> asyncio.Lock:
        """Serialize materialize→run→sync cycles per workspace (parallel tool calls)."""
        return self._locks[workspace]

    async def _items(self, workspace: str) -> list[Any]:
        items, offset = [], 0
        while True:
            page = await self.store.asearch(self.namespace(workspace), limit=500, offset=offset)
            items += page
            if len(page) < 500:
                return items
            offset += 500

    async def list(self, workspace: str) -> list[dict[str, Any]]:
        out = [{"path": it.key, "size": _size(it.value), "modified_at": it.value.get("modified_at"),
                "binary": it.value.get("encoding") == "base64"} for it in await self._items(workspace)]
        return sorted(out, key=lambda f: f["path"])

    def list_templates(self) -> list[dict[str, Any]]:
        if not self.templates_dir:
            return []
        return [{"path": TEMPLATES_PREFIX + p.relative_to(self.templates_dir).as_posix(), "size": p.stat().st_size,
                 "read_only": True} for p in sorted(self.templates_dir.rglob("*")) if p.is_file()]

    async def usage(self, workspace: str) -> int:
        return sum(_size(it.value) for it in await self._items(workspace))

    async def read(self, workspace: str, path: str) -> bytes | None:
        path = normalize(path, allow_reserved=True)
        if path.startswith(TEMPLATES_PREFIX):
            return self._read_template(path)
        item = await self.store.aget(self.namespace(workspace), path)
        return _decode(item.value) if item else None

    def _read_template(self, path: str) -> bytes | None:
        if not self.templates_dir:
            return None
        target = (self.templates_dir / path[len(TEMPLATES_PREFIX):]).resolve()
        root = self.templates_dir.resolve()
        if root not in target.parents or not target.is_file():
            return None
        return target.read_bytes()

    async def write(self, workspace: str, path: str, data: bytes) -> str:
        path = normalize(path)
        if len(data) > self.max_file_bytes:
            raise VFSError(f"{path} is {len(data):,} bytes; the limit per file is {self.max_file_bytes:,}")
        existing = await self.store.aget(self.namespace(workspace), path)
        used = await self.usage(workspace) - (_size(existing.value) if existing else 0)
        if used + len(data) > self.quota_bytes:
            raise VFSError(f"storage is full ({used:,} of {self.quota_bytes:,} bytes used)")
        await self.store.aput(self.namespace(workspace), path,
                              _encode(data, existing.value.get("created_at") if existing else None))
        return path

    async def delete(self, workspace: str, path: str) -> bool:
        path = normalize(path)
        if await self.store.aget(self.namespace(workspace), path) is None:
            return False
        await self.store.adelete(self.namespace(workspace), path)
        return True

    async def copy_all(self, src: str, dst: str) -> int:
        items = await self._items(src)
        for it in items:
            await self.store.aput(self.namespace(dst), it.key, dict(it.value))
        return len(items)

    # ---- bridge for host-path tools -------------------------------------------------------

    async def materialize(self, workspace: str, dest: Path) -> dict[str, str]:
        """Copy the workspace (and read-only templates) into `dest`; return {vpath: sha256}."""
        manifest: dict[str, str] = {}
        for it in await self._items(workspace):
            data = _decode(it.value)
            target = dest / it.key.lstrip("/")
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
            manifest[it.key] = hashlib.sha256(data).hexdigest()
        if self.templates_dir:
            tdest = dest / TEMPLATES_PREFIX.strip("/")
            shutil.copytree(self.templates_dir, tdest)
            # read-only copy: a tool that tries to write into /templates fails instead of silently
            # producing a change we would drop.
            for root, dirs, files in os.walk(tdest):
                for f in files:
                    os.chmod(os.path.join(root, f), stat.S_IRUSR)
                os.chmod(root, stat.S_IRUSR | stat.S_IXUSR)
        return manifest

    async def sync_back(self, workspace: str, src: Path, manifest: dict[str, str]) -> list[str]:
        """Write new or changed files from `src` back into the workspace. Returns changed paths."""
        changed: list[tuple[str, bytes]] = []
        for path in sorted(src.rglob("*")):
            if not path.is_file() or path.is_symlink():
                continue
            vpath = "/" + path.relative_to(src).as_posix()
            if any((vpath + "/").startswith(p) or vpath.startswith(p) for p in RESERVED_PREFIXES):
                continue
            data = path.read_bytes()
            if manifest.get(vpath) != hashlib.sha256(data).hexdigest():
                changed.append((vpath, data))
        for vpath, data in changed:
            await self.write(workspace, vpath, data)
        return [p for p, _ in changed]

    @staticmethod
    def restore_permissions(dest: Path) -> None:
        """Make the read-only template copy deletable again before the temp dir is removed."""
        tdest = dest / TEMPLATES_PREFIX.strip("/")
        if tdest.exists():
            for root, _dirs, files in os.walk(tdest):
                os.chmod(root, stat.S_IRWXU)
                for f in files:
                    os.chmod(os.path.join(root, f), stat.S_IRUSR | stat.S_IWUSR)
