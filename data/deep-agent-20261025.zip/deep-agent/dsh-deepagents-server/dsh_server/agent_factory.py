"""Compose one deepagents graph per (preset, model, effort, role).

This is where the harness's plugin tree is flattened into a deepagents call:

    harness plugin / subsystem          ->  deepagents / LangChain piece
    ----------------------------------------------------------------------------
    llm-deepseek (Messages protocol)    ->  ChatAnthropic(base_url=.../anthropic)
    fs tools read/write/edit/glob/grep  ->  FilesystemMiddleware (built in)
    bash + sandbox backends             ->  SandboxedShellBackend.execute
    spill-policy (12.5k tokens)         ->  FilesystemMiddleware(tool_token_limit_before_evict)
    compaction-basic                    ->  SummarizationMiddleware (+ pruner, + compact tool)
    todo_write                          ->  TodoListMiddleware (write_todos)
    skills / AGENTS.md                  ->  SkillsMiddleware / MemoryMiddleware
    approval + permission presets       ->  FilesystemPermission + interrupt_on (HITL)
    plan, goal, ask-user, present,      ->  custom middleware in middleware.py
      guards, runtime context
    jobs, schedule, web, mcp            ->  plain tools (jobs.py, schedule.py, web.py)
    subagent (async, steerable)         ->  SubagentManager tools (runner.py)
    task (sync delegation)              ->  deepagents general-purpose subagent
"""

from __future__ import annotations

import asyncio
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any

from deepagents import FilesystemMiddleware, FilesystemPermission, create_deep_agent
from deepagents.backends import CompositeBackend, FilesystemBackend, StoreBackend
from deepagents.middleware import SummarizationMiddleware, SummarizationToolMiddleware
from langchain.agents.middleware import AgentMiddleware, ModelRequest, ModelResponse, TodoListMiddleware
from langchain_core.language_models import BaseChatModel
from langchain_core.messages import ToolMessage
from langchain_core.tools import BaseTool, StructuredTool
from langgraph.config import get_config
from pydantic import BaseModel, Field

from .config import Settings
from .middleware import (
    GoalMiddleware,
    InteractionMiddleware,
    PlanModeMiddleware,
    ReadBeforeWriteMiddleware,
    RepeatToolReminderMiddleware,
    RuntimeContextMiddleware,
    ToolResultPrunerMiddleware,
)
from .permissions import HOME_PREFIX, WRITE_TOOLS, DenyToolsMiddleware, get_preset
from .prompts import COMPACTION_PROMPT, SUBAGENT_SUFFIX, SYSTEM_PROMPT
from .office import OFFICE_SYSTEM_PROMPT, OfficeGuardMiddleware
from .sandbox import SandboxedShellBackend
from .vfs import TEMPLATES_PREFIX, VFS

try:
    from genoffice.integrations.deepagents import SKILLS_DIR as GENOFFICE_SKILLS_DIR
except ImportError:  # pragma: no cover
    GENOFFICE_SKILLS_DIR = None

SPILL_PREFIX = "/large_tool_results/"
HISTORY_PREFIX = "/conversation_history/"
MEMORIES_PREFIX = "/memories/"
SKILLS_PREFIX = "/_skills/"
ROUTED_PREFIXES = (HOME_PREFIX, SPILL_PREFIX, HISTORY_PREFIX, MEMORIES_PREFIX)


@dataclass(frozen=True)
class AgentKey:
    preset: str
    model: str
    effort: str
    role: str  # "root" | "subagent"
    profile: str = "dev"  # "dev" | "office"


class EscalatedExecuteInput(BaseModel):
    command: str
    sandbox_permissions: str = Field(description="'workspace-write' or 'danger-full-access'")
    justification: str = Field(description="Why the command needs wider permissions. Shown to the user.")
    timeout: int | None = Field(default=None, ge=1, le=600)


def escalation_tool(settings: Settings) -> BaseTool:
    """Harness `sandbox_permissions` + `justification` escalation, as a separate tool.

    It is always listed in `interrupt_on`, so it only runs after a human approves the exact call.
    """

    async def request_escalated_execute(command: str, sandbox_permissions: str, justification: str,
                                        timeout: int | None = None) -> str:
        if sandbox_permissions not in ("workspace-write", "danger-full-access"):
            return "Error: sandbox_permissions must be 'workspace-write' or 'danger-full-access'"
        backend = SandboxedShellBackend(settings.workspace, mode=sandbox_permissions,  # type: ignore[arg-type]
                                        timeout=settings.shell_timeout_s, max_output_bytes=settings.shell_max_output_bytes)
        result = await asyncio.to_thread(backend.execute, command, timeout=timeout)
        return f"{result.output}\n[exit code: {result.exit_code}]"

    return StructuredTool.from_function(
        name="request_escalated_execute", coroutine=request_escalated_execute, args_schema=EscalatedExecuteInput,
        infer_schema=False,
        description="Run one shell command with wider sandbox permissions after the user approves it. "
                    "Use only after `execute` failed because of the sandbox.")


class ExcludeToolsMiddleware(AgentMiddleware):
    """Hide tools from a role (subagents may not delegate further: harness maxDepth 1)."""

    def __init__(self, excluded: frozenset[str]) -> None:
        super().__init__()
        self.excluded = excluded

    async def awrap_model_call(self, request: ModelRequest, handler: Callable) -> ModelResponse:
        tools = [t for t in request.tools if (t.get("name") if isinstance(t, dict) else t.name) not in self.excluded]
        return await handler(request.override(tools=tools))

    async def awrap_tool_call(self, request: Any, handler: Callable) -> Any:
        if request.tool_call["name"] in self.excluded:
            return ToolMessage(f"Error: `{request.tool_call['name']}` is not available here.",
                               tool_call_id=request.tool_call["id"], status="error")
        return await handler(request)


class AgentFactory:
    def __init__(self, settings: Settings, *, checkpointer: Any, store: Any,
                 model_builder: Callable[..., BaseChatModel],
                 root_tools: Callable[[], list[BaseTool]], shared_tools: Callable[[], list[BaseTool]],
                 office: Any = None, workspace_of: Callable[[str], str] | None = None,
                 office_shared_tools: Callable[[], list[BaseTool]] = list) -> None:
        self.settings = settings
        self.office = office  # OfficeToolkit, when genoffice is installed
        self.workspace_of = workspace_of or (lambda sid: sid)
        self.office_shared_tools = office_shared_tools
        self.checkpointer = checkpointer
        self.store = store
        self.model_builder = model_builder
        self.root_tools = root_tools
        self.shared_tools = shared_tools
        self._cache: dict[AgentKey, Any] = {}

    def preset_mode(self, preset: str) -> str:
        return get_preset(preset).sandbox

    def get(self, key: AgentKey) -> Any:
        if key not in self._cache:
            self._cache[key] = self._build(key)
        return self._cache[key]

    def backend(self, preset: str) -> CompositeBackend:
        s = self.settings
        user_dir = s.home / "user"
        for d in (user_dir / "skills", s.data_dir / "spill", s.data_dir / "history"):
            d.mkdir(parents=True, exist_ok=True)
        shell = SandboxedShellBackend(s.workspace, mode=get_preset(preset).sandbox,  # type: ignore[arg-type]
                                      timeout=s.shell_timeout_s, max_output_bytes=s.shell_max_output_bytes)
        return CompositeBackend(default=shell, routes={
            HOME_PREFIX: FilesystemBackend(root_dir=user_dir, virtual_mode=True),
            SPILL_PREFIX: FilesystemBackend(root_dir=s.data_dir / "spill", virtual_mode=True),
            HISTORY_PREFIX: FilesystemBackend(root_dir=s.data_dir / "history", virtual_mode=True),
            MEMORIES_PREFIX: StoreBackend(namespace=lambda _rt: ("memories",), store=self.store),
        })

    def _build(self, key: AgentKey) -> Any:
        if key.profile == "office":
            return self._build_office(key)
        s = self.settings
        preset = get_preset(key.preset)
        model = self.model_builder(s, effort=key.effort, model=key.model)
        backend = self.backend(key.preset)
        fs_permissions = preset.fs_permissions()
        trigger = s.compaction_trigger_tokens()

        summarization = SummarizationMiddleware(
            model, backend=backend, trigger=("tokens", trigger), keep=("tokens", s.compaction_keep_tokens()),
            summary_prompt=COMPACTION_PROMPT)

        tools: list[BaseTool] = [*self.shared_tools()]
        if preset.approval == "ask":
            tools.append(escalation_tool(s))
        if key.role == "root":
            tools += self.root_tools()

        middleware: list[AgentMiddleware] = [
            # Replace deepagents defaults by name with harness-tuned instances.
            FilesystemMiddleware(backend=backend, permissions=fs_permissions or None,
                                 tool_token_limit_before_evict=s.spill_max_inline_tokens,
                                 max_execute_timeout=s.shell_max_timeout_s),
            summarization,
            # New capabilities.
            SummarizationToolMiddleware(summarization),
            TodoListMiddleware(),
            PlanModeMiddleware(),
            GoalMiddleware(s.default_max_goal_rounds),
            InteractionMiddleware(),
            ToolResultPrunerMiddleware(start_tokens=trigger // 2, max_chars=s.prune_tool_result_chars,
                                       head=s.prune_head_chars, tail=s.prune_tail_chars),
            RepeatToolReminderMiddleware(),
            ReadBeforeWriteMiddleware(s.workspace, ROUTED_PREFIXES),
            RuntimeContextMiddleware(s.workspace, key.preset),
        ]
        if preset.sandbox == "read-only":
            middleware.append(DenyToolsMiddleware(WRITE_TOOLS, "the session is in the read-only permission preset."))
        prompt = SYSTEM_PROMPT
        if key.role == "subagent":
            prompt += SUBAGENT_SUFFIX
            middleware.append(ExcludeToolsMiddleware(frozenset({"task", "create_goal", "update_goal"})))

        return create_deep_agent(
            model=model,
            tools=tools,
            system_prompt=prompt,
            middleware=middleware,
            skills=[f"{HOME_PREFIX}skills/", "/.agents/skills/", "/.dsh/skills/"],
            memory=[f"{HOME_PREFIX}AGENTS.md", "/AGENTS.md"],
            permissions=fs_permissions or None,
            backend=backend,
            interrupt_on=preset.interrupt_on(s.always_ask_tools) or None,
            checkpointer=self.checkpointer,
            store=self.store,
            name=f"dsh-{key.role}",
        )

    # ------------------------------------------------------------------ office / VFS profile

    def office_backend(self) -> CompositeBackend:
        """Everything is virtual: user files in the store, per-workspace spill/history, read-only
        templates and the genoffice skill. No backend can execute commands, so `execute` never
        appears and deepagents' path permissions apply everywhere."""

        def workspace() -> str:
            return self.workspace_of(str(get_config().get("configurable", {}).get("thread_id", "default")))

        routes: dict[str, Any] = {
            SPILL_PREFIX: StoreBackend(namespace=lambda _rt: ("vfs-spill", workspace()), store=self.store),
            HISTORY_PREFIX: StoreBackend(namespace=lambda _rt: ("vfs-history", workspace()), store=self.store),
            SKILLS_PREFIX: FilesystemBackend(root_dir=GENOFFICE_SKILLS_DIR, virtual_mode=True),
        }
        if self.settings.office_templates_dir and self.settings.office_templates_dir.is_dir():
            routes[TEMPLATES_PREFIX] = FilesystemBackend(root_dir=self.settings.office_templates_dir, virtual_mode=True)
        return CompositeBackend(
            default=StoreBackend(namespace=lambda _rt: VFS.namespace(workspace()), store=self.store), routes=routes)

    def _build_office(self, key: AgentKey) -> Any:
        if self.office is None:
            raise RuntimeError("the office profile needs genoffice-py installed")
        s = self.settings
        preset = get_preset(key.preset)
        model = self.model_builder(s, effort=key.effort, model=key.model)
        backend = self.office_backend()
        trigger = s.compaction_trigger_tokens()
        permissions = [FilesystemPermission(operations=["write"], paths=[f"{TEMPLATES_PREFIX}**", f"{SKILLS_PREFIX}**"],
                                            mode="deny")]
        if preset.sandbox == "read-only":
            permissions.append(FilesystemPermission(operations=["write"], paths=["/**"], mode="deny"))
        summarization = SummarizationMiddleware(
            model, backend=backend, trigger=("tokens", trigger), keep=("tokens", s.compaction_keep_tokens()),
            summary_prompt=COMPACTION_PROMPT)

        tools: list[BaseTool] = [*self.office.tools(), *self.office_shared_tools()]
        if key.role == "root":
            tools += self.root_tools()
        middleware: list[AgentMiddleware] = [
            FilesystemMiddleware(backend=backend, permissions=permissions,
                                 tool_token_limit_before_evict=s.spill_max_inline_tokens),
            summarization,
            SummarizationToolMiddleware(summarization),
            TodoListMiddleware(),
            PlanModeMiddleware(extra_mutating=self.office.mutating),
            GoalMiddleware(s.default_max_goal_rounds),
            InteractionMiddleware(),
            ToolResultPrunerMiddleware(start_tokens=trigger // 2, max_chars=s.prune_tool_result_chars,
                                       head=s.prune_head_chars, tail=s.prune_tail_chars),
            RepeatToolReminderMiddleware(),
            RuntimeContextMiddleware("/ (virtual workspace; files panel)", key.preset),  # type: ignore[arg-type]
            OfficeGuardMiddleware(deny_mutating=self.office.mutating if preset.sandbox == "read-only" else frozenset()),
        ]
        prompt = OFFICE_SYSTEM_PROMPT
        if key.role == "subagent":
            prompt += SUBAGENT_SUFFIX
            middleware.append(ExcludeToolsMiddleware(frozenset({"task", "create_goal", "update_goal"})))
        # Non-developers get a confirmation before files are deleted (unless the preset never asks).
        interrupt_on = {} if preset.approval == "never" else {"delete": {"allowed_decisions": ["approve", "reject"]}}
        return create_deep_agent(
            model=model,
            tools=tools,
            system_prompt=prompt,
            middleware=middleware,
            skills=[SKILLS_PREFIX],
            permissions=permissions,
            backend=backend,
            interrupt_on=interrupt_on or None,
            checkpointer=self.checkpointer,
            store=self.store,
            name=f"dsh-office-{key.role}",
        )
