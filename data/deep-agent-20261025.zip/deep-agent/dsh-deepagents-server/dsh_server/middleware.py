"""Harness subsystems that deepagents lacks, written as LangChain `AgentMiddleware`.

Each class names the harness subsystem it reproduces. Middleware that changes what the model
sees does it on the *request* (not on graph state) and appends at the *tail* of the message
list, so the cached prompt prefix stays byte-identical between calls.
"""

from __future__ import annotations

import json
import time
import uuid
from collections import defaultdict
from collections.abc import Awaitable, Callable
from datetime import datetime
from pathlib import Path
from typing import Annotated, Any, Literal

from langchain.agents.middleware import AgentMiddleware, AgentState, ModelRequest, ModelResponse
from langchain.agents.middleware.types import OmitFromInput
from langchain.tools import ToolRuntime
from langchain_core.messages import HumanMessage, ToolMessage
from langchain_core.messages.utils import count_tokens_approximately
from langchain_core.tools import StructuredTool
from langgraph.prebuilt.tool_node import ToolCallRequest
from langgraph.types import Command, interrupt
from pydantic import BaseModel, Field
from typing_extensions import NotRequired, TypedDict

from .prompts import PLAN_MODE_POLICY

ToolHandler = Callable[[ToolCallRequest], Awaitable[ToolMessage | Command]]
ModelHandler = Callable[[ModelRequest], Awaitable[ModelResponse]]

MUTATING_TOOLS = frozenset({"write_file", "edit_file", "delete", "execute", "job_start",
                            "request_escalated_execute", "subagent", "schedule_create"})


def thread_id_of(runtime: Any) -> str:
    config = getattr(runtime, "config", None) or {}
    return str(config.get("configurable", {}).get("thread_id", "default"))


def _tool_error(request: ToolCallRequest, text: str) -> ToolMessage:
    return ToolMessage(content=text, tool_call_id=request.tool_call["id"], name=request.tool_call["name"], status="error")


def _append_tail(request: ModelRequest, text: str) -> ModelRequest:
    return request.override(messages=[*request.messages, HumanMessage(content=text)])


# ---------------------------------------------------------------------------
# Plan mode  (harness: packages/plan, docs/subsystems/plan.md)
# ---------------------------------------------------------------------------


class PlanState(AgentState):
    plan_mode: NotRequired[bool]  # settable via run input by the server (/plan)
    approved_plan: Annotated[NotRequired[str], OmitFromInput]


class ExitPlanModeInput(BaseModel):
    plan: str = Field(description="Decision-complete plan in markdown, starting with a `#` heading.")


async def _exit_plan_mode(runtime: ToolRuntime, plan: str) -> Command | str:
    if not runtime.state.get("plan_mode"):
        return "Error: plan mode is not active."
    if not plan.lstrip().startswith("#"):
        return "Error: the plan must be markdown that starts with a `#` heading."
    answer = interrupt({"type": "plan_review", "plan": plan})
    answer = answer if isinstance(answer, dict) else {"approved": bool(answer)}
    if answer.get("approved"):
        return Command(update={
            "plan_mode": False,
            "approved_plan": plan,
            "messages": [ToolMessage("The user approved the plan. Plan mode is off; implement it now.",
                                     tool_call_id=runtime.tool_call_id)],
        })
    feedback = answer.get("feedback") or "(no feedback given)"
    return Command(update={"messages": [ToolMessage(
        f"The user asked you to keep planning. Feedback: {feedback}",
        tool_call_id=runtime.tool_call_id, status="error")]})


class PlanModeMiddleware(AgentMiddleware):
    """Plan mode. Unlike the harness (prompt guidance only) mutation tools are also *blocked*."""

    state_schema = PlanState

    def __init__(self, extra_mutating: frozenset[str] = frozenset()) -> None:
        super().__init__()
        self.mutating = MUTATING_TOOLS | extra_mutating
        self.tools = [StructuredTool.from_function(
            name="exit_plan_mode", coroutine=_exit_plan_mode, args_schema=ExitPlanModeInput, infer_schema=False,
            description="Submit the finished plan for user review. Only valid while plan mode is active.")]

    async def awrap_model_call(self, request: ModelRequest, handler: ModelHandler) -> ModelResponse:
        if request.state.get("plan_mode"):
            request = _append_tail(request, PLAN_MODE_POLICY)
        return await handler(request)

    async def awrap_tool_call(self, request: ToolCallRequest, handler: ToolHandler) -> ToolMessage | Command:
        if request.state.get("plan_mode") and request.tool_call["name"] in self.mutating:
            return _tool_error(request, "Error: plan mode is active; mutating tools are disabled until "
                                        "the user approves a plan via `exit_plan_mode`.")
        return await handler(request)


# ---------------------------------------------------------------------------
# Goal  (harness: packages/goal, docs/subsystems/goal.md)
# ---------------------------------------------------------------------------


class Goal(TypedDict):
    id: str
    revision: int
    objective: str
    phase: Literal["active", "paused", "blocked", "complete"]
    max_rounds: int
    rounds: int
    blocked_reason: NotRequired[str]


class GoalState(AgentState):
    goal: NotRequired[Goal | None]  # the server advances `rounds` via run input


class CreateGoalInput(BaseModel):
    objective: str = Field(description="The objective to keep working on across turns.")
    max_goal_rounds: int | None = Field(default=None, description="Upper bound on automatic continuation rounds.")


class UpdateGoalInput(BaseModel):
    goal_id: str
    revision: int = Field(description="Revision you last saw; the update fails if the goal changed since.")
    action: Literal["edit", "pause", "resume", "complete", "blocked"]
    objective: str | None = None
    max_goal_rounds: int | None = None
    blocked_reason: str | None = None


class GoalMiddleware(AgentMiddleware):
    """Durable same-session objective with compare-and-set revisions.

    The continuation driver (inject `<goal_round>` while idle) lives in the session runner,
    because it acts *between* graph runs.
    """

    state_schema = GoalState

    def __init__(self, default_max_rounds: int) -> None:
        super().__init__()
        self.default_max_rounds = default_max_rounds
        self.tools = [
            StructuredTool.from_function(
                name="create_goal", coroutine=self._create, args_schema=CreateGoalInput, infer_schema=False,
                description="Create a durable goal the harness keeps working on across turns. "
                            "Only when the user explicitly asks for an ongoing goal."),
            StructuredTool.from_function(
                name="get_goal", coroutine=self._get, infer_schema=True,
                description="Return the current goal (id, revision, phase, rounds)."),
            StructuredTool.from_function(
                name="update_goal", coroutine=self._update, args_schema=UpdateGoalInput, infer_schema=False,
                description="Edit, pause, resume, complete or mark the goal blocked (compare-and-set on revision)."),
        ]

    async def _create(self, runtime: ToolRuntime, objective: str, max_goal_rounds: int | None = None) -> Command | str:
        current = runtime.state.get("goal")
        if current and current["phase"] in ("active", "paused", "blocked"):
            return f"Error: goal {current['id']} already exists (phase {current['phase']}); update it instead."
        goal: Goal = {"id": f"goal-{uuid.uuid4().hex[:12]}", "revision": 1, "objective": objective,
                      "phase": "active", "max_rounds": max_goal_rounds or self.default_max_rounds, "rounds": 0}
        return Command(update={"goal": goal, "messages": [ToolMessage(json.dumps(goal), tool_call_id=runtime.tool_call_id)]})

    async def _get(self, runtime: ToolRuntime) -> str:
        return json.dumps(runtime.state.get("goal") or None)

    async def _update(self, runtime: ToolRuntime, goal_id: str, revision: int, action: str,
                      objective: str | None = None, max_goal_rounds: int | None = None,
                      blocked_reason: str | None = None) -> Command | str:
        goal = runtime.state.get("goal")
        if not goal or goal["id"] != goal_id:
            return "Error: no such goal."
        if goal["revision"] != revision:
            return f"Error: stale revision {revision}; current revision is {goal['revision']}. Call get_goal."
        goal = dict(goal)  # type: ignore[assignment]
        if action == "edit":
            goal["objective"] = objective or goal["objective"]
            goal["max_rounds"] = max_goal_rounds or goal["max_rounds"]
        elif action == "pause":
            goal["phase"] = "paused"
        elif action == "resume":
            goal["phase"] = "active"
        elif action == "complete":
            goal["phase"] = "complete"
        elif action == "blocked":
            if goal["rounds"] < 3:
                return "Error: a goal cannot be marked blocked before round 3; keep trying."
            goal["phase"] = "blocked"
            goal["blocked_reason"] = blocked_reason or "unspecified"
        goal["revision"] += 1
        return Command(update={"goal": goal, "messages": [ToolMessage(json.dumps(goal), tool_call_id=runtime.tool_call_id)]})


# ---------------------------------------------------------------------------
# User questions + deliverables  (harness: interaction/ask-user, deliverables/present)
# ---------------------------------------------------------------------------


class QuestionOption(BaseModel):
    label: str
    description: str | None = None


class Question(BaseModel):
    id: str
    question: str
    header: str | None = None
    options: list[QuestionOption] = Field(default_factory=list)
    multi_select: bool = False


class AskUserInput(BaseModel):
    questions: list[Question] = Field(min_length=1)


class PresentedFile(BaseModel):
    path: str
    description: str | None = None


class PresentInput(BaseModel):
    files: list[PresentedFile] = Field(min_length=1)


class InteractionState(AgentState):
    deliverables: Annotated[NotRequired[list[dict]], OmitFromInput]


async def _ask_user_question(runtime: ToolRuntime, questions: list[Question]) -> str:
    payload = {"type": "user_question", "questions": [q.model_dump() for q in questions]}
    answer = interrupt(payload)
    return json.dumps(answer, ensure_ascii=False)


async def _present(runtime: ToolRuntime, files: list[PresentedFile]) -> Command:
    items = [f.model_dump() for f in files]
    return Command(update={"deliverables": items, "messages": [
        ToolMessage(f"Presented {len(items)} file(s) to the user.", tool_call_id=runtime.tool_call_id)]})


class InteractionMiddleware(AgentMiddleware):
    state_schema = InteractionState

    def __init__(self) -> None:
        super().__init__()
        self.tools = [
            StructuredTool.from_function(
                name="ask_user_question", coroutine=_ask_user_question, args_schema=AskUserInput, infer_schema=False,
                description="Ask the user one or more multiple-choice questions and wait for the answers. "
                            "The user may also answer with free text."),
            StructuredTool.from_function(
                name="present", coroutine=_present, args_schema=PresentInput, infer_schema=False,
                description="Declare the final deliverable files of this task so the user sees them."),
        ]


# ---------------------------------------------------------------------------
# Runtime context  (harness: packages/context — cache-safe PromptContext snapshots)
# ---------------------------------------------------------------------------


class RuntimeContextMiddleware(AgentMiddleware):
    """Append cwd / date / permission preset / goal as a trailing user-role block.

    The harness appends these after history instead of editing the system prompt so the
    prefix cache survives; we do the same, per request, without touching graph state.
    """

    def __init__(self, workspace: Path, preset: str) -> None:
        super().__init__()
        self.workspace = workspace
        self.preset = preset

    async def awrap_model_call(self, request: ModelRequest, handler: ModelHandler) -> ModelResponse:
        lines = [f"workspace: {self.workspace}", f"date: {datetime.now().astimezone():%Y-%m-%d %Z}",
                 f"permission_preset: {self.preset}"]
        goal = request.state.get("goal")
        if goal and goal.get("phase") == "active":
            lines.append(f"active_goal: {goal['objective']} (round {goal['rounds']}/{goal['max_rounds']})")
        return await handler(_append_tail(request, "<runtime_context>\n" + "\n".join(lines) + "\n</runtime_context>"))


# ---------------------------------------------------------------------------
# Loop-hygiene guards  (harness: packages/guard, dsh-fs-observation-policy)
# ---------------------------------------------------------------------------


class RepeatToolReminderMiddleware(AgentMiddleware):
    """Advisory nudge when an identical call repeats 3, 5 and 8 times in one session."""

    THRESHOLDS = (3, 5, 8)

    def __init__(self) -> None:
        super().__init__()
        self._counts: dict[str, dict[str, int]] = defaultdict(lambda: defaultdict(int))

    async def awrap_tool_call(self, request: ToolCallRequest, handler: ToolHandler) -> ToolMessage | Command:
        call = request.tool_call
        key = call["name"] + ":" + json.dumps(call.get("args", {}), sort_keys=True, default=str)
        counts = self._counts[thread_id_of(request.runtime)]
        counts[key] += 1
        result = await handler(request)
        if counts[key] in self.THRESHOLDS and isinstance(result, ToolMessage) and isinstance(result.content, str):
            result.content += (f"\n\n<reminder>You have called `{call['name']}` with identical arguments "
                               f"{counts[key]} times. If it is not making progress, change approach.</reminder>")
        return result


class ReadBeforeWriteMiddleware(AgentMiddleware):
    """Reject edits/overwrites of files not read in this session, or changed since the read."""

    def __init__(self, workspace: Path, routed_prefixes: tuple[str, ...]) -> None:
        super().__init__()
        self.workspace = workspace
        self.routed = routed_prefixes
        self._seen: dict[str, dict[str, float]] = defaultdict(dict)

    def _host(self, vpath: str) -> Path | None:
        if not vpath.startswith("/") or vpath.startswith(self.routed):
            return None
        return self.workspace / vpath.lstrip("/")

    async def awrap_tool_call(self, request: ToolCallRequest, handler: ToolHandler) -> ToolMessage | Command:
        name, args = request.tool_call["name"], request.tool_call.get("args", {})
        vpath = args.get("file_path") if isinstance(args, dict) else None
        host = self._host(vpath) if isinstance(vpath, str) else None
        seen = self._seen[thread_id_of(request.runtime)]
        if host is not None and name in ("edit_file", "write_file") and host.exists():
            recorded = seen.get(str(host))
            if recorded is None:
                return _tool_error(request, f"Error: read {vpath} with read_file before modifying it.")
            if host.stat().st_mtime != recorded:
                return _tool_error(request, f"Error: {vpath} changed since you read it. Read it again first.")
        result = await handler(request)
        if host is not None and name in ("read_file", "edit_file", "write_file") and host.exists():
            if not (isinstance(result, ToolMessage) and result.status == "error"):
                seen[str(host)] = host.stat().st_mtime
        return result


class ToolResultPrunerMiddleware(AgentMiddleware):
    """Compaction pre-pass: shrink old, large tool results before resorting to an LLM summary.

    Harness compaction-basic: results over 8,192 chars become head 4,096 + tail 1,024. We apply
    it to the request only (state keeps the full text) once the context passes `start_tokens`.
    """

    def __init__(self, *, start_tokens: int, max_chars: int, head: int, tail: int, keep_recent: int = 6) -> None:
        super().__init__()
        self.start_tokens, self.max_chars, self.head, self.tail, self.keep_recent = start_tokens, max_chars, head, tail, keep_recent

    async def awrap_model_call(self, request: ModelRequest, handler: ModelHandler) -> ModelResponse:
        messages = request.messages
        if len(messages) > self.keep_recent and count_tokens_approximately(messages) > self.start_tokens:
            cut = len(messages) - self.keep_recent
            pruned = []
            for i, m in enumerate(messages):
                if i < cut and isinstance(m, ToolMessage) and isinstance(m.content, str) and len(m.content) > self.max_chars:
                    dropped = len(m.content) - self.head - self.tail
                    m = m.model_copy(update={"content": f"{m.content[:self.head]}\n…[{dropped} chars pruned]…\n{m.content[-self.tail:]}"})
                pruned.append(m)
            request = request.override(messages=pruned)
        return await handler(request)


def now_ms() -> int:
    return int(time.time() * 1000)
