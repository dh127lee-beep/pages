"""Office documents inside the VFS sandbox, through genoffice-py.

genoffice works on real paths. For every call we:

1. copy the session workspace (+ read-only `/templates`) into a fresh private temp directory,
2. run the genoffice function with `root` and `allowed_roots` pinned to that directory, with
   LibreOffice and cloud providers disabled, so nothing outside it is reachable,
3. write new or changed files back to the VFS and scrub the temp path out of the result.

The model never gets a shell, never sees a host path, and only the fixed tool set below exists.
"""

from __future__ import annotations

import asyncio
import json
import os
import re
import tempfile
from collections.abc import Callable
from pathlib import Path
from typing import Any

from langchain.agents.middleware import AgentMiddleware
from langchain_core.messages import ToolMessage
from langchain_core.tools import BaseTool, StructuredTool
from langgraph.config import get_config

from .vfs import TEMPLATES_PREFIX, VFS, VFSError

try:
    from genoffice import GenOffice
    from genoffice.tools import BY_NAME, TOOLS, call
except ImportError:  # pragma: no cover - optional dependency
    GenOffice = None  # type: ignore[assignment,misc]
    TOOLS, BY_NAME, call = [], {}, None  # type: ignore[assignment]

#: Need LibreOffice or a cloud provider; not part of the fixed sandbox set.
EXCLUDED_TOOLS = frozenset({"create_pdf", "render", "slides_render", "search", "image", "media"})
PATH_KEYS = ("file", "from", "out", "dir", "pptx", "spec_dir")
#: genoffice accepts inline JSON or the path of a JSON file for these.
JSON_OR_PATH_KEYS = ("outline", "spec", "ops", "data", "cells")
OFFICE_EXTENSIONS = (".docx", ".xlsx", ".pptx", ".pdf", ".doc", ".xls", ".ppt", ".xlsm", ".odt", ".ods", ".odp")

#: Friendly labels the console shows for each tool.
LABELS = {
    "info": "문서 정보 확인", "convert": "형식 변환", "create_docx": "워드 문서 만들기", "create_xlsx": "엑셀 만들기",
    "create_pptx": "슬라이드 만들기", "docs_read": "워드 읽기", "docs_apply": "워드 수정", "docs_check": "워드 점검",
    "merge": "양식 채우기", "pdf_read": "PDF 읽기", "sheet_read": "엑셀 읽기", "sheet_apply": "엑셀 수정",
    "sheet_check": "엑셀 점검", "slides_read": "슬라이드 읽기", "slides_apply": "슬라이드 수정",
    "slides_audit": "슬라이드 점검", "slides_check": "슬라이드 검사", "slides_replace": "슬라이드 교체",
    "guide": "사용법 확인", "capabilities": "기능 확인", "deck_start": "발표자료 시작", "deck_page": "발표자료 페이지",
    "deck_build": "발표자료 완성", "deck_replace": "발표자료 페이지 교체",
}

OFFICE_SYSTEM_PROMPT = """You are a friendly office assistant for people who are NOT software developers.
You help them read, write and edit Word (.docx), Excel (.xlsx), PowerPoint (.pptx) and PDF files.

The environment:
- There is no shell and no code execution. You work only through the tools you have.
- Files live in the user's private workspace. Paths look like `/report.docx`.
  The user uploads files in the Files panel and downloads your results from there.
- `/templates/` holds fixed, read-only company documents and forms. Never edit them in place:
  fill a form with `merge`, or write edits to a new file with `out`.

How to talk to the user:
- Use plain, everyday language in the user's language. No jargon, no JSON, no tool or op names,
  no file-format internals, unless the user asks.
- Before a long task, say in one sentence what you will do. At the end, say what you produced,
  the file name, and what you could not do. Do not paste the whole document back.
- If the request is ambiguous (which file, which period, which tone), ask ONE short question with
  `ask_user_question` and offer clear choices.
- Keep the user's originals safe: write edits to a new file (e.g. `/report_edited.docx`) unless the
  user explicitly says to change the original. Only overwrite when they ask.
- Numbers matter: never invent figures. If data is missing, say so and ask.

How to use the office tools:
- Read first (`info`, `docs_read`, `sheet_read`, `slides_read`, `pdf_read`), then call
  `guide(domain, topic)` for the exact edit operations (never guess op fields), then apply, then
  check (`docs_check`, `sheet_check`, `slides_audit`) and fix what the check reports.
- Each tool returns a JSON result: `status` ok | partial | error. On error follow `suggestion`.
  A batch of edits is atomic: fix the rejected op and resend the whole batch.
- New documents: write Markdown and use `create_docx`; tables of numbers: `create_xlsx`;
  short slide decks: `create_pptx`; decks over ~5 slides: `deck_start` → `deck_page` → `deck_build`.
- Formulas in new spreadsheets show their value only after the file is opened in Excel; mention it.
- Never use `read_file`/`write_file`/`edit_file` on .docx/.xlsx/.pptx/.pdf: they are binary.
  Plain text files (.md, .csv, .txt) are fine with those tools.
- When you finish a deliverable, call `present` with the files so the user sees download buttons."""


def available() -> bool:
    return GenOffice is not None


class OfficeToolkit:
    def __init__(self, vfs: VFS, workspace_of: Callable[[str], str], *,
                 on_change: Callable[[str, list[str]], None] | None = None) -> None:
        if GenOffice is None:
            raise RuntimeError("genoffice-py is not installed: pip install genoffice-py (or the local checkout)")
        self.vfs = vfs
        self.workspace_of = workspace_of
        self.on_change = on_change or (lambda _s, _p: None)
        self.specs = [t for t in TOOLS if t.name not in EXCLUDED_TOOLS]
        self.read_only = frozenset(t.name for t in self.specs if t.read_only)
        self.mutating = frozenset(t.name for t in self.specs if not t.read_only)

    def tools(self) -> list[BaseTool]:
        return [self._tool(spec) for spec in self.specs]

    def _tool(self, spec: Any) -> BaseTool:
        async def run(**kwargs: Any) -> str:
            # The spec's JSON schema is a dict, so read the thread from the graph config instead of
            # relying on ToolRuntime injection.
            session_id = str(get_config().get("configurable", {}).get("thread_id", ""))
            env = await self.run(session_id, spec.name, kwargs)
            return json.dumps(env, ensure_ascii=False, default=str)

        return StructuredTool.from_function(
            coroutine=run, name=spec.name, description=spec.description, args_schema=spec.parameters,
            infer_schema=False, metadata={"office": True, "read_only": spec.read_only})

    async def run(self, session_id: str, name: str, args: dict[str, Any]) -> dict[str, Any]:
        workspace = self.workspace_of(session_id)
        try:
            args = translate_paths(args)
        except VFSError as e:
            return _error(name, str(e), "invalid_path")
        if name == "create_docx" and isinstance(args.get("markdown"), str):
            args["markdown"] = fix_cjk_emphasis(args["markdown"])
        async with self.vfs.lock(workspace):
            tmp = Path(tempfile.mkdtemp(prefix="dsh-office-"))
            real = Path(os.path.realpath(tmp))
            try:
                manifest = await self.vfs.materialize(workspace, real)
                go = GenOffice(root=str(real), allowed_roots=[str(real)], soffice="", audit_log="")
                env = await asyncio.to_thread(call, go, name, args)
                try:
                    changed = await self.vfs.sync_back(workspace, real, manifest)
                except VFSError as e:
                    return _error(name, str(e), "storage_limit")
            finally:
                VFS.restore_permissions(real)
                _rmtree(real)
        env = scrub(env, [str(real), str(tmp)])
        if changed:
            env["saved_files"] = changed
            self.on_change(session_id, changed)
        return env


def translate_paths(args: dict[str, Any]) -> dict[str, Any]:
    """Virtual `/x/y.docx` → `x/y.docx` relative to the temp root; reject traversal."""
    out = dict(args)
    for key in (*PATH_KEYS, *JSON_OR_PATH_KEYS):
        value = out.get(key)
        if key in JSON_OR_PATH_KEYS and isinstance(value, str) and value.strip()[:1] in ("[", "{"):
            continue  # inline JSON, not a path
        if isinstance(value, str) and value:
            parts = value.replace("\\", "/").split("/")
            if ".." in parts or "\x00" in value or value.startswith("~"):
                raise VFSError(f"invalid path {value!r}: use workspace paths like /report.docx")
            out[key] = value.lstrip("/") or "."
    return out


_BOLD = re.compile(r"\*\*(?=\S)(.+?)(?<=\S)\*\*")
_FENCE = re.compile(r"^(```|~~~)")


def fix_cjk_emphasis(markdown: str) -> str:
    """`**5월(1,000원)**입니다` is not bold in CommonMark: a closing `**` after punctuation must be
    followed by whitespace or punctuation, and Korean text is neither. Models write this all the
    time, so bold is rewritten as inline `<strong>`, which genoffice renders. Code is left alone."""
    out, in_fence = [], False
    for line in markdown.split("\n"):
        if _FENCE.match(line.lstrip()):
            in_fence = not in_fence
        if in_fence or _FENCE.match(line.lstrip()):
            out.append(line)
            continue
        parts = line.split("`")
        for i in range(0, len(parts), 2):  # even parts are outside inline code spans
            parts[i] = _BOLD.sub(r"<strong>\1</strong>", parts[i])
        out.append("`".join(parts))
    return "\n".join(out)


def scrub(env: Any, roots: list[str]) -> Any:
    """Replace temp directory paths with virtual ones (`<tmp>/a.docx` → `/a.docx`)."""
    text = json.dumps(env, ensure_ascii=False, default=str)
    for root in sorted(set(roots), key=len, reverse=True):
        text = text.replace(root.rstrip("/") + "/", "/").replace(root.rstrip("/"), "/")
    return json.loads(text)


def _error(name: str, message: str, reason: str) -> dict[str, Any]:
    return {"status": "error", "command": name, "code": 3, "error": reason, "message": message,
            "suggestion": "use a path inside the workspace, e.g. /report.docx"}


def _rmtree(path: Path) -> None:
    import shutil

    shutil.rmtree(path, ignore_errors=True)


class OfficeGuardMiddleware(AgentMiddleware):
    """Keep text file tools away from binary office files and mutating tools out of read-only mode."""

    def __init__(self, *, deny_mutating: frozenset[str] = frozenset()) -> None:
        super().__init__()
        self.deny_mutating = deny_mutating

    async def awrap_tool_call(self, request: Any, handler: Any) -> Any:
        name, args = request.tool_call["name"], request.tool_call.get("args") or {}
        path = str(args.get("file_path", "")).lower() if isinstance(args, dict) else ""
        if name in ("read_file", "write_file", "edit_file") and path.endswith(OFFICE_EXTENSIONS):
            hint = {"read_file": "info / docs_read / sheet_read / slides_read / pdf_read",
                    "write_file": "create_docx / create_xlsx / create_pptx",
                    "edit_file": "docs_apply / sheet_apply / slides_apply"}[name]
            return ToolMessage(f"Error: {args.get('file_path')} is a binary office file. Use {hint} instead.",
                               tool_call_id=request.tool_call["id"], name=name, status="error")
        if name in self.deny_mutating:
            return ToolMessage("Error: this session is read-only; documents cannot be created or changed.",
                               tool_call_id=request.tool_call["id"], name=name, status="error")
        if name in ("write_file", "edit_file", "delete") and str(args.get("file_path", "")).startswith(TEMPLATES_PREFIX):
            return ToolMessage("Error: /templates is read-only. Save to a new path instead.",
                               tool_call_id=request.tool_call["id"], name=name, status="error")
        return await handler(request)
