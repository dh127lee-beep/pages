"""`python -m dsh_server` / `dsh-server`: run the HTTP server."""

from __future__ import annotations

import logging

import uvicorn

from .app import create_app
from .config import load_settings


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    settings = load_settings()
    if not settings.api_key:
        logging.warning("DEEPSEEK_API_KEY is not set; model calls will fail")
    if settings.host not in ("127.0.0.1", "localhost", "::1"):
        logging.warning("listening on %s: put this behind TLS and keep DSH_SERVER_TOKEN secret", settings.host)
    print(f"dsh-deepagents-server on http://{settings.host}:{settings.port}  token: {settings.auth_token}", flush=True)
    uvicorn.run(create_app(settings), host=settings.host, port=settings.port, log_level="info")


if __name__ == "__main__":
    main()
