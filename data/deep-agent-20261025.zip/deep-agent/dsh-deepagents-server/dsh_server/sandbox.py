"""Process confinement for `execute` and background jobs.

Harness parity (`docs/subsystems/sandbox.md`):

* modes `read-only | workspace-write | danger-full-access` govern *file writes* only
  (network and process access are not restricted);
* backends: Linux bubblewrap, macOS Seatbelt (`sandbox-exec`);
* fail closed: with no backend available a confined command is refused with
  `SANDBOX_UNAVAILABLE` instead of running unconfined;
* denials are surfaced to the model with a `[sandbox: ...]` marker.

deepagents' `LocalShellBackend` runs `subprocess.run(shell=True)` with no isolation, so we
subclass it and rewrite the command line before it reaches the parent implementation.
"""

from __future__ import annotations

import functools
import os
import shlex
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

from deepagents.backends import LocalShellBackend
from deepagents.backends.protocol import ExecuteResponse

from .config import PresetName

SAFE_ENV_KEYS = ("PATH", "HOME", "LANG", "LC_ALL", "TERM", "TMPDIR", "USER", "SHELL")
_DENIAL_HINTS = ("Operation not permitted", "Read-only file system", "Permission denied")


def safe_env() -> dict[str, str]:
    """Environment for model-run processes. Server secrets (API keys, tokens) are not inherited."""
    env = {k: v for k, v in os.environ.items() if k in SAFE_ENV_KEYS}
    env.setdefault("PATH", "/usr/local/bin:/usr/bin:/bin")
    return env


@functools.cache
def available_backend() -> str | None:
    if sys.platform == "darwin" and shutil.which("sandbox-exec"):
        return "seatbelt"
    if sys.platform.startswith("linux") and shutil.which("bwrap"):
        probe = subprocess.run(["bwrap", "--ro-bind", "/", "/", "true"], capture_output=True, check=False)
        if probe.returncode == 0:
            return "bwrap"
    return None


def _seatbelt_profile(mode: PresetName, roots: list[Path]) -> str:
    writable = ['(literal "/dev/null")', '(regex #"^/dev/tty")', '(regex #"^/dev/fd/")']
    if mode == "workspace-write":
        temp_roots = {Path("/private/tmp"), Path("/private/var/folders"), Path(tempfile.gettempdir()).resolve()}
        writable += [f'(subpath "{p}")' for p in [*roots, *sorted(temp_roots)]]
    return "(version 1)\n(allow default)\n(deny file-write*)\n(allow file-write* " + " ".join(writable) + ")\n"


def wrap_command(command: str, mode: PresetName, roots: list[Path], cwd: Path) -> str | None:
    """Return a shell string that runs `command` confined to `mode`, or None if impossible."""
    if mode == "danger-full-access":
        return command
    backend = available_backend()
    roots = [r.resolve() for r in roots]
    if backend == "seatbelt":
        profile = _seatbelt_profile(mode, roots)
        return f"sandbox-exec -p {shlex.quote(profile)} /bin/bash -c {shlex.quote(command)}"
    if backend == "bwrap":
        args = ["bwrap", "--ro-bind", "/", "/", "--dev", "/dev", "--proc", "/proc", "--die-with-parent"]
        if mode == "workspace-write":
            for root in roots:
                args += ["--bind", str(root), str(root)]
            args += ["--bind", "/tmp", "/tmp"]
        else:
            args += ["--tmpfs", "/tmp"]
        args += ["--chdir", str(cwd.resolve()), "/bin/bash", "-c", command]
        return shlex.join(args)
    return None


class SandboxedShellBackend(LocalShellBackend):
    """`LocalShellBackend` whose `execute` runs under the session's sandbox mode."""

    def __init__(self, root_dir: Path, *, mode: PresetName, writable_roots: list[Path] | None = None,
                 timeout: int, max_output_bytes: int) -> None:
        super().__init__(root_dir=root_dir, virtual_mode=True, timeout=timeout,
                         max_output_bytes=max_output_bytes, env=safe_env(), inherit_env=False)
        self.mode: PresetName = mode
        self.writable_roots = [Path(root_dir), *(writable_roots or [])]

    def execute(self, command: str, *, timeout: int | None = None) -> ExecuteResponse:
        wrapped = wrap_command(command, self.mode, self.writable_roots, Path(self.cwd))
        if wrapped is None:
            return ExecuteResponse(
                output=(f"[sandbox: SANDBOX_UNAVAILABLE] no sandbox backend on this host for mode "
                        f"'{self.mode}'. The command was not run. Use `request_escalated_execute` "
                        "with a justification to ask the user to run it unconfined."),
                exit_code=1,
                truncated=False,
            )
        result = super().execute(wrapped, timeout=timeout)
        if self.mode != "danger-full-access" and result.exit_code not in (0, None) and any(
            hint in result.output for hint in _DENIAL_HINTS
        ):
            result = ExecuteResponse(
                output=f"{result.output}\n[sandbox: file access denied under {self.mode} mode]",
                exit_code=result.exit_code,
                truncated=result.truncated,
            )
        return result
