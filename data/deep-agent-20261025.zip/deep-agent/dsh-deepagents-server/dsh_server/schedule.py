"""Scheduled follow-ups (harness: packages/schedule, docs/subsystems/schedule.md).

Timing kinds: `after_seconds`, `at` (RFC 3339), `every_seconds` (>= 60), `daily`, `weekly`,
`cron` (5-field). Delivery is a wake-up prompt into the original session. After downtime only
the latest overdue occurrence fires. Subagent sessions do not get these tools.
APScheduler is used only as a trigger calculator; persistence is a JSON file we own.
"""

from __future__ import annotations

import asyncio
import json
import logging
import time
import uuid
from collections.abc import Awaitable, Callable
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Literal

from apscheduler.triggers.cron import CronTrigger
from apscheduler.triggers.date import DateTrigger
from apscheduler.triggers.interval import IntervalTrigger
from langchain.tools import ToolRuntime
from langchain_core.tools import BaseTool, StructuredTool
from pydantic import BaseModel, Field, model_validator

from .middleware import thread_id_of

log = logging.getLogger(__name__)
Weekday = Literal["mon", "tue", "wed", "thu", "fri", "sat", "sun"]


class DailySpec(BaseModel):
    time: str = Field(pattern=r"^\d{2}:\d{2}$", description="HH:MM")
    time_zone: str = "UTC"


class WeeklySpec(DailySpec):
    days: list[Weekday] = Field(min_length=1)


class CronSpec(BaseModel):
    expression: str = Field(description="5-field cron expression, e.g. '0 9 * * 1-5'")
    time_zone: str = "UTC"


TIMING_FIELDS = ("after_seconds", "at", "every_seconds", "daily", "weekly", "cron")


class Timing(BaseModel):
    after_seconds: int | None = Field(default=None, ge=1)
    at: datetime | None = None
    every_seconds: int | None = Field(default=None, ge=60)
    daily: DailySpec | None = None
    weekly: WeeklySpec | None = None
    cron: CronSpec | None = None

    @model_validator(mode="after")
    def _exactly_one(self) -> Timing:
        set_fields = [k for k in TIMING_FIELDS if getattr(self, k) is not None]
        if len(set_fields) != 1:
            raise ValueError(f"exactly one timing field is required, got {set_fields or 'none'}")
        return self


def _trigger(spec: dict[str, Any], created_at: float) -> Any:
    if spec.get("at"):
        return DateTrigger(run_date=datetime.fromisoformat(spec["at"]))
    if spec.get("every_seconds"):
        return IntervalTrigger(seconds=spec["every_seconds"], start_date=datetime.fromtimestamp(created_at, timezone.utc))
    if spec.get("daily"):
        d = spec["daily"]
        hh, mm = d["time"].split(":")
        return CronTrigger(hour=int(hh), minute=int(mm), timezone=d["time_zone"])
    if spec.get("weekly"):
        w = spec["weekly"]
        hh, mm = w["time"].split(":")
        return CronTrigger(day_of_week=",".join(w["days"]), hour=int(hh), minute=int(mm), timezone=w["time_zone"])
    c = spec["cron"]
    return CronTrigger.from_crontab(c["expression"], timezone=c["time_zone"])


def _next_after(trigger: Any, prev: datetime | None, now: datetime) -> datetime | None:
    nxt = trigger.get_next_fire_time(prev, now)
    while nxt is not None and nxt <= now and prev is not None:  # coalesce missed occurrences
        prev, nxt = nxt, trigger.get_next_fire_time(nxt, now)
    return nxt


class Scheduler:
    def __init__(self, path: Path, deliver: Callable[[str, str, str], Awaitable[None]],
                 on_event: Callable[[str, str, dict], None]) -> None:
        self.path = path
        self.deliver = deliver
        self.on_event = on_event
        self.items: dict[str, dict[str, Any]] = json.loads(path.read_text()) if path.exists() else {}
        self._task: asyncio.Task | None = None

    def _save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(json.dumps(self.items, indent=2, default=str))

    def create(self, session_id: str, prompt: str, title: str, timing: Timing) -> dict[str, Any]:
        spec = json.loads(timing.model_dump_json(exclude_none=True, include=set(TIMING_FIELDS)))
        if timing.after_seconds:
            spec = {"at": (datetime.now(timezone.utc) + timedelta(seconds=timing.after_seconds)).isoformat()}
        now = time.time()
        item = {"id": f"sched-{uuid.uuid4().hex[:12]}", "session_id": session_id, "prompt": prompt,
                "title": title, "timing": spec, "created_at": now, "active": True, "history": []}
        nxt = _next_after(_trigger(spec, now), None, datetime.now(timezone.utc))
        item["next_run"] = nxt.isoformat() if nxt else None
        self.items[item["id"]] = item
        self._save()
        self.on_event(session_id, "schedule/created", item)
        return item

    def update(self, item_id: str, **changes: Any) -> dict[str, Any]:
        item = self.items[item_id]
        if "timing" in changes and changes["timing"] is not None:
            item["timing"] = json.loads(changes.pop("timing").model_dump_json(exclude_none=True))
            nxt = _next_after(_trigger(item["timing"], time.time()), None, datetime.now(timezone.utc))
            item["next_run"] = nxt.isoformat() if nxt else None
        item.update({k: v for k, v in changes.items() if v is not None})
        self._save()
        return item

    def delete(self, item_id: str) -> None:
        self.items.pop(item_id, None)
        self._save()

    def for_session(self, session_id: str) -> list[dict[str, Any]]:
        return [i for i in self.items.values() if i["session_id"] == session_id]

    async def tick(self) -> None:
        now = datetime.now(timezone.utc)
        for item in list(self.items.values()):
            if not item["active"] or not item.get("next_run"):
                continue
            due = datetime.fromisoformat(item["next_run"])
            if due > now:
                continue
            nxt = _next_after(_trigger(item["timing"], item["created_at"]), due, now)
            item["next_run"] = nxt.isoformat() if nxt else None
            item["active"] = nxt is not None
            item["history"] = [*item["history"][-19:], {"fired_at": now.isoformat(), "scheduled_for": due.isoformat()}]
            self._save()
            self.on_event(item["session_id"], "schedule/fired", {"id": item["id"], "title": item["title"]})
            try:
                await self.deliver(item["session_id"], f"<scheduled_task id=\"{item['id']}\" title=\"{item['title']}\">\n"
                                                       f"{item['prompt']}\n</scheduled_task>", "schedule")
            except Exception:  # noqa: BLE001
                log.exception("schedule delivery failed for %s", item["id"])

    async def run_forever(self, interval_s: float = 5.0) -> None:
        while True:
            await self.tick()
            await asyncio.sleep(interval_s)

    def start(self) -> None:
        self._task = asyncio.create_task(self.run_forever())

    async def stop(self) -> None:
        if self._task:
            self._task.cancel()


class ScheduleCreateInput(Timing):
    prompt: str = Field(description="The instruction you will receive when it fires.")
    title: str = Field(description="Short title.")


class ScheduleUpdateInput(BaseModel):
    id: str
    prompt: str | None = None
    title: str | None = None
    active: bool | None = None
    timing: Timing | None = None


class ScheduleDeleteInput(BaseModel):
    id: str


def schedule_tools(scheduler: Scheduler) -> list[BaseTool]:
    async def schedule_create(runtime: ToolRuntime, prompt: str, title: str, **timing: Any) -> str:
        timing = {k: v for k, v in timing.items() if k in TIMING_FIELDS}
        item = scheduler.create(thread_id_of(runtime), prompt, title, Timing(**timing))
        return json.dumps({"id": item["id"], "next_run": item["next_run"]})

    async def schedule_list(runtime: ToolRuntime) -> str:
        return json.dumps(scheduler.for_session(thread_id_of(runtime)), default=str)

    async def schedule_update(runtime: ToolRuntime, id: str, **changes: Any) -> str:  # noqa: A002
        if scheduler.items.get(id, {}).get("session_id") != thread_id_of(runtime):
            return "Error: unknown schedule"
        return json.dumps(scheduler.update(id, **changes), default=str)

    async def schedule_delete(runtime: ToolRuntime, id: str) -> str:  # noqa: A002
        if scheduler.items.get(id, {}).get("session_id") != thread_id_of(runtime):
            return "Error: unknown schedule"
        scheduler.delete(id)
        return f"Deleted {id}"

    return [
        StructuredTool.from_function(name="schedule_create", coroutine=schedule_create, args_schema=ScheduleCreateInput,
                                     infer_schema=False, description="Schedule a follow-up prompt into this session. "
                                     "Give exactly one of after_seconds, at, every_seconds, daily, weekly, cron."),
        StructuredTool.from_function(name="schedule_list", coroutine=schedule_list,
                                     description="List this session's scheduled follow-ups."),
        StructuredTool.from_function(name="schedule_update", coroutine=schedule_update, args_schema=ScheduleUpdateInput,
                                     infer_schema=False, description="Change a scheduled follow-up."),
        StructuredTool.from_function(name="schedule_delete", coroutine=schedule_delete, args_schema=ScheduleDeleteInput,
                                     infer_schema=False, description="Delete a scheduled follow-up."),
    ]
