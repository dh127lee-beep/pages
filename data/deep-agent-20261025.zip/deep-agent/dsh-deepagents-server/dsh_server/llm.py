"""DeepSeek chat-model factory.

The harness adapter (`packages/llm/llm-deepseek`) talks to DeepSeek's *Anthropic Messages*
endpoint (`https://api.deepseek.com/anthropic`, `POST /v1/messages`):

* reasoning effort `off|low|high|max` -> `thinking.type` + `output_config.effort`
* prior `thinking` blocks (with signatures) are replayed verbatim on every request

`ChatAnthropic` already keeps `thinking` blocks in `AIMessage.content` and sends them back,
so pointing it at the DeepSeek base URL gives the same wire behaviour with no custom code.

The OpenAI-compatible endpoint is offered as a fallback. There, `langchain-deepseek` reads
`reasoning_content` from responses but does not send it back, while DeepSeek thinking mode
requires it on assistant messages that carry tool calls. `ReasoningReplayChatDeepSeek` fixes
that gap (the harness's pi-ai adapter has the same `requiresReasoningContentOnAssistantMessages`
compat flag).
"""

from __future__ import annotations

from typing import Any

from langchain_core.language_models import BaseChatModel
from langchain_core.messages import AIMessage

from .config import Effort, Settings

USER_AGENT = "dsh-deepagents-server/0.1"


def build_chat_model(settings: Settings, *, effort: Effort | None = None, model: str | None = None) -> BaseChatModel:
    effort = effort or settings.effort
    model = model or settings.model
    if effort not in ("off", "low", "high", "max"):
        raise ValueError(f"unsupported reasoning effort {effort!r}")
    if settings.protocol == "anthropic":
        return _anthropic_model(settings, model, effort)
    if settings.protocol == "openai-compat":
        return _compat_model(settings, model)
    return _openai_model(settings, model, effort)


def _compat_model(settings: Settings, model: str) -> BaseChatModel:
    """Plain OpenAI-compatible chat completions (local gateways, proxies). Effort is not sent."""
    from langchain_openai import ChatOpenAI

    chat = ChatOpenAI(
        model=model,
        base_url=settings.base_url,
        api_key=settings.api_key or "missing-key",
        max_tokens=settings.max_tokens,
        streaming=True,
        stream_usage=True,
        use_responses_api=False,
        max_retries=5,
        timeout=300,
        default_headers={"user-agent": USER_AGENT},
    )
    _set_profile(chat, settings)
    return chat


def _anthropic_model(settings: Settings, model: str, effort: Effort) -> BaseChatModel:
    from langchain_anthropic import ChatAnthropic

    kwargs: dict[str, Any] = {}
    if effort == "off":
        kwargs["thinking"] = {"type": "disabled"}
    else:
        kwargs["thinking"] = {"type": "enabled"}
        kwargs["output_config"] = {"effort": effort}
    chat = ChatAnthropic(
        model=model,
        base_url=settings.base_url,
        api_key=settings.api_key or "missing-key",
        max_tokens=settings.max_tokens,
        streaming=True,
        max_retries=5,  # harness llm-retry: "normal, 5 retries"
        default_request_timeout=300,  # harness streamIdleTimeoutMs 300000
        default_headers={"user-agent": USER_AGENT},
        **kwargs,
    )
    _set_profile(chat, settings)
    return chat


def _openai_model(settings: Settings, model: str, effort: Effort) -> BaseChatModel:
    extra_body = {"thinking": {"type": "disabled" if effort == "off" else "enabled"}}
    chat = ReasoningReplayChatDeepSeek(
        model=model,
        api_base=settings.base_url,
        api_key=settings.api_key or "missing-key",
        max_tokens=settings.max_tokens,
        streaming=True,
        max_retries=5,
        timeout=300,
        extra_body=extra_body,
        default_headers={"user-agent": USER_AGENT},
    )
    _set_profile(chat, settings)
    return chat


def _set_profile(chat: BaseChatModel, settings: Settings) -> None:
    # DeepSeek ids are unknown to langchain's model-profile registry; without a profile,
    # deepagents falls back to a 170k-token summarization trigger. We pass explicit
    # thresholds anyway, but the profile also feeds token-fraction checks elsewhere.
    try:
        chat.profile = {
            **(chat.profile or {}),
            "max_input_tokens": settings.context_window,
            "max_output_tokens": settings.max_tokens,
        }
    except Exception:  # noqa: BLE001 - profile is advisory
        pass


try:
    from langchain_deepseek import ChatDeepSeek
except ImportError:  # pragma: no cover
    ChatDeepSeek = None  # type: ignore[assignment,misc]


if ChatDeepSeek is not None:

    class ReasoningReplayChatDeepSeek(ChatDeepSeek):  # type: ignore[misc,valid-type]
        """ChatDeepSeek that sends `reasoning_content` back on assistant messages."""

        def _get_request_payload(self, input_: Any, *, stop: list[str] | None = None, **kwargs: Any) -> dict:
            payload = super()._get_request_payload(input_, stop=stop, **kwargs)
            source = [m for m in self._convert_input(input_).to_messages() if isinstance(m, AIMessage)]
            wire = [m for m in payload["messages"] if m.get("role") == "assistant"]
            for src, dst in zip(source, wire):
                reasoning = src.additional_kwargs.get("reasoning_content")
                if reasoning:
                    dst["reasoning_content"] = reasoning
            return payload

else:  # pragma: no cover
    ReasoningReplayChatDeepSeek = None  # type: ignore[assignment,misc]
