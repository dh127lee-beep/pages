"""Session runtime: inbox, turns, interrupts, notices, async subagents and the goal driver.

LangGraph runs one *graph invocation* at a time; the harness has a long-lived Agent with an
inbox. This module rebuilds that layer on top of deepagents:

* every session has an inbox; prompts sent while a turn runs are queued, not dropped;
* non-waking *notices* (job settled, subagent waiting) ride along with the next input,
  like harness `agent.inject()`; *waking* inputs (user prompt, subagent settled, schedule,
  goal round) start a turn;
* state changes the server makes between turns (plan mode, goal rounds) are applied as part
  of the next run input instead of `update_state`, so they land at the next pre-step;
* interrupts (HITL approvals, `ask_user_question`, plan review) park the session in
  `waiting`; `resume()` answers them by interrupt id;
* forks are *seeded* sessions: the parent's completed messages are prepended to the first input.
"""

from __future__ import annotations

import asyncio
import json
import logging
import subprocess
import uuid
from dataclasses import dataclass, field
from typing import Any, Literal

from langchain.tools import ToolRuntime
from langchain_core.messages import AIMessage, AIMessageChunk, BaseMessage, HumanMessage, ToolMessage, messages_from_dict, messages_to_dict
from langchain_core.tools import BaseTool, StructuredTool
from langgraph.types import Command
from pydantic import BaseModel, Field

from .agent_factory import AgentFactory, AgentKey
from .config import Settings
from .middleware import thread_id_of
from .prompts import TITLE_PROMPT
from .store import EventLog, SessionRecord, SessionStore

log = logging.getLogger(__name__)
Status = Literal["idle", "running", "waiting"]
STATE_EVENTS = {"todos": "todo/write", "plan_mode": "plan/mode", "goal": "goal/change",
                "deliverables": "deliverables/presented", "_summarization_event": "compaction/summary"}


@dataclass
class InboxItem:
    text: str
    source: str = "user"  # user | subagent | schedule | goal | webhook
    patch: dict[str, Any] = field(default_factory=dict)


@dataclass
class SessionRuntime:
    id: str
    inbox: list[InboxItem] = field(default_factory=list)
    notices: list[str] = field(default_factory=list)
    patch: dict[str, Any] = field(default_factory=dict)  # applied with the next input
    seed: list[BaseMessage] = field(default_factory=list)
    status: Status = "idle"
    worker: asyncio.Task | None = None
    pending_resume: dict[str, Any] | None = None
    usage: dict[str, int] = field(default_factory=lambda: {"input": 0, "output": 0, "cache_read": 0, "requests": 0})


def _text_and_reasoning(msg: BaseMessage) -> tuple[str, str]:
    text, reasoning = [], []
    content = msg.content
    if isinstance(content, str):
        text.append(content)
    else:
        for block in content:
            if isinstance(block, str):
                text.append(block)
            elif block.get("type") == "text":
                text.append(block.get("text", ""))
            elif block.get("type") in ("thinking", "reasoning"):
                reasoning.append(block.get("thinking") or block.get("reasoning") or "")
    if rc := msg.additional_kwargs.get("reasoning_content"):
        reasoning.append(rc)
    return "".join(text), "".join(reasoning)


class Hub:
    def __init__(self, settings: Settings, store: SessionStore, events: EventLog, factory: AgentFactory) -> None:
        self.settings = settings
        self.store = store
        self.events = events
        self.factory = factory
        self.runtimes: dict[str, SessionRuntime] = {}
        self.vfs: Any = None  # VFS, set by the app when the office profile is available
        self.seed_dir = settings.data_dir / "seeds"
        self.seed_dir.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------ sessions

    def rt(self, session_id: str) -> SessionRuntime:
        if session_id not in self.runtimes:
            rt = SessionRuntime(session_id)
            seed_file = self.seed_dir / f"{session_id}.json"
            if seed_file.exists():
                rt.seed = messages_from_dict(json.loads(seed_file.read_text()))
            # Counters live in memory; restore the last snapshot from the durable event log.
            last = next((e for e in reversed(self.events.read(session_id)) if e["type"] == "usage"), None)
            if last:
                rt.usage.update(last["data"])
            self.runtimes[session_id] = rt
        return self.runtimes[session_id]

    def create_session(self, *, preset: str | None = None, model: str | None = None, effort: str | None = None,
                       title: str = "", kind: str = "root", parent_id: str | None = None,
                       seed: list[BaseMessage] | None = None, profile: str | None = None) -> SessionRecord:
        s = self.settings
        rec = SessionRecord(id=f"ses-{uuid.uuid4().hex[:16]}", title=title, preset=preset or s.default_preset,
                            model=model or s.model, effort=effort or s.effort, kind=kind, parent_id=parent_id,
                            profile=profile or s.default_profile)
        self.factory.preset_mode(rec.preset)  # validates the preset name
        if rec.profile not in ("dev", "office"):
            raise ValueError(f"unknown profile {rec.profile!r}")
        if rec.profile == "office" and self.vfs is None:
            raise ValueError("the office profile is unavailable (genoffice-py is not installed)")
        self.store.put(rec)
        if seed:
            (self.seed_dir / f"{rec.id}.json").write_text(json.dumps(messages_to_dict(seed)))
            self.rt(rec.id).seed = list(seed)
        self.events.emit(rec.id, "session/created", rec.to_dict())
        return rec

    def graph_for(self, rec: SessionRecord) -> Any:
        role = "subagent" if rec.kind == "subagent" else "root"
        return self.factory.get(AgentKey(rec.preset, rec.model, rec.effort, role, rec.profile))

    def workspace_of(self, session_id: str) -> str:
        """VFS workspace id: a subagent works in its parent's files; others own their workspace."""
        rec = self.store.get(session_id)
        seen = set()
        while rec and rec.kind == "subagent" and rec.parent_id and rec.id not in seen:
            seen.add(rec.id)
            rec = self.store.get(rec.parent_id) or rec
        return rec.id if rec else session_id

    @staticmethod
    def config(session_id: str) -> dict[str, Any]:
        return {"configurable": {"thread_id": session_id}, "recursion_limit": 9_999}

    async def snapshot(self, session_id: str) -> Any:
        rec = self._rec(session_id)
        return await self.graph_for(rec).aget_state(self.config(session_id))

    def _rec(self, session_id: str) -> SessionRecord:
        rec = self.store.get(session_id)
        if rec is None:
            raise KeyError(session_id)
        return rec

    async def pending_interrupts(self, session_id: str) -> list[dict[str, Any]]:
        snap = await self.snapshot(session_id)
        return [{"id": i.id, "value": i.value} for i in (snap.interrupts or ())]

    # ------------------------------------------------------------------ inputs

    async def enqueue(self, session_id: str, text: str, *, source: str = "user", patch: dict | None = None) -> None:
        """Waking input: starts a turn now, or after the current one / pending interrupt."""
        self._rec(session_id)
        self.rt(session_id).inbox.append(InboxItem(text, source, patch or {}))
        self.events.emit(session_id, "inbox/queued", {"source": source, "text": text[:2000]})
        self._kick(session_id)

    def notice(self, session_id: str, text: str) -> None:
        """Non-waking context: delivered with the next input."""
        self.rt(session_id).notices.append(text)

    def set_patch(self, session_id: str, **values: Any) -> None:
        self.rt(session_id).patch.update(values)

    async def resume(self, session_id: str, responses: dict[str, Any]) -> None:
        pending = {i["id"] for i in await self.pending_interrupts(session_id)}
        if not pending:
            raise ValueError("session has no pending interrupt")
        unknown = set(responses) - pending
        if unknown or not responses:
            raise ValueError(f"responses must answer pending interrupt ids {sorted(pending)}")
        rt = self.rt(session_id)
        rt.pending_resume = responses
        for iid, value in responses.items():
            self.events.emit(session_id, "interrupt/decided", {"id": iid, "value": value})
        self._kick(session_id)

    async def cancel(self, session_id: str) -> bool:
        rt = self.rt(session_id)
        if rt.worker and not rt.worker.done():
            rt.worker.cancel()
            return True
        return False

    # ------------------------------------------------------------------ worker

    def _kick(self, session_id: str) -> None:
        rt = self.rt(session_id)
        if rt.worker is None or rt.worker.done():
            rt.worker = asyncio.create_task(self._drain(session_id), name=f"session-{session_id}")

    async def _drain(self, session_id: str) -> None:
        rt = self.rt(session_id)
        try:
            while True:
                if rt.pending_resume is not None:
                    responses, rt.pending_resume = rt.pending_resume, None
                    await self._run(session_id, Command(resume=responses))
                    continue
                if await self.pending_interrupts(session_id):
                    rt.status = "waiting"
                    return
                if not rt.inbox:
                    rt.status = "idle"
                    return
                item = rt.inbox.pop(0)
                await self._run(session_id, self._input_for(rt, item), source=item.source)
        finally:
            if rt.status == "running":
                rt.status = "idle"
            self.events.emit(session_id, "session/status", {"status": rt.status})

    def _input_for(self, rt: SessionRuntime, item: InboxItem) -> dict[str, Any]:
        text = item.text
        if rt.notices:
            text = "\n\n".join([*rt.notices, text])
            rt.notices.clear()
        messages: list[BaseMessage] = [*rt.seed, HumanMessage(content=text)]
        if rt.seed:
            rt.seed = []
            (self.seed_dir / f"{rt.id}.json").unlink(missing_ok=True)
        payload: dict[str, Any] = {"messages": messages, **rt.patch, **item.patch}
        rt.patch = {}
        return payload

    async def _run(self, session_id: str, graph_input: Any, *, source: str = "resume") -> None:
        rt = self.rt(session_id)
        rec = self._rec(session_id)
        graph = self.graph_for(rec)
        rt.status = "running"
        self.events.emit(session_id, "session/status", {"status": "running"})
        if isinstance(graph_input, dict):
            human = graph_input["messages"][-1]
            self.events.emit(session_id, "turn/start", {"source": source})
            self.events.emit(session_id, "user/message", {"source": source, "text": human.content})
        reason: dict[str, Any] = {"kind": "completed"}
        try:
            async for ns, mode, data in graph.astream(graph_input, self.config(session_id),
                                                      stream_mode=["messages", "updates"], subgraphs=True):
                if mode == "messages":
                    self._on_chunk(session_id, ns, *data)
                else:
                    self._on_update(session_id, ns, data)
        except asyncio.CancelledError:
            reason = {"kind": "aborted", "reason": "cancelled"}
            self.events.emit(session_id, "turn/end", reason)
            rt.status = "idle"
            raise
        except Exception as e:  # noqa: BLE001
            log.exception("turn failed for %s", session_id)
            reason = {"kind": "error", "error": f"{type(e).__name__}: {e}"}
        interrupts = await self.pending_interrupts(session_id)
        if interrupts and reason["kind"] == "completed":
            rt.status = "waiting"
            for i in interrupts:
                self.events.emit(session_id, "interrupt/asked", i)
            if rec.kind == "subagent" and rec.parent_id:
                self.notice(rec.parent_id, f"<subagent_waiting id=\"{session_id}\">The subagent is waiting for "
                                           "user input (approval or question).</subagent_waiting>")
            return
        self.events.emit(session_id, "turn/end", reason)
        await self._after_turn(rec, reason)

    def _on_chunk(self, session_id: str, ns: tuple, chunk: Any, meta: dict) -> None:
        if not isinstance(chunk, AIMessageChunk) or meta.get("langgraph_node") != "model":
            return
        text, reasoning = _text_and_reasoning(chunk)
        if text or reasoning:
            self.events.emit(session_id, "assistant/delta", {"ns": list(ns), "text": text, "reasoning": reasoning})

    def _on_update(self, session_id: str, ns: tuple, data: Any) -> None:
        if not isinstance(data, dict):
            return
        for node, update in data.items():
            if node == "__interrupt__" or not isinstance(update, dict):
                continue
            for msg in update.get("messages") or []:
                if isinstance(msg, AIMessage):
                    text, reasoning = _text_and_reasoning(msg)
                    usage = msg.usage_metadata or {}
                    self.events.emit(session_id, "assistant/message", {
                        "ns": list(ns), "id": msg.id, "text": text, "reasoning": reasoning,
                        "tool_calls": [{"id": c["id"], "name": c["name"], "args": c["args"]} for c in msg.tool_calls],
                        "usage": usage})
                    if not ns:
                        self._meter(session_id, usage)
                elif isinstance(msg, ToolMessage):
                    content = msg.content if isinstance(msg.content, str) else json.dumps(msg.content, default=str)
                    self.events.emit(session_id, "tool/result", {
                        "ns": list(ns), "tool_call_id": msg.tool_call_id, "name": msg.name,
                        "status": msg.status, "content": content[:4000], "truncated": len(content) > 4000})
            for key, event in STATE_EVENTS.items():
                if key in update and update[key] is not None:
                    self.events.emit(session_id, event, {"ns": list(ns), "value": update[key]})

    def _meter(self, session_id: str, usage: dict) -> None:
        u = self.rt(session_id).usage
        u["input"] += usage.get("input_tokens", 0)
        u["output"] += usage.get("output_tokens", 0)
        u["cache_read"] += (usage.get("input_token_details") or {}).get("cache_read", 0)
        u["requests"] += 1
        u["reported"] = u.get("reported", 0) + (1 if usage else 0)  # some gateways omit streamed usage
        self.events.emit(session_id, "usage", dict(u))

    async def _after_turn(self, rec: SessionRecord, reason: dict[str, Any]) -> None:
        rt = self.rt(rec.id)
        if rec.profile != "office":
            self._workspace_changes(rec.id)
        if rec.kind != "subagent" and not rec.title:
            asyncio.create_task(self._title(rec))
        snap = await self.snapshot(rec.id)
        values = snap.values or {}
        if rec.kind == "subagent" and rec.parent_id and not rt.inbox:
            last = next((m for m in reversed(values.get("messages", [])) if isinstance(m, AIMessage)), None)
            output = _text_and_reasoning(last)[0] if last else ""
            self.events.emit(rec.parent_id, "subagent/settled", {"id": rec.id, "reason": reason})
            await self.enqueue(rec.parent_id, f"<subagent_settled id=\"{rec.id}\" title=\"{rec.title}\" "
                                              f"stop_reason=\"{reason['kind']}\">\n{output}\n</subagent_settled>",
                               source="subagent")
        goal = values.get("goal")
        if reason["kind"] == "completed" and goal and goal.get("phase") == "active" and not rt.inbox:
            goal = dict(goal)
            if goal["rounds"] >= goal["max_rounds"]:
                goal.update(phase="blocked", blocked_reason="goal round limit reached", revision=goal["revision"] + 1)
                self.set_patch(rec.id, goal=goal)
                self.events.emit(rec.id, "goal/change", {"value": goal})
                return
            goal.update(rounds=goal["rounds"] + 1)
            await self.enqueue(rec.id, f"<goal_round round=\"{goal['rounds']}\" max=\"{goal['max_rounds']}\">\n"
                                       f"Continue working toward the goal: {goal['objective']}\nCall update_goal "
                                       "with action=complete when it is done.\n</goal_round>",
                               source="goal", patch={"goal": goal})

    def _workspace_changes(self, session_id: str) -> None:
        ws = self.settings.workspace
        if not (ws / ".git").exists():
            return
        try:
            out = subprocess.run(["git", "status", "--porcelain"], cwd=ws, capture_output=True, text=True, timeout=10)
        except (OSError, subprocess.TimeoutExpired):
            return
        if out.returncode == 0:
            self.events.emit(session_id, "workspace/changes", {"status": out.stdout.splitlines()[:500]})

    async def _title(self, rec: SessionRecord) -> None:
        events = [e for e in self.events.read(rec.id) if e["type"] == "user/message"]
        if not events:
            return
        try:
            model = self.factory.model_builder(self.settings, effort="off", model=rec.model)
            reply = await model.ainvoke([HumanMessage(TITLE_PROMPT + str(events[0]["data"]["text"])[:4000])])
            title = _text_and_reasoning(reply)[0].strip().strip('"')[:80]
        except Exception:  # noqa: BLE001 - titles are cosmetic
            log.warning("title generation failed for %s", rec.id, exc_info=True)
            return
        if title:
            rec = self._rec(rec.id)
            rec.title = title
            self.store.put(rec)
            self.events.emit(rec.id, "session/title", {"title": title})

    # ------------------------------------------------------------------ forks

    async def fork(self, session_id: str, *, completed_only: bool = False, copy_files: bool = True) -> SessionRecord:
        """New session seeded with this session's history (harness `session.fork` / `subagent_fork`).

        Office forks get a snapshot copy of the workspace files so the two conversations can diverge.
        """
        rec = self._rec(session_id)
        messages = list((await self.snapshot(session_id)).values.get("messages", []))
        if completed_only:
            last_human = max((i for i, m in enumerate(messages) if isinstance(m, HumanMessage)), default=0)
            messages = messages[:last_human]
        new = self.create_session(preset=rec.preset, model=rec.model, effort=rec.effort, profile=rec.profile,
                                  title=f"Fork of {rec.title or rec.id}", parent_id=rec.id, seed=messages)
        if rec.profile == "office" and copy_files and self.vfs is not None:
            await self.vfs.copy_all(self.workspace_of(session_id), new.id)
        return new

    async def shutdown(self) -> None:
        for rt in self.runtimes.values():
            if rt.worker and not rt.worker.done():
                rt.worker.cancel()


# ---------------------------------------------------------------------------
# Async, steerable subagents  (harness: packages/subagent — subagent / send_message / ...)
# ---------------------------------------------------------------------------


class SubagentInput(BaseModel):
    description: str = Field(description="3-7 word label for the child agent.")
    prompt: str = Field(description="Complete, self-contained task for the child agent.")


class SendMessageInput(BaseModel):
    agent_id: str
    message: str


class AgentIdInput(BaseModel):
    agent_id: str


def subagent_tools(hub: Hub) -> list[BaseTool]:
    max_active = hub.settings.max_active_subagents

    def _children(parent: str) -> list[SessionRecord]:
        return hub.store.list(parent_id=parent)

    def _check_limit(parent: str) -> str | None:
        active = [c for c in _children(parent) if c.kind == "subagent" and hub.rt(c.id).status != "idle"]
        if len(active) >= max_active:
            return f"Error: ACTIVATION_LIMIT_REACHED ({max_active} active subagents)."
        return None

    async def _spawn(runtime: ToolRuntime, description: str, prompt: str, fork: bool) -> str:
        parent = thread_id_of(runtime)
        if err := _check_limit(parent):
            return err
        prec = hub._rec(parent)
        if fork:
            seed = await hub.fork(parent, completed_only=True, copy_files=False)
            seed.kind, seed.title = "subagent", description
            hub.store.put(seed)
            child = seed
        else:
            child = hub.create_session(preset=prec.preset, model=prec.model, effort=prec.effort, profile=prec.profile,
                                       title=description, kind="subagent", parent_id=parent)
        hub.events.emit(parent, "subagent/started", {"id": child.id, "description": description, "fork": fork})
        await hub.enqueue(child.id, prompt, source="parent")
        return (f"Started subagent {child.id}. Continue with other work; you will receive a "
                f"<subagent_settled> message when it finishes.")

    async def subagent(runtime: ToolRuntime, description: str, prompt: str) -> str:
        return await _spawn(runtime, description, prompt, fork=False)

    async def subagent_fork(runtime: ToolRuntime, description: str, prompt: str) -> str:
        return await _spawn(runtime, description, prompt, fork=True)

    def _own(runtime: ToolRuntime, agent_id: str) -> SessionRecord | None:
        rec = hub.store.get(agent_id)
        return rec if rec and rec.parent_id == thread_id_of(runtime) else None

    async def send_message(runtime: ToolRuntime, agent_id: str, message: str) -> str:
        if not _own(runtime, agent_id):
            return f"Error: unknown agent {agent_id}"
        await hub.enqueue(agent_id, f"<message_from_parent>\n{message}\n</message_from_parent>", source="parent")
        return f"Delivered to {agent_id} (status: {hub.rt(agent_id).status})."

    async def interrupt_agent(runtime: ToolRuntime, agent_id: str) -> str:
        if not _own(runtime, agent_id):
            return f"Error: unknown agent {agent_id}"
        return f"{agent_id}: {'interrupted' if await hub.cancel(agent_id) else 'was not running'}"

    async def list_agents(runtime: ToolRuntime) -> list[dict]:
        return [{"agent_id": c.id, "description": c.title, "status": hub.rt(c.id).status}
                for c in _children(thread_id_of(runtime)) if c.kind == "subagent"]

    return [
        StructuredTool.from_function(name="subagent", coroutine=subagent, args_schema=SubagentInput, infer_schema=False,
                                     description="Start a child agent with a clean context. Returns immediately; "
                                                 "the result arrives later as a <subagent_settled> message."),
        StructuredTool.from_function(name="subagent_fork", coroutine=subagent_fork, args_schema=SubagentInput,
                                     infer_schema=False,
                                     description="Like `subagent`, but the child starts with this conversation's "
                                                 "completed turns as context."),
        StructuredTool.from_function(name="send_message", coroutine=send_message, args_schema=SendMessageInput,
                                     infer_schema=False, description="Steer a running child agent or resume an idle one."),
        StructuredTool.from_function(name="interrupt_agent", coroutine=interrupt_agent, args_schema=AgentIdInput,
                                     infer_schema=False, description="Stop a child agent's current turn."),
        StructuredTool.from_function(name="list_agents", coroutine=list_agents,
                                     description="List this session's child agents and their status."),
    ]
