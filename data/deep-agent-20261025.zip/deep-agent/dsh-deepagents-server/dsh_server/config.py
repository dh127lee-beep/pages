"""Server configuration, read once from environment variables.

Defaults mirror the DeepSeek Harness base bundle (`packages/bundle/base/cordis.patch.yml`)
wherever the harness documents a number, so behaviour is comparable out of the box.
"""

from __future__ import annotations

import os
import secrets
from dataclasses import dataclass, field
from pathlib import Path
from typing import Literal

#: anthropic = DeepSeek Messages endpoint (harness wire); openai = DeepSeek OpenAI endpoint with
#: reasoning_content replay; openai-compat = any OpenAI-compatible server (no DeepSeek extras).
Protocol = Literal["anthropic", "openai", "openai-compat"]
Effort = Literal["off", "low", "high", "max"]
PresetName = Literal["read-only", "workspace-write", "danger-full-access"]
#: dev = host workspace + sandboxed shell (harness parity); office = VFS only, no code execution,
#: fixed office-document tool set, for non-developers.
ProfileName = Literal["dev", "office"]


def _env(name: str, default: str) -> str:
    return os.environ.get(name, default)


def _env_int(name: str, default: int) -> int:
    return int(os.environ.get(name, default))


def _env_float(name: str, default: float) -> float:
    return float(os.environ.get(name, default))


def _env_bool(name: str, default: bool) -> bool:
    raw = os.environ.get(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


@dataclass(frozen=True)
class Settings:
    # --- LLM (harness: packages/llm/llm-deepseek) ---
    # The harness adapter speaks the Anthropic Messages protocol to DeepSeek.
    protocol: Protocol = "anthropic"
    api_key: str = ""
    base_url: str = "https://api.deepseek.com/anthropic"
    model: str = "deepseek-flash"
    effort: Effort = "high"
    max_tokens: int = 64_000
    context_window: int = 1_048_576

    # --- Workspace / storage ---
    workspace: Path = field(default_factory=Path.cwd)
    home: Path = field(default_factory=lambda: Path.home() / ".dsh-deepagents")

    # --- Permissions (harness: docs/subsystems/permission-presets.md) ---
    default_preset: PresetName = "workspace-write"
    always_ask_tools: tuple[str, ...] = ()

    # --- Shell / jobs (harness: bash-sandbox timeoutMs 60000, jobs maxConcurrentJobsPerOwner 10) ---
    shell_timeout_s: int = 60
    shell_max_timeout_s: int = 600
    shell_max_output_bytes: int = 64_000
    max_jobs_per_session: int = 10

    # --- Context management (harness: compaction-basic + spill-policy defaults) ---
    compaction_threshold_ratio: float = 0.8
    compaction_headroom_tokens: int = 65_536
    compaction_retain_ratio: float = 0.16
    spill_max_inline_tokens: int = 12_500
    prune_tool_result_chars: int = 8_192
    prune_head_chars: int = 4_096
    prune_tail_chars: int = 1_024

    # --- Subagents (harness: maxDepth 1, maxActiveSubagents 8) ---
    max_active_subagents: int = 8

    # --- Goal (harness: defaultMaxGoalRounds 256) ---
    default_max_goal_rounds: int = 256

    # --- Integrations ---
    mcp_config: Path | None = None
    webhook_config: Path | None = None
    tavily_api_key: str = ""
    web_fetch_allow_private: bool = False

    # --- Office / VFS profile ---
    default_profile: ProfileName = "dev"
    office_templates_dir: Path | None = None
    office_quota_mb: int = 200
    office_max_file_mb: int = 25
    office_web: bool = False

    # --- Server ---
    host: str = "127.0.0.1"
    port: int = 3080
    auth_token: str = ""

    @property
    def data_dir(self) -> Path:
        return self.home / "data"

    @property
    def user_skills_dir(self) -> Path:
        return self.home / "skills"

    def compaction_trigger_tokens(self) -> int:
        """Harness formula: floor(min(W * ratio, W - O - headroom))."""
        w, o = self.context_window, self.max_tokens
        return int(min(w * self.compaction_threshold_ratio, w - o - self.compaction_headroom_tokens))

    def compaction_keep_tokens(self) -> int:
        """Harness formula: retainRatio * (W - O), kept verbatim after a summary."""
        return int(self.compaction_retain_ratio * (self.context_window - self.max_tokens))


def load_settings() -> Settings:
    protocol = _env("DSH_PROTOCOL", "anthropic")
    default_base = "https://api.deepseek.com/anthropic" if protocol == "anthropic" else "https://api.deepseek.com"
    default_model = "deepseek-flash" if protocol == "anthropic" else "deepseek-reasoner"
    mcp = os.environ.get("DSH_MCP_CONFIG")
    hooks = os.environ.get("DSH_WEBHOOK_CONFIG")
    templates = os.environ.get("DSH_OFFICE_TEMPLATES")
    token = os.environ.get("DSH_SERVER_TOKEN") or secrets.token_urlsafe(24)
    return Settings(
        protocol=protocol,  # type: ignore[arg-type]
        api_key=_env("DEEPSEEK_API_KEY", ""),
        base_url=_env("DEEPSEEK_BASE_URL", default_base),
        model=_env("DSH_MODEL", default_model),
        effort=_env("DSH_REASONING_EFFORT", "high"),  # type: ignore[arg-type]
        max_tokens=_env_int("DSH_MAX_TOKENS", 64_000),
        context_window=_env_int("DSH_CONTEXT_WINDOW", 1_048_576),
        workspace=Path(_env("DSH_WORKSPACE", str(Path.cwd()))).resolve(),
        home=Path(_env("DSH_HOME", str(Path.home() / ".dsh-deepagents"))).expanduser().resolve(),
        default_preset=_env("DSH_PERMISSION_MODE", "workspace-write"),  # type: ignore[arg-type]
        always_ask_tools=tuple(t for t in _env("DSH_ALWAYS_ASK_TOOLS", "").split(",") if t),
        shell_timeout_s=_env_int("DSH_SHELL_TIMEOUT", 60),
        compaction_threshold_ratio=_env_float("DSH_COMPACTION_RATIO", 0.8),
        spill_max_inline_tokens=_env_int("DSH_SPILL_MAX_INLINE_TOKENS", 12_500),
        max_active_subagents=_env_int("DSH_MAX_ACTIVE_SUBAGENTS", 8),
        mcp_config=Path(mcp).expanduser() if mcp else None,
        webhook_config=Path(hooks).expanduser() if hooks else None,
        tavily_api_key=_env("TAVILY_API_KEY", ""),
        web_fetch_allow_private=_env_bool("DSH_WEB_FETCH_ALLOW_PRIVATE", False),
        default_profile=_env("DSH_PROFILE", "dev"),  # type: ignore[arg-type]
        office_templates_dir=Path(templates).expanduser().resolve() if templates else None,
        office_quota_mb=_env_int("DSH_OFFICE_QUOTA_MB", 200),
        office_max_file_mb=_env_int("DSH_OFFICE_MAX_FILE_MB", 25),
        office_web=_env_bool("DSH_OFFICE_WEB", False),
        host=_env("DSH_HOST", "127.0.0.1"),
        port=_env_int("DSH_PORT", 3080),
        auth_token=token,
    )
