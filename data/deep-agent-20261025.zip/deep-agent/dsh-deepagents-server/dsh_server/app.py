"""FastAPI server: REST for control, Server-Sent Events for the session follow stream.

Harness parity: `session.create/list/prompt/cancel/fork`, `session.follow` (replay from a
sequence number, then live), approval / user-question answers, plan mode, compaction,
jobs, schedules, subagents and webhooks. Every route except `/health` and the
HMAC-verified webhooks needs the bearer token (harness: launch token -> auth cookie).
"""

from __future__ import annotations

import asyncio
import hmac
import json
import logging
from contextlib import AsyncExitStack, asynccontextmanager
from pathlib import Path
from typing import Any, Literal

from fastapi import Depends, FastAPI, HTTPException, Request, status
from fastapi.responses import FileResponse, JSONResponse, Response
from langchain_core.messages import messages_to_dict
from langgraph.checkpoint.sqlite.aio import AsyncSqliteSaver
from langgraph.store.sqlite.aio import AsyncSqliteStore
from pydantic import BaseModel, Field
from sse_starlette.sse import EventSourceResponse

from . import webhooks
from .agent_factory import AgentFactory
from .config import Settings, load_settings
from .jobs import JobManager, job_tools
from .llm import build_chat_model
from .permissions import PRESETS
from .runner import Hub, subagent_tools
from .sandbox import available_backend
from .schedule import Scheduler, schedule_tools
from .store import EventLog, SessionStore
from .vfs import VFS, VFSError
from . import office as office_mod
from .web import load_mcp_tools, web_tools

log = logging.getLogger(__name__)
STATIC_DIR = Path(__file__).parent / "static"


class CreateSession(BaseModel):
    profile: Literal["dev", "office"] | None = None
    preset: Literal["read-only", "workspace-write", "danger-full-access"] | None = None
    model: str | None = None
    effort: Literal["off", "low", "high", "max"] | None = None
    title: str = ""
    prompt: str | None = None


class UpdateSession(BaseModel):
    preset: Literal["read-only", "workspace-write", "danger-full-access"] | None = None
    model: str | None = None
    effort: Literal["off", "low", "high", "max"] | None = None
    title: str | None = None


class Prompt(BaseModel):
    text: str = Field(min_length=1)


class Resume(BaseModel):
    responses: dict[str, Any] = Field(description="interrupt id -> answer value")


class PlanMode(BaseModel):
    active: bool


def create_app(settings: Settings | None = None, *, model_builder=build_chat_model) -> FastAPI:
    settings = settings or load_settings()

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        async with AsyncExitStack() as stack:
            settings.data_dir.mkdir(parents=True, exist_ok=True)
            checkpointer = await stack.enter_async_context(
                AsyncSqliteSaver.from_conn_string(str(settings.data_dir / "checkpoints.sqlite")))
            await checkpointer.setup()
            lt_store = await stack.enter_async_context(
                AsyncSqliteStore.from_conn_string(str(settings.data_dir / "store.sqlite")))
            await lt_store.setup()

            sessions = SessionStore(settings.data_dir / "sessions.sqlite")
            events = EventLog(settings.data_dir / "events")
            hub_ref: dict[str, Hub] = {}

            def on_job_settled(job) -> None:
                hub_ref["hub"].notice(job.owner, f"<job_settled id=\"{job.id}\" status=\"{job.status}\" "
                                                 f"exit_code=\"{job.exit_code}\">{job.description}</job_settled>")

            jobs = JobManager(settings.data_dir / "jobs", max_per_owner=settings.max_jobs_per_session,
                              on_settled=on_job_settled, on_event=lambda s, t, d: events.emit(s, t, d))

            async def deliver(session_id: str, text: str, source: str) -> None:
                await hub_ref["hub"].enqueue(session_id, text, source=source)

            scheduler = Scheduler(settings.data_dir / "schedules.json", deliver, lambda s, t, d: events.emit(s, t, d))
            mcp_tools = await load_mcp_tools(settings.mcp_config)
            shared = [*web_tools(allow_private=settings.web_fetch_allow_private, tavily_api_key=settings.tavily_api_key),
                      *mcp_tools]

            def mode_of(session_id: str) -> str:
                rec = sessions.get(session_id)
                return PRESETS[rec.preset].sandbox if rec else "read-only"

            jtools = job_tools(jobs, mode_of=mode_of, workspace=settings.workspace)
            vfs = VFS(lt_store, quota_bytes=settings.office_quota_mb * 1024 * 1024,
                      max_file_bytes=settings.office_max_file_mb * 1024 * 1024, templates_dir=settings.office_templates_dir)

            def workspace_of(session_id: str) -> str:
                return hub_ref["hub"].workspace_of(session_id)

            def on_files_changed(session_id: str, paths: list[str]) -> None:
                events.emit(session_id, "vfs/changed", {"paths": paths})
                owner = workspace_of(session_id)
                if owner != session_id:  # a subagent wrote into its parent's files
                    events.emit(owner, "vfs/changed", {"paths": paths, "by": session_id})

            office = office_mod.OfficeToolkit(vfs, workspace_of, on_change=on_files_changed) if office_mod.available() else None
            office_web = web_tools(allow_private=False, tavily_api_key=settings.tavily_api_key) if settings.office_web else []
            factory = AgentFactory(
                settings, checkpointer=checkpointer, store=lt_store, model_builder=model_builder,
                shared_tools=lambda: [*shared, *jtools],
                root_tools=lambda: [*subagent_tools(hub_ref["hub"]), *schedule_tools(scheduler)],
                office=office, workspace_of=workspace_of, office_shared_tools=lambda: list(office_web))
            hub = Hub(settings, sessions, events, factory)
            hub.vfs = vfs if office else None
            hub_ref["hub"] = hub
            app.state.hub, app.state.jobs, app.state.scheduler = hub, jobs, scheduler
            app.state.webhook_rules = webhooks.load_rules(settings.webhook_config)
            scheduler.start()
            log.info("sandbox backend: %s; MCP tools: %d", available_backend() or "NONE (fail closed)", len(mcp_tools))
            try:
                yield
            finally:
                await scheduler.stop()
                await hub.shutdown()
                await jobs.shutdown()

    app = FastAPI(title="dsh-deepagents-server", version="0.1.0", lifespan=lifespan)
    app.state.settings = settings

    def auth(request: Request) -> None:
        header = request.headers.get("authorization", "")
        token = header.removeprefix("Bearer ").strip() if header.startswith("Bearer ") else request.query_params.get("token", "")
        if not token or not hmac.compare_digest(token, settings.auth_token):
            raise HTTPException(status.HTTP_401_UNAUTHORIZED, "missing or invalid token")

    def hub_of(request: Request) -> Hub:
        return request.app.state.hub

    def record(hub: Hub, session_id: str):
        rec = hub.store.get(session_id)
        if rec is None:
            raise HTTPException(404, f"unknown session {session_id}")
        return rec

    secured = [Depends(auth)]

    @app.get("/", include_in_schema=False)
    async def ui() -> FileResponse:
        # Static console; it calls the API with the token from `?token=` / localStorage.
        return FileResponse(STATIC_DIR / "index.html", headers={"cache-control": "no-store"})

    @app.get("/health")
    async def health() -> dict:
        return {"ok": True, "sandbox": available_backend(), "model": settings.model, "protocol": settings.protocol,
                "profiles": ["dev", "office"] if office_mod.available() else ["dev"],
                "default_profile": settings.default_profile}

    @app.get("/v1/presets", dependencies=secured)
    async def presets() -> list[dict]:
        return [{"name": p.name, "sandbox": p.sandbox, "approval": p.approval} for p in PRESETS.values()]

    @app.post("/v1/sessions", dependencies=secured, status_code=201)
    async def create_session(body: CreateSession, hub: Hub = Depends(hub_of)) -> dict:
        try:
            rec = hub.create_session(preset=body.preset, model=body.model, effort=body.effort, title=body.title,
                                     profile=body.profile)
        except ValueError as e:
            raise HTTPException(400, str(e)) from None
        if body.prompt:
            await hub.enqueue(rec.id, body.prompt)
        return rec.to_dict()

    @app.get("/v1/sessions", dependencies=secured)
    async def list_sessions(parent_id: str | None = None, hub: Hub = Depends(hub_of)) -> list[dict]:
        return [{**r.to_dict(), "status": hub.rt(r.id).status} for r in hub.store.list(parent_id=parent_id)]

    @app.get("/v1/sessions/{session_id}", dependencies=secured)
    async def get_session(session_id: str, hub: Hub = Depends(hub_of)) -> dict:
        rec = record(hub, session_id)
        snap = await hub.snapshot(session_id)
        values = snap.values or {}
        rt = hub.rt(session_id)
        return {**rec.to_dict(), "status": rt.status, "queued": len(rt.inbox), "usage": rt.usage,
                "interrupts": [{"id": i.id, "value": i.value} for i in (snap.interrupts or ())],
                "todos": values.get("todos", []), "plan_mode": values.get("plan_mode", False),
                "goal": values.get("goal"), "deliverables": values.get("deliverables", []),
                "message_count": len(values.get("messages", [])),
                "pending": {k: v for k, v in rt.patch.items() if k in ("plan_mode",)}}

    @app.patch("/v1/sessions/{session_id}", dependencies=secured)
    async def update_session(session_id: str, body: UpdateSession, hub: Hub = Depends(hub_of)) -> dict:
        rec = record(hub, session_id)
        for key, value in body.model_dump(exclude_none=True).items():
            setattr(rec, key, value)
        hub.store.put(rec)
        hub.events.emit(session_id, "session/updated", body.model_dump(exclude_none=True))
        return rec.to_dict()

    @app.get("/v1/sessions/{session_id}/messages", dependencies=secured)
    async def messages(session_id: str, hub: Hub = Depends(hub_of)) -> list[dict]:
        record(hub, session_id)
        return messages_to_dict((await hub.snapshot(session_id)).values.get("messages", []))

    @app.post("/v1/sessions/{session_id}/prompt", dependencies=secured, status_code=202)
    async def prompt(session_id: str, body: Prompt, hub: Hub = Depends(hub_of)) -> dict:
        record(hub, session_id)
        text = body.text.strip()
        # Human commands that dispatch without (or before) a model turn, like harness ctx.commands.
        if text == "/plan off":
            hub.set_patch(session_id, plan_mode=False)
            return {"command": "plan", "plan_mode": False}
        if text == "/plan" or text.startswith("/plan "):
            hub.set_patch(session_id, plan_mode=True)
            rest = text[len("/plan"):].strip()
            if rest:
                await hub.enqueue(session_id, rest)
            return {"command": "plan", "plan_mode": True, "queued": bool(rest)}
        if text == "/compact":
            await hub.enqueue(session_id, "Call the compact_conversation tool now, then reply 'compacted'.")
            return {"command": "compact"}
        await hub.enqueue(session_id, body.text)
        return {"queued": True, "status": hub.rt(session_id).status}

    @app.post("/v1/sessions/{session_id}/cancel", dependencies=secured)
    async def cancel(session_id: str, hub: Hub = Depends(hub_of)) -> dict:
        record(hub, session_id)
        return {"cancelled": await hub.cancel(session_id)}

    @app.get("/v1/sessions/{session_id}/interrupts", dependencies=secured)
    async def interrupts(session_id: str, hub: Hub = Depends(hub_of)) -> list[dict]:
        record(hub, session_id)
        return await hub.pending_interrupts(session_id)

    @app.post("/v1/sessions/{session_id}/resume", dependencies=secured, status_code=202)
    async def resume(session_id: str, body: Resume, hub: Hub = Depends(hub_of)) -> dict:
        record(hub, session_id)
        try:
            await hub.resume(session_id, body.responses)
        except ValueError as e:
            raise HTTPException(409, str(e)) from None
        return {"resumed": True}

    @app.post("/v1/sessions/{session_id}/plan-mode", dependencies=secured)
    async def plan_mode(session_id: str, body: PlanMode, hub: Hub = Depends(hub_of)) -> dict:
        record(hub, session_id)
        hub.set_patch(session_id, plan_mode=body.active)
        hub.events.emit(session_id, "plan/mode-requested", {"active": body.active})
        return {"plan_mode": body.active, "applies": "next turn"}

    @app.post("/v1/sessions/{session_id}/fork", dependencies=secured, status_code=201)
    async def fork(session_id: str, hub: Hub = Depends(hub_of)) -> dict:
        record(hub, session_id)
        if hub.rt(session_id).status != "idle":
            raise HTTPException(409, "fork at a turn boundary: the session must be idle")
        return (await hub.fork(session_id)).to_dict()

    @app.get("/v1/sessions/{session_id}/events", dependencies=secured)
    async def events(session_id: str, after_seq: int = 0, hub: Hub = Depends(hub_of)) -> list[dict]:
        record(hub, session_id)
        return hub.events.read(session_id, after_seq)

    @app.get("/v1/sessions/{session_id}/follow", dependencies=secured)
    async def follow(session_id: str, request: Request, after_seq: int = 0, hub: Hub = Depends(hub_of)):
        record(hub, session_id)
        queue = hub.events.subscribe(session_id)  # subscribe before replay so nothing falls in the gap

        async def stream():
            last = after_seq
            try:
                for ev in hub.events.read(session_id, after_seq):
                    last = ev["seq"]
                    yield {"id": str(ev["seq"]), "data": json.dumps(ev, default=str)}
                while not await request.is_disconnected():
                    try:
                        ev = await asyncio.wait_for(queue.get(), 15)
                    except TimeoutError:
                        yield {"comment": "keepalive"}
                        continue
                    if ev.get("seq", last + 1) <= last:
                        continue  # already replayed
                    last = ev.get("seq", last)
                    yield {"id": str(ev.get("seq", "")), "data": json.dumps(ev, default=str)}
            finally:
                hub.events.unsubscribe(session_id, queue)

        return EventSourceResponse(stream())

    # ---- virtual files (office profile) -------------------------------------------------

    def office_session(hub: Hub, session_id: str):
        rec = record(hub, session_id)
        if rec.profile != "office" or hub.vfs is None:
            raise HTTPException(409, "files are only available for office-profile sessions")
        return rec, hub.workspace_of(session_id)

    @app.get("/v1/sessions/{session_id}/files", dependencies=secured)
    async def list_files(session_id: str, hub: Hub = Depends(hub_of)) -> dict:
        _, ws = office_session(hub, session_id)
        return {"files": await hub.vfs.list(ws), "templates": hub.vfs.list_templates(),
                "usage": await hub.vfs.usage(ws), "quota": hub.vfs.quota_bytes, "max_file": hub.vfs.max_file_bytes}

    @app.put("/v1/sessions/{session_id}/files", dependencies=secured, status_code=201)
    async def upload_file(session_id: str, path: str, request: Request, hub: Hub = Depends(hub_of)) -> dict:
        _, ws = office_session(hub, session_id)
        chunks, size = [], 0
        async for chunk in request.stream():  # stop reading as soon as the limit is passed
            size += len(chunk)
            if size > hub.vfs.max_file_bytes:
                raise HTTPException(413, f"file is larger than {hub.vfs.max_file_bytes:,} bytes")
            chunks.append(chunk)
        try:
            vpath = await hub.vfs.write(ws, path, b"".join(chunks))
        except VFSError as e:
            raise HTTPException(400, str(e)) from None
        hub.notice(session_id, f"<file_uploaded path=\"{vpath}\" bytes=\"{size}\">The user uploaded this file.</file_uploaded>")
        hub.events.emit(session_id, "files/uploaded", {"path": vpath, "size": size})
        return {"path": vpath, "size": size}

    @app.get("/v1/sessions/{session_id}/files/raw", dependencies=secured)
    async def download_file(session_id: str, path: str, download: bool = True, hub: Hub = Depends(hub_of)) -> Response:
        _, ws = office_session(hub, session_id)
        try:
            data = await hub.vfs.read(ws, path)
        except VFSError as e:
            raise HTTPException(400, str(e)) from None
        if data is None:
            raise HTTPException(404, "file not found")
        import mimetypes
        from urllib.parse import quote

        name = path.rsplit("/", 1)[-1]
        mime = mimetypes.guess_type(name)[0] or "application/octet-stream"
        disposition = "attachment" if download else "inline"
        return Response(data, media_type=mime, headers={
            "content-disposition": f"{disposition}; filename*=UTF-8''{quote(name)}",
            "x-content-type-options": "nosniff", "cache-control": "no-store"})

    @app.delete("/v1/sessions/{session_id}/files", dependencies=secured)
    async def delete_file(session_id: str, path: str, hub: Hub = Depends(hub_of)) -> dict:
        _, ws = office_session(hub, session_id)
        try:
            deleted = await hub.vfs.delete(ws, path)
        except VFSError as e:
            raise HTTPException(400, str(e)) from None
        if deleted:
            hub.events.emit(session_id, "vfs/changed", {"paths": [path], "deleted": True})
        return {"deleted": deleted}

    @app.get("/v1/sessions/{session_id}/jobs", dependencies=secured)
    async def list_jobs(session_id: str, request: Request) -> list[dict]:
        return [j.summary() for j in request.app.state.jobs.owned(session_id)]

    @app.post("/v1/jobs/{job_id}/kill", dependencies=secured)
    async def kill_job(job_id: str, request: Request) -> dict:
        job = request.app.state.jobs.jobs.get(job_id)
        if job is None:
            raise HTTPException(404, "unknown job")
        await request.app.state.jobs.kill(job)
        return job.summary()

    @app.get("/v1/sessions/{session_id}/schedules", dependencies=secured)
    async def list_schedules(session_id: str, request: Request) -> list[dict]:
        return request.app.state.scheduler.for_session(session_id)

    @app.delete("/v1/schedules/{schedule_id}", dependencies=secured)
    async def delete_schedule(schedule_id: str, request: Request) -> dict:
        request.app.state.scheduler.delete(schedule_id)
        return {"deleted": schedule_id}

    @app.get("/v1/sessions/{session_id}/subagents", dependencies=secured)
    async def subagents(session_id: str, hub: Hub = Depends(hub_of)) -> list[dict]:
        return [{**c.to_dict(), "status": hub.rt(c.id).status}
                for c in hub.store.list(parent_id=session_id) if c.kind == "subagent"]

    @app.post("/v1/webhooks/{source}", status_code=202)
    async def webhook(source: Literal["github", "generic"], request: Request) -> JSONResponse:
        body = await request.body()
        headers = {k.lower(): v for k, v in request.headers.items()}
        try:
            payload = json.loads(body or b"{}")
        except json.JSONDecodeError:
            raise HTTPException(400, "body must be JSON") from None
        hub: Hub = request.app.state.hub
        for rule in request.app.state.webhook_rules:
            if not webhooks.match(rule, source, payload, headers):
                continue
            if not webhooks.verify(rule, body, headers):
                raise HTTPException(401, "bad signature")
            rec = hub.create_session(preset=rule.get("preset"), title=rule.get("name", "webhook"), kind="webhook")
            await hub.enqueue(rec.id, webhooks.render(rule, payload), source="webhook")
            return JSONResponse({"session_id": rec.id}, status_code=202)
        return JSONResponse({"session_id": None, "matched": False}, status_code=202)

    return app
