"""Session metadata (SQLite) and the append-only session event log (JSONL + live fan-out).

The harness treats an append-only `SessionEvent` log as the source of truth and derives model
history from it. Here LangGraph checkpoints own model history (and resume), and this log is
the *observable* record: turns, tool calls, approvals, todos, jobs, usage. Clients replay it
from any `seq` and then follow live, like the harness `session.follow` stream.
"""

from __future__ import annotations

import asyncio
import json
import sqlite3
import threading
import time
from collections import defaultdict
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

#: Events that are live-only (streamed, not persisted), like harness `agent/assistant-stream`.
LIVE_ONLY = frozenset({"assistant/delta"})


@dataclass
class SessionRecord:
    id: str
    title: str
    preset: str
    model: str
    effort: str
    kind: str = "root"  # root | subagent | webhook | schedule
    parent_id: str | None = None
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)
    profile: str = "dev"  # dev | office (column added by migration, so it stays last)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class SessionStore:
    def __init__(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        self._db = sqlite3.connect(path, check_same_thread=False)
        self._lock = threading.Lock()
        self._db.execute(
            "CREATE TABLE IF NOT EXISTS sessions (id TEXT PRIMARY KEY, title TEXT, preset TEXT, model TEXT,"
            " effort TEXT, kind TEXT, parent_id TEXT, created_at REAL, updated_at REAL)"
        )
        columns = {row[1] for row in self._db.execute("PRAGMA table_info(sessions)")}
        if "profile" not in columns:
            self._db.execute("ALTER TABLE sessions ADD COLUMN profile TEXT DEFAULT 'dev'")
        self._db.commit()

    def put(self, rec: SessionRecord) -> None:
        rec.updated_at = time.time()
        with self._lock:
            self._db.execute("INSERT OR REPLACE INTO sessions VALUES (?,?,?,?,?,?,?,?,?,?)",
                             (rec.id, rec.title, rec.preset, rec.model, rec.effort, rec.kind,
                              rec.parent_id, rec.created_at, rec.updated_at, rec.profile))
            self._db.commit()

    def get(self, session_id: str) -> SessionRecord | None:
        with self._lock:
            row = self._db.execute("SELECT * FROM sessions WHERE id = ?", (session_id,)).fetchone()
        return SessionRecord(*row) if row else None

    def list(self, *, parent_id: str | None = None, limit: int = 100) -> list[SessionRecord]:
        q, args = "SELECT * FROM sessions", ()
        if parent_id is not None:
            q, args = q + " WHERE parent_id = ?", (parent_id,)
        with self._lock:
            rows = self._db.execute(q + " ORDER BY updated_at DESC LIMIT ?", (*args, limit)).fetchall()
        return [SessionRecord(*r) for r in rows]

    def delete(self, session_id: str) -> None:
        with self._lock:
            self._db.execute("DELETE FROM sessions WHERE id = ?", (session_id,))
            self._db.commit()


class EventLog:
    """Per-session JSONL log with monotonically increasing `seq` and in-process subscribers."""

    def __init__(self, root: Path) -> None:
        self.root = root
        root.mkdir(parents=True, exist_ok=True)
        self._seq: dict[str, int] = {}
        self._subs: dict[str, set[asyncio.Queue]] = defaultdict(set)
        self._lock = threading.Lock()

    def _path(self, session_id: str) -> Path:
        return self.root / f"{session_id}.events.jsonl"

    def _next_seq(self, session_id: str) -> int:
        if session_id not in self._seq:
            p = self._path(session_id)
            self._seq[session_id] = sum(1 for _ in p.open()) if p.exists() else 0
        self._seq[session_id] += 1
        return self._seq[session_id]

    def emit(self, session_id: str, type_: str, data: dict[str, Any] | None = None) -> dict[str, Any]:
        event: dict[str, Any] = {"type": type_, "ts": time.time(), "data": data or {}}
        if type_ not in LIVE_ONLY:
            with self._lock:
                event["seq"] = self._next_seq(session_id)
                with self._path(session_id).open("a", encoding="utf-8") as f:
                    f.write(json.dumps(event, ensure_ascii=False, default=str) + "\n")
        for q in list(self._subs[session_id]):
            if q.qsize() < 10_000:  # drop live frames for a stuck consumer rather than grow unbounded
                q.put_nowait(event)
        return event

    def read(self, session_id: str, after_seq: int = 0) -> list[dict[str, Any]]:
        p = self._path(session_id)
        if not p.exists():
            return []
        out = []
        with p.open(encoding="utf-8") as f:
            for line in f:
                ev = json.loads(line)
                if ev.get("seq", 0) > after_seq:
                    out.append(ev)
        return out

    def subscribe(self, session_id: str) -> asyncio.Queue:
        q: asyncio.Queue = asyncio.Queue()
        self._subs[session_id].add(q)
        return q

    def unsubscribe(self, session_id: str, q: asyncio.Queue) -> None:
        self._subs[session_id].discard(q)
