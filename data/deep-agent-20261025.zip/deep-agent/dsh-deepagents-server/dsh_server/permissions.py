"""Permission presets = sandbox mode + approval policy (harness `docs/subsystems/permission-presets.md`).

| preset             | sandbox             | approval |
|--------------------|---------------------|----------|
| read-only          | read-only           | ask      |
| workspace-write    | workspace-write     | ask      |
| danger-full-access | danger-full-access  | never    |

deepagents expresses the same ideas with two knobs:

* `FilesystemPermission` rules for the file tools (`allow | deny | interrupt`);
* `interrupt_on` for HITL approval of any tool.

"ask" in the harness does not mean "ask for every call": calls run inside the sandbox
without prompting and only *escalation* (`sandbox_permissions` + `justification`) asks.
We keep that: `execute` is confined, `request_escalated_execute` always interrupts.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Literal

from deepagents import FilesystemPermission
from langchain.agents.middleware import AgentMiddleware
from langchain_core.messages import ToolMessage

from .config import PresetName

ApprovalPolicy = Literal["ask", "never"]

#: Virtual prefix under which user-global files (skills, AGENTS.md) are routed.
HOME_PREFIX = "/_user/"


@dataclass(frozen=True)
class Preset:
    name: PresetName
    sandbox: PresetName
    approval: ApprovalPolicy

    def fs_permissions(self) -> list[FilesystemPermission]:
        # deepagents refuses FilesystemPermission rules on an execute-capable backend unless
        # every rule is scoped to a CompositeBackend route, so only route-scoped rules go here;
        # read-only is enforced by `DenyToolsMiddleware` instead.
        if self.sandbox == "workspace-write":
            # Writes outside the workspace (the user-global home route) need a human.
            return [FilesystemPermission(operations=["write"], paths=[f"{HOME_PREFIX}**"], mode="interrupt")]
        return []

    def interrupt_on(self, always_ask: tuple[str, ...]) -> dict[str, Any]:
        if self.approval == "never":
            return {}
        rules: dict[str, Any] = {
            "request_escalated_execute": {
                "allowed_decisions": ["approve", "reject"],
                "description": "The agent asks to run a command OUTSIDE the sandbox.",
            },
        }
        for tool in always_ask:
            rules[tool] = {"allowed_decisions": ["approve", "edit", "reject"]}
        return rules


WRITE_TOOLS = frozenset({"write_file", "edit_file", "delete"})


class DenyToolsMiddleware(AgentMiddleware):
    """Refuse calls to some tools while keeping them listed.

    Removing tools per mode would change the tool schema block and break DeepSeek's prefix
    cache; the harness keeps the catalog stable for the same reason.
    """

    def __init__(self, denied: frozenset[str], reason: str) -> None:
        super().__init__()
        self.denied = denied
        self.reason = reason

    async def awrap_tool_call(self, request: Any, handler: Any) -> Any:
        if request.tool_call["name"] in self.denied:
            return ToolMessage(f"Error: {self.reason}", tool_call_id=request.tool_call["id"],
                               name=request.tool_call["name"], status="error")
        return await handler(request)


PRESETS: dict[str, Preset] = {
    "read-only": Preset("read-only", "read-only", "ask"),
    "workspace-write": Preset("workspace-write", "workspace-write", "ask"),
    "danger-full-access": Preset("danger-full-access", "danger-full-access", "never"),
}


def get_preset(name: str) -> Preset:
    try:
        return PRESETS[name]
    except KeyError:
        raise ValueError(f"unknown permission preset {name!r}; choose one of {sorted(PRESETS)}") from None
