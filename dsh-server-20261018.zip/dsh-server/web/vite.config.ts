import react from "@vitejs/plugin-react"
import { defineConfig } from "vite"

// Dev server proxies the API (REST + WebSocket) to dsh-server.
export default defineConfig({
  plugins: [react()],
  server: {
    proxy: {
      "/api": {
        target: process.env.DSH_SERVER_URL ?? "http://127.0.0.1:8000",
        ws: true,
      },
    },
  },
})
