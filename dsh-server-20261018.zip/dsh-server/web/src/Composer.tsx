import { type ClipboardEvent, type FormEvent, type KeyboardEvent, useRef, useState } from "react"
import { type Attachment, formatSize } from "./api"

export type PendingFile = {
  id: string
  name: string
  size: number
  status: "uploading" | "done" | "error"
  attachment?: Attachment
  error?: string
}

type Props = {
  disabled: boolean
  files: PendingFile[]
  onAddFiles: (files: File[]) => void
  onRemoveFile: (id: string) => void
  onSubmit: (text: string, attachments: Attachment[]) => Promise<boolean> | boolean
}

export function Composer({ disabled, files, onAddFiles, onRemoveFile, onSubmit }: Props) {
  const [text, setText] = useState("")
  const inputRef = useRef<HTMLInputElement>(null)

  const uploading = files.some((f) => f.status === "uploading")
  const ready = files.flatMap((f) => (f.status === "done" && f.attachment ? [f.attachment] : []))
  const canSend = !disabled && !uploading && (text.trim() !== "" || ready.length > 0)

  const send = async (e?: FormEvent) => {
    e?.preventDefault()
    if (!canSend) return
    if (await onSubmit(text.trim(), ready)) setText("")
  }

  const onKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey && !e.nativeEvent.isComposing) {
      e.preventDefault()
      send()
    }
  }

  const onPaste = (e: ClipboardEvent<HTMLTextAreaElement>) => {
    const pasted = Array.from(e.clipboardData.files)
    if (pasted.length > 0) {
      e.preventDefault()
      onAddFiles(pasted)
    }
  }

  return (
    <form className="composer" onSubmit={send}>
      {files.length > 0 && (
        <div className="pending-files">
          {files.map((f) => (
            <span key={f.id} className={`file-chip ${f.status}`} title={f.error ?? f.name}>
              <span className="file-chip-name">{f.name}</span>
              <span className="file-chip-meta">{f.status === "uploading" ? "업로드 중…" : f.status === "error" ? "실패" : formatSize(f.size)}</span>
              <button type="button" onClick={() => onRemoveFile(f.id)} aria-label="첨부 제거">
                ×
              </button>
            </span>
          ))}
        </div>
      )}
      <div className="composer-row">
        <button type="button" className="attach" onClick={() => inputRef.current?.click()} title="파일 첨부" aria-label="파일 첨부">
          <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48" />
          </svg>
        </button>
        <input
          ref={inputRef}
          type="file"
          multiple
          hidden
          onChange={(e) => {
            onAddFiles(Array.from(e.target.files ?? []))
            e.target.value = ""
          }}
        />
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={onKeyDown}
          onPaste={onPaste}
          placeholder={disabled ? "응답을 생성하는 중…" : "메시지를 입력하세요 (Shift+Enter 줄바꿈, 파일은 끌어다 놓기)"}
          rows={1}
        />
        <button type="submit" className="send" disabled={!canSend}>
          전송
        </button>
      </div>
    </form>
  )
}
