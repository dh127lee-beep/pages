import { useCallback, useEffect, useRef, useState } from "react"
import { type Attachment, type ChatItem, type SessionDetail, sessionSocketUrl } from "./api"

/** Text being streamed for one model attempt, before the final message arrives. */
export type Draft = { key: string; step: string; reasoning: string; text: string }

type Status = "connecting" | "open" | "closed"

const PERSISTED = new Set(["user", "reasoning", "text", "tool_call", "tool_result", "turn_end", "subagent_started", "subagent_finished", "error"])

export function useSession(sessionId: string | null, onActivity: () => void) {
  const [items, setItems] = useState<ChatItem[]>([])
  const [drafts, setDrafts] = useState<Draft[]>([])
  const [running, setRunning] = useState(false)
  const [status, setStatus] = useState<Status>("closed")
  const [notice, setNotice] = useState<string | null>(null)
  const socketRef = useRef<WebSocket | null>(null)
  const activityRef = useRef(onActivity)
  useEffect(() => {
    activityRef.current = onActivity
  })

  useEffect(() => {
    setItems([])
    setDrafts([])
    setRunning(false)
    setNotice(null)
    if (!sessionId) return

    let stopped = false
    let retry = 0
    let timer: number | undefined

    const connect = () => {
      setStatus("connecting")
      const ws = new WebSocket(sessionSocketUrl(sessionId))
      socketRef.current = ws

      ws.onopen = () => {
        retry = 0
        setStatus("open")
      }
      ws.onmessage = (ev) => {
        const msg = JSON.parse(ev.data as string) as ChatItem & { session?: SessionDetail }
        switch (msg.type) {
          case "snapshot":
            setItems(msg.session!.items)
            setRunning(msg.session!.running)
            setDrafts([])
            return
          case "turn_start":
            setRunning(true)
            return
          case "turn_done":
            setRunning(false)
            setDrafts([])
            activityRef.current()
            return
          case "notice":
            setNotice(msg.text ?? null)
            return
          case "busy":
            setNotice("이 대화에서 이미 응답을 생성하고 있습니다.")
            return
          case "deleted":
            setNotice("삭제된 대화입니다.")
            stopped = true
            ws.close()
            return
          case "stream_start":
            setDrafts((prev) => [
              ...prev.filter((d) => d.key !== msg.attempt_id),
              { key: msg.attempt_id!, step: `${msg.turn}:${msg.step}`, reasoning: "", text: "" },
            ])
            return
          case "text_delta":
          case "reasoning_delta":
            setDrafts((prev) => applyDelta(prev, msg))
            return
          case "stream_end":
            setDrafts((prev) => prev.filter((d) => d.key !== msg.attempt_id))
            return
        }
        if (!PERSISTED.has(msg.type)) return
        if (msg.turn !== undefined && msg.step !== undefined) {
          // The final blocks replace whatever was streamed for this step.
          const step = `${msg.turn}:${msg.step}`
          setDrafts((prev) => prev.filter((d) => d.step !== step))
        }
        setItems((prev) => [...prev, msg])
        if (msg.type === "user") activityRef.current()
      }
      ws.onclose = (ev) => {
        if (socketRef.current === ws) socketRef.current = null
        setStatus("closed")
        if (stopped) return
        if (ev.code === 4404) {
          setNotice("대화를 찾을 수 없습니다.")
          return
        }
        timer = window.setTimeout(connect, Math.min(1000 * 2 ** retry++, 10_000))
      }
    }

    connect()
    return () => {
      stopped = true
      window.clearTimeout(timer)
      socketRef.current?.close()
      socketRef.current = null
    }
  }, [sessionId])

  const send = useCallback((text: string, attachments: Attachment[] = []) => {
    const ws = socketRef.current
    if (!ws || ws.readyState !== WebSocket.OPEN) {
      setNotice("서버와 연결되지 않았습니다. 잠시 후 다시 시도하세요.")
      return false
    }
    setNotice(null)
    ws.send(JSON.stringify({ type: "prompt", text, attachments }))
    return true
  }, [])

  return { items, drafts, running, status, notice, send, clearNotice: () => setNotice(null) }
}

function applyDelta(prev: Draft[], msg: ChatItem): Draft[] {
  const key = msg.attempt_id ?? ""
  const field = msg.type === "text_delta" ? "text" : "reasoning"
  const existing = prev.find((d) => d.key === key)
  if (!existing) return [...prev, { key, step: "", reasoning: "", text: "", [field]: msg.text ?? "" }]
  return prev.map((d) => (d.key === key ? { ...d, [field]: d[field] + (msg.text ?? "") } : d))
}
