export type Attachment = { name: string; path: string; size: number; mime: string }

export type ChatItem = {
  type: string
  attachments?: Attachment[]
  ts?: number
  text?: string
  tool_name?: string
  tool_call_id?: string
  arguments?: unknown
  is_error?: boolean
  status?: string
  turn?: number
  step?: number
  index?: number
  attempt_id?: string
  finish_reason?: string
}

export type SessionSummary = {
  id: string
  title: string
  created_at: number
  updated_at: number
  running: boolean
}

export type SessionDetail = SessionSummary & { items: ChatItem[] }

const API_BASE: string = import.meta.env.VITE_API_BASE ?? ""

function storageGet(key: string): string | null {
  try {
    return localStorage.getItem(key)
  } catch {
    return null
  }
}

function storageSet(key: string, value: string) {
  try {
    localStorage.setItem(key, value)
  } catch {
    /* storage unavailable: value lives for this page only */
  }
}

let clientId = storageGet("dsh.clientId")
if (!clientId) {
  clientId = crypto.randomUUID()
  storageSet("dsh.clientId", clientId)
}

let token = storageGet("dsh.token") ?? import.meta.env.VITE_API_TOKEN ?? ""

export function setToken(value: string) {
  token = value
  storageSet("dsh.token", value)
}

export class UnauthorizedError extends Error {}

async function request<T>(method: string, path: string, body?: unknown): Promise<T> {
  const headers: Record<string, string> = { "X-Client-Id": clientId! }
  if (token) headers.Authorization = `Bearer ${token}`
  if (body !== undefined) headers["Content-Type"] = "application/json"
  const res = await fetch(`${API_BASE}${path}`, {
    method,
    headers,
    body: body === undefined ? undefined : JSON.stringify(body),
  })
  if (res.status === 401) throw new UnauthorizedError("unauthorized")
  if (!res.ok) throw new Error(`${res.status} ${await res.text()}`)
  return res.status === 204 ? (undefined as T) : ((await res.json()) as T)
}

export const api = {
  health: () => request<{ ok: boolean; model: string; profile: string; vision: boolean }>("GET", "/api/health"),
  listSessions: () => request<SessionSummary[]>("GET", "/api/sessions"),
  createSession: () => request<SessionDetail>("POST", "/api/sessions"),
  deleteSession: (id: string) => request<void>("DELETE", `/api/sessions/${id}`),
}

export async function uploadFiles(sessionId: string, files: File[]): Promise<Attachment[]> {
  const form = new FormData()
  for (const file of files) form.append("files", file, file.name)
  const headers: Record<string, string> = { "X-Client-Id": clientId! }
  if (token) headers.Authorization = `Bearer ${token}`
  const res = await fetch(`${API_BASE}/api/sessions/${sessionId}/files`, { method: "POST", headers, body: form })
  if (res.status === 401) throw new UnauthorizedError("unauthorized")
  if (!res.ok) throw new Error(`업로드 실패 (${res.status}): ${await res.text()}`)
  return (await res.json()) as Attachment[]
}

/** URL for a file in the session workspace (auth in the query so <img> and links work). */
export function fileUrl(sessionId: string, path: string): string {
  const params = new URLSearchParams({ client_id: clientId! })
  if (token) params.set("token", token)
  const encoded = path.split("/").map(encodeURIComponent).join("/")
  return `${API_BASE}/api/sessions/${sessionId}/files/${encoded}?${params}`
}

export function sessionSocketUrl(id: string): string {
  const base = API_BASE || window.location.origin
  const url = new URL(`${base}/api/sessions/${id}/ws`)
  url.protocol = url.protocol === "https:" ? "wss:" : "ws:"
  url.searchParams.set("client_id", clientId!)
  if (token) url.searchParams.set("token", token)
  return url.toString()
}

export function formatSize(size: number): string {
  if (size < 1024) return `${size} B`
  if (size < 1024 * 1024) return `${(size / 1024).toFixed(1)} KB`
  return `${(size / 1024 / 1024).toFixed(1)} MB`
}
