import { type DragEvent, useCallback, useEffect, useRef, useState } from "react"
import { api, type Attachment, type SessionSummary, setToken, UnauthorizedError, uploadFiles } from "./api"
import { Composer, type PendingFile } from "./Composer"
import { Transcript } from "./Transcript"
import { useSession } from "./useSession"

export default function App() {
  const [sessions, setSessions] = useState<SessionSummary[]>([])
  const [activeId, setActiveId] = useState<string | null>(null)
  const [model, setModel] = useState("")
  const [error, setError] = useState<string | null>(null)
  const [needsToken, setNeedsToken] = useState(false)
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [files, setFiles] = useState<PendingFile[]>([])
  const [dragging, setDragging] = useState(false)
  // A message submitted before its session's socket was open.
  const pendingSend = useRef<{ sessionId: string; text: string; attachments: Attachment[] } | null>(null)

  const handleError = useCallback((e: unknown) => {
    if (e instanceof UnauthorizedError) setNeedsToken(true)
    else setError(e instanceof Error ? e.message : String(e))
  }, [])

  const refresh = useCallback(async () => {
    try {
      setSessions(await api.listSessions())
      setError(null)
    } catch (e) {
      handleError(e)
    }
  }, [handleError])

  useEffect(() => {
    api.health().then((h) => setModel(`${h.model} · ${h.profile}`), handleError)
    refresh()
    const timer = window.setInterval(refresh, 10_000)
    return () => window.clearInterval(timer)
  }, [refresh, handleError])

  const session = useSession(activeId, refresh)
  const { status: socketStatus, send: sendToSession } = session

  const newChat = async () => {
    try {
      const created = await api.createSession()
      selectSession(created.id)
      setSidebarOpen(false)
      await refresh()
    } catch (e) {
      handleError(e)
    }
  }

  const remove = async (id: string) => {
    if (!confirm("이 대화를 삭제할까요?")) return
    try {
      await api.deleteSession(id)
      if (id === activeId) selectSession(null)
      await refresh()
    } catch (e) {
      handleError(e)
    }
  }

  const selectSession = (id: string | null) => {
    setActiveId(id)
    setFiles([])
  }

  /** The current session id, creating a session first when none is open. */
  const ensureSession = async (): Promise<string> => {
    if (activeId) return activeId
    const created = await api.createSession()
    setActiveId(created.id)
    refresh()
    return created.id
  }

  const addFiles = async (picked: File[]) => {
    if (picked.length === 0) return
    const entries: PendingFile[] = picked.map((f) => ({ id: crypto.randomUUID(), name: f.name, size: f.size, status: "uploading" }))
    setFiles((prev) => [...prev, ...entries])
    const settle = (id: string, patch: Partial<PendingFile>) => setFiles((prev) => prev.map((f) => (f.id === id ? { ...f, ...patch } : f)))
    let sessionId: string
    try {
      sessionId = await ensureSession()
    } catch (e) {
      entries.forEach((entry) => settle(entry.id, { status: "error", error: String(e) }))
      handleError(e)
      return
    }
    // One request per file so a large file doesn't hold up the rest.
    await Promise.all(
      picked.map(async (file, i) => {
        try {
          const [attachment] = await uploadFiles(sessionId, [file])
          settle(entries[i].id, { status: "done", attachment, name: attachment.name })
        } catch (e) {
          settle(entries[i].id, { status: "error", error: e instanceof Error ? e.message : String(e) })
        }
      }),
    )
  }

  const submit = async (text: string, attachments: Attachment[]) => {
    try {
      const sessionId = await ensureSession()
      if (sessionId === activeId && socketStatus === "open") {
        if (!sendToSession(text, attachments)) return false
      } else {
        pendingSend.current = { sessionId, text, attachments }
      }
      setFiles([])
      return true
    } catch (e) {
      handleError(e)
      return false
    }
  }

  // Deliver a message submitted before its session's socket opened.
  useEffect(() => {
    const pending = pendingSend.current
    if (socketStatus === "open" && pending && pending.sessionId === activeId) {
      pendingSend.current = null
      sendToSession(pending.text, pending.attachments)
    }
  }, [socketStatus, sendToSession, activeId])

  const onDrop = (e: DragEvent) => {
    e.preventDefault()
    setDragging(false)
    addFiles(Array.from(e.dataTransfer.files))
  }

  const active = sessions.find((s) => s.id === activeId)

  return (
    <div className="app">
      <aside className={`sidebar ${sidebarOpen ? "open" : ""}`}>
        <div className="brand">
          DSH Chat
          {model && <small>{model}</small>}
        </div>
        <button className="new-chat" onClick={newChat}>
          + 새 대화
        </button>
        <nav className="session-list">
          {sessions.map((s) => (
            <div
              key={s.id}
              className={`session-row ${s.id === activeId ? "active" : ""}`}
              onClick={() => {
                if (s.id !== activeId) selectSession(s.id)
                setSidebarOpen(false)
              }}
            >
              {s.running && <span className="running-dot" title="실행 중" />}
              <span className="session-title">{s.title}</span>
              <button
                className="delete"
                title="삭제"
                onClick={(e) => {
                  e.stopPropagation()
                  remove(s.id)
                }}
              >
                ×
              </button>
            </div>
          ))}
        </nav>
      </aside>
      {sidebarOpen && <div className="scrim" onClick={() => setSidebarOpen(false)} />}

      <main
        className={`chat ${dragging ? "dragging" : ""}`}
        onDragOver={(e) => {
          if (Array.from(e.dataTransfer.types).includes("Files")) {
            e.preventDefault()
            setDragging(true)
          }
        }}
        onDragLeave={(e) => {
          if (e.currentTarget === e.target) setDragging(false)
        }}
        onDrop={onDrop}
      >
        {dragging && <div className="drop-overlay">여기에 파일을 놓으면 첨부됩니다</div>}
        <header className="chat-header">
          <button className="menu" onClick={() => setSidebarOpen(true)} aria-label="대화 목록">
            ☰
          </button>
          <h1>{active?.title ?? "새 대화"}</h1>
          {activeId && <span className={`conn ${session.status}`} title={session.status} />}
        </header>

        {error && (
          <div className="banner" onClick={() => setError(null)}>
            {error}
          </div>
        )}
        {session.notice && (
          <div className="banner" onClick={session.clearNotice}>
            {session.notice}
          </div>
        )}

        <Transcript sessionId={activeId} items={session.items} drafts={session.drafts} running={session.running} />
        <Composer
          disabled={session.running}
          files={files}
          onAddFiles={addFiles}
          onRemoveFile={(id) => setFiles((prev) => prev.filter((f) => f.id !== id))}
          onSubmit={submit}
        />
      </main>

      {needsToken && (
        <TokenDialog
          onSave={(t) => {
            setToken(t)
            setNeedsToken(false)
            refresh()
            api.health().then((h) => setModel(`${h.model} · ${h.profile}`), handleError)
          }}
        />
      )}
    </div>
  )
}

function TokenDialog({ onSave }: { onSave: (token: string) => void }) {
  const [value, setValue] = useState("")
  return (
    <div className="modal-backdrop">
      <form
        className="modal"
        onSubmit={(e) => {
          e.preventDefault()
          onSave(value.trim())
        }}
      >
        <h2>접근 토큰</h2>
        <p>서버에 설정된 DSH_SERVER_TOKEN 값을 입력하세요.</p>
        <input type="password" value={value} onChange={(e) => setValue(e.target.value)} autoFocus />
        <button type="submit">저장</button>
      </form>
    </div>
  )
}
