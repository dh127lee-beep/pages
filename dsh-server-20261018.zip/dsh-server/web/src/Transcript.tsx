import { useEffect, useMemo, useRef } from "react"
import ReactMarkdown from "react-markdown"
import remarkGfm from "remark-gfm"
import { type Attachment, type ChatItem, fileUrl, formatSize } from "./api"
import type { Draft } from "./useSession"

type Props = { sessionId: string | null; items: ChatItem[]; drafts: Draft[]; running: boolean }

export function Transcript({ sessionId, items, drafts, running }: Props) {
  const endRef = useRef<HTMLDivElement>(null)

  // Tool results are rendered inside their matching tool call card.
  const results = useMemo(() => {
    const map = new Map<string, ChatItem>()
    for (const item of items) if (item.type === "tool_result" && item.tool_call_id) map.set(item.tool_call_id, item)
    return map
  }, [items])

  useEffect(() => {
    endRef.current?.scrollIntoView({ block: "end" })
  }, [items, drafts])

  return (
    <div className="transcript">
      {items.length === 0 && !running && <div className="empty">무엇이든 물어보세요. 에이전트가 도구를 사용해 작업합니다.</div>}
      {items.map((item, i) => (
        <Item key={i} sessionId={sessionId} item={item} result={item.tool_call_id ? results.get(item.tool_call_id) : undefined} />
      ))}
      {drafts.map((d) => (
        <div key={d.key}>
          {d.reasoning && <Reasoning text={d.reasoning} open />}
          {d.text && (
            <div className="msg assistant">
              <Markdown text={d.text} />
            </div>
          )}
        </div>
      ))}
      {running && drafts.every((d) => !d.text && !d.reasoning) && (
        <div className="typing" aria-label="응답 생성 중">
          <span />
          <span />
          <span />
        </div>
      )}
      <div ref={endRef} />
    </div>
  )
}

function Item({ sessionId, item, result }: { sessionId: string | null; item: ChatItem; result?: ChatItem }) {
  switch (item.type) {
    case "user":
      return (
        <div className="user-turn">
          {sessionId && item.attachments && item.attachments.length > 0 && <Attachments sessionId={sessionId} files={item.attachments} />}
          {item.text && <div className="msg user">{item.text}</div>}
        </div>
      )
    case "text":
      return (
        <div className="msg assistant">
          <Markdown text={item.text ?? ""} />
        </div>
      )
    case "reasoning":
      return <Reasoning text={item.text ?? ""} />
    case "tool_call":
      return <ToolCall item={item} result={result} />
    case "subagent_started":
      return <div className="meta">서브 에이전트 시작</div>
    case "subagent_finished":
      return <div className={`meta ${item.is_error ? "bad" : ""}`}>서브 에이전트 종료 ({item.status})</div>
    case "turn_end":
      return item.status && item.status !== "completed" ? <div className="meta bad">턴 종료: {item.status}</div> : null
    case "error":
      return <div className="msg error">{item.text}</div>
    default:
      return null
  }
}

function Attachments({ sessionId, files }: { sessionId: string; files: Attachment[] }) {
  return (
    <div className="attachments">
      {files.map((f) => {
        const url = fileUrl(sessionId, f.path)
        return f.mime.startsWith("image/") ? (
          <a key={f.path} href={url} target="_blank" rel="noreferrer" className="attachment-image" title={f.name}>
            <img src={url} alt={f.name} loading="lazy" />
          </a>
        ) : (
          <a key={f.path} href={url} target="_blank" rel="noreferrer" className="file-chip done" title={f.path}>
            <span className="file-chip-name">{f.name}</span>
            <span className="file-chip-meta">{formatSize(f.size)}</span>
          </a>
        )
      })}
    </div>
  )
}

function Reasoning({ text, open }: { text: string; open?: boolean }) {
  return (
    <details className="reasoning" open={open}>
      <summary>생각</summary>
      <div>{text}</div>
    </details>
  )
}

function ToolCall({ item, result }: { item: ChatItem; result?: ChatItem }) {
  const args = typeof item.arguments === "string" ? item.arguments : JSON.stringify(item.arguments, null, 2)
  const state = result ? (result.is_error ? "error" : "done") : "pending"
  return (
    <details className={`tool ${state}`}>
      <summary>
        <span className="tool-dot" />
        <code>{item.tool_name}</code>
        <span className="tool-brief">{brief(item.arguments)}</span>
      </summary>
      <div className="tool-body">
        <div className="label">입력</div>
        <pre>{args}</pre>
        {result && (
          <>
            <div className="label">{result.is_error ? "오류" : "결과"}</div>
            <pre>{result.text || "(출력 없음)"}</pre>
          </>
        )}
      </div>
    </details>
  )
}

function brief(args: unknown): string {
  if (args && typeof args === "object") {
    const values = Object.values(args as Record<string, unknown>)
    const first = values.find((v) => typeof v === "string") as string | undefined
    if (first) return first.split("\n")[0].slice(0, 80)
  }
  return typeof args === "string" ? args.slice(0, 80) : ""
}

function Markdown({ text }: { text: string }) {
  return (
    <ReactMarkdown
      remarkPlugins={[remarkGfm]}
      components={{ a: ({ ...props }) => <a {...props} target="_blank" rel="noreferrer" /> }}
    >
      {text}
    </ReactMarkdown>
  )
}
