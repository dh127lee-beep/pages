# 01. 개요

## 목표

- dsh(DeepSeek Harness) 에이전트를 여러 사용자가 동시에 쓰는 **채팅 서버 + 웹 UI**.
- 에이전트가 실제로 도구(코드 실행, 파일, 웹 검색)를 쓰되, **세션의 모든 도구가 그 세션 폴더로 제한**될 것.
- 커널 샌드박스(namespace/seccomp/Landlock)를 쓸 수 없는 **컨테이너 환경**에서도 동작할 것.
- 에이전트 실행부를 API 서버와 분리하고, **사용자마다 별도 워커**를 띄울 것.

## 전체 구조

```
 브라우저 (web/, React)
     │  REST + WebSocket (X-Client-Id, 선택적 Bearer 토큰)
     ▼
 ┌──────────────────────── API 서버 (dsh_server.app) ────────────────────────┐
 │ SessionHub: 대화 기록(store), 이벤트 브로드캐스트, 실행 중 턴 추적          │
 │ WorkerPool: 사용자 → 워커 (필요 시 기동, 유휴 시 종료)                     │
 └───────────────┬──────────────────────────────┬────────────────────────────┘
                 │ HTTP (NDJSON 스트림, 워커 토큰)│
                 ▼                              ▼
 ┌──── 사용자 A 워커 (dsh_server.worker) ───┐   ┌── 사용자 B 워커 ──┐
 │ AgentService                             │   │       ...         │
 │  ├ DshAgent ── stdio JSON-RPC ── dsh 런타임 (Node, 단일 실행파일)  │
 │  │                                 └ 플러그인: stream-bridge,      │
 │  │                                   web-search, code-tools,       │
 │  │                                   workspace-guard               │
 │  ├ Sidecar (127.0.0.1:임의포트)                                    │
 │  │   /v1/*   LLM 프록시 (도구 호출 보정, 키 주입) ──▶ LLM 게이트웨이 │
 │  │   /exec   WASM 코드 실행 (python / javascript)                  │
 │  │   /search 웹 검색 백엔드                                        │
 │  └ workspaces/<session_id>/  ← 세션의 유일한 작업 공간             │
 └──────────────────────────────────────────┘
```

- **API 서버**는 에이전트 코드를 실행하지 않는다. 대화 기록·소유권·스트림 중계만 한다.
- **워커**는 사용자 1명 전용이다. dsh 런타임, WASM 샌드박스, 세션 폴더를 가진다.
- dsh 런타임과 워커 사이, 워커와 LLM 사이에는 **사이드카**가 끼어 있어 도구 실행·검색·LLM 호출을 Python 쪽에서 통제한다.

## 한 턴의 흐름

1. 브라우저가 WebSocket으로 `{"type":"prompt","text","attachments"}` 전송.
2. `SessionHub.start_turn` → 첨부파일 검증(워커) → 사용자 메시지 기록 → 백그라운드 턴 시작.
3. `WorkerPool.use(owner)` 가 사용자 워커를 확보(없으면 기동) → `RemoteAgentService.run`.
4. 워커 `POST /sessions/{id}/turns` → `AgentService.run` → `DshAgent.run` → SDK `session/prompt`.
5. dsh 런타임이 LLM 호출(사이드카 `/v1` 경유) → 도구 호출 → `tools/pre-execute`(workspace-guard) → 실행.
6. 이벤트 경로: dsh `session.event` + `session.delta`(stream-bridge) → `AgentEvent` → 워커 NDJSON →
   API 서버 → `_record`(저장) / `_publish`(WebSocket 브로드캐스트).
7. `session.status: idle` 로 턴 종료 → `turn_done`.

## 코드 지도

| 파일 | 역할 |
|---|---|
| `src/dsh_server/app.py` | API 서버 (FastAPI): REST/WS, 인증, 워커 모드 선택 |
| `src/dsh_server/hub.py` | 세션 허브: 기록·브로드캐스트·턴 스케줄링 |
| `src/dsh_server/store.py` | 대화 기록 저장 (세션당 JSON 파일) |
| `src/dsh_server/pool.py` | 사용자별 워커 풀과 프로비저너(inprocess/remote/per-user/docker) |
| `src/dsh_server/remote.py` | 워커 HTTP 클라이언트 (`AgentBackend` 구현) |
| `src/dsh_server/worker.py` | 에이전트 워커 서버 (FastAPI) |
| `src/dsh_server/service.py` | `AgentService`: dsh + WASM + 세션 폴더 (`AgentBackend` 구현) |
| `src/dsh_server/agent.py` | `DshAgent`: SDK 래퍼, 런타임 재기동, 세션 잠금, 플러그인 설치 |
| `src/dsh_server/sidecar.py` | 사이드카 HTTP: LLM 프록시·도구 호출 보정·`/exec`·`/search` |
| `src/dsh_server/wasm_exec.py` | wasmtime 기반 Python/JS 실행기 |
| `src/dsh_server/events.py` | SDK 알림 → `AgentEvent` 변환 |
| `src/dsh_server/config.py` | 설정 (`DshSettings.from_env`) |
| `src/dsh_server/dsh_plugins/*` | dsh 런타임에 설치되는 JS 플러그인 4종 |
| `src/dsh_server/__main__.py` | 단일 실행 CLI (`python -m dsh_server "..."`) |
| `web/` | 채팅 UI (Vite + React + TS) |
| `Dockerfile.worker` | 워커 컨테이너 이미지 (설계, 미검증) |

## 웹 UI 기능

대화 목록/생성/삭제, 토큰 단위 스트리밍, 생각(reasoning) 접기, 도구 호출 카드(입력/결과),
첨부(📎 버튼·드래그 앤 드롭·붙여넣기, 업로드 진행 칩), 이미지 썸네일, 재연결, 다크 모드, 모바일 레이아웃,
`DSH_SERVER_TOKEN` 사용 시 토큰 입력 창.
