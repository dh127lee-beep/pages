# 02. dsh / SDK 조사 노트

기준: `github.com/deepseek-ai/deepseek-harness` (release-dsh-0.2.1-rc.2), PyPI `deepseek-harness-sdk==0.2.1rc2`.

## dsh 와 SDK

- `dsh` = DeepSeek Harness CLI. Cordis 기반으로 **모든 기능이 플러그인**이고, 프로필(`web`, `sdk`, `sdk-minimal` …)이
  플러그인 트리를 고르며 YAML 패치로 행(row)을 추가/변경/비활성화한다.
- Python SDK `deepseek-harness-sdk` 는 `deepseek-harness-runtime-bin` 휠의 **단일 실행 파일 런타임**을 하위 프로세스로 띄우고
  stdio 줄 단위 JSON-RPC 로 통신한다(Node 설치 불필요). 지원: linux x64/arm64, macOS 14+ arm64, win x64.
- SDK 는 런타임 환경 변수를 **항상 `os.environ.copy()` 위에 `env` 를 덮어써서** 만든다 → 런타임에서 변수를 숨기려면
  부모 프로세스 환경 자체에서 빼야 한다(워커가 `DSH_WORKER_TOKEN`, `DSH_LLM_API_KEY` 를 pop 하는 이유).
- `DSH_HOME`(또는 `dsh_home`)이 필수. 프로필·플러그인·세션 로그(JSONL)가 여기에 저장된다.

## 프로토콜 요약

| 메서드/알림 | 내용 |
|---|---|
| `initialize` | `cwd, provider, model, reasoningEffort?, maxTokens?` — **런타임 전체에 하나의 cwd** |
| `session/prompt` | `sessionId, contentBlocks` → `messageId` |
| `session/resume` | 디스크(DSH_HOME)의 세션 복원 |
| `session/working-directory/get|set` | 세션의 "현재" 작업 폴더 (경계가 아님) |
| 알림 `session.event` | 확정된 세션 이벤트 (`assistant/message`, `tool/call`, `tool/result`, `turn/end` …) |
| 알림 `session.status` | `idle` / `running` — 턴 종료 판정 |
| 알림 `subagent.started/finished` | 서브에이전트 생명주기 |

턴 완료 판정: 구독 → `session/prompt` → `agent/inbox/spliced`(messageId 포함) 이후 수집 → `session.status: idle`.

## 스레드/동시성

- `HarnessClient` 는 리더 스레드 + 쓰기 락 + 세션별 구독 큐를 가진 **스레드 안전** 구조라, 런타임 1개로 여러 세션을
  동시에 돌릴 수 있다. `DshAgent` 는 세션별 락만 두고(같은 세션 중복 턴은 `SessionBusyError`), 세션 간에는 병렬.
- 실측: 세션 3개 동시 실행 시 각 3.5초 내외로 병렬 응답, 세션 간 맥락 섞임 없음, 재시작 후 resume 정상.
- 턴 중간 취소 API 는 없다(런타임을 종료하는 수밖에 없음). 최대 턴 수·훅 같은 옵션도 SDK 에는 없다.

## 이벤트와 스트리밍

- SDK 서버는 **확정된 세션 이벤트만** 보낸다. 토큰 델타는 시도(attempt)가 끝난 뒤 `assistant/attempt` 에 묶여 기록된다
  (`assistant/chunk` 는 구버전 세션 포맷).
- 실시간 델타는 Cordis 이벤트 `agent/assistant-stream`(frame: `start` / `chunk` / `end`)에만 흐른다.
- → **stream-bridge 플러그인**이 이 이벤트를 받아 stdout 에 `session.delta` JSON-RPC 알림을 직접 쓴다.
  SDK 전송은 한 줄 = 한 번의 `write()` 라 섞이지 않고, Python SDK 는 `sessionId` 가 있는 알림을 세션 구독으로 라우팅한다.
- UI 는 attempt 단위 초안을 그리고, 확정 `assistant/message` 가 오면 교체, 재시도(abandoned)면 폐기한다.

## 플러그인 로딩 (중요한 함정 포함)

- 외부 플러그인은 `$DSH_HOME/profiles/<profile>/node_modules/<패키지>` 에 두고 패치의 `insert` 행 `name` 으로 로드된다.
  dsh-server 는 시작 시 `src/dsh_server/dsh_plugins/*` 를 복사하고 `dsh-server.plugins.patch.yml` 을 생성한다.
- ⚠️ **존재하지 않는 패키지 이름을 넣어도 런타임이 에러 없이 시작된다**(조용히 무시). 로드 여부는 별도 확인이 필요하다.
  (검증 방법: `apply()` 에서 파일을 남기는 프로브로 확인했음)
- 외부 플러그인은 하네스 내부 패키지(`@deepseek-ai/dsh-tools` 등)를 import 하지 않도록 작성했다(해석 보장 없음).
  도구는 `defineTool` 없이 **평문 ToolDefinition** (`name, description, parameters(JSON Schema), output{schema, render}, execute`)으로 등록.
- 패치 문법: `- insert: [{id, name, config?}]`, `- id: <row> config: {...}`(config **전체 교체**), `- id: <row> disabled: true`.

## 확장 지점 (사용 중)

| 지점 | 용도 |
|---|---|
| `agent/assistant-stream` | 토큰 스트리밍 (stream-bridge) |
| `ctx.web.registerSearchProvider` + `web` 행 `searchProvider` | 웹 검색 백엔드 교체 (web-search) |
| `ctx.tools.register` | `python` / `javascript` 도구 (code-tools), `exec.agent.session.id` 로 세션 식별 |
| `tools/pre-execute` waterfall (`allow`/`deny`) | 모든 도구 호출 검사 (workspace-guard) |
| `ctx.workingDirectory.ensure(agent)` | 도구의 상대 경로 기준 폴더 확인 |
| `llm-pi-ai` 행 `providers` | OpenAI 호환 게이트웨이 라우트 `local` |

## 기본 도구 (`sdk` 프로필, 25개)

`bash`, `read`, `write`, `edit`, `glob`, `grep`, `read_image`, `working_directory`, `web_search`, `web_fetch`,
`todo_write`, `skill`, `workflow`, `subagent`, `subagent_fork`, `send_message`, `list_agents`, `interrupt_agent`,
`job_list`, `job_output`, `job_kill`, `create_goal`, `get_goal`, `update_goal`, `exit_plan_mode`.

- `bash` 는 `bash-sandbox` 행, `workflow` 는 `tool-workflow` 행(JS 를 `ptc-runtime-node` 하위 프로세스로 실행).
- `bash` 의 `sandbox_permissions`(`workspace-write`/`danger-full-access`)는 **승인 요청**이 필요한데 SDK 에는 승인 채널이
  없어 즉시 거부된다(멈추지 않음): `sandbox escalation ... requires approval, but no approval channel is available`.
- 권한 모드는 `DSH_PERMISSION_MODE` 하나로 바뀐다: `sandbox-policy.mode` 와 `approval.policy`(`danger-full-access` → `never`).

## 파일 시스템 계층

- `fs-local`: 경로 제한 없음(절대 경로·`..` 허용). `config.cwd` 는 해석 기준일 뿐 경계가 아니다.
- `fs-sandbox`: **쓰기만** 세션 경계로 막는다. 읽기는 제한하지 않는다.
- 문서 권고: 엄격한 제한은 더 엄격한 `ctx.fs` 백엔드 또는 `tools/execute` 계열 권한 플러그인으로 → workspace-guard 채택.
