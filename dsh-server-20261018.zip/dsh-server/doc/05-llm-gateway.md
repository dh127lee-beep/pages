# 05. LLM 게이트웨이 연동

대상: `http://127.0.0.1:8899/v1`, 모델 `sonnet`, 키 `dummy` (OpenAI Chat Completions 호환, `/v1/models` 에 opus/sonnet/haiku/fable).

## 라우트

- dsh 의 DeepSeek 어댑터(`llm-deepseek`)는 **Anthropic Messages 프로토콜만** 쓴다(`{base}/v1/messages`) → 이 게이트웨이는 404.
- dsh 에 포함된 `llm-pi-ai` 어댑터에 OpenAI 호환 라우트 `local` 을 선언한다(`api: openai-completions`). 시작 시
  `$DSH_HOME/dsh-server.local-llm.patch.yml` 생성. 키는 `apiKeyEnv: DSH_SERVER_LLM_API_KEY` 참조.
- `sdk` 프로필은 `dsh-base` 를 포함하므로 `llm-pi-ai` 행이 이미 있다(라우트 0개로 대기 상태).

## 도구 호출 보정 (사이드카 `/v1`)

관찰:
- 게이트웨이는 `tools` / `tool_calls` / `role: tool` 을 지원하지만, **응답의 tool call 변환이 불안정**하다.
  같은 요청을 반복하면 정상 `tool_calls` 와 `<invoke name="…"><parameter …>` 텍스트가 섞여 나온다
  (모델이 `<function_calls>` 래퍼 없이 쓰면 텍스트로 흘리는 것으로 추정).
- 이 경우 dsh 는 도구를 실행하지 않고 그 마크업을 답변으로 보여준다(사용자가 본 "삼성전자 주가" 사례).

보정:
- dsh 런타임 → 사이드카 `/v1/*` → 게이트웨이. 요청은 그대로 전달.
- 응답 텍스트에서 `<function_calls` / `<invoke` 를 감지하면 그 뒤를 버퍼링하고, 메시지 끝에서 파싱해 OpenAI `tool_calls` 로
  변환, `finish_reason: tool_calls`. 스트리밍(SSE)·비스트리밍 모두. 태그 접두어일 수 있는 꼬리(`<`, `<inv` …)만 잠깐 보류.
- 파서: `name="x"` / `name='x'` / `name=x`, `antml:` 접두어, `<parameter>` 값은 스키마가 string 이면 그대로, 아니면 JSON 파싱
  시도, `<invoke>` 안에 JSON 객체가 바로 오는 형태도 허용, 도구 이름 대소문자 보정(`Bash` → `bash`).
- 파싱 결과 인자가 비면 원문을 서버 로그(WARNING)에 남긴다. 테스트 중 인자가 빈 `bash({})` 호출이 2회 관찰됨(모델이 곧바로 재시도) — 원인 추적 중.
- 끄기: `DSH_TOOL_REPAIR=0`.

## 키 주입

사이드카가 업스트림 요청의 `Authorization` 을 실제 키로 덮어쓴다. dsh 런타임 환경에는 `via-sidecar` 만 들어간다.

## 스트리밍

게이트웨이는 SSE 로 잘 스트리밍한다. dsh SDK 가 델타를 안 보내는 문제는 stream-bridge 플러그인으로 해결(02 문서 참조).
실측: 첫 토큰 약 2~3초, 완료 4~5초 수준.

## 비전(이미지)

- 게이트웨이는 `image_url` 입력을 **무시**한다("이미지가 첨부되지 않았다"고 응답).
- 그래서 기본 `DSH_VISION=0`: 첨부 이미지는 세션 폴더에만 저장, 모델에는 경로 목록만 전달.
- 비전 지원 엔드포인트라면 `DSH_VISION=1` → 이미지 블록 전달(파일당 5MB 이하), 라우트 모델 `input: [text, image]`.

## 기타 관찰

- 게이트웨이가 잠시 내려가 있으면 dsh 는 5회 재시도 후 `turn/end reason=error (TRANSPORT Connection error)` 로 끝난다.
- 웹 검색: dsh 기본 검색(`deepseek-official`)은 DeepSeek 키 필요 → web-search 플러그인으로 사이드카 `/search` 에 연결.
  기본은 더미 결과. 이 개발 머신에서 DuckDuckGo HTML 엔드포인트는 202(봇 차단)라 실검색은 넣지 않았다.
  `DshAgent(settings, search=fn)` / `AgentService(..., search=fn)` 로 `(query, max_results) -> {content, sources[]}` 교체.
