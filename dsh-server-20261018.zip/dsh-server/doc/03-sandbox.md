# 03. 코드 실행과 샌드박스

요구사항: **세션의 모든 도구가 그 세션 폴더로 제한**되어야 하고, 커널 기능이 막힌 **컨테이너 안**에서 동작해야 한다.

## 1. dsh 기본 샌드박스 분석

### 동작 방식 (소스 확인)

- `bash` → dsh 런타임 → `sandbox-local` 이 명령을 감싸 실행 → `bash -c "<cmd>"` (서버 계정 권한, 매 호출 새 셸).
- 러너 체인: Linux `bwrap` → `Landlock`, macOS `Seatbelt(sandbox-exec)`, Windows ACL 러너.
  사용 가능한 러너가 없으면 **fail-closed**(`SANDBOX_UNAVAILABLE`) — 샌드박스 없이 실행하지 않는다.
- 기본 모드 `workspace-write`: **쓰기만** 제한(작업 폴더, `/tmp`). 읽기·네트워크는 열림.
- bwrap 프로필: `--ro-bind / / --dev /dev --unshare-pid --proc /proc --die-with-parent`, `--tmpfs /tmp`,
  작업 폴더 `--bind`. `--unshare-net` 없음 → 네트워크 공유. bwrap 은 **시스템 PATH 의 바이너리**를 쓴다(번들 아님).
  탐지 프로브: `bwrap --ro-bind / / --dev /dev --unshare-pid --proc /proc --die-with-parent -- true`.

### macOS 실측 (서버와 동일 조건, 세션 workdir 지정)

| 동작 | 결과 |
|---|---|
| 세션 작업 폴더 쓰기 | 허용 |
| `/tmp` 쓰기 | 허용 |
| 홈(`~`) 쓰기 | 차단 (`Operation not permitted`) |
| **런타임 cwd(`DSH_WORKSPACE`) 쓰기** | **허용** ⚠️ |
| `/etc`, 홈 디렉터리 읽기 | 허용 |
| 네트워크 (`curl https://example.com`) | 허용 (200) |
| `danger-full-access` 권한 상승 요청 | 승인 채널 없음 → 즉시 거부 |

**핵심 문제**: 쓰기 경계는 "세션의 불변 cwd" = `initialize` 때의 **런타임 cwd 하나**다.
`session/working-directory/set` 은 현재 폴더만 바꿀 뿐 경계를 바꾸지 못한다. 런타임을 프로젝트 폴더에서 띄우면
에이전트가 서버 소스·다른 세션 기록까지 쓸 수 있었다. (현재 구조에서는 런타임 cwd = 워커의 `workspaces/` 로 고정)

### 컨테이너에서의 제약

- bwrap 은 unprivileged user namespace 가 필요 → Docker/k8s 기본 seccomp, Ubuntu 24.04 AppArmor
  (`kernel.apparmor_restrict_unprivileged_userns=1`), RHEL7(`user.max_user_namespaces=0`)에서 실패.
- Landlock 은 커널 5.13+ 필요, 쓰기 경로만 제한. 커널 접근이 막힌 환경이면 이것도 불가 가능성이 높다.
- 둘 다 실패하면 `bash` 가 매번 에러 → 유일한 우회는 `DSH_PERMISSION_MODE=danger-full-access`(샌드박스 완전 해제).
- 결론: **컨테이너 = 격리 경계**로 두고, 컨테이너 안에서는 커널 기능 없이 동작하는 다른 격리가 필요하다.

## 2. WASM 채택

dsh 저장소에는 WASM 실행 경로가 없다(`ptc-runtime` 은 하위 프로세스 + 같은 샌드박스 정책). 직접 붙였다.

- 엔진: `wasmtime` (Python 패키지 49.0.0), 프로세스 내 JIT. 커널 기능 불필요(실행 가능 메모리 할당만 필요).
- Python: CPython 3.15 WASI 빌드 (`brettcannon/cpython-wasi-build` v3.15.0, sha256 고정, 43MB 압축 해제 후).
- JavaScript: QuickJS-ng 0.17.0 `qjs-wasi.wasm` (sha256 고정, 1.5MB).
- 게스트에 보이는 것: `/workspace`(세션 폴더, 읽기/쓰기, cwd), `/exec`(프로그램, 읽기 전용), Python 은 `/lib`(stdlib, 읽기 전용).
- 제한: 벽시계 시간(epoch interruption, 기본 30초/최대 120초, 엔진 공용 50ms 티커 + 스토어별 데드라인이라 서로 간섭 없음),
  메모리(기본 512MB), 출력 20,000자.

### 실측 결과

| 테스트 | Python | JavaScript |
|---|---|---|
| 계산 / 최신 문법 | ✅ | ✅ ES2023, BigInt, top-level await |
| 작업 폴더 파일 읽기/쓰기 | ✅ (호스트에 반영) | ✅ `qjs:std` |
| `/etc/passwd`, 홈 읽기 | 🚫 FileNotFoundError | 🚫 `null` |
| `/workspace/../../etc/hosts` | 🚫 Operation not permitted | — |
| 네트워크 | 🚫 `_socket` 에 getaddrinfo 없음 | 🚫 `fetch` 없음 |
| 하위 프로세스 | 🚫 "wasi does not support processes" | 🚫 |
| 무한 루프 | ⏱ 제한 시간에 중단 (다른 실행은 영향 없음) | ⏱ |
| 1GB 할당 | 🚫 MemoryError | — |
| 성능 | 모듈 캐시 후 실행당 0.01~0.1초 | 유사 |

### 한계

- **셸이 없다.** `bash`, 파이프, `pip install` 불가. 코드 실행은 `python` / `javascript` 도구로만.
- Python 은 표준 라이브러리 + 순수 Python 만. **numpy/pandas 등 C 확장 불가** (필요하면 Pyodide 검토: Node 필요, 무거움).
- JavaScript 는 Node.js 가 아니다. `require`, `node:` 모듈, npm, `fetch` 없음. Node 자체는 WASI 로 빌드할 수 없다.
- 입력 이미지 등 바이너리 처리는 순수 Python 범위에서만.

## 3. 모든 도구의 세션 폴더 제한 (workspace-guard)

WASM 은 코드 실행만 막는다. dsh 의 파일 도구(`read/write/edit/glob/grep/read_image`)는 런타임 프로세스 안에서 직접
돌기 때문에 별도 통제가 필요했다. `tools/pre-execute` waterfall 에 가드 플러그인을 건다(모든 도구 호출이 통과).

1. **기본 거부(allowlist)**: 아래 외 도구는 전부 거부 — 새 도구, MCP 도구(`mcp__*`)도 자동 차단.

   | 허용 | 경로 인자 검사 |
   |---|---|
   | `read`, `read_image`, `write`, `edit` | `file_path` |
   | `glob`, `grep` | `path` (+ `pattern`/`include` 는 상대 패턴만) |
   | `working_directory` | `cd` |
   | `python`, `javascript` | 실행 자체가 WASM 안 |
   | `web_search`, `web_fetch`, `todo_write`, `*_goal`, `skill`, `exit_plan_mode` | 파일 접근 없음 |

   거부: `bash`, `workflow`, `subagent`, `subagent_fork`(별도 `cwd` 인자), `send_message`, `list_agents`,
   `interrupt_agent`, `job_*`. 그중 `bash-sandbox`, `tool-workflow` 행은 WASM 모드에서 아예 비활성화해 도구 목록에서도 뺀다.

2. **경로 검사**: `$DSH_SERVER_WORKSPACES_ROOT/<sessionId>` 를 realpath 로 고정하고, 인자를
   현재 작업 폴더 기준으로 해석한 뒤 **가장 가까운 존재하는 조상까지 realpath** 해서(심볼릭 링크 우회 차단,
   아직 없는 파일도 검사) 세션 폴더 안인지 확인. `~` 와 `..` 세그먼트는 무조건 거부. 작업 폴더 자체가 밖이면 거부.
3. 실패 시 모델에 `[sandbox] ... is outside the session workspace` 형태의 이유를 돌려준다.

### 실측 (AgentService, 사용자별 워커 모두)

- `read /etc/hosts`, 형제 폴더의 `secret.txt`, `write ../escape.txt`, `glob /etc/*` → 전부 거부, 파일 생성 없음.
- 다른 사용자의 업로드 파일을 절대 경로로 `read` → 거부, `python` 으로 open → 경로 자체가 없음.
- `bash` 는 도구 목록에 없어 시도조차 되지 않음.

## 4. 남은 위험

- **같은 사용자의 세션끼리**: 워커 하나가 사용자의 모든 세션을 담는다. 가드/WASM 이 세션 폴더를 강제하므로 도구로는
  넘어갈 수 없지만, 런타임 프로세스 수준 격리는 사용자 단위다.
- **`web_fetch`**: 네트워크 접근. dsh 의 HTTP fetch 는 공개 HTTP(S) 목적지만 허용하고 매 연결을 검증한다고 문서화되어
  있으나 내부망 차단은 컨테이너 네트워크 정책으로도 막아야 한다.
- **가드 우회 가능성**: 가드는 알려진 도구의 알려진 경로 인자만 검사한다. 허용 목록에 도구를 추가할 때는 그 도구의
  모든 파일 관련 인자를 `ALLOWED` 에 등록해야 한다(기본 거부라 등록 전에는 실행 불가).
- **dsh 의 `skill` 도구**는 dsh 홈의 스킬 문서를 읽는다(읽기 전용, 하네스 내용). 사용자 데이터 접근은 아님.
- 컨테이너 운영에서는 `DSH_PERMISSION_MODE=danger-full-access` 로 두므로(커널 샌드박스 없음) `grep` 등이 띄우는
  ripgrep 은 무제한 프로세스다. 경로 인자는 가드가 검사하고, 최종 경계는 사용자별 컨테이너다.
