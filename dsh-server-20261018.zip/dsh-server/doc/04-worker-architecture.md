# 04. API 서버 / 사용자별 에이전트 워커 분리

## 왜 분리하나

- 에이전트는 사용자 입력에 따라 코드를 실행하고 파일을 만진다. 같은 프로세스·컨테이너에 API 서버의 비밀값(토큰),
  다른 사용자의 대화 기록과 파일이 있으면 도구 제한이 한 번만 뚫려도 전부 노출된다.
- dsh 런타임 하나는 **cwd(=OS 샌드박스 쓰기 경계)가 하나**뿐이라 런타임 안에서 사용자 간 격리를 만들 수 없다.
- 그래서 **사용자마다 워커(= dsh 런타임 + WASM + 세션 폴더)를 따로** 둔다.

검토한 대안: (B) 코드 실행만 원격 서버로 분리 → dsh 파일 도구는 API 서버 쪽 파일을, 코드는 실행 서버 파일을 보게 되어
작업 폴더가 둘로 갈라지고 dsh 런타임이 여전히 API 서버 안에 남아 분리 효과가 약해서 기각.

## 구성

```
API 서버 ── WorkerPool ── Provisioner ──┬─ LocalProcessProvisioner  (사용자별 프로세스, 개발·단일 호스트)
                                        ├─ DockerProvisioner        (사용자별 컨테이너, 운영)
                                        ├─ RemoteProvisioner        (고정 워커 1개 공유)
                                        └─ InProcessProvisioner     (API 서버 안, 개발 전용·격리 없음)
```

`DSH_WORKER_MODE` = `per-user`(기본) | `docker` | `remote` | `inprocess`.

### 사용자 식별

- 현재 "사용자" = 브라우저가 만든 `X-Client-Id`(localStorage UUID). **인증이 아니다.** 운영에서는 로그인 사용자 ID 로
  바꿔야 한다(`app.py` 의 `require_client`). 워커 키 = `sha256(owner)[:20]`.

### WorkerPool

- `async with pool.use(owner) as backend:` — 워커가 없으면 기동(사용자별 락으로 중복 기동 방지), 리스(lease) 카운트 증가.
- 턴이 도는 동안 리스를 쥐고 있으므로 **실행 중인 워커는 종료되지 않는다**.
- 리퍼: 리스 0 이고 마지막 사용 후 `DSH_WORKER_IDLE_SECONDS`(기본 900초) 지나면 종료. 다음 요청 때 다시 기동하고
  세션은 워커 데이터의 dsh 홈에서 resume 된다.
- API 서버 종료 시 모든 워커 종료.

## API 서버 ↔ 워커 프로토콜

인증: `Authorization: Bearer <워커별 랜덤 토큰>` (프로비저너가 기동 시 생성). 워커는 시작 즉시 토큰을 환경에서 제거한다.

| 메서드 | 경로 | 설명 |
|---|---|---|
| GET | `/health` | `model, profile, vision, code_exec` |
| POST | `/sessions/{id}/turns` | `{text, attachments, resume}` → NDJSON: `{"event":…}`* 후 `{"result":…}` 또는 `{"error","code"}` |
| POST | `/sessions/{id}/attachments/check` | 첨부 경로 검증·정규화 |
| POST | `/sessions/{id}/files` | multipart 업로드 → `uploads/` |
| GET | `/sessions/{id}/files/{path}` | 세션 폴더 파일 스트리밍 (`X-File-Name` = UTF-8 hex) |
| DELETE | `/sessions/{id}` | 세션 잊기 + 세션 폴더 삭제 |

- 턴 스트림은 읽기 타임아웃 없음(에이전트가 오래 일할 수 있음). API 서버 연결이 끊겨도 워커의 턴은 끝까지 돈다.
- 중복 턴: API 서버가 실행 중 세션을 추적해 1차로 막고, 워커가 409/`busy` 로 2차로 막는다.
- 세션 ID 는 `^[A-Za-z0-9_-]{1,80}$` 만 허용(경로 조작 방지).

## 환경 변수 격리

- 워커에 넘기는 변수 = 허용 목록(`PATH, LANG, TZ, 프록시, SSL…`) + `DSH_*`, `DEEPSEEK_*` − API 서버 전용
  (`DSH_SERVER_TOKEN`, 데이터 경로, 워커 설정 등). (`pool.worker_env`)
- 워커는 시작 시 `DSH_WORKER_TOKEN`, `DSH_LLM_API_KEY` 를 `os.environ` 에서 제거 → dsh 런타임은 상속하지 않는다.
- LLM 키는 **사이드카가 업스트림 요청에 주입**하고 런타임에는 자리표시자 `via-sidecar` 만 준다.
- 실측: 워커의 dsh 런타임 자식 프로세스 환경에 비밀 변수 0개, `DSH_SERVER_LLM_API_KEY=via-sidecar`.

## 데이터 배치

```
.dsh-server/                      (API 서버 DSH_SERVER_DATA)
├─ sessions/<session>.json        대화 기록, 소유자
└─ workers/users/<owner_key>/     per-user 모드 워커 데이터 (docker 모드에서는 볼륨 dsh-user-<key>)
   ├─ dsh-home/                   dsh 프로필·플러그인·세션 로그 (resume 원천)
   ├─ workspaces/<session>/       세션 폴더 (업로드는 uploads/)
   └─ worker.log
~/.cache/dsh-server/wasm/         CPython/QuickJS WASI 바이너리 (공유 캐시, 이미지에선 /opt/dsh-wasm)
```

## 운영(컨테이너) 설계 — DockerProvisioner

구현은 `pool.DockerProvisioner`, 이미지는 `Dockerfile.worker`. **개발 환경에 Docker 가 없어 실행 검증은 하지 않았다.**

- API 서버와 워커가 같은 사용자 정의 네트워크(`DSH_WORKER_NETWORK`, 기본 `dsh`)에 있고, 워커는 `http://dsh-worker-<key>:8100`.
- 컨테이너 옵션: `--read-only`, `--tmpfs /tmp`, `--cap-drop ALL`, `--security-opt no-new-privileges`,
  `--memory 2g --cpus 1 --pids-limit 256`, 볼륨 `dsh-user-<key>:/data`, 비루트 사용자(uid 10001).
- 이미지 환경: `DSH_PERMISSION_MODE=danger-full-access`(컨테이너 안에 커널 샌드박스 없음), `DSH_CODE_EXEC=wasm`,
  `DSH_CONFINE_TOOLS=1`, WASM 바이너리 사전 내장.
- 네트워크 송신 정책: 워커는 LLM 게이트웨이와(web_fetch 를 허용한다면) 인터넷만 필요. 내부망·메타데이터 엔드포인트 차단 권장.
- API 서버가 Docker 소켓을 쓰므로 API 서버 자체는 신뢰 영역에 둔다. 더 엄격하게는 별도 "워커 매니저" 서비스로 분리.

### Kubernetes 로 옮길 때

- 프로비저너를 "사용자별 Pod(또는 StatefulSet replica) 생성 + Service/헤드리스 DNS" 로 구현.
- PVC 를 사용자별로, `securityContext`: `runAsNonRoot`, `readOnlyRootFilesystem`, `allowPrivilegeEscalation: false`,
  `capabilities.drop: [ALL]`, `seccompProfile: RuntimeDefault`(WASM 은 추가 권한 불필요). NetworkPolicy 로 송신 제한.

## 확장 시 고려

- API 서버를 여러 대 두려면: 대화 기록 저장소 공유(DB), 사용자 → 워커 주소 레지스트리 공유, 같은 사용자의 워커 중복 기동 방지(분산 락).
- 워커 크래시: `DshAgent` 가 런타임 크래시는 자동 재기동한다. 워커 프로세스 자체가 죽으면 현재는 다음 요청이 실패한다 →
  헬스 체크 실패 시 슬롯 재기동 로직 추가 필요(남은 과제).
