# 06. 운영

## 실행 (개발)

```bash
uv sync
uv run dsh-server                      # API 서버 :8000, 사용자별 워커 프로세스 자동 기동
cd web && npm install && npm run dev   # 웹 UI :5173 (/api → :8000 프록시, WebSocket 포함)
```

- 첫 실행 시 WASM 바이너리(CPython 15MB zip, QuickJS 1.5MB)를 `~/.cache/dsh-server/wasm` 에 내려받는다(sha256 검증).
- 첫 요청 때 사용자 워커가 뜬다(약 2~3초: dsh 런타임 + WASM 모듈 로드).
- 단독 워커: `DSH_WORKER_TOKEN=… DSH_WORKER_PORT=8100 uv run dsh-worker` → API 서버는 `DSH_WORKER_MODE=remote DSH_WORKER_URL=… DSH_WORKER_TOKEN=…`.
- CLI 한 번 실행: `uv run python -m dsh_server "질문" --workspace DIR` (워커/가드 없이 dsh 기본 도구 사용 — 신뢰 환경 전용).

## 환경 변수

### API 서버

| 변수 | 기본값 | 설명 |
|---|---|---|
| `DSH_SERVER_HOST` / `DSH_SERVER_PORT` | `127.0.0.1` / `8000` | |
| `DSH_SERVER_DATA` | `./.dsh-server` | 대화 기록, per-user 워커 데이터 |
| `DSH_SERVER_TOKEN` | (없음) | 설정 시 모든 요청에 Bearer 토큰 필요 |
| `DSH_CORS_ORIGINS` | `http://localhost:5173` | 쉼표 구분 |
| `DSH_MAX_CONCURRENT_TURNS` | `32` | 동시에 진행할 턴 수(스레드) |
| `DSH_WORKER_MODE` | `per-user` | `per-user` / `docker` / `remote` / `inprocess` |
| `DSH_WORKER_IDLE_SECONDS` | `900` | 유휴 워커 종료 시간 |
| `DSH_WORKER_IMAGE` / `DSH_WORKER_NETWORK` | — / `dsh` | docker 모드 |
| `DSH_WORKER_URL` / `DSH_WORKER_TOKEN` | — | remote 모드 |

### 워커 (API 서버가 필요한 것만 전달)

| 변수 | 기본값 | 설명 |
|---|---|---|
| `DSH_WORKER_TOKEN` | (필수) | API 서버 ↔ 워커 인증. 시작 시 환경에서 제거 |
| `DSH_WORKER_HOST` / `DSH_WORKER_PORT` / `DSH_WORKER_DATA` | `127.0.0.1` / `8100` / `./.dsh-worker` | |
| `DSH_PROVIDER` | `local` | `local`=아래 게이트웨이, `deepseek-official`=DeepSeek 직접 |
| `DSH_LLM_BASE_URL` | `http://127.0.0.1:8899/v1` | |
| `DSH_LLM_API_KEY` | `dummy` | 사이드카만 보관, 런타임에는 미전달 |
| `DSH_LLM_API` | `openai-completions` | `openai-responses` / `anthropic-messages` |
| `DSH_MODEL` | `sonnet` | |
| `DSH_PROFILE` | `sdk` | dsh 프로필 |
| `DSH_CODE_EXEC` | `wasm` | `wasm`: python/javascript 도구, bash·workflow 제거. `native`: dsh 기본(bash) |
| `DSH_CONFINE_TOOLS` | `1` | workspace-guard 설치 (모든 도구를 세션 폴더로 제한) |
| `DSH_PERMISSION_MODE` | dsh 기본(`workspace-write`) | 컨테이너에선 `danger-full-access` |
| `DSH_WASM_DIR` | `~/.cache/dsh-server/wasm` | WASI 바이너리 위치 |
| `DSH_STREAM` | `1` | 토큰 스트리밍 플러그인 |
| `DSH_TOOL_REPAIR` | `1` | 텍스트 `<invoke>` → tool call 보정 + 키 주입 |
| `DSH_WEB_SEARCH` | `1` | web_search 를 사이드카 검색(기본 더미)으로 |
| `DSH_VISION` | `0` | 첨부 이미지를 모델에 이미지로 전달 |
| `DSH_REASONING_EFFORT`, `DSH_MAX_TOKENS`, `DSH_REQUEST_TIMEOUT`, `DSH_PATCHES` | — | dsh 세부 설정 |

## 배포 (컨테이너)

```bash
docker network create dsh
docker build -f Dockerfile.worker -t dsh-worker .
# API 서버 (Docker 소켓 필요)
DSH_WORKER_MODE=docker DSH_WORKER_IMAGE=dsh-worker DSH_WORKER_NETWORK=dsh uv run dsh-server
```

> Docker 모드와 `Dockerfile.worker` 는 개발 환경(Docker 없음)에서 실행 검증되지 않았다. 첫 배포 전 확인 항목:
> 이미지 빌드, `dsh-worker` 기동·헬스, WASM 실행(JIT 용 실행 가능 메모리 허용 여부), dsh 런타임 바이너리(linux 휠) 동작,
> 워커 이름 DNS 해석, 볼륨 권한(uid 10001), 송신 네트워크 정책.

컨테이너 커널 기능 확인(참고):
```bash
bwrap --ro-bind / / --dev /dev --unshare-pid --proc /proc --die-with-parent -- true && echo bwrap-ok
sysctl user.max_user_namespaces kernel.unprivileged_userns_clone kernel.apparmor_restrict_unprivileged_userns
```
WASM 방식에서는 둘 다 필요 없다.

## 로그와 진단

- API 서버: stdout(uvicorn + `dsh_server.*`).
- per-user 워커: `.dsh-server/workers/users/<key>/worker.log`.
- 사이드카: `repaired N text tool call(s)`, `tool call … has no parsable arguments` (WARNING).
- dsh 세션 원본 로그: 워커 `dsh-home/sessions/` (JSONL).
- 상태: `GET /api/health` → `{model, profile, code_exec, workers, mode}`.

## 데이터 마이그레이션 메모

이 구조 이전(단일 프로세스) 버전에서 만든 `.dsh-server/sessions/*.json` 대화는 dsh 세션 원본이 예전 `.dsh-home` 에 있어
새 워커에서 이어서 대화(resume)할 수 없다. 기록 열람은 가능하다. 필요하면 정리한다.
