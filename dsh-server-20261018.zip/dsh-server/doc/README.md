# dsh-server 설계 문서

DeepSeek Harness(`dsh`) Python SDK 위에 만든 다중 사용자 에이전트 채팅 서버의 설계·조사·결정 기록.

| 문서 | 내용 |
|---|---|
| [01-overview.md](01-overview.md) | 목표, 전체 구조, 구성 요소, 요청 흐름, 코드 지도 |
| [02-dsh-sdk-notes.md](02-dsh-sdk-notes.md) | dsh/SDK 조사 결과: 프로필, 프로토콜, 이벤트, 플러그인, 도구, 확장 지점 |
| [03-sandbox.md](03-sandbox.md) | 코드 실행과 샌드박스: dsh 샌드박스 분석, 컨테이너 제약, WASM 채택, 도구 경로 제한 |
| [04-worker-architecture.md](04-worker-architecture.md) | API 서버 / 사용자별 에이전트 워커 분리 설계 |
| [05-llm-gateway.md](05-llm-gateway.md) | 로컬 LLM 게이트웨이 연동: 라우트, 도구 호출 보정, 스트리밍, 비전 |
| [06-operations.md](06-operations.md) | 실행 방법, 환경 변수, 데이터 디렉터리, 배포 |
| [07-decisions-and-open-issues.md](07-decisions-and-open-issues.md) | 주요 결정 기록과 남은 과제 |

작성 기준일: 2026-10-18. 기준 버전: `deepseek-harness-sdk==0.2.1rc2`
(저장소 `deepseek-ai/deepseek-harness` release-dsh-0.2.1-rc.2), `wasmtime==49.0.0`.
