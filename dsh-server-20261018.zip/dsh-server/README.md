# dsh-server

DeepSeek Harness(`dsh`) Python SDK 위에 만든 다중 사용자 에이전트 채팅 서버와 웹 UI.

- API 서버(대화 기록·스트리밍)와 **사용자별 에이전트 워커**(dsh 런타임·코드 실행·세션 폴더) 분리
- 코드 실행은 **WASM 샌드박스**(CPython / QuickJS on wasmtime) — 커널 샌드박스 없는 컨테이너에서도 동작
- 세션의 **모든 도구가 세션 폴더로 제한**(workspace-guard, 기본 거부)
- 토큰 스트리밍, 첨부파일, 웹 검색(교체 가능), 로컬 LLM 게이트웨이의 텍스트 tool call 보정

```
브라우저 ⇄ API 서버 (app.py, hub.py) ──HTTP──▶ 사용자별 워커 (worker.py: dsh + WASM + workspaces)
```

## 빠른 시작

```bash
uv sync
uv run dsh-server                      # http://127.0.0.1:8000 (사용자별 워커 자동 기동)
cd web && npm install && npm run dev   # http://localhost:5173
```

기본 LLM: `http://127.0.0.1:8899/v1`, 모델 `sonnet`, 키 `dummy` (`DSH_LLM_BASE_URL`, `DSH_MODEL`, `DSH_LLM_API_KEY`).

## 문서

설계·조사·결정 기록은 [`doc/`](doc/README.md) 에 있다.

| | |
|---|---|
| [개요](doc/01-overview.md) | 구조, 흐름, 코드 지도 |
| [dsh/SDK 노트](doc/02-dsh-sdk-notes.md) | 프로토콜, 이벤트, 플러그인, 도구, 함정 |
| [샌드박스](doc/03-sandbox.md) | dsh 샌드박스 실측, WASM, 도구 경로 제한 |
| [워커 구조](doc/04-worker-architecture.md) | API/워커 분리, 사용자별 워커, 컨테이너 설계 |
| [LLM 게이트웨이](doc/05-llm-gateway.md) | 라우트, tool call 보정, 비전 |
| [운영](doc/06-operations.md) | 실행, 환경 변수, 배포 |
| [결정과 과제](doc/07-decisions-and-open-issues.md) | 결정 기록, 남은 과제, 검증 이력 |
