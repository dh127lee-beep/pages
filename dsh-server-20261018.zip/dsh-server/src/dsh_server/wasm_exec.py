"""Run untrusted Python and JavaScript inside WebAssembly (WASI), hosted by wasmtime.

- Python: CPython compiled to WASI; the stdlib is mounted read-only at ``/lib``.
- JavaScript: QuickJS-ng compiled to WASI (ES2023 plus the ``qjs:std`` and
  ``qjs:os`` modules; no Node.js APIs, npm or fetch).

Each run sees one workspace (read-write at ``/workspace``, also its working
directory) and a read-only ``/exec`` holding the program. Guests have no
network, no subprocesses and no host environment variables. Wall time is
bounded with epoch interruption and memory with a store limit, so no kernel
sandboxing features (namespaces, seccomp, Landlock) are required.
"""

from __future__ import annotations

import hashlib
import logging
import math
import shutil
import tempfile
import threading
import time
import urllib.request
import zipfile
from dataclasses import dataclass
from pathlib import Path

from wasmtime import Config, Engine, ExitTrap, Linker, Module, Store, WasiConfig

log = logging.getLogger(__name__)

# Pinned CPython WASI build (https://github.com/brettcannon/cpython-wasi-build).
PYTHON_WASM_URL = (
    "https://github.com/brettcannon/cpython-wasi-build/releases/download/v3.15.0/python-3.15.0-wasi_sdk-33.zip"
)
PYTHON_WASM_SHA256 = "00b791b3729230f97a625087f534d71978433fb1e068e13a9cac8cd3f2541742"

# Pinned QuickJS-ng WASI build (https://github.com/quickjs-ng/quickjs).
QJS_WASM_URL = "https://github.com/quickjs-ng/quickjs/releases/download/v0.17.0/qjs-wasi.wasm"
QJS_WASM_SHA256 = "42a732a676ec2d93488c19411e0fad283bf72658fdad746f089914b523c783b1"

_TICK_SECONDS = 0.05
# Python runs /exec/main.py with /workspace as its cwd.
_PY_BOOTSTRAP = "import os, runpy; os.chdir('/workspace'); runpy.run_path('/exec/main.py', run_name='__main__')"
# QuickJS resolves relative paths against "/", so the program starts by entering the workspace.
_JS_PRELUDE = "import * as os from 'qjs:os';\nos.chdir('/workspace');\n"


def _download(url: str, sha256: str, dest: Path) -> None:
    log.info("downloading %s", url)
    with urllib.request.urlopen(url, timeout=300) as resp, dest.open("wb") as out:
        shutil.copyfileobj(resp, out)
    digest = hashlib.sha256(dest.read_bytes()).hexdigest()
    if digest != sha256:
        dest.unlink()
        raise RuntimeError(f"checksum mismatch for {url}: {digest}")


def ensure_python_wasm(root: Path) -> Path:
    """Download and unpack the pinned CPython WASI build into ``root`` if missing."""
    if (root / "python.wasm").is_file() and (root / "lib").is_dir():
        return root
    root.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=root.parent) as tmp:
        archive = Path(tmp) / "python-wasi.zip"
        _download(PYTHON_WASM_URL, PYTHON_WASM_SHA256, archive)
        with zipfile.ZipFile(archive) as zf:
            zf.extractall(Path(tmp) / "unpacked")
        for item in Path(tmp, "unpacked").iterdir():
            target = root / item.name
            if target.is_dir():
                shutil.rmtree(target)
            elif target.exists():
                target.unlink()
            shutil.move(str(item), target)
    return root


def ensure_qjs_wasm(root: Path) -> Path:
    """Download the pinned QuickJS-ng WASI binary into ``root`` if missing; return its path."""
    target = root / "qjs-wasi.wasm"
    if not target.is_file():
        root.mkdir(parents=True, exist_ok=True)
        part = target.with_suffix(".part")
        _download(QJS_WASM_URL, QJS_WASM_SHA256, part)
        part.replace(target)
    return target


@dataclass(slots=True)
class ExecResult:
    output: str
    exit_code: int
    timed_out: bool
    truncated: bool
    duration_ms: int

    def to_dict(self) -> dict[str, object]:
        return {
            "output": self.output,
            "exitCode": self.exit_code,
            "timedOut": self.timed_out,
            "truncated": self.truncated,
            "durationMs": self.duration_ms,
        }


class WasmSandbox:
    """One wasmtime engine shared by every Python and JavaScript run."""

    def __init__(
        self,
        root: Path,
        *,
        default_timeout: float = 30.0,
        max_timeout: float = 120.0,
        memory_mb: int = 512,
        max_output_chars: int = 20_000,
    ) -> None:
        self.default_timeout = default_timeout
        self.max_timeout = max_timeout
        self.memory_mb = memory_mb
        self.max_output_chars = max_output_chars

        self._python_root = ensure_python_wasm(root / "python")
        qjs_path = ensure_qjs_wasm(root / "quickjs")

        config = Config()
        config.epoch_interruption = True
        config.cache = True
        self._engine = Engine(config)
        started = time.monotonic()
        self._python = Module.from_file(self._engine, str(self._python_root / "python.wasm"))
        self._qjs = Module.from_file(self._engine, str(qjs_path))
        log.info("wasm runtimes ready in %.2fs", time.monotonic() - started)

        # One ticker drives every store's deadline, so runs never interrupt each other.
        self._stop = threading.Event()
        self._ticker = threading.Thread(target=self._tick, name="wasm-epoch", daemon=True)
        self._ticker.start()

    def _tick(self) -> None:
        while not self._stop.wait(_TICK_SECONDS):
            self._engine.increment_epoch()

    def close(self) -> None:
        self._stop.set()

    def run(self, language: str, code: str, workspace: Path, timeout: float | None = None) -> ExecResult:
        if language == "python":
            return self._run(
                self._python,
                "main.py",
                code,
                ["python", "-I", "-c", _PY_BOOTSTRAP],
                [("PYTHONHOME", "/"), ("PYTHONDONTWRITEBYTECODE", "1"), ("PYTHONUNBUFFERED", "1")],
                [(self._python_root / "lib", "/lib")],
                workspace,
                timeout,
            )
        if language == "javascript":
            return self._run(
                self._qjs, "main.mjs", _JS_PRELUDE + code, ["qjs", "--std", "/exec/main.mjs"], [], [], workspace, timeout
            )
        raise ValueError(f"unsupported language: {language}")

    def _run(
        self,
        module: Module,
        filename: str,
        code: str,
        argv: list[str],
        env: list[tuple[str, str]],
        readonly_dirs: list[tuple[Path, str]],
        workspace: Path,
        timeout: float | None,
    ) -> ExecResult:
        timeout = min(max(timeout or self.default_timeout, 1.0), self.max_timeout)
        workspace.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(prefix="dsh-exec-") as tmp:
            exec_dir = Path(tmp) / "exec"
            exec_dir.mkdir()
            (exec_dir / filename).write_text(code, "utf-8")
            output_path = Path(tmp) / "output.txt"

            wasi = WasiConfig()
            wasi.argv = argv
            wasi.env = env
            for host_dir, guest_dir in readonly_dirs:
                wasi.preopen_dir(str(host_dir), guest_dir, False)
            wasi.preopen_dir(str(exec_dir), "/exec", False)
            wasi.preopen_dir(str(workspace), "/workspace", True)
            wasi.stdout_file = str(output_path)
            wasi.stderr_file = str(output_path)

            store = Store(self._engine)
            store.set_wasi(wasi)
            store.set_limits(memory_size=self.memory_mb << 20)
            store.set_epoch_deadline(math.ceil(timeout / _TICK_SECONDS))
            linker = Linker(self._engine)
            linker.define_wasi()

            started = time.monotonic()
            exit_code, timed_out = 0, False
            try:
                instance = linker.instantiate(store, module)
                instance.exports(store)["_start"](store)
            except ExitTrap as exc:
                exit_code = exc.code
            except Exception as exc:  # noqa: BLE001 - traps are reported to the caller
                text = str(exc)
                timed_out = "interrupt" in text.lower()
                exit_code = 124 if timed_out else 1
                if not timed_out:
                    log.warning("wasm trap: %s", text.splitlines()[0] if text else exc)
            duration_ms = int((time.monotonic() - started) * 1000)

            output = output_path.read_text("utf-8", errors="replace") if output_path.exists() else ""
            truncated = len(output) > self.max_output_chars
            if truncated:
                output = "…(앞부분 생략)…\n" + output[-self.max_output_chars :]
            if timed_out:
                output += f"\n[시간 제한 {timeout:.0f}초 초과로 중단됨]"
            return ExecResult(output, exit_code, timed_out, truncated, duration_ms)
