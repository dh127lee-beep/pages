"""Chat transcript persistence for the web UI (one JSON file per session).

dsh keeps the agent's own history under DSH_HOME; this store only keeps what
the UI needs to redraw a conversation and who owns it.
"""

from __future__ import annotations

import json
import os
import threading
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any


@dataclass(slots=True)
class SessionRecord:
    id: str
    owner: str
    title: str = "새 대화"
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)
    # Whether dsh has persisted this session (at least one turn was sent).
    started: bool = False
    items: list[dict[str, Any]] = field(default_factory=list)

    def summary(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "title": self.title,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class SessionStore:
    def __init__(self, root: str | Path) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._cache: dict[str, SessionRecord] = {}
        for path in self.root.glob("*.json"):
            try:
                record = SessionRecord(**json.loads(path.read_text("utf-8")))
            except (ValueError, TypeError):
                continue
            self._cache[record.id] = record

    def _path(self, session_id: str) -> Path:
        if not session_id.replace("-", "").isalnum():
            raise KeyError(session_id)
        return self.root / f"{session_id}.json"

    def _save(self, record: SessionRecord) -> None:
        path = self._path(record.id)
        tmp = path.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(record.to_dict(), ensure_ascii=False), "utf-8")
        os.replace(tmp, path)

    def create(self, session_id: str, owner: str) -> SessionRecord:
        with self._lock:
            record = SessionRecord(id=session_id, owner=owner)
            self._cache[session_id] = record
            self._save(record)
            return record

    def get(self, session_id: str) -> SessionRecord | None:
        with self._lock:
            return self._cache.get(session_id)

    def list(self, owner: str | None = None) -> list[SessionRecord]:
        with self._lock:
            records = [r for r in self._cache.values() if owner is None or r.owner == owner]
        return sorted(records, key=lambda r: r.updated_at, reverse=True)

    def delete(self, session_id: str) -> None:
        with self._lock:
            self._cache.pop(session_id, None)
            self._path(session_id).unlink(missing_ok=True)

    def append(self, session_id: str, item: dict[str, Any]) -> None:
        with self._lock:
            record = self._cache[session_id]
            record.items.append({"ts": time.time(), **item})
            record.updated_at = time.time()
            self._save(record)

    def update(self, session_id: str, **fields: Any) -> SessionRecord:
        with self._lock:
            record = self._cache[session_id]
            for key, value in fields.items():
                setattr(record, key, value)
            record.updated_at = time.time()
            self._save(record)
            return record
