"""Session hub: transcripts, WebSocket fan-out and turn scheduling on per-user agent workers.

The hub owns what the API server keeps (transcripts, who owns which session,
which turns are running). Everything that touches agent code or session files
goes to the owner's agent backend through the WorkerPool.
"""

from __future__ import annotations

import asyncio
import logging
from concurrent.futures import ThreadPoolExecutor
from typing import Any, BinaryIO

from .agent import SessionBusyError
from .events import AgentEvent
from .pool import WorkerPool
from .service import FileStream
from .store import SessionStore

log = logging.getLogger(__name__)

# Streaming deltas are forwarded live but not persisted; the final blocks are.
_TRANSIENT_KINDS = {"stream_start", "text_delta", "reasoning_delta", "stream_end", "status"}


class SessionHub:
    def __init__(self, pool: WorkerPool, store: SessionStore, *, max_concurrent_turns: int = 32) -> None:
        self.pool = pool
        self.store = store
        # Blocking backend calls (a turn streams for its whole duration) run on these threads.
        self._executor = ThreadPoolExecutor(max_workers=max_concurrent_turns, thread_name_prefix="dsh-turn")
        self._subscribers: dict[str, set[asyncio.Queue[dict[str, Any]]]] = {}
        self._running: set[str] = set()
        self._tasks: set[asyncio.Task[None]] = set()

    def is_running(self, session_id: str) -> bool:
        return session_id in self._running

    # -- fan-out ---------------------------------------------------------
    def subscribe(self, session_id: str) -> asyncio.Queue[dict[str, Any]]:
        queue: asyncio.Queue[dict[str, Any]] = asyncio.Queue()
        self._subscribers.setdefault(session_id, set()).add(queue)
        return queue

    def unsubscribe(self, session_id: str, queue: asyncio.Queue[dict[str, Any]]) -> None:
        subscribers = self._subscribers.get(session_id)
        if subscribers is None:
            return
        subscribers.discard(queue)
        if not subscribers:
            del self._subscribers[session_id]

    def _publish(self, session_id: str, message: dict[str, Any]) -> None:
        for queue in self._subscribers.get(session_id, ()):
            queue.put_nowait(message)

    def _record(self, session_id: str, item: dict[str, Any]) -> None:
        """Persist and broadcast. Must be called on the event loop thread."""
        if item["type"] not in _TRANSIENT_KINDS and self.store.get(session_id) is not None:
            self.store.append(session_id, item)
        self._publish(session_id, item)

    def _owner(self, session_id: str) -> str:
        record = self.store.get(session_id)
        if record is None:
            raise KeyError(session_id)
        return record.owner

    async def _call(self, fn: Any, *args: Any) -> Any:
        return await asyncio.get_running_loop().run_in_executor(self._executor, fn, *args)

    # -- files -----------------------------------------------------------
    async def save_file(self, session_id: str, filename: str, source: BinaryIO, mime: str | None) -> dict[str, Any]:
        async with self.pool.use(self._owner(session_id)) as backend:
            return await self._call(backend.save_file, session_id, filename, source, mime)

    async def open_file(self, session_id: str, rel_path: str) -> FileStream:
        async with self.pool.use(self._owner(session_id)) as backend:
            return await self._call(backend.open_file, session_id, rel_path)

    # -- turns -----------------------------------------------------------
    async def start_turn(self, session_id: str, text: str, attachments: list[dict[str, Any]] | None = None) -> None:
        """Start a turn in the background. Raises SessionBusyError if one is running."""
        record = self.store.get(session_id)
        if record is None:
            raise KeyError(session_id)
        if session_id in self._running:
            raise SessionBusyError(session_id)
        self._running.add(session_id)
        try:
            checked: list[dict[str, Any]] = []
            if attachments:
                async with self.pool.use(record.owner) as backend:
                    checked = await self._call(backend.check_attachments, session_id, attachments)
        except BaseException:
            self._running.discard(session_id)
            raise

        if not record.started:
            self.store.update(session_id, title=_title_from(text or (checked[0]["name"] if checked else "")))
        user_item: dict[str, Any] = {"type": "user", "text": text}
        if checked:
            user_item["attachments"] = checked
        self._record(session_id, user_item)
        self._publish(session_id, {"type": "turn_start"})

        task = asyncio.create_task(self._run_turn(record.owner, session_id, text, checked, resume=record.started))
        self._tasks.add(task)
        task.add_done_callback(self._tasks.discard)

    async def _run_turn(
        self, owner: str, session_id: str, text: str, attachments: list[dict[str, Any]], *, resume: bool
    ) -> None:
        loop = asyncio.get_running_loop()
        received = False

        def on_event(event: AgentEvent) -> None:
            nonlocal received
            received = True
            # Only events from the root session go to the chat; sub-agent internals are summarized.
            if event.session_id != session_id and event.kind not in ("subagent_started", "subagent_finished"):
                return
            item = event.to_dict()
            item["type"] = item.pop("kind")
            item.pop("session_id", None)
            loop.call_soon_threadsafe(self._record, session_id, item)

        try:
            async with self.pool.use(owner) as backend:
                result = await loop.run_in_executor(
                    self._executor,
                    lambda: backend.run(session_id, text, attachments, resume=resume, on_event=on_event),
                )
            self._publish(session_id, {"type": "turn_done", "finish_reason": result.finish_reason})
        except Exception as exc:  # noqa: BLE001 - surface any runtime failure to the chat
            log.exception("turn failed in %s", session_id)
            self._record(session_id, {"type": "error", "text": f"{type(exc).__name__}: {exc}"})
            self._publish(session_id, {"type": "turn_done", "finish_reason": "error"})
        finally:
            # Once dsh has emitted anything it has persisted the session, so later turns must resume it.
            if received and not resume and self.store.get(session_id) is not None:
                self.store.update(session_id, started=True)
            self._running.discard(session_id)

    async def delete(self, session_id: str) -> None:
        if session_id in self._running:
            raise SessionBusyError(session_id)
        async with self.pool.use(self._owner(session_id)) as backend:
            await self._call(backend.delete_session, session_id)
        self.store.delete(session_id)
        self._publish(session_id, {"type": "deleted"})

    async def shutdown(self) -> None:
        for task in list(self._tasks):
            task.cancel()
        await self.pool.close()
        self._executor.shutdown(wait=False, cancel_futures=True)


def _title_from(text: str) -> str:
    line = text.strip().splitlines()[0] if text.strip() else "새 대화"
    return line[:40] + ("…" if len(line) > 40 else "")
