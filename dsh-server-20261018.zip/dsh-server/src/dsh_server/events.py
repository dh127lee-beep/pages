"""Translate raw dsh SDK notifications into a small set of typed agent events."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Literal

from deepseek_harness import Notification

EventKind = Literal[
    # live stream from the stream-bridge plugin (one model attempt)
    "stream_start",
    "reasoning_delta",
    "text_delta",
    "stream_end",
    "reasoning",
    "text",
    "tool_call",
    "tool_result",
    "turn_end",
    "status",
    "subagent_started",
    "subagent_finished",
    "error",
]


@dataclass(slots=True)
class AgentEvent:
    kind: EventKind
    session_id: str
    text: str = ""
    # tool_call / tool_result
    tool_name: str | None = None
    tool_call_id: str | None = None
    arguments: Any = None
    is_error: bool = False
    # turn_end reason kind, session status, or subagent status
    status: str | None = None
    # position of an assistant block: (turn, step, block index)
    turn: int | None = None
    step: int | None = None
    index: int | None = None
    # model attempt a live delta belongs to; retries start a new attempt
    attempt_id: str | None = None
    raw: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        out = {k: getattr(self, k) for k in self.__slots__ if k != "raw"}  # type: ignore[attr-defined]
        return {k: v for k, v in out.items() if v is not None and v != "" and v is not False}


def parse_notification(notification: Notification) -> list[AgentEvent]:
    """Return zero or more AgentEvents for one SDK notification."""
    method = notification.method
    payload = notification.payload

    if method == "session.status":
        return [AgentEvent("status", payload.get("sessionId", ""), status=payload.get("status"), raw=payload)]
    if method == "subagent.started":
        return [AgentEvent("subagent_started", payload.get("childSessionId", ""), raw=payload)]
    if method == "subagent.finished":
        text = _text_of(payload.get("lastAssistantMessage") or [])
        return [
            AgentEvent(
                "subagent_finished",
                payload.get("childSessionId", ""),
                text=text,
                status=payload.get("status"),
                is_error=payload.get("status") == "error",
                raw=payload,
            )
        ]
    if method == "session.delta":
        return _parse_delta(payload)
    if method != "session.event":
        return []

    session_id = payload.get("sessionId", "")
    event = payload.get("event")
    if not isinstance(event, dict):
        return []
    data = event.get("data") if isinstance(event.get("data"), dict) else {}
    etype = event.get("type")

    turn, step = data.get("turn"), data.get("step")

    if etype == "assistant/message":
        message = data.get("message") if isinstance(data.get("message"), dict) else data
        events: list[AgentEvent] = []
        for index, block in enumerate(message.get("content") or []):
            if not isinstance(block, dict):
                continue
            btype = block.get("type")
            pos = {"turn": turn, "step": step, "index": index, "raw": event}
            if btype == "reasoning":
                events.append(AgentEvent("reasoning", session_id, text=str(block.get("text") or ""), **pos))
            elif btype == "text":
                events.append(AgentEvent("text", session_id, text=str(block.get("text") or ""), **pos))
            elif btype == "tool-call":
                events.append(
                    AgentEvent(
                        "tool_call",
                        session_id,
                        tool_name=block.get("name"),
                        tool_call_id=block.get("id"),
                        arguments=_maybe_json(block.get("arguments")),
                        **pos,
                    )
                )
        return events

    if etype == "tool/result":
        message = data.get("message") if isinstance(data.get("message"), dict) else {}
        return [
            AgentEvent(
                "tool_result",
                session_id,
                text=_text_of(message.get("content") or []),
                tool_call_id=message.get("toolCallId"),
                is_error=bool(message.get("isError")),
                raw=event,
            )
        ]

    if etype == "turn/end":
        reason = data.get("reason") if isinstance(data.get("reason"), dict) else {}
        return [AgentEvent("turn_end", session_id, status=reason.get("kind"), turn=turn, raw=event)]

    if etype == "agent/error":
        return [AgentEvent("error", session_id, text=json.dumps(data, ensure_ascii=False), is_error=True, raw=event)]

    return []


def _parse_delta(payload: dict[str, Any]) -> list[AgentEvent]:
    session_id = payload.get("sessionId", "")
    attempt_id = payload.get("attemptId")
    dtype = payload.get("type")
    if dtype == "start":
        return [AgentEvent("stream_start", session_id, attempt_id=attempt_id, turn=payload.get("turn"), step=payload.get("step"))]
    if dtype == "end":
        return [AgentEvent("stream_end", session_id, attempt_id=attempt_id, status="committed" if payload.get("committed") else "abandoned")]
    if dtype in ("text", "reasoning"):
        kind: EventKind = "text_delta" if dtype == "text" else "reasoning_delta"
        return [AgentEvent(kind, session_id, text=str(payload.get("text") or ""), attempt_id=attempt_id, index=payload.get("index"))]
    return []


def _text_of(content: list[Any]) -> str:
    return "".join(str(b.get("text") or "") for b in content if isinstance(b, dict) and b.get("type") == "text")


def _maybe_json(value: Any) -> Any:
    if isinstance(value, str):
        try:
            return json.loads(value)
        except ValueError:
            return value
    return value
