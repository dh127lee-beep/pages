"""Client for an agent worker (worker.py); implements the AgentBackend protocol."""

from __future__ import annotations

import dataclasses
import json
import time
from collections.abc import Callable, Iterator
from typing import Any, BinaryIO

import httpx

from .agent import AgentResult, SessionBusyError
from .events import AgentEvent
from .service import FileStream

_EVENT_FIELDS = {f.name for f in dataclasses.fields(AgentEvent)}


def event_from_dict(data: dict[str, Any]) -> AgentEvent:
    fields = {k: v for k, v in data.items() if k in _EVENT_FIELDS and k not in ("kind", "session_id")}
    return AgentEvent(data["kind"], data.get("session_id", ""), **fields)


class RemoteAgentService:
    def __init__(self, base_url: str, token: str, *, connect_timeout: float = 10.0) -> None:
        self.base_url = base_url.rstrip("/")
        self._client = httpx.Client(
            base_url=self.base_url,
            headers={"Authorization": f"Bearer {token}"},
            # Turns stream for as long as the agent works, so reads have no timeout.
            timeout=httpx.Timeout(connect=connect_timeout, read=None, write=60.0, pool=30.0),
        )
        self._info: dict[str, Any] = {}

    def info(self) -> dict[str, Any]:
        return self._info

    def start(self, wait_seconds: float = 60.0) -> None:
        deadline = time.monotonic() + wait_seconds
        while True:
            try:
                response = self._client.get("/health", timeout=5.0)
                response.raise_for_status()
                self._info = {k: v for k, v in response.json().items() if k != "ok"}
                return
            except (httpx.TransportError, httpx.HTTPStatusError):
                if time.monotonic() > deadline:
                    raise
                time.sleep(0.5)

    def close(self) -> None:
        self._client.close()

    def is_busy(self, session_id: str) -> bool:
        # The API server tracks running turns itself; the worker rejects overlaps with "busy".
        return False

    def run(
        self,
        session_id: str,
        text: str,
        attachments: list[dict[str, Any]],
        *,
        resume: bool,
        on_event: Callable[[AgentEvent], None] | None = None,
    ) -> AgentResult:
        body = {"text": text, "attachments": attachments, "resume": resume}
        events: list[AgentEvent] = []
        with self._client.stream("POST", f"/sessions/{session_id}/turns", json=body) as response:
            if response.status_code == 409:
                raise SessionBusyError(session_id)
            response.raise_for_status()
            for line in response.iter_lines():
                if not line:
                    continue
                item = json.loads(line)
                if "event" in item:
                    event = event_from_dict(item["event"])
                    events.append(event)
                    if on_event is not None:
                        on_event(event)
                elif "result" in item:
                    result = item["result"]
                    return AgentResult(result["session_id"], result["text"], result["finish_reason"], events)
                elif "error" in item:
                    if item.get("code") == "busy":
                        raise SessionBusyError(session_id)
                    if item.get("code") == "not_found":
                        raise FileNotFoundError(item["error"])
                    raise RuntimeError(item["error"])
        raise RuntimeError("agent worker closed the stream without a result")

    def check_attachments(self, session_id: str, attachments: list[dict[str, Any]]) -> list[dict[str, Any]]:
        response = self._client.post(f"/sessions/{session_id}/attachments/check", json={"attachments": attachments})
        if response.status_code == 404:
            raise FileNotFoundError(response.json().get("detail", "attachment not found"))
        response.raise_for_status()
        return response.json()

    def save_file(self, session_id: str, filename: str, source: BinaryIO, mime: str | None) -> dict[str, Any]:
        files = {"files": (filename, source, mime or "application/octet-stream")}
        response = self._client.post(f"/sessions/{session_id}/files", files=files)
        if response.status_code == 413:
            raise ValueError(response.json().get("detail", "file too large"))
        response.raise_for_status()
        return response.json()[0]

    def open_file(self, session_id: str, rel_path: str) -> FileStream:
        request = self._client.build_request("GET", f"/sessions/{session_id}/files/{rel_path}")
        response = self._client.send(request, stream=True)
        if response.status_code == 404:
            response.close()
            raise FileNotFoundError(rel_path)
        response.raise_for_status()
        name = bytes.fromhex(response.headers.get("X-File-Name", "")).decode() or rel_path.rsplit("/", 1)[-1]

        def chunks() -> Iterator[bytes]:
            try:
                yield from response.iter_bytes()
            finally:
                response.close()

        return FileStream(
            name, response.headers.get("Content-Type", "application/octet-stream"), int(response.headers.get("Content-Length", 0)), chunks()
        )

    def delete_session(self, session_id: str) -> None:
        response = self._client.delete(f"/sessions/{session_id}")
        if response.status_code == 409:
            raise SessionBusyError(session_id)
        response.raise_for_status()
