"""Agent backend: one dsh runtime, its WASM code sandbox and per-session workspace folders.

``AgentService`` runs locally. The agent worker (worker.py) serves it over HTTP
and ``RemoteAgentService`` (remote.py) is the matching client, so the API
server can use either through the ``AgentBackend`` protocol.
"""

from __future__ import annotations

import base64
import logging
import mimetypes
import re
import shutil
import threading
from collections.abc import Callable, Iterator
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Any, BinaryIO, Protocol

from .agent import AgentResult, DshAgent, SessionBusyError
from .config import DshSettings
from .events import AgentEvent
from .sidecar import SearchFn, dummy_search
from .wasm_exec import WasmSandbox

log = logging.getLogger(__name__)

UPLOADS_DIR = "uploads"
MAX_ATTACHMENT_BYTES = 50 << 20
MAX_INLINE_IMAGE_BYTES = 5 << 20
VISION_MIME_TYPES = {"image/png", "image/jpeg", "image/webp", "image/gif"}
_SESSION_ID_RE = re.compile(r"^[A-Za-z0-9_-]{1,80}$")


@dataclass(slots=True)
class FileStream:
    name: str
    mime: str
    size: int
    chunks: Iterator[bytes]


class AgentBackend(Protocol):
    """What the API server needs from an agent backend, local or remote."""

    def info(self) -> dict[str, Any]: ...
    def start(self) -> None: ...
    def close(self) -> None: ...
    def is_busy(self, session_id: str) -> bool: ...
    def run(
        self,
        session_id: str,
        text: str,
        attachments: list[dict[str, Any]],
        *,
        resume: bool,
        on_event: Callable[[AgentEvent], None] | None = None,
    ) -> AgentResult: ...
    def check_attachments(self, session_id: str, attachments: list[dict[str, Any]]) -> list[dict[str, Any]]: ...
    def save_file(self, session_id: str, filename: str, source: BinaryIO, mime: str | None) -> dict[str, Any]: ...
    def open_file(self, session_id: str, rel_path: str) -> FileStream: ...
    def delete_session(self, session_id: str) -> None: ...


def check_session_id(session_id: str) -> str:
    if not _SESSION_ID_RE.match(session_id):
        raise ValueError(f"invalid session id: {session_id!r}")
    return session_id


class AgentService:
    """Local agent backend.

    The dsh runtime's own cwd is the workspaces root, so the OS sandbox (when
    one is available) can never write outside it; each session works in
    ``<workspaces_root>/<session_id>``, which the workspace guard and the WASM
    sandbox enforce for every tool call.
    """

    def __init__(self, settings: DshSettings, workspaces_root: Path, *, search: SearchFn = dummy_search) -> None:
        self.workspaces_root = workspaces_root.resolve()
        self.workspaces_root.mkdir(parents=True, exist_ok=True)
        self.settings = replace(settings, workspace=str(self.workspaces_root), workspaces_root=str(self.workspaces_root))
        self._wasm: WasmSandbox | None = None
        self._wasm_lock = threading.Lock()
        exec_fn = self._exec if self.settings.code_exec == "wasm" else None
        self.agent = DshAgent(self.settings, search=search, exec_fn=exec_fn)

    # -- lifecycle -------------------------------------------------------
    def info(self) -> dict[str, Any]:
        s = self.settings
        return {"model": s.model, "profile": s.profile, "vision": s.vision, "code_exec": s.code_exec}

    def start(self) -> None:
        if self.settings.code_exec == "wasm":
            self._sandbox()
        self.agent.start()

    def close(self) -> None:
        self.agent.close()
        if self._wasm is not None:
            self._wasm.close()

    # -- code sandbox ----------------------------------------------------
    def _sandbox(self) -> WasmSandbox:
        with self._wasm_lock:
            if self._wasm is None:
                self._wasm = WasmSandbox(Path(self.settings.wasm_dir))
            return self._wasm

    def _exec(self, request: dict[str, Any]) -> dict[str, Any]:
        """Sidecar /exec handler for the python/javascript tools."""
        workspace = self.workspace_for(str(request["sessionId"]))
        timeout = request.get("timeoutSeconds")
        result = self._sandbox().run(
            str(request.get("language") or "python"),
            str(request["code"]),
            workspace,
            float(timeout) if isinstance(timeout, (int, float)) else None,
        )
        return result.to_dict()

    # -- turns -----------------------------------------------------------
    def is_busy(self, session_id: str) -> bool:
        return self.agent.is_busy(session_id)

    def run(
        self,
        session_id: str,
        text: str,
        attachments: list[dict[str, Any]],
        *,
        resume: bool,
        on_event: Callable[[AgentEvent], None] | None = None,
    ) -> AgentResult:
        workspace = self.workspace_for(session_id)
        workspace.mkdir(parents=True, exist_ok=True)
        prompt = self._build_prompt(session_id, text, self.check_attachments(session_id, attachments))
        return self.agent.run(prompt, session_id=session_id, on_event=on_event, resume=resume, workdir=str(workspace))

    def _build_prompt(self, session_id: str, text: str, attachments: list[dict[str, Any]]) -> str | list[dict[str, Any]]:
        """The message plus a note listing attached files (and image blocks when vision is on)."""
        if not attachments:
            return text
        lines = [text or "첨부한 파일을 확인해 주세요.", "", "[첨부파일] 아래 파일이 작업 폴더에 저장되어 있습니다. 필요하면 도구로 열어 사용하세요."]
        lines += [f"- {a['path']} ({a['mime']}, {_human_size(a['size'])})" for a in attachments]
        blocks: list[dict[str, Any]] = [{"type": "text", "text": "\n".join(lines)}]
        if self.settings.vision:
            for a in attachments:
                if a["mime"] in VISION_MIME_TYPES and a["size"] <= MAX_INLINE_IMAGE_BYTES:
                    data = self.resolve_file(session_id, a["path"]).read_bytes()
                    blocks.append({"type": "image", "data": base64.b64encode(data).decode(), "mimeType": a["mime"]})
        return blocks if len(blocks) > 1 else blocks[0]["text"]

    # -- files -----------------------------------------------------------
    def workspace_for(self, session_id: str) -> Path:
        return self.workspaces_root / check_session_id(session_id)

    def resolve_file(self, session_id: str, rel_path: str) -> Path:
        """A file inside the session workspace; FileNotFoundError when outside or missing."""
        workspace = self.workspace_for(session_id).resolve()
        target = (workspace / rel_path).resolve()
        if not target.is_relative_to(workspace) or not target.is_file():
            raise FileNotFoundError(rel_path)
        return target

    def check_attachments(self, session_id: str, attachments: list[dict[str, Any]]) -> list[dict[str, Any]]:
        checked = []
        workspace = self.workspace_for(session_id).resolve()
        for attachment in attachments:
            path = self.resolve_file(session_id, str(attachment.get("path") or ""))
            checked.append(
                {
                    "name": path.name,
                    "path": path.relative_to(workspace).as_posix(),
                    "size": path.stat().st_size,
                    "mime": attachment.get("mime") or mimetypes.guess_type(path.name)[0] or "application/octet-stream",
                }
            )
        return checked

    def save_file(self, session_id: str, filename: str, source: BinaryIO, mime: str | None) -> dict[str, Any]:
        """Store an upload under the session workspace's uploads/ folder."""
        workspace = self.workspace_for(session_id)
        uploads = workspace / UPLOADS_DIR
        uploads.mkdir(parents=True, exist_ok=True)
        target = _unique_path(uploads / _safe_filename(filename))
        size = 0
        with target.open("wb") as out:
            while chunk := source.read(1 << 20):
                size += len(chunk)
                if size > MAX_ATTACHMENT_BYTES:
                    out.close()
                    target.unlink(missing_ok=True)
                    raise ValueError(f"file exceeds {MAX_ATTACHMENT_BYTES >> 20} MB")
                out.write(chunk)
        mime = mime or mimetypes.guess_type(target.name)[0] or "application/octet-stream"
        return {"name": target.name, "path": target.relative_to(workspace).as_posix(), "size": size, "mime": mime}

    def open_file(self, session_id: str, rel_path: str) -> FileStream:
        path = self.resolve_file(session_id, rel_path)

        def chunks() -> Iterator[bytes]:
            with path.open("rb") as f:
                while chunk := f.read(1 << 16):
                    yield chunk

        mime = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
        return FileStream(path.name, mime, path.stat().st_size, chunks())

    def delete_session(self, session_id: str) -> None:
        if self.is_busy(session_id):
            raise SessionBusyError(session_id)
        self.agent.forget_session(session_id)
        shutil.rmtree(self.workspace_for(session_id), ignore_errors=True)


def _safe_filename(name: str) -> str:
    name = Path(name.replace("\\", "/")).name.strip()
    name = re.sub(r'[\x00-\x1f/:*?"<>|]', "_", name).lstrip(".")
    return name[:120] or "file"


def _unique_path(path: Path) -> Path:
    if not path.exists():
        return path
    for i in range(1, 10_000):
        candidate = path.with_name(f"{path.stem}-{i}{path.suffix}")
        if not candidate.exists():
            return candidate
    raise FileExistsError(path)


def _human_size(size: int) -> str:
    if size < 1024:
        return f"{size} B"
    if size < 1 << 20:
        return f"{size / 1024:.1f} KB"
    return f"{size / (1 << 20):.1f} MB"
