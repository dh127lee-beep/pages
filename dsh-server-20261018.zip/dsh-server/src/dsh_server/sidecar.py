"""In-process HTTP sidecar that the dsh runtime talks to.

- ``/v1/*``: OpenAI-compatible proxy to the upstream LLM. Some gateways
  sometimes return a tool call as plain text (``<invoke name="...">`` markup)
  instead of ``tool_calls``. The proxy rewrites that text into real tool calls,
  in both streaming and non-streaming responses, so dsh can run the tool.
- ``/exec``: runs the ``python`` tool in the WASM sandbox (see wasm_exec.py).
- ``/search``: backend for the dsh ``web_search`` tool (see the web-search
  plugin). Returns dummy results unless a real search function is plugged in.
"""

from __future__ import annotations

import json
import logging
import re
import threading
import urllib.error
import urllib.parse
import urllib.request
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any, Callable, Iterator

log = logging.getLogger(__name__)

SearchFn = Callable[[str, int], dict[str, Any]]
# Handles a python-tool request {"sessionId", "code", "timeoutSeconds"} and returns ExecResult.to_dict().
ExecFn = Callable[[dict[str, Any]], dict[str, Any]]

_TAGS = ("<function_calls", "<invoke")
_NAME = r"""name\s*=\s*["']?([^"'>\s]+)["']?"""
_INVOKE_RE = re.compile(r"<(?:antml:)?invoke\s+" + _NAME + r"\s*>(.*?)(?:</(?:antml:)?invoke>|$)", re.S)
_PARAM_RE = re.compile(r"<(?:antml:)?parameter\s+" + _NAME + r"\s*>(.*?)(?:</(?:antml:)?parameter>|$)", re.S)


def dummy_search(query: str, max_results: int) -> dict[str, Any]:
    """Placeholder search backend: deterministic fake sources for ``query``."""
    slug = urllib.parse.quote(query)
    sources = [
        {
            "url": f"https://example.com/search/{slug}/{i}",
            "title": f"[더미] {query} - 결과 {i}",
            "snippet": f"'{query}'에 대한 더미 검색 결과 {i}입니다. 실제 검색 백엔드를 연결하면 실제 내용이 표시됩니다.",
        }
        for i in range(1, min(max_results, 5) + 1)
    ]
    return {"content": f"(더미 검색) '{query}'에 대한 실제 데이터는 없습니다.", "sources": sources}


class ToolCallRepair:
    """Turns ``<invoke>`` markup in assistant text into OpenAI ``tool_calls``."""

    def __init__(self, tools: list[dict[str, Any]] | None) -> None:
        self.schemas: dict[str, dict[str, Any]] = {}
        for tool in tools or []:
            fn = tool.get("function") or {}
            if fn.get("name"):
                self.schemas[fn["name"]] = fn.get("parameters") or {}
        self._held = ""
        self._captured: str | None = None
        self._next_index = 0
        self.repaired = 0

    @property
    def enabled(self) -> bool:
        return bool(self.schemas)

    # -- streaming -------------------------------------------------------
    def feed(self, text: str) -> str:
        """Accept a content delta; return the part that is safe to emit now."""
        if self._captured is not None:
            self._captured += text
            return ""
        buf = self._held + text
        starts = [i for i in (buf.find(tag) for tag in _TAGS) if i >= 0]
        if starts:
            cut = min(starts)
            self._captured, self._held = buf[cut:], ""
            return buf[:cut]
        hold = _partial_tag_suffix(buf)
        self._held = buf[len(buf) - hold :] if hold else ""
        return buf[: len(buf) - hold]

    def note_upstream_tool_calls(self, tool_calls: list[dict[str, Any]]) -> None:
        for call in tool_calls:
            index = call.get("index")
            if isinstance(index, int):
                self._next_index = max(self._next_index, index + 1)

    def finish(self) -> tuple[str, list[dict[str, Any]]]:
        """End of the message: leftover text and synthesized tool calls."""
        text, self._held = self._held, ""
        captured, self._captured = self._captured, None
        if captured is None:
            return text, []
        calls = self.parse(captured)
        if not calls:
            return text + captured, []
        for call in calls:
            call["index"] = self._next_index
            self._next_index += 1
        return text, calls

    # -- parsing ---------------------------------------------------------
    def parse(self, markup: str) -> list[dict[str, Any]]:
        calls = []
        for name, body in _INVOKE_RE.findall(markup):
            name = self._resolve_name(name)
            schema = (self.schemas.get(name) or {}).get("properties") or {}
            args = {key: self._coerce(value, schema.get(key) or {}) for key, value in _PARAM_RE.findall(body)}
            if not args and body.strip():
                # Some replies put a JSON object inside <invoke> instead of <parameter> tags.
                try:
                    parsed = json.loads(body.strip())
                    args = parsed if isinstance(parsed, dict) else {}
                except ValueError:
                    pass
            if not args:
                log.warning("tool call %s has no parsable arguments: %r", name, markup[:500])
            calls.append(
                {
                    "id": f"call_{uuid.uuid4().hex[:24]}",
                    "type": "function",
                    "function": {"name": name, "arguments": json.dumps(args, ensure_ascii=False)},
                }
            )
        self.repaired += len(calls)
        return calls

    def _resolve_name(self, name: str) -> str:
        if name in self.schemas:
            return name
        lowered = {n.lower(): n for n in self.schemas}
        return lowered.get(name.lower(), name)

    @staticmethod
    def _coerce(raw: str, schema: dict[str, Any]) -> Any:
        value = raw.strip("\n")
        if schema.get("type") == "string":
            return value
        try:
            return json.loads(value)
        except ValueError:
            return value


def _partial_tag_suffix(text: str) -> int:
    """Length of the longest suffix of ``text`` that could start one of the tags."""
    best = 0
    for tag in _TAGS:
        for k in range(min(len(tag) - 1, len(text)), best, -1):
            if tag.startswith(text[-k:]):
                best = k
                break
    return best


class _Handler(BaseHTTPRequestHandler):
    server: "_Server"

    def log_message(self, fmt: str, *args: Any) -> None:
        log.debug("sidecar: " + fmt, *args)

    def _read_body(self) -> bytes:
        return self.rfile.read(int(self.headers.get("Content-Length") or 0))

    def _send_json(self, status: int, payload: Any) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self) -> None:
        if self.path.startswith("/v1/"):
            self._proxy(None)
        else:
            self._send_json(404, {"error": "not found"})

    def do_POST(self) -> None:
        if self.path == "/search":
            request = json.loads(self._read_body() or b"{}")
            query = str(request.get("query") or "")
            max_results = int(request.get("maxResults") or 5)
            try:
                self._send_json(200, self.server.search(query, max_results))
            except Exception as exc:  # noqa: BLE001 - report backend failures to the tool
                log.exception("search failed")
                self._send_json(502, {"error": str(exc)})
        elif self.path == "/exec" and self.server.exec_fn is not None:
            try:
                request = json.loads(self._read_body() or b"{}")
                self._send_json(200, self.server.exec_fn(request))
            except (ValueError, KeyError) as exc:
                self._send_json(400, {"error": str(exc)})
            except Exception as exc:  # noqa: BLE001 - report sandbox failures to the tool
                log.exception("exec failed")
                self._send_json(500, {"error": str(exc)})
        elif self.path.startswith("/v1/"):
            self._proxy(self._read_body())
        else:
            self._send_json(404, {"error": "not found"})

    def _proxy(self, body: bytes | None) -> None:
        payload: dict[str, Any] = {}
        if body:
            try:
                payload = json.loads(body)
            except ValueError:
                payload = {}
        url = self.server.upstream + self.path[len("/v1") :]
        request = urllib.request.Request(url, data=body, method=self.command)
        for header in ("Content-Type", "Authorization", "Accept"):
            if self.headers.get(header):
                request.add_header(header, self.headers[header])
        if self.server.upstream_api_key is not None:
            # The runtime only holds a placeholder key; the real one is added here.
            request.add_header("Authorization", f"Bearer {self.server.upstream_api_key}")
        try:
            upstream = urllib.request.urlopen(request, timeout=600)
        except urllib.error.HTTPError as err:
            data = err.read()
            self.send_response(err.code)
            self.send_header("Content-Type", err.headers.get("Content-Type", "application/json"))
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return
        except OSError as exc:
            self._send_json(502, {"error": {"message": f"upstream unreachable: {exc}"}})
            return

        repair = ToolCallRepair(payload.get("tools"))
        with upstream:
            if payload.get("stream") and repair.enabled:
                self._relay_stream(upstream, repair)
            elif repair.enabled and "json" in upstream.headers.get("Content-Type", ""):
                self._relay_json(upstream, repair)
            else:
                self._relay_raw(upstream)
        if repair.repaired:
            log.info("repaired %d text tool call(s)", repair.repaired)

    def _relay_raw(self, upstream: Any) -> None:
        self.send_response(upstream.status)
        self.send_header("Content-Type", upstream.headers.get("Content-Type", "application/octet-stream"))
        self.end_headers()
        while chunk := upstream.read(65536):
            self.wfile.write(chunk)

    def _relay_json(self, upstream: Any, repair: ToolCallRepair) -> None:
        response = json.loads(upstream.read())
        for choice in response.get("choices") or []:
            message = choice.get("message") or {}
            content = message.get("content")
            if not isinstance(content, str):
                continue
            text = repair.feed(content)
            rest, calls = repair.finish()
            if calls:
                message["content"] = (text + rest) or None
                for call in calls:
                    call.pop("index", None)
                message["tool_calls"] = (message.get("tool_calls") or []) + calls
                choice["finish_reason"] = "tool_calls"
        self._send_json(upstream.status, response)

    def _relay_stream(self, upstream: Any, repair: ToolCallRepair) -> None:
        self.send_response(upstream.status)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()

        def emit(event: dict[str, Any] | str) -> None:
            data = event if isinstance(event, str) else json.dumps(event, ensure_ascii=False)
            self.wfile.write(f"data: {data}\n\n".encode())
            self.wfile.flush()

        for data in _sse_data(upstream):
            if data == "[DONE]":
                emit(data)
                continue
            try:
                event = json.loads(data)
            except ValueError:
                emit(data)
                continue
            choices = event.get("choices") or []
            if not choices:
                emit(event)
                continue
            choice = choices[0]
            delta = choice.get("delta") or {}
            if delta.get("tool_calls"):
                repair.note_upstream_tool_calls(delta["tool_calls"])
            if isinstance(delta.get("content"), str) and delta["content"]:
                delta["content"] = repair.feed(delta["content"])
            finish = choice.get("finish_reason")
            if finish is not None:
                text, calls = repair.finish()
                if text or calls:
                    extra: dict[str, Any] = {}
                    if text:
                        extra["content"] = text
                    if calls:
                        extra["tool_calls"] = calls
                    emit({**event, "choices": [{"index": choice.get("index", 0), "delta": extra, "finish_reason": None}]})
                if calls:
                    choice["finish_reason"] = "tool_calls"
                    delta.pop("content", None)
            if delta.get("content") == "" and set(delta) == {"content"} and finish is None:
                continue
            emit(event)


def _sse_data(stream: Any) -> Iterator[str]:
    lines: list[str] = []
    for raw in stream:
        line = raw.decode("utf-8").rstrip("\r\n")
        if line == "":
            if lines:
                yield "\n".join(lines)
                lines = []
            continue
        if line.startswith("data:"):
            lines.append(line[5:].lstrip())
    if lines:
        yield "\n".join(lines)


class _Server(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, upstream: str, search: SearchFn, exec_fn: ExecFn | None, upstream_api_key: str | None) -> None:
        super().__init__(("127.0.0.1", 0), _Handler)
        self.upstream = upstream.rstrip("/")
        self.search = search
        self.exec_fn = exec_fn
        self.upstream_api_key = upstream_api_key


class Sidecar:
    def __init__(
        self,
        upstream: str,
        search: SearchFn = dummy_search,
        *,
        exec_fn: ExecFn | None = None,
        upstream_api_key: str | None = None,
    ) -> None:
        self._server = _Server(upstream, search, exec_fn, upstream_api_key)
        self._thread = threading.Thread(target=self._server.serve_forever, name="dsh-sidecar", daemon=True)

    @property
    def url(self) -> str:
        host, port = self._server.server_address[:2]
        return f"http://{host}:{port}"

    def start(self) -> "Sidecar":
        self._thread.start()
        return self

    def close(self) -> None:
        self._server.shutdown()
        self._server.server_close()
