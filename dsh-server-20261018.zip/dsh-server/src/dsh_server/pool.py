"""Per-user agent workers.

The API server never runs agent code itself. ``WorkerPool`` gives every user
(owner) their own agent backend, started on first use and stopped after
``idle_timeout`` with no running turn. How a worker is started is up to the
provisioner:

- ``InProcessProvisioner``: one AgentService inside the API server, shared by
  all users (development only; no isolation between users).
- ``RemoteProvisioner``: one pre-started worker at a fixed URL, shared.
- ``LocalProcessProvisioner``: one worker *process* per user on this host, with
  its own data folder and a scrubbed environment.
- ``DockerProvisioner``: one worker *container* per user (production design;
  see doc/04-worker-architecture.md).
"""

from __future__ import annotations

import asyncio
import hashlib
import logging
import os
import secrets
import socket
import subprocess
import sys
import time
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Protocol

from .remote import RemoteAgentService
from .service import AgentBackend

log = logging.getLogger(__name__)

# Environment passed from the API server to a worker: everything the agent
# needs, nothing that belongs to the API server (its token, data paths, ...).
_WORKER_ENV_KEYS = {"PATH", "LANG", "LC_ALL", "TZ", "TMPDIR", "SSL_CERT_FILE", "SSL_CERT_DIR",
                    "HTTP_PROXY", "HTTPS_PROXY", "NO_PROXY", "http_proxy", "https_proxy", "no_proxy"}
_WORKER_ENV_PREFIXES = ("DSH_", "DEEPSEEK_")
_SERVER_ONLY_ENV = {"DSH_SERVER_TOKEN", "DSH_SERVER_DATA", "DSH_SERVER_HOST", "DSH_SERVER_PORT", "DSH_CORS_ORIGINS",
                    "DSH_HOME", "DSH_WORKSPACE", "DSH_WORKSPACES_ROOT", "DSH_WORKER_MODE", "DSH_WORKER_URL",
                    "DSH_WORKER_TOKEN", "DSH_WORKER_IMAGE", "DSH_WORKER_IDLE_SECONDS", "DSH_SESSION_WORKSPACES"}


def worker_env(extra: dict[str, str]) -> dict[str, str]:
    env = {
        k: v
        for k, v in os.environ.items()
        if (k in _WORKER_ENV_KEYS or k.startswith(_WORKER_ENV_PREFIXES)) and k not in _SERVER_ONLY_ENV
    }
    env.update(extra)
    return env


def owner_key(owner: str) -> str:
    """Stable, filesystem/container-safe id for an owner."""
    return hashlib.sha256(owner.encode()).hexdigest()[:20]


class WorkerHandle(Protocol):
    backend: AgentBackend

    def stop(self) -> None: ...


class Provisioner(Protocol):
    shared: bool  # True: one backend for every owner (never reaped)

    def launch(self, owner: str) -> WorkerHandle: ...


@dataclass
class _SimpleHandle:
    backend: AgentBackend
    on_stop: Callable[[], None] | None = None

    def stop(self) -> None:
        self.backend.close()
        if self.on_stop is not None:
            self.on_stop()


class InProcessProvisioner:
    shared = True

    def __init__(self, data_dir: Path) -> None:
        self.data_dir = data_dir

    def launch(self, owner: str) -> WorkerHandle:
        from .config import DshSettings
        from .service import AgentService

        settings = DshSettings.from_env(dsh_home=os.environ.get("DSH_HOME") or str(self.data_dir / "dsh-home"))
        service = AgentService(settings, self.data_dir / "workspaces")
        service.start()
        return _SimpleHandle(service)


class RemoteProvisioner:
    shared = True

    def __init__(self, url: str, token: str) -> None:
        self.url, self.token = url, token

    def launch(self, owner: str) -> WorkerHandle:
        backend = RemoteAgentService(self.url, self.token)
        backend.start()
        return _SimpleHandle(backend)


class LocalProcessProvisioner:
    """One `python -m dsh_server.worker` process per owner on this host."""

    shared = False

    def __init__(self, data_dir: Path, *, start_timeout: float = 120.0) -> None:
        self.data_dir = data_dir
        self.start_timeout = start_timeout

    def launch(self, owner: str) -> WorkerHandle:
        key = owner_key(owner)
        home = self.data_dir / "users" / key
        home.mkdir(parents=True, exist_ok=True)
        port = _free_port()
        token = secrets.token_urlsafe(32)
        env = worker_env(
            {
                "DSH_WORKER_TOKEN": token,
                "DSH_WORKER_PORT": str(port),
                "DSH_WORKER_HOST": "127.0.0.1",
                "DSH_WORKER_DATA": str(home),
                "HOME": str(home),
            }
        )
        log_file = (home / "worker.log").open("ab")
        proc = subprocess.Popen(
            [sys.executable, "-m", "dsh_server.worker"],
            cwd=home,
            env=env,
            stdout=log_file,
            stderr=subprocess.STDOUT,
            start_new_session=True,
        )
        log.info("started worker for %s (pid=%s, port=%s)", key, proc.pid, port)
        backend = RemoteAgentService(f"http://127.0.0.1:{port}", token)

        def stop_process() -> None:
            proc.terminate()
            try:
                proc.wait(timeout=15)
            except subprocess.TimeoutExpired:
                proc.kill()
            log_file.close()
            log.info("stopped worker for %s", key)

        try:
            backend.start(wait_seconds=self.start_timeout)
        except Exception:
            backend.close()
            stop_process()
            raise
        return _SimpleHandle(backend, stop_process)


class DockerProvisioner:
    """One worker container per owner (docker CLI). See doc/04-worker-architecture.md.

    The API server and workers share a user-defined docker network; each worker
    keeps its data in a named volume, runs as a non-root user with a read-only
    root filesystem, no capabilities and CPU/memory/pid limits.
    """

    shared = False

    def __init__(self, image: str, network: str, *, port: int = 8100, start_timeout: float = 120.0,
                 memory: str = "2g", cpus: str = "1.0", pids: int = 256) -> None:
        self.image, self.network, self.port = image, network, port
        self.start_timeout, self.memory, self.cpus, self.pids = start_timeout, memory, cpus, pids

    def launch(self, owner: str) -> WorkerHandle:
        key = owner_key(owner)
        name = f"dsh-worker-{key}"
        token = secrets.token_urlsafe(32)
        env = worker_env({"DSH_WORKER_TOKEN": token, "DSH_WORKER_PORT": str(self.port),
                          "DSH_WORKER_HOST": "0.0.0.0", "DSH_WORKER_DATA": "/data"})
        env.pop("PATH", None)  # keep the image's own PATH
        subprocess.run(["docker", "rm", "-f", name], capture_output=True)
        cmd = [
            "docker", "run", "-d", "--rm", "--name", name, "--network", self.network,
            "-v", f"dsh-user-{key}:/data",
            "--read-only", "--tmpfs", "/tmp:rw,size=256m",
            "--cap-drop", "ALL", "--security-opt", "no-new-privileges",
            "--memory", self.memory, "--cpus", self.cpus, "--pids-limit", str(self.pids),
        ]
        for k, v in env.items():
            cmd += ["-e", f"{k}={v}"]
        subprocess.run([*cmd, self.image], check=True, capture_output=True)
        backend = RemoteAgentService(f"http://{name}:{self.port}", token)

        def stop_container() -> None:
            subprocess.run(["docker", "stop", "-t", "15", name], capture_output=True)

        try:
            backend.start(wait_seconds=self.start_timeout)
        except Exception:
            backend.close()
            stop_container()
            raise
        return _SimpleHandle(backend, stop_container)


def _free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


@dataclass
class _Slot:
    lock: asyncio.Lock = field(default_factory=asyncio.Lock)
    handle: WorkerHandle | None = None
    leases: int = 0
    last_used: float = field(default_factory=time.monotonic)


class WorkerPool:
    def __init__(self, provisioner: Provisioner, *, idle_timeout: float = 900.0) -> None:
        self.provisioner = provisioner
        self.idle_timeout = idle_timeout
        self._slots: dict[str, _Slot] = {}
        self._reaper: asyncio.Task[None] | None = None

    def _slot(self, owner: str) -> _Slot:
        return self._slots.setdefault("*" if self.provisioner.shared else owner, _Slot())

    async def start(self) -> None:
        if not self.provisioner.shared:
            self._reaper = asyncio.create_task(self._reap_loop())

    @asynccontextmanager
    async def use(self, owner: str) -> AsyncIterator[AgentBackend]:
        """Lease the owner's backend (starting its worker if needed) for the block's duration."""
        slot = self._slot(owner)
        async with slot.lock:
            if slot.handle is None:
                slot.handle = await asyncio.to_thread(self.provisioner.launch, owner)
            slot.leases += 1
        try:
            yield slot.handle.backend
        finally:
            slot.leases -= 1
            slot.last_used = time.monotonic()

    def info(self) -> dict[str, Any]:
        return {
            "workers": sum(1 for s in self._slots.values() if s.handle is not None),
            "mode": "shared" if self.provisioner.shared else "per-user",
        }

    async def _reap_loop(self) -> None:
        while True:
            await asyncio.sleep(min(30.0, self.idle_timeout / 2))
            now = time.monotonic()
            for owner, slot in list(self._slots.items()):
                if slot.handle is None or slot.leases > 0 or now - slot.last_used < self.idle_timeout:
                    continue
                async with slot.lock:
                    if slot.handle is None or slot.leases > 0:
                        continue
                    handle, slot.handle = slot.handle, None
                log.info("stopping idle worker for %s", owner_key(owner))
                await asyncio.to_thread(handle.stop)

    async def close(self) -> None:
        if self._reaper is not None:
            self._reaper.cancel()
        handles = [s.handle for s in self._slots.values() if s.handle is not None]
        for slot in self._slots.values():
            slot.handle = None
        await asyncio.gather(*(asyncio.to_thread(h.stop) for h in handles), return_exceptions=True)
