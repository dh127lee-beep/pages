"""High-level wrapper that owns one dsh runtime subprocess and runs agent turns on it."""

from __future__ import annotations

import json
import logging
import shutil
import threading
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

from deepseek_harness import DeepSeekHarness, JsonObject, Notification, RunResult

from .config import LOCAL_API_KEY_ENV, DshSettings
from .events import AgentEvent, parse_notification
from .sidecar import ExecFn, SearchFn, Sidecar, dummy_search

log = logging.getLogger(__name__)

EventHandler = Callable[[AgentEvent], None]


class SessionBusyError(RuntimeError):
    """A turn is already running in this session."""


@dataclass(slots=True)
class AgentResult:
    session_id: str
    text: str
    finish_reason: str | None
    events: list[AgentEvent] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return self.finish_reason in (None, "completed")


class DshAgent:
    """Runs prompts against the dsh runtime.

    One runtime subprocess serves many sessions. The SDK client multiplexes
    sessions over a single stdio connection and is thread-safe, so turns in
    different sessions run concurrently (call ``run`` from separate threads).
    Turns within the same session are rejected while one is in flight.

    If the runtime dies, the next call starts a fresh one and resumes sessions
    from ``dsh_home`` on demand.
    """

    def __init__(
        self,
        settings: DshSettings | None = None,
        *,
        search: SearchFn = dummy_search,
        exec_fn: ExecFn | None = None,
    ) -> None:
        self.settings = settings or DshSettings.from_env()
        Path(self.settings.dsh_home).mkdir(parents=True, exist_ok=True)
        self._search = search
        self._exec_fn = exec_fn
        self._sidecar: Sidecar | None = None
        self._runtime_lock = threading.Lock()
        self._harness: DeepSeekHarness | None = None
        # Sessions loaded into the current runtime process.
        self._live_sessions: set[str] = set()
        self._session_locks: dict[str, threading.Lock] = {}
        self._session_locks_guard = threading.Lock()

    def __enter__(self) -> "DshAgent":
        self.start()
        return self

    def __exit__(self, *_exc: object) -> None:
        self.close()

    def _new_harness(self) -> DeepSeekHarness:
        s = self.settings
        home = Path(s.dsh_home).resolve()
        via_sidecar = s.uses_local_route and s.tool_repair
        if self._sidecar is None:
            self._sidecar = Sidecar(
                s.llm_base_url,
                self._search,
                exec_fn=self._exec_fn,
                # The sidecar adds the real key upstream, so the runtime never holds it.
                upstream_api_key=s.llm_api_key if via_sidecar else None,
            ).start()
        sidecar_url = self._sidecar.url

        generated: list[Path] = []
        env: dict[str, str] = {"DSH_SERVER_SIDECAR_URL": sidecar_url}
        if s.permission_mode:
            env["DSH_PERMISSION_MODE"] = s.permission_mode
        if s.uses_local_route:
            base_url = f"{sidecar_url}/v1" if via_sidecar else s.llm_base_url
            patch_path = home / "dsh-server.local-llm.patch.yml"
            patch_path.write_text(s.local_route_patch(base_url), "utf-8")
            generated.append(patch_path)
            env[LOCAL_API_KEY_ENV] = "via-sidecar" if via_sidecar else s.llm_api_key

        # WASM tools need the sidecar exec handler (AgentService); without it dsh keeps its native tools.
        wasm = s.code_exec == "wasm" and self._exec_fn is not None
        confine = s.confine_tools and s.workspaces_root is not None
        if confine:
            env["DSH_SERVER_WORKSPACES_ROOT"] = str(Path(s.workspaces_root).resolve())  # type: ignore[arg-type]
        wanted = {
            "stream_bridge": s.stream,
            "web_search": s.web_search,
            "code_tools": wasm,
            "workspace_guard": confine,
        }
        plugins = [name for name, enabled in wanted.items() if enabled]
        # In wasm mode the OS-level code runners are removed from the tool set entirely.
        disabled = _NATIVE_CODE_ROWS if wasm else ()
        if plugins or disabled:
            generated.append(_install_plugins(home, s.profile, plugins, disabled))
        patches = [str(p) for p in generated] + [str(Path(p).resolve()) for p in s.patches]
        return DeepSeekHarness(
            provider=s.provider,
            model=s.model,
            profile=s.profile,
            reasoning_effort=s.reasoning_effort,
            max_tokens=s.max_tokens,
            cwd=str(Path(s.workspace).resolve()),
            dsh_home=str(Path(s.dsh_home).resolve()),
            patches=tuple(patches),
            env=env,
            api_key=s.api_key,
            base_url=s.base_url,
            request_timeout_seconds=s.request_timeout_seconds,
        )

    def _ensure_harness(self) -> DeepSeekHarness:
        with self._runtime_lock:
            if self._harness is None:
                harness = self._new_harness()
                harness.start()
                self._harness = harness
                self._live_sessions.clear()
            return self._harness

    def _discard_harness(self, harness: DeepSeekHarness) -> None:
        """Drop a broken runtime so the next call restarts it."""
        with self._runtime_lock:
            if self._harness is not harness:
                return
            self._harness = None
            self._live_sessions.clear()
        try:
            harness.close()
        except Exception:  # noqa: BLE001 - best effort cleanup of a dead runtime
            log.exception("failed to close dsh runtime")

    def start(self) -> None:
        self._ensure_harness()

    def close(self) -> None:
        with self._runtime_lock:
            harness, self._harness = self._harness, None
            sidecar, self._sidecar = self._sidecar, None
            self._live_sessions.clear()
        if harness is not None:
            harness.close()
        if sidecar is not None:
            sidecar.close()

    @staticmethod
    def new_session_id() -> str:
        return f"session-{uuid.uuid4().hex}"

    def is_busy(self, session_id: str) -> bool:
        lock = self._session_locks.get(session_id)
        return lock is not None and lock.locked()

    def _session_lock(self, session_id: str) -> threading.Lock:
        with self._session_locks_guard:
            return self._session_locks.setdefault(session_id, threading.Lock())

    def forget_session(self, session_id: str) -> None:
        with self._session_locks_guard:
            lock = self._session_locks.get(session_id)
            if lock is not None and not lock.locked():
                del self._session_locks[session_id]
        with self._runtime_lock:
            self._live_sessions.discard(session_id)

    def run(
        self,
        prompt: str | list[JsonObject],
        *,
        session_id: str | None = None,
        on_event: EventHandler | None = None,
        resume: bool | None = None,
        workdir: str | None = None,
    ) -> AgentResult:
        """Run one turn (blocking).

        Without ``session_id`` a new session is created. ``resume`` controls
        whether an id not yet loaded in this runtime is restored from
        ``dsh_home``; by default it is resumed whenever an id is given.
        ``workdir`` sets the working directory of a newly started session.
        Raises SessionBusyError if the session is already running a turn.
        """
        if resume is None:
            resume = session_id is not None
        session_id = session_id or self.new_session_id()
        lock = self._session_lock(session_id)
        if not lock.acquire(blocking=False):
            raise SessionBusyError(session_id)
        try:
            harness = self._ensure_harness()
            try:
                with self._runtime_lock:
                    live = session_id in self._live_sessions
                if not live and resume:
                    session = harness.resume_session(session_id)
                else:
                    session = harness.start_session(session_id)
                    if not live and workdir is not None:
                        Path(workdir).mkdir(parents=True, exist_ok=True)
                        session.set_working_directory(str(Path(workdir).resolve()))
                with self._runtime_lock:
                    self._live_sessions.add(session_id)

                collected: list[AgentEvent] = []

                def handle(notification: Notification) -> None:
                    for event in parse_notification(notification):
                        collected.append(event)
                        if on_event is not None:
                            try:
                                on_event(event)
                            except Exception:  # noqa: BLE001 - a bad listener must not kill the turn
                                log.exception("on_event handler failed")

                result: RunResult = session.run(prompt, on_notification=handle)
            except Exception:
                if not _runtime_alive(harness):
                    self._discard_harness(harness)
                raise
        finally:
            lock.release()

        return AgentResult(
            session_id=result.session_id,
            text=result.final_response,
            finish_reason=result.finish_reason,
            events=collected,
        )

    def ask(self, prompt: str, *, session_id: str | None = None) -> str:
        """Convenience: run a turn and return only the final assistant text."""
        return self.run(prompt, session_id=session_id).text


_PLUGINS_DIR = Path(__file__).parent / "dsh_plugins"
# plugin dir -> (package name, Cordis row id)
_PLUGINS = {
    "stream_bridge": ("@dsh-server/stream-bridge", "dsh-server-stream-bridge"),
    "web_search": ("@dsh-server/web-search", "dsh-server-web-search"),
    "code_tools": ("@dsh-server/code-tools", "dsh-server-code-tools"),
    "workspace_guard": ("@dsh-server/workspace-guard", "dsh-server-workspace-guard"),
}
# dsh rows that run code as host processes (bash, and JS workflows via ptc-runtime).
_NATIVE_CODE_ROWS = ("bash-sandbox", "tool-workflow")


def _install_plugins(dsh_home: Path, profile: str, plugins: list[str], disabled: tuple[str, ...] = ()) -> Path:
    """Copy bundled dsh plugins where the profile resolves packages; return the patch loading them."""
    rows = []
    for plugin in plugins:
        package, row_id = _PLUGINS[plugin]
        dest = dsh_home / "profiles" / profile / "node_modules" / package
        dest.mkdir(parents=True, exist_ok=True)
        for src in (_PLUGINS_DIR / plugin).iterdir():
            if src.is_file():
                shutil.copyfile(src, dest / src.name)
        rows.append({"id": row_id, "name": package})
    patch: list[dict[str, object]] = [{"insert": rows}] if rows else []
    patch += [{"id": row_id, "disabled": True} for row_id in disabled]
    if "web_search" in plugins:
        # Route the web_search tool to the sidecar-backed provider (overrides the whole row config).
        patch.append({"id": "web", "config": {"searchProvider": "dsh-server", "fetchProvider": "http"}})
    path = dsh_home / "dsh-server.plugins.patch.yml"
    path.write_text(json.dumps(patch, indent=2), "utf-8")
    (dsh_home / "dsh-server.stream-bridge.patch.yml").unlink(missing_ok=True)
    return path


def _runtime_alive(harness: DeepSeekHarness) -> bool:
    proc = getattr(harness.client, "_proc", None)
    return proc is not None and proc.poll() is None
