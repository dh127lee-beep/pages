/**
 * `python` and `javascript` tools: run model-written code in the dsh-server
 * WebAssembly sandbox.
 *
 * Execution happens in the sidecar (`POST $DSH_SERVER_SIDECAR_URL/exec`),
 * which runs CPython or QuickJS on WASI with only the calling session's
 * workspace mounted. Tools are registered as plain ToolDefinitions so the
 * plugin has no imports from the harness packages.
 */

export const name = 'dsh-server-code-tools'
export const inject = ['tools']

const COMMON = [
  'The current directory is the session workspace (uploaded files are under uploads/); files written there persist and can be read by later calls and by the read tool.',
  'There is no network access, no subprocess and no shell. Each call starts a fresh interpreter, so keep state in files.',
  'Print results to stdout. Use this tool instead of describing code whenever a calculation, data processing or file generation is needed.',
].join(' ')

const LANGUAGES = {
  python: {
    description: `Run a Python 3.15 program in an isolated WebAssembly sandbox and return its combined stdout/stderr. Only the standard library is available (no pip, no C extensions such as numpy or pandas). ${COMMON}`,
    codeDescription: 'Complete Python program to run.',
  },
  javascript: {
    description: `Run a JavaScript (ES2023 module, top-level await allowed) program in an isolated WebAssembly sandbox (QuickJS) and return its combined output. This is not Node.js: there is no require, node: modules, npm or fetch. Use console.log for output and the 'qjs:std' module for files (std.loadFile(path), std.open(path, 'w').puts(text)). ${COMMON}`,
    codeDescription: 'Complete JavaScript module to run.',
  },
}

const OUTPUT_SCHEMA = {
  type: 'object',
  additionalProperties: true,
  required: ['output', 'exitCode'],
  properties: {
    output: { type: 'string' },
    exitCode: { type: 'number' },
    timedOut: { type: 'boolean' },
    truncated: { type: 'boolean' },
    durationMs: { type: 'number' },
  },
}

export function apply(ctx) {
  const baseURL = process.env.DSH_SERVER_SIDECAR_URL

  for (const [language, spec] of Object.entries(LANGUAGES)) {
    ctx.tools.register({
      name: language,
      description: spec.description,
      parameters: {
        type: 'object',
        additionalProperties: false,
        required: ['code'],
        properties: {
          code: { type: 'string', description: spec.codeDescription },
          timeout_seconds: { type: 'number', description: 'Wall-clock limit in seconds (default 30, max 120).' },
        },
      },
      output: {
        schema: OUTPUT_SCHEMA,
        render: (_args, value) => [{
          type: 'text',
          text: `${value.output || '(no output)'}${value.exitCode === 0 ? '' : `\n[exit code ${value.exitCode}]`}`,
        }],
      },
      async execute(args, exec) {
        if (typeof args?.code !== 'string' || args.code.trim() === '') throw new Error(`${language}: "code" must be a non-empty string`)
        if (!baseURL) throw new Error(`${language}: sandbox sidecar is not configured`)
        if (exec.agent === undefined) throw new Error(`${language} requires an agent session`)
        const response = await fetch(`${baseURL}/exec`, {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({
            sessionId: String(exec.agent.session.id),
            language,
            code: args.code,
            timeoutSeconds: args.timeout_seconds,
          }),
          ...(exec.signal !== undefined ? { signal: exec.signal } : {}),
        })
        const payload = await response.json()
        if (!response.ok) throw new Error(`${language} sandbox error: ${payload.error ?? response.status}`)
        return payload
      },
    })
  }
}
