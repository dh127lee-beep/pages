/**
 * `WebSearchProvider` for the dsh `web_search` tool that delegates to the
 * dsh-server sidecar (`POST $DSH_SERVER_SIDECAR_URL/search`), so the search
 * backend is implemented in Python.
 */

export const name = 'dsh-server-web-search'
export const inject = ['web']

const PROVIDER_ID = 'dsh-server'

class SidecarSearchProvider {
  id = PROVIDER_ID

  constructor(baseURL) {
    this.baseURL = baseURL
  }

  available() {
    return typeof this.baseURL === 'string' && URL.canParse(this.baseURL)
  }

  async search(request, signal) {
    const response = await fetch(`${this.baseURL}/search`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ query: request.query, maxResults: request.maxResults }),
      ...(signal !== undefined ? { signal } : {}),
    })
    const payload = await response.json()
    if (!response.ok) throw new Error(`dsh-server search failed: ${payload.error ?? response.status}`)
    const sources = (payload.sources ?? [])
      .filter((s) => typeof s.url === 'string')
      .map((s) => ({
        url: s.url,
        ...(s.title ? { title: s.title } : {}),
        ...(s.snippet ? { snippet: s.snippet } : {}),
        ...(s.publishedAt ? { publishedAt: s.publishedAt } : {}),
      }))
    return { ...(payload.content ? { content: payload.content } : {}), sources, truncated: false }
  }
}

export function apply(ctx) {
  ctx.web.registerSearchProvider(new SidecarSearchProvider(process.env.DSH_SERVER_SIDECAR_URL))
}
