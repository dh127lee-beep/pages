/**
 * Forwards live model output to the SDK client.
 *
 * The SDK JSON-RPC server only relays durable session events, where token
 * deltas arrive packed after each model attempt. This plugin listens to the
 * live `agent/assistant-stream` frames and writes them to stdout as
 * `session.delta` JSON-RPC notifications. Each frame is a single
 * `write()` of one complete line, so it cannot interleave with the server's own
 * frames.
 */

export const name = 'dsh-server-stream-bridge'

function send(params) {
  process.stdout.write(`${JSON.stringify({ jsonrpc: '2.0', method: 'session.delta', params })}\n`)
}

export function apply(ctx) {
  ctx.on('agent/assistant-stream', ({ agent, frame }) => {
    const sessionId = String(agent.session.id)
    const attemptId = String(frame.attemptId)
    if (frame.type === 'start') {
      send({ sessionId, type: 'start', attemptId, turn: frame.turn, step: frame.step })
      return
    }
    if (frame.type === 'end') {
      send({ sessionId, type: 'end', attemptId, committed: frame.outcome.kind === 'committed' })
      return
    }
    const chunk = frame.chunk
    if ((chunk.type === 'text-delta' || chunk.type === 'reasoning-delta') && chunk.text !== '') {
      send({
        sessionId,
        type: chunk.type === 'text-delta' ? 'text' : 'reasoning',
        attemptId,
        index: chunk.index,
        text: chunk.text,
      })
    }
  })
}
