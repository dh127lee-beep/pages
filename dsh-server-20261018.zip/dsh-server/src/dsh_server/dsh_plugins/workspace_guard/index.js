/**
 * Confines every tool call of a session to that session's workspace folder.
 *
 * Hooks `tools/pre-execute`, which every tool dispatch passes through:
 * - deny by default: only tools listed below may run (new or MCP tools are blocked);
 * - path arguments must resolve, after following symlinks, inside
 *   `$DSH_SERVER_WORKSPACES_ROOT/<sessionId>`; `..` segments and absolute glob
 *   patterns are rejected outright.
 * Code execution itself happens in the WASM sandbox (code-tools plugin), which
 * only mounts the same folder.
 */

import fs from 'node:fs'
import path from 'node:path'

export const name = 'dsh-server-workspace-guard'
export const inject = ['workingDirectory']

/** tool name -> argument names holding a filesystem path (empty: no filesystem access). */
const ALLOWED = {
  read: ['file_path'],
  read_image: ['file_path'],
  write: ['file_path'],
  edit: ['file_path'],
  glob: ['path'],
  grep: ['path'],
  working_directory: ['cd'],
  python: [],
  javascript: [],
  web_search: [],
  web_fetch: [],
  todo_write: [],
  create_goal: [],
  get_goal: [],
  update_goal: [],
  skill: [],
  exit_plan_mode: [],
}

/** Glob-like arguments that are matched relative to `path`; they must stay relative. */
const PATTERN_ARGS = { glob: ['pattern'], grep: ['include'] }

function realResolve(target) {
  // realpath of the nearest existing ancestor, so not-yet-created files are checked too.
  const rest = []
  let current = target
  for (;;) {
    try {
      return path.join(fs.realpathSync(current), ...rest.reverse())
    } catch {
      const parent = path.dirname(current)
      if (parent === current) return target
      rest.push(path.basename(current))
      current = parent
    }
  }
}

function isInside(root, candidate) {
  return candidate === root || candidate.startsWith(root + path.sep)
}

function hasParentSegment(value) {
  return value.split(/[\\/]+/).includes('..')
}

function deny(reason) {
  return { kind: 'deny', reason: `[sandbox] ${reason}` }
}

export function apply(ctx) {
  const workspacesRoot = process.env.DSH_SERVER_WORKSPACES_ROOT
  if (!workspacesRoot) throw new Error('workspace-guard requires DSH_SERVER_WORKSPACES_ROOT')

  ctx.on('tools/pre-execute', async (exec, next) => {
    const argNames = ALLOWED[exec.name]
    if (argNames === undefined) return deny(`tool "${exec.name}" is not available in this sandboxed session`)
    if (exec.agent === undefined) return deny(`tool "${exec.name}" requires a session`)

    const sessionRoot = path.join(workspacesRoot, String(exec.agent.session.id))
    fs.mkdirSync(sessionRoot, { recursive: true })
    const root = fs.realpathSync(sessionRoot)
    const args = exec.arguments && typeof exec.arguments === 'object' ? exec.arguments : {}

    for (const name of PATTERN_ARGS[exec.name] ?? []) {
      const value = args[name]
      if (typeof value === 'string' && (path.isAbsolute(value) || value.startsWith('~') || hasParentSegment(value))) {
        return deny(`"${name}" must be a relative pattern inside the session workspace`)
      }
    }

    if (argNames.length > 0) {
      const cwd = await ctx.workingDirectory.ensure(exec.agent, exec.signal)
      if (!isInside(root, realResolve(cwd))) {
        return deny('the working directory is outside the session workspace; use working_directory to return to it')
      }
      for (const name of argNames) {
        const value = args[name]
        if (value === undefined || value === null || value === '') continue
        if (typeof value !== 'string') return deny(`"${name}" must be a path string`)
        if (value.startsWith('~') || hasParentSegment(value)) {
          return deny(`"${name}" may not use ~ or .. — use a path inside the session workspace`)
        }
        const resolved = realResolve(path.resolve(cwd, value))
        if (!isInside(root, resolved)) {
          return deny(`"${value}" is outside the session workspace (${root}); only files under it are accessible`)
        }
      }
    }
    return next()
  })
}
