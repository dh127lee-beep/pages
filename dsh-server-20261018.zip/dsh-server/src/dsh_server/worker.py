"""Agent worker: serves one AgentService over HTTP to the API server.

Run one worker per user (see pool.py). The worker holds the user's dsh runtime,
WASM sandbox and session folders; the API server never runs agent code.

  GET    /health
  POST   /sessions/{id}/turns              {"text", "attachments", "resume"} -> NDJSON stream:
                                           {"event": {...}}* then {"result": {...}} | {"error", "code"}
  POST   /sessions/{id}/attachments/check  {"attachments": [...]} -> normalized list
  POST   /sessions/{id}/files              multipart upload -> [{"name","path","size","mime"}]
  GET    /sessions/{id}/files/{path}
  DELETE /sessions/{id}

Every request needs "Authorization: Bearer $DSH_WORKER_TOKEN". The token is
removed from the environment at startup so the dsh runtime never inherits it.
"""

from __future__ import annotations

import asyncio
import hmac
import json
import logging
import os
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any

from fastapi import Depends, FastAPI, Header, HTTPException, UploadFile
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field

from .agent import SessionBusyError
from .config import DshSettings
from .events import AgentEvent
from .service import AgentService, check_session_id

log = logging.getLogger(__name__)

WORKER_TOKEN = os.environ.pop("DSH_WORKER_TOKEN", "")
DATA_DIR = Path(os.environ.get("DSH_WORKER_DATA", Path.cwd() / ".dsh-worker")).resolve()


@asynccontextmanager
async def lifespan(app: FastAPI):
    settings = DshSettings.from_env(dsh_home=os.environ.get("DSH_HOME") or str(DATA_DIR / "dsh-home"))
    # The sidecar injects the key upstream; keep it out of the environment the runtime inherits.
    os.environ.pop("DSH_LLM_API_KEY", None)
    service = AgentService(settings, DATA_DIR / "workspaces")
    await asyncio.to_thread(service.start)
    app.state.service = service
    log.info("agent worker ready (data=%s)", DATA_DIR)
    try:
        yield
    finally:
        await asyncio.to_thread(service.close)


app = FastAPI(title="dsh-agent-worker", lifespan=lifespan)


def require_token(authorization: str | None = Header(default=None)) -> None:
    token = authorization.removeprefix("Bearer ").strip() if authorization else ""
    if not WORKER_TOKEN or not hmac.compare_digest(token, WORKER_TOKEN):
        raise HTTPException(401, "invalid worker token")


def service() -> AgentService:
    return app.state.service


def session(session_id: str) -> str:
    try:
        return check_session_id(session_id)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from None


class TurnIn(BaseModel):
    text: str = ""
    attachments: list[dict[str, Any]] = Field(default_factory=list)
    resume: bool = False


class AttachmentsIn(BaseModel):
    attachments: list[dict[str, Any]] = Field(default_factory=list)


@app.get("/health")
def health(_: None = Depends(require_token)) -> dict[str, Any]:
    return {"ok": True, **service().info()}


@app.post("/sessions/{session_id}/turns")
async def run_turn(session_id: str, body: TurnIn, _: None = Depends(require_token)) -> StreamingResponse:
    session_id = session(session_id)
    svc = service()
    if svc.is_busy(session_id):
        raise HTTPException(409, "a turn is already running in this session")
    loop = asyncio.get_running_loop()
    queue: asyncio.Queue[dict[str, Any] | None] = asyncio.Queue()

    def on_event(event: AgentEvent) -> None:
        loop.call_soon_threadsafe(queue.put_nowait, {"event": event.to_dict()})

    def work() -> None:
        try:
            result = svc.run(session_id, body.text, body.attachments, resume=body.resume, on_event=on_event)
            final: dict[str, Any] = {
                "result": {"session_id": result.session_id, "text": result.text, "finish_reason": result.finish_reason}
            }
        except SessionBusyError:
            final = {"error": "a turn is already running in this session", "code": "busy"}
        except FileNotFoundError as exc:
            final = {"error": f"attachment not found: {exc}", "code": "not_found"}
        except Exception as exc:  # noqa: BLE001 - reported to the API server
            log.exception("turn failed in %s", session_id)
            final = {"error": f"{type(exc).__name__}: {exc}", "code": "internal"}
        loop.call_soon_threadsafe(queue.put_nowait, final)
        loop.call_soon_threadsafe(queue.put_nowait, None)

    # The turn keeps running even if the API server disconnects mid-stream.
    task = loop.run_in_executor(None, work)

    async def stream() -> AsyncIterator[bytes]:
        while (item := await queue.get()) is not None:
            yield (json.dumps(item, ensure_ascii=False) + "\n").encode()
        await task

    return StreamingResponse(stream(), media_type="application/x-ndjson")


@app.post("/sessions/{session_id}/attachments/check")
def check_attachments(session_id: str, body: AttachmentsIn, _: None = Depends(require_token)) -> list[dict[str, Any]]:
    try:
        return service().check_attachments(session(session_id), body.attachments)
    except FileNotFoundError as exc:
        raise HTTPException(404, f"attachment not found: {exc}") from None


@app.post("/sessions/{session_id}/files", status_code=201)
async def upload(session_id: str, files: list[UploadFile], _: None = Depends(require_token)) -> list[dict[str, Any]]:
    session_id = session(session_id)
    saved = []
    for f in files:
        try:
            saved.append(await asyncio.to_thread(service().save_file, session_id, f.filename or "file", f.file, f.content_type))
        except ValueError as exc:
            raise HTTPException(413, str(exc)) from None
    return saved


@app.get("/sessions/{session_id}/files/{path:path}")
def download(session_id: str, path: str, _: None = Depends(require_token)) -> StreamingResponse:
    try:
        stream = service().open_file(session(session_id), path)
    except FileNotFoundError:
        raise HTTPException(404, "file not found") from None
    return StreamingResponse(
        stream.chunks,
        media_type=stream.mime,
        headers={"Content-Length": str(stream.size), "X-File-Name": stream.name.encode().hex()},
    )


@app.delete("/sessions/{session_id}", status_code=204)
def delete(session_id: str, _: None = Depends(require_token)) -> None:
    try:
        service().delete_session(session(session_id))
    except SessionBusyError:
        raise HTTPException(409, "a turn is running in this session") from None


def main() -> None:
    import uvicorn

    logging.basicConfig(level=logging.INFO)
    if not WORKER_TOKEN:
        raise SystemExit("DSH_WORKER_TOKEN is required")
    uvicorn.run(
        app,
        host=os.environ.get("DSH_WORKER_HOST", "127.0.0.1"),
        port=int(os.environ.get("DSH_WORKER_PORT", "8100")),
        log_level="warning",
    )


if __name__ == "__main__":
    main()
