"""Settings for the dsh runtime, loaded from environment variables."""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from pathlib import Path

# Route name for the OpenAI-compatible endpoint declared on dsh's pi-ai adapter.
LOCAL_PROVIDER = "local"
# Env var the generated route reads its key from (passed only to the runtime).
LOCAL_API_KEY_ENV = "DSH_SERVER_LLM_API_KEY"


@dataclass(slots=True)
class DshSettings:
    # Directory holding dsh profiles, plugins and session logs. Required by the SDK.
    dsh_home: str
    # Workspace the agent operates in.
    workspace: str = field(default_factory=lambda: str(Path.cwd()))
    # "local" routes through llm_base_url below; "deepseek-official" uses DeepSeek directly.
    provider: str = LOCAL_PROVIDER
    model: str = "sonnet"
    profile: str = "sdk"
    reasoning_effort: str | None = None
    max_tokens: int | None = None
    patches: tuple[str, ...] = ()
    # Endpoint for the "local" provider.
    llm_base_url: str = "http://127.0.0.1:8899/v1"
    llm_api_key: str = "dummy"
    # pi-ai wire protocol: openai-completions | openai-responses | anthropic-messages
    llm_api: str = "openai-completions"
    # DeepSeek provider credentials (only used when provider is a DeepSeek route).
    api_key: str | None = None
    base_url: str | None = None
    request_timeout_seconds: float | None = None
    # Install the stream-bridge dsh plugin so token deltas reach the client live.
    stream: bool = True
    # Proxy the "local" route through the sidecar, turning text <invoke> markup into tool calls.
    tool_repair: bool = True
    # Back the web_search tool with the sidecar's search function instead of DeepSeek search.
    web_search: bool = True
    # Send attached images to the model as image blocks (needs a vision-capable endpoint).
    vision: bool = False
    # "wasm": code runs only through the python/javascript WASM tools (bash and workflow are removed).
    # "native": dsh's own bash/workflow tools, confined by the OS sandbox (bwrap/Landlock/Seatbelt).
    code_exec: str = "wasm"
    # Root holding one folder per session; set by the agent service. Enables per-session confinement.
    workspaces_root: str | None = None
    # Install the workspace guard: every tool call is limited to its session folder (needs workspaces_root).
    confine_tools: bool = True
    # Shared cache for the CPython/QuickJS WASI binaries.
    wasm_dir: str = field(default_factory=lambda: str(Path.home() / ".cache" / "dsh-server" / "wasm"))
    # dsh sandbox mode for its own tools (read-only | workspace-write | danger-full-access); None = dsh default.
    permission_mode: str | None = None

    @property
    def uses_local_route(self) -> bool:
        return self.provider == LOCAL_PROVIDER

    def local_route_patch(self, base_url: str | None = None) -> str:
        """Cordis patch declaring the "local" route on the pi-ai adapter (JSON is valid YAML)."""
        route = {
            "displayName": "Local LLM",
            "apiKeyEnv": LOCAL_API_KEY_ENV,
            "api": self.llm_api,
            "baseURL": base_url or self.llm_base_url,
            "models": [{"id": self.model, "input": ["text", "image"] if self.vision else ["text"]}],
        }
        return json.dumps([{"id": "llm-pi-ai", "config": {"providers": {LOCAL_PROVIDER: route}}}], indent=2)

    @classmethod
    def from_env(cls, **overrides: object) -> "DshSettings":
        """Build settings from DSH_* / DEEPSEEK_* env vars; keyword overrides win."""
        env = os.environ
        dsh_home = env.get("DSH_HOME", "").strip() or str(Path.cwd() / ".dsh-home")
        patches = tuple(p for p in env.get("DSH_PATCHES", "").split(os.pathsep) if p)
        max_tokens = env.get("DSH_MAX_TOKENS")
        timeout = env.get("DSH_REQUEST_TIMEOUT")

        values: dict[str, object] = {
            "dsh_home": dsh_home,
            "workspace": env.get("DSH_WORKSPACE") or str(Path.cwd()),
            "provider": env.get("DSH_PROVIDER", LOCAL_PROVIDER),
            "model": env.get("DSH_MODEL", "sonnet"),
            "profile": env.get("DSH_PROFILE", "sdk"),
            "reasoning_effort": env.get("DSH_REASONING_EFFORT") or None,
            "max_tokens": int(max_tokens) if max_tokens else None,
            "patches": patches,
            "llm_base_url": env.get("DSH_LLM_BASE_URL", "http://127.0.0.1:8899/v1"),
            "llm_api_key": env.get("DSH_LLM_API_KEY", "dummy"),
            "llm_api": env.get("DSH_LLM_API", "openai-completions"),
            # None lets the runtime inherit DEEPSEEK_API_KEY / DEEPSEEK_BASE_URL directly.
            "api_key": None,
            "base_url": None,
            "request_timeout_seconds": float(timeout) if timeout else None,
            "stream": _flag(env.get("DSH_STREAM")),
            "tool_repair": _flag(env.get("DSH_TOOL_REPAIR")),
            "web_search": _flag(env.get("DSH_WEB_SEARCH")),
            "vision": _flag(env.get("DSH_VISION"), default=False),
            "code_exec": env.get("DSH_CODE_EXEC", "wasm"),
            "workspaces_root": env.get("DSH_WORKSPACES_ROOT") or None,
            "confine_tools": _flag(env.get("DSH_CONFINE_TOOLS")),
            "wasm_dir": env.get("DSH_WASM_DIR") or str(Path.home() / ".cache" / "dsh-server" / "wasm"),
            "permission_mode": env.get("DSH_PERMISSION_MODE") or None,
        }
        values.update(overrides)
        return cls(**values)  # type: ignore[arg-type]


def _flag(value: str | None, default: bool = True) -> bool:
    if not value:
        return default
    return value.lower() not in ("0", "false", "no", "off")
