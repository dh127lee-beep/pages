"""API server: multi-client HTTP/WebSocket chat backed by per-user agent workers.

It keeps users' transcripts and fans out events; agent code never runs here.
Each user's turns, files and code execution go to that user's agent worker
(see pool.py; DSH_WORKER_MODE = per-user | remote | inprocess).

REST
  GET    /api/health
  GET    /api/sessions                 list the caller's sessions
  POST   /api/sessions                 create a session
  GET    /api/sessions/{id}            transcript
  DELETE /api/sessions/{id}
  POST   /api/sessions/{id}/messages   {"text": "...", "attachments": [{"path": ...}]} start a turn (202)
  POST   /api/sessions/{id}/files      multipart upload -> [{"name","path","size","mime"}]
  GET    /api/sessions/{id}/files/{path}  a file from the session workspace
WebSocket
  /api/sessions/{id}/ws                send {"type":"prompt","text":"...","attachments":[...]}; receive events

Callers identify themselves with the X-Client-Id header (or ?client_id= on the
WebSocket); sessions are only visible to the client that created them. When
DSH_SERVER_TOKEN is set, every request also needs "Authorization: Bearer <token>"
(or ?token= on the WebSocket).
"""

from __future__ import annotations

import asyncio
import hmac
import logging
import os
from contextlib import asynccontextmanager
from urllib.parse import quote
from pathlib import Path
from typing import Any

from fastapi import Depends, FastAPI, Header, HTTPException, Query, UploadFile, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field

from .agent import DshAgent, SessionBusyError
from .config import DshSettings
from .hub import SessionHub
from .pool import DockerProvisioner, InProcessProvisioner, LocalProcessProvisioner, Provisioner, RemoteProvisioner, WorkerPool
from .store import SessionRecord, SessionStore

log = logging.getLogger(__name__)

DATA_DIR = Path(os.environ.get("DSH_SERVER_DATA", Path.cwd() / ".dsh-server")).resolve()
SERVER_TOKEN = os.environ.get("DSH_SERVER_TOKEN", "")
MAX_CONCURRENT_TURNS = int(os.environ.get("DSH_MAX_CONCURRENT_TURNS", "32"))
CORS_ORIGINS = [o for o in os.environ.get("DSH_CORS_ORIGINS", "http://localhost:5173").split(",") if o]
WORKER_MODE = os.environ.get("DSH_WORKER_MODE", "per-user")
WORKER_IDLE_SECONDS = float(os.environ.get("DSH_WORKER_IDLE_SECONDS", "900"))


def make_provisioner() -> Provisioner:
    if WORKER_MODE == "per-user":
        return LocalProcessProvisioner(DATA_DIR / "workers")
    if WORKER_MODE == "docker":
        return DockerProvisioner(os.environ["DSH_WORKER_IMAGE"], os.environ.get("DSH_WORKER_NETWORK", "dsh"))
    if WORKER_MODE == "remote":
        return RemoteProvisioner(os.environ["DSH_WORKER_URL"], os.environ["DSH_WORKER_TOKEN"])
    if WORKER_MODE == "inprocess":
        return InProcessProvisioner(DATA_DIR / "inprocess")
    raise SystemExit(f"unknown DSH_WORKER_MODE: {WORKER_MODE}")


@asynccontextmanager
async def lifespan(app: FastAPI):
    pool = WorkerPool(make_provisioner(), idle_timeout=WORKER_IDLE_SECONDS)
    await pool.start()
    app.state.hub = SessionHub(pool, SessionStore(DATA_DIR / "sessions"), max_concurrent_turns=MAX_CONCURRENT_TURNS)
    app.state.settings = DshSettings.from_env(dsh_home=str(DATA_DIR / "unused"))
    log.info("api server ready (worker mode=%s)", WORKER_MODE)
    try:
        yield
    finally:
        await app.state.hub.shutdown()


app = FastAPI(title="dsh-server", lifespan=lifespan)
app.add_middleware(
    CORSMiddleware,
    allow_origins=CORS_ORIGINS,
    allow_methods=["*"],
    allow_headers=["*"],
)


def _token_ok(token: str | None) -> bool:
    return not SERVER_TOKEN or (token is not None and hmac.compare_digest(token, SERVER_TOKEN))


def _valid_client_id(client_id: str | None) -> str:
    if not client_id or len(client_id) > 128:
        raise HTTPException(400, "X-Client-Id header is required")
    return client_id


def require_client(
    x_client_id: str | None = Header(default=None),
    authorization: str | None = Header(default=None),
) -> str:
    token = authorization.removeprefix("Bearer ").strip() if authorization else None
    if not _token_ok(token):
        raise HTTPException(401, "invalid token")
    return _valid_client_id(x_client_id)


def get_hub() -> SessionHub:
    return app.state.hub


def _owned(hub: SessionHub, session_id: str, client_id: str) -> SessionRecord:
    record = hub.store.get(session_id)
    if record is None or record.owner != client_id:
        raise HTTPException(404, "session not found")
    return record


def _session_view(hub: SessionHub, record: SessionRecord, *, items: bool = False) -> dict[str, Any]:
    view = record.summary()
    view["running"] = hub.is_running(record.id)
    if items:
        view["items"] = record.items
    return view


class AttachmentRef(BaseModel):
    path: str = Field(min_length=1, max_length=1024)
    mime: str | None = None


class MessageIn(BaseModel):
    text: str = Field(default="", max_length=100_000)
    attachments: list[AttachmentRef] = Field(default_factory=list, max_length=20)


@app.get("/api/health")
def health() -> dict[str, Any]:
    s: DshSettings = app.state.settings
    return {
        "ok": True,
        "model": s.model,
        "profile": s.profile,
        "vision": s.vision,
        "code_exec": s.code_exec,
        **get_hub().pool.info(),
    }


@app.get("/api/sessions")
def list_sessions(client_id: str = Depends(require_client)) -> list[dict[str, Any]]:
    hub = get_hub()
    return [_session_view(hub, r) for r in hub.store.list(owner=client_id)]


@app.post("/api/sessions", status_code=201)
def create_session(client_id: str = Depends(require_client)) -> dict[str, Any]:
    hub = get_hub()
    record = hub.store.create(DshAgent.new_session_id(), owner=client_id)
    return _session_view(hub, record, items=True)


@app.get("/api/sessions/{session_id}")
def get_session(session_id: str, client_id: str = Depends(require_client)) -> dict[str, Any]:
    hub = get_hub()
    return _session_view(hub, _owned(hub, session_id, client_id), items=True)


@app.delete("/api/sessions/{session_id}", status_code=204)
async def delete_session(session_id: str, client_id: str = Depends(require_client)) -> None:
    hub = get_hub()
    _owned(hub, session_id, client_id)
    try:
        await hub.delete(session_id)
    except SessionBusyError:
        raise HTTPException(409, "a turn is running in this session") from None


@app.post("/api/sessions/{session_id}/messages", status_code=202)
async def post_message(session_id: str, body: MessageIn, client_id: str = Depends(require_client)) -> dict[str, Any]:
    hub = get_hub()
    _owned(hub, session_id, client_id)
    if not body.text.strip() and not body.attachments:
        raise HTTPException(422, "text or attachments required")
    try:
        await hub.start_turn(session_id, body.text.strip(), [a.model_dump() for a in body.attachments])
    except SessionBusyError:
        raise HTTPException(409, "a turn is already running in this session") from None
    except FileNotFoundError as exc:
        raise HTTPException(400, f"attachment not found: {exc}") from None
    return {"accepted": True}


@app.post("/api/sessions/{session_id}/files", status_code=201)
async def upload_files(
    session_id: str, files: list[UploadFile], client_id: str = Depends(require_client)
) -> list[dict[str, Any]]:
    hub = get_hub()
    _owned(hub, session_id, client_id)
    saved = []
    for upload in files:
        try:
            saved.append(await hub.save_file(session_id, upload.filename or "file", upload.file, upload.content_type))
        except ValueError as exc:
            raise HTTPException(413, str(exc)) from None
    return saved


def require_client_or_query(
    x_client_id: str | None = Header(default=None),
    authorization: str | None = Header(default=None),
    client_id: str | None = Query(default=None),
    token: str | None = Query(default=None),
) -> str:
    """Like require_client, but also accepts ?client_id=&token= so <img src> and links work."""
    bearer = authorization.removeprefix("Bearer ").strip() if authorization else token
    if not _token_ok(bearer):
        raise HTTPException(401, "invalid token")
    return _valid_client_id(x_client_id or client_id)


@app.get("/api/sessions/{session_id}/files/{path:path}")
async def get_file(session_id: str, path: str, client_id: str = Depends(require_client_or_query)) -> StreamingResponse:
    hub = get_hub()
    _owned(hub, session_id, client_id)
    try:
        stream = await hub.open_file(session_id, path)
    except FileNotFoundError:
        raise HTTPException(404, "file not found") from None
    return StreamingResponse(
        stream.chunks,
        media_type=stream.mime,
        headers={"Content-Length": str(stream.size), "Content-Disposition": f"inline; filename*=UTF-8''{quote(stream.name)}"},
    )


@app.websocket("/api/sessions/{session_id}/ws")
async def session_ws(
    websocket: WebSocket,
    session_id: str,
    client_id: str | None = Query(default=None),
    token: str | None = Query(default=None),
) -> None:
    hub = get_hub()
    record = hub.store.get(session_id)
    if not _token_ok(token) or not client_id or record is None or record.owner != client_id:
        await websocket.close(code=4404)
        return
    await websocket.accept()

    queue = hub.subscribe(session_id)
    await websocket.send_json({"type": "snapshot", "session": _session_view(hub, record, items=True)})

    async def pump() -> None:
        while True:
            await websocket.send_json(await queue.get())

    sender = asyncio.create_task(pump())
    try:
        while True:
            message = await websocket.receive_json()
            if message.get("type") != "prompt":
                continue
            text = str(message.get("text") or "").strip()
            attachments = [a for a in message.get("attachments") or [] if isinstance(a, dict)][:20]
            if not text and not attachments:
                continue
            try:
                await hub.start_turn(session_id, text, attachments)
            except SessionBusyError:
                await websocket.send_json({"type": "busy"})
            except FileNotFoundError as exc:
                await websocket.send_json({"type": "notice", "text": f"첨부파일을 찾을 수 없습니다: {exc}"})
            except KeyError:
                await websocket.send_json({"type": "deleted"})
    except WebSocketDisconnect:
        pass
    except Exception:  # noqa: BLE001 - malformed frames just drop this connection
        log.exception("websocket error")
    finally:
        sender.cancel()
        hub.unsubscribe(session_id, queue)


def main() -> None:
    import uvicorn

    logging.basicConfig(level=logging.INFO)
    uvicorn.run(
        "dsh_server.app:app",
        host=os.environ.get("DSH_SERVER_HOST", "127.0.0.1"),
        port=int(os.environ.get("DSH_SERVER_PORT", "8000")),
    )


if __name__ == "__main__":
    main()
