"""CLI: python -m dsh_server "prompt" [--session-id ID] [--workspace DIR]"""

from __future__ import annotations

import argparse
import json
import sys

from .agent import DshAgent
from .config import DshSettings
from .events import AgentEvent


def _print_event(event: AgentEvent) -> None:
    if event.kind == "tool_call":
        print(f"[tool] {event.tool_name} {json.dumps(event.arguments, ensure_ascii=False)}", file=sys.stderr)
    elif event.kind == "tool_result":
        flag = "error" if event.is_error else "ok"
        print(f"[tool:{flag}] {event.text[:500]}", file=sys.stderr)
    elif event.kind == "subagent_started":
        print(f"[subagent] started {event.session_id}", file=sys.stderr)


def main() -> None:
    parser = argparse.ArgumentParser(prog="dsh-agent")
    parser.add_argument("prompt")
    parser.add_argument("--session-id")
    parser.add_argument("--workspace")
    parser.add_argument("--profile")
    parser.add_argument("--model")
    parser.add_argument("--quiet", action="store_true", help="do not print tool activity")
    args = parser.parse_args()

    overrides = {k: v for k, v in {"workspace": args.workspace, "profile": args.profile, "model": args.model}.items() if v}
    with DshAgent(DshSettings.from_env(**overrides)) as agent:
        result = agent.run(args.prompt, session_id=args.session_id, on_event=None if args.quiet else _print_event)

    print(result.text)
    print(f"\n[session] {result.session_id} ({result.finish_reason})", file=sys.stderr)
    sys.exit(0 if result.ok else 1)


if __name__ == "__main__":
    main()
