# 1일 집중 과정 · 발표 덱·강의안 작성 규칙

시간표의 단일 소스는 `course_config.py`입니다. 시간·제목·산출물을 바꾼 뒤 아래 순서로 다시 생성합니다.

```bash
python3 practice/build_practice.py
python3 slides/build_decks.py
python3 slides/build_index.py
python3 instructor/build_sessions.py
python3 instructor/build_guide.py
python3 build_curriculum.py
```

## 운영 원칙

1. 과정은 1일 09:00–17:00, 순수 교육 370분입니다.
2. 모든 참가자가 같은 순서와 범위를 완주합니다. 과제를 별도 단계로 구분하지 않습니다.
3. 각 세션은 하나의 산출물로 닫고 다음 세션의 입력으로 이어 씁니다.
4. 발송은 본인에게만, 워크스페이스에는 비기밀 자료만, 승인 창은 읽고 누릅니다.
5. 지연 시 과제를 빼지 않습니다. 설명을 줄이고 예비 PC·짝 실습·동봉 대체 자료로 전환합니다.

## 발표 덱

- 00–15까지 세션당 7장으로 고정합니다.
- 순서: 표지 → 핵심 → 화면 → 전원 완주 순서 → 복사용 프롬프트 → 안전 확인 → 완료.
- 공통 스타일은 `../_assets/deck.css`, 동작은 `../_assets/deck.js`를 사용합니다.
- 덱 HTML 안에 별도 `<style>`을 넣지 않습니다.
- 프롬프트·완료 기준은 `practice/prompts/D1-NN-*.md`와 일치해야 합니다.
- 수정 뒤 `python3 ../_assets/shot.py slides/NN.*.html all <출력폴더>`로 1920×1080 전 장을 렌더링합니다.

## 강사용 강의안

세션 조각은 `instructor/build_sessions.py`가 `instructor/sessions/00.html`부터 `15.html`까지 생성하고, `instructor/build_guide.py`가 `instructor-guide.html`로 합칩니다. 각 세션에는 시간 배분, 실제 발표 대본, 실습 운영, 조교 체크포인트, 장애 대응, 지연 시 운영, 예상 질문이 있어야 합니다.

## 실습 자료

`practice/build_practice.py`가 세션별 안내 16개, 실습 허브, 체크리스트를 생성합니다. 실습 안내는 시작 전 확인 → 전원 완주 순서 → 복사용 프롬프트 → 완료 기준 → 장애 대응 → 다음 세션으로 넘길 것 순서입니다.

## 검증 기준

- 발표 덱 16개, 각 7장
- 강사용 세션 16개
- 실습 안내 16개
- 로컬 링크 오류 0건
- 세션 시간 합계 370분
- 이전 다일 과정 표기 0건
