#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""강사용 강의안 조립기.
sessions/NN.html 조각들을 읽어 instructor-guide.html 하나로 합칩니다. 조각을 고친 뒤 이 스크립트를 다시 실행하세요.
    python3 EDU-CLASS/02.SPICA-LEARN/instructor/build_guide.py
"""
import os, re, glob, html, datetime

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, 'instructor-guide.html')

CSS = r"""
:root{--ink:#344256;--mid:#677180;--soft:#858e9a;--faint:#c2c6cc;--line:#e1e3e6;--panel:#f4f6fa;--acc:#007fff;--warn:#b5680a;--warnbg:#fff6e5;--ok:#1a9d5e;
--brand:linear-gradient(90deg,#ebce14 0%,#fa5c96 25%,#48ade0 50%,#3fd98f 75%,#ebce14 100%)}
*{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth}
body{font-family:'Pretendard','Apple SD Gothic Neo','Malgun Gothic',system-ui,-apple-system,'Segoe UI',sans-serif;color:var(--ink);background:#fff;line-height:1.65;word-break:keep-all;-webkit-font-smoothing:antialiased;display:grid;grid-template-columns:280px 1fr;min-height:100vh}
a{color:var(--acc);text-decoration:none}a:hover{text-decoration:underline}
aside{position:sticky;top:0;height:100vh;overflow:auto;background:var(--panel);border-right:1px solid var(--line);padding:22px 18px;font-size:13.5px}
aside .logo{display:flex;align-items:center;gap:10px;font-weight:800;font-size:16px;margin-bottom:6px}
aside .logo i{width:22px;height:22px;border-radius:6px;background:linear-gradient(135deg,#ebce14,#fa5c96 40%,#48ade0 70%,#3fd98f)}
aside .sub{color:var(--soft);font-size:12px;margin-bottom:18px}
aside h5{font-size:11px;letter-spacing:.08em;color:var(--soft);margin:16px 0 6px;font-weight:700}
aside a{display:block;color:var(--mid);padding:5px 8px;border-radius:8px;line-height:1.35}
aside a:hover{background:#fff;text-decoration:none;color:var(--acc)}
aside a b{color:var(--acc);font-variant-numeric:tabular-nums;margin-right:6px}
aside a small{display:block;color:var(--faint);font-size:11px}
main{padding:0 0 80px}
.brandbar{height:6px;background:var(--brand)}
.wrap{max-width:980px;margin:0 auto;padding:0 40px}
header.top{padding:48px 0 36px;border-bottom:1px solid var(--line)}
.kicker{font-size:13px;font-weight:700;color:var(--acc);letter-spacing:.04em}
h1{font-size:40px;font-weight:800;letter-spacing:-.035em;line-height:1.15;margin-top:10px}
.lead{font-size:17px;color:var(--mid);margin-top:14px;max-width:760px}
.overview{padding:36px 0;border-bottom:1px solid var(--line)}
.overview h2{font-size:24px;font-weight:800;letter-spacing:-.03em;margin-bottom:14px}
.overview h3{font-size:16px;margin:24px 0 8px;color:var(--soft)}
.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px;margin-top:14px}
.card{border-radius:14px;padding:18px;background:#fff;box-shadow:inset 0 0 0 1px var(--line);font-size:14px}
.card b{display:block;font-size:15px;margin-bottom:6px}
.card.warn{background:var(--warnbg);box-shadow:inset 0 0 0 1px #f0c47a;color:var(--warn)}
section.session{padding:44px 0;border-bottom:1px solid var(--line)}
section.session header .k{font-size:13px;font-weight:700;color:var(--acc);letter-spacing:.04em}
section.session h2{font-size:30px;font-weight:800;letter-spacing:-.03em;line-height:1.2;margin-top:6px}
section.session .goal{margin-top:12px;font-size:16px;color:var(--mid);background:var(--panel);border-radius:12px;padding:12px 16px}
section.session .goal b{color:var(--ink)}
section.session .links{display:flex;flex-wrap:wrap;gap:8px;margin-top:12px}
section.session .links a{display:inline-flex;align-items:center;height:32px;padding:0 12px;border-radius:16px;background:#fff;box-shadow:inset 0 0 0 1px var(--line);font-size:13px;font-weight:600}
section.session .links a:hover{text-decoration:none;box-shadow:inset 0 0 0 1px var(--acc)}
section.session h3{font-size:18px;font-weight:800;margin:32px 0 10px;letter-spacing:-.02em;display:flex;align-items:center;gap:10px}
section.session h3::before{content:"";width:22px;height:4px;background:var(--acc);border-radius:2px}
table.tt{width:100%;border-collapse:collapse;font-size:14px}
table.tt th{text-align:left;font-size:11.5px;font-weight:700;color:var(--soft);letter-spacing:.04em;padding:8px 10px;border-bottom:2px solid var(--line)}
table.tt td{padding:9px 10px;border-bottom:1px solid var(--line);vertical-align:top}
table.tt td:first-child{white-space:nowrap;color:var(--soft);font-variant-numeric:tabular-nums}
.script h4{font-size:16px;font-weight:700;margin:22px 0 8px;letter-spacing:-.01em}
.script h4 em{font-style:normal;font-weight:600;color:var(--soft);font-size:13px;margin-left:8px}
.script blockquote{border-left:4px solid var(--acc);background:#fff;padding:12px 18px;border-radius:0 12px 12px 0;font-size:15.5px;line-height:1.75;box-shadow:inset 0 0 0 1px var(--line)}
.script blockquote b{color:var(--acc)}
.script p.tip{margin-top:8px;font-size:13.5px;color:var(--warn);background:var(--warnbg);border-radius:10px;padding:8px 12px}
.script p.tip::before{content:"발표 팁 · ";font-weight:700}
ul.check{list-style:none;display:flex;flex-direction:column;gap:6px;font-size:14.5px}
ul.check li{padding-left:28px;position:relative}
ul.check li::before{content:"";position:absolute;left:0;top:5px;width:16px;height:16px;border:2px solid var(--acc);border-radius:4px}
dl.qa dt{font-weight:700;margin-top:12px;font-size:15px}dl.qa dt::before{content:"Q · ";color:var(--acc)}
dl.qa dd{color:var(--mid);font-size:14.5px;margin-top:2px;padding-left:22px}
section.session > p{font-size:15px;color:var(--mid)}
.daytag{display:inline-block;font-size:11px;font-weight:800;letter-spacing:.06em;color:#fff;background:var(--ink);border-radius:6px;padding:2px 8px;margin-right:8px;vertical-align:middle}
.toolbar{position:fixed;right:18px;bottom:16px;display:flex;gap:8px;z-index:5}
.toolbar button{height:38px;padding:0 14px;border-radius:19px;border:1px solid var(--line);background:#fff;font:inherit;font-size:13px;font-weight:700;color:var(--mid);cursor:pointer;box-shadow:0 4px 14px rgba(0,0,0,.08)}
.toolbar button:hover{color:var(--acc);border-color:var(--acc)}
@media (max-width:900px){body{grid-template-columns:1fr}aside{position:static;height:auto}}
@media print{body{display:block}aside,.toolbar{display:none}section.session{break-before:page;padding:20px 0}.wrap{max-width:none;padding:0 10px}h1{font-size:28px}section.session h2{font-size:22px}.script blockquote{font-size:13px}table.tt{font-size:12px}}
"""

OVERVIEW = r"""
<div class="overview"><div class="wrap">
  <h2>운영 개요</h2>
  <div class="cards">
    <div class="card"><b>편성</b>1일 · 09:00–17:00 · 순수 교육 370분 · 16개 마이크로 세션 · 정원 20명 (강사 1 + 조교 1)</div>
    <div class="card"><b>수료 기준</b>세션별 실습 전 과정 + 개인 스킬 1건 · 동료 스킬 실행 1건 · 적용 계획 제출 — <a href="../practice/worksheets/practice-checklist.md">체크리스트</a></div>
    <div class="card"><b>실습 데이터</b>가상 회사 가온테크(주) 경영지원본부. 참가자 본인 역할은 경영기획팀 홍길동. <a href="../practice/data/README.md">정답표</a></div>
    <div class="card warn"><b>세 가지 규칙</b>① 메일 받는 사람 본인 고정 · 결재 상신 금지 ② 워크스페이스에 비기밀만 ③ 승인 창은 읽고 누른다</div>
  </div>
  <h3>강사 · 조교 역할</h3>
  <table class="tt">
    <tr><th>때</th><th>강사</th><th>조교</th></tr>
    <tr><td>강의</td><td>대본대로. 시간을 지키고 질문은 세션 끝 Q&amp;A 나 문의 경로로</td><td>출석 · 인쇄물 · 안 되는 PC 붙잡기 (강사는 붙지 않음)</td></tr>
    <tr><td>실습</td><td>앞에서 시연 · 전체 공지 · 잘 된 결과 공유</td><td>순회 · 체크포인트 손 들기 확인 · 한계 사례 취합 시트</td></tr>
    <tr><td>세션 00 · 04 · 08</td><td>예정대로 시작</td><td><b>전원 상태 눈으로 확인</b> — 로그인 · 나스카 · 익스텐션 연결</td></tr>
    <tr><td>세션 06 · 12</td><td>규칙을 소리 내어 읽힘 · 결재는 시연만</td><td>발송 승인 창의 "받는 사람" 이 본인인지 순회 확인</td></tr>
  </table>
  <h3>지연 시 운영</h3>
  <table class="tt">
    <tr><th>상황</th><th>강사</th><th>조교</th></tr>
    <tr><td>개인 PC 장애</td><td>수업을 계속 진행</td><td>예비 PC 또는 짝 실습으로 즉시 전환</td></tr>
    <tr><td>공통 서비스 장애</td><td>원인을 한 번 설명하고 로컬 대체 자료로 전환</td><td>전원 상태를 같은 시작점으로 맞춤</td></tr>
    <tr><td>종료 3분 전</td><td>새 작업 중단 · 저장 안내</td><td>산출물을 눈으로 확인하고 미완료자 표시</td></tr>
    <tr><td colspan="3"><b>모든 참가자가 같은 과정을 수행합니다.</b> 설명 시간을 줄여 실습 시작 시각을 지킵니다.</td></tr>
  </table>
  <h3>준비물 (담당 · 기한)</h3>
  <table class="tt">
    <tr><th>항목</th><th>담당</th><th>기한</th></tr>
    <tr><td>참가자 PC 설치 · 로그인 · <b>나스카 로그인</b> 사전 안내</td><td>교육 운영</td><td>3일 전</td></tr>
    <tr><td>조회 전용 계정 (컨플루언스 · 모자익) · 실습 페이지 "AX 추진 로드맵 v2"</td><td>시스템 담당</td><td>1주 전</td></tr>
    <tr><td><b>녹스 실습용 비실명 계정</b></td><td>시스템 담당</td><td>1주 전</td></tr>
    <tr><td>WebMCP 샘플 사이트 2종 · Replay+ 샘플 루틴 (없으면 <a href="../practice/sample-sites/room-reservation/index.html">동봉 샘플</a>)</td><td>제품팀</td><td>1주 전</td></tr>
    <tr><td>반입 금지 자료 목록 (세션 04 슬라이드 반영)</td><td>정보보호</td><td>2주 전</td></tr>
    <tr><td>팀 스페이스 사전 생성 권한</td><td>포털 관리자</td><td>3일 전</td></tr>
    <tr><td>적용 계획 워크시트 인쇄 (정원 + 5부) · 실습 README 인쇄</td><td>교육 운영</td><td>전일</td></tr>
  </table>
  <h3>발표 화면 조작</h3>
  <p style="font-size:14px;color:var(--mid)">덱은 브라우저로 엽니다. ← → Space 이동 · <b>O</b> 전체 보기 · <b>F</b> 전체 화면 · <b>P</b> 인쇄(PDF) · Esc 닫기. 화면 크기에 맞춰 자동 배율. 슬라이드의 화면 그림은 목업이며 실제 스크린샷으로 교체 예정입니다 — 청중이 물으면 한 마디로 넘기세요.</p>
</div></div>
"""

def main():
    frags = sorted(glob.glob(os.path.join(HERE, 'sessions', '[0-9][0-9].html')))
    nav, body = [], []
    day_seen = set()
    for f in frags:
        s = open(f, encoding='utf-8').read()
        m = re.search(r'<section class="session" id="(s\d\d)" data-day="(\d)" data-title="([^"]+)" data-time="([^"]+)"', s)
        if not m:
            print('skip (no header):', f); continue
        sid, day, title, time = m.groups()
        if day not in day_seen:
            nav.append('<h5>1일 집중 과정</h5>'); day_seen.add(day)
        num, name = title.split('.', 1)
        nav.append(f'<a href="#{sid}"><b>{html.escape(num)}</b>{html.escape(name.strip())}<small>{html.escape(time)}</small></a>')
        s = s.replace('<div class="k">', '<div class="k"><span class="daytag">1 DAY</span>', 1)
        s = s.replace('href="../../', 'href="../')
        body.append(s)
    page = ('<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
            '<title>SPICA 실무 과정 · 강사용 강의안</title><style>' + CSS + '</style></head><body>'
            '<aside><div class="logo"><i></i>강사용 강의안</div><div class="sub">SPICA 실무 과정 · 1일 집중</div>'
            '<a href="#top">운영 개요</a>' + ''.join(nav) +
            '<h5>자료</h5><a href="../curriculum.html">커리큘럼 페이지</a><a href="../slides/index.html">발표 덱 목록</a><a href="../practice/index.html">실습 자료</a><a href="../practice/worksheets/practice-checklist.md">실습 체크리스트</a></aside>'
            '<main id="top"><div class="brandbar"></div><header class="top"><div class="wrap"><div class="kicker">EDU-CLASS · 02.SPICA-LEARN · 강사용</div>'
            '<h1>SPICA 1일 집중 과정 강의안</h1><p class="lead">세션마다 분 단위 시간 배분, 실제로 말할 대본, 시연 순서, 조교 체크포인트, 흔한 문제와 조치, 지연 대응, 예상 질문. '
            '대본은 그대로 읽어도 되고 자기 말로 바꿔도 됩니다 — 다만 <b>⚠ 표시된 주의와 시간</b>은 지키세요.</p></div></header>'
            + OVERVIEW + '<div class="wrap">' + '\n'.join(body) + '</div></main>'
            '<div class="toolbar"><button onclick="window.print()">인쇄 · PDF</button><button onclick="window.scrollTo({top:0,behavior:\'smooth\'})">맨 위로</button></div>'
            f'<!-- built {datetime.datetime.now():%Y-%m-%d %H:%M} from {len(body)} fragments --></body></html>')
    open(OUT, 'w', encoding='utf-8').write(page)
    print(f'wrote {OUT} ({len(body)} sessions)')

if __name__ == '__main__':
    main()
