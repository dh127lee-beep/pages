#!/usr/bin/env python3
"""course_config.py에서 1일 과정용 세션 강의안 조각 16개를 생성한다."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from course_config import SESSIONS  # noqa: E402

PROMPTS = {
    "00": "../../practice/prompts/D1-00-orientation-login.md",
    **{s["num"]: f'../../practice/prompts/D1-{s["num"]}-{s["slug"].replace("DESKTOP-", "").replace("EXTENSION-", "").replace("PORTAL-", "")}.md' for s in SESSIONS if s["num"] != "00"},
}
PROMPTS.update({
    "01":"../../practice/prompts/D1-01-install-setup-wizard.md", "02":"../../practice/prompts/D1-02-basic-chat-profile.md",
    "03":"../../practice/prompts/D1-03-web-search-approval.md", "04":"../../practice/prompts/D1-04-local-docs-workspace.md",
    "05":"../../practice/prompts/D1-05-agents-md-roleplay.md", "06":"../../practice/prompts/D1-06-knox-integration.md",
    "07":"../../practice/prompts/D1-07-scheduled-task.md", "08":"../../practice/prompts/D1-08-extension-setup.md",
    "09":"../../practice/prompts/D1-09-page-context-work.md", "10":"../../practice/prompts/D1-10-webmcp.md",
    "11":"../../practice/prompts/D1-11-replay-plus.md", "12":"../../practice/prompts/D1-12-end-to-end.md",
    "13":"../../practice/prompts/D1-13-skill-artifact.md", "14":"../../practice/prompts/D1-14-team-space.md",
    "15":"../../practice/prompts/D1-15-bluenote-action-plan.md",
})

def form_parts(form, mins):
    if "+" not in form:
        return mins, 0
    nums = [int(x.split()[-1]) for x in form.replace("안내", "강의").replace("작성", "practice").split("+")]
    return nums[0], nums[1]

def render(s):
    lecture, practice = form_parts(s["form"], s["mins"])
    save = 1 if 0 < practice <= 5 else 3
    finish = s["mins"] - save
    middle = max(lecture, 1)
    prompt = PROMPTS[s["num"]]
    practice_row = "" if practice == 0 else f'''\n  <h3>실습 운영</h3>
  <table class="tt">
    <tr><th>분</th><th>참가자</th><th>강사 · 조교</th></tr>
    <tr><td>{middle}–{min(middle+2, finish)}</td><td>강사 시연을 보고 시작 상태 맞추기</td><td>강사: 한 번만 시연 · 조교: 뒤쪽부터 순회</td></tr>
    <tr><td>{min(middle+2, finish)}–{finish}</td><td>{s['practice']}</td><td>조교: {s['check']}</td></tr>
    <tr><td>{finish}–{s['mins']}</td><td>저장 · 완료 화면을 조교에게 보여 주기</td><td>새 작업 시작 금지 · 미완료자 바로 표시</td></tr>
  </table>'''
    return f'''<!-- build_sessions.py가 생성한 1일 과정 세션 조각 -->
<section class="session" id="s{s['num']}" data-day="1" data-title="{s['num']}. {s['title']}" data-time="{s['time']} · {s['mins']}분 · {s['form']}">
  <header>
    <div class="k">1일 집중 · {s['time']} · {s['mins']}분 · {s['form']}</div>
    <h2>{s['num']}. {s['title']}</h2>
    <p class="goal"><b>목표</b> — {s['goal']}. <b>산출물</b> — {s['output']}.</p>
    <div class="links"><a href="../../slides/{s['num']}.{s['slug']}.html">발표 슬라이드</a><a href="{prompt}">실습 안내</a><a href="../../curriculum.md#2-하루-시간표">하루 시간표</a></div>
  </header>

  <h3>시간 배분</h3>
  <table class="tt">
    <tr><th>분</th><th>무엇을</th><th>완료 기준</th></tr>
    <tr><td>0–{middle}</td><td>핵심 개념 · 화면 시연 · 안전 규칙</td><td>실습 시작 화면까지 함께 이동</td></tr>
    <tr><td>{middle}–{finish}</td><td>전원 동일 실습</td><td>{s['check']}</td></tr>
    <tr><td>{finish}–{s['mins']}</td><td>저장 · 산출물 확인 · 다음 세션 연결</td><td>{s['output']}</td></tr>
  </table>

  <h3>발표 대본</h3>
  <div class="script">
    <h4>슬라이드 1 · 목표 <em>(1분)</em></h4>
    <blockquote>이번 세션의 목표는 <b>{s['goal']}</b>입니다. 설명을 듣는 것으로 끝내지 않고 <b>{s['output']}</b>을 화면에 남기고 넘어갑니다.</blockquote>
    <h4>슬라이드 2–4 · 핵심과 시연 <em>({max(lecture-1, 1)}분)</em></h4>
    <blockquote>{s['talk']}</blockquote>
    <p class="tip">실습 안내를 열고 시작 화면까지만 시연합니다. 참가자의 클릭을 기다리며 설명하지 않습니다.</p>
    <h4>실습 시작 · 한 문장 <em>(30초)</em></h4>
    <blockquote>지금부터 화면의 순서 그대로 진행합니다. 모두 같은 범위를 끝냅니다. 막히면 같은 동작을 반복하지 말고 손을 들어 주세요.</blockquote>
  </div>{practice_row}

  <h3>조교 체크포인트</h3>
  <ul class="check"><li>{s['check']}</li><li>종료 3분 전 새 작업을 멈추고 산출물을 저장했는지 확인</li><li>대체 자료를 쓴 경우 체크리스트 비고에 기록</li></ul>

  <h3>흔한 문제</h3>
  <table class="tt"><tr><th>증상</th><th>즉시 조치</th></tr><tr><td>예상 화면이나 결과가 나오지 않음</td><td>{s['issue']}</td></tr><tr><td>시간 안에 끝내기 어려움</td><td>범위를 빼지 않고 예비 PC 또는 짝 실습으로 같은 과정을 이어서 완료</td></tr></table>

  <h3>밀릴 때</h3>
  <p>모든 참가자가 같은 과정을 끝까지 수행합니다. 강사는 설명을 줄이고 실습 시작 시각을 지킵니다. 공통 장애는 전체에 한 번만 안내하고 조교가 개별 조치합니다.</p>

  <h3>예상 질문</h3>
  <dl class="qa"><dt>완료했는지는 무엇으로 확인하나요?</dt><dd>{s['check']}을 조교에게 보여 주면 됩니다.</dd><dt>실제 업무 자료로 바로 해도 되나요?</dt><dd>오늘은 동봉된 더미 자료로 전 과정을 익힙니다. 현업 적용은 정보 등급과 권한을 확인한 뒤 시작합니다.</dd></dl>
</section>'''

def main():
    out = Path(__file__).parent / "sessions"
    out.mkdir(exist_ok=True)
    for s in SESSIONS:
        (out / f"{s['num']}.html").write_text(render(s), encoding="utf-8")
    print(f"sessions: {len(SESSIONS)} files")

if __name__ == "__main__":
    main()
