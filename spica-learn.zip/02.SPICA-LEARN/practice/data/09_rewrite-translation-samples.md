# 실습 1 원문 모음 — 메시지 다듬기 · 메일 다듬기 · 번역

> 아래 원문은 일부러 거칠게 써 두었습니다. SPICA에게 "다듬어 달라"고 시키는 재료입니다.
> 사실(날짜 · 숫자 · 이름)은 바꾸지 말고 톤만 바꾸는 것이 과제입니다.

## A. 메신저 메시지 (팀장에게)

### A-1
```
경비 정산 마감 내일인데 아직 3명 안 냈어요 빨리 좀 내라고 해주세요
```

### A-2
```
회의실 7층 B 내일 2시 잡아놨는데 영업팀이 먼저 쓴다고 우기네요 어떻게 하죠
```

### A-3 (동료에게)
```
주간보고 양식 바뀐거 알지? 지연항목 칸 꼭 채워 안채우면 다시 돌려보냄
```

## B. 메일 초안

### B-1 협력사에 보내는 메일 (단가표 확인 요청)
```
가온소재 담당자님

지난번에 말씀드린 단가표요 아직 안 왔는데요
9월 20일 계약 끝나는거라 그 전에 받아야 해서요
3.2% 인하 반영된 버전으로 이번주까지 부탁드려요

홍길동
```

### B-2 전 직원 공지 (교육 안내)
```
제목: 교육

9/3 하루 동안 SPICA 교육이 있습니다. 7층 교육장이며 노트북을 가져오세요.
나스카 로그인 안되어있으면 실습 못하니까 전날 확인하시고
점심은 제공됩니다
```

## C. 번역

### C-1 영어 → 한국어 (해외 협력사 메일)
```
Subject: Q4 pricing and contract renewal

Dear Mr. Hong,

Thank you for the productive call last week. As discussed, we are able to offer a 3.2% reduction on the current unit price for office consumables, effective from the renewal date of September 21, 2026.

Please note that this offer is contingent on a minimum annual order volume of KRW 36,000,000. Should the volume fall below this threshold, the standard price list will apply.

We would appreciate your confirmation by September 12 so that we can prepare the renewed agreement in time.

Best regards,
Sarah Kim
Account Manager, Gaon Materials Co.
```

### C-2 한국어 → 영어 (해외 법인에 보내는 짧은 공지)
```
안녕하세요, 경영기획팀 홍길동입니다.

9월 15일부터 출장비 정산 기한이 복귀 후 7일로 통일됩니다.
기한이 지나면 다음 달 정산으로 넘어가니 영수증을 미리 챙겨 주세요.
문의는 총무팀 이서연 대리에게 부탁드립니다.

감사합니다.
```

## D. 자유 소재 (원하는 사람만)
- 오늘 아침 실제로 보낸 메시지 하나를 붙여 넣고 "더 짧게 · 더 정중하게 · 영어로" 세 가지 버전을 받아 보세요.
- 단, 실명 · 계좌 · 주민번호 · 미공개 숫자는 지우고 붙이세요.
