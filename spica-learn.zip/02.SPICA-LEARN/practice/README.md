# 실습 자료 — SPICA 1일 집중 과정

이 폴더를 참가자에게 통째로 배포합니다. 모든 참가자가 같은 순서와 범위를 수행하며, 각 세션 산출물은 다음 세션에서 이어 씁니다.

- `prompts/`: 세션별 전원 완주 순서·복사용 프롬프트·완료 기준
- `data/`: 가온테크(주) 더미 문서와 정답표
- `sample-sites/`: WebMCP·Replay+·E2E용 로컬 HTML
- `AGENTS-md/`: 업무 규칙 예제
- `worksheets/`: 실습 체크리스트와 현업 적용 계획

## 세 가지 규칙

1. 메일 받는 사람은 본인 계정으로 고정하고 결재 상신은 하지 않습니다.
2. 워크스페이스에는 실습 데이터와 비기밀 자료만 넣습니다.
3. 승인 창의 받는 사람·경로·실행 내용을 읽고 승인합니다.

브라우저 허브는 [index.html](index.html), 전체 시간표는 [../curriculum.md](../curriculum.md), 강사용 진행안은 [../instructor/instructor-guide.html](../instructor/instructor-guide.html)입니다.
