#!/usr/bin/env python3
"""1일 과정 실습 안내·허브·체크리스트를 단일 완주 동선으로 생성한다."""
from pathlib import Path
import sys, html

ROOT=Path(__file__).resolve().parents[1]; HERE=Path(__file__).parent
sys.path.insert(0,str(ROOT))
from course_config import SESSIONS, BY_NUM  # noqa: E402

DATA={
"00":dict(file="포털·나스카", steps=["포털에 로그인해 오른쪽 위 사용자 이름 확인","나스카에 로그인해 사내 문서 한 건 열기","세 가지 안전 규칙을 함께 읽기","두 화면을 조교에게 보여 주기"], prompt="포털과 나스카 로그인을 확인합니다.\n포털 홈의 사용자 이름과 사내 문서 열람 화면을 열고\n오늘 지킬 안전 규칙 세 가지를 함께 읽은 뒤\n완료 화면을 조교에게 보여 주세요.", expected="포털 사용자 이름과 사내 문서 열람 화면"),
"01":dict(file="설치 없음", steps=["Desktop을 실행하고 포털 계정으로 로그인","Setup Wizard의 사내망 연결·인증서·도구 상태를 끝까지 확인","완료 화면을 조교에게 보여 주고 첫 대화를 실행"], prompt="오늘 실습에서 내가 지켜야 할 안전 규칙 세 가지를 짧게 알려 줘.", expected="Desktop 홈, Setup Wizard 완료, 첫 응답"),
"02":dict(file="data/09_rewrite-translation-samples.md", steps=["원문 모음에서 메신저 문장 하나를 선택","대상·말투·길이를 지정해 다듬기","설정에서 내 역할·답변 기준을 메인 에이전트 프로필로 저장"], prompt="아래 메시지를 팀 메신저에 맞게 다듬어 줘.\n- 대상: 같은 팀 동료\n- 말투: 정중하지만 짧게\n- 길이: 3문장 이내\n- 일정·장소·준비물은 빠뜨리지 말 것\n\n[원문 붙여 넣기]", expected="다듬은 메시지 1건과 저장된 프로필"),
"03":dict(file="웹", steps=["승인 모드를 '물어보기'로 설정","오늘 기준 최신 정보 1건을 검색해 날짜·출처 링크가 있는 표로 정리","결과를 workspace에 저장하면서 승인 창의 경로와 작업을 읽고 승인"], prompt="오늘 기준 생성형 AI 관련 주요 뉴스 3건을 찾아\n제목, 발표일, 핵심 한 줄, 원문 링크 표로 정리해 줘.\n검색 기준 시각을 맨 위에 쓰고 workspace에 news-check.md로 저장해 줘.", expected="출처 표와 파일 저장 승인 경험"),
"04":dict(file="data/ 폴더 전체", steps=["나스카 로그인 후 데이터 폴더 전체를 워크스페이스로 열기","PDF·PPT·xlsx·docx에 각각 한 번 질문","W36 주간보고 2건을 담당·기한·지연 여부 표로 취합","weekly-report-summary_W36.docx로 저장"], prompt="03_weekly-report_corporate-planning_W36과\n04_weekly-report_hr_W36을 읽고\n완료·진행·지연 항목을 담당자와 기한이 있는 표로 취합해 줘.\n근거 파일명을 마지막 열에 쓰고 weekly-report-summary_W36.docx로 저장해 줘.", expected="문서 4종 질의와 취합 Word 파일"),
"05":dict(file="AGENTS-md/AGENTS.md", steps=["예제 AGENTS.md를 워크스페이스 루트에 복사","내 부서 역할과 검토 기준으로 수정","같은 아이디어를 규칙 적용 전후로 검토","세 페르소나 자동 토론 결과를 결론 3줄로 저장"], prompt="우리 팀의 월간 업무 개선 아이디어로 '보고서 자동 취합'을 검토해 줘.\nAGENTS.md의 세 관점으로 토론하고\n합의점, 반대 이유, 다음 행동을 각각 한 줄로 정리해 줘.", expected="AGENTS.md와 자동 토론 결과"),
"06":dict(file="세션 04의 weekly-report-summary_W36.docx", steps=["녹스 실습용 비실명 계정 연결","취합 문서를 5줄로 요약","받는 사람을 본인 하나로 지정","승인 창에서 주소를 확인하고 발송·수신 확인"], prompt="weekly-report-summary_W36.docx를 5줄로 요약해\n제목 '[실습] W36 주간보고 취합'으로 메일을 작성해 줘.\n받는 사람은 내 계정 하나만 지정하고\n발송 직전에 반드시 내 확인을 받아.", expected="본인 계정으로 수신한 메일 1건"),
"07":dict(file="data/06_vendor-contracts.xlsx", steps=["예약 작업 메뉴에서 새 작업 생성","매일 오전 9시 계약 만료 점검으로 등록","등록 직후 '지금 실행'","대기→진행→평가와 결과 확인"], prompt="매일 오전 9시에 협력사 계약현황을 확인해서\n30일 이내 만료이면서 자동갱신이 아닌 계약을 표로 정리해 줘.\n결과는 대시보드에 남겨 줘. 등록 후 지금 실행으로 시험해 줘.", expected="예약 작업 1건과 첫 실행 결과"),
"08":dict(file="Chrome·SPICA Extension", steps=["Chrome에서 SPICA Extension 설치 상태 확인","Extension을 열고 Desktop 연결 표시 확인","현재 탭 접근 상태 확인","제출·발송 전 멈춤 설정을 읽고 조교에게 화면 제시"], prompt="Chrome에서 SPICA Extension을 열고\nDesktop 연결 상태와 현재 탭 접근 상태를 확인합니다.\n제출·발송 앞에서는 멈추도록 설정을 확인하고\n완료 화면을 조교에게 보여 주세요.", expected="Extension 아이콘, Desktop 연결, 현재 탭 접근 상태"),
"09":dict(file="컨플루언스 실습 페이지", steps=["요약할 페이지 탭을 활성화","Extension 사이드 패널 열기","핵심 5줄과 의사결정·담당·기한 표 요청","페이지 근거와 결과 대조"], prompt="지금 보고 있는 페이지를 핵심 5줄로 요약하고,\n의사결정 · 담당자 · 기한을 표로 정리해 줘.\n각 항목 옆에 페이지의 근거 문구를 짧게 붙여 줘.", expected="현재 페이지에 근거한 요약과 표"),
"10":dict(file="sample-sites/room-reservation/index.html", steps=["같은 조건을 WebMCP 없이 화면 클릭으로 예약","예약 취소 후 WebMCP 도구로 같은 조건 재예약","두 방식의 시간·단계 수·성공 여부 기록","도구 호출 로그와 승인 창 확인"], prompt="내일 14:00, 7층, 6인 회의실을 먼저 화면 클릭으로 예약해 줘.\n완료 후 취소하고 같은 조건을 WebMCP 도구로 다시 예약해 줘.\n두 방식의 시간, 단계 수, 성공 여부를 표로 비교해 줘.", expected="두 방식 비교표와 도구 호출 로그"),
"11":dict(file="sample-sites/purchase-request/index.html", steps=["Replay+ 녹화 시작 후 구매요청 1건 수행","품목·수량·납기를 실행 변수로 일반화","다른 값으로 재생해 제출 직전 확인","검증 성공 후 개인 루틴으로 저장"], prompt="구매요청 등록 과정을 Replay+로 기록해 줘.\n품목, 수량, 납기일은 실행할 때 묻게 만들고\n제출 직전에는 반드시 멈춰 확인을 받아.\n다른 값으로 검증한 뒤 개인 루틴으로 저장해 줘.", expected="검증된 개인 Replay+ 루틴 1건"),
"12":dict(file="구매요청 사이트·다운로드 CSV·녹스", steps=["구매요청 사이트에서 경비 명세 CSV 다운로드","Desktop으로 부서별 집행률과 초과 부서 보고서 생성","받는 사람 본인 확인 후 녹스 메일 발송","실행 대시보드에서 전체 단계와 결과 확인"], prompt="구매요청 페이지에서 경비 명세 CSV를 내려받고,\n부서별 집행률과 초과 부서 원인을 표로 분석한 보고서를 만들어 줘.\n보고서는 내 계정으로만 메일 발송하고 발송 전에 확인받아.\n완료 후 전체 실행 단계를 대시보드로 보여 줘.", expected="다운로드 CSV, 보고서, 본인 메일, 실행 대시보드"),
"13":dict(file="세션 04 취합 문서 또는 세션 11 루틴", steps=["포털 스킬 작업실에서 기존 절차 하나 선택","언제 쓰는지·입력·순서·확인 기준 작성","개인 범위로 발행","Desktop 새 대화에서 이름 없이 요청해 자동 호출 확인"], prompt="오늘 만든 주간보고 취합 절차를 개인 스킬로 만들어 줘.\n입력은 W36 주간보고 문서들이고,\n결과는 담당·기한·지연·근거 파일이 있는 Word 표야.\n저장 전 누락 문서와 출력 파일명을 확인하게 해 줘.", expected="발행된 개인 스킬과 자동 호출 결과"),
"14":dict(file="세션 13 개인 스킬", steps=["옆자리와 2인 1조, 한 명이 팀 스페이스 생성","상대에게 편집 권한 부여","각자 개인 스킬을 팀에 업로드","서로의 스킬을 설치하고 이름 없이 실행"], prompt="옆 사람이 올린 스킬을 설치한 뒤 새 대화에서\n스킬 이름을 말하지 않고 해당 업무를 요청해 봅니다.\n실행 결과와 필요한 입력 파일을 서로 확인하고\n완료 화면을 조교에게 보여 주세요.", expected="팀 업로드와 동료 스킬 설치·실행"),
"15":dict(file="worksheets/application-plan-worksheet.docx", steps=["오늘 대화·결정·프롬프트를 블루 노트로 정리","다음 주 실행할 실제 업무 3건 작성","각 업무의 입력·결과·성공 기준·첫 날짜·권한 작성","워크시트 저장 또는 제출"], prompt="다음 주 SPICA로 실행할 업무 3건을 적습니다.\n각 업무마다 입력 자료, 실행 동사, 결과 형식,\n성공 기준, 첫 실행 날짜, 필요한 권한을 채우고\n작성한 워크시트를 제출해 주세요.", expected="블루 노트 기록과 제출된 적용 계획"),
}

def prompt_name(s):
    return next((p.name for p in (HERE/'prompts').glob(f"D1-{s['num']}-*.md")), '')

def render_prompt(s,d):
    steps='\n'.join(f"{i}. {v}" for i,v in enumerate(d['steps'],1))
    return f'''# D1-{s['num']} · {s['title']}

| 시간 | 실습 | 산출물 | 사용 자료 |
| --- | ---: | --- | --- |
| {s['time']} | {s['form']} | **{s['output']}** | `{d['file']}` |

## 시작 전 확인

- 앞 세션 산출물을 저장했습니다.
- 실습 안내와 대상 화면을 열었습니다.
- 메일·제출·저장 승인 창에서는 대상과 경로를 읽습니다.

## 전원 완주 순서

{steps}

## 복사용 프롬프트

```
{d['prompt']}
```

## 완료 기준

- [ ] {d['expected']}
- [ ] 결과를 저장하고 조교에게 화면을 보여 줌

## 잘 안 될 때

{s['issue']} 그래도 해결되지 않으면 같은 동작을 반복하지 말고 손을 듭니다. 조교는 동봉 자료·예비 PC·짝 실습 중 하나로 같은 과정을 이어 가게 합니다.

## 다음 세션으로 넘길 것

`{s['output']}`을 저장합니다. 다음 세션에서 다시 쓰는 경우 파일명이나 스킬 이름을 바꾸지 않습니다.
'''

def render_index():
    cards=[]
    for s in SESSIONS:
        link=f"prompts/{prompt_name(s)}"
        cards.append(f'<article class="card"><div class="n">{s["time"]} · {s["mins"]}분</div><h3>{s["num"]} {html.escape(s["title"])}</h3><p>{html.escape(s["practice"])}</p><a href="{link}">실습 안내</a></article>')
    return f'''<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>SPICA 1일 집중 과정 · 실습</title><style>:root{{--ink:#344256;--mid:#677180;--soft:#858e9a;--line:#e1e3e6;--panel:#f4f6fa;--acc:#007fff;--brand:linear-gradient(90deg,#ebce14,#fa5c96 25%,#48ade0 50%,#3fd98f 75%,#ebce14)}}*{{box-sizing:border-box}}body{{margin:0;font-family:'Pretendard','Apple SD Gothic Neo','Malgun Gothic',system-ui,sans-serif;color:var(--ink);line-height:1.55;word-break:keep-all}}.brand{{height:6px;background:var(--brand)}}.wrap{{max-width:1100px;margin:auto;padding:42px 24px 80px}}.kicker{{font-size:13px;font-weight:800;color:var(--acc)}}h1{{font-size:38px;margin:8px 0}}.lead{{color:var(--mid);max-width:800px}}.rules{{margin-top:20px;padding:16px 18px;border-radius:14px;background:#fff6e5;border:1px solid #f0c47a}}h2{{font-size:22px;margin:38px 0 12px}}.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:12px}}.card{{border:1px solid var(--line);border-radius:14px;padding:18px}}.n{{font-size:12px;color:var(--soft);font-weight:700}}.card h3{{font-size:16px;margin:5px 0}}.card p{{font-size:13px;color:var(--mid)}}a{{color:var(--acc);text-decoration:none;font-size:13px;font-weight:700}}.links{{display:flex;gap:12px;flex-wrap:wrap;padding:18px;border-radius:14px;background:var(--panel)}}</style></head><body><div class="brand"></div><main class="wrap"><div class="kicker">EDU-CLASS · 02.SPICA-LEARN · 1일 집중</div><h1>실습 자료</h1><p class="lead">모든 참가자가 같은 순서와 범위를 끝까지 수행합니다. 각 세션의 산출물을 저장하고 다음 세션의 입력으로 이어 씁니다.</p><div class="rules"><b>세 가지 규칙</b> — 본인에게만 발송 · 비기밀 더미 데이터만 사용 · 승인 창의 대상과 경로 확인</div><h2>09:00–17:00 실습 동선</h2><div class="grid">{''.join(cards)}</div><h2>공통 자료</h2><div class="links"><a href="data/README.md">데이터·정답표</a><a href="sample-sites/room-reservation/index.html">회의실 예약</a><a href="sample-sites/purchase-request/index.html">구매 요청</a><a href="AGENTS-md/README.md">AGENTS.md 예제</a><a href="worksheets/practice-checklist.md">체크리스트</a><a href="worksheets/application-plan-worksheet.docx">적용 계획</a><a href="../instructor/instructor-guide.html">강사용 강의안</a></div></main></body></html>'''

def main():
    for s in SESSIONS:
        if s['num'] in DATA:
            path=next((p for p in (HERE/'prompts').glob(f"D1-{s['num']}-*.md")),None)
            if not path:
                names={"00":"orientation-login","08":"extension-setup"}
                path=HERE/'prompts'/f"D1-{s['num']}-{names[s['num']]}.md"
            path.write_text(render_prompt(s,DATA[s['num']]),encoding='utf-8')
    rows='\n'.join(f"| {s['num']} | {s['title']} | {s['check']} | ☐ |" for s in SESSIONS)
    checklist=f'''# SPICA 1일 집중 과정 · 실습 체크리스트\n\n수료 기준은 세션별 실습 전 과정, 개인 스킬 1건, 동료 스킬 실행 1건, 적용 계획 제출입니다. 모든 참가자가 같은 범위를 수행합니다.\n\n| 세션 | 실습 | 완료 증거 | 확인 |\n| --- | --- | --- | --- |\n{rows}\n\n## 공통 장애 대응\n\n| 증상 | 조치 |\n| --- | --- |\n| 문서 로딩 실패 | 나스카 로그인 → Desktop 재시작 → md·csv 사본 |\n| 승인 창이 안 뜸 | 승인 모드를 `물어보기`로 변경 |\n| Extension이 페이지를 못 읽음 | 로그인·활성 탭·새로고침 확인 |\n| Replay+가 멈춤 | 로딩 대기 단계 추가 후 재검증 |\n| 팀 스페이스 권한 없음 | 조교 공용 실습 공간에서 같은 과정 수행 |\n\n대체 자료나 짝 실습으로 완료한 경우에도 결과 화면을 확인하고 비고를 남깁니다.\n'''
    (HERE/'worksheets/practice-checklist.md').write_text(checklist,encoding='utf-8')
    readme='''# 실습 자료 — SPICA 1일 집중 과정\n\n이 폴더를 참가자에게 통째로 배포합니다. 모든 참가자가 같은 순서와 범위를 수행하며, 각 세션 산출물은 다음 세션에서 이어 씁니다.\n\n- `prompts/`: 세션별 전원 완주 순서·복사용 프롬프트·완료 기준\n- `data/`: 가온테크(주) 더미 문서와 정답표\n- `sample-sites/`: WebMCP·Replay+·E2E용 로컬 HTML\n- `AGENTS-md/`: 업무 규칙 예제\n- `worksheets/`: 실습 체크리스트와 현업 적용 계획\n\n## 세 가지 규칙\n\n1. 메일 받는 사람은 본인 계정으로 고정하고 결재 상신은 하지 않습니다.\n2. 워크스페이스에는 실습 데이터와 비기밀 자료만 넣습니다.\n3. 승인 창의 받는 사람·경로·실행 내용을 읽고 승인합니다.\n\n브라우저 허브는 [index.html](index.html), 전체 시간표는 [../curriculum.md](../curriculum.md), 강사용 진행안은 [../instructor/instructor-guide.html](../instructor/instructor-guide.html)입니다.\n'''
    (HERE/'README.md').write_text(readme,encoding='utf-8')
    (HERE/'index.html').write_text(render_index(),encoding='utf-8')
    print(f"practice: {len(DATA)} guides + index + checklist")

if __name__=='__main__': main()
