#!/usr/bin/env python3
"""1일 과정 발표 덱 16개를 동일한 7장 완주 구조로 생성한다."""
from pathlib import Path
import sys, html

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from course_config import BY_NUM  # noqa: E402

CONTENT = {
"00": dict(lines=[("정의", "SPICA는 대화가 아니라 실행"), ("구성", "Desktop · Extension · Portal"), ("이유", "연결성 · 비용 · 보안"), ("규칙", "본인 발송 · 비기밀 · 승인 확인")], prompt="포털과 나스카에 로그인합니다.\n포털 홈 오른쪽 위의 사용자 이름과\n사내 문서 한 건의 열람 여부를 확인한 뒤\n완료 화면을 조교에게 보여 주세요.", warning="계정 문제가 있는 참가자는 조교가 별도로 지원하고 강사는 정시에 다음 세션을 시작합니다.", asset="spica-3products.svg"),
"01": dict(lines=[("실행", "Desktop을 열고 포털 계정 로그인"), ("점검", "사내망 · 인증서 · 도구 상태"), ("완료", "Setup Wizard 마지막 화면"), ("확인", "첫 대화 한 줄 실행")], prompt="Setup Wizard의 모든 단계를 끝까지 진행하고\n완료 또는 확인 필요 상태를 조교에게 보여 주세요.\n완료 뒤 새 대화에서\n'오늘 안전 규칙 세 가지를 알려 줘'라고 입력합니다.", warning="현장 해결이 15분을 넘으면 예비 PC 또는 짝 실습으로 같은 과정을 이어 갑니다.", asset="setup-wizard.svg"),
"02": dict(lines=[("원문", "메신저 문장 하나 선택"), ("지시", "대상 · 말투 · 길이 지정"), ("검토", "일정 · 장소 · 준비물 확인"), ("저장", "내 역할과 기준을 프로필로")], prompt="아래 메시지를 같은 팀 동료에게 보낼 말투로 다듬어 줘.\n정중하지만 3문장 이내로 쓰고\n일정, 장소, 준비물은 빠뜨리지 마.\n\n[원문 붙여 넣기]", warning="프로필에는 실제 주민번호·계정·비밀번호 같은 민감정보를 적지 않습니다.", asset="desktop-profile.svg"),
"03": dict(lines=[("설정", "승인 모드를 '물어보기'로"), ("검색", "오늘 기준 최신 뉴스 3건"), ("검증", "날짜 · 원문 링크 확인"), ("저장", "경로를 읽고 승인")], prompt="오늘 기준 생성형 AI 관련 주요 뉴스 3건을 찾아\n제목, 발표일, 핵심 한 줄, 원문 링크 표로 정리해 줘.\n검색 기준 시각을 맨 위에 쓰고\nworkspace에 news-check.md로 저장해 줘.", warning="출처 없는 최신 정보는 완료로 보지 않습니다. 저장 승인 창의 경로와 작업을 읽습니다.", asset="desktop-approval.svg"),
"04": dict(lines=[("준비", "나스카 로그인 · 데이터 폴더 열기"), ("질의", "PDF · PPT · Excel · Word"), ("취합", "완료 · 진행 · 지연 표"), ("저장", "weekly-report-summary_W36.docx")], prompt="경영기획팀과 인사팀 W36 주간보고를 읽고\n완료·진행·지연 항목을 담당자와 기한이 있는 표로 취합해 줘.\n근거 파일명을 마지막 열에 쓰고\nweekly-report-summary_W36.docx로 저장해 줘.", warning="워크스페이스에는 실습 데이터만 넣습니다. 인사·급여·도면·원가는 반입하지 않습니다.", asset="desktop-doc-qa.svg"),
"05": dict(lines=[("복사", "예제 AGENTS.md를 워크스페이스 루트로"), ("수정", "내 부서 역할과 검토 기준"), ("비교", "같은 아이디어 적용 전후"), ("토론", "세 관점의 합의·반대·다음 행동")], prompt="'보고서 자동 취합' 아이디어를\nAGENTS.md의 세 관점으로 토론해 줘.\n합의점, 반대 이유, 다음 행동을\n각각 한 줄로 정리해 줘.", warning="파일명은 정확히 AGENTS.md이며 워크스페이스 루트에 둡니다. 변경 뒤에는 새 대화를 엽니다.", asset="desktop-agents-md.svg"),
"06": dict(lines=[("연결", "녹스 실습용 비실명 계정만 사용"), ("요약", "오전 취합 결과를 5줄로 정리"), ("확인", "받는 사람은 반드시 본인"), ("실행", "승인 창을 읽고 발송")], prompt="오전 주간보고 취합 결과를 5줄로 요약하고,\n제목은 '[실습] W36 주간보고 취합'으로 해 줘.\n받는 사람은 내 계정 하나만 지정하고,\n발송 직전에 반드시 내 확인을 받아.", warning="결재 상신은 하지 않습니다. 받는 사람이 본인이 아니면 승인하지 않습니다.", asset="desktop-knox-mail.svg"),
"07": dict(lines=[("대상", "협력사 계약 만료를 매일 확인"), ("조건", "30일 이내 · 자동갱신 아님"), ("시험", "등록 뒤 지금 실행"), ("확인", "대기 → 진행 → 평가")], prompt="매일 오전 9시에 협력사 계약현황을 확인해서\n30일 이내 만료이면서 자동갱신이 아닌 계약을 표로 정리해 줘.\n오늘은 등록 직후 지금 실행으로 시험하고\n결과는 대시보드에만 남겨 줘.", warning="로컬 파일을 쓰는 예약 작업은 PC 전원과 절전 상태의 영향을 받습니다.", asset="desktop-schedule.svg"),
"08": dict(lines=[("설치", "Chrome에서 Extension 확인"), ("연결", "Desktop 연결 표시"), ("권한", "현재 로그인 권한 그대로"), ("한계", "느림 · 로딩 · 팝업 · 화면 변경")], prompt="Chrome에서 SPICA Extension을 열고\nDesktop 연결 상태와 현재 탭 접근 상태를 확인합니다.\n제출·발송 앞에서는 멈추도록 설정을 확인하고\n완료 화면을 조교에게 보여 주세요.", warning="Extension은 사람이 보는 권한 이상을 갖지 않습니다. 제출과 발송 앞에서는 반드시 멈춥니다.", asset="ext-install.svg"),
"09": dict(lines=[("페이지", "현재 보고 있는 화면을 문맥으로"), ("요약", "핵심 다섯 줄"), ("추출", "의사결정 · 담당 · 기한"), ("확인", "페이지 안 근거 위치")], prompt="지금 보고 있는 페이지를 핵심 5줄로 요약하고,\n의사결정 · 담당자 · 기한을 표로 정리해 줘.\n각 항목 옆에 페이지의 근거 문구를 짧게 붙여 줘.", warning="대상 탭을 활성화하고 시작합니다. 붙여 넣기보다 현재 페이지를 직접 읽게 합니다.", asset="ext-sidepanel.svg"),
"10": dict(lines=[("1차", "도구 없이 화면 클릭으로 예약"), ("2차", "WebMCP 도구로 같은 예약"), ("기록", "시간 · 단계 수 · 성공 여부"), ("비교", "화면 변화에 대한 안정성")], prompt="먼저 WebMCP 도구 없이 화면을 직접 조작해\n내일 14:00, 7층, 6인 회의실을 예약해 줘.\n완료 후 같은 조건을 WebMCP 도구로 다시 실행하고\n두 방식의 시간과 단계 수를 표로 비교해 줘.", warning="예약·취소 도구를 호출하기 전 확인 창은 자동 승인 설정과 관계없이 읽습니다.", asset="ext-webmcp-compare.svg"),
"11": dict(lines=[("녹화", "구매요청 한 건을 직접 수행"), ("일반화", "품목·수량·납기를 변수로"), ("검증", "다른 값으로 한 번 재생"), ("저장", "개인 Replay+ 루틴으로")], prompt="구매요청 등록 과정을 Replay+로 기록해 줘.\n품목, 수량, 납기일은 실행할 때 묻게 만들고\n제출 직전에는 반드시 멈춰 확인을 받아.\n다른 값으로 한 번 검증한 뒤 개인 루틴으로 저장해 줘.", warning="녹화 성공보다 재생 검증이 중요합니다. 실패한 단계와 로딩 조건도 함께 남깁니다.", asset="ext-replay-run.svg"),
"12": dict(lines=[("다운로드", "구매요청 사이트의 경비 명세 CSV"), ("보고서", "부서별 집행률과 초과 원인"), ("메일", "받는 사람 본인 확인 후 발송"), ("대시보드", "전체 단계와 결과 확인")], prompt="구매요청 페이지에서 경비 명세 CSV를 내려받고,\n부서별 집행률과 초과 원인을 분석한 보고서를 만들어 줘.\n보고서는 내 계정으로만 발송하고 발송 전에 확인받아.\n완료 후 전체 실행 단계를 대시보드로 보여 줘.", warning="한 지시라도 발송 앞에서는 사람이 승인합니다. 실패하면 대시보드의 해당 단계부터 재개합니다.", asset="ext-e2e.svg"),
"13": dict(lines=[("소재", "주간보고 취합 또는 구매요청 루틴"), ("설명", "언제 쓰는지 · 입력 · 결과"), ("발행", "개인 범위로 저장"), ("검증", "새 대화에서 이름 없이 호출")], prompt="오늘 만든 주간보고 취합 절차를 개인 스킬로 만들어 줘.\n입력은 W36 주간보고 문서들이고\n결과는 담당·기한·지연·근거 파일이 있는 Word 표야.\n저장 전 누락 문서와 출력 파일명을 확인하게 해 줘.", warning="스킬은 권한을 늘리지 않습니다. description에는 사용할 때와 필요한 입력을 구체적으로 씁니다.", asset="portal-skill-studio.svg"),
"14": dict(lines=[("짝", "옆자리와 2인 1조"), ("올리기", "각자 개인 스킬을 팀으로"), ("받기", "서로의 스킬 설치"), ("실행", "이름 없이 실제로 한 번 사용")], prompt="옆 사람이 만든 스킬을 설치한 뒤 새 대화에서\n그 스킬 이름을 직접 말하지 않고 업무를 요청해 봅니다.\n실행 결과와 필요한 입력 파일을 서로 확인하고\n완료 화면을 조교에게 보여 주세요.", warning="보기 권한으로는 업로드할 수 없습니다. 조원에게 편집 권한을 준 뒤 시작합니다.", asset="portal-teamspace.svg"),
"15": dict(lines=[("정리", "오늘 대화와 결정을 블루 노트로"), ("업무", "다음 주 실행할 실제 업무 3건"), ("기준", "완료를 판단할 수 있는 성공 기준"), ("약속", "첫 실행 날짜와 필요한 권한")], prompt="워크시트에 다음 주 SPICA로 실행할 업무 3건을 적습니다.\n각 업무마다 입력 자료, 실행 동사, 결과 형식,\n성공 기준, 첫 실행 날짜, 필요한 권한을 채우고\n작성한 워크시트를 제출해 주세요.", warning="'업무 자동화'처럼 넓게 쓰지 않습니다. 입력과 결과를 다른 사람이 확인할 수 있게 적습니다.", asset="bluenote.svg"),
}

def foot(s):
    return f'<div class="foot"><span>SPICA 실무 과정 · {s["num"]} {html.escape(s["title"])}</span><span class="pg"></span></div>'

def render(num, c):
    s = BY_NUM[num]
    items = ''.join(f'<li><span class="n">{i}</span><span><span class="t">{html.escape(t)}</span><span class="d">{html.escape(d)}</span></span></li>' for i,(t,d) in enumerate(c['lines'],1))
    next_num = f"{int(num)+1:02d}" if num != "15" else None
    next_text = BY_NUM[next_num]['title'] if next_num else "현업에서 첫 업무 실행"
    return f'''<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>SPICA 실무 과정 · {num} {html.escape(s['title'])}</title><link rel="stylesheet" href="../../_assets/deck.css"></head><body><div id="stage">
<section class="slide cover" data-label="표지"><div class="wash"><i style="background:radial-gradient(860px 860px at 90% 10%,rgba(72,173,224,.55),transparent 70%)"></i><i style="background:radial-gradient(760px 760px at 0% 100%,rgba(63,217,143,.38),transparent 70%)"></i></div><div class="inner"><div class="kicker">SPICA 실무 과정 · 1일 집중 · 세션 {num}</div><h1>{html.escape(s['title'])}</h1><div class="sub">{html.escape(s['goal'])}</div><div class="chips"><span class="chip">{s['time']}</span><span class="chip">{s['mins']}분 · {s['form']}</span><span class="chip">산출물 · {html.escape(s['output'])}</span></div></div></section>
<section class="slide quote" data-label="핵심"><div class="mid"><div class="rule"></div><div class="big">{html.escape(s['talk'].split('.')[0])}</div><div class="note">설명으로 끝내지 않고 <b>{html.escape(s['output'])}</b>을 남깁니다.</div></div>{foot(s)}</section>
<section class="slide" data-label="화면"><div class="eyebrow">화면에서 확인</div><h1>시작 화면과 완료 화면을 먼저 맞춥니다</h1><div class="body figure side"><img src="assets/{c['asset']}" alt="{html.escape(s['title'])} 화면"><div class="notes"><div><span>1</span>시작 위치를 전원 함께 확인</div><div><span>2</span>강사 시연은 한 번만 보고 바로 실행</div><div><span>3</span>완료 증거: {html.escape(s['check'])}</div><div class="cap">막히면 같은 동작을 반복하지 말고 손을 듭니다.</div></div></div>{foot(s)}</section>
<section class="slide" data-label="완주 순서"><div class="eyebrow">전원 동일 실습</div><h1>한 흐름으로 끝까지 갑니다</h1><div class="body"><ul class="list">{items}</ul></div>{foot(s)}</section>
<section class="slide" data-label="실습 프롬프트"><div class="eyebrow">복사해서 시작</div><h1>지시와 확인 기준을 한 번에 줍니다</h1><div class="body practice"><ul class="list"><li><span class="n">1</span><span><span class="t">화면의 시작 위치 확인</span><span class="d">강사와 같은 상태에서 시작</span></span></li><li><span class="n">2</span><span><span class="t">프롬프트 실행</span><span class="d">승인 창은 읽고 결정</span></span></li><li><span class="n">3</span><span><span class="t">산출물 저장</span><span class="d">조교에게 완료 화면 제시</span></span></li></ul><div><div class="prompt"><div class="lbl">실습 프롬프트</div><pre>{html.escape(c['prompt'])}</pre><div class="exp">완료 기준 · <b>{html.escape(s['check'])}</b></div></div></div></div>{foot(s)}</section>
<section class="slide" data-label="안전 확인"><div class="eyebrow">실행 전 확인</div><h1>마지막 한 번은 사람이 확인합니다</h1><div class="body"><div class="warn"><span>{html.escape(c['warning'])}</span></div><div class="tip"><span>문제가 생기면: {html.escape(s['issue'])}</span></div></div>{foot(s)}</section>
<section class="slide end" data-label="마무리"><div class="mid"><div class="eyebrow">세션 {num} 완료</div><h1>{html.escape(s['output'])}을 남겼습니다</h1><div class="three"><div><span>1</span>{html.escape(s['goal'])}</div><div><span>2</span>{html.escape(s['check'])}</div><div><span>3</span>저장하고 다음 세션의 입력으로 사용</div></div><div class="next">다음 · <b>{html.escape(next_text)}</b></div></div>{foot(s)}</section>
</div><script src="../../_assets/deck.js"></script></body></html>'''

def main():
    here = Path(__file__).parent
    for num, content in sorted(CONTENT.items()):
        path = here / f"{num}.{BY_NUM[num]['slug']}.html"
        path.write_text(render(num, content), encoding="utf-8")
    print(f"decks: {len(CONTENT)} generated (all sessions)")

if __name__ == "__main__":
    main()
