#!/usr/bin/env python3
"""1일 집중 과정 발표 덱 목록을 생성한다."""
from pathlib import Path
import html, re, sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
from course_config import SESSIONS  # noqa: E402

CSS = """
:root{--ink:#344256;--mid:#677180;--soft:#858e9a;--line:#e1e3e6;--panel:#f4f6fa;--acc:#007fff;--brand:linear-gradient(90deg,#ebce14,#fa5c96 25%,#48ade0 50%,#3fd98f 75%,#ebce14)}
*{box-sizing:border-box;margin:0;padding:0}body{font-family:'Pretendard','Apple SD Gothic Neo','Malgun Gothic',system-ui,sans-serif;color:var(--ink);line-height:1.55;word-break:keep-all}a{color:var(--acc);text-decoration:none}.brandbar{height:6px;background:var(--brand)}.wrap{max-width:1120px;margin:auto;padding:40px 24px 80px}.kicker{font-size:13px;font-weight:700;color:var(--acc)}h1{font-size:38px;margin-top:8px}.lead{color:var(--mid);margin-top:10px;max-width:820px}.keys{margin-top:14px;font-size:13px;color:var(--soft)}.keys b{padding:2px 7px;border-radius:5px;background:var(--panel);margin-right:3px}h2{font-size:20px;margin:36px 0 12px;color:var(--soft)}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(310px,1fr));gap:12px}.deck{display:block;border-radius:14px;padding:18px 20px;box-shadow:inset 0 0 0 1px var(--line);color:var(--ink)}.deck:hover{box-shadow:inset 0 0 0 2px var(--acc)}.n{font-size:12px;color:var(--soft);font-weight:700}.n b{display:inline-flex;width:30px;height:30px;align-items:center;justify-content:center;border-radius:50%;background:var(--panel);color:var(--acc);margin-right:8px}.deck h3{font-size:16px;margin-top:7px}.deck p{font-size:13px;color:var(--mid);margin-top:6px}.m{font-size:12px;color:var(--soft);margin-top:10px;font-family:ui-monospace,monospace}.note{font-size:13px;color:var(--soft);margin-top:26px}
"""

def main():
    cards=[]; total=0
    for s in SESSIONS:
        name=f"{s['num']}.{s['slug']}.html"; path=HERE/name
        src=path.read_text(encoding="utf-8")
        count=len(re.findall(r'<section class="slide',src)); total+=count
        cards.append(f'<a class="deck" href="{name}"><div class="n"><b>{s["num"]}</b>{s["time"]} · {s["mins"]}분 · {s["form"]}</div><h3>{html.escape(s["title"])}</h3><p>{html.escape(s["goal"])}</p><div class="m">{count}장 · {name}</div></a>')
    page=f'''<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>SPICA 1일 집중 과정 · 발표 슬라이드</title><style>{CSS}</style></head><body><div class="brandbar"></div><div class="wrap"><div class="kicker">EDU-CLASS · 02.SPICA-LEARN · 발표용</div><h1>SPICA 1일 집중 과정 발표 슬라이드</h1><p class="lead">09:00–17:00 한 번의 흐름으로 진행합니다. 총 16개 덱 · {total}장. 각 세션은 하나의 실습 산출물로 닫고 다음 세션으로 연결됩니다.</p><p class="keys"><b>←</b><b>→</b> 이동 · <b>O</b> 전체 보기 · <b>F</b> 전체 화면 · <b>P</b> 인쇄(PDF)</p><h2>1일 과정 · 오전 Desktop → 오후 Extension · Portal</h2><div class="grid">{''.join(cards)}</div><p class="note"><a href="../curriculum.html">커리큘럼</a> · <a href="../instructor/instructor-guide.html">강사용 강의안</a> · <a href="../practice/index.html">실습 자료</a></p></div></body></html>'''
    (HERE/'index.html').write_text(page,encoding='utf-8')
    print(f"index.html: {len(cards)} decks, {total} slides")

if __name__ == '__main__': main()
