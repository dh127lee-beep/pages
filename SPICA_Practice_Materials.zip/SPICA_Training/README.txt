SPICA 교육 실습 자료

1. ZIP을 모두 풀어 주세요.
2. SPICA_Training 폴더를 데스크톱 워크스페이스로 선택하세요.
3. 00_getting_started.html을 Chrome 또는 Edge로 여세요.
4. prompt_collection.html에서 복사 버튼을 사용하세요.

01_source: Word 3개, Excel 1개
02_results: 결과를 저장할 빈 폴더
03_web_labs: 공지, WebMCP 조회, Replay+ 다운로드 페이지
04_reference: AGENTS 예시, 메일 원문, 프롬프트 TXT, 진행자 안내

모든 데이터는 교육용 가상 자료입니다.
